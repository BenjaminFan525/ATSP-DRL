"""Regression tests for frozen-head transfer, selection and paired BC audits."""

import copy
import json
import random
from pathlib import Path
from types import SimpleNamespace
import unittest
from tempfile import TemporaryDirectory

import numpy as np
import torch

from onpolicy.config.config import get_config
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.shared_hkbz_evaluator import _request_cache_key
from onpolicy.scripts.train.analyze_stage2_bc_injection import paired_comparison, evaluation_cases
from onpolicy.utils.stage2_bc_contract import (
    capture_rng_state, restore_rng_state, choose_best_epoch,
    ready_head_config, ready_head_signature, supervised_gate,
    validate_frozen_ready_checkpoint,
    json_safe, supervised_optimizer_step,
    compare_reference_cases,
    copy_bc_epoch_evidence,
    portable_rng_state,
)
from onpolicy.utils.training_stage import CANONICAL_RESOURCE_JOINT


class TinyActor(torch.nn.Module):
    def __init__(self, injection):
        super().__init__()
        self.request_ready_prediction = True
        self.request_ready_policy_injection = injection
        self.request_ready_time_scale = 3600.0
        self.request_ready_hard_blocking = True
        self.request_ready_head = torch.nn.Linear(4, 1)
        self.request_ready_feature = torch.nn.Linear(2, 4, bias=False)
        torch.nn.init.zeros_(self.request_ready_feature.weight)
        self.resource = torch.nn.Linear(4, 2)
        self.transporter_sel_enc = torch.nn.Linear(4, 4)
        self.transporter_actor = torch.nn.Linear(4, 2)
        self.encoder = torch.nn.Linear(4, 4)
        self.actor = torch.nn.Linear(4, 2)
        self.critic = torch.nn.Linear(4, 1)
        self.device_actor_param = SimpleNamespace(modules=[
            self.resource, self.request_ready_head, self.request_ready_feature,
        ])


def runner_for(ac):
    runner = object.__new__(HKBZ_Runner)
    runner.policy = SimpleNamespace(ac=ac)
    runner.device_bc_training_scope = 'policy_frozen_ready'
    runner.device_bc_train_gnn = False
    runner.training_stage = CANONICAL_RESOURCE_JOINT
    return runner


class FrozenReadyInjectionTest(unittest.TestCase):
    def test_scope_keeps_head_shared_plane_and_critic_out_of_optimizer(self):
        initial = None
        for injection in ('none', 'dag', 'learned'):
            torch.manual_seed(17)
            ac = TinyActor(injection)
            runner = runner_for(ac)
            params = [p for module in runner._device_bc_trainable_modules() for p in module.parameters()]
            runner._set_device_bc_requires_grad(params)
            self.assertFalse(ac.request_ready_head.weight.requires_grad)
            self.assertFalse(ac.encoder.weight.requires_grad)
            self.assertFalse(ac.actor.weight.requires_grad)
            self.assertFalse(ac.critic.weight.requires_grad)
            self.assertEqual(ac.request_ready_feature.weight.requires_grad, injection != 'none')
            before = copy.deepcopy(ac.state_dict())
            x = torch.ones(3, 4)
            features = torch.cat([torch.ones(3, 1), torch.nn.functional.softplus(ac.request_ready_head(x))], dim=-1)
            if injection == 'dag':
                features[:, 1] = 0
            augmented = x if injection == 'none' else x + ac.request_ready_feature(features)
            logits = ac.resource(augmented)
            if initial is None:
                initial = logits.detach().clone()
            self.assertTrue(torch.equal(logits.detach(), initial))
            optimizer = torch.optim.Adam(params, lr=0.001)
            logits.square().mean().backward()
            optimizer.step()
            after = ac.state_dict()
            for prefix in ('request_ready_head.', 'encoder.', 'actor.', 'critic.'):
                self.assertTrue(all(torch.equal(before[k], after[k]) for k in before if k.startswith(prefix)))
            self.assertFalse(torch.equal(before['resource.weight'], after['resource.weight']))
            self.assertEqual(torch.equal(before['request_ready_feature.weight'], after['request_ready_feature.weight']), injection == 'none')

    def test_checkpoint_rejects_wrong_source_routing_shapes_and_finiteness(self):
        ac = TinyActor('learned')
        checkpoint = {
            'stage2_training_mode': 'ready_predictor_only', 'source_m2_sha256': 'source',
            'resource_lookahead_contract': {'H': 2, 'F': 4},
            'request_ready_time_scale': 3600.0, **ready_head_config(ac),
            'protected_parameter_summary_before_bc': {'sha256': 'unchanged'},
            'protected_parameter_summary_after_bc': {'sha256': 'unchanged'},
            'resource_actor_summary_before_bc': {'sha256': 'resource'},
            'resource_actor_summary_after_bc': {'sha256': 'resource'},
            'model': copy.deepcopy(ac.state_dict()),
        }
        def validate(payload):
            return validate_frozen_ready_checkpoint(payload, ac, source_sha256='source',
                                                     planning_contract={'H': 2, 'F': 4})
        self.assertEqual(set(validate(checkpoint)), {'weight', 'bias'})
        for key, value in [('source_m2_sha256', 'other'), ('request_ready_hard_blocking', False),
                           ('request_ready_time_scale', 60.0), ('stage2_training_mode', 'supervised_only')]:
            bad = copy.deepcopy(checkpoint)
            bad[key] = value
            with self.assertRaises(ValueError):
                validate(bad)
        bad = copy.deepcopy(checkpoint)
        bad['model']['request_ready_head.weight'][0, 0] = float('nan')
        with self.assertRaises(ValueError):
            validate(bad)

    def test_eval_cache_changes_for_each_routing_field(self):
        request = {'model_sha256': 'a' * 64, **ready_head_config({})}
        original = _request_cache_key(request)
        for key, default in ready_head_config({}).items():
            changed = {**request, key: 'horizon_split' if isinstance(default, str) else not default}
            self.assertNotEqual(original, _request_cache_key(changed))
            self.assertNotEqual(ready_head_signature(request), ready_head_signature(changed))

    def test_epoch_selection_does_not_promote_last_or_rejected_epoch(self):
        records = [{'epoch': 1, 'gate': {'passed': True}, 'metrics': {'eval_raw_makespan': 8000}},
                   {'epoch': 2, 'gate': {'passed': True}, 'metrics': {'eval_raw_makespan': 8200}},
                   {'epoch': 3, 'gate': {'passed': False}, 'metrics': {'eval_raw_makespan': 7800}}]
        self.assertEqual(choose_best_epoch(records)['epoch'], 1)
        self.assertIsNone(choose_best_epoch([records[-1]]))

    def test_gate_fails_closed_on_nan_and_incomplete_cases(self):
        pre = {'eval_raw_makespan': 9000, 'eval_distribution_ood_stress_makespan': 9500}
        post = {**pre, 'eval_raw_makespan': 8300, 'eval_valid': 1.0,
                'eval_completion_rate': 1.0, 'eval_cycle_count': 0, 'eval_timeout_count': 0}
        def gate(row):
            return supervised_gate(pre, row, max_raw_regression=0, max_stress_regression=30)
        self.assertTrue(gate(post)['passed'])
        for key, value in [('eval_raw_makespan', float('nan')), ('eval_timeout_count', 1),
                           ('eval_completion_rate', 0.99), ('eval_distribution_ood_stress_makespan', 9531)]:
            self.assertFalse(gate({**post, key: value})['passed'])

    def test_rng_roundtrip(self):
        state = capture_rng_state()
        expected = (random.random(), np.random.random(), torch.rand(4))
        restore_rng_state(state)
        self.assertEqual(random.random(), expected[0])
        self.assertEqual(np.random.random(), expected[1])
        self.assertTrue(torch.equal(torch.rand(4), expected[2]))

    def test_rng_checkpoint_supports_weights_only_loading(self):
        state = capture_rng_state()
        legacy = {**state, 'numpy': np.random.get_state()}
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / 'state.pt'
            torch.save({'rng': portable_rng_state(legacy)}, path)
            loaded = torch.load(path, weights_only=True)
            restore_rng_state(loaded['rng'])
            self.assertEqual(loaded['rng']['numpy'], state['numpy'])

    def test_constant_matching_loss_does_not_step_or_backward(self):
        parameter = torch.nn.Parameter(torch.tensor([1.0]))
        optimizer = torch.optim.Adam([parameter], lr=0.1)
        norm, stepped = supervised_optimizer_step(torch.tensor(0.0), optimizer,
                                                  enabled=True, max_grad_norm=1.0)
        self.assertFalse(stepped)
        self.assertEqual(float(norm), 0.0)
        self.assertFalse(optimizer.state)
        _, stepped = supervised_optimizer_step(parameter.square().sum(), optimizer,
                                                enabled=True, max_grad_norm=1.0)
        self.assertTrue(stepped)
        self.assertLess(float(parameter), 1.0)

    def test_teacher_execution_rate_excludes_finished_padding_environments(self):
        runner = object.__new__(HKBZ_Runner)
        runner.policy = SimpleNamespace(ac=SimpleNamespace(max_plane_agents=1))
        runner.num_agents = 2
        actions = np.zeros((2, 2, 2), dtype=np.int64)
        _, _, stats = runner._merge_device_bc_actions(
            actions, [{'actions': action, 'info': {}} for action in actions],
            teacher_execution_mask=[True, False], active_env_mask=[True, False],
        )
        self.assertEqual(stats['teacher_executed_envs'], 1)
        self.assertEqual(stats['student_executed_envs'], 0)

    def test_unavailable_auxiliary_metrics_serialize_without_hiding_raw_failure(self):
        self.assertEqual(json_safe({'auxiliary': float('inf'), 'raw': 8100}),
                         {'auxiliary': None, 'raw': 8100})

    def test_reference_replay_requires_each_complete_case_to_match(self):
        expected = [{'case_sha256': 'a', 'makespan': 8., 'completed': True},
                    {'case_sha256': 'b', 'makespan': 12., 'completed': True}]
        def compare(actual):
            return compare_reference_cases(expected, actual, case_count=2, tolerance_seconds=1e-5)
        self.assertTrue(compare(list(reversed(expected)))['passed'])
        changed = [{**expected[0], 'makespan': 9.}, {**expected[1], 'makespan': 11.}]
        self.assertFalse(compare(changed)['passed'])  # The mean alone still matches.
        with self.assertRaises(ValueError):
            compare([expected[0], {**expected[1], 'completed': False}])
        with self.assertRaises(ValueError):
            compare([expected[0], {**expected[1], 'case_sha256': 'c'}])

    def test_recovery_retains_boundary_evidence_without_future_epoch_rows(self):
        with TemporaryDirectory() as temporary:
            source, destination = Path(temporary) / 'old', Path(temporary) / 'new'
            for name in ('evaluations/pre_supervised.json', 'evaluations/bc_epoch_1.json',
                         'logs/request_ready_cases_epoch1.json'):
                path = source / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('{}')
            metrics = Path('logs/request_ready_epoch_metrics.jsonl')
            (source / metrics).write_text(''.join(json.dumps({'device_bc_epoch': epoch}) + '\n'
                                                for epoch in (1, 2)))
            copy_bc_epoch_evidence(source, destination, 1)
            self.assertTrue((destination / 'evaluations/bc_epoch_1.json').exists())
            rows = [json.loads(line) for line in (destination / metrics).read_text().splitlines()]
            self.assertEqual(rows, [{'device_bc_epoch': 1}])
            with self.assertRaises(FileExistsError):
                copy_bc_epoch_evidence(source, destination, 1)
            with self.assertRaises(FileNotFoundError):
                copy_bc_epoch_evidence(source, Path(temporary) / 'missing', 2)

    def test_case_statistics_keep_horizon_sums(self):
        stats = HKBZ_Runner._request_ready_case_metric_sums(
            torch.tensor([[10., 30., 0.]]), torch.zeros(1, 3), torch.ones(1, 3, dtype=torch.bool),
            torch.tensor([[False, False, True]]), ['case'], torch.tensor([[1, 2, 3]]))
        self.assertEqual(stats['case']['count'], 2)
        self.assertEqual(stats['case']['h1_abs_error_sum'], 10)
        self.assertEqual(stats['case']['h2_abs_error_sum'], 30)
        self.assertEqual(stats['case']['blocking_count'], 0)

    def test_case_pairing_requires_hash_identity(self):
        with self.assertRaises(ValueError):
            paired_comparison({'a': 10}, {'b': 10})
        result = paired_comparison({'a': 8, 'b': 18}, {'a': 10, 'b': 20})
        self.assertEqual(result['mean_delta_seconds'], -2)
        self.assertEqual(result['case_bootstrap_95ci_seconds'], [-2, -2])

    def test_epoch_case_audit_rejects_nonfinite_or_missing_cases(self):
        case = {'case_sha256': 'a', 'makespan': 8., 'completed': True,
                'cycle_terminated': False, 'timeout': False}
        self.assertEqual(evaluation_cases({'cases': [case]}, 1), {'a': 8.})
        with self.assertRaises(ValueError):
            evaluation_cases({'cases': [{**case, 'makespan': float('nan')}]}, 1)
        with self.assertRaises(ValueError):
            evaluation_cases({'cases': [case]}, 2)

    def test_new_options_parse_without_changing_legacy_defaults(self):
        parser = get_config()
        defaults = parser.parse_args([])
        self.assertEqual(defaults.device_bc_training_scope, 'policy_and_ready')
        self.assertFalse(defaults.device_bc_eval_each_epoch)
        self.assertFalse(defaults.stage2_bc_deterministic)
        args = parser.parse_args(['--device_bc_training_scope', 'policy_frozen_ready',
                                  '--request_ready_checkpoint', '/tmp/ready.pt',
                                  '--device_bc_eval_each_epoch', '--stage2_bc_deterministic',
                                  '--train_sampling_seed', '1'])
        self.assertEqual(args.train_sampling_seed, 1)
        self.assertTrue(args.device_bc_eval_each_epoch)
        self.assertTrue(args.stage2_bc_deterministic)


if __name__ == '__main__':
    unittest.main()
