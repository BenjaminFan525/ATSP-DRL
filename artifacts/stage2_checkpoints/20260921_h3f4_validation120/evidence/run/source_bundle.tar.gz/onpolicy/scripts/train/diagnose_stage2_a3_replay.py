#!/usr/bin/env python3
"""Bounded, fresh-process A3 replay probes; never start or alter a trainer."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from onpolicy.utils.shared_eval import parse_cpu_set
from onpolicy.utils.stage2_bc_contract import compare_reference_cases


def write_json(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    temporary.replace(path)


def set_option(command, flag, value):
    index = command.index(flag)
    command[index + 1] = str(value)


def stop_owned(process):
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--failed-suite', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--variants', nargs='+', choices=(
        '12_strict', '20_legacy', '20_strict', '12_legacy'),
        default=['12_strict', '20_legacy'])
    parser.add_argument('--hard-timeout-seconds', type=int, default=3600)
    args = parser.parse_args()
    if len(set(args.variants)) != len(args.variants) or len(args.variants) > 2:
        raise ValueError('Use one or two distinct variants per bounded probe.')
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('Only physical GPU0 is authorized.')
    allowed = set(range(32)) | set(range(64, 96))
    if not allowed.issubset(os.sched_getaffinity(0)):
        raise ValueError('CPU allowance does not contain the reserved half.')
    # All children belong to a dedicated systemd cgroup confined to this half.
    os.sched_setaffinity(0, parse_cpu_set('30-31,94-95'))
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    source = args.failed_suite.resolve()
    manifest = json.loads((source / 'manifest.json').read_text())
    reference = manifest['reference_validation']
    original = json.loads(Path(reference['expected_evaluation']).read_text())
    failed = json.loads((source / 'reference_a3.json').read_text())
    base_command = json.loads((source / 'evaluator_source.json').read_text())['command']
    # Reuse the explicit source allowlist, not the interactive shell's PATH or
    # a broad repository walk (which could include private/unrelated files).
    source_paths = set(manifest['code_fingerprint'])
    source_paths.add(str(Path(__file__).resolve().relative_to(ROOT)))
    fingerprints = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                    for name in sorted(source_paths)}
    status = {'status': 'running', 'started_unix_time': time.time(),
              'failed_suite': str(source), 'reference': reference,
              'code_fingerprint': fingerprints,
              'allowed_cpus': '0-31,64-95', 'gpu': 0,
              'fresh_service_per_variant': True, 'variants': {}}
    status['hardware'] = subprocess.check_output([
        'nvidia-smi', '--query-gpu=index,uuid,name,driver_version',
        '--format=csv,noheader'], text=True)
    import torch
    status['runtime'] = {'python': sys.version, 'torch': str(torch.__version__),
                         'cuda': torch.version.cuda}
    write_json(output / 'diagnostic_status.json', status)
    running, owned, handles = {}, [], []
    try:
        for index, variant in enumerate(args.variants):
            workers, arithmetic = variant.split('_')
            cpus = ('0-13,64-77', '14-29,78-93')[index]
            directory = output / variant
            directory.mkdir()
            command = list(base_command)
            set_option(command, '--n_eval_rollout_threads', workers)
            if '--stage2_bc_deterministic' in command:
                command.remove('--stage2_bc_deterministic')
            environment = os.environ.copy()
            environment.pop('CUBLAS_WORKSPACE_CONFIG', None)
            if arithmetic == 'strict':
                command.append('--stage2_bc_deterministic')
                environment['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
            write_json(directory / 'evaluator_source.json', {'command': command})
            socket = Path('/tmp') / ('hkbz-a3diag-' + hashlib.sha256(
                str(directory).encode()).hexdigest()[:16] + '.sock')
            if socket.exists():
                raise FileExistsError(socket)
            service_command = [sys.executable, '-u',
                str(ROOT / 'onpolicy/scripts/train/shared_hkbz_evaluator.py'),
                '--source-command-json', str(directory / 'evaluator_source.json'),
                '--socket-path', str(socket), '--cpu-pool', cpus,
                '--run-dir', str(directory / 'service'),
                '--eval-dataset-dir', manifest['evaluation_contract']['dataset'],
                '--max-eval-cases', '60', '--cuda-memory-fraction', '0.20']
            handle = (directory / 'evaluator.log').open('x')
            handles.append(handle)
            service = subprocess.Popen(['taskset', '-c', cpus, *service_command],
                cwd=ROOT, env=environment, stdout=handle, stderr=subprocess.STDOUT,
                start_new_session=True)
            owned.append(service)
            running[variant] = dict(service=service, client=None, socket=socket,
                                    directory=directory, cpus=cpus, workers=workers,
                                    environment=environment)
            status['variants'][variant] = dict(status='starting', pid=service.pid,
                cpu_set=cpus, workers=int(workers), strict=arithmetic == 'strict',
                service_command=service_command)
        last_heartbeat = 0
        while running:
            elapsed = time.time() - status['started_unix_time']
            if elapsed > args.hard_timeout_seconds:
                raise TimeoutError('Declared A3 diagnostic hard timeout reached.')
            for variant, item in list(running.items()):
                service, client = item['service'], item['client']
                if service.poll() is not None:
                    raise RuntimeError(f'{variant} service exited: {service.returncode}')
                if client is None and item['socket'].exists():
                    client_command = [sys.executable, '-u', str(ROOT /
                        'onpolicy/scripts/train/evaluate_stage1_shared_checkpoint.py'),
                        '--socket-path', str(item['socket']),
                        '--checkpoint', reference['checkpoint'], '--cpu-set', item['cpus'],
                        '--seed', '1', '--output', str(item['directory'] / 'evaluation.json'),
                        '--label', variant, '--evaluation-tau', '0.3',
                        '--n-eval-rollout-threads', item['workers']]
                    handle = (item['directory'] / 'client.log').open('x')
                    handles.append(handle)
                    client = subprocess.Popen(client_command, cwd=ROOT,
                        env=item['environment'], stdout=handle, stderr=subprocess.STDOUT,
                        start_new_session=True)
                    owned.append(client)
                    item['client'] = client
                    status['variants'][variant].update(status='evaluating',
                        client_pid=client.pid, client_command=client_command)
                if client is not None and client.poll() is not None:
                    if client.returncode:
                        raise RuntimeError(f'{variant} client exited: {client.returncode}')
                    actual = json.loads((item['directory'] / 'evaluation.json').read_text())
                    comparison = {}
                    for label, expected in [('historical', original['cases']),
                            ('failed_strict12', failed['evaluation']['records'])]:
                        comparison[label] = compare_reference_cases(expected,
                            actual['evaluation']['records'], case_count=60,
                            tolerance_seconds=1e-5)
                    write_json(item['directory'] / 'comparison.json', comparison)
                    status['variants'][variant].update(status='completed',
                        comparison=comparison, evaluation_seconds=actual['evaluation_seconds'])
                    stop_owned(service)
                    del running[variant]
            if time.monotonic() - last_heartbeat >= 30:
                last_heartbeat = time.monotonic()
                status['updated_unix_time'] = time.time()
                write_json(output / 'diagnostic_status.json', status)
                print(f'[A3Diagnostic] elapsed={elapsed:.0f}s ' + repr({
                    name: item['status'] for name, item in status['variants'].items()}), flush=True)
            time.sleep(2)
        status['status'] = 'completed'
    except BaseException as error:
        status.update(status='failed', error=str(error))
        raise
    finally:
        for process in reversed(owned):
            stop_owned(process)
        for handle in handles:
            handle.close()
        status['ended_unix_time'] = time.time()
        write_json(output / 'diagnostic_status.json', status)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    main()
