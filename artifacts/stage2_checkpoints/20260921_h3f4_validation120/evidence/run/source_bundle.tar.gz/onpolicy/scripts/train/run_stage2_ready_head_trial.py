#!/usr/bin/env python3
"""Execute one affinity-bound predictor-only command from a suite manifest."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import time


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.utils.shared_eval import format_cpu_set, parse_cpu_set  # noqa: E402


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f'.{path.name}.tmp.{os.getpid()}')
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)
        + '\n',
        encoding='utf-8',
    )
    os.replace(temporary, path)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--command-key', required=True)
    parser.add_argument('--gpu', type=int, required=True)
    parser.add_argument('--cpu-set', required=True)
    parser.add_argument('--start-delay-seconds', type=float, default=0.0)
    parser.add_argument('--record', type=Path, required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    requested = parse_cpu_set(args.cpu_set)
    allowed = frozenset(os.sched_getaffinity(0))
    if requested != allowed:
        raise RuntimeError(
            'Trainer cgroup affinity mismatch: '
            f'requested={format_cpu_set(requested)}, '
            f'allowed={format_cpu_set(allowed)}'
        )
    if os.environ.get('CUDA_VISIBLE_DEVICES', '') != str(args.gpu):
        raise RuntimeError('CUDA_VISIBLE_DEVICES does not match --gpu.')
    payload = json.loads(args.manifest.read_text(encoding='utf-8'))
    entry = payload.get('commands', {}).get(args.command_key)
    if not isinstance(entry, dict):
        raise KeyError(f'Unknown predictor method {args.command_key!r}.')
    command = list(entry['argv'])
    if command[0] != sys.executable:
        command[0] = sys.executable

    # Predictor output is deliberately disconnected from the policy, so a
    # Cmax evaluator would execute the exact same frozen policy six times.
    # Disable it explicitly and preserve the CPU/GPU budget for supervision.
    remove_option(command, '--shared_eval_socket', takes_value=True)
    remove_option(command, '--shared_eval_cpu_set', takes_value=True)
    remove_option(command, '--n_eval_rollout_threads', takes_value=True)
    set_option(command, '--n_eval_rollout_threads', 1)
    set_switch(command, '--use_eval', False)
    set_switch(command, '--safe_graph_batch_pipeline', True)
    set_switch(command, '--safe_dagger_teacher_overlap', True)
    set_option(command, '--safe_async_graph_clone_workers', 4)
    set_option(command, '--torch_mp_sharing_strategy', 'file_descriptor')
    set_option(command, '--ipc_timeout_seconds', 600)

    record = {
        'schema_version': 1,
        'manifest': str(args.manifest.resolve()),
        'command_key': args.command_key,
        'gpu': args.gpu,
        'cpu_set': args.cpu_set,
        'launcher_pid': os.getpid(),
        'created_unix_time': time.time(),
        'start_delay_seconds': args.start_delay_seconds,
        'command': command,
        'status': 'waiting' if args.start_delay_seconds else 'starting',
    }
    atomic_json(args.record, record)
    if args.start_delay_seconds:
        time.sleep(args.start_delay_seconds)
    record['status'] = 'exec'
    record['exec_unix_time'] = time.time()
    atomic_json(args.record, record)
    os.execv(command[0], command)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
