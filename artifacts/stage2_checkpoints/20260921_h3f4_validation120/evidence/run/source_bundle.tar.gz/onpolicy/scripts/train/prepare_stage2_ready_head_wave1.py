#!/usr/bin/env python3
"""Prepare the preregistered Stage2 intrinsic-ready predictor-only screen."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    DEFAULT_HANDOFF,
    DEFAULT_PYTHON,
    atomic_json,
    sha256_file,
    source_contract,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    build_stage2_command,
    remove_option,
    set_option,
    set_switch,
)


DEFAULT_TEACHER_INDEX = (
    ROOT / 'result/hkbz_train_logs/stage2_supervised_hf_labels_20260901_r1/'
    'stage2_bc_labels/iga1800/stage2_bc_teacher_index.json'
)

# All arms see the same 240 cases three times with seed 1.  Only the predictor
# optimizer and its loss differ; no arm is allowed to change policy behavior.
METHODS = {
    'P0_log_lr3e5': {
        'learning_rate': 3e-5,
        'seconds_loss_coef': 0.0,
        'h2_weight': 1.0,
        'hypothesis': 'historical log-Huber objective, isolated from policy BC',
    },
    'P1_log_lr3e4': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.0,
        'h2_weight': 1.0,
        'hypothesis': '10x learning rate after removing joint gradient clipping',
    },
    'P2_log_lr1e3': {
        'learning_rate': 1e-3,
        'seconds_loss_coef': 0.0,
        'h2_weight': 1.0,
        'hypothesis': 'upper learning-rate probe for the small isolated head',
    },
    'P3_hybrid_lr3e4': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.10,
        'h2_weight': 1.0,
        'hypothesis': 'log-Huber plus direct seconds-domain error pressure',
    },
    'P4_h2x3_lr3e4': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.0,
        'h2_weight': 3.0,
        'hypothesis': 'emphasize the long-horizon H2 frontier',
    },
    'P5_hybrid_h2x3_lr3e4': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.10,
        'h2_weight': 3.0,
        'hypothesis': 'combine seconds calibration and H2 emphasis',
    },
}


def configure(base, method_id, method, run_tag):
    command = list(base)
    set_option(
        command,
        '--experiment_name',
        f'{run_tag}_ready_head_wave1_{method_id}_seed1',
    )
    set_option(command, '--seed', 1)
    set_option(command, '--n_rollout_threads', 24)
    set_option(command, '--n_eval_rollout_threads', 1)
    set_option(command, '--max_train_cases', 240)
    set_option(command, '--train_sampling_size', 240)
    set_option(command, '--train_sampling_mode', 'distribution_balanced')
    set_option(
        command,
        '--train_sampling_weights',
        'iid=0.50,ood_stress=0.45,ood_scale=0.05',
    )
    set_option(command, '--device_bc_pretrain_epochs', 3)
    set_option(command, '--device_bc_min_rollouts_per_epoch', 10)
    set_option(command, '--device_bc_max_rollouts_per_epoch', 10)
    set_option(command, '--device_bc_min_labels_per_epoch', 64)
    set_option(command, '--device_bc_training_scope', 'ready_only')
    set_option(command, '--device_bc_lr', method['learning_rate'])
    set_option(command, '--device_bc_dagger_schedule', '1.0')
    set_option(command, '--device_bc_categorical_loss_coef', 0.0)
    set_option(command, '--device_bc_ranking_loss_coef', 0.0)
    set_option(command, '--device_bc_min_ranking_labels_per_epoch', 0)
    set_option(command, '--device_bc_timing_loss_coef', 0.0)
    set_option(command, '--device_bc_assignment_loss_coef', 0.0)
    set_option(command, '--device_bc_assignment_margin_loss_coef', 0.0)
    set_option(command, '--device_bc_min_assignment_labels_per_epoch', 0)
    set_option(command, '--request_ready_loss_coef', 1.0)
    set_option(
        command,
        '--request_ready_seconds_loss_coef',
        method['seconds_loss_coef'],
    )
    set_option(command, '--request_ready_seconds_loss_scale', 600.0)
    set_option(command, '--request_ready_h1_weight', 1.0)
    set_option(command, '--request_ready_h2_weight', method['h2_weight'])
    set_option(command, '--request_ready_departure_weight', 1.0)
    set_option(command, '--request_ready_underprediction_weight', 2.0)
    set_option(command, '--request_ready_blocking_weight', 2.0)
    set_option(command, '--request_ready_min_labels_per_epoch', 64)
    set_option(command, '--request_ready_policy_injection', 'none')
    set_option(command, '--max_graphs_per_forward', 1000)
    set_option(command, '--cuda_memory_fraction', 0.30)
    set_option(command, '--status_heartbeat_seconds', 30)
    set_switch(command, '--rollout_until_done', True)
    set_switch(command, '--use_eval', False)
    set_switch(command, '--device_bc_role_balanced', False)
    set_switch(command, '--device_bc_timing_balanced', False)
    for flag in ('--resume_stage1', '--resume_stage2'):
        remove_option(command, flag, takes_value=False)
    return command


def _option(command, name):
    index = command.index(name)
    return command[index + 1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--handoff', type=Path, default=DEFAULT_HANDOFF)
    parser.add_argument('--source-seed', type=int, default=3)
    parser.add_argument('--teacher-index', type=Path, default=DEFAULT_TEACHER_INDEX)
    parser.add_argument('--python', type=Path, default=DEFAULT_PYTHON)
    args = parser.parse_args()

    source, source_command = source_contract(
        args.handoff.resolve(), args.source_seed
    )
    teacher_index_path = args.teacher_index.resolve()
    teacher_index = json.loads(teacher_index_path.read_text(encoding='utf-8'))
    teacher_dir = Path(teacher_index['teacher_dir']).resolve()
    if int(teacher_index.get('case_count', 0)) != 600:
        raise ValueError('Predictor Wave1 requires all 600 verified IGA teachers.')
    if teacher_index.get('frozen_plane_checkpoint_sha256') != source['sha256']:
        raise ValueError('IGA ready labels and Stage1 source checkpoint differ.')
    if not teacher_dir.is_dir():
        raise FileNotFoundError(f'Teacher directory is missing: {teacher_dir}')

    base = build_stage2_command(
        source['path'],
        run_tag=args.run_tag,
        seed=1,
        bc_epochs=3,
        ppo_epochs=0,
        ppo_epoch=0,
        bc_min_labels=64,
        ranking_min_labels=64,
        ranking_loss_coef=1.0,
        timing_loss_coef=0.5,
        ready_min_labels=64,
        ready_loss_coef=1.0,
        device_bc_teacher='iga',
        resource_teacher_dir=teacher_dir,
        resource_teacher_index=teacher_index_path,
        bc_min_rollouts=10,
        bc_max_rollouts=10,
        bc_lr=3e-4,
        source_command=source_command,
        python=args.python.resolve(),
    )
    commands = {}
    for method_id, method in METHODS.items():
        command = configure(base, method_id, method, args.run_tag)
        # Fail manifest generation if any policy loss was accidentally left on.
        for option in (
            '--device_bc_categorical_loss_coef',
            '--device_bc_ranking_loss_coef',
            '--device_bc_timing_loss_coef',
            '--device_bc_assignment_loss_coef',
            '--device_bc_assignment_margin_loss_coef',
        ):
            if float(_option(command, option)) != 0.0:
                raise RuntimeError(f'{method_id} retained policy loss {option}.')
        commands[method_id] = {
            'argv': command,
            'shell': shlex.join(command),
            **method,
        }

    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
    ).strip()
    manifest = {
        'schema_version': 1,
        'research_stage': 'stage2_request_ready_predictor',
        'profile': 'ready_head_wave1',
        'run_tag': args.run_tag,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'code_commit': revision,
        'working_tree_note': 'launch intentionally includes reviewed uncommitted changes',
        'source': source,
        'teacher_index_path': str(teacher_index_path),
        'teacher_index_sha256': sha256_file(teacher_index_path),
        'teacher_dir': str(teacher_dir),
        'training_contract': {
            'seed': 1,
            'train_cases': 240,
            'distribution': {'iid': 120, 'ood_stress': 108, 'ood_scale': 12},
            'epochs': 3,
            'rollouts_per_epoch': 10,
            'device_bc_training_scope': 'ready_only',
            'request_ready_policy_injection': 'none',
            'frozen': ['shared_encoder', 'plane_actor', 'resource_actors',
                       'transporter_actor', 'request_ready_feature'],
            'trainable': ['request_ready_head'],
            'ppo_epochs': 0,
        },
        'selection_contract': {
            'primary': '0.60*H2_MAE + 0.30*H1_MAE + 0.10*departure_MAE',
            'guardrails': [
                'all-label RMSE', 'signed bias', 'underprediction rate',
                'within 60/120/300 seconds', 'frozen-policy hashes unchanged',
            ],
            'policy_cmax_validation': 'omitted because prediction injection is none',
        },
        'cpu_contract': {
            'trainers': 6,
            'logical_cpus_each': 24,
            'physical_cores_each': 12,
            'physical_core_isolation': True,
            'full_host_coverage': True,
        },
        'gpu_contract': {
            'gpus': [0, 1],
            'trainers_each': 3,
            'max_graphs_per_forward': 1000,
            'cuda_memory_fraction_each': 0.30,
        },
        'methods': METHODS,
        'commands': commands,
    }
    atomic_json(args.output.resolve(), manifest)
    print(json.dumps({
        'manifest': str(args.output.resolve()),
        'methods': list(METHODS),
        'teacher_cases': teacher_index['case_count'],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
