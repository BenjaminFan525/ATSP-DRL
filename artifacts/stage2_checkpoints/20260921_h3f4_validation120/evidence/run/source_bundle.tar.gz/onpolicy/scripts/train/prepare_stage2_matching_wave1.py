#!/usr/bin/env python3
"""Prepare the preregistered five-arm Stage2 final-matching screen."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    DEFAULT_HANDOFF,
    DEFAULT_PYTHON,
    atomic_json,
    sha256_file,
    source_contract,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    build_stage2_command,
    remove_option,
    set_option,
    set_switch,
)


DEFAULT_TEACHER_INDEX = (
    ROOT / 'result/hkbz_train_logs/stage2_supervised_hf_labels_20260901_r1/'
    'stage2_bc_labels/iga1800/stage2_bc_teacher_index.json'
)
DEFAULT_VALIDATION = (
    ROOT / 'onpolicy/envs/HKBZ/dataset/'
    'fjsp_v3_resource_joint_eval_s20260811/joint/tune'
)
METHODS = {
    'A0_sequential_categorical': {
        'global_matching': False,
        'categorical_coef': 1.0,
        'assignment_coef': 0.0,
        'margin_coef': 0.0,
        'head_mode': 'shared',
        'resource_adapter': False,
        'hypothesis': 'serialized categorical DeviceBC control',
    },
    'A1_global_categorical': {
        'global_matching': True,
        'categorical_coef': 1.0,
        'assignment_coef': 0.0,
        'margin_coef': 0.0,
        'head_mode': 'shared',
        'resource_adapter': False,
        'hypothesis': 'global Hungarian decoding without changing supervision',
    },
    'A2_final_matching': {
        'global_matching': True,
        'categorical_coef': 0.0,
        'assignment_coef': 1.0,
        'margin_coef': 0.0,
        'head_mode': 'shared',
        'resource_adapter': False,
        'hypothesis': 'permutation-invariant final IGA matching supervision',
    },
    'A3_matching_margin': {
        'global_matching': True,
        'categorical_coef': 0.0,
        'assignment_coef': 1.0,
        'margin_coef': 0.25,
        'head_mode': 'shared',
        'resource_adapter': False,
        'hypothesis': 'final matching plus structured non-target margin',
    },
    'A4_resource_adapter': {
        'global_matching': True,
        'categorical_coef': 0.0,
        'assignment_coef': 1.0,
        'margin_coef': 0.25,
        'head_mode': 'type_adapter',
        'resource_adapter': True,
        'hypothesis': 'A3 plus type context and resource-only residual capacity',
    },
}


def configure(base, method_id, method, run_tag):
    command = list(base)
    set_option(
        command, '--experiment_name',
        f'{run_tag}_matching_wave1_{method_id}_seed1',
    )
    set_option(command, '--seed', 1)
    set_option(command, '--n_rollout_threads', 24)
    set_option(command, '--n_eval_rollout_threads', 20)
    set_option(command, '--max_train_cases', 240)
    set_option(command, '--train_sampling_size', 240)
    set_option(command, '--train_sampling_mode', 'distribution_balanced')
    set_option(
        command, '--train_sampling_weights',
        'iid=0.50,ood_stress=0.45,ood_scale=0.05',
    )
    set_option(command, '--device_bc_pretrain_epochs', 1)
    set_option(command, '--device_bc_min_rollouts_per_epoch', 10)
    set_option(command, '--device_bc_max_rollouts_per_epoch', 10)
    set_option(command, '--device_bc_min_labels_per_epoch', 64)
    set_option(command, '--device_bc_lr', 3e-5)
    set_option(command, '--device_bc_dagger_schedule', '1.0')
    set_option(command, '--device_bc_ranking_loss_coef', 0.0)
    set_option(command, '--device_bc_min_ranking_labels_per_epoch', 0)
    set_option(command, '--device_bc_timing_loss_coef', 0.0)
    set_option(
        command, '--device_bc_categorical_loss_coef',
        method['categorical_coef'],
    )
    set_option(
        command, '--device_bc_assignment_loss_coef',
        method['assignment_coef'],
    )
    set_option(
        command, '--device_bc_assignment_margin_loss_coef',
        method['margin_coef'],
    )
    set_option(command, '--device_bc_assignment_margin', 0.20)
    set_option(
        command, '--device_bc_min_assignment_labels_per_epoch',
        64 if method['assignment_coef'] > 0 else 0,
    )
    set_option(command, '--request_ready_loss_coef', 1.0)
    set_option(command, '--request_ready_underprediction_weight', 2.0)
    set_option(command, '--request_ready_blocking_weight', 2.0)
    set_option(command, '--request_ready_min_labels_per_epoch', 64)
    set_option(command, '--request_ready_policy_injection', 'none')
    set_option(command, '--device_policy_head_mode', method['head_mode'])
    set_switch(command, '--device_global_matching', method['global_matching'])
    set_switch(command, '--device_resource_adapter', method['resource_adapter'])
    set_switch(command, '--device_bc_role_balanced', True)
    set_switch(command, '--device_bc_timing_balanced', False)
    set_option(command, '--max_graphs_per_forward', 1000)
    set_option(command, '--cuda_memory_fraction', 0.19)
    set_option(command, '--max_eval_cases', 60)
    set_option(command, '--selection_metric', 'raw')
    set_option(command, '--stage2_max_raw_regression_seconds', 0.0)
    set_option(command, '--stage2_max_stress_regression_seconds', 30.0)
    set_option(command, '--status_heartbeat_seconds', 30)
    set_switch(command, '--rollout_until_done', True)
    set_switch(command, '--use_eval', True)
    # These supervised arms have no PPO batch; remove stale source recovery.
    for flag in ('--resume_stage1', '--resume_stage2'):
        remove_option(command, flag, takes_value=False)
    return command


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--handoff', type=Path, default=DEFAULT_HANDOFF)
    parser.add_argument('--source-seed', type=int, default=3)
    parser.add_argument('--teacher-index', type=Path, default=DEFAULT_TEACHER_INDEX)
    parser.add_argument('--python', type=Path, default=DEFAULT_PYTHON)
    args = parser.parse_args()

    source, source_command = source_contract(
        args.handoff.resolve(), args.source_seed
    )
    teacher_index_path = args.teacher_index.resolve()
    teacher_index = json.loads(teacher_index_path.read_text(encoding='utf-8'))
    teacher_dir = Path(teacher_index['teacher_dir']).resolve()
    if int(teacher_index.get('case_count', 0)) != 600:
        raise ValueError('Stage2 matching Wave1 requires 600 IGA teachers.')
    if teacher_index.get('frozen_plane_checkpoint_sha256') != source['sha256']:
        raise ValueError('IGA labels and selected Stage1 source checkpoint differ.')
    if not teacher_dir.is_dir() or not DEFAULT_VALIDATION.is_dir():
        raise FileNotFoundError('Teacher or Valid60 directory is missing.')

    # The established builder performs the immutable source/teacher planning
    # audit.  Its legacy positive ranking/timing defaults are then explicitly
    # replaced by this Wave's registered final-matching targets.
    base = build_stage2_command(
        source['path'],
        run_tag=args.run_tag,
        seed=1,
        bc_epochs=1,
        ppo_epochs=0,
        ppo_epoch=0,
        bc_min_labels=64,
        ranking_min_labels=64,
        ranking_loss_coef=1.0,
        timing_loss_coef=0.5,
        ready_min_labels=64,
        ready_loss_coef=1.0,
        device_bc_teacher='iga',
        resource_teacher_dir=teacher_dir,
        resource_teacher_index=teacher_index_path,
        bc_min_rollouts=10,
        bc_max_rollouts=10,
        bc_lr=3e-5,
        source_command=source_command,
        python=args.python.resolve(),
    )
    commands = {}
    for method_id, method in METHODS.items():
        command = configure(base, method_id, method, args.run_tag)
        commands[method_id] = {
            'argv': command,
            'shell': shlex.join(command),
            **method,
        }
    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
    ).strip()
    manifest = {
        'schema_version': 2,
        'research_stage': 'stage2_supervised_matching',
        'profile': 'matching_wave1',
        'run_tag': args.run_tag,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'code_commit': revision,
        'source': source,
        'teacher_index_path': str(teacher_index_path),
        'teacher_index_sha256': sha256_file(teacher_index_path),
        'teacher_dir': str(teacher_dir),
        'validation_dir': str(DEFAULT_VALIDATION.resolve()),
        'training_contract': {
            'seed': 1,
            'train_cases': 240,
            'distribution': {'iid': 120, 'ood_stress': 108, 'ood_scale': 12},
            'bc_epochs': 1,
            'bc_rollouts': 10,
            'ppo_epochs': 0,
            'request_ready_policy_injection': 'none',
            'raw_iga_chromosome_ranking': False,
            'scientific_gate': {
                'raw_regression_seconds': 0.0,
                'ood_stress_regression_seconds': 30.0,
                'completion': '60/60',
                'cycle_count': 0,
                'timeout_count': 0,
            },
        },
        'cpu_contract': {
            'trainers': 5,
            'trainer_logical_cpus_each': 24,
            'shared_validator_logical_cpus': 20,
            'reserved_logical_cpus': 4,
            'physical_core_isolation': True,
        },
        'gpu_contract': {
            'gpu': 0,
            'trainer_count': 5,
            'max_graphs_per_forward': 1000,
            'shared_validator_count': 1,
        },
        'evaluator_source_method': 'A0_sequential_categorical',
        'evaluator_command': commands['A0_sequential_categorical']['argv'],
        'methods': METHODS,
        'commands': commands,
    }
    atomic_json(args.output.resolve(), manifest)
    print(json.dumps({
        'manifest': str(args.output.resolve()),
        'methods': list(METHODS),
        'teacher_cases': teacher_index['case_count'],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
