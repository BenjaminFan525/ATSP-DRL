#!/usr/bin/env python3
"""Paired forward probes on identical A3 inputs, never optimizing parameters.

Repeated graphs isolate arithmetic/batch-shape sensitivity; this is not a
second scheduling benchmark or an estimate of its frequency on tune60.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from torch_geometric.data import Batch
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.config.config import get_config
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.shared_hkbz_evaluator import source_training_args
from onpolicy.scripts.train.train_hkbz import parse_args, make_eval_env, list_case_folders
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-suite', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--case', default='case_0029')
    parser.add_argument('--steps', type=int, default=300)
    parser.add_argument('--probe-interval', type=int, default=5)
    cli = parser.parse_args()
    if cli.probe_interval < 1:
        raise ValueError('Probe interval must be positive.')
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('Only GPU0 is authorized.')
    output = cli.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(0.10, device=0)
    args = parse_args(source_training_args(cli.source_suite / 'evaluator_source.json'), get_config())
    manifest = json.loads((cli.source_suite / 'manifest.json').read_text())
    checkpoint_path = Path(manifest['reference_validation']['checkpoint'])
    payload = torch.load(checkpoint_path, map_location='cpu')
    for key, value in ready_head_config(payload).items():
        setattr(args, key, value)
    args.n_eval_rollout_threads = 1
    args.safe_async_graph_clone_workers = 0
    args.seed = 1
    names = list_case_folders(args.eval_dataset_dir, 60, case_offset=0,
        partition_seed=args.eval_partition_seed, stratify_by=args.eval_partition_stratify_by)
    args.eval_case_offset = names.index(cli.case)
    args.max_eval_cases = 1
    envs, _ = make_eval_env(args)
    report = dict(status='running', case=cli.case, started_unix_time=time.time(),
        checkpoint=str(checkpoint_path), checkpoint_sha256=hashlib.sha256(checkpoint_path.read_bytes()).hexdigest(),
        contract='identical graph and recurrent inputs; repeated graphs; fixed cuBLAS workspace',
        observations=[], strict_repeat_exact=True)
    try:
        policy = GNN_MAPPOPolicy(args, yaml.safe_load(Path(args.ac_config).read_text()), device=torch.device('cuda:0'))
        policy.load_model_state(payload['model'])
        policy.ac.eval()
        policy.ac.tau = 0.3
        captured = {}

        def capture_encoder(module, inputs, outputs):
            captured.clear()
            captured.update({key: value[:1].detach().cpu().clone()
                for key, value in outputs.items() if value.dtype.is_floating_point})

        hook = policy.ac.encoder.register_forward_hook(capture_encoder)
        obs, dones, infos = envs.reset()
        agents = args.max_agent_num + args.max_device_num
        hidden = np.zeros((1, agents, args.recurrent_N, args.hidden_size), dtype=np.float32)
        previous = -np.ones((1, agents, 2), dtype=np.float32)
        with torch.no_grad():
            for step in range(cli.steps):
                history = HKBZ_Runner._authoritative_policy_history(infos, previous, args.max_agent_num)
                active = np.asarray(infos['active_agents'], dtype=bool)

                def forward(width, strict):
                    torch.use_deterministic_algorithms(strict)
                    action, state = policy.act(Batch.from_data_list([obs[0].clone() for _ in range(width)]),
                        np.repeat(hidden, width, axis=0), np.repeat(active, width, axis=0),
                        np.repeat(history[..., 0], width, axis=0),
                        np.repeat(history[..., 1], width, axis=0), deterministic=True)
                    return action[:1].cpu().numpy().copy(), state[:1].cpu().numpy().copy(), dict(captured)

                reference_action, reference_state, reference_encoder = forward(12, True)
                if step % cli.probe_interval == 0:
                    found_flip = False
                    for label, width, strict in [('strict12_repeat', 12, True),
                            ('strict20', 20, True), ('nonstrict12', 12, False)]:
                        action, state, encoded = forward(width, strict)
                        encoder_delta = max(float((encoded[k] - reference_encoder[k]).abs().max())
                                            for k in encoded)
                        active_diff = np.any(action != reference_action, axis=-1) & active.reshape(1, agents)
                        row = dict(step=step, variant=label, encoder_max_abs_delta=encoder_delta,
                            recurrent_max_abs_delta=float(np.max(np.abs(state - reference_state))),
                            active_action_differences=int(active_diff.sum()))
                        report['observations'].append(row)
                        if label == 'strict12_repeat':
                            exact = encoder_delta == 0 and np.array_equal(state, reference_state) and np.array_equal(action, reference_action)
                            report['strict_repeat_exact'] &= exact
                            if not exact:
                                raise RuntimeError('Identical strict forwards were not exact.')
                        if active_diff.any():
                            found_flip = True
                            report.setdefault('first_action_difference', row)
                            snapshot = output / 'first_action_difference.pt'
                            if not snapshot.exists():
                                torch.save(dict(graph=obs[0], hidden=hidden, active=active,
                                    history=history, reference_action=reference_action, alternate_action=action,
                                    variant=label, step=step), snapshot)
                    (output / 'probe.json').write_text(json.dumps(report, indent=2) + '\n')
                    print('[NumericProbe]', step, report['observations'][-3:], flush=True)
                    if found_flip:
                        break
                torch.use_deterministic_algorithms(True)
                obs, _, dones, infos = envs.step(reference_action)
                hidden, previous = reference_state, reference_action
                if np.all(dones):
                    break
        hook.remove()
        report['status'] = 'completed'
    except BaseException as error:
        report.update(status='failed', error=str(error))
        raise
    finally:
        envs.close()
        report['ended_unix_time'] = time.time()
        (output / 'probe.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
