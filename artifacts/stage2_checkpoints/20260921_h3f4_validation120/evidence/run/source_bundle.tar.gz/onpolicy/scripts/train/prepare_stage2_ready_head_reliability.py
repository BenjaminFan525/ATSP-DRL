#!/usr/bin/env python3
"""Prepare the preregistered Stage2 reliable ready-head screen."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import glob
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    DEFAULT_HANDOFF,
    DEFAULT_PYTHON,
    atomic_json,
    sha256_file,
    source_contract,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    build_stage2_command,
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.scripts.train.train_hkbz import (  # noqa: E402
    select_train_case_dirs,
)


DEFAULT_TEACHER_INDEX = (
    ROOT / 'result/hkbz_train_logs/stage2_supervised_hf_labels_20260901_r1/'
    'stage2_bc_labels/iga1800/stage2_bc_teacher_index.json'
)

METHODS = {
    'R0_block_rule_control': {
        'learning_rate': 1e-3,
        'seconds_loss_coef': 0.0,
        'underprediction_weight': 2.0,
        'context_features': False,
        'head_mode': 'shared',
        'kind_balanced': False,
        'quantile_head': False,
        'quantile_loss_coef': 0.0,
        'hypothesis': 'strong prior point-head control after exact Blocking routing',
    },
    'R1_symmetric_hybrid': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.10,
        'underprediction_weight': 1.0,
        'context_features': False,
        'head_mode': 'shared',
        'kind_balanced': False,
        'quantile_head': False,
        'quantile_loss_coef': 0.0,
        'hypothesis': 'symmetric point loss removes deliberate one-sided calibration',
    },
    'R2_explicit_context': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.10,
        'underprediction_weight': 1.0,
        'context_features': True,
        'head_mode': 'shared',
        'kind_balanced': False,
        'quantile_head': False,
        'quantile_loss_coef': 0.0,
        'hypothesis': 'kind/depth/predecessor context resolves frozen-embedding ambiguity',
    },
    'R3_split_kind_balanced': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.10,
        'underprediction_weight': 1.0,
        'context_features': True,
        'head_mode': 'horizon_split',
        'kind_balanced': True,
        'quantile_head': False,
        'quantile_loss_coef': 0.0,
        'hypothesis': 'role-specific calibration prevents H1 frequency from suppressing H2',
    },
    'R4_ordered_quantiles': {
        'learning_rate': 3e-4,
        'seconds_loss_coef': 0.10,
        'underprediction_weight': 1.0,
        'context_features': True,
        'head_mode': 'horizon_split',
        'kind_balanced': True,
        'quantile_head': True,
        'quantile_loss_coef': 1.0,
        'hypothesis': 'ordered q20/q50/q80 represents irreducible timing uncertainty',
    },
}

DEFAULT_CPU_SETS = (
    '0-14,72-86',
    '15-29,87-101',
    '30-43,102-115',
    '44-57,116-129',
    '58-71,130-143',
)


def expand_cpu_set(spec):
    cpus = set()
    for part in str(spec).split(','):
        left, separator, right = part.partition('-')
        cpus.update(
            range(int(left), int(right) + 1)
            if separator else (int(left),)
        )
    return cpus


def configure(base, method_id, method, run_tag):
    command = list(base)
    experiment_name = f'{run_tag}_ready_reliable_{method_id}_seed1'
    set_option(command, '--experiment_name', experiment_name)
    set_option(command, '--seed', 1)
    set_option(command, '--n_rollout_threads', 24)
    set_option(command, '--n_eval_rollout_threads', 1)
    set_option(command, '--max_train_cases', 240)
    set_option(command, '--train_sampling_size', 240)
    set_option(command, '--train_sampling_mode', 'distribution_balanced')
    set_option(
        command,
        '--train_sampling_weights',
        'iid=0.50,ood_stress=0.45,ood_scale=0.05',
    )
    set_option(command, '--device_bc_pretrain_epochs', 3)
    set_option(command, '--device_bc_min_rollouts_per_epoch', 10)
    set_option(command, '--device_bc_max_rollouts_per_epoch', 10)
    set_option(command, '--device_bc_min_labels_per_epoch', 64)
    set_option(command, '--device_bc_training_scope', 'ready_only')
    set_option(command, '--device_bc_lr', method['learning_rate'])
    set_option(command, '--device_bc_dagger_schedule', '1.0')
    set_option(command, '--device_bc_categorical_loss_coef', 0.0)
    set_option(command, '--device_bc_ranking_loss_coef', 0.0)
    set_option(command, '--device_bc_min_ranking_labels_per_epoch', 0)
    set_option(command, '--device_bc_timing_loss_coef', 0.0)
    set_option(command, '--device_bc_assignment_loss_coef', 0.0)
    set_option(command, '--device_bc_assignment_margin_loss_coef', 0.0)
    set_option(command, '--device_bc_min_assignment_labels_per_epoch', 0)
    set_option(command, '--request_ready_loss_coef', 1.0)
    set_option(
        command,
        '--request_ready_seconds_loss_coef',
        method['seconds_loss_coef'],
    )
    set_option(command, '--request_ready_seconds_loss_scale', 600.0)
    set_option(command, '--request_ready_h1_weight', 1.0)
    set_option(command, '--request_ready_h2_weight', 1.0)
    set_option(command, '--request_ready_departure_weight', 1.0)
    set_option(
        command,
        '--request_ready_underprediction_weight',
        method['underprediction_weight'],
    )
    set_option(command, '--request_ready_blocking_weight', 1.0)
    set_option(command, '--request_ready_min_labels_per_epoch', 64)
    set_option(command, '--request_ready_policy_injection', 'none')
    set_option(command, '--request_ready_head_mode', method['head_mode'])
    set_option(
        command,
        '--request_ready_quantile_loss_coef',
        method['quantile_loss_coef'],
    )
    set_option(command, '--request_ready_holdout_folds', 5)
    set_option(command, '--request_ready_holdout_fold', 0)
    set_switch(command, '--request_ready_hard_blocking', True)
    set_switch(command, '--request_ready_exclude_blocking_loss', True)
    set_switch(
        command,
        '--request_ready_context_features',
        method['context_features'],
    )
    set_switch(
        command,
        '--request_ready_kind_balanced_loss',
        method['kind_balanced'],
    )
    set_switch(
        command,
        '--request_ready_quantile_head',
        method['quantile_head'],
    )
    set_option(command, '--max_graphs_per_forward', 1000)
    set_option(command, '--cuda_memory_fraction', 0.19)
    set_option(command, '--status_heartbeat_seconds', 30)
    set_switch(command, '--rollout_until_done', True)
    set_switch(command, '--use_eval', False)
    set_switch(command, '--device_bc_role_balanced', False)
    set_switch(command, '--device_bc_timing_balanced', False)
    for flag in ('--resume_stage1', '--resume_stage2'):
        remove_option(command, flag, takes_value=False)
    return experiment_name, command


def _option(command, name):
    index = command.index(name)
    return command[index + 1]


def case_fold(case_path, folds=5):
    digest = hashlib.sha256(
        Path(str(case_path)).name.encode('utf-8')
    ).digest()
    return int.from_bytes(digest[:8], byteorder='big') % int(folds)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--handoff', type=Path, default=DEFAULT_HANDOFF)
    parser.add_argument('--source-seed', type=int, default=3)
    parser.add_argument('--teacher-index', type=Path, default=DEFAULT_TEACHER_INDEX)
    parser.add_argument('--python', type=Path, default=DEFAULT_PYTHON)
    parser.add_argument(
        '--gpu-launch-mode',
        choices=('exclusive', 'shared'),
        default='exclusive',
    )
    parser.add_argument(
        '--cpu-sets',
        nargs=5,
        default=DEFAULT_CPU_SETS,
        metavar=('R0_CPUS', 'R1_CPUS', 'R2_CPUS', 'R3_CPUS', 'R4_CPUS'),
        help='Five disjoint logical-CPU sets recorded in the execution manifest.',
    )
    args = parser.parse_args()

    cpu_groups = [expand_cpu_set(value) for value in args.cpu_sets]
    cpu_union = set()
    for lane, group in enumerate(cpu_groups):
        if not group:
            raise ValueError(f'CPU set for lane {lane} is empty.')
        overlap = cpu_union & group
        if overlap:
            raise ValueError(
                f'CPU sets overlap at lane {lane}: {sorted(overlap)}'
            )
        cpu_union |= group
    available_cpus = set(os.sched_getaffinity(0))
    unavailable = cpu_union - available_cpus
    if unavailable:
        raise ValueError(f'CPU sets include unavailable CPUs: {sorted(unavailable)}')

    source, source_command = source_contract(
        args.handoff.resolve(), args.source_seed
    )
    teacher_index_path = args.teacher_index.resolve()
    teacher_index = json.loads(teacher_index_path.read_text(encoding='utf-8'))
    teacher_dir = Path(teacher_index['teacher_dir']).resolve()
    if int(teacher_index.get('case_count', 0)) != 600:
        raise ValueError('Reliable predictor Wave1 requires 600 IGA teachers.')
    if teacher_index.get('frozen_plane_checkpoint_sha256') != source['sha256']:
        raise ValueError('IGA labels and the selected Stage1 checkpoint differ.')
    if int(teacher_index.get('intrinsic_ready_time_label_schema_version', 0)) != 1:
        raise ValueError('Reliable predictor requires exact ready-label schema 1.')
    if int(teacher_index.get('intrinsic_ready_time_labeled_request_count', 0)) <= 0:
        raise ValueError('Teacher index contains no intrinsic-ready labels.')
    if not teacher_dir.is_dir():
        raise FileNotFoundError(f'Teacher directory is missing: {teacher_dir}')

    dataset_dir = Path(teacher_index['dataset_dir']).resolve()
    source_cases = sorted(glob.glob(str(dataset_dir / 'case_*')))
    selected_cases, sampling_audit = select_train_case_dirs(
        source_cases,
        mode='distribution_balanced',
        weights_spec='iid=0.50,ood_stress=0.45,ood_scale=0.05',
        seed=1,
        max_cases=240,
        sample_size=240,
    )
    holdout_cases = [case for case in selected_cases if case_fold(case) == 0]
    holdout_distribution = {}
    for case in holdout_cases:
        metadata = json.loads(
            (Path(case) / 'metadata.json').read_text(encoding='utf-8')
        )
        distribution = str(metadata['distribution'])
        holdout_distribution[distribution] = (
            holdout_distribution.get(distribution, 0) + 1
        )
    if len(selected_cases) != 240 or len(set(selected_cases)) != 240:
        raise RuntimeError('Wave1 case selection is not 240 unique cases.')
    if len(holdout_cases) < 20:
        raise RuntimeError('The deterministic holdout fold is unexpectedly small.')

    base = build_stage2_command(
        source['path'],
        run_tag=args.run_tag,
        seed=1,
        bc_epochs=3,
        ppo_epochs=0,
        ppo_epoch=0,
        bc_min_labels=64,
        ranking_min_labels=64,
        ranking_loss_coef=1.0,
        timing_loss_coef=0.5,
        ready_min_labels=64,
        ready_loss_coef=1.0,
        device_bc_teacher='iga',
        resource_teacher_dir=teacher_dir,
        resource_teacher_index=teacher_index_path,
        bc_min_rollouts=10,
        bc_max_rollouts=10,
        bc_lr=3e-4,
        source_command=source_command,
        python=args.python.resolve(),
    )
    commands = {}
    for method_id, method in METHODS.items():
        experiment_name, command = configure(
            base, method_id, method, args.run_tag
        )
        for option in (
            '--device_bc_categorical_loss_coef',
            '--device_bc_ranking_loss_coef',
            '--device_bc_timing_loss_coef',
            '--device_bc_assignment_loss_coef',
            '--device_bc_assignment_margin_loss_coef',
        ):
            if float(_option(command, option)) != 0.0:
                raise RuntimeError(f'{method_id} retained policy loss {option}.')
        if '--request_ready_hard_blocking' not in command:
            raise RuntimeError(f'{method_id} did not hard-route Blocking.')
        if '--request_ready_exclude_blocking_loss' not in command:
            raise RuntimeError(f'{method_id} retained Blocking neural loss.')
        commands[method_id] = {
            'argv': command,
            'shell': shlex.join(command),
            'experiment_name': experiment_name,
            **method,
        }

    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
    ).strip()
    git_status = subprocess.check_output(
        ['git', 'status', '--porcelain=v1', '-z'], cwd=ROOT
    )
    git_diff = subprocess.check_output(
        ['git', 'diff', '--binary', 'HEAD'], cwd=ROOT
    )
    manifest = {
        'schema_version': 2,
        'research_stage': 'stage2_request_ready_predictor',
        'profile': 'ready_head_reliability_wave1',
        'run_tag': args.run_tag,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'code_commit': revision,
        'working_tree_note': 'launch intentionally includes reviewed uncommitted changes',
        'working_tree_fingerprint': {
            'status_sha256': hashlib.sha256(git_status).hexdigest(),
            'tracked_diff_sha256': hashlib.sha256(git_diff).hexdigest(),
            'status_entry_count': len(
                [entry for entry in git_status.split(b'\0') if entry]
            ),
        },
        'source': source,
        'teacher_index_path': str(teacher_index_path),
        'teacher_index_sha256': sha256_file(teacher_index_path),
        'teacher_dir': str(teacher_dir),
        'teacher_label_contract': {
            'schema_version': 1,
            'semantics': teacher_index.get('intrinsic_ready_time_semantics'),
            'labeled_requests': int(
                teacher_index['intrinsic_ready_time_labeled_request_count']
            ),
            'coverage': float(
                teacher_index['intrinsic_ready_time_label_coverage']
            ),
            'selected_H': int(teacher_index['selected_H']),
            'selected_F': int(teacher_index['selected_F']),
        },
        'training_contract': {
            'seed': 1,
            'sampled_cases': 240,
            'distribution': {'iid': 120, 'ood_stress': 108, 'ood_scale': 12},
            'optimization_epochs': 3,
            'rollouts_per_epoch': 10,
            'rollout_threads': 24,
            'device_bc_training_scope': 'ready_only',
            'request_ready_policy_injection': 'none',
            'blocking_route': 'deterministic_exact_zero',
            'blocking_in_neural_loss': False,
            'frozen': [
                'shared_encoder', 'plane_actor', 'resource_actors',
                'transporter_actor', 'critics', 'request_ready_feature',
            ],
            'trainable': ['request_ready_head'],
            'ppo_epochs': 0,
        },
        'holdout_contract': {
            'folds': 5,
            'fold': 0,
            'unit': 'case basename',
            'assignment': 'first_8_bytes(SHA256(case_basename)) mod 5',
            'execution': 'one frozen no-backward pass after optimization',
            'expected_case_count': len(holdout_cases),
            'expected_distribution': dict(sorted(holdout_distribution.items())),
            'case_basenames': sorted(Path(case).name for case in holdout_cases),
        },
        'sampling_audit': sampling_audit,
        'selection_contract': {
            'dataset': 'holdout fold 0 only',
            'primary': '0.60*H2_MAE + 0.30*H1_MAE + 0.10*departure_MAE',
            'guardrails': [
                'blocking MAE exactly zero',
                'nonblocking RMSE and signed bias',
                'late-by-60/120/300/600 rates',
                'case-macro MAE/RMSE',
                'q20/q50/q80 calibration when enabled',
                'all frozen parameter hashes unchanged',
            ],
            'policy_cmax_validation': (
                'omitted because prediction injection is none'
            ),
        },
        'cpu_contract': {
            'trainers': 5,
            'cpu_sets': list(args.cpu_sets),
            'physical_cores': [len(group) // 2 for group in cpu_groups],
            'logical_cpus': [len(group) for group in cpu_groups],
            'allocated_logical_cpus': len(cpu_union),
            'available_logical_cpus': len(available_cpus),
            'allocated_fraction': len(cpu_union) / len(available_cpus),
            'physical_core_isolation': True,
            'full_host_coverage': cpu_union == available_cpus,
        },
        'gpu_contract': {
            'gpu': 0,
            'launch_mode': args.gpu_launch_mode,
            'trainers': 5,
            'max_graphs_per_forward': 1000,
            'cuda_memory_fraction_each': 0.19,
            'aggregate_allocator_fraction': 0.95,
        },
        'methods': METHODS,
        'commands': commands,
    }
    atomic_json(args.output.resolve(), manifest)
    print(json.dumps({
        'manifest': str(args.output.resolve()),
        'methods': list(METHODS),
        'teacher_cases': teacher_index['case_count'],
        'teacher_labels': teacher_index[
            'intrinsic_ready_time_labeled_request_count'
        ],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
