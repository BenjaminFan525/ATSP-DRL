#!/usr/bin/env python3
"""Prepare immutable frozen-R1 BC canary/pilot/formal manifests. Never launch."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_matching_wave1 import (
    DEFAULT_TEACHER_INDEX, DEFAULT_VALIDATION, METHODS, configure,
)
from onpolicy.scripts.train.prepare_stage2_resource_research import (
    DEFAULT_HANDOFF, DEFAULT_PYTHON, atomic_json, sha256_file, source_contract,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (
    build_stage2_command, set_option, set_switch,
)
from onpolicy.scripts.train.train_hkbz import select_train_case_dirs
from onpolicy.utils.stage2_bc_replay import build_local_reference

READY_SELECTION = ROOT / ('result/hkbz_train_logs/'
    'stage2_ready_reliable_20260904_local_a6000_r2/analysis/selection.json')
READY_SHA256 = 'c0c4825946e469b680e764a4c4b9f3bcbcfdaa66ccfb2fee221633b5d3afb1f1'
ARMS = {'B0_none': 'none', 'B1_dag': 'dag', 'B2_R1': 'learned'}
TRAIN_CPUS = ('0-11,64-75', '12-23,76-87')
EVAL_CPUS = '24-29,88-93'
MONITOR_CPUS = '30-31,94-95'
A3_RUN = ROOT / ('onpolicy/scripts/results/HKBZ/simple/gnn_mappo/'
    'stage2_matching_wave1_20260902_r1_matching_wave1_A3_matching_margin_seed1/run1')


def code_fingerprint():
    paths = subprocess.check_output(
        ['rg', '--files', 'onpolicy', '-g', '*.py', '-g', '*.yaml'],
        cwd=ROOT, text=True,
    ).splitlines()
    paths.append('onpolicy/scripts/train/launch_stage2_bc_injection_gpu0.sh')
    return {name: sha256_file(ROOT / name) for name in sorted(set(paths))}


def prepare(args):
    args.reference_diagnostic_dir = getattr(args, 'reference_diagnostic_dir', None)
    args.reference_numeric_probe_dir = getattr(args, 'reference_numeric_probe_dir', None)
    if bool(args.reference_diagnostic_dir) != bool(args.reference_numeric_probe_dir):
        raise ValueError('A local reference amendment needs both complete replay and numerical-probe evidence.')
    suite = args.suite_dir.resolve()
    output = suite / 'manifest.json'
    if output.exists():
        raise FileExistsError(f'Never overwrite an experiment manifest: {output}')
    source, source_command = source_contract(DEFAULT_HANDOFF, 3)
    teacher = json.loads(DEFAULT_TEACHER_INDEX.read_text())
    if teacher['case_count'] != 600 or (teacher['selected_H'], teacher['selected_F']) != (2, 4):
        raise ValueError('Expected the complete H2/F4 teacher600 corpus.')
    if teacher['frozen_plane_checkpoint_sha256'] != source['sha256']:
        raise ValueError('Teacher and Stage1 source mismatch.')
    selection = json.loads(READY_SELECTION.read_text())
    if not selection['complete'] or selection['failures'] or selection['winner']['method'] != 'R1_symmetric_hybrid':
        raise ValueError('Reliability selection is not a complete R1 selection.')
    ready = Path(selection['winner']['checkpoint'])
    if sha256_file(ready) != READY_SHA256:
        raise ValueError('Pinned R1 checkpoint digest mismatch.')
    canary = args.profile == 'canary'
    formal = args.profile == 'formal'
    samples, workers = (2, 2) if canary else ((0, 24) if formal else (240, 24))
    eval_workers, eval_cases = (2, 4) if canary else (12, 60)
    rollouts = 1 if canary else (40 if formal else 10)
    seeds = [1, 2, 3] if formal else [11]
    arms = ['B2_R1'] if canary else list(ARMS)
    base = build_stage2_command(
        source['path'], run_tag=args.run_tag, seed=seeds[0], bc_epochs=2,
        ppo_epochs=0, ppo_epoch=0, bc_min_labels=64,
        ranking_min_labels=64, ranking_loss_coef=1.0, timing_loss_coef=0.5,
        ready_min_labels=64, ready_loss_coef=1.0, device_bc_teacher='iga',
        resource_teacher_dir=Path(teacher['teacher_dir']),
        resource_teacher_index=DEFAULT_TEACHER_INDEX,
        bc_min_rollouts=rollouts, bc_max_rollouts=rollouts, bc_lr=3e-5,
        source_command=source_command, python=args.python.resolve(),
    )
    commands, audits = {}, {}
    dataset = Path(teacher['dataset_dir'])
    for seed in seeds:
        sampling_seed = seed if formal else 1
        selected, audit = select_train_case_dirs(
            sorted(dataset.glob('case_*')), mode='uniform' if canary else 'distribution_balanced',
            weights_spec='iid=0.50,ood_stress=0.45,ood_scale=0.05',
            seed=sampling_seed, max_cases=samples, sample_size=samples,
        )
        if len(selected) != workers * rollouts or len(set(selected)) != (600 if formal else samples):
            raise ValueError('Training coverage differs from the complete-rollout budget.')
        order = [Path(path).name for path in selected]
        audit.update({'case_order': order, 'sampling_seed': sampling_seed,
                      'case_order_sha256': hashlib.sha256('\n'.join(order).encode()).hexdigest()})
        audits[str(seed)] = audit
        for arm in arms:
            key = f'{arm}_seed{seed}'
            command = configure(base, arm, METHODS['A3_matching_margin'], args.run_tag)
            options = {
                '--experiment_name': f'{args.run_tag}_{key}', '--seed': seed,
                '--train_sampling_seed': sampling_seed,
                '--train_sampling_mode': 'uniform' if canary else 'distribution_balanced',
                '--max_train_cases': samples, '--train_sampling_size': samples,
                '--train_sampling_pool_size': 0, '--n_rollout_threads': workers,
                '--n_eval_rollout_threads': eval_workers, '--max_eval_cases': eval_cases,
                '--eval_dataset_dir': str(DEFAULT_VALIDATION), '--mini_batch_size': min(7, workers),
                '--device_bc_training_scope': 'policy_frozen_ready',
                '--device_bc_pretrain_epochs': 2,
                '--device_bc_min_rollouts_per_epoch': rollouts,
                '--device_bc_max_rollouts_per_epoch': rollouts,
                '--request_ready_checkpoint': str(ready),
                '--request_ready_checkpoint_sha256': READY_SHA256,
                '--request_ready_policy_injection': ARMS[arm],
                '--request_ready_loss_coef': 0.0, '--request_ready_head_mode': 'shared',
                '--request_ready_holdout_folds': 0, '--request_ready_holdout_fold': 0,
                '--request_ready_seconds_loss_coef': 0.1,
                '--request_ready_underprediction_weight': 1.0,
                '--request_ready_blocking_weight': 1.0,
                '--request_ready_quantile_loss_coef': 0.0,
                '--cuda_memory_fraction': 0.40, '--device': 'cuda:0',
                '--safe_async_graph_clone_workers': 4,
                '--torch_mp_sharing_strategy': 'file_descriptor', '--ipc_timeout_seconds': 600,
            }
            for name, value in options.items():
                set_option(command, name, value)
            for name, value in {
                '--device_bc_eval_each_epoch': True,
                '--stage2_bc_deterministic': True,
                '--request_ready_hard_blocking': True,
                '--request_ready_exclude_blocking_loss': True,
                '--request_ready_context_features': False,
                '--request_ready_quantile_head': False,
                '--request_ready_kind_balanced_loss': False,
                '--safe_graph_batch_pipeline': True,
                '--safe_dagger_teacher_overlap': True,
            }.items():
                set_switch(command, name, value)
            experiment_name = options['--experiment_name']
            if (ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / experiment_name).exists():
                raise FileExistsError(f'Experiment already exists: {experiment_name}')
            commands[key] = {'argv': command, 'shell': shlex.join(command),
                             'experiment_name': experiment_name, 'seed': seed,
                             'arm': arm, 'injection': ARMS[arm]}
    manifest = {
        'schema_version': 1, 'run_tag': args.run_tag, 'profile': args.profile,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'scientific_result': not canary, 'commands': commands, 'source': source,
        'ready_source': {'path': str(ready), 'sha256': READY_SHA256,
                         'selection_path': str(READY_SELECTION)},
        'teacher_index': str(DEFAULT_TEACHER_INDEX),
        'teacher_index_sha256': sha256_file(DEFAULT_TEACHER_INDEX),
        'sampling_audits': audits,
        'training_contract': {'epochs': 2, 'rollouts_per_epoch': rollouts,
                              'workers': workers, 'teacher_execution_rate': 1.0,
                              'ppo_epochs': 0, 'scope': 'policy_frozen_ready'},
        'evaluation_contract': {'dataset': str(DEFAULT_VALIDATION), 'cases': eval_cases,
                               'workers': eval_workers, 'epochs': [0, 1, 2],
                               'numeric_mode': 'strict_pytorch_cublas',
                               'partition_seed': 20260803, 'partition_stratify_by': 'profile',
                               'case_offset': 0,
                               'selection': 'minimum eligible epoch raw Cmax, earlier epoch breaks ties',
                               'finalblind_access': False},
        'resource_contract': {'gpu': 0, 'allowed_cpus': '0-31,64-95',
                              'train_cpu_sets': list(TRAIN_CPUS), 'eval_cpu_set': EVAL_CPUS,
                              'monitor_cpu_set': MONITOR_CPUS, 'allocated_logical_cpus': 64,
                              'max_concurrent_trainers': 2, 'heartbeat_seconds': 30,
                              'hard_timeout_seconds': 172800},
        'analysis_contract': {'primary_contrast': 'B2_R1 - B1_dag',
                              'secondary_contrast': 'B2_R1 - B0_none',
                              'resampling_unit': 'paired case, not request labels',
                              'practical_gain_fraction': 0.005},
        'code_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'code_fingerprint': code_fingerprint(),
    }
    if not canary:
        reference_checkpoint = A3_RUN / 'models/checkpoint_Best.pt'
        reference_evaluation = A3_RUN / 'evaluations/post_supervised.json'
        manifest['reference_validation'] = {
            'checkpoint': str(reference_checkpoint),
            'checkpoint_sha256': sha256_file(reference_checkpoint),
            'expected_evaluation': str(reference_evaluation),
            'expected_evaluation_sha256': sha256_file(reference_evaluation),
            'seed': 1, 'evaluation_tau': 0.3, 'cases': 60,
            'case_tolerance_seconds': 1e-5,
            'failure_action': 'stop before any pilot/formal trainer starts',
        }
        if args.reference_diagnostic_dir:
            manifest['reference_validation'] = build_local_reference(
                ROOT, manifest['reference_validation'],
                diagnosis_dir=args.reference_diagnostic_dir,
                numerical_probe_dir=args.reference_numeric_probe_dir,
                dataset=DEFAULT_VALIDATION, workers=eval_workers,
            )
    elif args.reference_diagnostic_dir:
        raise ValueError('The tune60 reference amendment does not apply to a tiny canary.')
    suite.mkdir(parents=True, exist_ok=True)
    archive_path = suite / 'source_bundle.tar.gz'
    with tarfile.open(archive_path, mode='x:gz') as archive:
        for relative, expected_sha in manifest['code_fingerprint'].items():
            data = (ROOT / relative).read_bytes()
            if hashlib.sha256(data).hexdigest() != expected_sha:
                raise ValueError(f'Code changed while creating the source snapshot: {relative}')
            info = archive.gettarinfo(str(ROOT / relative), arcname=relative)
            info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
    manifest['source_archive'] = {'path': str(archive_path), 'sha256': sha256_file(archive_path)}
    atomic_json(output, manifest)
    atomic_json(suite / 'evaluator_source.json', {'command': next(iter(commands.values()))['argv']})
    print(output)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--profile', choices=['canary', 'pilot', 'formal'], default='pilot')
    parser.add_argument('--python', type=Path, default=DEFAULT_PYTHON)
    parser.add_argument('--reference-diagnostic-dir', type=Path)
    parser.add_argument('--reference-numeric-probe-dir', type=Path)
    prepare(parser.parse_args())


if __name__ == '__main__':
    main()
