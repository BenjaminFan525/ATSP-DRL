#!/usr/bin/env python3
"""Select a reliable ready-time predictor from frozen case-holdout metrics."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
RESULT_ROOT = ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo'


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f'.{path.name}.tmp.{os.getpid()}')
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)
        + '\n',
        encoding='utf-8',
    )
    os.replace(temporary, path)


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def newest_complete_run(experiment_name: str) -> tuple[Path, dict, list[dict]]:
    experiment_dir = RESULT_ROOT / experiment_name
    candidates = []
    for run_dir in experiment_dir.glob('run*'):
        metrics_path = run_dir / 'logs/request_ready_epoch_metrics.jsonl'
        final_checkpoint = run_dir / 'models/checkpoint_BestPredictor.pt'
        if not metrics_path.is_file() or not final_checkpoint.is_file():
            continue
        rows = load_jsonl(metrics_path)
        holdout = [
            row for row in rows
            if row.get('request_ready_phase') == 'holdout_validation'
        ]
        if holdout:
            candidates.append((metrics_path.stat().st_mtime, run_dir, holdout[-1], rows))
    if not candidates:
        raise FileNotFoundError(
            f'No complete holdout run found for {experiment_name}'
        )
    _, run_dir, holdout, rows = max(candidates, key=lambda item: item[0])
    return run_dir, holdout, rows


def finite_metric(row: dict, key: str) -> float:
    value = float(row[key])
    if not math.isfinite(value):
        raise ValueError(f'Non-finite holdout metric {key}={value!r}')
    return value


def summarize(method_id: str, entry: dict, holdout_contract: dict) -> dict:
    run_dir, holdout, all_rows = newest_complete_run(entry['experiment_name'])
    train_rows = [
        row for row in all_rows if row.get('request_ready_phase') == 'train'
    ]
    required_counts = {
        name: int(holdout.get(f'request_ready_{name}_count', 0))
        for name in ('nonblocking', 'h1', 'h2', 'departure')
    }
    reasons = []
    if len(train_rows) != 3:
        reasons.append(f'expected_3_train_epochs_got_{len(train_rows)}')
    observed_case_count = int(holdout.get('request_ready_case_count', 0))
    expected_case_count = int(holdout_contract['expected_case_count'])
    if observed_case_count != expected_case_count:
        reasons.append(
            f'holdout_case_count_{observed_case_count}_expected_'
            f'{expected_case_count}'
        )
    for name, count in required_counts.items():
        if count <= 0:
            reasons.append(f'missing_{name}_labels')
    blocking_mae = finite_metric(
        holdout, 'request_ready_blocking_mae_seconds'
    )
    if blocking_mae != 0.0:
        reasons.append('blocking_not_exact_zero')
    result = {
        'method': method_id,
        'experiment_name': entry['experiment_name'],
        'run_dir': str(run_dir.resolve()),
        'checkpoint': str((
            run_dir / 'models/checkpoint_BestPredictor.pt'
        ).resolve()),
        'eligible': not reasons,
        'reasons': reasons,
        'holdout_case_count': observed_case_count,
        'holdout_counts': required_counts,
        'selection_score_seconds': finite_metric(
            holdout, 'request_ready_selection_score_seconds'
        ),
        'nonblocking_mae_seconds': finite_metric(
            holdout, 'request_ready_nonblocking_mae_seconds'
        ),
        'nonblocking_rmse_seconds': finite_metric(
            holdout, 'request_ready_nonblocking_rmse_seconds'
        ),
        'nonblocking_bias_seconds': finite_metric(
            holdout, 'request_ready_nonblocking_bias_seconds'
        ),
        'nonblocking_late_mae_seconds': finite_metric(
            holdout, 'request_ready_nonblocking_late_mae_seconds'
        ),
        'nonblocking_late_60_rate': finite_metric(
            holdout, 'request_ready_nonblocking_late_60_rate'
        ),
        'nonblocking_late_120_rate': finite_metric(
            holdout, 'request_ready_nonblocking_late_120_rate'
        ),
        'nonblocking_late_300_rate': finite_metric(
            holdout, 'request_ready_nonblocking_late_300_rate'
        ),
        'nonblocking_within_300_rate': finite_metric(
            holdout, 'request_ready_nonblocking_within_300_rate'
        ),
        'h1_mae_seconds': finite_metric(
            holdout, 'request_ready_h1_mae_seconds'
        ),
        'h2_mae_seconds': finite_metric(
            holdout, 'request_ready_h2_mae_seconds'
        ),
        'departure_mae_seconds': finite_metric(
            holdout, 'request_ready_departure_mae_seconds'
        ),
        'blocking_mae_seconds': blocking_mae,
        'case_macro_mae_seconds': finite_metric(
            holdout, 'request_ready_case_macro_mae_seconds'
        ),
        'case_macro_rmse_seconds': finite_metric(
            holdout, 'request_ready_case_macro_rmse_seconds'
        ),
        'case_macro_bias_seconds': finite_metric(
            holdout, 'request_ready_case_macro_bias_seconds'
        ),
        'training_curve': [
            {
                'epoch': int(row['device_bc_epoch']),
                'selection_score_seconds': finite_metric(
                    row, 'request_ready_selection_score_seconds'
                ),
                'nonblocking_mae_seconds': finite_metric(
                    row, 'request_ready_nonblocking_mae_seconds'
                ),
                'h2_mae_seconds': finite_metric(
                    row, 'request_ready_h2_mae_seconds'
                ),
            }
            for row in train_rows
        ],
    }
    if bool(entry.get('quantile_head', False)):
        result['quantile_calibration'] = {
            key: finite_metric(holdout, f'request_ready_{key}')
            for key in (
                'q20_coverage', 'q50_coverage', 'q80_coverage',
                'q20_q80_interval_coverage',
                'q20_q80_mean_width_seconds',
            )
        }
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding='utf-8'))
    if manifest.get('profile') != 'ready_head_reliability_wave1':
        raise ValueError('Analyzer received a different experiment profile.')
    results = []
    failures = {}
    for method_id, entry in manifest['commands'].items():
        try:
            results.append(summarize(
                method_id, entry, manifest['holdout_contract']
            ))
        except Exception as error:  # preserve a complete failure report
            failures[method_id] = f'{type(error).__name__}: {error}'
    eligible = [row for row in results if row['eligible']]
    winner = min(
        eligible, key=lambda row: row['selection_score_seconds']
    ) if eligible and not failures else None
    control = next(
        (row for row in results if row['method'] == 'R0_block_rule_control'),
        None,
    )
    if control is not None:
        for row in results:
            row['delta_vs_R0_selection_seconds'] = float(
                row['selection_score_seconds']
                - control['selection_score_seconds']
            )
            row['delta_vs_R0_nonblocking_mae_seconds'] = float(
                row['nonblocking_mae_seconds']
                - control['nonblocking_mae_seconds']
            )
    payload = {
        'schema_version': 1,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'manifest': str(args.manifest.resolve()),
        'complete': not failures and len(results) == len(manifest['commands']),
        'failures': failures,
        'winner': winner,
        'ranking': sorted(
            results, key=lambda row: row['selection_score_seconds']
        ),
        'promotion': (
            'predictor selected for a later policy-injection experiment; '
            'no policy was changed in this wave'
            if winner is not None else 'withheld because the full screen is incomplete'
        ),
    }
    atomic_json(args.output.resolve(), payload)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload['complete'] and winner is not None else 2


if __name__ == '__main__':
    raise SystemExit(main())
