"""Explicit provenance for the isolated B0 cross-Stage1-seed reproduction."""

import hashlib
import json
from pathlib import Path


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fixed_teacher_ready_binding(args, checkpoint, student, donor):
    path = getattr(args, 'b0_fixed_teacher_contract', '')
    if not path:
        return None
    path = Path(path).resolve()
    contract = json.loads(path.read_text())
    h3 = contract.get('protocol') == 'b0_h3_fixed_teacher_cross_stage1_seed_v1'
    if contract.get('protocol') != 'b0_fixed_teacher_cross_stage1_seed_v1' and not h3:
        raise ValueError('Unknown B0 cross-parent contract.')
    required = {
        'request_ready_policy_injection': 'none',
        'request_ready_loss_coef': 0.0,
        'device_bc_training_scope': 'policy_frozen_ready',
        'device_bc_teacher': 'iga',
        'training_stage': 'resource_joint',
        'ppo_epoch': 0,
        'num_episodes': 0,
        'seed': 11,
        'train_sampling_seed': 1,
    }
    for key, value in required.items():
        if getattr(args, key, None) != value:
            raise ValueError(f'B0 fixed-teacher contract requires {key}={value!r}.')
    parents = contract['stage1_parents']
    parent = next((p for p in parents.values() if p['sha256'] == student['sha256']), None)
    if parent is None or Path(parent['path']).resolve() != Path(student['path']).resolve():
        raise ValueError('Stage1 source is not an authorized cross-parent checkpoint.')
    if file_sha256(parent['path']) != parent['sha256']:
        raise ValueError('Stage1 parent digest changed.')
    expected_donor = contract['ready_donor']
    if (donor['sha256'] != expected_donor['sha256']
            or Path(donor['path']).resolve() != Path(expected_donor['path']).resolve()
            or file_sha256(donor['path']) != expected_donor['sha256']):
        raise ValueError('Ready donor differs from the pinned original R1 checkpoint.')
    donor_parent = contract['teacher_stage1_source']
    if checkpoint.get('source_m2_sha256') != donor_parent['sha256']:
        raise ValueError('Ready donor Stage1 provenance mismatch.')
    if file_sha256(donor_parent['path']) != donor_parent['sha256']:
        raise ValueError('Teacher/Ready Stage1 source digest changed.')
    teacher_path = Path(args.resource_iga_teacher_index).resolve()
    if (teacher_path != Path(contract['teacher_index']).resolve()
            or file_sha256(teacher_path) != contract['teacher_index_sha256']):
        raise ValueError('Fixed teacher index differs from the original corpus.')
    teacher = json.loads(teacher_path.read_text())
    if teacher['frozen_plane_checkpoint_sha256'] != donor_parent['sha256']:
        raise ValueError('Fixed teacher Stage1 provenance mismatch.')
    planning_binding = {}
    if h3:
        source_index = Path(checkpoint['resource_iga_teacher_index']).resolve()
        original_index = contract['ready_teacher_index']
        if (source_index != Path(original_index['path']).resolve()
                or file_sha256(source_index) != original_index['sha256']):
            raise ValueError('Inactive Ready donor teacher provenance changed.')
        source_planning = checkpoint.get('resource_lookahead_contract')
        if source_planning != contract['ready_planning_contract']:
            raise ValueError('Inactive Ready donor planning provenance changed.')
        target = contract['planning_contract']
        if (source_planning.get('device_future_intent_horizon') != 2
                or source_planning.get('device_frontier_max_requests') != 4
                or target != {**source_planning, 'device_future_intent_horizon': 3}
                or teacher.get('resource_lookahead_contract') != target
                or any(getattr(args, key, None) != value for key, value in target.items())):
            raise ValueError('H3 fixed-teacher admission requires exact H2/F4 to H3/F4 inactive-Ready transfer.')
        planning_binding = {
            'inactive_donor_planning_contract': source_planning,
            'runtime_planning_contract': target,
            'ready_teacher_index': original_index,
            'runtime_teacher_index': str(teacher_path),
            'scope': 'fresh H3/F4 resource BC conditional on one seed3 H3/F4 teacher corpus; inactive H2/F4 Ready donor retained',
        }
    return {
        'protocol': contract['protocol'],
        'contract_path': str(path),
        'contract_sha256': file_sha256(path),
        'student_stage1_sha256': student['sha256'],
        'donor_stage1_sha256': donor_parent['sha256'],
        'ready_donor_sha256': donor['sha256'],
        'teacher_index_sha256': contract['teacher_index_sha256'],
        'ready_policy_injection': 'none',
        'ready_loss_coefficient': 0.0,
        'scope': 'cross-Stage1-seed reproduction conditional on the fixed original teacher corpus',
        **planning_binding,
    }
