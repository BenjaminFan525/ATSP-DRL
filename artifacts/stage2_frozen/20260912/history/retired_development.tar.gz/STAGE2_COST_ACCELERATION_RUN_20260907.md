## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: user-authorized stop, artifact preservation, launch and monitoring
- Origin Date: 2026-09-07 (Asia/Shanghai)
- Verification Status: stop and artifact preservation verified; new training NOT STARTED
- Version Label: gpu0_half_handoff_r1_launch_environment_blocked

## 交接结果

用户授权：停止旧诊断、保留全部产物，并在 GPU0 和原 CPU 半区切换到新流程。

旧诊断已停止，产物全部原地保留；新流程尝试启动后，在 `prepare_bc_canary` 阶段因 systemd 的 PATH 缺少 `rg` 退出。没有启动 N0/N1 训练，没有生成新的训练权重，也没有自动重试。已向用户请求授权：修正新服务的启动环境后，以新编号重新启动并保留本次失败目录。

## 旧诊断停止与完整性

- 服务：`hkbz-stage2-cost-improvement-20260907-gpu0-half-r1.service`。
- 控制器 PID 2938076，诊断 PID 2938087。
- 停止请求时间：2026-09-07 09:04:05 CST。
- 命令：`systemctl --user stop --no-block hkbz-stage2-cost-improvement-20260907-gpu0-half-r1.service`。
- 服务此前运行约 7 小时 13 分钟，仍处于诊断阶段，未启动 N0–N3 训练。
- 停止后已确认：控制器、诊断、环境子进程和资源组中的任务全部退出，`cgroup.events` 为 `populated 0`，GPU0 不再有计算进程。
- 主机 systemd 日志存在 inotify watch 耗尽提示，导致空资源组的停止状态延迟到 09:07:05 才收尾，最终服务标签为 `failed/result=timeout`；这不表示仍有训练进程。未更改系统全局限制，也未处理任何其他服务。

原始目录：`result/hkbz_train_logs/stage2_cost_improvement_20260907_gpu0_half_r1/`。

停止前后均为 **238 个文件**；无删除、无替换目录、无重启或追加实验。仅 `controller.log` 和 `pipeline_state.json` 因正常停止记录而变化，其余 236 个文件的 SHA256 均保持一致。停止后总文件大小为 114,665,012 字节。

落盘证据包含 **33 个状态、104 条已完成候选续跑结果**。停止时尚在内存中的未完成计算不冒充已落盘证据。源码归档、冻结目标、环境快照、历史状态、原始日志和诊断报告均保留。旧报告中的 `running` 字段和控制器中的 `failed` 字段保持原样；本交接记录将本次中断明确标注为 `stopped_by_user_for_new_pipeline`，不改写原始科研记录。

逐文件清单及前后状态：

- `result/hkbz_train_logs/stage2_cost_switch_20260907_gpu0_half_r1/handoff_before_stop.json`
- `result/hkbz_train_logs/stage2_cost_switch_20260907_gpu0_half_r1/handoff_after_stop.json`

旧 manifest SHA256：`a63ea6e9321a83381fd227fc215de849730f71c8bb4c1049c11e9ec849262299`。
旧 manifest 固定的 231 个源码文件在切换前逐项校验通过。

## 新流程首次启动记录

- 新目录：`result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r1/`，与所有旧目录及开发验证目录隔离。
- 命令：`env RUN_TAG=stage2_cost_accelerated_20260907_gpu0_half_r1 PYTHON=/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11 bash onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh`。
- 服务：`hkbz-stage2-cost-accelerated-20260907-gpu0-half-r1.service`。
- 启动时间：2026-09-07 09:05:59 CST；控制器 PID 2988846；准备子进程 PID 2988859。
- 退出时间：09:06:30 CST；退出码 1；失败阶段 `prepare_bc_canary`。
- 运行控制器记录：`pipeline_state.json`、`controller.log`、`prepare_bc_canary.log`。
- 根 manifest 和两份源码归档已生成，均保留；尚未生成 BC canary 子目录。
- 根 manifest SHA256：`dc45c6e91b759c03b3e9b76440954fef972d508aed8ff132035ce24abd61c7dd`。
- 加速源码归档 SHA256：`545128ddd773827b6eb14e441133642a7e27859836b53de8bf03527905f1f8f7`。
- 246 个固定源码/配置/说明文件与此前 `devcheck_r4` 完全一致。本次没有修改训练代码或源码指纹。

根 manifest 的输入、源码、归档和原 CPU 半区契约在启动前通过只读检查。第一次人工检查误把 `CUDA_VISIBLE_DEVICES` 留空，被资源检查按预期拒绝；将该检查环境改为启动器要求的 `0` 后通过，期间没有创建 GPU 上下文或执行训练。

## 启动阻断原因与待授权动作

`prepare_stage2_bc_injection.code_fingerprint()` 调用 `rg --files` 生成源码指纹。交互终端能找到 `rg`，但 systemd 用户管理器的 PATH 为：

`/home/fanyx/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin`

该 PATH 中没有 `rg`。实际 `rg` 位于 Codex 安装的 `codex-path` 目录，而新启动器未显式向服务传递工具 PATH，因此准备子进程抛出 `FileNotFoundError: [Errno 2] No such file or directory: 'rg'`。这属于启动环境错误，不是模型或训练失败。

待用户授权后：只为新服务补全工具 PATH，检查服务环境下必需命令可用，再使用全新运行编号启动。不得复用或覆盖 `r1` 目录，不得全局修改 systemd 环境影响 GPU1，不得跳过源码指纹、复验或科学门槛。

依据 academic-research-suite 的实验执行规范，失败后不自动重试；本次已主动报告并请求决定。

## 资源与新流程安排

- 仅物理 GPU0，UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`。
- CPU `0-31,64-95`，32 个物理核及其 SMT 兄弟，共 64 个逻辑 CPU。
- 训练通道：`0-11,64-75` 与 `12-23,76-87`；共享评估：`24-29,88-93`；监控：`30-31,94-95`。
- 服务级 `AllowedCPUs`、`CPUAffinity` 均核实为该半区；`Restart=no`；总硬上限 48 小时。
- 新流程阶段：N0/N1 canary → N0/N1 pilot → 完整加速等价性/吞吐验证 → 成本诊断 → N2/N3 canary → 条件通过后的 N2/N3 pilot。
- N0/N1 不再等待成本诊断。N2/N3 仍须通过完整复验、可学习性和容量检查，不能以短程工程检查代替。
- GPU1 的 MAIA 服务保持运行，MainPID 2719600 及其 5 个 GPU 进程与切换前一致，未发送停止信号、未改动 CPU 分配。

当前没有任何新的 N0–N3 训练在运行；不能将服务曾短暂启动或已有工程加速验证解释为训练已完成或研究目标达成。
