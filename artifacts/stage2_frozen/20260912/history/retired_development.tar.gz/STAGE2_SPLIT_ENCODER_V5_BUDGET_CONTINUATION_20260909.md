# V5 新时间授权与续跑（r3）

## Material Passport

- Origin Skill: academic-research-suite/experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-09
- Verification Status: UNVERIFIED
- Version Label: v5_explicit_budget_continuation_v1

## 授权与范围

用户明确要求：“重新授权时间预算，然后继续实验”。依据此前完整剩余流程
25–29小时的粗估，采用从新控制器启动起 **30小时** 的硬上限。此授权替代
原2026-09-10 01:31截止时间，不意味着追加数据、第二轮或无限期重试。
只使用GPU0及CPU `0-31,64-95`，最多2训练进程，评估互斥。保持Restart=no。

## 恢复点

来源：`result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r2`。
四臂工程各24病例全部完成，所有工程worker退出码为0；因预算门禁退出，
没有执行初始tune60复验、B0参考采集或科学训练。

已完成96病例不重复采样。新目录只复制必要的工程报告/完成状态；
原目录、checkpoint、fixture、日志和旧预算报告全部保留；对续跑依赖的
报告、状态、checkpoint及旧预算记录SHA256。
训练仍重新从不可变B0初始化，不使用丢弃的工程更新权重。

续跑只新增调度适配器和启动入口，不修改任何已通过工程复验的科学代码。
新manifest同时冻结新代码和旧工程来源。若旧代码、源checkpoint、报告
或复制文件发生变化，拒绝复用工程结果。

## 剩余流程与预算

1. 四臂初始AR tune60及B0 Hungarian tune60，共300病例。
2. B0 train240参考原图与MC目标采集，共240病例。
3. 根据完整复验实测耗时重新检查剩余时间，门禁不放宽。
4. E0–E3各train240，共960训练病例；轮5/10的AR以及轮10的Hungarian
   评估共720病例。最多80 actor更新/臂、700 critic更新/臂，训练参数不变。

本次新增上限 **2220病例**，加上保留的96工程病例，原首批总量仍为2316。
不自动重复工程，不自动重试失败，不自动追加种子、Stage C、IGA或Stage3。
新30小时控制器deadline优先于保留训练配置中旧的默认24小时字段；worker
本来就从control.json读取硬截止时间，学习率、loss、采样、更新次数均不变。

科学效果仍是UNVERIFIED。工程复验通过不能证明已达到IGA目标。

## 启动前验证

旧manifest固定的282个代码/配置文件以及不可变输入校验均通过。
11项新增续跑回归与45项现有V5/V3/V4回归全部通过（合计56项）：
覆盖禁止重复工程、保留病例只计数一次、新30小时起点、预算不能静默延长、
数据/资源范围不能变更，以及坏报告/NaN/梯度或退出证据缺失时拒绝续跑。
新增启动脚本通过bash语法检查，当前改动通过git diff --check。
这些检查不产生额外完整环境病例，不能代替后续零更新复验或科学效果验证。
