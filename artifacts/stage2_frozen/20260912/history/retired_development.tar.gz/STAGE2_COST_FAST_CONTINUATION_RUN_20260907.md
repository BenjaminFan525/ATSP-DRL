# N2/N3 frozen-inference acceleration and r4 continuation

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent execution and deterministic verification
- Origin Mode: user-authorized implementation (N2/N3 acceleration)
- Origin Date: 2026-09-07
- Verification Status: unit, CUDA and prefix checks passed; complete trajectory verification running at handoff
- Version Label: r4 / full_batch_exact_host_matching_v1

## Applied changes

Only frozen cost actors use batched host matching and vectorized unique GPU
output writes. The original float64 solver and all neural operators are
unchanged. Private inference threads increase from 2 to 4; the candidate
execution window increases from 8 to 16. No cases, candidates, epochs,
continuation horizons, recurrent states, losses or evaluation rules change.
The original model/learner/environment/teacher/evaluator source hashes remain
identical to those of the completed r3 N0/N1 controls.

The multiprocess alternative was slower and is not enabled. An index-only
forward transformation had no stable extra gain and was removed from the
deployment path. Their performance-screen archives/results are retained.

## Verification completed before launch

- Targeted regression run: 90 tests, 89 passed and the unavailable CUDA test
  skipped in the CPU-only run. A subsequent strict deterministic GPU0 run
  passed all 5 matching tests, including the CUDA output/gradient test.
- After the last guard/continuation edits: 12 schedule/continuation tests passed.
- Launcher syntax and diff whitespace checks passed.
- Performance screen r2 (two archived real batch-24 states, 5 repeats of 8
  requests): previous two-thread median 1.389789 seconds; selected four-thread
  host-matching median 1.046852 seconds, 1.328x actor-only throughput. Every
  action and complete recurrent tensor matched the unchanged reference.
- Integration smoke: both fixed batch-2 and batch-24, 8 continuation steps,
  exact actions/recurrent/terminal-status traces. Versus the previous
  8-branch/2-thread executor, measured speedups 1.218700x and 1.230655x.
  The smoke correctly records `acceleration_gate_passed=false` and cannot
  authorize training. These timings are not complete-training speedups/ETAs.
- Continuation preparation verified 34 bound baseline artifacts and immutable
  source archives. All changed production files are explicit cost-only or
  orchestration amendments; the scientific/control source remains unchanged.

Evidence:

- `result/hkbz_train_logs/stage2_cost_inference_screen_20260907_r2/report.json`
- `result/hkbz_train_logs/stage2_cost_fast_continue_preflight_20260907_r1/acceleration_smoke/report.json`

## Controlled transition and active run

The old r3 pipeline was explicitly stopped to implement the requested
acceleration. Its root exited, and the service reached its bounded stop
timeout while cleaning up remaining processes. Its final systemd `timeout`
and pipeline interruption status describe this operator transition, not a
new learning/integrity failure. No old report/status was rewritten to success.
All artifacts remain: 10 complete diagnostic state records, 43 completed
candidate cache entries, in-progress snapshots, and all N0/N1 outputs. Old
cache entries are not imported into a new source/runtime namespace.

New service: `hkbz-stage2-cost-accelerated-20260907-gpu0-half-r4.service`.
Started 2026-09-07 18:40:41 CST; root PID 3306691, proof PID 3306709.
Verified active/running, GPU0 only, affinity `0-31,64-95`.
Service RuntimeMaxSec at launch: 147827 seconds (41h 03m 47s), not a fresh
48-hour budget. Original controller deadline remains September 9 11:44:28 CST.

Suite: `result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r4/`.

- Manifest SHA256: `00968774d4ce60d9addd3e70e1db1a27a7f327a4cbaa1ee891c7c05d6b5cad0b`
- Source archive SHA256: `8a707282f7ed579985cb27aef38eade120c83e8abcc1af06778cd2b4dcde550f`
- Executor SHA256: `96cacd84a53c5248bbed7e10ba8235f92e8ccbafe8fd4372125e09e9f3f1b06b`
- Source namespace: `fd73ab6b87ce9f07bf5e51eae628fa1a57ca91401ed7b08e667670a0ee2c85c4`
- Pinned source files: 256.

At handoff, `phase=acceleration`, `baseline_completed=true`,
`baseline_reused=true`, `cost_completed=false`. N2/N3 gradient training has
NOT started. The controlled sequence is complete three-path replay at both
batch sizes, original cost diagnostic, cost canary, capacity check, then
N2/N3 pilot and four-arm analysis using explicitly identified reused controls.
The new full proof must beat both unchanged serial and previous fanout paths
while exactly matching complete action/dual-GRU traces, terminal steps, Cmax
and cache replay. Any failed gate holds the cost path without retry. The
remaining budget can still hold the pilot; no overall acceleration/finish-time
guarantee is implied by the short benchmarks.

## Reproduction

The launch used the existing dedicated launcher with `RUN_TAG` ending in
`gpu0_half_r4`, `CONTINUE_FROM` pointing at the stopped r3 manifest,
`FANOUT_WIDTH=16`, `ACTOR_LANES=4`, `INFERENCE_MODE=host_matching`, and Python
`/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11`.
Do not reuse output directories or edit pinned source while r4 is running.
