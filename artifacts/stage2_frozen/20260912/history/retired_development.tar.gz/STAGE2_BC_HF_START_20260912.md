## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: plan + run
- Origin Date: 2026-09-12, Asia/Shanghai
- Verification Status: engineering VERIFIED; full evaluation RUNNING; research outcome UNVERIFIED
- Version Label: stage2_bc_hf_start_v1

# BC H/F 研究首批启动记录

计划见 [研究计划](STAGE2_BC_HF_RESEARCH_PLAN_20260912.md)。本次实际启动 A：
冻结 B0 + Hungarian 的 12 组 H/F tune60 敏感性评测，包含原生基线、
固定容量基线和终末重复，共 14 次评测/840 个物理 case-episodes。
不是四组独立 BC 训练；后台没有教师搜索、BC/PPO 或 Stage3 启动入口。

## 实现与验证

新增专用合同、prepare/check/run、GPU0 launcher 和单元测试；未改
原有物理环境、网络、匹配解码器及训练器实现，未覆盖任何历史产物。
源 checkpoint 保持原始 H2/F4 元数据，本轮变化单独记为反事实部署
配置。请求容量固定 5、评测批宽 12，保留历史 no-grad 的 GRU 元数据。

- 55 项 unittest 回归全部通过；新 launcher 的 bash 语法检查通过。
- 12/12 组 GPU0 工程检查通过，耗时 157.592 秒。
- 工程检查只使用固定 6 个训练案例的 64 事件前缀，零参数更新、零
  教师查询；不记为完整科学 case-episodes。
- 原 train240/tune60 内容哈希核验通过；分布分别 120/108/12 与30/27/3。
- 工程证据：`result/hkbz_train_logs/stage2_bc_hf_20260912_gpu0_half_engineering_r1/report.json`。
- 本机环境未安装 pytest；直接使用项目已有 unittest，不安装新依赖。

## 实际启动

- 服务：`hkbz-stage2-bc-hf-20260912-gpu0-half-r1.service`
- systemd 启动时间：2026-09-12 01:27:25 CST
- 初始主 PID：706739；初始基线 worker PID：706800
- 已只读核实 `ActiveState=active`、`SubState=running`。
- `CUDA_VISIBLE_DEVICES=0`，GPU0 UUID 744c1334-98c8-5318-e799-7ad15eea1fbf。
- `AllowedCPUs` 与 `CPUAffinity` 均为 0–31,64–95。
- 两个评测槽最多并发；首尾基线复验串行。GPU1 及其 CPU 半区未改动。
- `Restart=no`，`RuntimeMaxUSec=infinity`，无自动重试或恢复墙钟杀停。

产物根目录：
`result/hkbz_train_logs/stage2_bc_hf_20260912_gpu0_half_tune60_r1/`

其中 `manifest.json` 固定输入与工作量，`source_bundle.tar.gz` 保留源码；
`run_status.json` 为控制器状态，`workers/*/run_status.json` 和
`workers/*/worker.log` 为各组状态，`evaluations/` 为逐批/逐例结果。
必须先通过两次 H2/F4 对原 B0 的完整精确复验，才续发其余网格配置。

下一阶段仍是四个预定锚点 H2/F4、H2/F2、H1/F2、H3/F4 的 train-only
教师兼容性/质量/成本审计，再做独立 train240/tune60 匹配式 BC。
不能将 A 的冻结模型排名解释成已经找到 BC 的重训最优 H/F。
