# Stage2 pilot B2 提前启动记录

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-05
- Verification Status: UNVERIFIED（研究结果未完成；启动及资源检查已验证）
- Version Label: stage2_b2_early_start_v1

## 用户授权与范围

用户明确要求“启动 B2”。目标是提前执行现有 pilot 的 `B2_R1_seed11`，
而不是新增方法、seed 或另开一份同名实验。只使用物理 GPU0 和原 CPU 半区
`0-31,64-95`，不重启 B0/B1，不接触 GPU1 上的任务。

原 suite：`result/hkbz_train_logs/stage2_bc_injection_20260905_gpu0_half_pilot_r2`。
原 manifest 和原始 210 文件源码归档不改写；仅单任务启动器增加防重复与接管逻辑。
所有冻结数值/训练源文件、S1/R1 模型、teacher index 在附加启动前重新核验。

## 调度变更

| 用途 | 调整后的逻辑 CPU |
|---|---|
| B0 | `0-7,64-71`（16） |
| B1 | `12-19,76-83`（16） |
| B2 | `8-11,20-23,72-75,84-87`（16） |
| 原共享评测 | `24-29,88-93`（12，不变） |
| 控制器和附加监控器 | `30-31,94-95`（4） |

总计 64 个唯一逻辑 CPU，各训练组、评测池之间互不重叠，不拆分 SMT sibling。
B0/B1 原进程组的全部现存线程在线调整 affinity，训练进度、优化器和 RNG 不重置。
CPU affinity 的变更不改变 rollout 批宽：每组仍为 24 个环境、每 epoch 10 次完整
rollout、共 2 个 epoch、固定 240 案例；评测始终为严格数值模式下的 12 环境/60 案例。

B0/B1 allocator fraction 保持 0.40；B2 使用 0.10；共享评测保持 0.10。
这些是显存分配上限，而不是预留量。B2 预期显存需求参考已运行两组约 1.6 GiB/组，
启动后还需实测验证；显存上限不改变模型数学计算或训练样本。

## 避免重复与生命周期

- B2 用附加 systemd 服务启动，`Restart=no`，不自动重试。
- 每个 manifest command 通过跨进程独占锁防重复。
- 附加监控器持锁；同名原队列任务随后启动时读取绑定 manifest SHA 的接管记录，
  等待这一进程的真实退出码，不再次执行训练。
- PID 身份同时绑定 boot ID 和进程 start ticks，防止 PID 重用造成误接管。
- 原控制器因此会等待 B2 完成后再进行全套分析、关闭共享 evaluator。
- 附加服务绑定原 suite 的 systemd 生命周期，并沿用其原定 48 小时总截止时间。
- 运行中若监控器异常消失，接管程序报错，不将其解释为完成或自动重新训练。

原控制器内存里的 `pending` 不支持热更新，所以在原训练槽位释放以前，
`suite_status.json` 仍可能显示 B2 pending。此阶段 B2 的真实状态以
`external_jobs/B2_R1_seed11.json` 和其 `run1/run_status.json` 为准。

## 可追溯文件

以下均位于原 suite，独立新增，不覆盖既有 B0/B1 日志：

- `external_jobs/B2_R1_seed11.json`：实际 PID、资源调整审计、源码差异及生命周期。
- `records/B2_R1_seed11.external.json`：B2 实际执行命令及资源覆盖项。
- `service_logs/B2_R1_seed11.external.log`：B2 实际训练日志。
- `service_logs/B2_R1_seed11.supervisor.log`：附加监控器日志。
- `b2_external_source_bundle.tar.gz`：本次接管相关源码的补充快照。
- 原队列轮到 B2 后，标准 `records/B2_R1_seed11.json` 记录接管而非重复训练。

## 启动验证

2026-09-05 19:24:58（北京时间）启动成功：

- 附加服务：`hkbz-stage2-bc-injection-20260905-gpu0-half-pilot-r2-b2-early.service`。
- B2 训练进程 PID `2385273`，附加监控器 PID `2385272`。
- B0/B1 仍为原 PID `2376349` / `2376350`，没有重启或回退。
- B2 已加载绑定的 S1/R1，并在共享 evaluator 中实际开始执行 `pre_supervised`，
  不是只创建了一个等待训练槽位的空进程。评测完成后自动进入 BC。
- 19:26:30 资源终核：90 个进程、182 个线程，实际 CPU 并集恰好为
  `0-31,64-95` 共 64 个逻辑 CPU，affinity 违规数为 0。
- 三组训练及 evaluator 均位于 GPU0 UUID
  `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`；GPU1 未改动。
- B2 实际执行参数再次确认：seed11、sampling seed1、24 rollout envs、12 eval envs、
  240 cases、2 epochs、每 epoch 10 rollouts、learned injection；
  显式 runtime override 仅为 `cuda_memory_fraction=0.10`。
- 原 manifest SHA 未变，冻结模型、teacher index 和原源码归档 SHA 均通过检查。
- 调度接管、资源覆盖、BC injection、复验和既有 resource research 合计
  **53 项回归测试通过**；4 个涉及 Python 文件的语法检查通过。
- 补充源码归档 SHA-256：
  `6cdbb6be43836440df1e395aba3a8088f8b08337fd7370797742d1010a615db1`。

研究成败仍由原 pilot 的完整性检查和逐 epoch tune60 结果决定，提前启动不构成
正式 Stage2 通过。B2 本次启动时尚未进行梯度更新，不能把“已启动”写成“训练已完成”。
