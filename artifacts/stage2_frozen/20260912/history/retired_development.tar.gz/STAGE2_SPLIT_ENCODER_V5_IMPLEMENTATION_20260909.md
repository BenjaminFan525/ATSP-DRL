# V5 E0–E3 实现与启动记录

## Material Passport

- Origin Skill: academic-research-suite/experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-09
- Verification Status: UNVERIFIED
- Version Label: split_encoder_v5_implementation_r1

科学效果尚未验证。当前只完成代码与启动前检查，不可视为已完成训练。

## 实现

- 原 `GNN_Actor_Critic.forward` 增加 opt-in 独立资源编码器路径；无新编码器的旧模型
  保持原路径。仅追加这段新逻辑，保留该文件此前所有用户改动。
- `onpolicy/utils/stage2_resource_rl_v5.py`：E0–E3 独立初始化、互斥优化器、
  原图/冻结视图缓存、价值 MC 快照、48/6 图批次 critic、分层均匀采样、
  每例至多32状态的原始图参考池、严格权重/Adam/RNG 恢复、运行指标分区。
- `onpolicy/utils/stage2_resource_rl_v5_handoff.py`：版本化角色、白名单、原始/当前
  hash 和真实 B0/Stage1 血缘校验；拒绝未完成产物用于完成态交接。旧验证器未放宽。
- 新 prepare / worker / controller / launcher：train240 原案例与顺序、tune60、
  工程96例、初始检查300例、参考240例、训练960例、训练评估720例；
  共2316病例，两训练槽、评估互斥、首批24小时、禁止自动重试与 Stage C。

## 已执行验证

- 42 项 V3/V4/缓存/阶段交接回归测试通过。
- 10 项 V5 新测试通过，包括真实图梯度和缓存隔离、真实 B0 四臂文件交接、
  Adam 状态独立、运行指标不继承旧值、预算门禁、cuDNN 风格连续缓冲区。
- 四臂真实 CUDA 模型构造、无重叠参数与权重/Adam/RNG 恢复全部通过；
  检查报告：`result/hkbz_train_logs/stage2_split_encoder_v5_gpu_layout_check_20260909_r1/report.json`。
  这是零环境病例的合成参数更新检查，测试更新丢弃，不能替代完整工程基准。
- 启动脚本通过 `bash -n`，当前补丁通过 `git diff --check`。

## 首次启动与修复

服务 `hkbz-stage2-split-v5-20260909-gpu0-half-r1.service` 于
2026-09-09 01:31:17 CST 启动，仅 GPU0、CPU `0-31,64-95`。
目录：`result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r1`。

首次启动在 E0/E1 模型构造期间失败。原因是隔离检查只比较底层 storage 地址，
把 cuDNN 同一 GRU 连续缓冲区中的不同权重误判为共享参数。
已改为比较含 storage_offset 的实际字节区间：允许不重叠的连续布局，
真正的重叠仍拒绝。新增对应正、负测试并在真实 GPU0 上复验通过。

本次失败的环境尝试数、完成病例数、正式更新数均为0。所有旧产物保留；
未自动重试，未启动科学训练，未触及 GPU1 实验。
根据实验执行规范及“不自动重试”的协议，已向用户请求修复后的重新启动授权。
新 prepare 的显式 `--repair-of` 路径只接受这种零病例初始化失败，使用新目录，
保留原截止时间，不扩大病例或墙钟预算；不得用于静默重跑已采集病例。

## 用户授权后的 r2 重启

用户于 2026-09-09 明确要求“修复问题，并且重新启动实验”。复核代码后，
再次执行45项 V5/V3/V4/缓存回归测试，全部通过；控制器状态测试另通过1项。
四臂真实 GPU0 模型与 Adam/权重/RNG 恢复再次全部通过，报告位于
`result/hkbz_train_logs/stage2_split_encoder_v5_gpu_layout_check_20260909_r2/report.json`。

新服务 `hkbz-stage2-split-v5-20260909-gpu0-half-r2.service` 于
2026-09-09 **08:59:19 CST** 启动。新目录：
`result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r2`。
启动命令为：

```bash
UNIT_NAME=hkbz-stage2-split-v5-20260909-gpu0-half-r2 bash onpolicy/scripts/train/launch_stage2_resource_rl_v5_gpu0.sh result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r2/manifest.json
```

重启使用显式 `--repair-of` 新 manifest，r1 产物及其失败状态未覆盖。
沿用原截止时间 **2026-09-10 01:31:22 CST**，不重新授予24小时。
状态输出新增本进程运行时间与原预算经过时间，避免将等待重启的时间误认为训练时间。

启动后现场核验：主进程4036515；E0进程4036729，CPU `0-11,64-75`；
E1进程4036730，CPU `12-23,76-87`。两个工程进程均映射至物理GPU0，
服务限制CPU `0-31,64-95`，Restart=no；GPU1原实验保持运行。
首次持续进度核验中，E0/E1分别推进至31/26个全局事件步，暂无新异常。
这些是工程批次采样，不是已通过全部门禁的科学训练。

后续仍由控制器依次执行 E2/E3 工程基准、全量零更新复验、B0原图参考采集、
剩余时间预算门禁，然后才允许四臂各train240。首批之外不自动续轮、晋级或重试。

## 新时间授权后的 r3 准备（当时尚未启动）

r2 的 E0–E3 工程共96例已全部通过，四个worker退出码为0。
控制器于2026-09-09 10:32因原时间预算不足退出，尚未进入初始复验或正式训练。
用户随后明确要求“重新授权时间预算，然后继续实验”。

已按完整剩余流程25–29小时粗估记录新的30小时硬上限，准备独立目录：
`result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r3`。
范围与恢复协议见 `STAGE2_SPLIT_ENCODER_V5_BUDGET_CONTINUATION_20260909.md`。
旧282个固定代码/配置与不可变输入校验通过，56项回归测试全部通过。
新manifest及复制报告校验通过，原96工程病例仅保留不重跑；剩余2220病例，
其中正式训练仍为四臂各240例。只使用GPU0与CPU `0-31,64-95`。

本次主机只读检查和服务启动的自动权限审查均超时；两类请求各按工具提示
仅重试一次，仍未创建执行进程。普通沙箱不能访问NVIDIA驱动或用户级systemd总线。
这不是GPU损坏或训练异常的证据，也不能报告“实验已恢复”。
最终检查r3尚无 `control.json`，新30小时预算尚未开始；旧产物全部保留。
恢复主机执行权限后，使用已准备的manifest启动，不再次prepare或重跑工程：

```bash
bash onpolicy/scripts/train/launch_stage2_resource_rl_v5_continuation_gpu0.sh result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r3/manifest.json
```

预计新服务名为 `hkbz-stage2-split-v5-20260909-gpu0-half-r3.service`。
实际启动与首个持续进度尚待核验；不得将此准备记录当作运行或科学成功证据。

## 用户再次确认后的 r3 实际启动

用户随后明确要求“启动”。本次宿主机权限审查恢复正常；启动前确认
GPU0空闲、r3服务不存在、control.json不存在，且续跑来源和代码校验再次通过。
沿用上述r3目录和命令，未重新prepare，未修改已固定的科学代码或训练参数。

服务 `hkbz-stage2-split-v5-20260909-gpu0-half-r3.service` 于
**2026-09-09 12:18:20 CST** 启动，现场状态为active/running。
新控制器于12:18:24开始计时，内部截止为2026-09-10 18:18:24 CST；
systemd的30小时硬上限更早约5秒，于**2026-09-10 18:18:20 CST**到达。
Restart=no，AllowedCPUs和CPUAffinity均为 `0-31,64-95`。

主进程4097399，实际CPU `30-31,94-95`，初次内存采样RSS 697152 KiB。
setup worker为4097480，当前评估CPU `24-29,88-93`，RSS 1430644 KiB。
GPU现场核验该worker仅位于物理GPU0
`GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`，采样时进程显存1296 MiB。
这些是启动后的瞬时资源读数，不是峰值或训练吞吐指标。

控制器日志明确复用E0–E3原工程证明，新增工程病例为0，未加载工程更新权重。
新的初步预算门禁已通过，当前执行 `E0_initial_AR` 全量初始复验；
连续日志显示全局事件步50→102、环境事件600→1224，进度在推进，无当前异常。
尚未开始正式PPO训练：仍须完成四臂零更新复验、B0 Hungarian复验、
B0原图参考采集以及实测完整预算门禁。后续仅原Stage B四臂各train240，
不自动扩展规模、重试失败或进入Stage C/Stage3，科学效果仍为UNVERIFIED。

## 用户授权修复后的 r4 实际启动

r3随后在E0初始复验第247次前向失败：相同资源Actor权重因当前/冻结参考的
requires_grad元数据不同，触发不同矩阵计算路径，log-probability差异达到
1.0728836059570312e-6，略超1e-6阈值。动作、掩码、RNN隐状态相同。
故障复现、逐层定位、修复边界与证据见
`STAGE2_SPLIT_ENCODER_V5_ZERO_AUDIT_REPAIR_20260909.md`。

按用户“排查并修复问题，然后继续实验”的授权，只修复初始参考审计的
数值执行条件，不放宽误差阈值、不改变训练/参考KL路径。67项CPU回归通过；
精确故障输入上四臂GPU复验均完全一致，实际行为输出不变，真实权重扰动
仍被拒绝。修复清单、不可变输入、代码/产物hash及非审计AST签名均通过校验。

新服务 `hkbz-stage2-split-v5-20260909-gpu0-half-r4.service` 于
**2026-09-09 13:14:53 CST** 启动。独立目录为
`result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r4`。
启动命令：

```bash
bash onpolicy/scripts/train/launch_stage2_resource_rl_v5_repair_gpu0.sh result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r4/manifest.json
```

13:15:11现场核验：服务active/running，控制器4143988，setup worker4144059；
GPU进程仅映射至GPU0 UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`。
AllowedCPUs与CPUAffinity均为 `0-31,64-95`，Restart=no。
沿用r3原授权起点与截止时间，系统服务硬截止仍为
**2026-09-10 18:18:20 CST**；启动时剩余104606秒，没有重新开始30小时。

原工程96例证明复用，工程更新权重不加载；r3及所有诊断产物保留。
故障12例尝试和诊断12例尝试另列账本，不计作已完成训练或评估。
正式训练仍为四臂各240例；初始AR/H复验、B0原图参考采集和实测预算门禁
尚需完成，服务启动不等于正式PPO已经开始，科学效果仍为UNVERIFIED。

持续验证至13:19:47：E0_initial_AR首批12例全部完成，共579个全局事件步、
5264个环境事件，已经完整越过原第247次前向故障点并进入第二批。
当前初始评估完成12/60，未出现新的审计错误；这仅证明该批运行检查通过，
不替代剩余初始复验、预算门禁或正式训练效果验证。
实际进程CPU亲和性核验：控制器 `30-31,94-95`，评估worker `24-29,88-93`，
均在授权半区内。GPU1和另一CPU半区未作更改。

## 用户解除时间门禁后的 r5 接管准备

用户明确要求“解除超时门禁”。新增独立时间授权、接管控制器、无墙钟上限
训练入口及GPU0启动脚本；未修改任何r4已固定文件。协议与过渡边界见
`STAGE2_SPLIT_ENCODER_V5_TIME_LIMIT_REMOVAL_20260909.md`。

2026-09-09 15:18前完成81项回归测试（新增14项，原V3/V4/V5等67项），
全部通过；启动脚本语法和补丁空白检查通过。新增测试校验原训练方法直接
继承，科学初始化、错误处理及清理的AST一致，保留数值/KL/失败门禁，
只对旧调度器发信号、不打断setup，失败后恢复调度器且不自动重试。
首次新增测试中NaN负向样本被标准JSON写入层提前拒绝；测试改为在读取层
注入该负向输入后验证检查拒绝，没有修改生产序列化或数值阈值。

15:18现场文件进度：四臂各60例AR及B0_H 60例均完成，开始参考批次1/10。
仍未开始正式训练。宿主机只读权限审查及其一次重试均超时，均未创建命令
进程；这不证明实验故障。部署状态需以下实际执行记录确认，不以本准备记录
宣称已解除活动进程中的时间约束。

### r5 授权已准备，部署尚未生效

已创建一次性授权：
`result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r5/authorization.json`。
完整校验通过：292个旧固定文件保持不变，新快照297个文件；科学训练仍960例，
setup之后剩余1680例。新源代码快照已固定，不应再编辑其文件后直接启动。

宿主机部署请求及按工具提示的一次重试均因自动权限审查超时而未创建命令进程。
**截至15:24:17，r5没有handoff_started.json或control.json，活动时间门禁未解除。**
没有暂停旧调度器、没有中断setup，也没有修改旧服务RuntimeMaxSec。
r4仍正常执行参考批次2/10，原截止与预算门禁仍有效，正式训练0/960。
本次阻塞是宿主机执行权限不可用，不是已观察到的科学失败或安全拒绝。

活动状态记录在r5的`activation_status.json`。权限恢复后使用同一授权启动，
不要重新prepare或重跑已完成病例：

```bash
bash onpolicy/scripts/train/launch_stage2_resource_rl_v5_unlimited_gpu0.sh result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r5/authorization.json
```

若届时r4已自然停在“完整setup完成后的预算门禁”，接管器支持该零训练停止点；
若出现科学失败或已经进入训练，它会拒绝隐式重跑，需要新的明确处理决定。

### 再次授权后的部署兼容性修复

用户再次明确要求“解除超时门禁”。本轮首次部署权限审查超时，按提示重试后，
r5服务于2026-09-09 15:31:16实际启动，但接管器在任何进程控制操作之前退出：
Conda Python3.11未提供`os.pidfd_open`及`signal.pidfd_send_signal`。
r4控制器和setup未暂停，旧服务RuntimeMaxSec未改动，没有新增科学病例或更新。
r5错误状态、日志、授权和源码快照全部保留，不覆盖或重启该失败服务。

已新增兼容层，在缺失Python包装时调用相同Linux pidfd系统调用；限定已核实的
Linux x86-64 LP64 ABI，保留内核权限错误及PID重用保护，不退化为数字PID kill。
宿主环境为Linux6.8、glibc2.35，本地头文件与
[Linux6.8系统调用表](https://github.com/torvalds/linux/blob/v6.8/arch/x86/entry/syscalls/syscall_64.tbl)
核对一致。接口依据：[pidfd_open](https://man7.org/linux/man-pages/man2/pidfd_open.2.html)、
[pidfd_send_signal](https://man7.org/linux/man-pages/man2/pidfd_send_signal.2.html)。

87项回归测试通过，包括真实测试子进程的暂停/恢复/退出、句柄关闭和权限错误
传播。15:36前宿主机精确目标的只读pidfd打开及信号0检查通过：控制器4143988
和setup4144059身份、父子关系正确，未发送暂停或终止信号。
r4科学代码292个固定文件仍不变；兼容改动仅涉及新部署层。

使用独立r6授权，显式固定r5的这次“操作前初始化失败”记录；这不是科学训练
失败后的自动重跑。r4仍在原参考批次4/10，后续接管仍只保留原有限Stage B规模。

### systemd运行时属性限制与 r7 阶段边界接管

r6于15:37:40启动；pidfd身份检查通过，但宿主systemd拒绝通过set-property
热修改旧服务RuntimeMaxUSec。接管在发送SIGSTOP之前退出：旧调度器及setup
仍原样运行，旧RuntimeMax未变，未产生新科学病例。r6全部失败产物保留。

据此移除旧服务的无效热修改步骤。改为核验**新服务自己的MainPID及无限时限**，
然后只暂停旧调度器；旧服务/旧setup保留原计时直到这段准备工作自然完成后退役。
新Stage B不在旧服务中运行，既不继承旧截止，也不经过旧预测预算门禁。
这项过渡限制已明确写入更新的时间解除协议，不能误报旧setup的计时器已被热改。

修订后的87项回归全部通过（11.265秒），启动脚本及空白检查通过。
准备独立r7，明确固定r6这次操作前部署失败及其原源码快照；不重启r5/r6服务，
不改动r4的292个固定科学文件，不改变四臂训练数量、数据顺序或安全检查。

### r7 实际激活与资源核验

服务 `hkbz-stage2-split-v5-20260909-gpu0-half-r7.service` 于
**2026-09-09 15:44:49 CST** 启动。实际使用已固定的r7授权：

```bash
env UNIT_NAME=hkbz-stage2-split-v5-20260909-gpu0-half-r7 bash onpolicy/scripts/train/launch_stage2_resource_rl_v5_unlimited_gpu0.sh result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r7/authorization.json
```

15:46现场确认：r7控制器51798为active/running，RuntimeMaxUSec=infinity，
AllowedCPUs和CPUAffinity均为 `0-31,64-95`，Restart=no。
`checks/active_handoff.json`证明旧调度器4143988已暂停（进程状态Tsl），
原setup4144059仍运行（Rl），未重启，父子关系及开始时间未变。
GPU0 UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf` 上仍为原setup进程。

新活动入口为r7的`run_status.json`，阶段`waiting_for_retained_setup`；
hard_deadline_unix=null，wall_clock_limit_enabled=false，projected_time_gate_enabled=false。
旧r4根状态在调度器暂停后不再更新，不应再用它的更新时间判断采样卡住；
r7状态中的live_setup及r4的workers/setup/run_status.json仍持续更新。

这时参考采集第6/10批仍在推进，正式训练尚未开始。旧准备进程及其旧服务
保留原时钟直到准备自然结束，随后退役；**不是声称热改了该旧计时器**。
后续Stage B由无墙钟限制的新服务执行，不继承2026-09-10 18:18:20旧截止，
也不再因预测总时间超过剩余授权而拒绝启动；其他完整性和安全门禁仍必须通过。
已完成病例和所有旧部署失败产物保留，未增加任何科学采样或训练次数。

### Stage B 接管完成及四组并发授权（17:02 前）

r7 已于 16:09 左右完成 setup 边界接管并启动 E0/E1（PID 54889/54890）；
540 个 setup 病例全部完成。用户随后明确要求“E2/E3现在可以一起启动”。

新增独立四组并发调度适配器、启动脚本、12 项测试和
`STAGE2_SPLIT_ENCODER_V5_FOUR_ARM_20260909.md`；原 299 个固定源码不修改，
原 r7 科学 manifest 和产物不覆盖。新的 r8 只记录调度授权、接管与实时状态，
科学产物仍统一写回 r7。E0/E1 保留当前进程，E2/E3 将使用相同原 worker 首次启动。

首次宿主检查 GPU0 空闲 37788 MiB，现有两组占用约 10.5 GiB；主机
MemAvailable 约 105 GiB。四组工程 reserved 峰值合计约 25 GiB。
执行前仍重新检查显存及主机余量，不能把历史峰值当作未来峰值保证。
GPU0 瞬时利用率 97%，因此提前并发不承诺吞吐翻倍。

99 项 CPU 回归全部通过（11.593 秒），包括科学范围、进程保留、
日志独占防重复、故障安全边界及既有 V5/V4/pidfd 检查。
此处记录的是准备通过，实际启动以 r8 的 checks/activated.json 为准。

### 17:07 四组并发部署尚未激活：宿主授权审核超时

初次宿主执行请求及工具允许的唯一一次重试均返回自动权限审核超时。
两次命令均未执行，不是训练进程崩溃，也没有发生科学训练重试。
17:07:08 核验：r8 只有授权、行政源码归档及接管前状态，没有 started.json、
active_handoff 或 activated 记录；r7 logs 中只有 train_E0.log 和 train_E1.log。

因此不得报告 E2/E3 已启动。r7 调度器 51798 未暂停，E0 54889 和 E1 54890
保持原进程并持续更新，均处于第 2 轮；全部产物保留，原串行队列仍有效。
已记录 `r8/activation_status_20260909T170708.json`。
后续重新获得宿主机执行授权后可以直接复用已固定的 r8 请求；启动前会再次
检查状态、显存、主机内存和是否已有 E2/E3 产物，不会无条件重跑。

### 17:20 用户确认授权后仍被宿主执行审核超时阻塞

用户明确回复“确认授权”后，复用既有 r8 授权和全部固定代码再次提交宿主执行。
初次请求和唯一一次允许重试仍都因平台自动权限审核超时而未执行。
这不是缺少用户确认，也不是训练超时；不应继续通过重复口头确认暗示问题已解决。

17:20:24 核验：r8 仍无 started.json、active_handoff 或 activated 记录；
r7 仍只有 E0/E1 日志。调度器 51798 没有被本次接管暂停；E0 54889 在第 3 轮
采集，E1 54890 在第 2 轮更新，日志持续推进。全部旧产物保留，没有科学重试。
新增带时间戳观测 `r8/activation_status_20260909T172024.json`，没有修改旧观测、
授权文件或任何固定源码。已向用户提供可在宿主终端直接运行的同一启动命令；
启动器自身仍会重新预检资源和精确进程身份，并拒绝重复启动。
