## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run / user-authorized implementation
- Origin Date: 2026-09-08
- Verification Status: UNVERIFIED（工程测试和运行状态另存；优化效果待实验）
- Version Label: stage2_bc_resource_rl_v4

# Stage2 V4：完整案例 minibatch + 两种回报基线

用户授权按上一轮研究计划修改并启动，随后补充“数据量对齐之前的stage2”。
此版本取代下一轮 train96/tune12 的小样本安排，不改写旧实验 manifest、源码归档、权重或结果。
旧 v3 和停止的 r5 保留；后续 BC 对照、多种子、扩大训练、独立 IGA 和 Stage3 均不自动启动。

## 数据与预算修订

精确复用 `stage2_bc_injection_20260905_gpu0_half_pilot_r2/manifest.json` 中 seed11 的
sampling audit 案例清单和顺序：源 train600，实际 train240（IID120 / stress108 / scale12）。
每组两轮完整覆盖；每轮 10 次采集，每次 24 个完整案例。因此各 480 case-episodes，
两组共 960。评测完整 tune60，固定 12 workers 分批执行。训练与评测按内容哈希去重。
采集批次也复用旧 vector-env 的访问次序：240 例连续分成 24 个 worker shard，每次各取下一例，
而非误把清单中连续的 24 例当成旧训练的一批。
这既不是 600 个案例全训，也不是近期仅 24 例的 RL pilot。

每次采集做 2 遍完整轨迹重放，每个 minibatch 为 6 个案例，每批最多 8 次 actor 更新，
各组最多 160 次。第 10 批只监控，第 20 批为唯一预定主候选；不事后选中间最佳检查点。
B0-H 在 train240 各运行一次，同时提供 Cmax 基线和小型价值头的冻结图特征。

完整 main evaluations：B0-H/B0-AR 各 60，两个组第 10/20 批各 60，末次两个组 H 副评测各 60，
共 480。另有旧 BC/PPO 权重 H 副评测各 12 和旧 PPO 的 4 例动作轨迹，最多 28 次。
全套上限为 240 + 960 + 480 + 28 = 1708 case-episodes；工程 smoke 另记，不计科学结果。
总墙钟硬上限 24 小时，零更新/解码检查最多 2 小时；不含代码开发与独立工程测试。
这是随用户数据规模修订后的投入上限，不是已测得 ETA，也不允许超时后自动续跑。

## 两组方法与固定边界

- `S2RL_PPO_R`：从固定 B0 初始化，以同案例冻结 B0-H 的完整 Cmax 作基线，
  `raw_A = (Cmax_B0_H - Cmax_student)/10000`，每个有效资源联合事件共用该案例 MC 优势。
  不依赖 critic，不冒称逐动作精确信用分配；没有反事实成本标签。
- `S2RL_PPO_V`：同一起点，以 `G_t = -(Cmax-t)/10000` 减去本批拟合前的价值快照形成优势。
  初始价值头使用 B0 固定轨迹预热，最多 200 步/300 秒（先到者停止），按案例留出 25% 验证。
  每轮优势固定后，价值头最多再拟合 50 步/60 秒，结果只用于下一轮。

两组交替完成一个采集/更新批次，GPU0 同时只有一个活跃训练/评测工作单元。
actor LR=3e-5，critic LR=1e-4，clip=0.1，PPO passes=2，entropy=0.001，
B0 条件 KL 系数=0.01，old-policy sampled KL 上限=0.01，gamma=1，缩放10000。
不改环境物理/Blocking/last-chance/no-op/规划合同，不解冻 plane/shared/R1，不重训预测头。
飞机始终确定性；资源训练 AR 采样、主评测 AR argmax。H 仅为独立副评测，不能充当 PPO 概率。

## 正确性与可追溯性

每个 minibatch 在当前参数下从零重放完整案例，16 事件只截断梯度，不在案例中途 step。
采样/条件 reference/重放使用相同的固定 6 案例成员与行顺序，仅打乱 minibatch 执行顺序。
这是首次 GPU 工程检查发现拆批 GEMM 浮点差异后采取的数值合同修正，不放宽 1e-6 阈值。
AR 评测沿用相同 6 案例计算单元；Hungarian 保留原 12 worker 评测计算形状。
采样比例修正保持整批事件损失聚合，不按每案例自己的事件数倒数重新加权。
优势每次采集仅归一化一次；初始化/rollout/shuffle RNG 独立；两个组首批的动作哈希和终局结果必须相同。
每批更新前对每个案例 shard 的前 64 事件做概率检查，logp 最大差<=1e-6、ratio 差<=1e-5。
每个 minibatch 记录 pre-update KL；每批后使用当前权重完整重放测 post-update KL。
post-KL 超限保存并暂停该组，不回滚、不重试、不用步数配额突破 KL 上限。
任意工程/概率/冻结/完整性错误停止实验并保留已完成与中断检查点，不丢弃坏案例继续选模。

冻结 encoder 缓存维持原 dtype，单批缓存上限 8 GiB。超限清除本批缓存，使用未缓存计算，
记录性能回退；不改输入、不降精度。缓存与未缓存、batch 拆分的等价性需由工程测试验证。
指定 4 个 tune 案例保留可观察动作轨迹：0001、0021、0054、0058。
记录固定图 operation/site/plane/type 语义 ID，不只记录瞬时 request index，不读取未来事实。

## 验收与停止

平均 Cmax 相对 B0-AR 和 B0-H 均至少改善 0.5%；分组均值和尾部不退化；零失败；
任一案例相对 B0-H 退化大于 1% 不扩大投入。这只是开发筛选，并未放宽 IGA180 逐例零退化目标。
分别记录 `maximum_cmax_delta` 和 `maximum_paired_delta`，不能用两模型各自最大值之差替代逐案例退化。
历史 IGA180/1800 同案例结果只作差距参考，计时尚未正式认证；tune60 不作为独立确认。
静态交接检查标记 PPO-R 的价值头未训练，后续 Stage3 须重建 critic，不继承优化器/归一化。
静态加载兼容、训练完成、开发筛选、IGA 达标、Stage3 动态收益分别记录，不能混为一谈。

## 资源与入口

物理 GPU0（UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`），CPU `0-31,64-95`。
训练 `0-23,64-87`，评测 `24-29,88-93`，监控 `30-31,94-95`；总进程树受 cgroup 半区约束。
GPU1 及其 CPU `32-63,96-127` 保持不动。每 30 秒更新状态，systemd 硬超时与进程存活监控，Restart=no。

入口为 `onpolicy/scripts/train/launch_stage2_resource_rl_v4_gpu0.sh`，
必须提供 `ENGINEERING_REPORT` 指向两组通过的 GPU 工程报告；准备器校验报告绑定的源码未改变。
生成独立 manifest/source archive，禁止复用运行目录。实际验证、PID、阶段和耗时以运行目录产物为准。
