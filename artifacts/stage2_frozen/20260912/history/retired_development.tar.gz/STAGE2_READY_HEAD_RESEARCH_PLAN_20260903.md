# Stage2 就绪时间预测头专项研究计划（2026-09-03）

## 1. 研究判断

上一轮最佳 Stage2 方法 A3 将 Valid60 Cmax 从 8839.19 降至 8340.61，说明移动设备策略 BC 本身能够学习；但其预测头仍有约 506.59 秒的在线平均绝对误差，欠预测率为 56.38%，且 A2/A3/A4 的预测指标几乎相同。

这不能直接归因为预测目标不可学，因为上一轮有三个明显混杂：

1. A3 总损失 0.728318 中，assignment 约占 90.8%，margin 约占 6.2%，ready regression 仅约占 3.0%。
2. 所有目标共享一次 `max_grad_norm=1` 的全局裁剪；平均裁剪前梯度范数约 8.58，预测头梯度会被策略损失一并缩小。
3. 旧日志按 update 等权平均 MAE。不同 update 的标签数不同，blocking 等稀疏分层还会被“无该类标签的 update=0”稀释，不能用于可靠选型。

因此，本轮不改进资源策略头，也不评价 Cmax 改善；只回答以下问题：

> 在固定表示、固定行为轨迹和精确 IGA 标签下，现有预测头是否能够稳定学习 `intrinsic_ready_time`，什么优化率、误差域和 H2 权重最有效？

## 2. 不变量与可变量

所有实验共同固定：

- Stage1 飞机 checkpoint、训练样本、IGA-1800 teacher、随机种子均相同；
- 使用 240 个分布平衡样本：IID 120、OOD-stress 108、OOD-scale 12；
- 每个 epoch 恰好 10 个 rollout × 24 个环境，即完整重放相同的 240 个案例；
- 共 3 个 epoch，用相同数据观察真实学习曲线；
- `request_ready_policy_injection=none`，预测不会改变动作或后续状态；
- 冻结共享 GNN、飞机 actor、普通设备 actor、R014 actor、critic 和 `request_ready_feature`；
- optimizer 只持有 `request_ready_head` 参数；
- 不执行策略 categorical/ranking/timing/assignment/margin loss，不执行 PPO；
- `max_graphs_per_forward=1000`。

唯一可变量是预测头学习率、秒域辅助损失与 H2 标签权重。

## 3. Wave 1：六组因果对照

| 方法 | 学习率 | 秒域损失系数 | H2 权重 | 目的 |
|---|---:|---:|---:|---|
| P0 | 3e-5 | 0 | 1 | 重现旧 log-Huber，但去掉策略损失干扰 |
| P1 | 3e-4 | 0 | 1 | 检查小预测头是否只是学习率过低 |
| P2 | 1e-3 | 0 | 1 | 学习率上界/稳定性探针 |
| P3 | 3e-4 | 0.10 | 1 | log-Huber 加直接秒误差校准 |
| P4 | 3e-4 | 0 | 3 | 强化上一轮误差最大的 H2 长前视标签 |
| P5 | 3e-4 | 0.10 | 3 | 同时验证秒域校准和 H2 加权是否互补 |

基础预测损失仍为 `log1p(t/3600)` 空间的 Smooth-L1。秒域辅助项是在 `(prediction-target)/600` 上计算 Smooth-L1。所有组保留欠预测权重 2 和 blocking 权重 2，避免仅靠系统性提前预测降低 MAE。

## 4. 统计与选择规则

每个 update 输出可加的充分统计量，并在 epoch 末按真实标签数汇总，而不是平均 update 均值。对 all、H1、H2、blocking、departure、other 分别记录：

- 标签数；
- MAE、RMSE、signed bias；
- 欠预测率；
- 绝对误差落在 60/120/300 秒内的比例；
- log-domain loss、seconds-domain loss、裁剪前梯度范数；
- epoch 运行时间。

Wave 1 的统一主分数为：

`0.60 × H2_MAE + 0.30 × H1_MAE + 0.10 × departure_MAE`

该分数只用于跨实验比较，不等于各实验自己的训练目标。选择方法必须同时满足：

1. epoch 2/3 相比 epoch 1 明显下降，而非单批随机波动；
2. H2 改善不能以 H1 或 departure 明显退化换取；
3. 欠预测率向 50% 或更低移动，signed bias 不出现严重单边偏置；
4. P2 若出现 loss/梯度发散则判定 1e-3 越过稳定上限；
5. 共享 encoder、飞机策略和两个资源策略的训练前后哈希必须完全相同；只有 `request_ready_head` 哈希允许改变。

预测输出未注入策略，因此本轮不重复跑六份等价的 Cmax validation。这样既避免把“Cmax 不变”误解为预测失败，也把 CPU/GPU 预算全部用于标签学习。

## 5. Wave 2 与后续边界

Wave 1 完成后才执行以下步骤，不在本轮训练中偷换问题：

1. 取主分数最好的两组，在未参与训练的 gate120 精确标签上做只读重放；
2. 若 held-out H2 MAE、欠预测率和 300 秒命中率同步改善，确定预测器版本；
3. 固定该预测器，再单独设计 `learned_feature` 注入与资源策略蒸馏实验；
4. 只有注入阶段才重新评价 Cmax、late-dispatch 和资源等待时间。

如果训练集指标不降，优先检查标签/特征可辨识性与头容量；如果训练集显著下降而 gate120 不降，优先处理过拟合和数据覆盖；如果预测 held-out 改善但后续 Cmax 不改善，问题才定位到策略使用预测信息的方式，而不是继续盲目训练预测头。

## 6. 资源与复现设置

- GPU0：P0/P1/P2；GPU1：P3/P4/P5；每卡三个进程；
- 每进程 12 个完整物理核（24 个 SMT 逻辑 CPU），六组覆盖全机 72 个物理核/144 个逻辑 CPU；
- 同卡三组的物理核和逻辑 CPU 均不重叠；GPU0 绑定 NUMA0，GPU1 绑定 NUMA1；
- 每进程 CUDA memory fraction 为 0.30，理论上限约 24 GiB，三进程总上限约 72 GiB/卡；
- 以 systemd cgroup 的 `AllowedCPUs`/`CPUAffinity` 约束完整进程树，并将 BLAS/OpenMP 线程数设为 1；
- 启动脚本生成不可变 manifest、每 lane 的实际命令记录、独立服务日志和每 epoch JSONL 指标。

统一入口：

`onpolicy/scripts/train/launch_stage2_ready_head_wave1_dual_gpu.sh`
