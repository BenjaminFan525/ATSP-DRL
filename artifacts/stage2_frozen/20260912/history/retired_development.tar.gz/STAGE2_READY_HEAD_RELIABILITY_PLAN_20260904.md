# Stage2 就绪时间预测头可靠性 Wave 1（2026-09-04）

## 研究目标

本轮只训练 `intrinsic_ready_time` 预测头，不训练移动设备策略头，也不运行
PPO。目标是先证明预测器能在按案例隔离的留出集上可靠泛化，再讨论把预测结果注入
资源策略。

上一轮剥离 Blocking 后，最佳非 Blocking MAE 仍约 541 秒；同时，旧指标来自训练
轨迹本身，不能区分拟合能力和泛化能力。本轮因此同时解决三个混杂：

1. `blocking_wait` 的真实 lead time 恒为 0，改为确定性路由，并从神经损失中剔除；
2. 使用案例路径 basename 的 SHA256 固定五折，fold 0 只用于冻结权重后的留出评测；
3. 除标签加权指标外，增加案例等权、迟到方向和分位数校准指标。

## 固定合同

- 固定同一 Stage1 checkpoint、同一 IGA-1800 teacher、seed 1；
- 使用 240 个分布平衡案例：IID/OOD-stress/OOD-scale = 120/108/12；
- 三个训练 epoch，每个 epoch 10 × 24 个环境；随后增加一次无反向传播的留出 pass；
- `request_ready_policy_injection=none`，预测值不改变动作、轨迹或 Cmax；
- 冻结共享 encoder、飞机策略、普通设备策略、R014 策略、critic 和 timing feature；
- 唯一可训练参数是 `request_ready_head`；所有策略 BC loss 和 PPO 均为 0；
- `max_graphs_per_forward=1000`。

## 五组对照

| 方法 | 核心变化 | 要回答的问题 |
|---|---|---|
| R0 | 旧 shared point head，log-Huber，LR=1e-3 | 剥离 Blocking 后的强学习率对照 |
| R1 | LR=3e-4，秒域系数 0.1，取消欠预测双倍权重 | 对称损失能否消除系统性偏置 |
| R2 | R1 + request kind/depth/前驱统计显式上下文 | 冻结 GNN 表示是否缺少可辨识信息 |
| R3 | R2 + H1/H2/Departure 分头、按 kind 平衡 loss | 长短时域是否存在负迁移/频数支配 |
| R4 | R3 + 有序 q20/q50/q80 pinball loss | 单点不可辨识部分能否用不确定性表达 |

所有组都对 Blocking 做严格零值路由并从回归损失中排除。R1–R4 的欠预测和过预测
训练权重均为 1；迟到风险不再靠扭曲中位数处理，而由 R4 的 q80 显式提供。

## 评测与选择

主指标只使用 fold 0 的冻结留出 pass：

`0.60 × H2_MAE + 0.30 × H1_MAE + 0.10 × Departure_MAE`

同时报告：

- 非 Blocking label-weighted MAE/RMSE/bias；
- 预测晚于真实值 60/120/300/600 秒的比例，以及条件迟到 MAE；
- 60/120/300/600 秒命中率；
- case-macro MAE/RMSE/bias/300 秒命中率；
- R4 的 q20/q50/q80 覆盖率和 q20–q80 区间宽度；
- 三个训练 epoch 的训练曲线，但训练指标不参与最终方法选择；
- Blocking 必须逐标签精确为 0，冻结参数哈希必须保持不变。

本轮不会因为 frozen-policy Cmax 不变而误判失败，也不会把最优预测器自动注入策略。
只有留出指标确认改善后，下一轮才单独比较 q50/q80/动态风险阈值的策略注入方式。

## 资源调度

五组均运行在 GPU0；每组 CUDA allocator 上限为显存的 19%，总上限 95%。72 个
物理核按完整 SMT sibling 对静态分为 15/15/14/14/14 核，逻辑 CPU 无交集并覆盖
0–143。每个实验使用 24 个 rollout worker，剩余线程预算服务于主进程、教师重放和
图批处理。启动错开 12 秒，避免五组同时扫描 teacher 和构图。

