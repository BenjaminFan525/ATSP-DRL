# Stage2 E0–E3 独立编码器协议 V5

Material Passport: Origin Skill = academic-research-suite/experiment-agent;
Origin Mode = run; Origin Date = 2026-09-09; Verification Status = UNVERIFIED;
Version Label = split_encoder_v5. 工程复验不等于科学效果验证。

## 目标与授权范围

最终目标不变：完全超越 IGA180（逐例无退步、均值严格更好），达到或超越
IGA1800 的均值、分组和尾部。历史 IGA 只作诊断，不宣称公平预算认证。
此次只授权 Stage A 工程验证与 Stage B 四臂第一轮 train240；不自动执行
Stage C、更多种子、IGA 搜索、成本标签、BC、Stage3 或失败重试。

## 结构与训练

| 臂 | 资源 actor | critic |
| --- | --- | --- |
| E0 | 原冻结编码器 | 原冻结编码器 |
| E1 | 独立可训练 E_resource | 原冻结编码器 |
| E2 | 原冻结编码器 | 独立可训练 E_value |
| E3 | 独立可训练 E_resource | 独立可训练 E_value |

新编码器深拷贝同一个不可变 B0 原编码器，不随机初始化。原编码器（E_plane）、
飞机策略和 Ready/R1 永远冻结。Ready 注入仍为 none。普通资源与 R014 共用
E_resource，保留各自 GRU/head。B0 KL 参考只有原冻结编码器及自己的历史。
E_resource 只收 actor 梯度，E_value 只收 critic 梯度。优化器不共享参数或状态。

全部 PPO-V：actor/GRU LR 3e-5，E_resource LR 3e-6，critic MLP LR 1e-4，
E_value LR 1e-5；clip .1，passes 2，entropy .001，B0 reference KL .01，
旧策略 KL 暂停阈值 .01；gamma 1，MC 剩余时间目标 /10000；无 GAE/新奖励。
24 个完整 case/collection，固定 6-case 成员和行顺序，打乱组执行次序；
TBPTT16，每组从零隐藏状态在当前参数下重放，case 中途不 optimizer.step。
FP32、logp 1e-6/ratio 1e-5 等原概率守卫不放宽。

四臂采用统一 critic 逻辑 batch48，图 microbatch6，累积8次后 step；
先独立 B0 train240 轨迹预热最多200步，每轮50步。均匀抽 case，再均匀抽轨迹位置，
不让长 case 占据价值训练。原始图参考池每例均匀 reservoir 最多32状态，
只含可观测输入和该完整轨迹 MC 目标，不生成成本标签。初始预热按 case hash
固定留出25%，之后不称其为独立策略评估。当前 rollout 的价值和优势先快照，
本轮所有 actor 更新结束后才拟合本轮价值目标。

只缓存原始不可变图/掩码/元数据和 E_plane 输出；不跨更新缓存新编码器输出，
不缓存 GRU 隐状态。新编码器启用无随机 dropout 的非重入激活检查点。
模型只作 opt-in 扩展，旧 V3/V4 默认前向和严格 handoff 校验保持原样。

## 指标与门禁

当前环境指标保存于 runtime_metrics，旧基线于 baseline_metrics，算术比较于
comparison_metrics。未采集字段缺失，不从历史行继承。case hash 必须一致。

工程：每臂24-case完整 collect/update，全部丢弃测试更新；梯度归属、零更新、
缓存、原飞机条件行为、Adam/权重恢复通过后才能进入科学训练。初始每臂全量
AR tune60 与 B0 同条件动作/logp/隐藏状态一致；E0 与历史 B0 AR Cmax/steps
严格复验，另 B0 Hungarian tune60 严格复验。

Stage B：每臂10轮×24=240病例，至多80 actor step，200+500 critic step；
AR round5/10，Hungarian round10。round10 为预先规定主终点，round5 仅监测。
筛选需同时相对 B0 AR/H 平均增益≥0.5%、分组和尾部不退化、相对 B0 H
最大逐例回退≤1%、零失败，并优于同协议 E0。1% 是希望达到的幅度，不是承诺。
不因 E0 退化而只相对 E0 宣称成功；不根据 round5 临时改主终点。

## 资源与预算

GPU0 UUID GPU-744c1334-98c8-5318-e799-7ad15eea1fbf；CPU 0-31,64-95。
最多2训练进程，槽0为0-11,64-75，槽1为12-23,76-87；评估串行使用
24-29,88-93；监控30-31,94-95。GPU1及另一半CPU不变。
工程双槽基准必须通过显存/吞吐门禁；不为塞进预算静默缩减病例、更新或评估。

首批总2316 case episodes：工程96，初始评估300，B0参考240，训练960，
AR训练评估480，H最终评估240。硬墙钟24小时从工程进程启动开始（开发不计）。
基准和初始评估/参考采集提供实测速度；估计无法在剩余预算完成则不启动训练，
写出 budget_gate 拦截报告等待用户选择。无自动追加时间或第二轮。

checkpoint 保存完整编码器 role map、初始/当前 hash、冻结证据、参数白名单、
独立 Adam/RNG 和案例计数；恢复需显式新 manifest，不覆盖旧产物。
Stage3 必须用新版本 split handoff 保持结构，重新初始化价值网络和所有优化器；
本批完成也不自动授权 Stage3。
