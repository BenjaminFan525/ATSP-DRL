## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run + deterministic engineering validation
- Origin Date: 2026-09-06
- Verification Status: VERIFIED for deterministic engineering equivalence; pilot/scientific efficacy UNVERIFIED
- Version Label: stage2_wait_acceleration_v1

## Scope and authority

User requested acceleration of the current M2/M3 experiment. GPU0 only;
CPU 0-31,64-95 only. M0/M1 and unrelated GPU1 workloads are not stopped.
Old M2/M3 continues until an exact, faster acceleration canary passes.
No files/checkpoints/evidence from an existing experiment are overwritten.

## Implementation

Isolated source: `result/hkbz_train_logs/stage2_wait_accel_20260906_gpu0_half/code`.
Derived from the 228-file source archive of
`stage2_verified_wait_20260906_gpu0_half_pilot_r1`, archive SHA256
`3f903eb5fdd0bd86fd86b6995e4ef0b363c3c83bad579b0dda8439b93e05f83e`.

1. Persistent process pool: 16 private frozen-S1 CPU policies, one thread each;
   cores 8-23 with SMT sibling affinity 72-87. Shares the permitted half with
   trainers; no new CPU allocation and no GPU counterfactual continuation.
2. Candidate prefetch: same full heterogeneous GPU environment batch, exact
   plane actions and post-forward GRU; 100% teacher execution, frozen encoder
   and Ready head. No optimizer update during prefetch. Restore parent RNG and
   replay the identical case cursor; resource RNN and all BC updates still run
   in the original chronological loop.
3. Exact per-vector-step trace checks bind plane actions/GRU, resource teacher
   actions, active masks, policy history and case IDs. Missing prefetched
   candidate or any replay mismatch fails closed before that BC update.
4. Independent wait/dispatch branches run concurrently and are reassembled in
   the original order. The entire serial CounterfactualWaitVerifier class is
   unchanged (AST equality regression). Maximum 256 pending candidates; no
   candidate dropping. Source-bound shared cache retained across arms/epochs.
5. New source creates a new cache namespace. Old evidence is not silently
   migrated or relabeled.

## Unchanged scientific contract

`paired_completed_cmax_empty_group_wait_v1`; all feasible dispatch alternatives
must complete, waiting >= 1 second and Cmax gain >= 1 second against every
alternative. Same 2000-step / 180-second per-branch limits, six probes per case,
10-step spacing, teacher projection, fixed source/seed/case order, coefficients,
24-worker pilot, two epochs, 240 cases, and strict pre-gradient tune60 replay.
No RL/DAgger/Stage3 expansion or scientific-success claim.

## Verification gate

195 regression tests passed in 15.354 seconds on the final pinned source, including seven acceleration
tests for resource bounds, snapshot fidelity, branch order, deduplication,
capacity fail-closed behavior, missing candidates, exact trace mismatch and
unchanged serial continuation.

Before replacement, a two-arm / two-epoch canary must match the completed serial
canary in all positive AND negative evidence (excluding wall time/provenance),
every model and Adam tensor, all non-runtime training metrics, and all case Cmax
values at epochs 0/1/2. Actual epoch-1 elapsed time including prefetch must be
lower for both arms. Timing is host-load sensitive and not a pilot guarantee.

Serial reference:
`result/hkbz_train_logs/stage2_verified_wait_20260906_gpu0_half_canary_r1`, manifest
SHA256 `68dbc14905fe685953e5fbd9ac0e5cfdddcc26dc1481bf4428bec8f7b6803841`.

## Runtime

Acceleration canary r2 started as
`hkbz-stage2-wait-accel-20260906-gpu0-half-canary-r2.service`.
233 pinned source files; manifest SHA256
`8b5d36b151ea304002c1f6ef75268100c13b623f0b9975259555f1ce8337505c`, archive
SHA256 `95e27b1bdbaba3c78e7a117039f297e31ad1818d69ee1968571a8e251ab2f570`;
counterfactual config file SHA256
`5055ef0a0696a22e63a41f16256240d521d864e23ac2bfb0157a443dd410e39d`.

The r1 directory is an unstarted dry-run manifest, retained for provenance.
A unit fixture initially omitted the new required acceleration-proof fields;
the test was extended to require both exact equivalence and measured speedup,
including explicit negative tests. No gate was relaxed. The focused 41-test
suite then passed in 1.046 seconds. No crashed experiment was retried.

M0/M1 completed normally before the accelerated canary started; not stopped.
Old M2/M3 remains running pending the explicit safe service replacement.
At 18:19 CST, all 12 first-epoch evidence rows per arm matched the serial
canary exactly, including five positive and seven negative verdicts, real GPU
state fingerprints, all 26 branch outcomes, waiting duration, and Cmax.
The 562-step prefetch took 80.255 s (M2) and 99.360 s (M3); it performed no
optimizer updates. Full checkpoint/evaluation comparison remains pending.
Host `/proc` inspection confirmed 16 pool workers each pinned to one of the
physical cores 8-23 and its SMT sibling, within the declared CPU half.
First-epoch elapsed time (including prefetch): serial M2 639.3577297031879 s,
accelerated M2 174.86941315233707 s; serial M3 645.3838258893229 s,
accelerated M3 193.40589168109 s. Both first-epoch non-runtime metric payloads
are exact matches. At 18:24 CST, the M2 epoch-1 model and Adam tensors also
passed exact comparison; full two-epoch/two-arm proof is still pending.
Old pilot first rollout: M2 4956.702 s, M3 4959.804 s (about 83 minutes each).
These are observed times, not a remaining-time estimate.

## Final canary gate and pilot handoff

The canary completed normally (service inactive/dead, exit status 0). Final
`analysis/comparison.json` SHA256:
`5e61b59a1494e564b7c14efe746df15d74b76e8cd8b9ad698c0f388129fb7735`.
The report records `acceleration_equivalence.passed=true` and
`measured_faster=true`:

- Both arms: exact model and Adam tensors at epochs 0, 1, 2.
- Both arms: exact four-case Cmax at epochs 0, 1, 2.
- Both arms: exact 24 evidence rows (48 total), including all positive and
  negative branches, excluding only runtime/provenance fields.
- Both arms: exact 239 non-runtime training metric fields for each epoch.
- Observed epoch-1 speedup: M2 3.6562x, M3 3.3369x. Concurrent host load differs;
  these are matched-canary observations, not a guaranteed pilot speedup.

Before stopping the old pilot, the new 240-case manifest passed all code,
source, checkpoint, canary-proof and physical GPU/CPU sharing checks. The old
manifest and pre-stop status were copied into
`result/hkbz_train_logs/stage2_wait_accel_20260906_gpu0_half/handoff`.
Its original 228 pinned source files and the accelerated 233 files were
independently rehashed unchanged.

At 18:33 CST, only
`hkbz-stage2-verified-wait-20260906-gpu0-half-pilot-r1.service` was stopped for
the user-requested verified acceleration handoff. It became inactive/dead,
MainPID 0, Result success; GPU0 had no remaining old compute processes.
GPU1 PIDs 2730780 and 2731764 remained present and were not touched. All old
checkpoints/logs/cache files remain in their original directories. This is
a fresh B0 fork, NOT an exact mid-epoch checkpoint resume.

Accelerated pilot launched:
`hkbz-stage2-wait-accel-20260906-gpu0-half-pilot-r1.service`, suite
`result/hkbz_train_logs/stage2_wait_accel_20260906_gpu0_half_pilot_r1`.
Manifest SHA256 `021a88a46a2158552608818c1ae96bb43af890622ebaedd580ed299ed3ad58bd`;
source archive SHA256
`f2ca624de3c5322ec064767b7456ae06dc7411d39389d7443604e8626967eb32`.
Same counterfactual config and exact code as the passed canary; fixed 240-case
order, 24 environments per arm, 10 rollouts/epoch, two epochs, no PPO. Before BC
updates, the original strict 60-case warm-start replay remains mandatory.

At 18:35 CST the accelerated pilot was verified active/running:
controller PID 2776776, M2 PID 2776875 (CPU 0-7,64-71), M3 PID 2776876
(CPU 8-15,72-79), shared evaluator PID 2776836 (12 workers, CPU 24-29,88-93),
and CPU-only wait service PID 2776831 (CPU 8-23,72-87; configured 16 workers).
The suite started at approximately 18:34:19 CST; both trainers started at
18:34:25 CST. Both restored the exact B0 weights with a fresh optimizer/RNG.
GPU telemetry placed the evaluator and both trainers on GPU0 UUID
`GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`; GPU1's preexisting processes were
unchanged. Systemd AllowedCPUs and CPUAffinity both equal 0-31,64-95.
The current phase is `pre_supervised` strict tune60 replay, not yet BC updates.
The controller retains 30-second liveness/resource monitoring and the declared
48-hour hard timeout; the label service emits 15-second heartbeats. Pilot
speedup and scientific training quality are not yet measured.
