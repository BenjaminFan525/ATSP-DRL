## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: validate + run
- Origin Date: 2026-09-05, Asia/Shanghai
- Verification Status: VERIFIED for the fixed local strict12 evaluation;
  ANALYZED / PARTIALLY_REPRODUCIBLE for cross-environment historical replay
- Version Label: stage2_a3_replay_diagnosis_v1

## Question and safety boundary

User request: diagnose the A3 replay discrepancy before starting the new
frozen-R1 BC pilot. No gate/finalblind access, no formal-nine-job launch,
no modification of historical evaluation files or failed-run manifests.
Only GPU0 and CPU 0-31,64-95 are authorized. GPU1 and its CPU half are untouched.

The first pilot controller stopped on 2026-09-05 at 16:00:51 CST, after
14m37s. It started **zero trainers**. Its retained suite is
`result/hkbz_train_logs/stage2_bc_injection_20260905_gpu0_half_pilot_r1`.

## Observed discrepancy

Historical A3 mean Cmax: 8340.605556 seconds. New strict-12 replay:
8362.016667 seconds, a +21.411111-second (+0.256709%) difference.
All 60 cases completed, without cycle termination or timeout. 44 case Cmax
values matched within 1e-5 seconds; 16 differed, maximum absolute difference
386 seconds. A small aggregate difference does not establish equivalence.

| Distribution | Cases | Different Cmax | Mean new-minus-old, seconds |
|---|---:|---:|---:|
| IID | 30 | 8 | +24.866667 |
| OOD stress | 27 | 7 | +24.061728 |
| OOD scale | 3 | 1 | -37.000000 |

## Source, data, and configuration audit

- A3 checkpoint SHA and historical evaluation-file SHA match the failed
  manifest. The shared evaluator also verifies a model-tensor digest.
- Recomputed the generator's **canonical-JSON** SHA256 for all 300 input
  files and all 60 cases: 300/300 and 60/60 match. These fingerprints are
  intentionally not hashes of pretty-printed JSON bytes.
- Compared the migration snapshot
  `migration/bundles/HKBZ_4090_migration_20260903_0020/archives/02-hkbz-code.tar.zst`
  against current source. GNN, pointer/matching decoder, GRU, actor config,
  and resource environment YAML are byte-identical.
- Environment changes are confined to additional ready-kind/context
  observation metadata. Environment transitions, scheduling feasibility,
  legal action masks and step semantics are unchanged in that comparison.
- `_eval_with_envs`, `_authoritative_policy_history`, and
  `_finalize_evaluation` are AST-identical to the archived implementations.
- Ready-head additions preserve the old shared/no-context/no-quantile path;
  the service log confirms all four A3 routing flags were reconstructed,
  including `hard_blocking=False`. A3 uses injection `none`.
- After relocating the old command paths before parsing YAML, effective
  evaluation environment/planning options agree. The meaningful evaluation
  changes are worker/batch width 20 -> 12 and strict Torch deterministic
  algorithms off -> on. The offline request explicitly restores seed1 and
  tau0.3 despite the new pilot source command's training seed11.
- Historical runtime metadata records Python 3.11.14 and Torch 2.6.0+cu124.
  The old research hardware was A800; this host is RTX A6000. Historical
  hardware/backend equivalence is therefore not assumed.

The initial diagnostic wrapper failed before launching any evaluator because
the systemd PATH lacked `rg`. It was corrected to hash the explicit source
allowlist. That startup failure is retained as diagnostic r1; no computed
result was discarded or silently overwritten.

## Controlled probes

Full tune60 comparisons use fresh services, not cache hits:

| Probe | Width | Strict algorithms | Purpose | Status |
|---|---:|---|---|---|
| failed pilot reference | 12 | on | Current-environment candidate baseline | completed |
| diagnosis r2 / 12_strict | 12 | on | Independent exact-repeat check | completed, exact |
| diagnosis r2 / 20_legacy | 20 | off | Restore historical width/arithmetic settings on A6000 | completed |

Diagnostic r2 service:
`hkbz-stage2-a3-diagnosis-20260905-r2.service`.
Artifacts: `result/hkbz_train_logs/stage2_a3_replay_diagnosis_20260905_r2/`.
It reserves CPU 0-31,64-95, with disjoint evaluation pools and 30-second
process/time monitoring, a declared 3600-second hard timeout, and two GPU0
allocator caps of 0.20. All normal completion cleanup targets owned processes.

An additional fixed-input probe uses case0029 (chosen because it had the
largest discrepancy) and repeats identical graphs/recurrent states at widths
12 and 20. It toggles only Torch deterministic algorithms while keeping
cuBLAS workspace fixed. It measures first-graph encoding, recurrent-state,
and active-action differences. This probe isolates numerical sensitivity;
it is **not** a new tune benchmark, and its selected-case frequency cannot
be generalized to all cases. Artifacts:
`result/hkbz_train_logs/stage2_a3_numeric_probe_20260905_r1/`.
Resource cap: GPU0 0.10, CPU30,94, hard timeout600 seconds.

The full legacy20 control completed all60 cases in 689.794 seconds, with no
cycles/timeouts and `cache_hit=False`. Its mean Cmax is 8341.288889 seconds,
only +0.683333 seconds (+0.008193%) from historical A3, but **15/60 case values
still differ**, maximum absolute delta211 seconds. Relative to local strict12,
9/60 cases differ. This rules out using near-equal aggregate means as evidence
of exact historical replay; hardware/legacy arithmetic remains a portability
limitation even when the old width is restored.

The independent strict12 replay completed in 1005.359 seconds. All60 case
Cmax values match the first strict12 replay exactly (maximum delta0 seconds,
mean8362.016666666666). Furthermore, the **entire evaluation payload**, not
only Cmax, is exactly equal as parsed JSON: case metadata, completion/step
counts and resource metrics all agree. No cache was used. Revalidation with
zero tolerance passes; this is the local baseline, not a claim that historical
8340.605556 has been recovered.

The first probe completed 300 trajectory steps, checking every fifth step:
60 strict-repeat checks were bitwise exact; changed widths/modes produced
encoder differences up to 6.675720e-6 but no action changes at those sampled
steps. A second probe checked **every step** (fresh output directory
`stage2_a3_numeric_probe_20260905_r2`) and stopped at the first active-action
difference on step1:

- Strict12 repeat: encoder/recurrent/action differences all exactly zero.
- Strict20, same graph/history/recurrent input: encoder max delta
  2.2649765014648438e-6, recurrent max delta 1.8998980522155762e-7.
- Resource agent34 chose request3 at width12 but no-op at width20;
  resource agent57 made the opposite change. Two active actions changed.
- The same-width nonstrict control on this step produced a 1.430511e-6
  encoder delta, but no active-action change.

The step1 input and both action arrays are retained in
`stage2_a3_numeric_probe_20260905_r2/first_action_difference.pt`.
This directly demonstrates a batch-size-induced assignment change, without
changing weights, feasibility rules, observations, or recurrent inputs. It
does not attribute every historical discrepancy uniquely to batch width or
quantify the separate contribution of A800 -> A6000 migration.

## Implemented preflight amendment

The default historical gate remains available. The local-reference route
requires both explicit `REFERENCE_DIAGNOSTIC_DIR` and
`REFERENCE_NUMERIC_PROBE_DIR`; an absent/incomplete/altered proof is rejected.
It requires two complete strict12 replays to agree at **zero** tolerance,
completed legacy20 control, same checkpoint/seed/tau, matching numerical
source files, 300 input fingerprints, and a completed fixed-input numerical
probe with an exact repeat and a demonstrated action flip.

The amended manifest retains the immutable historical evaluation and its
SHA, the new local reference and SHA, all proof-file SHAs, software/GPU/driver
identity, worker width, strict arithmetic mode, and both historical case
comparisons. Only preflight/launch orchestration source files may change
between the diagnostic and launch; numerical/model/environment/runner
changes invalidate this proof. The controller still performs a fresh tune60
preflight before it starts any trainer. Runtime or data drift fails closed.
The original scientific BC recipe, training budget and checkpoint selection
thresholds are unchanged.

Regression validation: 105 tests passed in 12.232 seconds on the launch code, including five
new fail-closed rebaseline tests and the existing100 Stage2/BC/sampling/
orchestration/lookahead tests. These reject partial or non-exact replays,
wrong model-tensor digests, absent action-sensitivity evidence, altered source,
altered case data, altered proof files, and runtime/GPU mismatches.

## New pilot execution

Launched at 2026-09-05 17:26 CST after both complete diagnostics, data/code
checks and GPU0-idle confirmation. Suite:
`result/hkbz_train_logs/stage2_bc_injection_20260905_gpu0_half_pilot_r2`.
Unit: `hkbz-stage2-bc-injection-20260905-gpu0-half-pilot-r2.service`.
Initial controller PID2370687, evaluator PID2370698. At17:26 it is running
its new-service exact tune60 preflight; trainers have not started yet.

**Latest status,17:41 CST:** the new-service preflight completed in875.660
seconds and passed60/60 at zero tolerance, maximum Cmax delta0. This is the
third independent strict12 evaluation. The complete evaluation payload also
equals the diagnostic payload. Historical differences remain recorded in
`reference_a3_integrity.json` under `historical_comparison_diagnostic_only`.

B0 and B1 trainer processes started at17:40:46 CST (PID2376349 and2376350).
Both accepted the pinned Stage1 handoff, loaded the frozen R1 predictor,
zeroed the time projection, and requested `pre_supervised` tune60 evaluation.
At this snapshot they are in training initialization/baseline evaluation,
**not yet performing optimizer updates**. B2 remains queued. This is a
running pilot, not a completed BC result.

Host audit at17:41 checked64 suite processes and91 threads: zero CPU affinity
violations. B0 is bound to0-11,64-75; B1 to12-23,76-87; evaluator to24-29,88-93;
controller to30-31,94-95. Only these three CUDA processes are on GPU0.

The manifest freezes210 source files with source archive SHA256
`b6f70d43c05a93c4932ffe6bbec9e539a22ca865a170191fb2c21d63e808df64`.
Reference mode: `local_exact_after_environment_diagnosis`, tolerance0 seconds.
GPU0 UUID: `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`, driver560.28.03,
Torch2.6.0+cu124 / CUDA12.4 / Python3.11.14.

Commands B0_none_seed11 / B1_dag_seed11 / B2_R1_seed11 retain24 rollout
workers,10 rollouts per epoch,240 fixed balanced training cases,2 epochs,
12 evaluation workers and0 PPO episodes. Maximum2 concurrent trainers;
B2 waits for a free lane. All descendant processes are constrained to
CPU0-31,64-95 and CUDA_VISIBLE_DEVICES=0. GPU1 remains occupied by the
unrelated experiment and was not modified.

Operational implication: changing evaluation worker/batch count, strict
arithmetic mode, GPU or backend is a new evaluation contract. It must not be
used as an unrecorded throughput/VRAM tweak when comparing case-level Cmax.
All three arms in the new pilot have identical commands except experiment
name and injection mode, and share one fixed240-case order (120IID,
108OOD-stress,12OOD-scale; sampling seed1). No source fingerprint changed
after the new manifest was created.

## Decision rule

No tolerance relaxation or historical-result overwrite is authorized by a
small mean delta. First require same-configuration repeatability and inspect
historical-setting and identical-input controls. If a semantics/data bug is
found, repair and replay. If current deterministic evaluation is exact but
old hardware/arithmetic is nonportable, explicitly version a local baseline
with its complete provenance, retain historical differences as diagnostics,
and require a new exact preflight before starting pilot trainers. Do not
claim exact reproduction of historical A3 in that case.

## Interpretation / fallacy scan

Coverage: 11/11 statistical-methodological fallacy categories reviewed.
No p-values, population effects, causal treatment benefits, or formal
equivalence tests are claimed here.

- Simpson/aggregation: retain all distribution-level deltas; OOD-scale has
  the opposite sign and only three cases.
- Ecological inference: do not use the small mean delta to dismiss individual
  case drift.
- Berkson/selection: case0029 is a targeted debugging fixture, not a random
  estimate of numerical sensitivity.
- Collider bias and base-rate neglect: no adjusted model or diagnostic-rate
  inference; not applicable to the replay comparison.
- Regression to mean: no claim of model improvement from remeasurement.
- Survivorship: all 60 cases retained; no failure or outlier filtering.
- Look-elsewhere: retain failed startup, failed gate and all numerical modes.
- Forking paths: any evaluation-baseline amendment must be explicit and
  evidence-bound, not selected for a more favorable mean.
- Correlation/causation and reverse causality: source audits alone do not
  identify a numerical kernel as the unique cause; distinguish controlled
  changes from the unresolved hardware-migration residual.
