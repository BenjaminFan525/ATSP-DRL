# Stage2 Blocking 规则修正与重启记录

Material Passport — academic-research-suite / experiment-agent，用户授权修正、复验及启动；单代理执行。
工程状态与科学状态分开：177项单元/兼容回归及完整四组 canary VERIFIED；新pilot服务已启动，正在60案例训练前回放；科学效果 UNVERIFIED。

## 失败证据与诊断

保留 `result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_pilot_r1`，不覆盖、不从 Emergency 续训。
原套件于 2026-09-06 13:24:52 CST 失败，M0/M1/M2 均在 E1 第5轮 case_0343 触发相同 Blocking 审计，M3 未启动。
旧教师的串行 last-chance 规则允许 `[20,1,0,0,0]`，但部署联合优先级要求可行的两个 Blocking 请求同时覆盖。
对应物理设备 `[25,26,39,41,55]`；新规则在该记录掩码上输出 `[2,1,0,0,0]`，只改动设备25。

## 修正边界

不修改部署 Hungarian +1e6、环境合法性、历史 IGA 搜索默认行为、教师文件或历史评测。
四组 BC 显式启用 `device_bc_teacher_deployment_projection`，合同 `iga_derived_max_blocking_identity_serial_v1`。
原本兼容的标签保持原物理身份；冲突的教师在损失之外明确派生并记录，损失端仍严格 fail-closed。
派生教师不是重新优化的 IGA1800。原教师 Cmax 单独保存，新轨迹 Cmax 不借用旧数值；旧 Ready 标签禁用。
被投影改动的联合决策不借用原得分置信度，其 no-op 不冒充有效等待。

## 检查与复现

109 项 unittest 全部通过（12.592秒），覆盖 matching_gap、structured_credit、bc_injection、policy_transfer、resource_iga_ablation、device_lookahead_dispatch、stage2_resource_research。
包含 400 组新旧部署解码逐项对照、350 组小规模可行匹配枚举、真实失败掩码、串行重解、重复/非法标签拒绝、默认教师行为及 Ready/Cmax 来源隔离。
`git diff --check` 通过。所有测试使用 CPU `30-31,94-95`，禁用 CUDA；不改动已有脏工作树中的无关文件。
补充 bc_replay、stage2_transition、joint_training、two_stage_orchestration 的68项测试也通过（2.003秒），共177项通过；参数非法值测试中预期的 argparse 报错不属于测试失败。
运行环境：Python3.11.14、PyTorch2.6.0+cu124（CUDA12.4）、NumPy1.26.4、SciPy1.14.1、torch_geometric2.7.0；固定解释器 `/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11`。

## Canary r3

启动时间：2026-09-06 13:53:48 CST。
服务：`hkbz-stage2-matching-gap-20260906-gpu0-half-canary-r3.service`。
套件：`result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_canary_r3`。
安全源码归档 SHA256：`ac844a1bc66f6d05a2d703b682f3528e8b727b3f490eb4126e4f1ed4017bcd3a`。
固定训练病例：seed541 → case_0294、case_0343；四组各2 epochs，2 rollout workers，4个评测病例。
必须实际触发修正且每轮完整完成，工程分析通过后才可作 pilot 证据。该小样本不能证明有效等待覆盖或科学优化。

## 资源与后续启动条件

只使用 GPU0（UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`），总 CPU `0-31,64-95`，64/128逻辑线程；GPU1 上的其他任务不触碰。
3条训练 lane、独立共享评测器；第4组排队。systemd AllowedCPUs/CPUAffinity 已核实。
心跳30秒；300秒无输出提示诊断；48小时硬上限。失败不盲目重试，不启动后续排队任务。
新 pilot 必须绑定同源 canary 报告，从原 B0 Best 重新 fresh fork，保留原 seed11、240训练病例/seed1顺序、24 workers、每 epoch10完整rollouts、2 epochs。
每组在第一步梯度前 strict-12 tune60 逐案例零差回放。有效等待覆盖门控保持不变。不会自动进入 RL、正式确认或 Stage3。

## 复验中额外发现：等待标签是数值边界，不作科学覆盖

前三组 E1 全部完成，均检查994个有效环境决策、修正1次；日志重现 case_0343 原始 `[20,1,0,0,0]` 并执行 `[2,1,0,0,0]`。
M0/M1 各252个优化步骤，M2 多1步；各有1个标为 temporal_defer 的空组。
额外 CPU 回放（仅30-31,94-95，不修改已锁定源码）完整完成 case_0294/0343，确认唯一等待样本出现在 case_0343 第25步、设备39、请求3：
lead=271.6666666666667，travel=211.66666666666666，safety=60，dispatch_delay=2.842170943040401e-14秒。
环境允许 <=1e-9 的边，旧教师严格比较 travel+safety<lead，从而给数值边界误标 temporal_defer。
证据：canary r3 下 `wait_label_boundary_audit.json`；CPU诊断不冒充 strict-12 GPU 基线复验。
两个诊断案例的派生教师 CPU 完整回放 Cmax 分别为9689、8873.33333333334，与各自历史教师文件记录逐数值相同；这仅是这两个案例的检查，不代表总体教师质量或学习效果。

**启动范围修订**：继续完成四组工程canary；新pilot只启动 M0_control/M1_full_edge，M2/M3 暂缓，等待标签需重新定义并独立确认，不能为数值噪声投入正式训练。
这一调整在任何新pilot梯度前声明；新manifest将保留原准备稿及显式修订、证据哈希，源码与canary保持一致。
M0/M1 的损失不包含等待项，原240案例、B0起点、超参数和完整边对照保持不变；不把“有效等待计数1”解释为等待策略的科学证据。

## 最终复验与启动结果（2026-09-06 14:24 CST）

Canary r3 四组各2 epochs 全部完成，分析 `complete=true`、`canary_contract_passed=true`，四组 `integrity_passed=true`、`warmstart_exact=true`。
每组每轮检查994个有效环境决策、修正1次，均越过真实故障点并完整结束。
四组的严格整体检查点选择均保留起点（effective_epoch=0）；**不宣称短复验得到性能提升**。
Canary服务已正常退出，ExecMainStatus=0，GPU0已释放；224个锁定源码文件在启动新pilot前逐一校验未变。

新服务：`hkbz-stage2-matching-gap-20260906-gpu0-half-pilot-r2.service`，14:23:08 CST 启动，MainPID=2734372，ActiveState=active。
套件：`result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_pilot_r2`。
最终 manifest SHA256：`2b7fc8ef36d217f34d91592a0601cf05f387acfa84ab2312d7ad80e9721fffe0`。
保留 `manifest_pre_wait_hold.json`，在任何服务启动/梯度前显式修订为M0/M1；原M2/M3命令保存在deferred_commands，原因和诊断文件SHA绑定于scope_amendment。
校验确认：M0/M1命令逐项等于准备稿，代码哈希逐项等于已完成canary，诊断文件和准备稿SHA一致；没有通过修改源码跳过canary门控。

M0 PID2734449、M1 PID2734450；共享评测器 PID2734386，strict deterministic algorithms，12 workers，tune60。
三进程的 NVIDIA 上下文均为GPU0 UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`，不使用GPU1。
systemd AllowedCPUs/CPUAffinity 均为 `0-31,64-95`。
**交接状态**：两个训练进程处于shared_eval_queued；评测器已开始pre_supervised。60案例零差回放尚未完成，尚未进行梯度更新；通过后自动进入E1，任何不一致都会停止，不重试。运行后续状态以suite_status.json、run_status.json及回放日志为准。
