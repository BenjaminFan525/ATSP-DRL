# Stage2 P0/P1：完整设备配对与有效等待监督

Material Passport: academic-research-suite / experiment-agent；用户授权实现与启动。
本文为运行前合同，实验状态见各新套件的 suite_status.json；科学结果在完成独立确认前均为 UNVERIFIED。

## 范围和目标

最终目标沿用 STAGE2_IGA_TARGET_REVISION_20260906.md：锁定评测集逐案例不劣且总体超越 IGA180，平均、各分布及尾部达到或超过 IGA1800。不能用 BC loss 下降代替闭环 Cmax 改善。
本轮落实 P0 工程一致性审计和 P1 四组因子筛选。代价学习、重优化教师、DAgger、资源 RL、多种子确认及 Stage3 探针均待本轮证据后决策，不自动启动。

## 实现

- 部署与新监督共用 private-noop Hungarian / Blocking +1e6 解码。保留旧参数、旧集合损失和默认关闭的新开关，以兼容旧模型。
- 完整边 hinge 保留教师的物理设备到请求身份，包括混合匹配中的等待设备；不将同类型设备擅自重配。使用相同合法域与 Blocking 规则对全部活跃资源联合进行损失增广匹配，按有选择的活跃行数归一化；full_edge_groups 的单位为联合环境决策，不是设备类型组。
- 新空组等待项只优化存在真实合法请求且教师明确标记 temporal_defer 的设备。结构性无请求、capacity_unmatched、claimed_noop 和含义混合的旧 deferred_noop 不冒充有效等待。
- 审计记录全联合、物理边、可选择边、请求集合准确率及其原始分母；旧 assignment_exact/f1 留作 legacy 指标，deploy_* 才对应真实部署。
- 教师身份不合法、请求冲突或违反部署 Blocking 优先时保存 matching_contract_failures.jsonl 并停止，不静默丢弃或重配。
- 单元测试覆盖错配梯度、同步设备重编号、混合组/全等待组、无选择空组、Blocking 优先、损失默认兼容；随机及并列分数对照旧解码必须逐项相同。

## 预先锁定的四组

| 方法 | 原集合损失 | 完整边系数 | 空组有效等待系数 |
|---|---:|---:|---:|
| M0_control | 1 | 0 | 0 |
| M1_full_edge | 1 | 1 | 0 |
| M2_typed_wait | 1 | 0 | 0.25 |
| M3_edge_wait | 1 | 1 | 0.25 |

所有组从同一已审计 B0 Best 权重重新分叉，seed11，fresh optimizer/RNG，固定 S1 与 R1；R1 不注入动作且不重新计算轨迹绑定标签。teacher execution=1，lr=1e-5，2 epochs。pilot 为固定240个train案例、24 workers、每epoch10轮完整rollout；每epoch必须实际产生优化步骤，等待组至少1个有效等待组，否则停止。

Canary 为2个train案例、2 workers、每epoch1轮、4个eval案例，用于验证完整训练/保存/评测/分析链。Canary 不证明科学效果；小样本允许没有自然有效等待，但对应单元梯度测试必须通过。
pilot 需要同一源码哈希的完整四组canary报告。每个pilot任务在任何梯度前对 B0 tune60 使用 strict-12 数值合同逐案例零差复验，失败不继续。

## 评测和预算审计

仅使用 tune60 开发，不访问 gate120/finalblind。保存 Pre/E1/E2 所有案例与所有结果，包括失败和未改善。选择整个数据集的单一检查点，要求相对未训练起点 raw、IID、stress、scale、tail10 点估计均不退化，否则保留起点。不能按案例挑选模型。
同步报告 M1/M2/M3 对 M0、M3 对 M1/M2，以及 B0/B2/强参考D_B0的配对差值。
开发筛选要求相对冻结D_B0至少缩小25%的历史IGA1800均值差距，并且各分布和tail10无点估计退化。此门槛仅决定是否值得追加投入，不代表最终目标已实现。

IGA审计锁定历史 H2/F4 同S1、同60个案例SHA、规划合同、完成和回放状态、嵌套180+1620预算及逐文件哈希。记录名义和实际耗时、候选数、所有退化案例、分组/尾部/每profile差值、胜平负、最大正差值与案例bootstrap区间。1e-6只用于展示胜平负；逐案例不退化按零容忍判断。
历史IGA180平均实际搜索287.43秒，IGA1800平均额外1620.253秒。当前v4首次获得可行incumbent可越过deadline，初始化和最终回放不在搜索计时内。因此历史参考不构成严格预算或当前运行时重放证明。正式目标确认前必须另做锁定硬件、计时边界与独立案例的基线重建；本轮不得宣布 confirmed_scientific_success。
区间为固定单训练种子条件下的10,000次案例重采样（seed20260906），未经选模/多重比较校正，只作探索诊断。

## 资源、追溯与停止

仅GPU0；CPU共128逻辑线程，拥有0-31,64-95（64逻辑线程/32完整物理核）。三条训练lane分别0-7,64-71、8-15,72-79、16-23,80-87；评测24-29,88-93；控制30-31,94-95。最多3个训练并发，第4个排队，共享独立评测器，不使用GPU1。
新套件不覆盖旧目录。manifest锁定代码与安全的onpolicy源码归档、输入数据/检查点、采样顺序、训练评测合同及canary证据。运行中不修改已锁定源码。
心跳30秒，300秒无日志仅提示诊断，48小时硬上限；失败不自动重试，不启动剩余排队任务。失败记录保留，修正需要新run tag并重新canary。

启动器：onpolicy/scripts/train/launch_stage2_matching_gap_gpu0.sh。默认canary；pilot必须显式提供PROFILE=pilot与CANARY_PROOF，使用systemd资源限制运行。

## Canary r1 的修正记录

r1在梯度前审计阶段停止，三组failed、M3未启动，记录不覆盖。case_0444的同一请求3可由R005和R013行选择：当前请求代表job/site，needed_res_types可含多种类型，但全局解码每次只允许一个设备claim该请求。因此“按设备类型独立求匹配”的可分解假设不成立，并非设备索引错误。
v2将完整边损失改为跨类型的全资源联合匹配；类型分组只用于等待分层与指标，不用于独立求解。保留教师身份和全局唯一性，不丢弃样本，也不修改环境/教师/部署规则。增加跨类型共享请求的梯度回归测试；新源码必须重新canary，旧r1不能作为启动pilot的证据。

## Pilot r1 Blocking 规则冲突修正（2026-09-06）

r1 于 13:24:52 停止：case_0343，agents=[25,26,39,41,55]，教师动作=[20,1,0,0,0]。
原教师按设备串行合法性选 Lookahead 20 和 Blocking 1，但部署联合匹配可以覆盖 Blocking 1、2。
本次用户授权修正后复验重启；保留失败日志、Emergency 和旧 manifest，不恢复不完整的 E1。

- 新开关 device_bc_teacher_deployment_projection 默认关闭；仅本轮四组同时开启。历史 IGA 搜索、教师文件、环境及部署解码默认行为不变。
- 显式派生教师合同 iga_derived_max_blocking_identity_serial_v1：已经兼容的标签逐项不变；冲突时先最大化 Blocking 覆盖，再奖励保持原物理边。若与串行 last-chance 冲突，固定合法前缀、限制首个冲突行并重解后缀，最后通过环境静态 plan 校验。不是重新做 IGA 优化，也不宣称同时约束下的全局最少编辑。
- case_0343 的记录掩码修复应为 [2,1,0,0,0]，只改一个设备。非法身份、重复 claim、原教师串行非法仍报错；完整监督的严格审计不关闭。
- 新轨迹不继承历史教师 Cmax/Ready 事实标签；保留 original_teacher_cmax，derived_teacher_cmax=null。投影产生的 no-op 不作为 temporal_defer 监督，投影事件的分数置信度不沿用。
- 每个事件保存 teacher_projection_events.jsonl（案例、教师 SHA、原动作/新动作、合法集），每 epoch 汇总检查数、事件数、改动行数、新增 Blocking 和串行重解数；检查点和恢复合同绑定教师版本。
- 新 canary 固定抽样 seed541，包含 case_0294、case_0343（不是科学选样）；仍四组各2 epochs。分析必须确认实际触发修正并完整跑完。pilot 保留原 seed1、240案例及原顺序；所有组从原 B0 fresh fork，重新 strict-12 tune60 零差复验。
- 当前修正是可表示性与执行合法性修复，不保证教师闭环性能或科学目标改善。有效等待覆盖门控保持不变；没有真实 temporal_defer 空组时不得将等待组当作有效消融。
