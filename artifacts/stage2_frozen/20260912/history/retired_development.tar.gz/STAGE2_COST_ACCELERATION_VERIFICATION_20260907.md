## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: user-authorized implementation + deterministic engineering verification
- Origin Date: 2026-09-07
- Verification Status: CPU and bounded GPU replay verified; complete GPU continuations and research efficacy UNVERIFIED
- Version Label: exact_full_batch_fanout_shared_environment_prefix_v1 / devcheck_r4

## 已完成

新增独立加速入口，不修改正在运行的旧 Stage2 源码：

- N0/N1 独立 canary → pilot，不依赖成本标签或成本 microfit；每个训练阶段最多两组并发。
- 候选去重、环境分支共享相同前缀、批处理 RPC；分歧前复制私有环境与随机状态。
- 默认两路私有冻结模型 CUDA stream；每次推理仍保持原始 24 环境批次与双 GRU。
- 精确缓存绑定源码、GPU/驱动/库版本、冻结策略、全部伴随状态、双 GRU、历史与完整首动作；不缓存未完成分支。
- 分别记录逻辑查询、实际作业、缓存命中、共享环境步、RPC/推理时间和不重叠墙钟时间。
- 科学正确性/可学习性、完整数值等价性/吞吐、执行预算分别检查。预算不足只暂停成本 pilot，不阻塞已完成的 BC 对照。

## CPU 与配置验证

最终 81 项测试通过，涵盖候选/损失、原始匹配与复验契约、分叉隔离、缓存损坏与失效、完整合成案例证据写入、逻辑/实际计数、阶段依赖与独立预算门槛。
新增集成测试初次对来源名称的断言误写为 `teacher`，已更正为实现原有的 `derived_teacher`；没有修改教师来源或候选语义。
20 个相关 Python 文件 AST 检查和新启动脚本 `bash -n` 通过。

最终配置验证：

- `result/hkbz_train_logs/stage2_cost_accel_20260907_devcheck_r4/manifest.json`
- SHA256 `81ce511e556de0ce30851e9145ebb37d46339347a9e689d234385a28352b0fe2`
- 固定 246 个源码/配置/说明文件。
- N0/N1 canary 在没有任何成本证明时可独立准备，且不含成本训练开关。
- 缺少证明的成本 pilot 被拒绝准备。
- 旧运行 manifest 的 231 个源码文件逐一哈希一致。

## GPU 数值检查

仅 GPU0，与明确核对的旧诊断 PID 2938087 共享；GPU 检查内部限制到 CPU 30-31,94-95，属于原定 CPU 半区。每次检查硬限时 15 分钟，没有停止旧服务或使用 GPU1。

| 检查 | 批次宽度 | 前缀步数 | 串行秒数 | 新执行器秒数 | 观测加速 |
|---|---:|---:|---:|---:|---:|
| r2 双 stream | 2 | 32 | 20.0423 | 13.3411 | 1.50× |
| r2 双 stream | 24 | 32 | 97.5448 | 40.9824 | 2.38× |
| r4 最终配置复核 | 2 | 8 | 5.0751 | 2.9411 | 1.73× |
| r4 最终配置复核 | 24 | 8 | 22.7542 | 8.5797 | 2.65× |

上述检查的逐步动作、双 GRU、环境终止标志/中间状态摘要均与串行参考完全一致，源权重未改变。
r4 在 r2 后补充了缓存运行环境绑定和独立预算门槛，最终版本重新通过短程检查。

r4 报告：`result/hkbz_train_logs/stage2_cost_accel_20260907_devcheck_r4/acceleration_smoke/report.json`

SHA256：`8009fe8d0bfc4747037f9c1524e4cfcd0d9ee71c8a011fbede9ab13b68cd6f7b`

这些是共享主机负载下的短程工程观测，不是完整轨迹成本复验，也不是整轮加速保证。
报告明确保留 `acceleration_gate_passed=false`；短程成功不会放行 N2/N3 成本训练。

## 未启动及后续门槛

本次没有停止旧诊断、没有启动新的 N0–N3 训练，也没有生成新的已训练权重。
完整 2/24 批次续跑、真实完成 Cmax 和缓存复验、训练 canary 与研究效果仍需后续执行。
新控制器已将这些检查设为明确门槛，不会把短程测试冒充完整复验。

新入口：`bash onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh`

正式切换前需先明确停止旧 GPU0 诊断；新入口遇到 GPU0 已有进程会拒绝启动，不会自动抢占或终止旧任务。所有开发验证目录均保留；它们是工程检查，不是 N0–N3 训练运行。
