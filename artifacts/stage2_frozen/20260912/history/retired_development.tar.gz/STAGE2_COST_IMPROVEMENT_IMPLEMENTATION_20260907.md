# Stage2 cost-sensitive policy improvement: N0–N3

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: user-authorized implementation + run + deterministic engineering validation
- Origin Date: 2026-09-07
- Verification Status: 140 CPU regressions passed, including full-state persistence;
  real-GPU candidate/anchor/recurrent-gradient probes passed; scientific efficacy UNVERIFIED
- Version Label: joint4_full_gpu_batch_frozen_student_cmax_v1

## Scope and fixed target

Latest user instruction authorizes GPU0 only and the remaining CPU half.
The observed GPU1/MAIA workers occupy 32-63,96-127. This suite reserves
0-31,64-95 (32 complete physical cores, 64 logical CPUs), never GPU1.
Maximum two trainers: 0-11,64-75 and 12-23,76-87. Shared evaluation:
24-29,88-93; controller: 30-31,94-95. No existing task is stopped.

The research target is unchanged: every locked case nonworse than IGA180,
strictly better mean; mean, IID/stress/scale and tail10 nonworse than IGA1800.
Historical IGA budgets/runtime cannot certify that target. No RL, Stage3,
independent confirmation or finalblind evaluation is automatically launched.

## Mechanism

N0/N1 use original full-edge BC, N2/N3 add completed-Cmax cost preferences.
Teacher execution schedules are 1/1 for N0/N2 and .75/.5 for N1/N3.
All fresh-fork B0 seed11; Stage1/shared/R1 frozen, Ready injection none.
Same 240 cases, 24 rollout workers, 10 complete rollouts/epoch, two epochs,
BC lr1e-5. Cost scale120 seconds, clip4, tie band1 second, coefficient1;
fixed a priori without tune fitting. Full-edge1, set1 and set-margin.25
remain BC anchors ONLY on uncovered joints. No old CPU wait cache is reused.

At resource-choice ordinals4/16 in each case, within the first256 events,
consider up to4 distinct complete joint actions: current deployed student,
derived deployment-compatible teacher, legal wait/dispatch and local swaps.
This is bounded local improvement, NOT exhaustive wait verification/global
optimality. All candidates satisfy global uniqueness, maximum Blocking
coverage and serialized last-chance legality. Incomplete branches abstain.

Each epoch freezes a private current-student target. Its own plane/resource
GRUs are advanced on the actual roll-in history. Every intervention restores
all worker environments and both target GRUs. The entire original
heterogeneous CUDA batch and companions continue; only one environment's
initial resource joint action changes. No CPU proxy, reduced batch or teacher
resource continuation is represented as Q_student. Snapshot, history, mask,
policy and evidence digests plus query/vector-step/wall-time ledgers are saved.
Losslessly compressed FULL environment snapshots, both target GRUs, learner
GRUs/current weights and raw observation/history prefix are retained for each
nontrivial selected vector state, with a separate frozen-target checkpoint.
This supports later replay/gradient-conflict audits, not just hash comparison.
Limit16 GiB compressed evidence per cost iteration; excess fails closed and
preserves outputs, never silently discards selected states. The pilot's four
cost iterations therefore permit at most64 GiB plus diagnostics/canary.

All N arms disable actor/encoder dropout while gradients stay enabled. Only
zero-dropout resource GRU leaves use train-mode to retain the cuDNN backward
reserve; engineering checks compare their actions/hidden outputs to deployed
eval-mode exactly. Plane GRUs stay eval-mode. At selected states all N arms
reconstruct the CURRENT learner's GRU from
raw trajectory prefix at its current weights. The existing online truncated
BPTT convention remains on uncovered BC states; this is NOT full-trajectory
backpropagation. Target hidden states are never supplied to the learner.
The new common protocol means N0 is contemporaneous, not relabeled old M1.

Cost supervision uses normalized/clipped ordered-pair structured hinges.
Its additive row score is NOT the probability of a Hungarian matching.
Ties receive no identity preference. Every covered joint suppresses ALL old
resource losses, including set/margin/full-edge losses. The actual deployed
current action must belong to the scored set; an escape fails closed.

Pilot cap: 2 cost arms ×2 epochs ×240 cases ×2 states ×4 candidates =7680
candidate continuations. This excludes diagnostic replay queries and counts
neither companion environment interactions nor BC work as free compute.

## Gates and launch order

1. CPU engineering tests and immutable source/input/checkpoint manifest.
2. Phase A on24 fixed train-only cases: IID12/stress10/scale2, selected in
   locked pilot order before observing new results;0343/0444 excluded.
   Audit all1159 old wait states, retaining negative/tie directions. Exact
   whole-batch zero-intervention replay must match all24 live Cmax values.
   Compare B0 and deployment-compatible IGA-derived teacher in closed loop;
   derived teacher is an empirical reference, not a mathematical upper bound.
   Old raw IGA1800 numbers are NOT called same-runtime results.
3. Microfit at most4 non-tied train snapshots on a discarded resource-only
   model copy:100 Adam updates at1e-3, exact current-parameter prefix replay
   before EACH update. Loss must decrease by≥50%, candidate regret nonworse.
   This tests learnability, not generalization; no microfit weights transfer.
4. No incomplete diagnostic branches; serial cost-query estimate extrapolated
   from the locked24-case candidate density must fit the declared48-hour bound.
   Also report the7680-query worst-budget estimate. This is conservative,
   not a claimed acceleration factor; controller also enforces wall timeout.
5. Four-arm/two-epoch engineering canary on train0343/0444. Source-matched
   Phase-A proof required. Frozen tensor/optimizer scope, nonzero updates,
   candidate budgets, exact warm-start weights and all evaluations audited.
6. Only then launch N0–N3 pilot. Each job must pass zero-tolerance B0 tune60
   replay before gradients. Source-matched four-arm canary proof required.
7. Keep all raw epochs, use whole-dataset group/tail nonregression selection
   with unchanged-B0 fallback. IGA1800 gap-closure screen25% relative to
   D_B0 (mean threshold8265.2513889), group/tail nonworse than D_B0 as well.
   No passing candidate means diagnose, not automatically add epochs.

Any failure preserves outputs and blocks later stages. Services use
Restart=no; no automatic retries, baseline amendments or gate relaxation.
The Phase-A wall estimate covers only candidate work, not total pilot time.
Historical gradient-conflict frequency cannot be measured retrospectively
without old full snapshots; the label audit states that limitation explicitly.

## Entry point

`bash onpolicy/scripts/train/launch_stage2_cost_improvement_gpu0.sh`

Creates a new suite, then runs Phase A → gated canary → gated pilot. Runtime
state: pipeline_state.json; phase logs, diagnostics/report.json, manifests,
per-epoch cost evidence and final analysis are retained in separate paths.
Use a new tag only for an explicitly authorized new experiment; never restart
a failed process silently. Source_bundle.tar.gz contains only fingerprinted
onpolicy code/configs and this implementation note, not unrelated user files.
