## Material Passport

- Origin Skill: academic-research-suite/experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-09
- Verification Status: UNVERIFIED
- Version Label: v5_initial_audit_matched_autograd_metadata_v1

## 故障与证据

r3于12:18:20启动，于12:21:01退出。在E0_initial_AR首批12例的第247次
前向中，log-probability最大差异1.0728836059570312e-6，略超1e-6门槛。
动作、decision_mask、RNN隐状态完全相同；Actor参数完全相同，唯一不同
的参数是协议要求重新初始化且本次Actor前向不使用的team critic。

有界复现最多260步、600秒，实际在同一第247次前向重现；12例均未完成，
没有训练更新。原输入保存在
`result/hkbz_train_logs/stage2_split_encoder_v5_zero_reproduction_20260909_r1/failure_fixture.pt`。
报告与逐层定位结果分别在同级report.json和
`result/hkbz_train_logs/stage2_split_encoder_v5_zero_layers_20260909_r2/report.json`。

首个分歧来自transporter_actor.req_query_attn的K/V投影：输入、权重、stride
相同，但冻结参考与可训练Actor的requires_grad元数据不同。
单独对齐参考注意力层的梯度标志后，输出差异降为0，且没有建立计算图。
这是数值执行路径的差异，不是已经证明Actor学坏或编码器复制错误。

PyTorch 2.6的非连续3D linear进入matmul，should_fold会直接检查右侧矩阵
requires_grad，选择mm或bmm；该检查不受外层no_grad消除。
依据：[Linear.cpp](https://github.com/pytorch/pytorch/blob/v2.6.0/aten/src/ATen/native/Linear.cpp#L105)、
[LinearAlgebra.cpp](https://github.com/pytorch/pytorch/blob/v2.6.0/aten/src/ATen/native/LinearAlgebra.cpp#L1780)。

## 修复边界

只改V5的初始参考审计分支：在no_grad和eval模式内临时对齐参考资源Actor的
requires_grad元数据，finally恢复完全冻结。没有优化器更新、权重替换、
参考权重共享或训练梯度。训练期间的B0参考KL路径保持原实现。
1e-6概率/隐状态阈值、动作和掩码精确一致要求均不放宽；新增有限值检查
及包含具体误差的失败信息。

AST签名逐节点验证：排除这一初始审计分支及其新增import后，旧V5文件
所有实现与新文件相同。其他已固定旧代码的SHA256全部要求不变。
因此原96例工程训练、梯度、Adam恢复及吞吐证明可保留，不重复工程采样；
新初始tune60复验仍全部执行，不把单步修复验证替代为科学结果。

## 复验

- 67项CPU回归全部通过，包括原V3/V4/V5、严格1e-6阈值与NaN拒绝、
  参考冻结恢复、非审计实现不变、原时间起点/截止继承及失败尝试计数。
- 精确故障输入上E0–E3四臂均达到bit-exact：log-probability、隐状态、动作、
  掩码及完整资源分布一致；修复前后实际行为完全相同。
- 刻意扰动参考权重仍被审计拒绝；异常退出后参考恢复全冻结，权重不变。
- GPU证明：`result/hkbz_train_logs/stage2_split_encoder_v5_zero_fix_check_20260909_r2/report.json`。
  零新增环境病例、零训练更新。r1检查工具曾直接比较CPU fixture与CUDA结果，
  设备比较错误已修正；该失败记录保留，未将其算作通过证明。

## 继续实验与时间/病例账本

用户明确要求“排查并修复问题，然后继续实验”。使用独立r4目录，保留r3
日志、失败状态、完整中断checkpoint和所有早期产物，不加载中断或工程权重。
仍从不可变B0初始化，Stage B仍四臂各train240；各轮评估、门禁、超参不变。
只使用GPU0、CPU 0-31,64-95，最多2训练槽，评估互斥，Restart=no。

不重置时间授权：控制器沿用r3起点12:18:24和原截止时间；系统服务硬截止
继续为2026-09-10 18:18:20 CST。修复耗时计入原授权墙钟。

原正常流程上限2316病例执行：96工程已保留，剩余2220。
修复账本另列r3未完成的12次尝试与有界故障复现12次尝试；两者均不产生
训练样本或已完成评估结果。含故障和诊断的累计物理尝试上限2340，
不是静默追加train240或tune60。离线GPU与单元复验不新增完整环境病例。

续跑先完整初始AR/H复验和B0原图参考采集，再按实测耗时检查预算，通过
才启动E0/E1、E2/E3两组正式PPO-V。故障不自动重试，Stage C/Stage3不自动启动。
科学效果仍为UNVERIFIED。
