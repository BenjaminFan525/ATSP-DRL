# Stage2 M2/M3 等待标签修正与启动记录

Material Passport — academic-research-suite / experiment-agent；用户授权排查、修正、复验后启动，单代理执行。
工程检查、标签来源与科学效果分开记录；不把标签反事实收益等同于训练后策略提升。
最终交接状态（2026-09-06 15:58 CST）：188项测试和M2/M3各2轮canary全部通过；240案例pilot已于15:56:38启动，两组正做训练前strict-12 tune60零差回放，尚未进行pilot梯度更新。

## 修正结果

旧 M2/M3 被暂缓是合理的：deadline-aware 环境允许 delay<=1e-9，而旧 IGA 使用无容差的严格比较。
唯一被记为 temporal_defer 的空组来自 case_0343 第25步、agent39/request3，delay=2.842170943040401e-14秒；不是有意义的主动等待。
该数值边界现在单独计数，不产生等待梯度；capacity/claimed/无需求 no-op 也不能仅凭类别获得正标签。

新标签要求在同一真实状态、实际飞机动作及 post-forward GRU 下，保持其他资源动作固定，完整比较等待与全部可行的单请求设备派遣分支。
只有实际等待>=1秒，所有分支完整完成且等待 Cmax 比每个派遣分支至少少1秒，才接受。
等待损失仅比较证据指定的 no-op/请求两列，不抑制其他未验证请求。真实执行轨迹与部署匹配规则不变。
反事实后续是冻结 S1 CPU 策略加投影 IGA，结论是该续跑策略下的条件收益，不是全局最优保证或GPU正式评测。

## 代码隔离与复现

为不破坏正在运行的 M0/M1 源码合同，修正实现位于：
`result/hkbz_train_logs/stage2_wait_labels_20260906_gpu0_half/code`。
它由已完成 canary r3 的安全源码归档派生，数据/结果目录链接至原位置；原 M0/M1 的224个锁定文件逐一校验均未变。
主入口、环境RPC、等待标签模块、匹配损失、runner、配置、制备/分析/启动控制器及测试均在隔离副本中；暂不覆盖原目录源码。
实现合同见该副本内 `STAGE2_VERIFIED_WAIT_20260906.md`。实验运行后不再修改其228个锁定文件。

测试：最终188项单元与兼容回归全部通过，14.889秒；新增覆盖来源/缓存篡改、真实GRU状态绑定、数值边界、所有设备备选、负例拒绝、等待梯度范围和逐epoch证据审计。
此前失败仅为隔离归档未包含历史测试引用的说明文件/启动脚本，补齐原文件后通过；未跳过测试或更改原逻辑。
Python3.11.14、PyTorch2.6.0+cu124、CUDA12.4、NumPy1.26.4、SciPy1.14.1、PyG2.7.0；固定解释器 `/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11`。
测试及诊断均限于允许CPU集合，测试禁用CUDA；运行使用严格确定性算法与 CUBLAS_WORKSPACE_CONFIG=:4096:8。

## 开发期完整续跑证据

6案例各检查6候选，共36个，全部基准轨迹完整结束；11个候选通过，覆盖5案例；25个因平局或存在更优立即派遣而拒绝。

| 案例 | 检查数 | 接受数 |
|---|---:|---:|
| case_0294 | 6 | 0 |
| case_0343 | 6 | 5 |
| case_0089 | 6 | 1 |
| case_0268 | 6 | 1 |
| case_0183 | 6 | 3 |
| case_0249 | 6 | 1 |

全部正负分支保留在 `result/hkbz_train_logs/stage2_wait_labels_20260906_gpu0_half/probe*_r1/evidence.jsonl`。
各文件SHA256：

- probe_r1：`2b2f06023da21b959d90a7d7871332e5e8a5fa300dac960d9aaa226e2d1974ad`
- probe_case_0089_r1：`20fa82c7dda925b986bdbf00f323a87c84a7bf01e0144e434af70fe6b8d752a5`
- probe_case_0268_r1：`5b627dee5e9231cd28bb7d25c04ee808fa3b14ae63534a55f8535a749b499f19`
- probe_case_0183_r1：`6ae7a9866e6b045dfe7fb00e9eeb418217510da439d1a861f3bfdc2b06b1fa77`
- probe_case_0249_r1：`021f04f977892b730aacb1181eb4bfca78723ffff89d5d6bda464d609676a23a`

上述探查发生在开发过程中，不替代当前锁定代码的在线RPC、真实GPU GRU和训练复验。

## Canary r1 已启动

启动：2026-09-06 15:23:16 CST。
服务：`hkbz-stage2-verified-wait-20260906-gpu0-half-canary-r1.service`，MainPID2749211。
套件：`result/hkbz_train_logs/stage2_verified_wait_20260906_gpu0_half_canary_r1`。
M2 PID2749249，M3 PID2749250，共享评测器PID2749224；均处于训练前评测阶段（后续以运行文件为准）。
Manifest SHA256：`68dbc14905fe685953e5fbd9ac0e5cfdddcc26dc1481bf4428bec8f7b6803841`。
228文件源码归档 SHA256：`f244489e9f84be274cfd759a4e9155703da2bd92efa37cafd4fe3e2f295f617b`。
反事实配置 SHA256：`8ab049b68b0de6f327bd09b10bc223b90d7bc17d2f8545cf5e682b091a9cf3aa`。

仅 GPU0（UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`）。systemd已确认 AllowedCPUs/CPUAffinity均为0-31,64-95。
M2用16-23,80-87；M3用0-7,64-71，与M0共享；评测24-29,88-93。M0/M1不停止，GPU1不触碰。
启动前GPU0显存3594MiB；共享权限严格绑定原M0/M1 manifest及其已登记PID，拒绝其他GPU0作业或不足显存。

## Canary 最终结果

两组各2 epochs全部完整完成；两训练进程退出码0，服务inactive/dead，ExecMainStatus=0，GPU0复验上下文全部释放。
最终报告 `complete=true`、`canary_contract_passed=true`，两组 `integrity_passed=true`、`warmstart_exact=true`；228个代码指纹未变。
报告 SHA256：`fe90400e68cfd26f081f58c66fd2d7c5f5af6b98d5b10abb8b1a50b2e7aa0bbe`。

每组每轮完成562批向量环境步、994个有效环境决策、252次优化更新；触发1次历史Blocking修正，无匹配审计失败。
每轮12份成对证据，5个有效等待组/1案例、7个拒绝；不完整分支0。
有效等待最短1.666666666666515秒，最小条件Cmax优势190.66666666666242秒；该优势不是已训练策略的评测改进。
原浮点边界各单独计数1次，temporal_defer=0。等待损失非零，全部日志与缓存逐项一致。
第一轮两组合计仅计算12份证据，其余跨组复用；第二轮每组12份均从相同状态缓存命中。
修正后的4案例训练前评测与原canary r3逐案例零差。

4案例探索性检查：严格选择后M2保留起点；M3选择E2，平均Cmax从9182.75降到9111.25（−71.5秒，约−0.78%），4案例均改善。
缺少ood_scale覆盖，且只有4个评测案例和一个训练种子，不能证明全面优化、超越IGA180/1800或Stage3收益。

## Pilot 已启动

启动：2026-09-06 15:56:38 CST。
服务：`hkbz-stage2-verified-wait-20260906-gpu0-half-pilot-r1.service`，MainPID2757008，active/running。
套件：`result/hkbz_train_logs/stage2_verified_wait_20260906_gpu0_half_pilot_r1`。
M2 PID2757053（16-23,80-87），M3 PID2757054（0-7,64-71），共享评测器PID2757018（24-29,88-93）。
已核实三者GPU上下文均为GPU0；systemd AllowedCPUs/CPUAffinity仍为0-31,64-95。GPU1既有任务未改动。
M0/M1仍运行，原224源文件校验全部未变。

Manifest SHA256：`39da2dbabf501588b4cc127b384e937dfe33699ed5e4a584bdcadbc7b8ec9a5d`。
源码归档 SHA256：`3f903eb5fdd0bd86fd86b6995e4ef0b363c3c83bad579b0dda8439b93e05f83e`；其中228个文件指纹逐一与已通过canary完全相同。
反事实配置仍为 `8ab049b68b0de6f327bd09b10bc223b90d7bc17d2f8545cf5e682b091a9cf3aa`。
绑定canary报告与manifest哈希；不跳过来源一致性检查。

两组均从原B0权重 `b7740b2b688c83dc7fa65bed6381243cdf2f6675f4b96808ff05a41d4e44e7e8` fresh fork，未恢复优化器/RNG，未从canary或Emergency续训。
固定240案例（iid120、ood_stress108、ood_scale12），24 workers，每轮10个完整rollouts，共2 epochs，PPO epochs=0。
每epoch至少8等待组及4不同案例，否则停止；开发期11个正例覆盖的5案例均属于该固定训练集，但实际pilot覆盖仍须在线审核。
外部M0/M1的起点、训练顺序/预算、评测合同已核对一致；最终对照须等待其完整审计后才计算。

**交接时两组处于shared_eval_queued；评测器已开始pre_supervised，strict deterministic algorithms、12 workers、tune60。**
逐案例零差回放尚未完成，尚未进行pilot梯度更新；通过后自动进入E1，任何复验差异或标签覆盖不足都会停止，不盲目重试。
后续进度以该套件suite_status.json及各run1/run_status.json为准。不会自动进入RL、正式确认或Stage3；科学优化目标尚待pilot结果验证。
