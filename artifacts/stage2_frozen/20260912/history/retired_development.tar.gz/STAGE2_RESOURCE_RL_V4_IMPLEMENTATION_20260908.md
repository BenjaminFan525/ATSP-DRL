## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-08
- Verification Status: UNVERIFIED（新实验效果未验证；工程证据分项记录如下）
- Version Label: stage2_resource_rl_v4_implementation

# 实现与数据对齐

新增独立 V4 learner、准备器、控制器、GPU0 启动器、工程测试及回归测试。
V3 入口保留；原 ResourceLearner 仅增加默认不启用的采集 hook、编码缓存、价值特征与动作轨迹采集能力。
未修改环境物理规则或 actor 的合法动作定义，未解冻 S1/shared/R1。

- PPO-R 使用冻结 B0-H 的同案例完整 Cmax 作回报基线；不训练其 critic。
- PPO-V 使用有限预热价值头；当前 rollout 的优势在拟合该批价值目标之前固定。
- 每个 24 案例采集批次包含 4 个固定 6 案例计算单元；采样、reference 和 replay 成员/行序相同。
- 每个 minibatch 从零使用当前权重重放完整案例，仅在案例组完成后更新一次。
- 每批 2 遍，最多 8 个 actor steps；两组交替完成一批，不并发超用 CPU。
- 8 GiB 上限的冻结 encoder 原 dtype 缓存、完整 post-update KL、真实 Adam step 计数。
- 分开最大绝对 Cmax 变化与最大逐案例退化，保留全部负例和失败状态。
- 新增有版本静态交接检查；PPO-R 价值头标记未训练，Stage3 需新 critic，不自动启动。

数据来自历史 B0/N0-N3 同一 sampling audit：train600 中固定 train240，IID120/stress108/scale12；
每组 2 轮覆盖、480 完整 episodes、最多 160 actor steps；完整 tune60（30/27/3）。
按原 24 worker 连续 shard 的逐列次序访问案例。240 个内容哈希均与历史教师索引匹配；train/tune 零重叠。
不是 train600 全量，也不再使用计划草案的 train96/tune12。

资源固定物理 GPU0、CPU 0-31,64-95；GPU1 现有任务的实际亲和性为 32-63,96-127，未修改。
总实验上限 1708 case-episodes、24 小时；不自动重试、追加组、多种子、BC 对照或 Stage3。
详细合同见 `STAGE2_RESOURCE_RL_V4_20260908.md`。

## 工程验证记录

CPU 最终回归：86 项通过（13.620 秒）。包括 resource_rl、resource_rl_v4、joint_training、
stage2_transition、stage3_joint_finetune；新增分组数值合同、历史 worker 访问顺序、内容哈希与预算检查。
`git diff --check` 和新控制器 CLI 导入检查通过。

GPU 工程产物全部保留，不用于科学选模：

1. `result/hkbz_train_logs/stage2_rl_v4_engineering_20260908_gpu0_r1`：首次发现拆分计算形状后
   logp 差 1.430511474609375e-6 超出 1e-6 合同，更新前停止；未放宽阈值。
2. `result/hkbz_train_logs/stage2_rl_v4_engineering_20260908_gpu0_r2`：固定子批次后，两组通过，
   各 4 次真实 actor 更新；logp/ratio/缓存误差均 0；初始动作轨迹完全相同。
   PPO-R/PPO-V post-KL 分别约 0.001258/0.001535，小于 0.01；静态冻结与交接检查通过。
   后续完成了准备器/控制器的历史 worker 数据访问顺序对齐，故最终启动不复用旧源码绑定。
3. `result/hkbz_train_logs/stage2_rl_v4_engineering_20260908_gpu0_r3`：最终冻结源码验收；
   `report.json` 最终 `passed=true`，开始/结束源码哈希一致，且启动准备器再次核对通过。
   共 8 个完整 case-episodes；R/V 初始动作轨迹一致，各 4 次真实 actor 更新；
   R critic 0 次、V critic 22 次。每组核查 86 个有效联合事件，logp/ratio/缓存误差均 0，
   post-KL 分别 0.0012575986439367348/0.001534979654624918；受保护参数与静态交接检查通过。
   工程报告 SHA256：`04bd0af0166013c97a7ca658026b5dcc366b1b7a2fc5bd852e05ed89f2de62ce`。

## 启动状态

完整套件已于 **2026-09-08 10:03:55 CST** 启动：

- Run：`stage2_bc_rl_v4_20260908_gpu0_half_train240_r1`。
- Service：`hkbz-stage2-bc-rl-v4-20260908-gpu0-half-train240-r1.service`。
- 主进程 PID：`3777619`；服务状态 `active/running`。
- 输出目录：`result/hkbz_train_logs/stage2_bc_rl_v4_20260908_gpu0_half_train240_r1/`。
- `manifest.json` 固定 train240、tune60、每组 480 完整训练案例及最多 160 次 actor 更新，
  并绑定最终源码归档、工程证明、历史抽样清单和数据内容哈希。
- 服务硬约束 `AllowedCPUs=0-31,64-95`、`CPUAffinity=0-31,64-95`、
  `Restart=no`、`RuntimeMaxUSec=1d`。24 小时是保护上限，不是剩余时间预测。
- 实测 PID 3777619 仅连接物理 GPU0（UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`），
  `CUDA_VISIBLE_DEVICES=0`，数值库单线程；GPU1 原服务和 CPU `32-63,96-127` 未动。
- 启动核查时主进程与 12 个评估 worker 全部位于评估子区 `24-29,88-93`，
  均包含于授权 CPU 半区；训练时按合同切换到训练子区。

截至 **2026-09-08 10:08:49 CST**，正在执行 `S2RL_F_H`（B0＋Hungarian）全量零更新复验：
已完成首批 12/60，第二批正在推进。正式训练案例完成数为 0；不能把此时进度表述为 actor 已开始训练。
复验、参考 rollout 和有限 critic 预热通过后，控制器将交替执行 PPO-R/PPO-V。

r5 及其后续自动训练保持停止，所有旧产物保留。工程成功不代表本轮优化有效或 IGA 达标。
