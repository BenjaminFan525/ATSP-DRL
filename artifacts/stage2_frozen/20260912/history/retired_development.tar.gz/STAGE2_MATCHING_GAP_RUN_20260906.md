# Stage2 matching-gap P0/P1 启动记录

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent，inline execution。
- Date: 2026-09-06。
- Verification Status: 106项回归测试通过；四组canary工程审计通过；pilot已启动、当前处于训练前tune60复验。Pilot闭环优化效果和IGA目标均为UNVERIFIED。
- Version: physical_edges_typed_empty_wait_v2。
- 范围：P0一致性/基线审计与P1监督对照；不自动启动代价学习、DAgger、RL、多种子正式确认或Stage3。

## 本次修改与验证

实现跨类型的完整设备—请求联合匹配监督、仅对明确temporal_defer且有合法选择的空类型组施加等待监督，以及与真实Blocking优先部署一致的联合/边级指标。保留旧集合损失作为对照，新项默认关闭。补充IGA180/1800历史预算与来源审计、严格回退选模、逐案例/分布/尾部/profile差距报告和失败停止机制。

Canary r1暴露出“设备类型组之间可独立求匹配”的假设错误：一个job/site请求可能涉及多个资源类型。已保留失败目录，并在v2中改为全部资源联合求解；没有丢弃或重配教师身份标签，没有修改环境或部署规则。修复后重新运行完整测试和canary。

验证结果：

- 106项测试通过，覆盖 matching_gap、supervised_pipeline、bc_injection、policy_transfer、structured_credit、bc_replay、stage2_transition、device_lookahead_dispatch。
- 新旧部署解码在400个随机/并列分数用例上逐项一致；错配与跨类型共享请求均产生正确的非零梯度。
- Canary r2四组均完成2 epochs，每组每epoch 211次优化器更新；冻结参数、源权重、训练预算、保存与闭环评测审计通过。
- Canary仅2个训练案例，未观察到有效全空组等待样本，不能据此声称验证了等待方法的效果。Pilot等待分支每epoch至少需要1个有效等待组，否则停止。
- Canary在分组/尾部不退化的严格选择下四组均保留原起点；它仅放行工程链，不证明有科研收益。

## 实际运行

- Run tag: `stage2_matching_gap_20260906_gpu0_half_pilot_r1`。
- Service: `hkbz-stage2-matching-gap-20260906-gpu0-half-pilot-r1.service`。
- 起点：同一B0 Best，seed11，重新建立优化器/RNG；固定S1与R1，不注入R1预测，不收集ready标签。
- 四组：M0原集合对照；M1完整边系数1；M2有效等待系数0.25；M3两者结合。
- 每组固定240个train案例，24 workers，每epoch10轮完整rollout，共2 epochs；tune60评测12 workers。
- 先逐案例零差复验B0起点，失败不开始梯度训练；当前M0/M1/M2已启动，M3排队，最多3个训练进程并发。
- 只使用GPU0；CPU 0-31,64-95，为128逻辑CPU中的64个、32个完整物理核。
- 启动后实际检查：89个服务进程的affinity全部在该半区；4个CUDA进程均位于GPU0；GPU1未使用。Restart=no，48小时硬上限。

## 证据与限制

- [实现与运行前合同](STAGE2_MATCHING_GAP_IMPLEMENTATION_20260906.md)
- [Canary r2测试日志](result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_canary_r2/cpu_regression.log)
- [Canary r2完整审计](result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_canary_r2/analysis/comparison.json)
- [Pilot manifest](result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_pilot_r1/manifest.json)
- [Pilot实时状态](result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_pilot_r1/suite_status.json)
- [Pilot控制器日志](result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_pilot_r1/controller.log)
- [IGA历史参考审计](result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_pilot_r1/iga_reference_audit.json)

源代码与归档、模型、数据顺序、基线和canary证明均由manifest固定哈希。历史IGA计时不是严格180/1800秒预算证明；本轮是单种子tune开发筛选，不能宣布完全超越IGA180或达到IGA1800。完整效果必须等待实际评测，正式目标仍需严格预算基线和独立确认。
