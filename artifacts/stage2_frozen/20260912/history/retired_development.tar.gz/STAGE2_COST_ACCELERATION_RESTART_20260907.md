## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: user-authorized launch-environment repair, restart and monitoring
- Origin Date: 2026-09-07 (Asia/Shanghai)
- Verification Status: launch repair and resource allocation VERIFIED; experiment RUNNING; scientific results UNVERIFIED
- Version Label: gpu0_half_r2_service_path_repair

## 授权与修复范围

用户明确授权“修复并重新启动 stage2 实验”。沿用已批准的新加速流程，仅 GPU0 与 CPU `0-31,64-95`，使用新编号 `stage2_cost_accelerated_20260907_gpu0_half_r2`。没有恢复旧慢诊断、覆盖旧运行、修改 GPU1 或修改 systemd 用户管理器的全局环境。

首次加速运行 r1 于 09:06 在 `prepare_bc_canary` 因找不到 `rg` 退出，未训练。本次修改：

- `onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh`：将调用环境的 PATH 显式传入新服务；在创建清单/目录前检查 Python 可执行文件和 `rg`、`taskset`、`nvidia-smi`、`bash`、`systemd-run`。
- 新增 `onpolicy/envs/HKBZ/test/test_stage2_cost_launcher.py`：模拟缺省服务 PATH，覆盖 PATH 传递（含空格）、缺少依赖、Python 不可用、旧目录保护、dry-run 和非法编号。

根 r1 清单固定的 246 个文件中，只有新加速启动器变化；新 r2 固定 247 个文件，增加上述测试。训练、评估、资源、诊断、成本、匹配、分析、调度、Stage1/R1/B0 权重及复验契约逐项对比未变化。命令只有运行路径与重新生成的执行配置摘要变化；没有改变超参数或降低门槛。

## 启动前验证

- 启动器 `bash -n` 和工作树 `git diff --check` 通过。
- 71 项 CPU 回归测试通过：启动器、调度、加速执行器、适配器、成本目标、BC 复验及匹配规则。测试固定在 CPU `30-31,94-95`，数值库线程数为 1，不进行 GPU 训练。
- 一次真实 systemd 预检：`hkbz-stage2-cost-accelerated-preflight-20260907-r2.service`，退出码 0，运行 6.675 秒；使用服务级 PATH 和原 CPU 半区，准备 `pipeline` 与 `bc_canary` 两份新清单并执行资源/源码/输入哈希验证，两者均通过。
- 预检目录为 `result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_preflight_r2` 及其 `_bc_canary` 同级目录。没有启动这些预检目录中的训练，也没有将预检冒充 canary 训练证明。
- 预检根清单 SHA256：`8b545ba7451b0b661ac299ee1f42ffbd058f112d6b0b3b02b29d5408891a641a`。
- 辅助契约对比脚本第一次将可选的 `reference_validation` 当成必填键而报 KeyError；修正只读检查，使其同时比较字段存在性和可选值后通过。这不是实验崩溃，没有修改训练代码或补造缺失证明。

## 新运行

命令（仓库根目录）：

```bash
env RUN_TAG=stage2_cost_accelerated_20260907_gpu0_half_r2 \
  PYTHON=/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11 \
  bash onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh
```

- 服务：`hkbz-stage2-cost-accelerated-20260907-gpu0-half-r2.service`。
- systemd 启动时间：2026-09-07 11:11:10 CST；控制器 PID 3051140。
- 根目录：`result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r2/`。
- 根清单 SHA256：`dcab4d62d9b08a3caf14b1d218047619fd8c1799b39e3699c0515b3919379c14`。
- 加速源码归档 SHA256：`52872993c6f91a7c37952b0d9bd2b9ede708d0cc56969576ba0ea88012d5d1d2`。
- 执行配置 SHA256：`fe9a15815edcfe4e3160a2959d6dcf0410eca6d4726f4ef22fb5333cb05dd8f6`。
- 新源码命名空间：`29aa5f6c1629a591e7751f4837b92fff964904b518b39fb3ebecc591d5edec46`；不挪用旧命名空间的缓存或证明。
- 原失败步骤 `prepare_bc_canary` 已成功退出，代码 0。
- BC canary 控制器 PID 3051610；N0/N1 进程 PID 3051792 / 3051793；共享评估器 PID 3051641。
- 初次健康检查时三者均已建立 GPU0 上下文；两组完成固定 Stage1/R1/B0 权重加载，正在训练前四案例评估，尚不能称为完成 pilot 训练。
- 11:14 后续健康检查：两组训练前评估已完成，均进入 `resource_supervised / resource_bc_epoch_started`；服务保持 `active/running`，重启次数 0，无输出停滞告警。此时 GPU0 使用 1534 MiB、采样利用率 52%，GPU1 为 15 MiB / 0%。这是小规模 canary 训练，不是 240 案例 pilot 已完成。
- 11:15 心跳继续推进到 `resource_bc_progress`，两组 `device_bc_epoch=1`；启动后 247 个固定文件的 SHA256 再次逐项校验通过。
- 训练前四案例评估两组均 4/4 完成、无超时或循环，所有案例 Cmax 有限。日志中综合/历史最优指标的 `inf` 被标量记录器跳过；四案例子集没有 `ood_scale`，部分综合字段不适用，历史最优字段尚在初始化。这些不等于案例求解失败或已观察到训练损失发散；没有据此改动指标逻辑。

## 资源与阶段约束

- 物理 GPU0：`GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`，GPU1 无本实验计算进程。
- 服务 `AllowedCPUs` / `CPUAffinity`：`0-31,64-95`，32 个物理核 / 64 个逻辑 CPU。
- N0 通道：`0-11,64-75`；N1 通道：`12-23,76-87`；评估器：`24-29,88-93`；子套件控制器：`30-31,94-95`。已检查实际进程及工作进程的 CPU 亲和性。
- `Restart=no`，总硬上限 172800 秒（48 小时）；控制器每 30 秒检查子进程和写入心跳，不自动重试。
- 顺序：N0/N1 canary → N0/N1 pilot → 完整加速等价性与吞吐验证 → 成本诊断 → N2/N3 canary → 条件通过后的 N2/N3 pilot。
- N0/N1 不再等待成本诊断；N2/N3 不绕过完整复验、可学习性与预算门槛。没有启动 RL 或 Stage3。
- 48 小时是硬上限，不是完整实验预计时长；训练 ETA 需根据本次实际进度估算。

## 旧产物保护

启动前已记录下列完整目录内容摘要，后续复核使用相同算法：对每个文件按相对路径排序，记录 `(相对路径, 字节数, 文件 SHA256)`，紧凑 JSON 编码后计算 SHA256。时间戳不作为内容判据。

| 保留目录 | 文件数 | 总字节数 | 内容树 SHA256 |
|---|---:|---:|---|
| `stage2_cost_improvement_20260907_gpu0_half_r1` | 238 | 114665012 | `7bafc8c2d05ba289e381570ceb06b6125d5cb4393128bf6a07face1e2e095ffa` |
| `stage2_cost_accelerated_20260907_gpu0_half_r1` | 12 | 2659062 | `7c4d465bc15436f87ada5cece9380f768b27886c379a3ccd1c325bdeb1782127` |

旧停止/失败状态不改写，原交接记录 `STAGE2_COST_ACCELERATION_RUN_20260907.md` 保留为当时的历史快照；本记录补充用户授权后的 r2 重启。

11:14 在新训练启动后重新计算上述两棵内容树，文件数和内容 SHA256 均与启动前完全一致；两个旧目录全部保留，内容未改动。

## 监控入口

- 根阶段进度：`result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r2/pipeline_state.json`。
- 根心跳：同目录 `controller.log`。
- N0/N1 canary：`result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r2_bc_canary/suite_status.json` 及 `service_logs/`。
- 完成后各阶段单独保存分析报告；截至初次健康检查尚无新研究效果结论。
