## Material Passport

- Origin Skill: academic-research-suite/experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-09
- Verification Status: UNVERIFIED
- Version Label: v5_user_disabled_wallclock_v1

## 授权及边界

用户明确要求“解除超时门禁”。本次解释为取消本轮Stage B的预测时间预算门禁、
控制器/训练worker的墙钟硬截止以及systemd RuntimeMaxSec，不是增加训练轮数。
此前2026-09-10 18:18:20 CST的服务截止不再约束接管后的训练。
原30小时记录作为历史保留，不修改旧manifest、日志或状态来伪造当时配置。

GPU0、CPU `0-31,64-95`、两训练槽、评估互斥、四臂各train240、全部720例
训练评估、KL暂停、数值/血缘/参数隔离检查、病例数量和每例事件步上限不变。
失败不自动重试，不扩展种子/第二轮，不进入Stage C或Stage3。
本次授权允许既定有限工作量运行至自然结束，不授权无限追加实验。

## 无重复采样的阶段边界接管

原r4控制器及setup worker已把截止时间读入内存，不支持配置热读。
新增r5接管服务先核验旧服务MainPID、精确命令/manifest、父子关系和pidfd，
确认新服务自身RuntimeMaxSec为infinity，只暂停旧调度器，不暂停采样worker。
setup沿用同一进程继续完成原四臂AR复验、B0_H和240例参考采集。

宿主systemd不支持热修改旧服务RuntimeMaxSec，因此不再尝试修改该属性。
过渡期间旧服务及setup内部计时器仍是原配置，未注入或改写其运行时状态；
它们在setup自然完成后即退役，不承载任何新训练，旧截止不传入新训练。
新控制器的预测时间门禁和后续训练墙钟限制均关闭。若setup失败，接管停止，
不重复其病例、不越过科学门禁。接管异常或被终止时恢复暂停的旧调度器；
ExecStopPost提供额外恢复路径。交接完成前不能声称训练worker已经切换。

setup成功退出、540例全部完成且每项AR/H/参考证明重新校验通过后，
在无活动采样的边界终止旧调度器；其终止记录属于显式配置交接，不是科学失败。
新manifest保留全部旧文件hash，复制完成证明与评估/轨迹，原始图池保留在r4
并由hash固定引用，不复制或重采样。旧产物均不删除，旧图池路径不得随意移动。

r5随后从原不可变B0初始化E0/E1、E2/E3；不加载工程更新或setup中的随机critic。
原636例完成工作保留（96工程+540准备）；新增上限1680例（960训练+720评估）。
加上r3失败12例与诊断12例，历史累计物理尝试上限仍为2340。

## 实现与验证口径

所有r4已固定文件保持原SHA256，包括科学训练、环境和初始审计修复代码。
新增worker继承原模型初始化方法、train_one、collect_batch、evaluate、checkpoint、
PPO/critic实现，只替换执行入口中的墙钟检查及进度计时器。
新控制器继承原两槽调度和失败处理；预算预测照常计算并存档，但标记enforced=false。
JSON中的活动hard_deadline_unix为null，不用虚假的远期日期或非标准Infinity。

验证包括：缺失授权拒绝、资源/规模/旧代码变更拒绝、逾期预算仅报告、长时间
进度不超时、无SIGALRM定时器、继承的科学方法及执行初始化/错误处理一致、
非时间门禁不放宽、完成态/成功退出必需、控制器失败恢复和无自动重跑。
具体执行结果和实际接管状态记录到未固定的
`STAGE2_SPLIT_ENCODER_V5_IMPLEMENTATION_20260909.md`，不改动本固定协议文件。
科学优化效果仍为UNVERIFIED。
