## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: plan / protocol revision
- Origin Date: 2026-09-08
- Verification Status: UNVERIFIED（已核对相关代码接口；新协议尚未实现、运行或证明有效）
- Version Label: stage2_bc_resource_rl_v3
- Supersedes: 后续 Stage2 的 supervised-only 限制、RL 条件后置路线，以及全量成本标签作为训练前置条件的安排；不改写已运行实验的 manifest、源码归档、检查点和结果。

# Stage2 协议修订：BC 初始化 + 资源策略 RL

> 下一轮实现已修订为 [V4 完整案例 minibatch 协议](STAGE2_RESOURCE_RL_V4_20260908.md)。
> 根据用户“数据量对齐之前的stage2”，V4 精确复用 train240/tune60、每组两轮覆盖；
> 本文以下 train24/tune12、四小时和整批两步描述保留为已完成 V3 pilot 的历史合同。

## 1. 本次决定与不变的目标

根据用户“修改原有stage2协议，还是把RL环节加回来吧”的决定，Stage2 恢复 RL，主线改为：

`可靠预测头 / 已验证 BC 起点 → 资源 PPO 优化 → Stage2 对标验收 → Stage3 联合微调与迁移验证`

BC 负责提供合法、稳定的初始资源策略；RL 负责利用学生自身完整调度轨迹的真实 Cmax，寻找教师动作之外的改进。RL 是接下来的主研究环节，不再要求 BC、DAgger 或全量反事实成本标签先取得收益。已有合格预测头和 BC 权重直接复用，不为恢复 RL 从头重复预训练。

主目标仍是**完全超越 IGA180，达到或者超越 IGA1800**，验收沿用 [IGA 目标修订版](STAGE2_IGA_TARGET_REVISION_20260906.md)：IGA180 在锁定评测集上逐案例不劣、总体严格更优；IGA1800 总体、IID/OOD 分组及尾部不劣，不引入正的退化容忍幅度。相对 BC 的小幅提升只是研究进展，不是目标达成。

本次只修订协议，不修改训练代码或启动命令，不启动实验。r5 及后续自动训练保持停止，全部已有产物保留。后续实现和启动需要单独授权；本文的参数是拟定配置，不是现有入口已经支持的参数组合。

## 2. Stage2 的训练边界与固定起点

| 部件 | 资源 BC 初始化 | Stage2 资源 RL | Stage3 |
|---|---|---|---|
| Stage1 飞机 actor / GRU、共享图 encoder | 冻结 | 冻结，包括 critic 的反向传播路径 | 单独协议决定联合更新 |
| 已验证 R1 Ready 预测头 | 冻结复用 | 冻结复用，不使用教师事实时间戳重新标注学生状态 | 保留来源证据 |
| 普通移动设备、R014 的 actor / GRU | 监督学习或加载合格权重 | 允许 PPO 更新 | 可继续更新 |
| 资源/团队 critic | 不把旧 BC critic 当作合格价值函数 | 新建并训练团队价值头，禁止更新受保护 encoder | 默认新建优化器与价值归一化状态 |

首个验证从已经完成当前运行时复验的 B0 `Best` 分叉，属于 warm start，不是旧 PPO 的精确 resume：

- [B0 检查点](onpolicy/scripts/results/HKBZ/simple/gnn_mappo/stage2_bc_injection_20260905_gpu0_half_pilot_r2_B0_none_seed11/run1/models/checkpoint_Best.pt)，SHA256 `b7740b2b688c83dc7fa65bed6381243cdf2f6675f4b96808ff05a41d4e44e7e8`。
- S1 SHA256 `8ce0244f9b0b3877e2cc581a2479a6e5edab1854c1ed643749712612d0c5379d`；R1 来源 SHA256 `c0c4825946e469b680e764a4c4b9f3bcbcfdaa66ccfb2fee221633b5d3afb1f1`。模型内对应受保护张量另行逐项比较，不能用整个 checkpoint 文件哈希替代张量冻结证据。
- B0 不启用时间特征注入，首轮不同时新增投影或更换预测头。B2 等强 BC 仍作为冻结部署参考；不根据 RL 中途表现切换初始化来源。
- 飞机始终使用同一冻结策略及其原确定性解码；“资源随机采样”不得顺带把飞机改为随机采样。
- actor、critic 优化器和训练 RNG 新建；价值头重新初始化。首轮使用固定回报缩放，不沿用旧 ValueNorm，关闭额外价值归一化，避免把旧统计混入新回报。

研究假设是“从已学会合法匹配的起点直接优化闭环目标，能够改善 Cmax”；这是待验证假设，不是对 PPO 必然胜过 BC 或 IGA 的保证。

## 3. RL 的动作概率与解码合同

当前 [actor](onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py) 在确定性评测时采用全局匹配，随机采样时采用串行自回归决策；全局匹配选中边的分数之和并不是该匹配的随机采样概率。因此本轮不直接把历史 Hungarian 输出的 `log_prob` 填入 PPO。

首轮只采用一个可检验的行为策略：资源按固定顺序自回归采样，前序选择占用的请求实时从后续条件 mask 中移除。PPO 重放同一组已执行动作、同一顺序和条件 mask；确定性主评测采用同一解码器的逐步 argmax。保留原 Hungarian B0 为独立冻结对照，不将解码器替换带来的变化算作学习收益。

对一个资源联合决策，定义：

`log πθ(a_resource | s) = Σ_j log πθ(a_j | s, a_<j, legal_mask_j)`

`ratio = exp(log πθ(a_resource | s) − log πold(a_resource | s))`

- `j` 只包括实际参与本次资源决策的普通设备和 R014；飞机、不活动设备和 padding 不进入资源 ratio。只有一个合法动作的强制决策概率为 1、log-prob 为 0。
- 每个资源联合决策用一个团队优势、一个 clipped surrogate；不得一边求联合 ratio，一边又按设备数重复累计该联合损失。轨迹贡献按固定案例采样设计聚合，不通过各案例自身的决策数倒数偷偷重加权目标。
- 采样、记录、环境执行与 replay 必须动作相同；环境若会修正非法动作，必须修正采样支持集，不能训练未执行动作的概率。
- 监督用的“同一 pre-claim 请求池全局打分”与 RL 的“前序已 claim 条件分布”必须分开；请求 `return_log_prob_components` 不得悄悄改变 PPO 分布。
- RNN reset、序列 chunk 边界和 hidden-state 来源需明确；actor 输入只能包含决策当时可观察的状态与过去历史，完整轨迹终局信息只进入训练回报，不能泄露为推理特征。冻结 BC reference 使用其自身对同一历史的 RNN replay。

更新前做一次小型正确性检查：零更新时 rollout/replay 的动作、mask、顺序完全相同，log-prob 最大绝对差不超过 `1e-6`、ratio 与 1 的最大差不超过 `1e-5`；小型可枚举合法动作集的联合概率和为 1。再确认 critic-only 更新不改变 actor，资源更新不改变 plane/shared/R1。检查失败先修接口，不跑长训练，也不转回大规模成本标签诊断。

## 4. 优化目标、回报和稳定性

采用资源联合动作的 clipped PPO；其方法依据是 [Schulman 等，Proximal Policy Optimization Algorithms](https://arxiv.org/abs/1707.06347)。本文对冻结边界、解码器和预算的选择属于本项目方案，不是论文对本任务有效性的证明。

首轮使用已有 `team_time` 思路：完整成功轨迹中，在物理时间 `t` 的价值目标为 `G_t = −(Cmax − t) / 10000`，`gamma=1`，直接用完整轨迹 Monte Carlo return-to-go，不启用 GAE。减去已经发生的时间只是形成剩余时间目标，优化的实际终局指标仍是 Cmax，不增加等待、提前到达、预测迟到或 IGA 势函数奖励。环境终局目标、决策时间与 [buffer 回报构造](onpolicy/utils/shared_buffer.py) 的一致性必须有小样本断言。

一次真实 rollout 即可提供这些回报；不需要为每个状态展开多个反事实分支，也不调用 IGA 搜索生成成本标签。完成状态必须经过环境判定：cycle、timeout、截断或未完成轨迹不能拿当前较短的物理时间充当成功 Cmax。首轮出现这些异常时保留记录并停止该试验，报告未完成，不自动丢弃坏案例继续选模。

首轮拟定单一配置，不做参数网格：actor LR `1e-5`、critic LR `1e-4`、clip `0.1`、每次完整采集后 PPO 优化 `2` 遍、熵系数 `0.001`、采样近似 KL 上限 `0.01`。共同优势在一次采集后计算并固定，不在同一批 PPO epochs 中反复改写。KL 超限停止该批剩余 PPO 更新并记录，不回滚后自动重跑来隐藏超限。

主方法使用 `0.01` 系数的冻结 BC 条件分布 KL 锚：在同一学生访问状态、相同前序动作和合法 mask 上，计算 `KL(π_B0 || πθ)`，每个资源联合事件对有效、非强制条件分布取均值；熵项也使用相同资源范围的条件分布均值，不包含飞机。它是局部条件分布正则，不冒称 Hungarian 匹配的精确联合 KL，不需要新教师搜索或成本标签。全程记录 PPO、锚定和熵项的实际量级；若锚定压过优化信号，在本轮结束后再提出去锚消融，不中途改系数。

critic 可在首个已收集批次上独立预热，最多 `10` 次优化步，然后冻结该批用于 PPO 的优势。预热复用现有 rollout，不产生另一套标注任务；如价值拟合仍不足，记录这一风险，不能把“critic 预热”变成无限期前置工程。

## 5. 最小验证实验：先回答 RL 是否有闭环收益

首轮只保留下面的对照；旧 N0–N3 名称和 r5 产物不复用为新结果。

| 标识 | 内容 | 用途 |
|---|---|---|
| `S2RL_F_H` | 原 B0 + 原 Hungarian 解码，零更新 | 原部署质量对照 |
| `S2RL_F_AR` | 同一 B0 + 确定性自回归解码，零更新 | 单独量化解码改变 |
| `S2RL_BC` | 同一 B0 继续资源 BC，学生自回归采集、当前合法状态下查询资源教师 | 等案例交互预算的继续模仿对照 |
| `S2RL_PPO` | 同一 B0 + 资源 PPO + 固定 BC-reference 锚 | 主优化方法 |

两个训练组都在学生自身轨迹上采集；BC 组教师只提供监督，不替换 rollout 中的学生动作。PPO 组不执行教师混合动作。两组均用自回归 argmax 评测，所有已保存候选都相对 `F_AR` 与原 `F_H` 报告，不按案例择优拼模型。

任何梯度更新前，`F_H` 必须在下面选定的 12 个开发案例上与绑定的原始评测逐例复验 Cmax 和步数，使用原严格数值合同；来源权重与加载后权重逐张量一致。`F_AR` 不要求与 `F_H` 数值相同，其差异正是解码对照要测量的结果，不能用它放宽 `F_H` 的回放标准。

拟定预算和数据纪律：

- 训练 seed `11`；从已有 train600 中按内容哈希锁定 `24` 个案例，IID/stress/scale 分别 `12/10/2`。两个训练组各采集 `2` 轮，每轮每案例完整运行一次，即各 `48` 个 case-episodes。BC 每轮优化 `2` 遍；PPO 的 `2` 遍优化不等于再次收集 `2` 轮环境轨迹。
- 从已用于开发的 tune60 按固定规则预选 `12` 个案例（`6/5/1`），与训练哈希去重；只做零更新和末次候选评测，不每个 minibatch 全集评测，不打开 gate120 / finalblind。这个规模只能筛选学习信号，不能估计可靠的 OOD/tail 置信界或证明 IGA 达标。
- 完整案例预算相同不代表决策数、教师查询、梯度样本、优化步数或墙钟完全相同；这些必须分别记录。PPO 的成本标签查询数应为 `0`。
- 正确性检查预算最多 `30` 分钟；整个最小试验含检查、预热、对照和评测最多 `4` 小时墙钟。这是预定投入上限，不是已测得的耗时预测。到上限保存产物、停止并报告未完成，不自动加时、重试或排队扩大训练。
- 后续启动沿用物理 GPU0 与 CPU `0-31,64-95`，所有训练、评测和监控子进程合计受此半区约束；最多两个训练任务，不把“每任务半机”叠加成整机占用。实现时先以单任务测吞吐，再决定是否在同一 GPU0 内并发；不占 GPU1。

预先区分两种筛选结果：相对 `F_AR` 有提升，说明有同解码器学习信号；只有主方法同时超过 `F_H` 和继续 BC 对照，才支持下一档验证原部署策略的实际改进。首轮推进线拟定为相对 `F_AR`、`F_H` 平均 Cmax 均改善至少 `0.5%`，优于 BC 对照，且这 12 例上的 IID/OOD 分组及最差案例 Cmax 不退化、零 cycle/timeout。这里的 `0.5%` 只是投入筛选线，不替代 IGA 主目标，也不是统计显著性标准。

若只有同解码器提升而仍不如原 Hungarian B0，结论应是“RL 有局部学习信号，但部署净收益未成立”；先检查解码损失，不自动加轮数。若没有收益，分别用执行动作变化、回报/优势方差、critic 拟合、clip/KL、锚定项与 Cmax 变化定位问题，不根据 BC loss 或 surrogate loss 下降宣布成功。

## 6. 从最小验证到正式 Stage2 / Stage3

通过小实验只意味着值得继续，不自动触发后续训练。下一档先将锁定候选与冻结 B0/B2 在完整 tune60 上配对评测，再安排有限扩大的 train240 训练和至少三个下游训练种子；具体采集轮数根据小实验实测吞吐、收益趋势和明确预算另行锁定。不得预先排数天的全量流水线。

IGA180/1800 的旧 tune60 结果仅作历史参考：[已有审计](result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r3_bc_pilot/iga_reference_audit.json) 未证明其在当前运行时严格遵守名义搜索时限，不能凭旧表宣布正式达标。确认阶段须统一案例、冻结飞机策略、H2/F4 规划、合法动作、信息范围和真实预算，完成当前运行时基线核验；IGA1800 是包含 IGA180 incumbent 的累计 1800 秒，不是另加 1800 秒。该正式基准工作不作为小型 RL 信号实验的前置任务。

模型/预算/选模规则锁定后，按 [IGA 验收协议](STAGE2_IGA_TARGET_REVISION_20260906.md) 使用独立确认集和多种子报告配对差值、不确定性、所有退化与失败；tune60、曾用于选择的 gate120 不能冒充独立证据。未达绝对目标就如实记录差距。

Stage3 交接需同时保留：完整模型、S1/R1 来源及冻结证据、BC 起点、RL 完成状态、实际训练预算、行为/评测解码器、奖励合同与选模依据。Stage3 必须显式沿用交接解码器并先零更新回放；若改解码，重新单列对照，不能静默切回 Hungarian。后续相同 Stage3 交互预算下比较原 BC 起点与 RL 起点的最终绝对 Cmax 和学习曲线，静态文件兼容不代表动态迁移有利。

## 7. 当前实现缺口与交付要求

下列是之后代码工作的边界，不是本次已完成实现：

1. [Stage2 runner](onpolicy/runner/shared/hkbz_runner.py) 目前硬性要求 `num_episodes=0`、`ppo_epoch=0`，并拒绝资源 BC 检查点直接接 PPO。需要显式的 BC→资源 RL 模式、可跳过已完成预训练的 warm-start 入口、资源专用冻结和优化器分组；保留旧 supervised-only 模式的历史可回放性。
2. [策略接口](onpolicy/algorithms/gnn_mappo/algorithm/MAPPOPolicy.py) 与 [PPO trainer](onpolicy/algorithms/gnn_mappo/gnn_mappo.py) 已有采样、动作重放和 PPO 构件，但现有 `joint_team_ppo_scope` 只有 `plane/all`，不能只开一个旧开关就视为资源概率合同通过。须证明资源专属 mask、条件 log-prob、团队 critic、BC reference 和第 3 节的检查真正一致；单测中也要覆盖 R014 和 no-op。
3. [阶段交接校验](onpolicy/utils/training_stage.py) 当前只接受 `resource_supervised_completed` / `supervised_only` 的 Stage2→Stage3 来源。新协议须增加带版本的“资源 RL 完成”来源及其独立验证，不能只放宽旧条件，也不能借 `joint_finetune` 绕过 Stage2 的冻结边界。
4. 新运行使用独立 `stage2_bc_rl_<date>_<tag>` 目录，输出不可变 manifest/source archive、逐例 pre/post 评测、所有末次/选中 checkpoint、学习日志和终态。每 `30` 秒记录所属阶段、已完成/总 case-episodes、环境事件、优化步数与已用墙钟；硬超时和人工停止都记录未完成状态。
5. 现有 cost-improvement / accelerated 入口不接到新主线；成本标签、全量分支展开和旧 microfit 仅为可选独立研究工具。未经新的实验授权，不恢复 r5、不启动 N2/N3、不自动进入 Stage3。

协议修改完成的含义是：RL 已恢复为 Stage2 的正式研究环节，必要的接口适配与最小验证要求已写明；不代表代码已支持新模式，也不代表实验取得任何优化效果。
