# Stage2 V4 加速续训记录（2026-09-08）

## Material Passport

Origin: 本仓库、原 V4 固定清单和完整批次检查点。Mode: academic-research-suite / experiment execution，单代理顺序执行。Version: v4_execution_cache_sync_v1。Status: 工程逐位验证通过，已启动检查点续训；科学目标尚未验证。

## 授权与不变项

用户明确要求加载加速并从最近 checkpoint 继续训练。仅允许物理 GPU0 和 CPU `0-31,64-95`。GPU1 及其 CPU 半区不在操作范围。保留原目录的全部产物，不重写原指纹化源码；新增隔离入口。旧服务在开发和初步复验期间继续运行；完整采样逐位对照通过后，在 R 第 10 轮完整检查点提交边界停止旧服务，释放 GPU 争用，再完成更新参数/优化器的最后对照。新生产进程仍须等待全部对照通过。

保持原 train240 / tune60、每组 2 个 epoch / 20 个 collection / 480 个完整训练案例回合、每次 24 案例、固定 6 案例小批次、2 次 PPO pass、TBPTT16。保持 FP32、原概率容差、冻结参数、KL 停止规则、两种优势定义。无新增训练轮数、成本标签、自动重试、自动晋级或 Stage3。

## 加速实现

- 同一步的行为前向、概率复验和 B0 参考前向复用已组装输入；不缓存可训练 GRU 的隐状态。
- 每个固定小批次的图、元数据和冻结编码只准备一次。GPU 复验实测 6 案例组需要约 2.01 GiB 输入缓存；正式 24 案例有 4 组，故生产缓存上限定为每进程 12 GiB，覆盖约 8 GiB 的估计占用并留余量，避免原先拟定的 4 GiB 上限使一半输入反复回传。超过预算仍保留 CPU 路径，精度不变；43% 的单进程 allocator 硬上限不变。
- 诊断统计按原顺序以 FP64 累加，减少逐事件标量回传；所有 finite / legal-support / normalization / mask 检查最迟在 TBPTT 反传前验证，绝不跨优化器更新放行。
- 2 个 CPU 图克隆线程，保持 worker 顺序，不接触环境状态或 RNG。
- R/V 独立进程：R 使用 `0-11,64-75`，V 使用 `12-23,76-87`。评估使用原 `24-29,88-93`，监控使用 `30-31,94-95`。
- 两组训练可并行，两个评估通过文件锁串行使用评估 CPU；一个组评估时，另一个组仍可继续训练。保留历史 H 解码的评估 batch shape。每个进程 CUDA allocator 上限为 GPU0 的 43%，合计 86%，给 CUDA 上下文及非 allocator 开销留余量，不沿用原单进程的 80% 上限。

## 续训保障

从各组 `result.json` 指向的 `checkpoint_round_N.pt` 恢复模型、actor Adam、critic Adam、步数、数值审计计数和 PyTorch RNG。逐张量核验模型与优化器一致。不加载可能含半轮更新的 `checkpoint_interrupted.pt`。冻结参考仍是原 B0，不换成恢复后的 actor；PPO-V 不重置 critic 或重复预热。

复用已完成的源检查、B0 tune60、240 个冻结参考回合及完整中期评估。若第 10 轮检查点已提交但该轮评估尚未完成，先补该检查点的评估，再训练第 11 轮；不允许把新权重冒充旧轮次评估。

沿用原 `hard_deadline_unix = 1788919440.3846061`，即北京时间 2026-09-09 10:04:00 左右，systemd 只授予原来的剩余时间。原实验物理案例预算 1708；切换时如存在未提交的采样/评估，单独记录其尝试次数和有界重算开销（最多一个未提交评估的 60 个案例），不增加已优化的逻辑训练量。新旧物理尝试均纳入续训账本。

## 验证记录

- 新的数学、梯度、恢复和预算单元测试，加原 RL/V4、joint、Stage2 transition、Stage3 handoff 回归：95 项通过，15.632 秒。
- 后续新增“缓存复用、不缓存隐状态、CPU 回退不修改原图”的验证也通过；该文件 10 项测试通过，相关回归累计 96 项。
- 第一轮 GPU 复验在 R 的最终权重逐位对比处失败，所有日志/失败报告保留。根因通过 CPU 最小复现锁定：Adam `load_state_dict` 会直接复用非 capturable 的 CPU `step` 张量，两个对照 learner 加载同一对象后共享步数。只更新 A，B 的 step 也从 1 变成 2。现将两套优化器 state 深拷贝后加载；新增独立性/不可变检查点回归通过。相关 RL/恢复套件 35 项通过，累计相关回归 97 项，未放宽任何容差。
- 最终修复版完整相关回归重跑：97 项通过，13.176 秒。
- 宿主机上的异步图克隆顺序、独立存储/FD、worker 崩溃、IPC 超时测试：4 项通过，16.595 秒。
- 首次宽泛的 105 项组合在沙箱中有 5 项错误：4 项进程 IPC 测试在宿主机验证通过；另一个原有 `test_shard_canary_stops_after_three_percent_regression` 使用缺少 `canary_baseline_makespan` 的旧测试对象，与本次独立 V4 入口无关，未修改该历史测试或生产 runner，不能声称全仓测试通过。
- 新增 Python 模块 AST 和启动脚本 Bash 语法检查通过。
- GPU 修复后旧/新对照复验：`result/hkbz_train_logs/stage2_rl_v4_fast_proof_20260908_r2/`，18 个案例回合完成、服务退出码 0。两组更新后的全模型、actor Adam、critic Adam、完整更新指标均逐位一致，概率 / ratio 误差均为 0。所有测试更新均未写入生产检查点。额外保存完整诊断轨迹和新旧更新状态，避免后续数值诊断重复采样。
- 6 案例小批次的实测更新耗时：R 144.717 → 139.295 秒，V 120.126 → 115.481 秒，单进程减少约 4%；R 采样 162.477 → 166.871 秒，暂未观察到采样提速。该测试用于数值兼容性验证，并非 24 案例、R/V 并行的吞吐量基准；不据此承诺整体倍速。主要整体收益需由生产中的双进程并行计时确认。
- 工程回合单独记账：首轮失败对照已执行 12 个案例回合，修复版执行 18 个，共 30 个；不混入正式训练的 960 个逻辑案例回合。

## 已执行的停止与续训

- 旧服务：`hkbz-stage2-bc-rl-v4-20260908-gpu0-half-train240-r1.service`。已向核验后的主 PID 3777619 发送 SIGTERM，`run_status.json` 为 `operator_stopped`，退出码 130，主 PID 为 0，`Restart=no`。旧目录及检查点、日志、未完成产物全部保留。
- 停止边界：R 第 10 轮、V 第 9 轮已完整提交。R 的中期评估有一个 12 案例批次未提交，需重算；没有回退任何已提交训练批次。
- 旧物理尝试 856，已提交物理回合 844，其中训练回合 456。续训还需 R 240 个训练 + 180 个评估、V 264 个训练 + 180 个评估。原逻辑训练总量仍为 960；含 12 个中断评估重算的物理上限为 1720，工程验证回合另列。
- 新目录：`result/hkbz_train_logs/stage2_bc_rl_v4_fast_20260908_gpu0_half_train240_r1/`。
- 新服务：`hkbz-stage2-rl-v4-fast-20260908-gpu0-half-r1.service`，北京时间 **2026-09-08 17:17:29** 启动，控制器 PID 3837766，`Restart=no`，启动时 RuntimeMax 为原剩余 60390 秒。
- R worker PID **3837782**：从 `checkpoint_round_10.pt` 恢复，actor step 80、critic step 0，先补第 10 轮 AR tune60。
- V worker PID **3837783**：从 `checkpoint_round_9.pt` 恢复，actor step 72、critic step 650，正在训练第 10 轮。没有重新预热 critic。
- 两组 `workers/<arm>/checks/full_checkpoint_restore.json` 均为 passed，模型和两套 Adam 状态精确恢复，冻结参考确为原 B0。
- 启动后核验：39 个服务进程、87 个线程均未超出 `0-31,64-95`；两个 CUDA worker 均位于物理 GPU0（UUID `GPU-744c1334-98c8-5318-e799-7ad15eea1fbf`）。GPU1 未用于本次续训。
- 当前处于采样/评估阶段；GPU 常驻回放缓存会在 PPO update 阶段按需填充。12 GiB 是每进程缓存上限，不是启动时预占显存。

## 入口

- `onpolicy/utils/stage2_resource_rl_v4_fast.py`
- `onpolicy/utils/stage2_resource_rl_v4_resume.py`
- `onpolicy/scripts/train/prepare_stage2_resource_rl_v4_continuation.py`
- `onpolicy/scripts/train/continue_stage2_resource_rl_v4.py`
- `onpolicy/scripts/train/launch_stage2_resource_rl_v4_continuation_gpu0.sh`

本记录不构成任何 IGA180 / IGA1800 科学目标已达成的证据。
