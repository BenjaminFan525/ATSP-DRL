## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: user-authorized timeout repair, deterministic regression and continuation
- Origin Date: 2026-09-07 (Asia/Shanghai)
- Verification Status: unit tests and GPU prefix integration VERIFIED; full-load terminal regression RUNNING; scientific results UNVERIFIED
- Version Label: gpu0_half_r5_amortized_timeout_v2

## 当前结论（2026-09-07 22:07 CST）

已修复高并发成本分支的重复计时缺陷，停止 r4，保留全部旧产物，启动 r5。新流程当前处于 `timeout_regression`，不是 N2/N3 正式训练。完整终局复验尚未完成，因此本记录不声称实际 29 个候选已经全部完成，也不声称获得新的研究优化效果。

本次遵循 academic-research-suite 的可复现性要求：固化失败批次、参考输入与完整终局结果；新源码重新取证，不沿用旧版本成本门禁；短检查不作为终局验证证明。没有改变训练方法、损失、教师、模型、研究案例或完整终局标签定义。

## 根因与旧运行证据

原 `run_fanout` 把一次全批次环境 RPC 的耗时完整记到每个存活分支上，并把并发 actor 的重叠主机延迟作为各分支私有计算时间。16 个并发分支、4 条推理通道下，计费会重复包含共享时间与竞争等待，导致仍在正常推进的分支提前耗尽 600 秒工程预算。

- r4 第一个实际批次：24 个环境、10 个选中状态、29 个逻辑候选、20 个不同完整干预；其中 18 个 `wall_timeout`、11 个完成。
- 停止前 r4 共持久化 28 个状态、87 个候选：27 个 `wall_timeout`、60 个完成。
- 同批次 r3 的 29 个候选全部完整结束。已比较两轮的环境快照、冻结策略、历史、下一步双 GRU 状态、完整首动作以及候选身份，未发现起点不一致。
- r4 先前的小型 2/24 环境测试只有 3–4 个不同干预，不能覆盖 16 个分支同时存活的实际失败负载；因此 r5 新增该真实负载复验。
- 不把 r4 截断分支后缩短的用时当作有效加速。

旧证据：`result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r4_cost_diagnostic/diagnostics/cost_evidence_epoch1.jsonl`。r4 根状态结束于 21:36:17 CST。已对该服务执行受控停止；systemd 最终显示 `MainPID=0`、`Result=timeout`，这是本次停止时的有界清理结果。没有改写旧失败报告，也没有删除或覆盖历史目录。

## 修复内容

1. 新增 `amortized_shared_wall_and_progress_deadline_v2` 超时契约：全批次 RPC 的实际墙钟时间在存活物理分支之间分摊；actor 池实际墙钟时间按各分支报告延迟归一化分摊，同一时间区间只计一次。原始重叠延迟另行保存，不再冒充私有计算时间。
2. 仍使用数值为 600 秒的分支工作预算，但明确采用新的分摊口径，不等同于原始墙钟时限。保留完整终局步数上限；增加连续 600 秒无完成 RPC/推理操作的硬看门狗；保留原总实验截止时间。看门狗触发退出码 124，不自动重试，不把不完整 Cmax 当标签。
3. 新契约下，诊断中出现任何不完整候选，会先保存已有证据再立即停止，不继续收集数小时后才判定失败。
4. 新增真实失败批次复验：从 r3 固定档案恢复完整 24 环境上下文，重算并逐项核对初始动作及双 GRU，再用 16 分支、4 通道完成全部 29 个候选。只有终局 Cmax、终止步数、完成原因与原完整结果完全一致，且缓存重放精确、权重不变，才通过门禁。
5. 新增真实负载轨迹哈希，但不声称其与不存在的旧完整负载轨迹哈希相同。原有小型串行/旧并行/新并行的完整动作、双 GRU 与终局等价性检查仍须在新源码上通过。
6. 复验生成的是 r5 当前源码的新缓存；后续诊断仅在上下文和干预身份完全相同时复用，绝不导入 r3/r4 成本缓存。诊断的工作量估计补回这部分已验证的冷执行时间，避免缓存使后续训练 ETA 过度乐观。

主要实现：`onpolicy/utils/stage2_cost_timeout.py`、`stage2_cost_execution.py`、`stage2_cost_accelerated.py`、`stage2_cost_timeout_reference.py`、`stage2_cost_schedule.py`，以及 `onpolicy/scripts/train/verify_stage2_cost_timeout.py`、诊断脚本、准备器、控制器和启动器。完整技术说明见 `STAGE2_COST_ACCELERATION_IMPLEMENTATION_20260907.md` 的 timeout amendment。

## 已完成验证

- 最终源码 CPU 回归：97 项，96 项通过，1 项 CUDA 项跳过；覆盖超时、推理、续跑、执行器、适配器、调度、启动器、成本目标、分析、阻塞审计和匹配规则。CPU 固定 `30-31,94-95`，数值库线程数 1，禁用 CUDA。
- 合成 16 分支回归能够在旧计时下重现全部误超时，而新计时全部完整结束；真正单分支预算耗尽仍拒绝标签；真正无进展的子进程以 124 退出。
- GPU 严格匹配测试 5/5 通过。
- 真实 GPU0 的 16 分支、20 个不同干预、29 个候选、8 步前缀集成检查通过。冷执行实际用时 23.747 秒，分摊计时 23.321 秒，原始重叠 actor 延迟合计 74.783 秒。冻结权重未变，初始完整动作和双 GRU 与档案一致。
- 前缀检查明确设置 `timeout_gate_passed=false`，不作为完整终局证明。产物：`result/hkbz_train_logs/stage2_cost_timeout_preflight_20260907_r3/timeout_regression_smoke/report.json`。
- 早期前缀检查 r2 因新增复验脚本缺少档案事件步数初始化而失败；已修正脚本、保留失败产物，并使用新编号 r3 检查。没有修改模型或伪造结果。
- 启动器 `bash -n`、`git diff --check` 通过；r5 启动后重新校验全部 260 个固定源码文件，0 项变化。

## r5 启动与资源

仓库根目录执行：

```bash
env RUN_TAG=stage2_cost_accelerated_20260907_gpu0_half_r5 \
  CONTINUE_FROM=/home/fanyx/HKBZ-environment/result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r4/manifest.json \
  FANOUT_WIDTH=16 ACTOR_LANES=4 INFERENCE_MODE=host_matching \
  TIMEOUT_CONTRACT=amortized_shared_wall_and_progress_deadline_v2 \
  PYTHON=/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11 \
  bash onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh
```

- 服务：`hkbz-stage2-cost-accelerated-20260907-gpu0-half-r5.service`，启动于 21:59:44 CST。
- 根控制器 PID：3339503；完整负载复验 PID：3339512。
- 已检查服务和复验进程实际 CPU 亲和性：`0-31,64-95`，64 个逻辑 CPU；GPU0 中观察到复验进程，采样显存 5022 MiB。未使用 GPU1。
- 原截止时间仍是 **2026-09-09 11:44:28 CST**。服务启动时 `RuntimeMaxUSec=1d 13h 44min 44s`，不是重新获得 48 小时。
- 重用已完成且源码/输入/产物审计通过的 N0/N1 对照；不重新训练，不宣称其已达到科学目标。
- 顺序：实际负载超时复验 → 新源码完整等价性及吞吐验证 → 成本诊断 → N2/N3 canary → 容量与研究门槛允许后的 N2/N3 pilot。失败即停止，无自动重试，不绕过门槛。
- 22:06:41 的进度：第一并发批次 16 个活跃物理分支，推进到第 120 步，尚无终局候选完成；实际累计 407.83 秒，分摊计费 402.74 秒。进度文件的 `wall_seconds=0` 是运行中占位，实时用时应读取 `elapsed_seconds`。

## 固定版本与监控入口

- 根目录：`result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r5/`。
- 根清单 SHA256：`57e6a23a9169c8fe57a9662991ade7c7d41c34d96f02a39460f592a327e9c831`。
- 源码归档 SHA256：`d6ea28a4427f1049c2fc21d85624b87cdbd8530da71d98da3a6f8b8e348d1b79`。
- 执行配置 SHA256：`21e3640136d9899ce286eb07176e0c12875a076b21b3d6373a02e4ad326ca24c`。
- 源码命名空间：`9484f90d391ccb2e52e24a24d2c4c056af6574a04d020787191f4d3b940911e1`。
- 阶段状态：根目录 `pipeline_state.json`；控制器日志 `controller.log`。
- 实际批次日志：`timeout_regression.log`；实时分支进度：`timeout_regression/cost_execution_progress.json`；最终门禁结果：`timeout_regression/report.json`。

本文件是运行中的交接快照，不属于已固定的训练源码，不替代之后生成的门禁和研究结果报告。完整批次复验未结束前，只能确认修复代码和短程验证通过，不能确认端到端问题已经验证解决。
