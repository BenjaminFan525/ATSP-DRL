# Stage2 V6 first-block implementation and launch

Material Passport: Origin Skill = academic-research-suite/experiment-agent;
Origin Mode = run; Origin Date = 2026-09-10; Verification Status = UNVERIFIED;
Version Label = stage2_v6_pilot_v1. Experiment running; no scientific success claim.

## Implemented and verified

- Opt-in raw resource view, stable pre-dispatch semantic history and reset/no-op
  contract; legacy graph tensors/default actor path remain unchanged.
- Teacher labels independently bind live request identity to saved observation
  identity and teacher-forced AR masks. Archived genes are decoded without search.
- S1 keeps frozen original GNN and role GRU/pointer heads with a semantic history
  adapter; S2 has independent role-specific 2x128 pair scorers without resource GRU.
- Same48 teacher cases for both arms; equal-case/equal-present-role free-action CE.
  S2 packs observable inputs once and batches256 records per microbatch; both arms
  still take one optimizer step per six complete cases, at most80 steps/arm.
- Checkpoint model/Adam/RNG/schema/source tracking, protected-tensor assertions,
  pinned source bundle, finite episode budget and30s advisory-stall heartbeat.
- The separate V6 critic is provisioned but is NOT trained in this pilot. Formal
  train240, PPO, DAgger extension, further seeds and Stage3 are not auto-launched.

## Verification

55 selected regression tests passed in23.874s (V6, resource RL, V4 fast, BC replay,
V5 and lookahead-dispatch suites). This is not a whole-repository test claim.
GPU0 engineering report:
`result/hkbz_train_logs/stage2_v6_engineering_20260910_gpu0_r3/gpu_smoke.json`.
Six64-event prefixes exercised508 teacher decisions and6640 occupied historical
slots; zero-update max logp difference0; frozen conditional-plane equality,
both arm updates and model/Adam restore passed. All engineering updates discarded.
The prefix contained no real R014 free choices. Complete shared teacher48 data
must establish both-role label coverage before pilot fitting can begin.

## Launched execution

Suite: `result/hkbz_train_logs/stage2_semantic_pair_v6_20260910_gpu0_half_pilot48_r2`.
Systemd unit: `hkbz-stage2-v6-20260910-gpu0-half-r2.service`.
Observed main PID at launch:294756. GPU UUID:GPU-744c1334-98c8-5318-e799-7ad15eea1fbf.
AllowedCPUs/CPUAffinity:0-31,64-95; Restart=no; RuntimeMaxSec=infinity.
GPU1 jobs were not changed. Initial phase: archived IGA180 production replay.

172 planned complete-case episodes:16 archived reference comparisons +12 B0
development +48 shared teacher +24 candidate initial +72 candidate monitoring.
Then stop for pilot review, without automatic long-training promotion.
Engineering prefixes are separate and explicitly discarded. Earlier engineering
reports r1/r2 and the unlaunched prepared manifest r1 were retained; only r2 was
launched as a scientific pilot service.

Monitor `run_status.json`, `resource_ledger.json`, `controller.log`, `references/`,
`teacher_data/`, `S1/`, `S2/`, `evaluations/` and eventual `pilot_report.json`.
