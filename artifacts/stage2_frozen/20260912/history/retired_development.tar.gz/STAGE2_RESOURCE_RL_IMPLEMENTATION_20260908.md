## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: implementation / bounded experiment execution
- Origin Date: 2026-09-08
- Verification Status: IMPLEMENTATION VERIFIED / SCIENTIFIC EFFECT UNVERIFIED（122 项 CPU 回归、两例 BC/PPO GPU 闭环更新及工程检查点静态交接通过；正式运行和优化效果另行记录）
- Version Label: stage2_bc_resource_rl_v3 implementation r1
- Source Protocol: [Stage2 BC + 资源 RL 协议](STAGE2_BC_RL_PROTOCOL_20260908.md)

# Stage2 资源 RL 实现与首轮运行边界

## 实现入口

用户已单独授权本次代码改造及 GPU0 / CPU 半区启动。旧协议文档中“尚未实现、未获启动授权”的描述是上一轮协议修订时的状态，不是本次实现状态。

- `onpolicy/scripts/train/launch_stage2_resource_rl_gpu0.sh`：准备新目录、不可变 manifest / source archive，再启动有硬时限且 `Restart=no` 的独立服务。
- `onpolicy/scripts/train/run_stage2_resource_rl.py`：来源复验、冻结对照、继续 BC / 资源 PPO、末次评测与终态记录。
- `onpolicy/utils/stage2_resource_rl.py`：资源条件概率、完整轨迹 MC 回报、独立团队 critic、冻结 BC reference 和资源 PPO 更新。
- `onpolicy/utils/stage2_resource_rl_handoff.py`：有版本的资源 RL → Stage3 静态交接检查；不启动 Stage3，也不证明动态迁移收益。

这是显式 `stage2_training_mode=bc_resource_rl` 的独立入口。旧 `train_hkbz.py` / `HKBZ_Runner` 的 supervised-only 运行路径保持兼容，不能用旧 BC 命令把 `ppo_epoch` 改大后冒充新流程。

## 数值与冻结合同

复用 B0 Best（SHA256 `b7740b2b688c83dc7fa65bed6381243cdf2f6675f4b96808ff05a41d4e44e7e8`），不重复 Ready 预训练。实际 plane/shared 张量对照 S1，Ready 头对照不可变 R1，B0 加载后全模型哈希一致。

仅四类资源 actor/GRU 前缀和 `team_critic` 可训练；encoder、飞机策略、Ready 头、其他 critic 均冻结。PPO 新初始化团队 critic、优化器与 RNG；不恢复旧优化器或 ValueNorm。BC 对照不更新 critic。

资源动作采用有前序 claim mask 的自回归采样。飞机始终确定性解码。资源联合 log-prob 是有效非强制资源动作条件 log-prob 之和，一次联合事件只有一个团队优势和 clipped surrogate。单合法动作、飞机、padding 不计入 ratio。资源 RL 模式显式切断冻结飞机 GRU 的反向图，避免资源/飞机共享 hidden-state 存储引入错误的 cuDNN backward 路径。

使用 `G_t=−(Cmax−t)/10000`、gamma=1、完整轨迹 MC，无 GAE、无额外 shaping、无成本标签。失败、cycle、超时或截断案例使试验停止，不按当前较短时间冒充完成 Cmax。

PPO 每次完整采集后重放两遍；每遍从零 hidden-state 在当前权重下重建整个前缀，16 步截断梯度，整遍累积完梯度才进行一次 actor optimizer step。因此每组两轮采集最多四次 actor step，不将两遍优化误记为再次采集。BC 使用同样的完整序列重放，但损失是学生状态上的自回归联合教师 NLL，不是旧 N0 的全边/匹配 margin 损失复刻。

BC reference 使用自己的 RNN 状态，重放实际学生动作；条件 KL 为 `KL(B0 || 当前策略)`，系数 0.01，熵系数 0.001。PPO clip=0.1，actor LR=1e-5，critic LR=1e-4。首个现有 rollout 上 critic 最多预热十步，然后固定该批优势。采样近似 KL 阈值 0.01；日志明确记录是在当前遍 optimizer step 之前测得，超限丢弃该遍梯度并停止剩余遍数，不回滚或重试已执行更新。

记录回报、价值与原始优势均值/标准差、explained variance、策略项、KL、熵、clip 数、梯度范数、actor/critic 实际步数和冻结证据。每次非跳过 actor step 必须实际改变资源张量；critic-only step 后检查 actor 不变。

## 本次锁定预算

| 项目 | 本次设置 |
|---|---|
| 冻结对照 | 原 B0 + Hungarian；同一 B0 + AR argmax |
| 训练对照 | 继续资源 BC；资源 PPO + B0 条件 KL 锚 |
| 案例 | train24：IID/stress/scale=12/10/2；tune12=6/5/1；均按内容哈希预选 |
| 训练量 | 两组各两轮、各 48 个完整 case-episodes，共 96 |
| 评测量 | 两个冻结对照及两组末次候选，各 12 例，共 48 |
| 设备 | 仅物理 GPU0；CPU 合计限定 `0-31,64-95` |
| CPU 分区 | 训练 `0-23,64-87`；评测 `24-29,88-93`；监控 `30-31,94-95` |
| 并发 | BC、PPO 串行；每轮 24 个案例环境并行，不启动第二个训练器 |
| 时限 | 服务共 4 小时；运行内正确性检查最多 30 分钟；到限停止，不重试、不加时 |

四小时是投入上限，不是剩余时间预测。独立工程 smoke 的两例轨迹和废弃权重只用于调试，不计入科学训练预算、选模或效果声明；所有失败工程目录保留。

在任何正式梯度更新前，12 例 `F_H` 必须和绑定的 B0 原始评测逐例 Cmax、完成步数严格一致；不得放宽数值容差。`F_AR` 用于单独衡量解码变化。检查失败只留下失败记录，不运行后续训练。

## 产物、检查与不自动开展的工作

本次启动前验证：122 项 CPU 回归全部通过；GPU 工程测试目录
`result/hkbz_train_logs/stage2_bc_rl_20260908_gpu0_half_engineering_r2/` 中
`report.json` 为 passed。BC/PPO 各两条完整轨迹、各一次 actor 更新；PPO 有
三次 critic 更新。两组各检查 64 个采样/重放事件，log-prob 与 ratio 误差均为
0，动作/mask 一致，冻结检查通过。`static_handoff_check.json` 使用真实工程
更新权重与实际预算构造工程合同，通过新静态校验；不算 Stage3 动态验证。
首次工程测试遇到的冻结飞机 GRU backward 错误已修正并有专门回归覆盖，
`engineering_r1` 失败目录保留。

默认运行目录：`result/hkbz_train_logs/stage2_bc_rl_20260908_gpu0_half_pilot_r1/`。

包含 `manifest.json`、`source_bundle.tar.gz`、`run_status.json`（30 秒心跳）、`controller.log`、`checks/`、`evaluations/`、每组逐轮 rollout / update 指标与完整 checkpoint、末次配对 `analysis.json`。模型的 optimizer / RNG 放在独立嵌套训练状态中，Stage3 不继承它们。

资源 RL 检查点只有完成全部声明采集轮数、资源 actor 与 critic 有实际更新、概率/冻结/来源证据通过时才标为 `resource_rl_completed`。Stage3 必须显式使用 AR 解码才能通过静态加载检查，且仍需后续单独授权的零更新回放和动态迁移验证。

首轮投入筛选线沿协议：PPO 比原 Hungarian B0、零更新 AR B0 的平均 Cmax 均改善至少 0.5%，优于继续 BC，对照分组均值与最大 Cmax 不退化、无失败。无论筛选是否通过，均不自动扩容、不自动进入 Stage3。该开发小样本不证明“完全超越 IGA180、达到或超越 IGA1800”。

旧 r5、N2/N3、成本标签与后续自动训练不恢复；所有历史源码归档、模型与结果保留。
