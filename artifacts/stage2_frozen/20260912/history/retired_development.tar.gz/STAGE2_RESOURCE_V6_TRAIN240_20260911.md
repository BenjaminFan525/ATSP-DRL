## Material Passport

- Origin Skill: academic-research-suite/experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-11
- Verification Status: UNVERIFIED (full-data scientific outcome not yet established)
- Version Label: stage2_v6_train240_v1

# V6 train240/tune60: explicitly requested exploratory full-data BC

User request: “启动train240／tune60 全量训练”. This authorizes the previously
discussed two-arm, ten-epoch BC expansion on GPU0 and CPU0-31,64-95 only.
It does not authorize PPO, Stage3, train600, extra seeds or automatic retries.

The preceding pilot completed but neither arm passed its screen. S1/S2 mean
Cmax regressed by1.8280%/3.1151% against B0 on development12. Those results are
preserved and bound into the new manifest/report. This is a manual exploratory
extension, NOT a passed-gate promotion or an IGA success claim.

## Fixed training and data

- Keep historical train240/tune60 cases, content hashes and order. Train groups
  contain6 cases; tune60 runs as5 sequential12-case groups, preserving the exact
  six-case numerical forward membership. Tune remains development, not blind.
- Both S1 and S2 start again from the same B0 source and deterministic V6
  initialization, not the epoch10 pilot checkpoints. Each gets10 complete
  offline epochs,40 Adam steps/epoch,400 steps total. All V6 learner parameters,
  FP32 guards, semantic history, role weighting, LR3e-5, TBPTT16 and S2 raw-feature
  microbatch256 stay unchanged. Frozen plane/GNN/Ready/critic remain frozen.
- Reuse the pilot's first48 teacher trajectories and stateless raw-feature
  caches READ-ONLY after verifying code/teacher/source/data hashes and case
  membership. Collect192 new teacher trajectories for the other cases.
  Neither learned embeddings nor pilot-trained Actor weights are reused.
- Repeat the4-case IGA180/1800 production/projected diagnostic and collect
  current B0 tune60. Require the overlapping pilot B0 cases to reproduce Cmax
  within1e-5 and event counts exactly. No new IGA search or cost-label branches.
- Evaluate both arms before training and after epochs1/5/10. Primary endpoint
  is epoch10. Keep each epoch checkpoint and report full tune60 mean/groups/tail
  and paired results against current B0. The inherited permissive development
  screen is descriptive only; passing does not certify IGA or Stage3 objectives.

## Accounting and execution

748 new complete environment case-episodes =16 reference +60 B0 +192 teacher
+480 candidate development. The reused48 teacher episodes are separately
identified; the corresponding logical budget including reuse is796. There are
4800 offline supervised case presentations and800 total Actor optimizer steps.

One process alternates S1/S2. Train CPUs0-23,64-87; evaluation24-29,88-93;
heartbeat30-31,94-95. No restored wall-clock kill gate; scientific/step/lineage
checks still apply. Invalid trajectories stop and preserve outputs. Restart=no.
Stop after full_report.json for manual review; never automatically start PPO.

Separate prepare/run/launch entries have the suffix resource_v6_full. Original
pilot source and artifacts are not edited. A source snapshot, passed versioned
CPU regression proof and the unchanged learner's GPU proof are required before
launch. Reused caches are externally referenced, not copied or overwritten.
