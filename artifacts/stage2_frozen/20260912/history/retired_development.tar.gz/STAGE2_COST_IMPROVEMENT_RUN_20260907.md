# Stage2 cost-improvement execution record

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: explicitly authorized implementation and experiment execution
- Origin Date: 2026-09-07
- Verification Status: engineering validated; scientific results pending
- Version Label: joint4_full_gpu_batch_frozen_student_cmax_v1

Latest authorization: GPU0, remaining half CPU only. GPU1/MAIA work is left
running on32-63,96-127; this experiment owns0-31,64-95. No old experiment,
checkpoint or result was overwritten or deleted.

Implementation: STAGE2_COST_IMPROVEMENT_IMPLEMENTATION_20260907.md.
Pipeline: Phase A fixed24 train cases → four-arm canary0343/0444 → gated
N0–N3 two-epoch/240-case pilot. No RL or Stage3 automatic promotion.

Preflight evidence:

- 139 CPU regressions passed in15.518 s on the recurrent-gradient version.
- 140 CPU regressions passed in15.458 s after adding persistent full-state
  evidence, including lossless environment round-trip/no-overwrite testing.
- Python AST syntax, shell syntax and git diff whitespace checks passed.
- GPU probe r1: completed4 joint candidates on a real0343 snapshot; covered
  8 active resource rows,3 ordered cost pairs, protected source unchanged.
- GPU probe r3: exact repeat and backward-ready resource-GRU/eval-mode action
  and hidden-state equality, completed candidates,20 real resource-only Adam
  updates on a discarded copy, original policy unchanged.
- The20-step regression microfit loss was8.2750310898→6.7988986969; candidate
  regret unchanged (numerical1.82e-12). It did NOT satisfy the50% loss-reduction
  criterion. This was an engineering probe on excluded regression cases,
  not Phase-A's preregistered100-step/four-snapshot learnability gate. That
  gate remains pending; no failed gate is overridden or called successful.
- r2 is only an unstarted immutable preflight manifest; no failed research
  experiment was automatically retried.

Preflight directories:
result/hkbz_train_logs/stage2_cost_improvement_20260907_preflight_r1
result/hkbz_train_logs/stage2_cost_improvement_20260907_preflight_r2
result/hkbz_train_logs/stage2_cost_improvement_20260907_preflight_r3

Planned runtime suite:
result/hkbz_train_logs/stage2_cost_improvement_20260907_gpu0_half_r1

Historical wait audit:1159 unique states;509 accepted waits. At strict1e-6
comparison:307 dispatch-better and319 ties. With the preregistered1-second
cost tie band:305 dispatch-better and321 ties. Both definitions are retained.
Old CPU teacher continuations are audited, never reused as student Q labels.

## Verified launch

Started 2026-09-07 01:50:32 CST.

- Service: hkbz-stage2-cost-improvement-20260907-gpu0-half-r1.service
- Controller PID:2938076; diagnostic/GPU PID:2938087;24 environment workers.
- ActiveState=active, SubState=running, Restart=no, RuntimeMaxUSec=2d.
- Actual service CPUAffinity and AllowedCPUs:0-31,64-95. Read-only /proc
  verification confirmed the diagnostic and all24 direct workers have exactly
  this mask. Future two-trainer/evaluator lanes are disjoint subsets.
- GPU0 UUID:GPU-744c1334-98c8-5318-e799-7ad15eea1fbf. NVIDIA reported only the
  new diagnostic PID on GPU0 (1310 MiB at the first check). GPU1/MAIA remained
  active with its original evaluator and four trainers; no task was stopped.
- Manifest SHA256:a63ea6e9321a83381fd227fc215de849730f71c8bb4c1049c11e9ec849262299
- 231 pinned source/config files; source archive SHA256:
  8f2f825b0a17cbbeb652f644173bf368cfd436c8be559023b696f81876546802.

At verification, Phase A was running its full24-case no-intervention replay
(200 vector steps,109.6 s reported), and the old1159-state label audit had
completed. This is an active diagnostic experiment, NOT a claim that N0–N3
training has started. Canary/pilot remain conditional on their source-bound
diagnostic/learnability/budget gates. Neither scientific success nor the
IGA180/IGA1800 objective has yet been demonstrated.

Live files: pipeline_state.json, diagnostic.log, diagnostics/report.json.
No further edits to fingerprinted source after launch. This execution record
is deliberately outside the immutable source fingerprint to allow status notes.
