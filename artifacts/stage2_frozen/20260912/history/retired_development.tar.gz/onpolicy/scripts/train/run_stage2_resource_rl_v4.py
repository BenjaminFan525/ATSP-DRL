#!/usr/bin/env python3
"""Bounded, alternating PPO-R/PPO-V on historical train240 and full tune60."""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.run_stage2_resource_rl import Progress, arguments, cpus, enriched, metrics, seed
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_policy_transfer import verified_frozen_ready_source
from onpolicy.utils.stage2_resource_rl import file_sha, reset_critic, RESOURCE_PREFIXES, summary
from onpolicy.utils.stage2_resource_rl_handoff import validate_frozen_lineage
from onpolicy.utils.stage2_resource_rl_v4 import ARMS, PROTOCOL, CaseMinibatchLearner, compare_cases, screen_candidate
from onpolicy.utils.training_stage import validate_stage2_joint_finetune_checkpoint


def save_tensor_artifact(value, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f'Never overwrite a checkpoint/cache: {path}')
    temporary = path.with_name(path.name + '.partial')
    torch.save(value, temporary)
    os.replace(temporary, path)


class Suite:
    def __init__(self, manifest_path):
        self.path = manifest_path.resolve()
        self.root = self.path.parent
        self.m = json.loads(self.path.read_text())
        self.c = self.m['training_contract']
        self.progress = None
        self.envs = None
        self.learners, self.arm_state, self.evaluations = {}, {}, {}
        self.total_episodes = 0
        self.attempted_episodes = 0
        self.training_episodes = 0
        self.first_signature = None

    def validate_manifest(self):
        m = self.m
        if m['protocol'] != PROTOCOL or m['execution']['arms'] != list(ARMS):
            raise ValueError('Unexpected V4 experiment or arms.')
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
            raise ValueError('V4 requires physical GPU0 only.')
        if not set(os.sched_getaffinity(0)).issubset(cpus(m['resource_contract']['allowed_cpus'])):
            raise ValueError('Process is outside the authorized CPU half.')
        if (self.root / 'run_status.json').exists():
            raise FileExistsError('No automatic retry or output directory reuse.')
        for name, expected in m['code_fingerprint'].items():
            if file_sha(ROOT / name) != expected:
                raise ValueError(f'Pinned source changed: {name}')
        for item in (m['source'], m['stage1_source'], m['source_archive'], m['engineering_proof'], m['iga_reference']):
            if file_sha(item['path']) != item['sha256']:
                raise ValueError(f'Immutable input changed: {item["path"]}')
        if file_sha(m['source']['evaluation']) != m['source']['evaluation_sha256']:
            raise ValueError('Original B0 evaluation changed.')
        alignment = m['data_alignment']
        if file_sha(alignment['parent_manifest']) != alignment['parent_sha256']:
            raise ValueError('Historical data-volume source changed.')
        parent = json.loads(Path(alignment['parent_manifest']).read_text())
        if [r['case_dir'] for r in m['train']['cases']] != parent['sampling_audits']['11']['case_order']:
            raise ValueError('Not the exact historical Stage2 case order.')
        if file_sha(m['teacher_index']) != m['teacher_index_sha256']:
            raise ValueError('Historical teacher index changed.')
        for key in ('train', 'evaluation'):
            validate_case_content(m[key]['cases'], m[key]['dataset'])
        train_hashes = {r['case_sha256'] for r in m['train']['cases']}
        eval_hashes = {r['case_sha256'] for r in m['evaluation']['cases']}
        if len(train_hashes) != 240 or len(eval_hashes) != 60 or train_hashes & eval_hashes:
            raise ValueError('V4 data coverage/uniqueness mismatch.')
        for item in m['diagnostics']['checkpoints'].values():
            if file_sha(item['path']) != item['sha256']:
                raise ValueError('Historical diagnostic checkpoint changed.')

    def policy(self, *, baseline, fresh_critic):
        # Initialization has its own RNG stream. Collection resets its stream
        # after every model/env construction, identically for both arms.
        seed(self.c['seed'] + 100000)
        policy = GNN_MAPPOPolicy(self.args, self.ac_config, torch.device('cuda:0'))
        policy.load_model_state(self.payload['model'])
        policy.ac.tau = self.args.evaluation_tau
        policy.ac.device_global_matching = False
        if summary(policy.ac) != summary(self.payload['model']):
            raise ValueError('Loaded B0 weights differ from their immutable source.')
        if fresh_critic:
            seed(self.c['seed'] + 200000)
            reset_critic(policy.ac)
            policy.capture_bc_reference(self.payload['model'])
            policy.bc_reference_ac.device_global_matching = False
        return CaseMinibatchLearner(policy, self.args, {**self.c, 'baseline': baseline}, self.progress)

    def collect_batch(self, learner, rows, *, training=False, hungarian=False,
                      evaluation=False, capture_values=False, audit=False, rollout_seed=1, traces=False):
        args = copy.copy(self.args)
        args.seed = rollout_seed
        args.max_train_cases = args.train_sampling_size = args.n_rollout_threads = len(rows)
        if self.attempted_episodes + len(rows) > self.m['execution']['total_case_episode_limit']:
            raise RuntimeError('Cannot start a batch beyond the physical case-episode budget.')
        os.sched_setaffinity(0, cpus(self.m['resource_contract']['eval_cpus' if evaluation else 'train_cpus']))
        dataset = self.m['evaluation' if evaluation else 'train']['dataset']
        self.envs, _ = make_train_env(args, case_records=rows, dataset_override=dataset, evaluation=evaluation)
        learner.policy.ac.device_global_matching = hungarian
        trace_indices = [i for i, row in enumerate(rows)
                         if traces and row['case_dir'] in self.m['diagnostics']['trace_cases']]
        seed(rollout_seed)
        self.attempted_episodes += len(rows)
        self.progress('case_batch_start', force=True, attempted_physical_case_episodes=self.attempted_episodes,
                      current_batch_cases=[r['case_dir'] for r in rows])
        try:
            result = learner.collect(self.envs, training=training, hungarian=hungarian,
                audit=audit, capture_values=capture_values, trace_indices=trace_indices)
        finally:
            self.envs.close()
            self.envs = None
        learner.policy.ac.device_global_matching = False
        result['cases'] = enriched(result['cases'], dict(cases=rows))
        self.total_episodes += len(rows)
        self.training_episodes += len(rows) if training else 0
        if self.total_episodes > self.m['execution']['total_case_episode_limit']:
            raise RuntimeError('Predeclared physical case-episode budget exceeded.')
        self.progress('case_batch_completed', force=True,
            completed_physical_case_episodes=self.total_episodes,
            total_physical_case_episode_limit=self.m['execution']['total_case_episode_limit'],
            completed_training_case_episodes=self.training_episodes,
            total_training_case_episodes=self.m['execution']['total_training_case_episodes'])
        return result

    def evaluate(self, learner, label, *, hungarian=False, rows=None, audit=False):
        selected = self.m['evaluation']['cases'] if rows is None else rows
        all_rows, seconds, events = [], 0., 0
        self.progress('evaluation_start', force=True, phase='evaluation', evaluation_label=label,
                      evaluation_completed=0, evaluation_total=len(selected))
        size = self.c['evaluation_workers']
        for start in range(0, len(selected), size):
            batch = selected[start:start + size]
            result = self.collect_batch(learner, batch, evaluation=True, hungarian=hungarian,
                                        audit=audit, traces=True)
            all_rows += result['cases']
            seconds += result['seconds']
            events += result['environment_events']
            for name, trace in result.get('traces', {}).items():
                row = next(r for r in batch if r['case_dir'] == name)
                atomic_json(self.root / 'traces' / label / (name + '.json'),
                    dict(case_dir=name, case_sha256=row['case_sha256'], evaluation_label=label,
                         decoder='hungarian' if hungarian else 'autoregressive_argmax', events=trace))
            self.progress('evaluation_batch_completed', evaluation_completed=len(all_rows))
        output = dict(label=label, cases=all_rows, summary=metrics(all_rows), seconds=seconds,
            environment_events=events, independent_confirmation=False,
            decoder='hungarian' if hungarian else 'autoregressive_argmax')
        atomic_json(self.root / 'evaluations' / (label + '.json'), output)
        self.evaluations[label] = all_rows
        return all_rows

    def preflight(self):
        learner = self.policy(baseline='rollout', fresh_critic=False)
        actual = self.evaluate(learner, 'S2RL_F_H', hungarian=True)
        expected = {r['case_sha256']: r for r in self.m['evaluation']['cases']}
        errors = [dict(case_dir=r['case_dir'], actual=r['makespan'], expected=expected[r['case_sha256']]['makespan'],
                       steps=r['steps'], expected_steps=expected[r['case_sha256']]['finish_steps'])
                  for r in actual if r['makespan'] != expected[r['case_sha256']]['makespan']
                  or r['steps'] != expected[r['case_sha256']]['finish_steps']]
        atomic_json(self.root / 'checks/source_replay.json', dict(passed=not errors,
                    cases=len(actual), errors=errors, tolerance=0.0))
        if errors:
            raise ValueError(f'Original B0 full tune60 strict replay failed: {errors[:3]}')
        self.evaluate(learner, 'S2RL_F_AR', audit=True)
        atomic_json(self.root / 'checks/probabilities.json', learner.probability_checks)
        if not learner.probability_checks['events']:
            raise ValueError('No zero-update likelihood checks executed.')
        for arm, item in self.m['diagnostics']['checkpoints'].items():
            payload = torch.load(item['path'], map_location='cpu', weights_only=True)
            learner.policy.load_model_state(payload['model'])
            self.evaluate(learner, 'HIST_' + arm + '_H', hungarian=True,
                          rows=self.m['diagnostics']['cases'])
            if arm == 'S2RL_PPO':
                rows = [r for r in self.m['diagnostics']['cases']
                        if r['case_dir'] in self.m['diagnostics']['trace_cases']]
                self.evaluate(learner, 'HIST_S2RL_PPO_AR_TRACE', rows=rows)
        del learner
        self.progress('preflight_passed', force=True, checks_passed=True, phase='reference_rollouts')

    def reference_rollouts(self):
        learner = self.policy(baseline='rollout', fresh_critic=False)
        rows, embeddings, targets, case_indices = [], [], [], []
        train = self.m['train']['cases']
        for batch_index, row_indices in enumerate(self.m['train']['collection_batches']):
            start = batch_index * self.c['rollout_cases']
            self.progress('reference_batch_start', force=True, phase='reference_rollouts',
                          reference_completed=start, reference_total=len(train))
            result = self.collect_batch(learner, [train[i] for i in row_indices],
                                        hungarian=True, capture_values=True)
            rows += result['cases']
            data = result['value_data']
            embeddings.append(data['embeddings'])
            targets.append(data['targets'])
            case_indices.append(torch.tensor(row_indices)[data['case_indices']])
            atomic_json(self.root / 'reference' / f'batch_{start // self.c["rollout_cases"] + 1}.json',
                        {k: v for k, v in result.items() if k not in ('frames', 'targets', 'value_data')})
        data = dict(embeddings=torch.cat(embeddings), targets=torch.cat(targets), case_indices=torch.cat(case_indices))
        save_tensor_artifact(data, self.root / 'reference/value_features.pt')
        self.reference_cmax = {r['case_dir']: r['makespan'] for r in rows}
        atomic_json(self.root / 'reference/summary.json', dict(cases=rows, summary=metrics(rows),
            source=self.m['source'], decoder='hungarian', cache_key_contract='source_case_environment_hashes_in_manifest',
            cost_label_queries=0, complete_reference_case_episodes=len(rows),
            value_features_sha256=file_sha(self.root / 'reference/value_features.pt')))
        del learner
        return data

    def checkpoint(self, arm, round_index, *, completed, suffix=None):
        learner = self.learners[arm]
        state = self.arm_state[arm]
        contract = dict(protocol=PROTOCOL, arm=arm, source=self.m['source'],
            training=learner.contract, actor_steps=learner.actor_steps, critic_steps=learner.critic_steps,
            completed_rounds=state['completed_rounds'], case_episodes=state['case_episodes'],
            protected_before=learner.protected, protected_after=summary(learner.policy.ac, protected=True),
            actor_before=learner.source_actor, actor_after=summary(learner.policy.ac, RESOURCE_PREFIXES),
            behavior_decoder='autoregressive', evaluation_decoder='autoregressive_argmax',
            teacher_execution=False, cost_queries=0, probability_checks=learner.probability_checks,
            minibatch_checks=learner.minibatch_checks,
            value_head_status='trained_value_baseline' if arm == 'S2RL_PPO_V' else 'not_used_untrained',
            stage3_requires_fresh_critic=True)
        checkpoint = {**self.payload, 'model': {k: v.detach().cpu() for k, v in learner.policy.ac.state_dict().items()},
            'training_stage': 'resource_joint', 'stage2_training_mode': 'bc_resource_rl',
            'phase': 'resource_rl_completed' if completed else 'resource_rl_running',
            'device_global_matching': False, 'resource_deployment_decoder': 'autoregressive',
            'resource_rl_contract': contract, 'confirmed_scientific_success': False,
            'stage2_scientific_gate': {'passed': False},
            'resource_rl_training_state': dict(actor_optim=learner.actor_optim.state_dict(),
                critic_optim=learner.critic_optim.state_dict(), torch_rng=torch.get_rng_state(),
                cuda_rng=torch.cuda.get_rng_state(), collection_round=round_index,
                resume_requires_explicit_new_manifest=True)}
        path = self.root / arm / (suffix or f'checkpoint_round_{round_index}.pt')
        save_tensor_artifact(checkpoint, path)
        if completed:
            validation = validate_stage2_joint_finetune_checkpoint(checkpoint, learner.policy.ac.state_dict(),
                plane_order_mode=learner.policy.ac.plane_order_mode,
                plane_pair_decoder=learner.policy.ac.plane_pair_decoder,
                global_feature_mode=self.args.global_feature_mode,
                planning_contract=self.payload['resource_lookahead_contract'],
                request_ready_time_scale=learner.policy.ac.request_ready_time_scale,
                resource_decoder='autoregressive')
            atomic_json(self.root / arm / 'static_handoff_check.json',
                dict(passed=True, validation=validation, dynamic_transfer_validated=False,
                     scientific_gate_passed=False, stage3_started=False))
        return str(path)

    def analyze(self):
        audit = json.loads(Path(self.m['iga_reference']['path']).read_text())
        reports = {}
        for arm in ARMS:
            state = self.arm_state.get(arm, {})
            label = arm + f'_round_{self.c["rounds"]}'
            if label not in self.evaluations:
                reports[arm] = dict(status=state.get('status', 'pending'), candidate_complete=False)
                continue
            rows = self.evaluations[label]
            ar = compare_cases(self.evaluations['S2RL_F_AR'], rows)
            original = compare_cases(self.evaluations['S2RL_F_H'], rows)
            reports[arm] = dict(status=state['status'], candidate_complete=True,
                summary=metrics(rows), versus_ar=ar, versus_original=original,
                screen_threshold_passed=screen_candidate(ar, original),
                historical_iga={name: compare_cases(item['cases'], rows) for name, item in audit['baselines'].items()},
                formal_iga_goal_certifiable=False, checkpoint=state.get('checkpoint'))
        output = dict(protocol=PROTOCOL, methods=reports,
            actual_training_case_episodes=self.training_episodes, actual_physical_case_episodes=self.total_episodes,
            attempted_physical_case_episodes=self.attempted_episodes,
            planned_budget=self.m['execution'], source_retained=True,
            confirmed_scientific_success=False, independent_confirmation=False,
            automatic_promotion=False, automatic_retry=False, stage3_started=False,
            goal='fully_better_IGA180_and_at_least_IGA1800')
        if all(r.get('candidate_complete') for r in reports.values()):
            output['rollout_versus_value'] = compare_cases(
                self.evaluations[f'S2RL_PPO_V_round_{self.c["rounds"]}'],
                self.evaluations[f'S2RL_PPO_R_round_{self.c["rounds"]}'])
        atomic_json(self.root / 'analysis.json', output)

    def train(self, value_data):
        for arm in ARMS:
            learner = self.policy(baseline='rollout' if arm == 'S2RL_PPO_R' else 'value', fresh_critic=True)
            self.learners[arm] = learner
            self.arm_state[arm] = dict(status='pending', completed_rounds=0, case_episodes=0, rounds=[])
            (self.root / arm).mkdir(exist_ok=False)
        validation = sorted(range(240), key=lambda i: self.m['train']['cases'][i]['case_sha256'])[::4]
        self.progress('critic_warmup_start', force=True, phase='critic_warmup', arm='S2RL_PPO_V')
        warmup = self.learners['S2RL_PPO_V'].warmup_value(value_data, validation)
        atomic_json(self.root / 'S2RL_PPO_V/critic_warmup.json', warmup)
        del value_data
        train_rows = self.m['train']['cases']
        batch_size = self.c['rollout_cases']
        batches_per_epoch = len(train_rows) // batch_size
        for round_index in range(1, self.c['rounds'] + 1):
            row_indices = self.m['train']['collection_batches'][(round_index - 1) % batches_per_epoch]
            rows = [train_rows[i] for i in row_indices]
            for arm in ARMS:
                state, learner = self.arm_state[arm], self.learners[arm]
                if state['status'] == 'paused_for_kl':
                    continue
                state['status'] = 'running'
                self.progress('round_start', force=True, phase='training', arm=arm,
                    collection_round=round_index, total_rounds=self.c['rounds'],
                    coverage_epoch=(round_index - 1) // batches_per_epoch + 1,
                    actor_steps=learner.actor_steps, actor_step_limit=self.m['execution']['actor_steps_per_arm'],
                    arm_status={k: v['status'] for k, v in self.arm_state.items()})
                rollout = self.collect_batch(learner, rows, training=True,
                                            rollout_seed=self.c['seed'] + 300000 + round_index)
                state['case_episodes'] += len(rows)
                record = {k: v for k, v in rollout.items() if k not in ('frames', 'targets')}
                atomic_json(self.root / arm / f'round_{round_index}_rollout.json', record)
                if round_index == 1:
                    signature = dict(action_sha256=rollout['trajectory_action_sha256'],
                                     cases=[(r['case_dir'], r['makespan'], r['steps']) for r in rollout['cases']])
                    if self.first_signature is None:
                        self.first_signature = signature
                    elif signature != self.first_signature:
                        raise RuntimeError('Identical initial actors did not produce identical first-round trajectories.')
                    else:
                        atomic_json(self.root / 'checks/independent_rng_first_round.json',
                                    dict(passed=True, signature=signature, critic_rng_separated=True))
                started = time.monotonic()
                update = learner.update(rollout, round_index=round_index, reference_cmax=self.reference_cmax)
                update['seconds'] = time.monotonic() - started
                atomic_json(self.root / arm / f'round_{round_index}_update.json', update)
                state['rounds'].append(dict(round=round_index, collection_seconds=rollout['seconds'], update=update))
                del rollout
                state['completed_rounds'] = round_index
                paused = update['paused_for_kl']
                completed = round_index == self.c['rounds'] and not paused
                state['status'] = 'paused_for_kl' if paused else 'completed' if completed else 'running'
                state['checkpoint'] = self.checkpoint(arm, round_index, completed=completed)
                atomic_json(self.root / arm / 'result.json', state)
                if round_index in self.c['evaluation_rounds'] and not paused:
                    self.evaluate(learner, arm + f'_round_{round_index}')
                if completed:
                    self.evaluate(learner, arm + '_H_DIAGNOSTIC', hungarian=True)
                self.analyze()
                self.progress('round_completed', force=True, phase='training', arm=arm,
                    collection_round=round_index, arm_status={k: v['status'] for k, v in self.arm_state.items()},
                    completed_rounds_by_arm={k: v['completed_rounds'] for k, v in self.arm_state.items()},
                    actor_steps_by_arm={k: v.actor_steps for k, v in self.learners.items()})
        return all(v['status'] == 'completed' for v in self.arm_state.values())

    def run(self):
        self.validate_manifest()
        self.progress = Progress(self.root, self.c['hard_timeout_seconds'])
        def stop_signal(signum, frame):
            if signum == signal.SIGALRM:
                raise TimeoutError('Predeclared V4 preflight/experiment deadline reached.')
            raise KeyboardInterrupt(f'Operator/service signal {signum}')
        signal.signal(signal.SIGTERM, stop_signal)
        signal.signal(signal.SIGALRM, stop_signal)
        signal.alarm(self.c['check_timeout_seconds'])
        try:
            configure_bc_determinism(True)
            torch.set_num_threads(1)
            torch.cuda.set_per_process_memory_fraction(.80, device=0)
            self.args = arguments(self.m)
            self.payload = torch.load(self.m['source']['path'], map_location='cpu', weights_only=True)
            verified_frozen_ready_source(self.payload)
            for key, value in ready_head_config(self.payload).items():
                setattr(self.args, key, value)
            self.ac_config = yaml.safe_load(Path(self.args.ac_config).read_text())
            atomic_json(self.root / 'checks/frozen_lineage.json',
                        validate_frozen_lineage(self.payload, self.m['stage1_source']))
            self.preflight()
            signal.alarm(max(1, int(self.progress.started + self.c['hard_timeout_seconds'] - time.time())))
            data = self.reference_rollouts()
            complete = self.train(data)
            self.analyze()
            self.progress('completed' if complete else 'completed_with_paused_arm', force=True,
                status='completed' if complete else 'completed_with_paused_arm', phase='completed',
                arm_status={k: v['status'] for k, v in self.arm_state.items()},
                completed_training_case_episodes=self.training_episodes,
                completed_physical_case_episodes=self.total_episodes)
            return 0 if complete else 2
        except BaseException as exc:
            status = 'operator_stopped' if isinstance(exc, KeyboardInterrupt) else 'timeout' if isinstance(exc, TimeoutError) else 'failed'
            self.progress.state.update(status=status, error=str(exc), traceback=traceback.format_exc())
            self.progress.write()
            for arm, learner in self.learners.items():
                try:
                    self.checkpoint(arm, self.arm_state[arm]['completed_rounds'], completed=False,
                                    suffix='checkpoint_interrupted.pt')
                except Exception as save_error:
                    print(f'Could not save interruption checkpoint for {arm}: {save_error}', flush=True)
            print(traceback.format_exc(), flush=True)
            return 130 if status == 'operator_stopped' else 1
        finally:
            signal.alarm(0)
            self.progress.stop.set()
            if self.envs is not None:
                self.envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    sys.exit(Suite(parser.parse_args().manifest).run())
