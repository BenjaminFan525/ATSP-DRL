#!/usr/bin/env python3
"""Prepare the authorized V6 semantic audit + shared-data S1/S2 pilot only."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import io
import itertools
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_v6 import ARMS, DEFAULTS, PROTOCOL

PARENT = ROOT / 'result/hkbz_train_logs/stage2_split_encoder_v5_20260909_gpu0_half_train240_r7/manifest.json'
SEARCH = ROOT / 'result/hkbz_train_logs/stage2_supervised_hf_labels_20260901_r1/hf_search'


def select_dev(rows):
    """Keep complete six-case numeric groups; select without viewing outcomes."""
    groups = [rows[i:i + 6] for i in range(0, len(rows), 6)]
    target = {'iid': 6, 'ood_stress': 5, 'ood_scale': 1}
    def key(pair):
        selected = groups[pair[0]] + groups[pair[1]]
        error = sum(abs(sum(r['distribution'] == name for r in selected) - count)
                    for name, count in target.items())
        fingerprint = hashlib.sha256(''.join(r['case_sha256'] for r in selected).encode()).hexdigest()
        return error, fingerprint
    a, b = min(itertools.combinations(range(len(groups)), 2), key=key)
    return copy.deepcopy(groups[a] + groups[b])


def prepare(destination, engineering_proof):
    destination = destination.resolve()
    if destination.exists():
        raise FileExistsError('V6 requires a new output directory; no retries or overwrite.')
    proof = json.loads(engineering_proof.read_text())
    if not proof['passed'] or not proof['scientific_updates_discarded'] or not proof.get('checked_sources'):
        raise ValueError('A passed and discarded version-pinned engineering proof is required.')
    for name, digest in proof['checked_sources'].items():
        if file_sha(ROOT / name) != digest:
            raise ValueError(f'Engineering proof predates current source: {name}')
    parent = json.loads(PARENT.read_text())
    m = {k: copy.deepcopy(parent[k]) for k in ('source', 'stage1_source', 'ready_source',
        'teacher_index', 'teacher_index_sha256', 'environment_argv', 'train', 'evaluation', 'iga_reference')}
    for key in ('train', 'evaluation'):
        validate_case_content(m[key]['cases'], m[key]['dataset'])
    index = json.loads(Path(m['teacher_index']).read_text())
    if file_sha(m['teacher_index']) != m['teacher_index_sha256']:
        raise ValueError('Teacher index changed.')
    hashes = {}
    for row in m['train']['cases']:
        entry = index['entries'][row['case_dir']]
        if entry['case_sha256'] != row['case_sha256']:
            raise ValueError('Teacher does not cover historical train240 content.')
        path = Path(index['teacher_dir']) / (row['case_dir'] + '.json')
        if file_sha(path) != entry['teacher_sha256']:
            raise ValueError('Teacher file changed.')
        hashes[row['case_dir']] = entry['teacher_sha256']
    if len(hashes) != 240 or len(m['evaluation']['cases']) != 60:
        raise ValueError('Historical train240 / tune60 alignment required.')
    pilot_train = copy.deepcopy(m['train']['cases'][:48])
    dev = select_dev(m['evaluation']['cases'])
    diagnostic_names = ['case_0001', 'case_0021', 'case_0054', 'case_0058']
    diagnostic = [copy.deepcopy(next(r for r in m['evaluation']['cases'] if r['case_dir'] == name))
                  for name in diagnostic_names]
    archived = {}
    for name, folder in (('IGA180', SEARCH / 'screen/H2_F4/iga180'),
                         ('IGA1800', SEARCH / 'refine/H2_F4/iga1800')):
        for row in diagnostic:
            saved = json.loads((folder / 'teachers' / (row['case_dir'] + '.json')).read_text())
            if (saved['case_sha256'] != row['case_sha256'] or
                    saved['frozen_plane_checkpoint_sha256'] != m['stage1_source']['sha256']):
                raise ValueError('Archived teacher case or frozen-plane lineage mismatch.')
        archived[name] = dict(teacher_dir=str(folder / 'teachers'),
            teacher_hashes={r['case_dir']: file_sha(folder / 'teachers' / (r['case_dir'] + '.json')) for r in diagnostic},
            archived_makespans={r['case_dir']: json.loads((folder / 'teachers' / (r['case_dir'] + '.json')).read_text())['makespan']
                               for r in diagnostic},
            diagnostic_only=True, strict_search_budget_certified=False)
    m.update(protocol=PROTOCOL, schema_version=1, run_tag=destination.name,
        created_at=datetime.now(timezone.utc).isoformat(),
        material_passport=dict(origin_skill='academic-research-suite/experiment-agent', origin_mode='run',
            origin_date='2026-09-10', verification_status='UNVERIFIED', version_label='stage2_v6_pilot_v1'),
        parent_manifest=dict(path=str(PARENT), sha256=file_sha(PARENT)),
        engineering_proof=dict(path=str(engineering_proof.resolve()), sha256=file_sha(engineering_proof)),
        training_contract=copy.deepcopy(DEFAULTS), pilot_train=pilot_train, pilot_dev=dev,
        diagnostic_cases=diagnostic, archived_teachers=archived,
        teacher_files=dict(directory=index['teacher_dir'], hashes=hashes),
        data_roles=dict(train240_preserved=True, pilot_train_subset=48, development_only=12,
            gate120_accessed=False, finalblind60_accessed=False, selection_uses_outcomes=False),
        resource_contract=dict(gpu=0, gpu_uuid='GPU-744c1334-98c8-5318-e799-7ad15eea1fbf',
            allowed_cpus='0-31,64-95', train_cpus='0-23,64-87', eval_cpus='24-29,88-93',
            monitor_cpus='30-31,94-95', max_concurrent_trainers=2, actual_trainers=1,
            scheduling='alternate_S1_S2_same_shared_teacher_batch', runtime_max_seconds=None),
        execution=dict(arms=list(ARMS), phases=['semantic_reference_audit', 'shared_teacher48', 'pilot_bc10'],
            total_case_episode_limit=172, actor_steps_per_arm=80, teacher_case_episodes=48,
            reference_case_episodes=16, b0_development_case_episodes=12,
            candidate_development_case_episodes=96, automatic_retry=False,
            automatic_full_train240=False, automatic_ppo=False, automatic_stage3=False,
            search_calls=0, cost_label_queries=0, wall_clock_limit_enabled=False),
        engineering=dict(prefix_cases_per_check=6, maximum_events_per_case=64,
            counts_separate_from_172_complete_case_budget=True, updates_discarded=True),
        screen=dict(maximum_mean_regression_vs_b0=.005, maximum_group_regression=.01,
            maximum_tail_regression=.01, primary_epoch=10, zero_failures=True,
            projected_teacher_maximum_mean_regression=.005, minimum_gradient_steps=80,
            scientific_goal_certified_by_pilot=False),
        goal='fully_better_IGA180_and_at_least_IGA1800', confirmed_scientific_success=False)
    fingerprints = code_fingerprint()
    for name in ('STAGE2_RESOURCE_V6_20260910.md', 'onpolicy/scripts/train/launch_stage2_resource_v6_gpu0.sh'):
        fingerprints[name] = file_sha(ROOT / name)
    m['code_fingerprint'] = fingerprints
    destination.mkdir(parents=True, exist_ok=False)
    archive = destination / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as stream:
        for name, digest in fingerprints.items():
            content = (ROOT / name).read_bytes()
            if hashlib.sha256(content).hexdigest() != digest:
                raise ValueError('Source changed during V6 snapshot.')
            stream.addfile(stream.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(content))
    m['source_archive'] = dict(path=str(archive), sha256=file_sha(archive))
    atomic_json(destination / 'manifest.json', m)
    print(destination / 'manifest.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--engineering-proof', type=Path, required=True)
    cli = parser.parse_args()
    prepare(cli.suite_dir, cli.engineering_proof)
