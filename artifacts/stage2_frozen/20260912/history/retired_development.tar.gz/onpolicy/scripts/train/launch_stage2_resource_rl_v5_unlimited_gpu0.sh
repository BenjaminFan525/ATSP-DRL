#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_PYTHON="${PYTHON:-/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
TASK_REQUEST="$(realpath -- "${1:?Pass the explicit time-limit removal authorization}")"
TASK_SUITE="$(dirname -- "${TASK_REQUEST}")"
TASK_UNIT="${UNIT_NAME:-hkbz-stage2-split-v5-20260909-gpu0-half-r5}"
[[ "${TASK_UNIT}" =~ ^[a-zA-Z0-9_-]+$ ]] || exit 1
[[ -f "${TASK_REQUEST}" && ! -e "${TASK_SUITE}/handoff_started.json" && ! -e "${TASK_SUITE}/control.json" ]] || { echo 'Explicit one-shot authorization only; no retry' >&2; exit 1; }
systemd-run --user --unit="${TASK_UNIT}" --working-directory="${TASK_ROOT}" \
  --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
  --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 --setenv=OPENBLAS_NUM_THREADS=1 \
  --setenv=NUMEXPR_NUM_THREADS=1 --setenv=PYTHONHASHSEED=0 --setenv=PYTHONDONTWRITEBYTECODE=1 \
  --setenv=STAGE2_TIME_WAIVER_UNIT="${TASK_UNIT}.service" \
  --setenv=CUBLAS_WORKSPACE_CONFIG=:4096:8 --setenv=MPLCONFIGDIR="${TASK_SUITE}/mplconfig" \
  --property=Type=exec --property=Restart=no --property=KillMode=control-group \
  --property=RuntimeMaxSec=infinity --property=TimeoutStopSec=10 --property=LimitNOFILE=65536 \
  --property=AllowedCPUs=0-31,64-95 --property=CPUAffinity=0-31,64-95 \
  --property="ExecStopPost=${TASK_PYTHON} ${TASK_ROOT}/onpolicy/scripts/train/continue_stage2_resource_rl_v5_unlimited.py recover --authorization ${TASK_REQUEST}" \
  --property="StandardOutput=append:${TASK_SUITE}/controller.log" \
  --property="StandardError=append:${TASK_SUITE}/controller.log" \
  "${TASK_PYTHON}" -u "${TASK_ROOT}/onpolicy/scripts/train/continue_stage2_resource_rl_v5_unlimited.py" \
  handoff --authorization "${TASK_REQUEST}"
printf 'Started %s: wait for the existing setup without resampling, then fixed Stage B; GPU0 + original CPU half, no wall-clock gate\n' "${TASK_UNIT}"
