#!/usr/bin/env python3
"""Lock the small BC/resource-PPO experiment; never start or promote a run."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from onpolicy.envs.HKBZ.data_generator import _sha256 as canonical_sha
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_resource_rl import DEFAULTS, PROTOCOL, file_sha
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_policy_transfer import verified_frozen_ready_source

PARENT = ROOT / 'result/hkbz_train_logs/stage2_bc_injection_20260905_gpu0_half_pilot_r2'
B0 = ROOT / ('onpolicy/scripts/results/HKBZ/simple/gnn_mappo/'
    'stage2_bc_injection_20260905_gpu0_half_pilot_r2_B0_none_seed11/run1')
B0_SHA = 'b7740b2b688c83dc7fa65bed6381243cdf2f6675f4b96808ff05a41d4e44e7e8'


def case_record(path):
    record = json.loads((path / 'metadata.json').read_text())
    names = ('job.json', 'fixed_resources.json', 'mobile_resources.json', 'sites.json', 'flights.json')
    values = {n: json.loads((path / n).read_text()) for n in names}
    return {**record, 'case_dir': path.name, 'case_sha256': canonical_sha(values),
            'fingerprints': {'files': {n: canonical_sha(v) for n, v in values.items()}}}


def select(rows, quotas):
    selected = []
    for group, count in quotas.items():
        pool = sorted((r for r in rows if r['distribution'] == group),
                      key=lambda r: (r['case_sha256'], r['case_dir']))
        if len(pool) < count:
            raise ValueError(f'Insufficient cases for {group}.')
        selected.extend(pool[:count])
    return sorted(selected, key=lambda r: r['case_sha256'])


def prepare(cli):
    suite = cli.suite_dir.resolve()
    if suite.exists() or not cli.run_tag.replace('_', '').replace('-', '').isalnum():
        raise ValueError('Use a safe unique run tag and a NEW suite directory.')
    parent = json.loads((PARENT / 'manifest.json').read_text())
    source, evaluation = B0 / 'models/checkpoint_Best.pt', B0 / 'evaluations/bc_epoch_1.json'
    if file_sha(source) != B0_SHA:
        raise ValueError('Pinned B0 source changed.')
    payload = torch.load(source, map_location='cpu', weights_only=True)
    if not payload.get('stage2_scientific_gate', {}).get('passed'):
        raise ValueError('B0 is not the selected eligible BC source.')
    ready = verified_frozen_ready_source(payload)
    teacher_path = Path(parent['teacher_index'])
    if file_sha(teacher_path) != parent['teacher_index_sha256']:
        raise ValueError('Teacher index changed.')
    teacher = json.loads(teacher_path.read_text())
    train_dataset = Path(teacher['dataset_dir']).resolve()
    tune_dataset = Path(parent['evaluation_contract']['dataset']).resolve()
    training = select([case_record(p) for p in sorted(train_dataset.glob('case_*'))],
                      {'iid': 12, 'ood_stress': 10, 'ood_scale': 2})
    reference = json.loads(evaluation.read_text())['cases']
    tuning = select(reference, {'iid': 6, 'ood_stress': 5, 'ood_scale': 1})
    validate_case_content(training, train_dataset)
    validate_case_content(tuning, tune_dataset)
    if {r['case_sha256'] for r in training} & {r['case_sha256'] for r in tuning}:
        raise ValueError('Train/evaluation content overlap.')
    manifest = dict(schema_version=1, protocol=PROTOCOL, run_tag=cli.run_tag,
        material_passport=dict(origin_skill='academic-research-suite/experiment-agent',
            origin_mode='run', origin_date='2026-09-08', verification_status='UNVERIFIED'),
        created_at=datetime.now(timezone.utc).isoformat(),
        runtime=dict(python=platform.python_version(), torch=str(torch.__version__),
                     cuda=torch.version.cuda, executable=sys.executable),
        source=dict(path=str(source), sha256=B0_SHA, evaluation=str(evaluation),
                    evaluation_sha256=file_sha(evaluation)),
        stage1_source=parent['source'], ready_source=ready,
        teacher_index=str(teacher_path), teacher_index_sha256=file_sha(teacher_path),
        environment_argv=parent['commands']['B0_none_seed11']['argv'][2:],
        training_contract={**DEFAULTS},
        train=dict(dataset=str(train_dataset), cases=training, outcome_selected=False),
        evaluation=dict(dataset=str(tune_dataset), cases=tuning, outcome_selected=False,
                        independent=False, gate_access=False, finalblind_access=False),
        resource_contract=dict(gpu=0, allowed_cpus='0-31,64-95',
            train_cpus='0-23,64-87', eval_cpus='24-29,88-93', monitor_cpus='30-31,94-95',
            max_concurrent_trainers=1, runtime_max_seconds=14400),
        execution=dict(arms=['S2RL_BC', 'S2RL_PPO'], automatic_promotion=False,
            cost_label_queries=0, teacher_execution=False,
            bc_objective='autoregressive_joint_teacher_nll_on_student_states',
            recurrent_replay='current_weights_from_zero_each_full_pass',
            actor_optimizer_steps_per_collection=2, critic_warmup_once=10),
        source_command=parent['commands']['B0_none_seed11'],
        protocol_path=str(ROOT / 'STAGE2_BC_RL_PROTOCOL_20260908.md'),
        confirmed_scientific_success=False)
    fingerprints = code_fingerprint()
    for relative in ('STAGE2_BC_RL_PROTOCOL_20260908.md',
                     'STAGE2_RESOURCE_RL_IMPLEMENTATION_20260908.md',
                     'onpolicy/scripts/train/launch_stage2_resource_rl_gpu0.sh'):
        fingerprints[relative] = file_sha(ROOT / relative)
    manifest['code_fingerprint'] = fingerprints
    suite.mkdir(parents=True, exist_ok=False)
    archive = suite / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for name, expected in fingerprints.items():
            data = (ROOT / name).read_bytes()
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError(f'Source changed during preparation: {name}')
            info = handle.gettarinfo(str(ROOT / name), arcname=name)
            handle.addfile(info, io.BytesIO(data))
    manifest['source_archive'] = dict(path=str(archive), sha256=file_sha(archive))
    atomic_json(suite / 'manifest.json', manifest)
    print(suite / 'manifest.json', flush=True)
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    prepare(parser.parse_args())
