#!/usr/bin/env python3
"""Freeze V4 contracts with exactly the historical Stage2 train240/tune60."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import platform
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from onpolicy.scripts.train.prepare_stage2_resource_rl import B0, B0_SHA, PARENT, case_record
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_policy_transfer import verified_frozen_ready_source
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v4 import ARMS, DEFAULTS, PROTOCOL

PREVIOUS = ROOT / 'result/hkbz_train_logs/stage2_bc_rl_20260908_gpu0_half_pilot_r1'
IGA_AUDIT = ROOT / 'result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r3_bc_pilot/iga_reference_audit.json'
PROTOCOL_FILE = 'STAGE2_RESOURCE_RL_V4_20260908.md'


def legacy_collection_batches(case_count, workers):
    """Historical vector env array_split: each worker owns a contiguous shard.

    One collection takes the next case from every worker, not the next 24
    adjacent names in the pool list. Preserve that historical visitation order.
    """
    if workers <= 0 or case_count % workers:
        raise ValueError('Historical equal case shards are required.')
    per_worker = case_count // workers
    return [[rank * per_worker + offset for rank in range(workers)] for offset in range(per_worker)]


def validate_historical_case_hashes(rows, teacher_index):
    for row in rows:
        original = teacher_index['entries'].get(row['case_dir'])
        if original is None or original['case_sha256'] != row['case_sha256']:
            raise ValueError(f'Historical training case content changed: {row["case_dir"]}')


def align_legacy_cases(parent, all_rows):
    audit = parent['sampling_audits']['11']
    order = audit['case_order']
    rows = {r['case_dir']: r for r in all_rows}
    if (audit['source_cases'] != 600 or audit['selected_cases'] != 240
            or len(order) != 240 or len(set(order)) != 240):
        raise ValueError('Historical Stage2 did not use the expected fixed train240.')
    chosen = [rows[name] for name in order]
    counts = dict(Counter(r['distribution'] for r in chosen))
    if counts != {'iid': 120, 'ood_stress': 108, 'ood_scale': 12}:
        raise ValueError('Historical train240 distribution changed.')
    if len({r['case_sha256'] for r in chosen}) != len(chosen):
        raise ValueError('Duplicate case contents in historical Stage2 training list.')
    return chosen


def execution_budget(train_count, eval_count, contract):
    workers = contract['rollout_cases']
    if train_count % workers or workers % contract['minibatch_cases']:
        raise ValueError('This experiment requires complete equal-sized case batches.')
    per_epoch = train_count // workers
    rounds = contract['epochs'] * per_epoch
    if rounds != contract['rounds']:
        raise ValueError('Coverage epochs and collection rounds differ.')
    return dict(train_unique_cases=train_count, evaluation_cases=eval_count,
        rounds_per_epoch=per_epoch, rounds_per_arm=rounds,
        case_episodes_per_arm=rounds * workers,
        actor_steps_per_collection=workers // contract['minibatch_cases'] * contract['ppo_passes'],
        actor_steps_per_arm=rounds * workers // contract['minibatch_cases'] * contract['ppo_passes'],
        total_training_case_episodes=len(ARMS) * rounds * workers,
        frozen_reference_case_episodes=train_count,
        main_evaluation_case_episodes=(2 + len(ARMS) * len(contract['evaluation_rounds']) + len(ARMS)) * eval_count,
        historical_decoder_diagnostic_case_episodes=28,
        automatic_promotion=False, automatic_retry=False,
        total_case_episode_limit=(len(ARMS) * rounds * workers + train_count
            + (2 + len(ARMS) * len(contract['evaluation_rounds']) + len(ARMS)) * eval_count + 28))


def prepare(cli):
    suite = cli.suite_dir.resolve()
    if suite.exists() or not cli.run_tag.replace('_', '').replace('-', '').isalnum():
        raise ValueError('Use a new experiment directory and a safe tag.')
    parent_path = PARENT / 'manifest.json'
    parent = json.loads(parent_path.read_text())
    source, evaluation = B0 / 'models/checkpoint_Best.pt', B0 / 'evaluations/bc_epoch_1.json'
    if file_sha(source) != B0_SHA:
        raise ValueError('Pinned B0 source changed.')
    payload = torch.load(source, map_location='cpu', weights_only=True)
    if not payload.get('stage2_scientific_gate', {}).get('passed'):
        raise ValueError('B0 is not an eligible historical BC source.')
    ready = verified_frozen_ready_source(payload)
    teacher_path = Path(parent['teacher_index'])
    if file_sha(teacher_path) != parent['teacher_index_sha256']:
        raise ValueError('Teacher600 index changed.')
    teacher = json.loads(teacher_path.read_text())
    dataset = Path(teacher['dataset_dir']).resolve()
    training = align_legacy_cases(parent, [case_record(p) for p in sorted(dataset.glob('case_*'))])
    validate_historical_case_hashes(training, teacher)
    tuning = json.loads(evaluation.read_text())['cases']
    tune_dataset = parent['evaluation_contract']['dataset']
    if len(tuning) != 60:
        raise ValueError('Expected the original complete tune60 evaluation.')
    validate_case_content(training, dataset)
    validate_case_content(tuning, tune_dataset)
    if {r['case_sha256'] for r in training} & {r['case_sha256'] for r in tuning}:
        raise ValueError('Train/tune case content overlap.')
    proof_path = cli.engineering_report.resolve()
    proof = json.loads(proof_path.read_text())
    if not proof.get('passed') or set(proof.get('arms', {})) != set(ARMS):
        raise ValueError('Both V4 GPU engineering arms must pass before preparing a run.')
    for name, expected in proof['code_fingerprint'].items():
        if file_sha(ROOT / name) != expected:
            raise ValueError(f'Code changed since the engineering proof: {name}')
    contract = dict(DEFAULTS)
    budget = execution_budget(len(training), len(tuning), contract)
    prior = json.loads((PREVIOUS / 'manifest.json').read_text())
    diagnostics = {}
    for arm in ('S2RL_BC', 'S2RL_PPO'):
        checkpoint = PREVIOUS / arm / 'checkpoint_round_2.pt'
        diagnostics[arm] = dict(path=str(checkpoint), sha256=file_sha(checkpoint))
    manifest = dict(schema_version=2, protocol=PROTOCOL, run_tag=cli.run_tag,
        material_passport=dict(origin_skill='academic-research-suite/experiment-agent',
            origin_mode='run', origin_date='2026-09-08', verification_status='UNVERIFIED'),
        created_at=datetime.now(timezone.utc).isoformat(),
        runtime=dict(python=platform.python_version(), torch=str(torch.__version__),
                     cuda=torch.version.cuda, executable=sys.executable),
        source=dict(path=str(source), sha256=B0_SHA, evaluation=str(evaluation),
                    evaluation_sha256=file_sha(evaluation)),
        stage1_source=parent['source'], ready_source=ready,
        teacher_index=str(teacher_path), teacher_index_sha256=file_sha(teacher_path),
        environment_argv=parent['commands']['B0_none_seed11']['argv'][2:],
        training_contract=contract,
        data_alignment=dict(parent_manifest=str(parent_path), parent_sha256=file_sha(parent_path),
            original_sampling_audit=parent['sampling_audits']['11'], exact_case_order_reused=True,
            original_epochs=2, original_rollouts_per_epoch=10, original_workers=24,
            source_pool_cases=600, actual_training_cases=240, complete_evaluation_cases=60,
            user_amendment='Match previous Stage2 data volume, replacing planned train96/tune12.'),
        train=dict(dataset=str(dataset), cases=training, outcome_selected=False,
            collection_batches=legacy_collection_batches(len(training), contract['rollout_cases']),
            collection_order='historical_contiguous_worker_shards_then_next_case_per_worker'),
        evaluation=dict(dataset=str(tune_dataset), cases=tuning, workers=12,
            outcome_selected=False, independent=False, gate_access=False, finalblind_access=False),
        diagnostics=dict(checkpoints=diagnostics, cases=prior['evaluation']['cases'],
            trace_cases=['case_0001', 'case_0021', 'case_0054', 'case_0058'],
            trace_schema='observable_case_graph_semantic_ids_v1', extra_rollout_limit=28),
        iga_reference=dict(path=str(IGA_AUDIT), sha256=file_sha(IGA_AUDIT),
            usage='historical_diagnostic_only', strict_budget_certified=False),
        engineering_proof=dict(path=str(proof_path), sha256=file_sha(proof_path)),
        resource_contract=dict(gpu=0, gpu_uuid='GPU-744c1334-98c8-5318-e799-7ad15eea1fbf',
            allowed_cpus='0-31,64-95', train_cpus='0-23,64-87', eval_cpus='24-29,88-93',
            monitor_cpus='30-31,94-95', max_concurrent_trainers=1,
            runtime_max_seconds=contract['hard_timeout_seconds']),
        execution=dict(arms=list(ARMS), **budget, cost_label_queries=0, teacher_execution=False,
            baseline_reference_decoder='hungarian', reference_kl_decoder='autoregressive',
            minibatch_replay='current_weights_from_zero_each_complete_case_minibatch',
            candidate_round=contract['rounds'], monitor_rounds=contract['evaluation_rounds'][:-1],
            future_bc_control=False, future_multiseed=False, stage3_started=False),
        screen=dict(mean_gain_vs_both=.005, group_nonregression=True, tail_nonregression=True,
            maximum_paired_relative_regression_vs_B0_H=.01, zero_failures=True,
            not_iga_certification=True, not_independent_confirmation=True),
        protocol_path=str(ROOT / PROTOCOL_FILE), confirmed_scientific_success=False)
    fingerprints = code_fingerprint()
    for name in (PROTOCOL_FILE, 'onpolicy/scripts/train/launch_stage2_resource_rl_v4_gpu0.sh'):
        fingerprints[name] = file_sha(ROOT / name)
    manifest['code_fingerprint'] = fingerprints
    suite.mkdir(parents=True, exist_ok=False)
    archive = suite / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for name, expected in fingerprints.items():
            data = (ROOT / name).read_bytes()
            if file_sha(ROOT / name) != expected:
                raise ValueError(f'Source changed during archive: {name}')
            handle.addfile(handle.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(data))
    manifest['source_archive'] = dict(path=str(archive), sha256=file_sha(archive))
    atomic_json(suite / 'manifest.json', manifest)
    print(suite / 'manifest.json', flush=True)
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--engineering-report', type=Path, required=True)
    prepare(parser.parse_args())
