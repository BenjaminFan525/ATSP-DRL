#!/usr/bin/env python3
"""Prepare the P0/P1 full-assignment x typed-wait pilot; never auto-promote."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shlex
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.config.config import get_config
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.prepare_stage2_policy_transfer import PARENT, TRAIN_CPUS, digest
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import set_option, set_switch
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args as parse_training_args, select_train_case_dirs
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_iga_contract import load_historical_iga, checked_cases
from onpolicy.utils.stage2_matching import MATCHING_CONTRACT, SUPERVISION_CONTRACT, TEACHER_PROJECTION_CONTRACT
from onpolicy.utils.training_stage import source_checkpoint_metadata


METHODS = {'M0_control': (0., 0.), 'M1_full_edge': (1., 0.),
           'M2_typed_wait': (0., .25), 'M3_edge_wait': (1., .25)}
IGA_ROOT = ROOT / 'result/hkbz_train_logs/stage2_supervised_hf_labels_20260901_r1/hf_search'
STRONG_RUN = ROOT / ('onpolicy/scripts/results/HKBZ/simple/gnn_mappo/'
    'stage2_policy_transfer_20260906_gpu0_half_pilot_r1_D_B0_seed11/run1')


def validate_canary_proof(path, fingerprints):
    if path is None:
        raise ValueError('Pilot requires --canary-proof with a completed, source-matched four-arm canary.')
    path = Path(path).resolve()
    report = json.loads(path.read_text())
    manifest_path = path.parent.parent / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    if (manifest.get('profile') != 'canary' or manifest.get('research_family') != 'stage2_matching_gap'
            or report.get('canary_contract_passed') is not True
            or not report.get('complete') or manifest['code_fingerprint'] != fingerprints):
        raise ValueError('Canary proof is incomplete or its code differs from the proposed pilot.')
    if set(report['methods']) != {name + '_seed11' for name in METHODS}:
        raise ValueError('Canary proof does not cover all four matching/wait arms.')
    return {'path': str(path), 'sha256': digest(path),
            'manifest': str(manifest_path), 'manifest_sha256': digest(manifest_path)}


def prepare(args):
    suite = args.suite_dir.resolve()
    if suite.exists():
        raise FileExistsError(f'Never overwrite a suite: {suite}')
    if args.profile not in ('canary', 'pilot'):
        raise ValueError('No automatic formal/DAgger/RL/Stage3 profiles.')
    old = json.loads((args.parent_suite / 'manifest.json').read_text())
    report = json.loads((args.parent_suite / 'analysis/comparison.json').read_text())
    if not report.get('complete') or any(not row['integrity_passed'] for row in report['methods'].values()):
        raise ValueError('The B0/B1/B2 source pilot is not complete and audited.')
    canary = args.profile == 'canary'
    workers, cases, eval_workers, eval_cases, rollouts = (2, 2, 2, 4, 1) if canary else (24, 240, 12, 60, 10)
    # Engineering regression coverage, not a change to pilot sample/seed/order.
    sampling_seed = 541 if canary else 1
    teacher = json.loads(Path(old['teacher_index']).read_text())
    selected, sampling = select_train_case_dirs(
        sorted(Path(teacher['dataset_dir']).glob('case_*')),
        mode='uniform' if canary else 'distribution_balanced',
        weights_spec='iid=0.50,ood_stress=0.45,ood_scale=0.05', seed=sampling_seed,
        max_cases=cases, sample_size=cases,
    )
    order = [Path(value).name for value in selected]
    if canary and 'case_0343' not in order:
        raise ValueError('Regression canary must include the real Blocking-priority failure case.')
    if not canary and order != old['sampling_audits']['11']['case_order']:
        raise ValueError('Pilot training cases/order differ from the fixed 240-case control.')
    sampling.update(case_order=order, sampling_seed=sampling_seed,
                    case_order_sha256=hashlib.sha256('\n'.join(order).encode()).hexdigest())
    origins = {}
    for arm in ('B0_none', 'B2_R1'):
        method = report['methods'][arm + '_seed11']
        run = Path(method['run_dir'])
        evaluation = run / 'evaluations' / f'bc_epoch_{method["selected_epoch"]}.json'
        origins[arm] = {**source_checkpoint_metadata(run / 'models/checkpoint_Best.pt'),
                        'evaluation': str(evaluation), 'evaluation_sha256': digest(evaluation)}
    strong_eval = STRONG_RUN / 'evaluations/bc_epoch_1.json'
    origins['D_B0'] = {**source_checkpoint_metadata(STRONG_RUN / 'models/checkpoint_BCEpoch1.pt'),
                       'evaluation': str(strong_eval), 'evaluation_sha256': digest(strong_eval)}
    baseline = json.loads(Path(origins['B0_none']['evaluation']).read_text())
    validate_case_content(baseline['cases'], old['evaluation_contract']['dataset'])
    for origin in origins.values():
        if set(checked_cases(json.loads(Path(origin['evaluation']).read_text()))) != set(checked_cases(baseline)):
            raise ValueError('Fixed strong references are not hash paired.')
    baselines = {
        'IGA180': load_historical_iga(IGA_ROOT / 'screen/H2_F4/iga180',
            source_sha256=old['source']['sha256'], planning_contract=teacher['resource_lookahead_contract'], nominal_budget=180),
        'IGA1800': load_historical_iga(IGA_ROOT / 'refine/H2_F4/iga1800',
            source_sha256=old['source']['sha256'], planning_contract=teacher['resource_lookahead_contract'], nominal_budget=1800),
    }
    short, long = [checked_cases(baselines[key]) for key in ('IGA180', 'IGA1800')]
    if set(short) != set(long) or set(short) != set(checked_cases(baseline)):
        raise ValueError('IGA and policy references are not hash paired.')
    if any(long[key]['makespan'] > short[key]['makespan'] + 1e-6 for key in short):
        raise ValueError('IGA1800 lost its nested IGA180 incumbent.')
    commands = {}
    for arm, (edge, wait) in METHODS.items():
        source = origins['B0_none']
        experiment = f'{args.run_tag}_{arm}_seed11'
        if (ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / experiment).exists():
            raise FileExistsError(f'Experiment already exists: {experiment}')
        command = list(old['commands']['B0_none_seed11']['argv'])
        command[0] = str(args.python.resolve())
        for key, value in {
            '--experiment_name': experiment, '--seed': 11, '--train_sampling_seed': sampling_seed,
            '--train_sampling_mode': 'uniform' if canary else 'distribution_balanced',
            '--max_train_cases': cases, '--train_sampling_size': cases,
            '--n_rollout_threads': workers, '--n_eval_rollout_threads': eval_workers,
            '--max_eval_cases': eval_cases, '--mini_batch_size': min(7, workers),
            '--device_bc_min_rollouts_per_epoch': rollouts, '--device_bc_max_rollouts_per_epoch': rollouts,
            '--device_bc_pretrain_epochs': 2, '--device_bc_lr': 1e-5,
            '--request_ready_min_labels_per_epoch': 0, '--request_ready_loss_coef': 0,
            '--request_ready_policy_injection': 'none', '--device_bc_dagger_schedule': '1.0,1.0',
            '--cuda_memory_fraction': .25,
            '--device_bc_full_edge_loss_coef': edge, '--device_bc_empty_wait_loss_coef': wait,
            '--device_bc_min_wait_groups_per_epoch': 1 if wait and not canary else 0,
            '--stage2_max_raw_regression_seconds': 0, '--stage2_max_stress_regression_seconds': 0,
            '--stage2_policy_warmstart_checkpoint': source['path'],
            '--stage2_policy_warmstart_sha256': source['sha256'],
            '--stage2_policy_warmstart_evaluation': '' if canary else source['evaluation'],
            '--stage2_policy_warmstart_evaluation_sha256': '' if canary else source['evaluation_sha256'],
        }.items():
            set_option(command, key, value)
        set_switch(command, '--device_bc_stochastic_plane', False)
        set_switch(command, '--device_bc_skip_ready_targets', True)
        set_switch(command, '--device_bc_matching_audit', True)
        set_switch(command, '--device_bc_teacher_deployment_projection', True)
        parser = get_config()
        parsed = parse_training_args(command[2:], parser)
        _, unknown = parser.parse_known_args(command[2:])
        if unknown or not parsed.device_bc_plane_deterministic or not parsed.stage2_bc_deterministic:
            raise ValueError(f'Invalid/ nondeterministic pilot command: {unknown}')
        commands[arm + '_seed11'] = {
            'argv': command, 'shell': shlex.join(command), 'arm': arm, 'seed': 11,
            'experiment_name': experiment, 'injection': 'none', 'warmstart_arm': 'B0_none',
            'warmstart_source': source, 'teacher_execution_schedule': [1., 1.],
            'full_edge_coef': edge, 'empty_wait_coef': wait,
        }
    fingerprints = code_fingerprint()
    for extra in ('onpolicy/scripts/train/launch_stage2_matching_gap_gpu0.sh',
                  'STAGE2_MATCHING_GAP_IMPLEMENTATION_20260906.md'):
        fingerprints[extra] = digest(ROOT / extra)
    proof = None if canary else validate_canary_proof(args.canary_proof, fingerprints)
    manifest = {
        'schema_version': 1, 'run_tag': args.run_tag, 'profile': args.profile,
        'research_family': 'stage2_matching_gap', 'scientific_result': not canary,
        'created_at': datetime.now(timezone.utc).isoformat(), 'commands': commands,
        'parent_manifest': str(args.parent_suite / 'manifest.json'),
        'parent_manifest_sha256': digest(args.parent_suite / 'manifest.json'),
        'source': old['source'], 'ready_source': old['ready_source'],
        'teacher_index': old['teacher_index'], 'teacher_index_sha256': old['teacher_index_sha256'],
        'warmstart_sources': origins, 'sampling_audits': {'11': sampling},
        'training_contract': {'epochs': 2, 'workers': workers, 'rollouts_per_epoch': rollouts,
                             'scope': 'policy_frozen_ready', 'ppo_epochs': 0,
                             'warmstart': 'weights_only_fork', 'shared_initial_seed': 11,
                             'optimizer_restored': False, 'rng_restored': False},
        'matching_contract': {'decoder': MATCHING_CONTRACT, 'supervision': SUPERVISION_CONTRACT,
                             'teacher_decoder': TEACHER_PROJECTION_CONTRACT,
                             'original_teacher_unchanged': True,
                             'derived_teacher_is_historical_iga1800': False,
                             'audit_in_all_arms': True, 'unrepresentable_teacher': 'fail_closed',
                             'wait_cause': 'temporal_defer', 'teacher_execution': 1.,
                             'log_probability_is_matching_probability': False},
        'evaluation_contract': {**old['evaluation_contract'], 'workers': eval_workers, 'cases': eval_cases,
                               'gate_access': False, 'finalblind_access': False,
                               'per_job_zero_tolerance_replay': not canary},
        'resource_contract': {**old['resource_contract'], 'train_cpu_sets': TRAIN_CPUS, 'max_concurrent_trainers': 3},
        'analysis_contract': {
            'contrasts': [['M1_full_edge', 'M0_control'], ['M2_typed_wait', 'M0_control'],
                          ['M3_edge_wait', 'M0_control'], ['M3_edge_wait', 'M1_full_edge'],
                          ['M3_edge_wait', 'M2_typed_wait']],
            'frozen_strong_reference': 'D_B0', 'gap_closure_screen_fraction': .25,
            'point_group_tail_regression_tolerance': 0.,
            'iga180_requirement': 'each_locked_case_nonworse_and_mean_strictly_better',
            'iga1800_requirement': 'mean_group_tail_nonworse',
            'baseline_status': 'historical_nominal_budget_reference_only',
            'resampling_unit': 'case conditional on one training seed; exploratory only',
            'retain_unchanged_source': True, 'automatic_promotion': False,
        },
        'canary_proof': proof, 'analysis_script': 'onpolicy/scripts/train/analyze_stage2_matching_gap.py',
        'code_commit': old['code_commit'], 'code_fingerprint': fingerprints,
        'note': 'P0/P1 only. Historical IGA timing audit is explicit; no strict-budget success claim or automatic P2/RL/Stage3.',
    }
    suite.mkdir(parents=True, exist_ok=False)
    baseline_path = suite / 'iga_reference_audit.json'
    atomic_json(baseline_path, {'baselines': baselines, 'nested_incumbent_checked': True,
                              'formal_iga_goal_certifiable': False})
    manifest['iga_reference_audit'] = {'path': str(baseline_path), 'sha256': digest(baseline_path)}
    archive = suite / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for relative, expected in fingerprints.items():
            path = ROOT / relative
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError(f'Source changed during preparation: {relative}')
            info = handle.gettarinfo(str(path), arcname=relative)
            info.size = len(data)
            handle.addfile(info, io.BytesIO(data))
    manifest['source_archive'] = {'path': str(archive), 'sha256': digest(archive)}
    atomic_json(suite / 'manifest.json', manifest)
    atomic_json(suite / 'evaluator_source.json', {'command': next(iter(commands.values()))['argv']})
    print(suite / 'manifest.json')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--profile', choices=['canary', 'pilot'], default='pilot')
    parser.add_argument('--parent-suite', type=Path, default=PARENT)
    parser.add_argument('--canary-proof', type=Path)
    parser.add_argument('--python', type=Path, default=Path(sys.executable))
    prepare(parser.parse_args())
