#!/usr/bin/env bash
set -euo pipefail

# One command runs a 3-lane production canary, six structured DeviceBC arms,
# promotes the best safe BC boundary, then runs six residual-PPO credit arms.
# Each GPU owns three disjoint 10-core/20-thread trainer pools and one shared
# 6-core/12-thread persistent validation pool.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARER="${ROOT_DIR}/onpolicy/scripts/train/prepare_stage2_structured_credit.py"
TRIAL_RUNNER="${ROOT_DIR}/onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
EVALUATOR="${ROOT_DIR}/onpolicy/scripts/train/shared_hkbz_evaluator.py"

RUN_TAG="${RUN_TAG:-stage2_structured_credit_20260830_r3}"
SUITE_DIR="${SUITE_DIR:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT="${UNIT:-hkbz-s2-structured-credit-20260830-r3}"
SOURCE_MANIFEST="${SOURCE_MANIFEST:-${ROOT_DIR}/result/hkbz_train_logs/stage2_iga_distill_cf_20260828_r1/commands/device_bc_screen.json}"
TEACHER_INDEX="${TEACHER_INDEX:-${ROOT_DIR}/result/hkbz_train_logs/stage2_iga_distill_cf_20260828_r1/artifacts/resource_iga1800_index.json}"
VALIDATION_DIR="${VALIDATION_DIR:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
MATCHED_IGA="${MATCHED_IGA:-${ROOT_DIR}/result/hkbz_train_logs/stage2_matched_iga_tune60_20260827_r1/analysis/matched_iga_comparison.json}"
CANARY_MANIFEST="${SUITE_DIR}/commands/canary.json"
WAVE_A_MANIFEST="${SUITE_DIR}/commands/wave_a.json"
WAVE_B_MANIFEST="${SUITE_DIR}/commands/wave_b.json"
BC_SELECTION="${SUITE_DIR}/analysis/wave_a_bc_selection.json"
PPO_SELECTION="${SUITE_DIR}/analysis/wave_b_ppo_selection.json"
PAIRED_BASELINE="${SUITE_DIR}/artifacts/train600_iga1800_baseline.json"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-15}"

TRAIN_CPUS=(
  "0-9,72-81" "10-19,82-91" "20-29,92-101"
  "36-45,108-117" "46-55,118-127" "56-65,128-137"
)
VAL_CPUS=("30-35,102-107" "66-71,138-143")
EVALUATOR_PIDS=()
EVALUATOR_SOCKETS=()
TRAINER_PIDS=()
MONITOR_PID=""

stop_children() {
  local pid
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}"; do
    [[ -n "${pid}" ]] || continue
    kill "${pid}" >/dev/null 2>&1 || true
  done
  [[ -z "${MONITOR_PID}" ]] || kill "${MONITOR_PID}" >/dev/null 2>&1 || true
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}" "${MONITOR_PID}"; do
    [[ -n "${pid}" ]] || continue
    wait "${pid}" >/dev/null 2>&1 || true
  done
  TRAINER_PIDS=()
  EVALUATOR_PIDS=()
  EVALUATOR_SOCKETS=()
  MONITOR_PID=""
}

controller_exit() {
  local status=$?
  stop_children
  if (( status != 0 )); then
    "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"failed","failed_unix_time":time.time(),"exit_status":int(sys.argv[2])},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json" "${status}" || true
  fi
}

verify_cpu_topology() {
  "${PYTHON}" - "${TRAIN_CPUS[@]}" "${VAL_CPUS[@]}" <<'PY'
import os, sys
def expand(spec):
    result=set()
    for part in spec.split(','):
        lo, sep, hi=part.partition('-')
        result.update(range(int(lo), int(hi)+1) if sep else [int(lo)])
    return result
if os.cpu_count() != 144:
    raise SystemExit(f'expected 144 logical CPUs, got {os.cpu_count()}')
groups=[expand(spec) for spec in sys.argv[1:]]
trainers, evaluators=groups[:6], groups[6:]
for gpu in range(2):
    local=trainers[gpu*3:(gpu+1)*3]+[evaluators[gpu]]
    if [len(item) for item in local] != [20,20,20,12]:
        raise SystemExit(f'GPU{gpu} CPU widths are invalid')
    if sum(map(len, local)) != len(set().union(*local)):
        raise SystemExit(f'GPU{gpu} CPU sets overlap')
for group in groups:
    for cpu in group:
        sibling=cpu+72 if cpu < 72 else cpu-72
        if sibling not in group:
            raise SystemExit(f'CPU set splits SMT siblings {cpu}/{sibling}')
print('[CPU] verified two NUMA-local 3x20+12 logical-CPU partitions')
PY
}

monitor_output_path() {
  local phase="$1"
  printf '%s\n' "${SUITE_DIR}/hardware/${phase}_usage.csv"
}

trainer_cpu_set() {
  local gpu="$1" lane="$2"
  [[ "${gpu}" =~ ^[01]$ && "${lane}" =~ ^[0-2]$ ]] || return 2
  local index
  index=$((gpu * 3 + lane))
  printf '%s\n' "${TRAIN_CPUS[$index]}"
}

validate_launcher_contract() {
  verify_cpu_topology
  local gpu lane cpus
  [[ "$(monitor_output_path contract_check)" == \
    "${SUITE_DIR}/hardware/contract_check_usage.csv" ]]
  for gpu in 0 1; do
    for lane in 0 1 2; do
      cpus="$(trainer_cpu_set "${gpu}" "${lane}")"
      [[ -n "${cpus}" ]]
    done
  done
  echo "[Launcher] set -u path/CPU contract passed"
}

preparer_args() {
  PREPARER_ARGS=(
    --run-tag "${RUN_TAG}" --suite-dir "${SUITE_DIR}"
    --source-manifest "${SOURCE_MANIFEST}"
    --teacher-index "${TEACHER_INDEX}" --python "${PYTHON}"
    --canary-output "${CANARY_MANIFEST}"
    --wave-a-output "${WAVE_A_MANIFEST}"
    --wave-b-output "${WAVE_B_MANIFEST}"
    --selection-output "${BC_SELECTION}"
    --ppo-selection-output "${PPO_SELECTION}"
    --baseline-output "${PAIRED_BASELINE}"
    --matched-iga "${MATCHED_IGA}"
  )
}

monitor_phase() {
  local phase="$1"
  local output
  output="$(monitor_output_path "${phase}")"
  mkdir -p "${SUITE_DIR}/hardware"
  echo "unix_time,gpu0_mem_mib,gpu0_util,gpu1_mem_mib,gpu1_util,mem_available_mib,swap_used_mib" >"${output}"
  while true; do
    local rows g0m g0u g1m g1u available swap
    rows="$(nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader,nounits)"
    g0m="$(sed -n '1{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g0u="$(sed -n '1{s/.*,//;s/ //g;p}' <<<"${rows}")"
    g1m="$(sed -n '2{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g1u="$(sed -n '2{s/.*,//;s/ //g;p}' <<<"${rows}")"
    available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap="$(awk '/SwapTotal:/ {t=$2} /SwapFree:/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)"
    echo "$(date +%s),${g0m},${g0u},${g1m},${g1u},${available},${swap}" >>"${output}"
    sleep 30
  done
}

start_evaluator() {
  local phase="$1" manifest="$2" gpu="$3"
  local cpus="${VAL_CPUS[$gpu]}" socket="/tmp/${UNIT}-${phase}-g${gpu}.sock"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}_eval.log"
  rm -f -- "${socket}"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${EVALUATOR}" \
      --source-command-json "${manifest}" --socket-path "${socket}" \
      --cpu-pool "${cpus}" \
      --run-dir "${SUITE_DIR}/shared_evaluator/${phase}_g${gpu}" \
      --eval-dataset-dir "${VALIDATION_DIR}" --max-eval-cases 60 \
      --cuda-memory-fraction 0.08 --eval-partition-seed 20260811 \
      --eval-partition-stratify-by distribution \
      >"${log}" 2>&1 &
  EVALUATOR_PIDS[$gpu]="$!"
  local deadline=$((SECONDS + 1200))
  while (( SECONDS < deadline )); do
    kill -0 "${EVALUATOR_PIDS[$gpu]}" >/dev/null 2>&1 || {
      echo "[Error] ${phase} GPU${gpu} evaluator exited" >&2
      return 1
    }
    if [[ -S "${socket}" ]] && "${PYTHON}" - "${socket}" <<'PY'
import sys
from onpolicy.utils.shared_eval import SharedEvalClient
reply=SharedEvalClient(sys.argv[1], timeout_seconds=5).ping()
raise SystemExit(0 if int(reply.get('worker_count', -1)) == 12 else 1)
PY
    then
      EVALUATOR_SOCKETS[$gpu]="${socket}"
      echo "[SharedEval] ${phase} GPU${gpu} ready"
      return 0
    fi
    sleep 2
  done
  echo "[Error] ${phase} GPU${gpu} evaluator readiness timeout" >&2
  return 1
}

launch_trial() {
  local phase="$1" manifest="$2" key="$3" gpu="$4" lane="$5" delay="$6"
  local cpus
  cpus="$(trainer_cpu_set "${gpu}" "${lane}")"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}l${lane}_${key}.log"
  local record="${SUITE_DIR}/records/${phase}_${key}.json"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "${manifest}" --command-key "${key}" \
      --gpu "${gpu}" --cpu-set "${cpus}" \
      --shared-eval-socket "${EVALUATOR_SOCKETS[$gpu]}" \
      --shared-eval-cpu-set "${VAL_CPUS[$gpu]}" --eval-workers 12 \
      --start-delay-seconds "${delay}" --record "${record}" \
      >"${log}" 2>&1 &
  LAST_LAUNCHED_PID="$!"
  TRAINER_PIDS+=("${LAST_LAUNCHED_PID}")
  echo "[Launch] ${phase} GPU${gpu} lane=${lane} ${key} CPUs=${cpus} pid=${LAST_LAUNCHED_PID}"
}

run_canary() {
  local keys=(C_B1_candidate_ranking C_B4_full_structure C_B5_full_hard_dagger)
  local lane failed=0 pids=()
  start_evaluator canary "${CANARY_MANIFEST}" 0
  monitor_phase canary & MONITOR_PID="$!"
  for lane in 0 1 2; do
    launch_trial canary "${CANARY_MANIFEST}" "${keys[$lane]}" 0 "${lane}" "$((lane * START_STAGGER_SECONDS))"
    pids+=("${LAST_LAUNCHED_PID}")
  done
  for lane in 0 1 2; do
    wait "${pids[$lane]}" || failed=1
  done
  stop_children
  (( failed == 0 )) || return 1
  echo "[Canary] structured ranking/timing/matching paths passed"
}

run_six_arm_phase() {
  local phase="$1" manifest="$2"
  shift 2
  local keys=("$@") failed=0 index gpu lane key
  [[ "${#keys[@]}" -eq 6 ]] || return 2
  start_evaluator "${phase}" "${manifest}" 0
  start_evaluator "${phase}" "${manifest}" 1
  monitor_phase "${phase}" & MONITOR_PID="$!"
  local pids=()
  for index in 0 1 2 3 4 5; do
    gpu=$((index / 3)); lane=$((index % 3)); key="${keys[$index]}"
    launch_trial "${phase}" "${manifest}" "${key}" "${gpu}" "${lane}" "$((lane * START_STAGGER_SECONDS))"
    pids+=("${LAST_LAUNCHED_PID}")
  done
  for index in 0 1 2 3 4 5; do
    wait "${pids[$index]}" || failed=1
  done
  stop_children
  (( failed == 0 )) || return 1
  echo "[Phase] ${phase} completed all six arms"
}

write_status() {
  local status="$1" phase="$2"
  "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; p=Path(sys.argv[1]); old=json.loads(p.read_text()) if p.exists() else {}; old.update({"status":sys.argv[2],"phase":sys.argv[3],"updated_unix_time":time.time()}); p.write_text(json.dumps(old,indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json" "${status}" "${phase}"
}

controller() {
  trap controller_exit EXIT
  trap 'exit 130' INT TERM
  mkdir -p "${SUITE_DIR}"/{commands,analysis,artifacts,service_logs,records,shared_evaluator,hardware}
  write_status running prepare
  preparer_args
  "${PYTHON}" -u "${PREPARER}" --mode prepare "${PREPARER_ARGS[@]}" >"${SUITE_DIR}/service_logs/prepare.log" 2>&1
  write_status running canary
  run_canary
  write_status running wave_a_structured_bc
  run_six_arm_phase wave_a "${WAVE_A_MANIFEST}" \
    B0_categorical_control B1_candidate_ranking B2_ranking_timing \
    B3_ranking_matching B4_full_structure B5_full_hard_dagger
  write_status running promote_bc
  "${PYTHON}" -u "${PREPARER}" --mode promote "${PREPARER_ARGS[@]}" >"${SUITE_DIR}/service_logs/promote_bc.log" 2>&1
  write_status running wave_b_residual_ppo
  run_six_arm_phase wave_b "${WAVE_B_MANIFEST}" \
    P0_near_bc_control P1_mc_counterfactual P2_residual_hard_kl \
    P3_paired_case_baseline P4_critical_event_credit P5_paired_delta_tail
  write_status running analyze_wave_b
  "${PYTHON}" -u "${PREPARER}" --mode analyze "${PREPARER_ARGS[@]}" >"${SUITE_DIR}/service_logs/analyze_wave_b.log" 2>&1
  write_status completed wave_b_analyzed
  echo "[Pipeline] structured DeviceBC and residual-PPO screen completed"
}

initial_launch() {
  local required load_state compute_pids
  for required in "${PYTHON}" "${PREPARER}" "${TRIAL_RUNNER}" \
    "${EVALUATOR}" "${SOURCE_MANIFEST}" "${TEACHER_INDEX}" \
    "${VALIDATION_DIR}" "${MATCHED_IGA}" /usr/bin/taskset /usr/bin/nvidia-smi; do
    [[ -e "${required}" ]] || { echo "[Error] missing input ${required}" >&2; exit 1; }
  done
  [[ "${RUN_TAG}" =~ ^[A-Za-z0-9._-]+$ && "${UNIT}" =~ ^[A-Za-z0-9._-]+$ ]] || {
    echo "[Error] RUN_TAG/UNIT is not path safe" >&2; exit 1;
  }
  verify_cpu_topology
  systemctl --user show-environment >/dev/null
  load_state="$(systemctl --user show "${UNIT}.service" --property=LoadState --value 2>/dev/null || true)"
  [[ -z "${load_state}" || "${load_state}" == not-found ]] || {
    echo "[Error] systemd unit already exists: ${UNIT}.service" >&2; exit 1;
  }
  [[ "$(nvidia-smi --query-gpu=index --format=csv,noheader,nounits | wc -l)" -ge 2 ]] || {
    echo "[Error] two CUDA GPUs are required" >&2; exit 1;
  }
  compute_pids="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | sed '/^[[:space:]]*$/d')"
  [[ -z "${compute_pids}" ]] || {
    echo "[Error] refusing launch while GPU compute processes exist: ${compute_pids//$'\n'/,}" >&2; exit 1;
  }
  mkdir -p "${SUITE_DIR}/service_logs" "/tmp/${UNIT}/matplotlib"
  systemd-run --user --unit="${UNIT}" --same-dir \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv="MPLCONFIGDIR=/tmp/${UNIT}/matplotlib" \
    --setenv="RUN_TAG=${RUN_TAG}" --setenv="SUITE_DIR=${SUITE_DIR}" \
    --setenv="UNIT=${UNIT}" \
    --property=Type=exec --property=Restart=no \
    --property=KillMode=control-group --property=TimeoutStopSec=300 \
    --property=LimitNOFILE=65536 \
    --property=AllowedCPUs=0-143 --property=CPUAffinity=0-143 \
    --property="StandardOutput=append:${SUITE_DIR}/service_logs/controller.log" \
    --property="StandardError=append:${SUITE_DIR}/service_logs/controller.log" \
    /bin/bash "${BASH_SOURCE[0]}" --controller >/dev/null
  echo "[Started] ${UNIT}.service"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] phase=production canary -> Wave A BC -> Wave B PPO"
}

if [[ "${1:-}" == --controller ]]; then
  [[ $# -eq 1 ]] || { echo "Usage: $0 --controller" >&2; exit 2; }
  controller
elif [[ "${1:-}" == --validate ]]; then
  [[ $# -eq 1 ]] || { echo "Usage: $0 --validate" >&2; exit 2; }
  validate_launcher_contract
elif [[ $# -eq 0 ]]; then
  initial_launch
else
  echo "Usage: $0 [--controller|--validate]" >&2
  exit 2
fi
