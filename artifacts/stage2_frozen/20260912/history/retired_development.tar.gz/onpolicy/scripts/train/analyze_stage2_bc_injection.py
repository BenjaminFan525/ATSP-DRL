#!/usr/bin/env python3
"""Audit frozen-predictor BC and compare paired case-level Cmax outcomes."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.training_stage import PROTECTED_RESOURCE_JOINT_PREFIXES, protected_parameter_summary
from onpolicy.utils.stage2_bc_contract import json_safe, choose_best_epoch


def evaluation_cases(evaluation, expected_count):
    cases = evaluation['cases']
    if len(cases) != expected_count:
        raise ValueError('Evaluation case count mismatch.')
    by_case = {}
    for case in cases:
        if not case['completed'] or case['cycle_terminated'] or case['timeout']:
            raise ValueError('An incomplete evaluation case cannot be dropped.')
        case_hash = case['case_sha256']
        value = float(case['makespan'])
        if not case_hash or case_hash in by_case or not np.isfinite(value):
            raise ValueError('Evaluation has missing/duplicate hashes or non-finite Cmax.')
        by_case[case_hash] = value
    return by_case


def paired_comparison(left, right, *, seed=20260905, samples=10000, tie_tolerance_seconds=1e-6):
    if set(left) != set(right) or not left:
        raise ValueError('Paired comparison needs identical nonempty case hashes.')
    differences = np.array([left[key] - right[key] for key in sorted(left)], dtype=float)
    if not np.isfinite(differences).all():
        raise ValueError('Non-finite paired Cmax.')
    rng = np.random.default_rng(seed)
    means = differences[rng.integers(0, len(differences), (samples, len(differences)))].mean(axis=1)
    return {'case_count': len(differences), 'mean_delta_seconds': float(differences.mean()),
            'case_bootstrap_95ci_seconds': np.quantile(means, [0.025, 0.975]).tolist(),
            'left_wins': int((differences < -tie_tolerance_seconds).sum()),
            'ties': int((np.abs(differences) <= tie_tolerance_seconds).sum()),
            'right_wins': int((differences > tie_tolerance_seconds).sum()),
            'tie_tolerance_seconds': tie_tolerance_seconds,
            'uncertainty_scope': 'case resampling conditional on the observed training seeds'}


def analyze(manifest_path, *, publish=True):
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text())
    suite = manifest_path.parent
    source = torch.load(manifest['source']['path'], map_location='cpu')['model']
    ready = torch.load(manifest['ready_source']['path'], map_location='cpu')['model']
    methods, case_rows, grouped = {}, [], {}
    for key, entry in manifest['commands'].items():
        run = ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / entry['experiment_name'] / 'run1'
        status = json.loads((run / 'run_status.json').read_text())
        if status.get('status') != 'completed':
            raise ValueError(f'{key} did not complete.')
        last = torch.load(run / 'models/checkpoint_Last.pt', map_location='cpu')
        model = last['model']
        for name, value in model.items():
            if name.startswith(PROTECTED_RESOURCE_JOINT_PREFIXES + (
                'plane_critic.', 'device_critic.', 'transporter_critic.', 'team_critic.',
            )):
                if name not in source or not torch.equal(value, source[name]):
                    raise ValueError(f'{key} changed protected tensor {name}.')
            if name.startswith('request_ready_head.') and not torch.equal(value, ready[name]):
                raise ValueError(f'{key} changed the frozen ready head.')
            if not torch.isfinite(value).all():
                raise ValueError(f'{key} has a non-finite model tensor.')
        state = last['stage2_bc_state']
        if state['completed_epochs'] != manifest['training_contract']['epochs']:
            raise ValueError(f'{key} has an incomplete epoch budget.')
        frozen = {name: value for name, value in model.items()
                  if name not in set(state['optimizer_parameter_names'])}
        if protected_parameter_summary(frozen, prefixes=('',)) != last.get('stage2_frozen_state_before'):
            raise ValueError(f'{key} changed tensors outside the registered optimizer scope.')
        if [row['epoch'] for row in state['epoch_records']] != list(range(1, state['completed_epochs'] + 1)):
            raise ValueError(f'{key} has missing or duplicate epoch evaluations.')
        expected_count = manifest['evaluation_contract']['cases']
        baseline = json.loads((run / 'evaluations/pre_supervised.json').read_text())
        case_hashes = set(evaluation_cases(baseline, expected_count))
        evaluations = {}
        for epoch_record in state['epoch_records']:
            epoch = epoch_record['epoch']
            evaluation = json.loads((run / 'evaluations' / f'bc_epoch_{epoch}.json').read_text())
            if set(evaluation_cases(evaluation, expected_count)) != case_hashes:
                raise ValueError(f'{key} changed evaluation cases between epochs.')
            evaluations[epoch] = evaluation
        selected_path = run / 'models/checkpoint_Best.pt'
        selected = torch.load(selected_path, map_location='cpu') if selected_path.exists() else None
        selected_epoch = selected.get('selected_bc_epoch') if selected else None
        record = choose_best_epoch(state['epoch_records'])
        if (record is None) != (selected is None) or (record and selected_epoch != record['epoch']):
            raise ValueError(f'{key} did not promote the actual best eligible epoch.')
        if selected is not None:
            epoch_model = torch.load(run / 'models' / record['filename'], map_location='cpu')['model']
            if set(selected['model']) != set(epoch_model) or any(
                not torch.equal(value, epoch_model[name]) for name, value in selected['model'].items()
            ):
                raise ValueError(f'{key} Best weights differ from the selected epoch.')
        methods[key] = {'arm': entry['arm'], 'seed': entry['seed'], 'run_dir': str(run),
                        'integrity_passed': True, 'selected_epoch': selected_epoch,
                        'eligible': record is not None,
                        'epoch_metrics': [{k: row[k] for k in ('epoch', 'metrics', 'gate')}
                                          for row in state['epoch_records']]}
        if record is None:
            continue
        evaluation = evaluations[selected_epoch]
        cases = evaluation['cases']
        by_case = evaluation_cases(evaluation, expected_count)
        for case in cases:
            case_hash = case['case_sha256']
            case_rows.append({'method': key, 'arm': entry['arm'], 'seed': entry['seed'],
                              'epoch': selected_epoch, 'case_sha256': case_hash,
                              'distribution': case['distribution'], 'cmax': case['makespan']})
        grouped.setdefault(entry['arm'], {})[str(entry['seed'])] = by_case
    comparisons = {}
    for right_arm in ('B1_dag', 'B0_none'):
        if 'B2_R1' not in grouped or right_arm not in grouped:
            continue
        lhs, rhs = grouped['B2_R1'], grouped[right_arm]
        if set(lhs) != set(rhs):
            continue
        seeds = sorted(lhs)
        per_seed = {seed: paired_comparison(lhs[seed], rhs[seed]) for seed in seeds}
        case_keys = set(lhs[seeds[0]])
        if any(set(group[seed]) != case_keys for group in (lhs, rhs) for seed in seeds):
            raise ValueError('Case sets vary across training seeds.')
        averaged = [{key: float(np.mean([group[seed][key] for seed in seeds]))
                     for key in case_keys} for group in (lhs, rhs)]
        comparisons[f'B2_R1_minus_{right_arm}'] = {
            **paired_comparison(*averaged), 'training_seeds': seeds, 'per_seed': per_seed,
        }
    report = {'schema_version': 1, 'manifest': str(manifest_path), 'profile': manifest['profile'],
              'complete': True, 'methods': methods, 'paired_comparisons': comparisons,
              'formal_promotion': False,
              'note': 'Canary is engineering-only; pilot cannot lock Stage2 or trigger formal training automatically.'}
    if publish:
        atomic_json(suite / 'analysis/comparison.json', json_safe(report))
    if publish and case_rows:
        with (suite / 'analysis/paired_cases.csv').open('w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(case_rows[0]))
            writer.writeheader()
            writer.writerows(case_rows)
    if publish:
        print(json.dumps({'integrity_passed': True, 'methods': len(methods),
                          'comparisons': list(comparisons)}))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    analyze(parser.parse_args().manifest)
