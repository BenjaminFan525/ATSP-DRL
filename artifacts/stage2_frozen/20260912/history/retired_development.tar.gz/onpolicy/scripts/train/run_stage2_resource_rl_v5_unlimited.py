#!/usr/bin/env python3
"""The existing V5 training worker with explicitly user-disabled wall-clock limits.

All scientific methods are inherited unchanged. Episode/step, numerical, KL,
lineage, GPU/CPU and no-retry checks remain active.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import yaml
from onpolicy.scripts.train.run_stage2_resource_rl import Progress, arguments
from onpolicy.scripts.train.run_stage2_resource_rl_v5 import SplitSuite
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_policy_transfer import verified_frozen_ready_source
from onpolicy.utils.stage2_resource_rl_handoff import validate_frozen_lineage
from onpolicy.utils.stage2_resource_rl_v5 import ARMS

VERSION = 'v5_user_disabled_wallclock_v1'


def require_time_authorization(manifest):
    authorization = manifest.get('time_limit_removal', {})
    if (authorization.get('version') != VERSION
            or authorization.get('user_request') != '解除超时门禁'
            or authorization.get('wall_clock_limit_enabled') is not False
            or authorization.get('projected_time_gate_enabled') is not False
            or manifest['resource_contract'].get('runtime_max_seconds') is not None):
        raise ValueError('Explicit unlimited-time authorization for this fixed experiment is required.')
    return authorization


class UnlimitedProgress(Progress):
    def __init__(self, suite):
        super().__init__(suite, math.inf)

    def write(self):
        with self.lock:
            self.state.update(updated_unix=time.time(), elapsed_seconds=time.time() - self.started,
                hard_deadline_unix=None, wall_clock_limit_enabled=False,
                time_authorization_version=VERSION)
            atomic_json(self.suite / 'run_status.json', self.state)


class UnlimitedSplitSuite(SplitSuite):
    def validate_manifest(self):
        require_time_authorization(self.m)
        if self.phase != 'train':
            raise ValueError('Passed engineering/setup must be retained, never repeated.')
        return super().validate_manifest()

    def run(self):
        self.validate_manifest()
        control = json.loads((self.root / 'control.json').read_text())
        if control.get('hard_deadline_unix', 'missing') is not None or control.get('time_authorization_version') != VERSION:
            raise ValueError('Controller has not acknowledged disabled wall-clock limits.')
        self.worker_root.mkdir(parents=True, exist_ok=True)
        self.progress = UnlimitedProgress(self.worker_root)

        def stop(signum, frame):
            raise KeyboardInterrupt(f'Operator/service signal {signum}')

        signal.signal(signal.SIGTERM, stop)
        signal.alarm(0)
        try:
            configure_bc_determinism(True)
            torch.set_num_threads(1)
            torch.cuda.set_per_process_memory_fraction(.42, 0)
            if str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') != self.m['resource_contract']['gpu_uuid'].removeprefix('GPU-'):
                raise ValueError('Physical GPU UUID differs from authorized GPU0.')
            self.args = arguments(self.m)
            self.payload = torch.load(self.m['source']['path'], map_location='cpu', weights_only=True)
            verified_frozen_ready_source(self.payload)
            for key, value in ready_head_config(self.payload).items():
                setattr(self.args, key, value)
            self.ac_config = yaml.safe_load(Path(self.args.ac_config).read_text())
            atomic_json(self.worker_root / 'frozen_lineage.json', validate_frozen_lineage(self.payload, self.m['stage1_source']))
            completed = self.train_one()
            self.progress('completed' if completed else 'paused_for_kl', force=True,
                status='completed' if completed else 'paused_for_kl', phase=self.phase, arm=self.arm,
                completed_physical_case_episodes=self.total_episodes, scientific_success_confirmed=False)
            return 0
        except BaseException as exc:
            self.progress.state.update(event='worker_stopped', status='timeout' if isinstance(exc, TimeoutError) else 'failed',
                                       error=str(exc), traceback=traceback.format_exc())
            self.progress.write()
            if self.learner is not None:
                try:
                    self.checkpoint(self.learner, 'checkpoint_interrupted.pt')
                except Exception as save_error:
                    print('Could not save interruption checkpoint:', save_error, flush=True)
            print(traceback.format_exc(), flush=True)
            return 1
        finally:
            signal.alarm(0)
            self.progress.stop.set()
            if self.envs is not None:
                self.envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--phase', choices=('train',), required=True)
    parser.add_argument('--arm', choices=ARMS, required=True)
    parser.add_argument('--slot', type=int, choices=(0, 1), required=True)
    cli = parser.parse_args()
    sys.exit(UnlimitedSplitSuite(cli.manifest, cli.phase, cli.arm, cli.slot).run())
