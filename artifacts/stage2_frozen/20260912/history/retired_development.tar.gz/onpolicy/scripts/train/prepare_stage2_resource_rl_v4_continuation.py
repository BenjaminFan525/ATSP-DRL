#!/usr/bin/env python3
"""Pin a single checkpoint continuation without resetting the experiment."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl_v4 import Suite
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v4 import ARMS
from onpolicy.utils.stage2_resource_rl_v4_fast import FAST_VERSION
from onpolicy.utils.stage2_resource_rl_v4_resume import continuation_budget, select_committed_checkpoint

NEW_FILES = (
    'onpolicy/utils/stage2_resource_rl_v4_fast.py',
    'onpolicy/utils/stage2_resource_rl_v4_resume.py',
    'onpolicy/scripts/train/continue_stage2_resource_rl_v4.py',
    'onpolicy/scripts/train/prepare_stage2_resource_rl_v4_continuation.py',
    'onpolicy/scripts/train/smoke_stage2_resource_rl_v4_fast.py',
    'onpolicy/scripts/train/launch_stage2_resource_rl_v4_continuation_gpu0.sh',
    'onpolicy/envs/HKBZ/test/test_stage2_resource_rl_v4_fast.py',
)


def prepare(cli):
    parent, output = cli.parent.resolve(), cli.output.resolve()
    if output.exists():
        raise FileExistsError('Never reuse a continuation output directory.')
    service = subprocess.run(['systemctl', '--user', 'is-active', cli.parent_service],
        capture_output=True, text=True, check=False)
    if service.returncode != 3 or service.stdout.strip() not in ('inactive', 'failed'):
        raise ValueError(f'Parent must be explicitly stopped first: {service.stdout.strip()}')
    manifest_path, status_path = parent / 'manifest.json', parent / 'run_status.json'
    old = json.loads(manifest_path.read_text())
    status = json.loads(status_path.read_text())
    validator = Suite(manifest_path)
    validator.root = output  # reuse all original immutable/data checks, not its run-directory check
    validator.validate_manifest()
    proof_path = cli.proof.resolve()
    proof = json.loads(proof_path.read_text())
    if not proof.get('passed') or set(proof.get('arms', {})) != set(ARMS):
        raise ValueError('Both baselines require a passed acceleration proof.')
    fingerprints = {name: file_sha(ROOT / name) for name in NEW_FILES}
    if any(proof['code_fingerprint'].get(name) != fingerprints[name] for name in (
            'onpolicy/utils/stage2_resource_rl_v4_fast.py', 'onpolicy/utils/stage2_resource_rl_v4_resume.py')):
        raise ValueError('Tested acceleration or restoration code changed after verification.')
    checkpoints = {arm: select_committed_checkpoint(parent, arm) for arm in ARMS}
    evaluations = {p.stem: json.loads(p.read_text()) for p in (parent / 'evaluations').glob('*.json')}
    for label in ('S2RL_F_H', 'S2RL_F_AR'):
        if len(evaluations[label]['cases']) != 60:
            raise ValueError('The original preflight is not complete.')
    if not json.loads((parent / 'checks/source_replay.json').read_text())['passed']:
        raise ValueError('Original strict source replay failed.')
    reference_path = parent / 'reference/summary.json'
    if json.loads(reference_path.read_text())['complete_reference_case_episodes'] != 240:
        raise ValueError('Cannot skip an incomplete frozen reference rollout.')
    deadline = float(status['hard_deadline_unix'])
    if deadline <= time.time():
        raise TimeoutError('Original deadline reached; continuation does not grant another 24 hours.')
    budget = continuation_budget(old, checkpoints, evaluations, status['attempted_physical_case_episodes'])
    paths = [manifest_path, status_path, proof_path, reference_path,
        parent / 'reference/value_features.pt', parent / 'checks/source_replay.json',
        parent / 'checks/probabilities.json', parent / 'checks/independent_rng_first_round.json',
        parent / 'S2RL_PPO_V/critic_warmup.json']
    for item in checkpoints.values():
        paths += [Path(item[key]) for key in ('path', 'result_path', 'update_path')]
    preserved = {}
    for label in evaluations:
        path = parent / 'evaluations' / (label + '.json')
        paths.append(path)
        preserved[label] = dict(path=str(path), sha256=file_sha(path))
    manifest = copy.deepcopy(old)
    manifest['run_tag'] = output.name
    manifest['continuation_of_run_tag'] = old['run_tag']
    manifest['created_at'] = datetime.now(timezone.utc).isoformat()
    manifest['material_passport'] = dict(origin_skill='academic-research-suite/experiment-agent',
        origin_mode='checkpoint_continuation', origin_date=datetime.now().date().isoformat(),
        verification_status='UNVERIFIED', engineering_verified=True, scientific_goal_verified=False)
    manifest['continuation'] = dict(version=FAST_VERSION, prepared_unix=time.time(),
        parent_manifest=str(manifest_path), parent_service=cli.parent_service,
        original_started_unix=status['started_unix'], hard_deadline_unix=deadline,
        checkpoints=checkpoints, budget=budget, reference_summary=str(reference_path),
        preserved_evaluations=preserved, engineering_proof=dict(path=str(proof_path), sha256=file_sha(proof_path)),
        immutable_inputs={str(path): file_sha(path) for path in paths}, new_code_fingerprint=fingerprints,
        worker_cpus={ARMS[0]: '0-11,64-75', ARMS[1]: '12-23,76-87'},
        # The full six-case proof retained 2.01 GiB of immutable inputs. A
        # production rollout has four such groups; 4 GiB would evict roughly
        # half the prepared inputs. 12 GiB fits the measured ~8 GiB footprint
        # with margin, while the independent 43% allocator cap remains hard.
        acceleration=dict(replay_gpu_cache_bytes=12 * 1024 ** 3,
            cuda_memory_fraction_per_worker=.43, async_graph_clone_workers=2,
            independent_arm_processes=True, evaluations_serialized=True,
            evaluation_training_overlap=True,
            prepared_collection_inputs=True, prepared_replay_inputs=True,
            batched_diagnostic_sync=True, mixed_precision=False, tf32=False,
            training_contract_changed=False, critic_reinitialized=False),
        automatic_retry=False, old_artifacts_preserved=True, stage3_started=False)
    output.mkdir(parents=True)
    # A source snapshot, not a rewrite of the original pinned code/archive.
    for name in NEW_FILES:
        destination = output / 'source' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((ROOT / name).read_bytes())
    atomic_json(output / 'manifest.json', manifest)
    print(json.dumps(dict(manifest=str(output / 'manifest.json'),
        resume_rounds={arm: x['state']['completed_rounds'] for arm, x in checkpoints.items()},
        budget=budget, hard_deadline_unix=deadline), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--proof', type=Path, required=True)
    parser.add_argument('--parent-service', required=True)
    prepare(parser.parse_args())
