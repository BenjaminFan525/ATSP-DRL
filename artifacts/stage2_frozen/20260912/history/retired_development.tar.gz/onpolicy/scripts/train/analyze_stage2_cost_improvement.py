#!/usr/bin/env python3
"""Four-arm integrity + cost-budget audits; never auto-promote to RL/Stage3."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from onpolicy.scripts.train.analyze_stage2_matching_gap import analyze as base_analyze
from onpolicy.scripts.train.prepare_stage2_cost_improvement import ARMS
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_iga_contract import file_digest
from onpolicy.utils.stage2_cost_improvement import COST_CONTRACT


def analyze(path):
    path = Path(path).resolve()
    manifest = json.loads(path.read_text())
    if (manifest['research_family'] != 'stage2_cost_improvement'
            or set(manifest['commands']) != {arm + '_seed11' for arm in ARMS}):
        raise ValueError('A complete N0-N3 contemporaneous comparison is required.')
    # Base audit is reused for checkpoint scope, source replay, raw epochs,
    # group/tail fallback, IGA screen and protected-parameter checks.
    report = base_analyze(path, canary_gate=False)
    total_queries = 0
    verified_artifacts = set()
    for key, method in report['methods'].items():
        run = Path(method['run_dir'])
        entry = manifest['commands'][key]
        last = torch.load(run / 'models/checkpoint_Last.pt', map_location='cpu', weights_only=True)
        summaries = []
        for epoch in (1, 2):
            summary = json.loads((run / f'logs/cost_summary_epoch{epoch}.json').read_text())
            if (summary['contract'] != COST_CONTRACT or summary['enabled'] != entry['cost_improvement']
                    or summary['epoch'] != epoch or any(n > 2 for n in summary['case_counts'].values())):
                raise ValueError('Cost iteration contract or state budget failed.')
            if entry['cost_improvement']:
                evidence_path = run / f'logs/cost_evidence_epoch{epoch}.jsonl'
                if file_digest(evidence_path) != summary['evidence_sha256']:
                    raise ValueError('Cost evidence was changed after the epoch.')
                rows = [json.loads(line) for line in evidence_path.read_text().splitlines()]
                for row in rows:
                    artifacts = [(row['state_path'], row['state_sha256']),
                                 (row['target_checkpoint'], row['target_file_sha256'])]
                    artifacts += [(x['path'], x['file_sha256']) for x in row['environment_snapshots']]
                    for artifact, expected in artifacts:
                        if artifact not in verified_artifacts and file_digest(artifact) != expected:
                            raise ValueError('Saved full-state continuation evidence changed.')
                        verified_artifacts.add(artifact)
                queries = sum(len(row['candidates']) for row in rows)
                if queries != summary['counts']['candidate_queries'] or any(
                    row['policy_sha256'] != summary['policy_sha256'] or row['batch_width'] != manifest['training_contract']['workers']
                    or len(row['candidates']) > 4 or row['origins'][0] != 'student' for row in rows):
                    raise ValueError('Continuation policy, batch, incumbent or query ledger failed.')
                if (queries <= 0 or summary['counts']['incomplete']
                        or method['matching_training_metrics'][epoch - 1].get('device_bc_cost_pairs', 0) <= 0):
                    raise ValueError('No verified cost learning or incomplete continuation; do not certify the arm.')
                total_queries += queries
            elif summary['counts']['candidate_queries']:
                raise ValueError('The BC control consumed counterfactual training labels.')
            summaries.append(summary)
        method['cost_iteration_summaries'] = summaries
    if total_queries > manifest['cost_contract']['candidate_continuation_budget']:
        raise ValueError('Suite exceeded its preregistered candidate continuation budget.')
    report.update(manifest=str(path), total_candidate_continuations=total_queries,
        cost_integrity_passed=True, canary_contract_passed=manifest['profile'] == 'canary',
        phase_a_proof=manifest['diagnostic_proof'], formal_promotion=False,
        stage3_training_started=False, confirmed_scientific_success=False)
    atomic_json(path.parent / 'analysis/comparison.json', report)
    print(json.dumps({'cost_integrity_passed': True, 'candidate_queries': total_queries,
                      'canary_contract_passed': report['canary_contract_passed']}))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    analyze(parser.parse_args().manifest)
