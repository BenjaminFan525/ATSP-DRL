#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
LAUNCHER="${ROOT}/onpolicy/scripts/train/launch_stage2_ready_head_reliability_gpu0.sh"
RUN_TAG="${RUN_TAG:-stage2_ready_reliable_20260904_r1}"
SUITE_DIR="${SUITE_DIR:-${ROOT}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT_PREFIX="${UNIT_PREFIX:-hkbz-s2-ready-rel-20260904-r1}"
QUEUE_UNIT="${QUEUE_UNIT:-${UNIT_PREFIX}-queue}"
POLL_SECONDS="${POLL_SECONDS:-60}"
IDLE_MEMORY_MIB="${IDLE_MEMORY_MIB:-2048}"

worker_main() {
  local used pids consecutive=0
  echo "[Queue] waiting for exclusive GPU0 availability before ${RUN_TAG}"
  while true; do
    if [[ -e "${SUITE_DIR}" ]]; then
      echo "[Queue] suite already exists; refusing a duplicate launch: ${SUITE_DIR}" >&2
      return 2
    fi
    used="$(nvidia-smi --id=0 --query-gpu=memory.used --format=csv,noheader,nounits | tr -d ' ')"
    pids="$(nvidia-smi --id=0 --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null || true)"
    if [[ -z "${pids//[[:space:]]/}" ]] && (( used <= IDLE_MEMORY_MIB )); then
      consecutive=$((consecutive + 1))
      echo "[Queue] GPU0 idle confirmation ${consecutive}/2 memory=${used} MiB"
      if (( consecutive >= 2 )); then
        break
      fi
    else
      consecutive=0
      echo "[Queue] GPU0 busy memory=${used} MiB compute_pids=${pids//$'\n'/,}"
    fi
    sleep "${POLL_SECONDS}"
  done
  echo "[Queue] GPU0 is stably idle; launching the five-arm suite"
  RUN_TAG="${RUN_TAG}" SUITE_DIR="${SUITE_DIR}" UNIT_PREFIX="${UNIT_PREFIX}" \
    /bin/bash "${LAUNCHER}"
}

start_queue() {
  local state log
  [[ -x "${LAUNCHER}" || -f "${LAUNCHER}" ]] || {
    echo "[Error] missing launcher: ${LAUNCHER}" >&2
    exit 1
  }
  [[ ! -e "${SUITE_DIR}" ]] || {
    echo "[Error] suite already exists: ${SUITE_DIR}" >&2
    exit 1
  }
  state="$(systemctl --user show "${QUEUE_UNIT}.service" -p LoadState --value 2>/dev/null || true)"
  [[ -z "${state}" || "${state}" == not-found ]] || {
    echo "[Error] queue service already exists: ${QUEUE_UNIT}.service" >&2
    exit 1
  }
  log="${ROOT}/result/hkbz_train_logs/${RUN_TAG}.queue.log"
  systemd-run --user --unit="${QUEUE_UNIT}" --same-dir \
    --setenv="RUN_TAG=${RUN_TAG}" \
    --setenv="SUITE_DIR=${SUITE_DIR}" \
    --setenv="UNIT_PREFIX=${UNIT_PREFIX}" \
    --setenv="POLL_SECONDS=${POLL_SECONDS}" \
    --setenv="IDLE_MEMORY_MIB=${IDLE_MEMORY_MIB}" \
    --property=Type=exec \
    --property=Restart=no \
    --property=KillMode=control-group \
    --property=Nice=19 \
    --property="AllowedCPUs=70-71,142-143" \
    --property="CPUAffinity=70-71,142-143" \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    /bin/bash "${BASH_SOURCE[0]}" --worker >/dev/null
  sleep 2
  state="$(systemctl --user is-active "${QUEUE_UNIT}.service" 2>/dev/null || true)"
  [[ "${state}" == active || "${state}" == activating ]] || {
    echo "[Error] queue service failed initial health check: ${state}" >&2
    exit 1
  }
  echo "[Queued] ${QUEUE_UNIT}.service"
  echo "[Queued] GPU0 will be rechecked every ${POLL_SECONDS}s"
  echo "[Queued] log=${log}"
}

if [[ "${1:-}" == --worker ]]; then
  worker_main
else
  start_queue
fi

