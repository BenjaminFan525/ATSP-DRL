#!/usr/bin/env bash
set -euo pipefail

# One-command matched-budget legacy Stage2 comparison (GPU0 by default). Three
# trainers own complete SMT sibling pairs and share one persistent validator.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARE="${ROOT_DIR}/onpolicy/scripts/train/prepare_stage2_legacy_baselines.py"
TRIAL_RUNNER="${ROOT_DIR}/onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
EVALUATOR="${ROOT_DIR}/onpolicy/scripts/train/shared_hkbz_evaluator.py"

RUN_TAG="${RUN_TAG:-stage2_legacy_baselines_20260903_r1}"
SUITE_DIR="${SUITE_DIR:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT_PREFIX="${UNIT_PREFIX:-hkbz-s2-legacy-20260903-r1}"
GPU_ID="${GPU_ID:-0}"
VALIDATION_DIR="${VALIDATION_DIR:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-12}"
DRY_RUN="${DRY_RUN:-0}"

METHODS=(
  L0_legacy_full
  L1_legacy_ranking_only
  L2_legacy_timing_only
)
# The host has 72 physical cores with SMT siblings separated by 72.  Keep
# every sibling pair in one cgroup.  The validator receives 16 physical cores
# for 20 workers; two physical cores remain for monitoring and the OS.
TRAIN_CPUS=(
  0-17,72-89
  18-35,90-107
  36-53,108-125
)
VAL_CPUS="54-69,126-141"
MONITOR_CPUS="70-71,142-143"

manifest_path() { echo "${SUITE_DIR}/commands/legacy_baselines.json"; }
trainer_unit() { echo "${UNIT_PREFIX}-g${GPU_ID}l$1"; }
evaluator_unit() { echo "${UNIT_PREFIX}-g${GPU_ID}eval"; }
monitor_unit() { echo "${UNIT_PREFIX}-monitor"; }

numa_for_lane() {
  if (( $1 < 2 )); then echo 0; else echo 1; fi
}

verify_inputs() {
  local path
  for path in "${PYTHON}" "${PREPARE}" "${TRIAL_RUNNER}" \
    "${EVALUATOR}" "${VALIDATION_DIR}"; do
    [[ -e "${path}" ]] || { echo "[Error] missing ${path}" >&2; exit 1; }
  done
  [[ "$(nproc)" -eq 144 ]] || {
    echo "[Error] expected 144 logical CPUs, got $(nproc)" >&2; exit 1;
  }
  [[ "${GPU_ID}" == 0 || "${GPU_ID}" == 1 ]] || {
    echo "[Error] GPU_ID must be 0 or 1, got ${GPU_ID}" >&2; exit 1;
  }
}

verify_cpu_partition() {
  "${PYTHON}" - "${TRAIN_CPUS[@]}" "${VAL_CPUS}" "${MONITOR_CPUS}" <<'PY'
import sys

def expand(spec):
    values = set()
    for part in spec.split(','):
        lo, sep, hi = part.partition('-')
        values.update(range(int(lo), int(hi) + 1) if sep else (int(lo),))
    return values

groups = [expand(value) for value in sys.argv[1:]]
widths = [36, 36, 36, 32, 4]
if [len(group) for group in groups] != widths:
    raise SystemExit(f'CPU widths mismatch: {[len(group) for group in groups]}')
union = set()
for index, group in enumerate(groups):
    overlap = union & group
    if overlap:
        raise SystemExit(f'CPU overlap in group {index}: {sorted(overlap)}')
    union |= group
    for cpu in group:
        sibling = cpu + 72 if cpu < 72 else cpu - 72
        if sibling not in group:
            raise SystemExit(f'group {index} splits SMT siblings {cpu}/{sibling}')
if union != set(range(144)):
    missing = sorted(set(range(144)) - union)
    raise SystemExit(f'CPU partition does not cover host: missing={missing}')
print('[CPU] 3x36 trainer + 32 shared validator + 4 OS/monitor = 144 logical CPUs')
PY
}

verify_gpu() {
  local row busy
  row="$(nvidia-smi --id="${GPU_ID}" --query-gpu=index,name,memory.total --format=csv,noheader,nounits)"
  [[ "${row}" == "${GPU_ID},"* ]] && [[ "${row}" == *"A800 80GB"* ]] || {
    echo "[Error] GPU${GPU_ID} hardware differs from calibration: ${row}" >&2; exit 1;
  }
  busy="$(nvidia-smi --id="${GPU_ID}" --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null || true)"
  [[ -z "${busy//[[:space:]]/}" ]] || {
    echo "[Error] GPU${GPU_ID} has active compute PIDs: ${busy}" >&2; exit 1;
  }
}

require_fresh_run() {
  [[ ! -e "${SUITE_DIR}" ]] || {
    echo "[Error] suite already exists: ${SUITE_DIR}" >&2; exit 1;
  }
  local lane unit state
  for lane in 0 1 2; do
    unit="$(trainer_unit "${lane}").service"
    state="$(systemctl --user show "${unit}" -p LoadState --value 2>/dev/null || true)"
    [[ -z "${state}" || "${state}" == not-found ]] || {
      echo "[Error] systemd unit already exists: ${unit}" >&2; exit 1;
    }
  done
  for unit in "$(evaluator_unit).service" "$(monitor_unit).service"; do
    state="$(systemctl --user show "${unit}" -p LoadState --value 2>/dev/null || true)"
    [[ -z "${state}" || "${state}" == not-found ]] || {
      echo "[Error] systemd unit already exists: ${unit}" >&2; exit 1;
    }
  done
}

prepare_manifest() {
  mkdir -p "${SUITE_DIR}"/{commands,records,service_logs,shared_evaluator,hardware}
  "${PYTHON}" "${PREPARE}" --run-tag "${RUN_TAG}" \
    --suite-dir "${SUITE_DIR}" --output "$(manifest_path)" \
    --gpu-id "${GPU_ID}"
}

launch_evaluator() {
  local unit socket log
  unit="$(evaluator_unit)"
  socket="/tmp/${unit}.sock"
  log="${SUITE_DIR}/service_logs/${unit}.log"
  [[ ! -e "${socket}" ]] || {
    echo "[Error] stale socket ${socket}" >&2; exit 1;
  }
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv="CUDA_VISIBLE_DEVICES=${GPU_ID}" --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv=MPLCONFIGDIR=/tmp/hkbz-mpl \
    --property=Type=exec --property=Restart=no --property=KillMode=control-group \
    --property=TimeoutStopSec=180 --property=LimitNOFILE=65536 \
    --property="AllowedCPUs=${VAL_CPUS}" \
    --property="CPUAffinity=${VAL_CPUS}" \
    --property=NUMAPolicy=bind --property=NUMAMask=1 \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    "${PYTHON}" -u "${EVALUATOR}" \
      --source-command-json "$(manifest_path)" --socket-path "${socket}" \
      --cpu-pool "${VAL_CPUS}" \
      --run-dir "${SUITE_DIR}/shared_evaluator/gpu${GPU_ID}" \
      --eval-dataset-dir "${VALIDATION_DIR}" --max-eval-cases 60 \
      --cuda-memory-fraction 0.04 --eval-partition-seed 20260811 \
      --eval-partition-stratify-by distribution >/dev/null
  echo "${socket}"
}

wait_evaluator() {
  local socket="$1" deadline unit
  unit="$(evaluator_unit)"
  deadline=$((SECONDS + 1200))
  while (( SECONDS < deadline )); do
    [[ "$(systemctl --user is-active "${unit}.service" 2>/dev/null || true)" == active ]] || {
      echo "[Error] evaluator stopped before ready" >&2; return 1;
    }
    if [[ -S "${socket}" ]] && "${PYTHON}" - "${socket}" <<'PY'
import sys
from onpolicy.utils.shared_eval import SharedEvalClient

response = SharedEvalClient(sys.argv[1], timeout_seconds=5).ping()
raise SystemExit(0 if int(response.get('worker_count', -1)) == 20 else 1)
PY
    then
      echo "[Ready] ${unit}.service workers=20 CPUs=${VAL_CPUS}" >&2
      return 0
    fi
    sleep 2
  done
  echo "[Error] evaluator readiness timeout" >&2
  return 1
}

launch_trainer() {
  local lane="$1" socket="$2" method cpus node unit log delay
  method="${METHODS[${lane}]}"
  cpus="${TRAIN_CPUS[${lane}]}"
  node="$(numa_for_lane "${lane}")"
  unit="$(trainer_unit "${lane}")"
  log="${SUITE_DIR}/service_logs/${unit}.log"
  delay=$((lane * START_STAGGER_SECONDS))
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv="CUDA_VISIBLE_DEVICES=${GPU_ID}" --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv=MPLCONFIGDIR=/tmp/hkbz-mpl \
    --property=Type=exec --property=Restart=no --property=KillMode=control-group \
    --property=TimeoutStopSec=180 --property=LimitNOFILE=65536 \
    --property="AllowedCPUs=${cpus}" --property="CPUAffinity=${cpus}" \
    --property=NUMAPolicy=bind --property="NUMAMask=${node}" \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "$(manifest_path)" --command-key "${method}" \
      --gpu "${GPU_ID}" --cpu-set "${cpus}" \
      --shared-eval-socket "${socket}" \
      --shared-eval-cpu-set "${VAL_CPUS}" \
      --eval-workers 20 --start-delay-seconds "${delay}" \
      --record "${SUITE_DIR}/records/g${GPU_ID}l${lane}.json" >/dev/null
  echo "[Launch] ${unit}.service ${method} CPUs=${cpus} NUMA=${node} delay=${delay}s"
}

stop_started_units() {
  local lane
  systemctl --user stop "$(monitor_unit).service" >/dev/null 2>&1 || true
  for lane in 0 1 2; do
    systemctl --user stop "$(trainer_unit "${lane}").service" >/dev/null 2>&1 || true
  done
  systemctl --user stop "$(evaluator_unit).service" >/dev/null 2>&1 || true
}

monitor_main() {
  local output active lane state gpu_mem gpu_util mem_available swap_used
  output="${SUITE_DIR}/hardware/runtime_usage.csv"
  echo 'unix_time,gpu_memory_used_mib,gpu_util_percent,mem_available_mib,swap_used_mib,active_trainers' >"${output}"
  while true; do
    active=0
    for lane in 0 1 2; do
      state="$(systemctl --user is-active "$(trainer_unit "${lane}").service" 2>/dev/null || true)"
      [[ "${state}" == active || "${state}" == activating ]] && active=$((active + 1))
    done
    gpu_mem="$(nvidia-smi --id="${GPU_ID}" --query-gpu=memory.used --format=csv,noheader,nounits | tr -d ' ')"
    gpu_util="$(nvidia-smi --id="${GPU_ID}" --query-gpu=utilization.gpu --format=csv,noheader,nounits | tr -d ' ')"
    mem_available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap_used="$(awk '/SwapTotal:/ {total=$2} /SwapFree:/ {free=$2} END {printf "%d", (total-free)/1024}' /proc/meminfo)"
    echo "$(date +%s),${gpu_mem},${gpu_util},${mem_available},${swap_used},${active}" >>"${output}"
    if (( active == 0 )); then
      systemctl --user stop "$(evaluator_unit).service" >/dev/null 2>&1 || true
      break
    fi
    sleep 30
  done
}

launch_monitor() {
  local unit log
  unit="$(monitor_unit)"
  log="${SUITE_DIR}/service_logs/${unit}.log"
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv=HKBZ_STAGE2_LEGACY_MONITOR=1 --setenv="RUN_TAG=${RUN_TAG}" \
    --setenv="SUITE_DIR=${SUITE_DIR}" --setenv="UNIT_PREFIX=${UNIT_PREFIX}" \
    --setenv="GPU_ID=${GPU_ID}" \
    --property=Type=exec --property=Restart=no --property=KillMode=control-group \
    --property="AllowedCPUs=${MONITOR_CPUS}" \
    --property="CPUAffinity=${MONITOR_CPUS}" \
    --property=NUMAPolicy=bind --property=NUMAMask=1 \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    /bin/bash "${BASH_SOURCE[0]}" >/dev/null
}

verify_services() {
  local lane unit state
  sleep 3
  for lane in 0 1 2; do
    unit="$(trainer_unit "${lane}")"
    state="$(systemctl --user is-active "${unit}.service" 2>/dev/null || true)"
    [[ "${state}" == active || "${state}" == activating ]] || {
      echo "[Error] ${unit}.service failed initial health check (${state})" >&2
      return 1
    }
  done
}

main() {
  local socket lane
  verify_inputs
  verify_cpu_partition
  require_fresh_run
  prepare_manifest
  if [[ "${DRY_RUN}" == 1 ]]; then
    echo "[DryRun] manifest=$(manifest_path)"
    echo "[DryRun] methods=${METHODS[*]}"
    return 0
  fi
  verify_gpu
  trap stop_started_units ERR INT TERM
  socket="$(launch_evaluator)"
  wait_evaluator "${socket}"
  for lane in 0 1 2; do
    launch_trainer "${lane}" "${socket}"
  done
  verify_services
  launch_monitor
  trap - ERR INT TERM
  echo "[Started] matched-budget legacy Stage2 baselines on GPU${GPU_ID}"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] CPU=3x36 isolated trainers + 32 shared validator + 4 reserved"
}

if [[ "${HKBZ_STAGE2_LEGACY_MONITOR:-0}" == 1 ]]; then
  monitor_main
else
  main "$@"
fi
