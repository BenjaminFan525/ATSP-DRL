#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARE="${ROOT}/onpolicy/scripts/train/prepare_stage2_ready_head_reliability.py"
TRIAL_RUNNER="${ROOT}/onpolicy/scripts/train/run_stage2_ready_head_trial.py"
ANALYZER="${ROOT}/onpolicy/scripts/train/analyze_stage2_ready_head_reliability.py"
RUN_TAG="${RUN_TAG:-stage2_ready_reliable_20260904_local_a6000_r2}"
SUITE_DIR="${SUITE_DIR:-${ROOT}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT_PREFIX="${UNIT_PREFIX:-hkbz-s2-ready-rel-local-a6000-r2}"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-12}"
DRY_RUN="${DRY_RUN:-0}"
ALLOW_SHARED_GPU0="${ALLOW_SHARED_GPU0:-0}"
MIN_FREE_GPU0_MIB="${MIN_FREE_GPU0_MIB:-16384}"

METHODS=(
  R0_block_rule_control
  R1_symmetric_hybrid
  R2_explicit_context
  R3_split_kind_balanced
  R4_ordered_quantiles
)
CPU_SETS=(
  0-6,64-70
  7-13,71-77
  14-19,78-83
  20-25,84-89
  26-31,90-95
)

manifest_path() { printf '%s/ready_head_reliability_manifest.json' "${SUITE_DIR}"; }
trainer_unit() { printf '%s-g0-l%s' "${UNIT_PREFIX}" "$1"; }
monitor_unit() { printf '%s-monitor' "${UNIT_PREFIX}"; }

verify_inputs() {
  local path
  for path in "${PYTHON}" "${PREPARE}" "${TRIAL_RUNNER}" "${ANALYZER}"; do
    [[ -e "${path}" ]] || { echo "[Error] missing ${path}" >&2; exit 1; }
  done
}

verify_cpu_partition() {
  "${PYTHON}" - "${CPU_SETS[@]}" <<'PY'
import os
import sys

def expand(spec):
    result = set()
    for part in spec.split(','):
        left, separator, right = part.partition('-')
        result.update(
            range(int(left), int(right) + 1)
            if separator else (int(left),)
        )
    return result

groups = [expand(value) for value in sys.argv[1:]]
expected = [14, 14, 12, 12, 12]
if [len(group) for group in groups] != expected:
    raise SystemExit(
        f'CPU widths differ from {expected}: {[len(x) for x in groups]}'
    )
union = set()
for index, group in enumerate(groups):
    overlap = union & group
    if overlap:
        raise SystemExit(f'CPU overlap in lane {index}: {sorted(overlap)}')
    union |= group
    for cpu in group:
        sibling = cpu + 64 if cpu < 64 else cpu - 64
        if sibling not in group:
            raise SystemExit(f'lane {index} splits SMT siblings {cpu}/{sibling}')
available = set(os.sched_getaffinity(0))
expected_union = set(range(32)) | set(range(64, 96))
if union != expected_union:
    raise SystemExit(
        f'partition differs from the local half-CPU contract: '
        f'missing={sorted(expected_union-union)}, extra={sorted(union-expected_union)}'
    )
if not union <= available:
    raise SystemExit(f'partition uses unavailable CPUs: {sorted(union-available)}')
if len(union) * 2 != len(available):
    raise SystemExit(
        f'partition is not half of launcher affinity: '
        f'allocated={len(union)} available={len(available)}'
    )
print('[CPU] five isolated lanes use 32 physical / 64 logical CPUs (half host)')
PY
}

verify_gpu0() {
  local row busy free used
  row="$(nvidia-smi --id=0 --query-gpu=index,name,memory.total --format=csv,noheader,nounits)"
  [[ "${row}" == 0,* ]] && [[ "${row}" == *"NVIDIA RTX A6000"* ]] || {
    echo "[Error] GPU0 differs from calibration: ${row}" >&2
    exit 1
  }
  busy="$(nvidia-smi --id=0 --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null || true)"
  if [[ -n "${busy//[[:space:]]/}" ]]; then
    [[ "${ALLOW_SHARED_GPU0}" == 1 ]] || {
      echo "[Error] GPU0 has active compute PIDs: ${busy}" >&2
      exit 1
    }
    read -r used free < <(
      nvidia-smi --id=0 \
        --query-gpu=memory.used,memory.free \
        --format=csv,noheader,nounits | tr -d ','
    )
    (( free >= MIN_FREE_GPU0_MIB )) || {
      echo "[Error] shared GPU0 has only ${free} MiB free; required ${MIN_FREE_GPU0_MIB} MiB" >&2
      exit 1
    }
    echo "[SharedGPU] GPU0 active_pids=${busy//$'\n'/,} used=${used}MiB free=${free}MiB"
  fi
}

require_fresh_run() {
  [[ ! -e "${SUITE_DIR}" ]] || {
    echo "[Error] suite already exists: ${SUITE_DIR}" >&2
    exit 1
  }
  local lane state unit
  for lane in 0 1 2 3 4; do
    unit="$(trainer_unit "${lane}").service"
    state="$(systemctl --user show "${unit}" -p LoadState --value 2>/dev/null || true)"
    [[ -z "${state}" || "${state}" == not-found ]] || {
      echo "[Error] systemd unit already exists: ${unit}" >&2
      exit 1
    }
  done
  unit="$(monitor_unit).service"
  state="$(systemctl --user show "${unit}" -p LoadState --value 2>/dev/null || true)"
  [[ -z "${state}" || "${state}" == not-found ]] || {
    echo "[Error] systemd unit already exists: ${unit}" >&2
    exit 1
  }
}

prepare_manifest() {
  mkdir -p "${SUITE_DIR}"/{records,service_logs,hardware,analysis}
  "${PYTHON}" "${PREPARE}" \
    --run-tag "${RUN_TAG}" \
    --suite-dir "${SUITE_DIR}" \
    --output "$(manifest_path)" \
    --cpu-sets "${CPU_SETS[@]}" \
    --gpu-launch-mode "$([[ "${ALLOW_SHARED_GPU0}" == 1 ]] && echo shared || echo exclusive)"
}

record_launch_hardware() {
  {
    echo 'timestamp,index,uuid,name,memory_total_mib,memory_used_mib,memory_free_mib,utilization_gpu_percent'
    nvidia-smi --id=0 \
      --query-gpu=timestamp,index,uuid,name,memory.total,memory.used,memory.free,utilization.gpu \
      --format=csv,noheader,nounits
  } >"${SUITE_DIR}/hardware/gpu0_at_launch.csv"
  nvidia-smi --id=0 \
    --query-compute-apps=gpu_uuid,pid,process_name,used_memory \
    --format=csv,noheader,nounits \
    >"${SUITE_DIR}/hardware/gpu0_compute_processes_at_launch.csv" || true
}

launch_lane() {
  local lane="$1"
  local method="${METHODS[${lane}]}"
  local cpus="${CPU_SETS[${lane}]}"
  local unit="$(trainer_unit "${lane}")"
  local log="${SUITE_DIR}/service_logs/${unit}.log"
  local delay=$((lane * START_STAGGER_SECONDS))
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv=CUDA_VISIBLE_DEVICES=0 \
    --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 \
    --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 \
    --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv=MPLCONFIGDIR=/tmp/hkbz-mpl \
    --property=Type=exec \
    --property=Restart=no \
    --property=KillMode=control-group \
    --property=TimeoutStopSec=180 \
    --property=LimitNOFILE=65536 \
    --property=TasksMax=infinity \
    --property=MemoryHigh=88G \
    --property=MemoryMax=96G \
    --property="AllowedCPUs=${cpus}" \
    --property="CPUAffinity=${cpus}" \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "$(manifest_path)" \
      --command-key "${method}" \
      --gpu 0 \
      --cpu-set "${cpus}" \
      --start-delay-seconds "${delay}" \
      --record "${SUITE_DIR}/records/g0l${lane}.json" >/dev/null
  echo "[Launch] ${unit}.service ${method} GPU=0 CPUs=${cpus} delay=${delay}s"
}

verify_services() {
  local lane state unit
  sleep 4
  for lane in 0 1 2 3 4; do
    unit="$(trainer_unit "${lane}")"
    state="$(systemctl --user is-active "${unit}.service" 2>/dev/null || true)"
    [[ "${state}" == active || "${state}" == activating ]] || {
      echo "[Error] ${unit}.service failed initial health check (${state})" >&2
      return 1
    }
  done
}

stop_started_units() {
  local lane
  systemctl --user stop "$(monitor_unit).service" >/dev/null 2>&1 || true
  for lane in 0 1 2 3 4; do
    systemctl --user stop "$(trainer_unit "${lane}").service" >/dev/null 2>&1 || true
  done
}

monitor_main() {
  local output active lane state gpu_mem gpu_util mem_available swap_used
  output="${SUITE_DIR}/hardware/runtime_usage.csv"
  echo 'unix_time,gpu0_memory_used_mib,gpu0_util_percent,mem_available_mib,swap_used_mib,active_trainers' >"${output}"
  while true; do
    active=0
    for lane in 0 1 2 3 4; do
      state="$(systemctl --user is-active "$(trainer_unit "${lane}").service" 2>/dev/null || true)"
      [[ "${state}" == active || "${state}" == activating ]] && active=$((active + 1))
    done
    gpu_mem="$(nvidia-smi --id=0 --query-gpu=memory.used --format=csv,noheader,nounits | tr -d ' ')"
    gpu_util="$(nvidia-smi --id=0 --query-gpu=utilization.gpu --format=csv,noheader,nounits | tr -d ' ')"
    mem_available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap_used="$(awk '/SwapTotal:/ {t=$2} /SwapFree:/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)"
    echo "$(date +%s),${gpu_mem},${gpu_util},${mem_available},${swap_used},${active}" >>"${output}"
    if (( active == 0 )); then
      break
    fi
    sleep 30
  done
  "${PYTHON}" "${ANALYZER}" \
    --manifest "$(manifest_path)" \
    --output "${SUITE_DIR}/analysis/selection.json"
}

launch_monitor() {
  local unit="$(monitor_unit)"
  local log="${SUITE_DIR}/service_logs/${unit}.log"
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv=HKBZ_STAGE2_READY_RELIABILITY_MONITOR=1 \
    --setenv="RUN_TAG=${RUN_TAG}" \
    --setenv="SUITE_DIR=${SUITE_DIR}" \
    --setenv="UNIT_PREFIX=${UNIT_PREFIX}" \
    --setenv="PYTHON=${PYTHON}" \
    --property=Type=exec \
    --property=Restart=no \
    --property=KillMode=control-group \
    --property=Nice=19 \
    --property=IOSchedulingClass=idle \
    --property="AllowedCPUs=30-31,94-95" \
    --property="CPUAffinity=30-31,94-95" \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    /bin/bash "${BASH_SOURCE[0]}" >/dev/null
}

main() {
  local lane
  cd "${ROOT}"
  verify_inputs
  verify_cpu_partition
  require_fresh_run
  prepare_manifest
  if [[ "${DRY_RUN}" == 1 ]]; then
    echo "[DryRun] manifest=$(manifest_path)"
    echo "[DryRun] methods=${METHODS[*]}"
    return 0
  fi
  verify_gpu0
  record_launch_hardware
  trap stop_started_units ERR INT TERM
  for lane in 0 1 2 3 4; do
    launch_lane "${lane}"
  done
  verify_services
  launch_monitor
  trap - ERR INT TERM
  echo "[Started] Stage2 ready-head reliability Wave1 on GPU0"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] CPU=5 physically isolated lanes using 64/128 logical CPUs"
}

if [[ "${HKBZ_STAGE2_READY_RELIABILITY_MONITOR:-0}" == 1 ]]; then
  monitor_main
else
  main "$@"
fi
