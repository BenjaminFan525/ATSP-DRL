#!/usr/bin/env bash
set -euo pipefail

# One-command Stage2 Wave-A screen.  A three-process canary proves the new
# potential/role-credit/counterfactual paths under the exact production memory
# layout, then six causal arms run as three isolated trainers per GPU.  Each GPU
# owns one persistent 12-worker validation service shared by its three arms.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARER="${ROOT_DIR}/onpolicy/scripts/train/prepare_stage2_event_credit_wave.py"
TRIAL_RUNNER="${ROOT_DIR}/onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
EVALUATOR="${ROOT_DIR}/onpolicy/scripts/train/shared_hkbz_evaluator.py"
AUTOPILOT="${ROOT_DIR}/onpolicy/scripts/train/stage2_event_credit_autopilot.py"

RUN_TAG="${RUN_TAG:-stage2_event_credit_wave_20260829_r2}"
SUITE_DIR="${SUITE_DIR:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT="${UNIT:-hkbz-s2-event-credit-wave-20260829-r2}"
AUTOPILOT_UNIT="${AUTOPILOT_UNIT:-${UNIT}-autopilot}"
DATASET="${DATASET:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train}"
VALIDATION_DIR="${VALIDATION_DIR:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
SOURCE_MANIFEST="${SOURCE_MANIFEST:-${ROOT_DIR}/result/hkbz_train_logs/stage2_stable_ppo_heads_20260828_r1/commands/wave1.json}"
POTENTIAL="${POTENTIAL:-${ROOT_DIR}/result/hkbz_train_logs/stage2_stable_ppo_heads_20260828_r1/artifacts/resource_potential_v2.json}"
CANARY_MANIFEST="${CANARY_MANIFEST:-${SUITE_DIR}/commands/canary.json}"
WAVE_MANIFEST="${WAVE_MANIFEST:-${SUITE_DIR}/commands/wave_a.json}"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-15}"

TRAIN_CPUS=(
  "0-9,72-81" "10-19,82-91" "20-29,92-101"
  "36-45,108-117" "46-55,118-127" "56-65,128-137"
)
VAL_CPUS=("30-35,102-107" "66-71,138-143")
EVALUATOR_PIDS=()
EVALUATOR_SOCKETS=()
TRAINER_PIDS=()
MONITOR_PID=""

stop_children() {
  local pid
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}"; do
    [[ -n "${pid}" ]] || continue
    kill "${pid}" >/dev/null 2>&1 || true
  done
  if [[ -n "${MONITOR_PID}" ]]; then
    kill "${MONITOR_PID}" >/dev/null 2>&1 || true
  fi
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}" "${MONITOR_PID}"; do
    [[ -n "${pid}" ]] || continue
    wait "${pid}" >/dev/null 2>&1 || true
  done
  TRAINER_PIDS=()
  EVALUATOR_PIDS=()
  EVALUATOR_SOCKETS=()
  MONITOR_PID=""
}

controller_exit() {
  local status=$?
  stop_children
  if (( status != 0 )); then
    "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"failed","failed_unix_time":time.time(),"exit_status":int(sys.argv[2])},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json" "${status}" || true
  fi
}

verify_cpu_topology() {
  "${PYTHON}" - "${TRAIN_CPUS[@]}" "${VAL_CPUS[@]}" <<'PY'
import os, sys

def expand(spec):
    result=set()
    for part in spec.split(','):
        lo, sep, hi=part.partition('-')
        result.update(range(int(lo), int(hi)+1) if sep else [int(lo)])
    return result

if os.cpu_count() != 144:
    raise SystemExit(f'expected 144 logical CPUs, got {os.cpu_count()}')
groups=[expand(spec) for spec in sys.argv[1:]]
trainers, evaluators=groups[:6], groups[6:]
for gpu in range(2):
    local=trainers[gpu*3:(gpu+1)*3]+[evaluators[gpu]]
    if [len(item) for item in local] != [20,20,20,12]:
        raise SystemExit(f'GPU{gpu} CPU widths are invalid')
    if sum(map(len, local)) != len(set().union(*local)):
        raise SystemExit(f'GPU{gpu} CPU sets overlap')
for group in groups:
    for cpu in group:
        sibling=cpu+72 if cpu < 72 else cpu-72
        if sibling not in group:
            raise SystemExit(f'CPU set splits SMT siblings {cpu}/{sibling}')
print('[CPU] verified two NUMA-local 3x20+12 physical-core partitions')
PY
}

prepare_manifests() {
  "${PYTHON}" -u "${PREPARER}" \
    --run-tag "${RUN_TAG}" --suite-dir "${SUITE_DIR}" \
    --source-manifest "${SOURCE_MANIFEST}" --potential "${POTENTIAL}" \
    --dataset-dir "${DATASET}" --python "${PYTHON}" \
    --wave-output "${WAVE_MANIFEST}" \
    --canary-output "${CANARY_MANIFEST}" \
    >"${SUITE_DIR}/service_logs/prepare.log" 2>&1
  echo "[Manifest] Wave A and production-layout canary prepared"
}

monitor_phase() {
  local phase="$1"
  local output="${SUITE_DIR}/hardware/${phase}_usage.csv"
  mkdir -p "${SUITE_DIR}/hardware"
  echo "unix_time,gpu0_mem_mib,gpu0_util,gpu1_mem_mib,gpu1_util,mem_available_mib,swap_used_mib" >"${output}"
  while true; do
    local rows g0m g0u g1m g1u available swap
    rows="$(nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader,nounits)"
    g0m="$(sed -n '1{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g0u="$(sed -n '1{s/.*,//;s/ //g;p}' <<<"${rows}")"
    g1m="$(sed -n '2{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g1u="$(sed -n '2{s/.*,//;s/ //g;p}' <<<"${rows}")"
    available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap="$(awk '/SwapTotal:/ {t=$2} /SwapFree:/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)"
    echo "$(date +%s),${g0m},${g0u},${g1m},${g1u},${available},${swap}" >>"${output}"
    sleep 30
  done
}

start_evaluator() {
  local phase="$1" manifest="$2" gpu="$3"
  local cpus="${VAL_CPUS[$gpu]}" socket="/tmp/${UNIT}-${phase}-g${gpu}.sock"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}_eval.log"
  rm -f -- "${socket}"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${EVALUATOR}" \
      --source-command-json "${manifest}" --socket-path "${socket}" \
      --cpu-pool "${cpus}" \
      --run-dir "${SUITE_DIR}/shared_evaluator/${phase}_g${gpu}" \
      --eval-dataset-dir "${VALIDATION_DIR}" --max-eval-cases 60 \
      --cuda-memory-fraction 0.08 --eval-partition-seed 20260811 \
      --eval-partition-stratify-by distribution \
      >"${log}" 2>&1 &
  EVALUATOR_PIDS[$gpu]="$!"
  local deadline=$((SECONDS + 1200))
  while (( SECONDS < deadline )); do
    kill -0 "${EVALUATOR_PIDS[$gpu]}" >/dev/null 2>&1 || {
      echo "[Error] ${phase} GPU${gpu} evaluator exited" >&2
      return 1
    }
    if [[ -S "${socket}" ]] && "${PYTHON}" - "${socket}" <<'PY'
import sys
from onpolicy.utils.shared_eval import SharedEvalClient
reply=SharedEvalClient(sys.argv[1], timeout_seconds=5).ping()
raise SystemExit(0 if int(reply.get('worker_count', -1)) == 12 else 1)
PY
    then
      EVALUATOR_SOCKETS[$gpu]="${socket}"
      echo "[SharedEval] ${phase} GPU${gpu} ready"
      return 0
    fi
    sleep 2
  done
  echo "[Error] ${phase} GPU${gpu} evaluator readiness timeout" >&2
  return 1
}

launch_trial() {
  local phase="$1" manifest="$2" key="$3" gpu="$4" lane="$5" delay="$6"
  local index=$((gpu * 3 + lane)) cpus="${TRAIN_CPUS[$((gpu * 3 + lane))]}"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}l${lane}_${key}.log"
  local record="${SUITE_DIR}/records/${phase}_${key}.json"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "${manifest}" --command-key "${key}" \
      --gpu "${gpu}" --cpu-set "${cpus}" \
      --shared-eval-socket "${EVALUATOR_SOCKETS[$gpu]}" \
      --shared-eval-cpu-set "${VAL_CPUS[$gpu]}" --eval-workers 12 \
      --start-delay-seconds "${delay}" --record "${record}" \
      >"${log}" 2>&1 &
  LAST_LAUNCHED_PID="$!"
  TRAINER_PIDS+=("${LAST_LAUNCHED_PID}")
  echo "[Launch] ${phase} GPU${gpu} lane=${lane} ${key} CPUs=${cpus} pid=${LAST_LAUNCHED_PID}"
}

run_canary() {
  local keys=(
    C_A1_mc_potential_v2
    C_A3_event_redistribution
    C_A5_event_cf
  )
  local pids=() lane failed=0
  start_evaluator canary "${CANARY_MANIFEST}" 0
  monitor_phase canary & MONITOR_PID="$!"
  for lane in 0 1 2; do
    launch_trial canary "${CANARY_MANIFEST}" "${keys[$lane]}" 0 "${lane}" "$((lane * START_STAGGER_SECONDS))"
    pids+=("${LAST_LAUNCHED_PID}")
  done
  for lane in 0 1 2; do
    if ! wait "${pids[$lane]}"; then
      echo "[Error] canary ${keys[$lane]} failed" >&2
      failed=1
    fi
  done
  stop_children
  (( failed == 0 )) || return 1
  echo "[Canary] potential composition, event credit, and counterfactual path passed"
}

run_wave_a() {
  local failed=0 key
  declare -A pids=()
  start_evaluator wave_a "${WAVE_MANIFEST}" 0
  start_evaluator wave_a "${WAVE_MANIFEST}" 1
  monitor_phase wave_a & MONITOR_PID="$!"

  launch_trial wave_a "${WAVE_MANIFEST}" A0_mc_control 0 0 0
  pids[A0_mc_control]="${LAST_LAUNCHED_PID}"
  launch_trial wave_a "${WAVE_MANIFEST}" A2_role_td_lambda 0 1 "${START_STAGGER_SECONDS}"
  pids[A2_role_td_lambda]="${LAST_LAUNCHED_PID}"
  launch_trial wave_a "${WAVE_MANIFEST}" A4_counterfactual_critic 0 2 "$((2 * START_STAGGER_SECONDS))"
  pids[A4_counterfactual_critic]="${LAST_LAUNCHED_PID}"

  launch_trial wave_a "${WAVE_MANIFEST}" A1_mc_potential_v2 1 0 0
  pids[A1_mc_potential_v2]="${LAST_LAUNCHED_PID}"
  launch_trial wave_a "${WAVE_MANIFEST}" A3_event_redistribution 1 1 "${START_STAGGER_SECONDS}"
  pids[A3_event_redistribution]="${LAST_LAUNCHED_PID}"
  launch_trial wave_a "${WAVE_MANIFEST}" A5_event_cf 1 2 "$((2 * START_STAGGER_SECONDS))"
  pids[A5_event_cf]="${LAST_LAUNCHED_PID}"

  for key in "${!pids[@]}"; do
    if ! wait "${pids[$key]}"; then
      echo "[Error] Wave A ${key} failed" >&2
      failed=1
    fi
  done
  stop_children
  (( failed == 0 )) || return 1
  echo "[Wave A] all six causal arms completed"
}

controller() {
  trap controller_exit EXIT
  trap 'exit 130' INT TERM
  mkdir -p "${SUITE_DIR}"/{commands,service_logs,records,shared_evaluator,hardware,analysis}
  "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"running","started_unix_time":time.time(),"phase":"prepare"},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json"
  prepare_manifests
  run_canary
  "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"running","started_unix_time":float(sys.argv[2]),"phase":"wave_a"},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json" "$(date +%s)"
  run_wave_a
  "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"completed","completed_unix_time":time.time(),"phase":"wave_a"},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json"
  echo "[Pipeline] Stage2 role-credit Wave A completed"
}

initial_launch() {
  local required status load_state autopilot_load_state compute_pids
  for required in "${PYTHON}" "${PREPARER}" "${TRIAL_RUNNER}" \
    "${EVALUATOR}" "${AUTOPILOT}" "${DATASET}" "${VALIDATION_DIR}" \
    "${SOURCE_MANIFEST}" "${POTENTIAL}" /usr/bin/taskset /usr/bin/nvidia-smi; do
    [[ -e "${required}" ]] || { echo "[Error] missing input ${required}" >&2; exit 1; }
  done
  [[ "${RUN_TAG}" =~ ^[A-Za-z0-9._-]+$ && "${UNIT}" =~ ^[A-Za-z0-9._-]+$ ]] || {
    echo "[Error] RUN_TAG/UNIT is not path safe" >&2; exit 1;
  }
  verify_cpu_topology
  if [[ -f "${SUITE_DIR}/pipeline_status.json" ]]; then
    status="$("${PYTHON}" -c 'import json,sys; print(json.load(open(sys.argv[1])).get("status",""))' "${SUITE_DIR}/pipeline_status.json")"
    [[ "${status}" != running ]] || {
      echo "[Error] suite already reports a running controller" >&2; exit 1;
    }
  fi
  systemctl --user show-environment >/dev/null
  load_state="$(systemctl --user show "${UNIT}.service" --property=LoadState --value 2>/dev/null || true)"
  [[ -z "${load_state}" || "${load_state}" == not-found ]] || {
    echo "[Error] systemd unit already exists: ${UNIT}.service" >&2; exit 1;
  }
  autopilot_load_state="$(systemctl --user show "${AUTOPILOT_UNIT}.service" --property=LoadState --value 2>/dev/null || true)"
  [[ -z "${autopilot_load_state}" || "${autopilot_load_state}" == not-found ]] || {
    echo "[Error] systemd unit already exists: ${AUTOPILOT_UNIT}.service" >&2; exit 1;
  }
  [[ "$(nvidia-smi --query-gpu=index --format=csv,noheader,nounits | wc -l)" -ge 2 ]] || {
    echo "[Error] two CUDA GPUs are required" >&2; exit 1;
  }
  compute_pids="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | sed '/^[[:space:]]*$/d')"
  [[ -z "${compute_pids}" ]] || {
    echo "[Error] refusing launch while GPU compute processes exist: ${compute_pids//$'\n'/,}" >&2; exit 1;
  }
  mkdir -p "${SUITE_DIR}/service_logs" "/tmp/${UNIT}/matplotlib"
  systemd-run --user --unit="${UNIT}" --same-dir \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv="MPLCONFIGDIR=/tmp/${UNIT}/matplotlib" \
    --setenv="RUN_TAG=${RUN_TAG}" --setenv="SUITE_DIR=${SUITE_DIR}" \
    --setenv="UNIT=${UNIT}" \
    --property=Type=exec --property=Restart=no \
    --property=KillMode=control-group --property=TimeoutStopSec=300 \
    --property=LimitNOFILE=65536 \
    --property=AllowedCPUs=0-143 --property=CPUAffinity=0-143 \
    --property="StandardOutput=append:${SUITE_DIR}/service_logs/controller.log" \
    --property="StandardError=append:${SUITE_DIR}/service_logs/controller.log" \
    /bin/bash "${BASH_SOURCE[0]}" --controller >/dev/null
  systemd-run --user --unit="${AUTOPILOT_UNIT}" --same-dir \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv="MPLCONFIGDIR=/tmp/${UNIT}/matplotlib" \
    --property=Type=exec --property=Restart=no \
    --property=KillMode=control-group --property=TimeoutStopSec=300 \
    --property=LimitNOFILE=65536 \
    --property=AllowedCPUs=0-143 --property=CPUAffinity=0-143 \
    --property="StandardOutput=append:${SUITE_DIR}/service_logs/autopilot.log" \
    --property="StandardError=append:${SUITE_DIR}/service_logs/autopilot.log" \
    "${PYTHON}" -u "${AUTOPILOT}" \
      --suite-dir "${SUITE_DIR}" --wave-unit "${UNIT}" \
      --autopilot-unit "${AUTOPILOT_UNIT}" --run-tag "${RUN_TAG}" \
      --python "${PYTHON}" >/dev/null
  echo "[Started] ${UNIT}.service"
  echo "[Started] ${AUTOPILOT_UNIT}.service (Wave A -> Wave B -> Formal -> finalblind)"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] phase=three-lane production canary, then six-arm Wave A"
}

if [[ "${1:-}" == --controller ]]; then
  [[ $# -eq 1 ]] || { echo "Usage: $0 --controller" >&2; exit 2; }
  controller
elif [[ $# -eq 0 ]]; then
  initial_launch
else
  echo "Usage: $0" >&2
  exit 2
fi
