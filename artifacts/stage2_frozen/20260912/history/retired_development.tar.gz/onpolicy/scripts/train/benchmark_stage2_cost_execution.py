#!/usr/bin/env python3
"""Matched serial/fanout GPU replay; prefix smoke can never approve cost training."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from onpolicy.config.config import get_config
from onpolicy.scripts.train.diagnose_stage2_cost_improvement import make_runner
from onpolicy.scripts.train.run_stage2_bc_injection_suite import verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism
from onpolicy.utils.stage2_cost_accelerated import AcceleratedCostIteration, load_config
from onpolicy.utils.stage2_cost_execution import (
    ExactCostCache, array_digest, coalesce_queries, json_digest, run_fanout, semantic_outcome,
)
from onpolicy.utils.stage2_cost_improvement import actor_forward, joint_candidates, policy_digest
from onpolicy.utils.stage2_cost_timeout import LEGACY_TIMEOUT_CONTRACT


def trace_update(digest, actions, hidden, rows):
    digest.update(array_digest(actions).encode())
    digest.update(array_digest(hidden).encode())
    for row in rows:
        digest.update(array_digest(row[2]).encode())
        digest.update(json_digest(row[4]).encode())


def serial_reference(iterator, queries):
    """Original one-target/full-batch algorithm, with a trace observer only."""
    runner, envs = iterator.runner, iterator.runner.envs
    outcomes, traces = [], []
    started = time.monotonic()
    for number, (first, target) in enumerate(queries):
        begin = time.monotonic()
        envs.call('stage2_cost_branch_restore')
        actions, hidden = first.copy(), iterator.next_rnn.copy()
        completed, makespan, reason, steps = False, None, 'step_limit', 0
        trace = hashlib.sha256()
        for steps in range(1, runner.episode_length + 1):
            if time.monotonic() - begin > iterator.args.stage2_cost_branch_timeout_seconds:
                reason = 'wall_timeout'
                break
            rows = envs.call_each('stage2_cost_branch_step', [(action,) for action in actions])
            graphs, _, done_rows, info_rows, statuses = zip(*rows)
            dones = np.stack(done_rows).astype(bool)
            hidden[dones] = 0.
            trace_update(trace, actions, hidden, rows)
            if np.all(dones[target]):
                completed = statuses[target]['completed']
                makespan = statuses[target]['makespan'] if completed else None
                reason = 'completed' if completed else 'incomplete_terminal'
                break
            infos = envs.stack_infos(info_rows)
            active = runner._active_masks_from_info(infos)
            history = runner._authoritative_policy_history(infos, actions, runner.policy.ac.max_plane_agents)
            actions, hidden = actor_forward(iterator.policy, graphs, hidden, active, history, infos.get('agent_types'))
            if steps % 100 == 0:
                print(f'[SerialProof] query={number + 1}/{len(queries)} step={steps} '
                      f'elapsed={time.monotonic()-begin:.1f}s', flush=True)
        outcomes.append(dict(completed=bool(completed), makespan=makespan, steps=steps,
                             reason=reason, wall_seconds=time.monotonic()-begin))
        traces.append(trace.hexdigest())
    return outcomes, traces, time.monotonic() - started


def fixture(manifest, manifest_path, output, batch_width, prefix_steps):
    directory = output / f'batch{batch_width}'
    directory.mkdir(exist_ok=False)
    args = parse_args(manifest['commands']['N2_cost_teacher_seed11']['argv'][2:], get_config())
    args.n_rollout_threads = args.max_train_cases = args.train_sampling_size = batch_width
    args.stage2_research_train_cases = str(manifest_path.parent / (
        'regression_cases.json' if batch_width == 2 else 'diagnostic_cases.json'))
    torch.manual_seed(11)
    torch.cuda.manual_seed_all(11)
    runner = make_runner(args, manifest, directory)
    before = policy_digest(runner.policy)
    iterator = AcceleratedCostIteration(runner, 1)
    try:
        obs, dones, infos = runner.envs.reset()
        hidden = np.zeros((batch_width, runner.num_agents, args.recurrent_N, args.hidden_size), np.float32)
        previous = -np.ones((batch_width, runner.num_agents, 2), np.int64)
        iterator.reset_rollout(hidden)
        queries, selected = [], []
        for step in range(128):
            active = runner._active_masks_from_info(infos)
            history = runner._authoritative_policy_history(infos, previous, args.max_agent_num)
            hidden = iterator.prepare(obs, active, history, infos, hidden)
            actions, next_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            if iterator.selected:
                labels = runner.envs.call('resource_iga_teacher_actions', return_info=True,
                    include_ready_targets=False, deployment_projection=True)
                teacher = np.stack([row['actions'] for row in labels])
                # Fixed first two eligible environments; never selected by cost.
                for env in iterator.selected[:2]:
                    resources = np.flatnonzero((active[env, :, 0] > 0)
                        & (np.arange(active.shape[1]) >= runner.policy.ac.max_plane_agents))
                    legal = obs[env].request_mask_matrix.detach().cpu().numpy().astype(bool)[resources]
                    lookahead = obs[env].request_is_lookahead.detach().cpu().numpy().astype(bool).reshape(-1)
                    candidates = joint_candidates(legal, actions[env, resources, 0], teacher[env, resources, 0], lookahead)
                    if len(candidates) < 2:
                        continue
                    selected.append(dict(env=env, case=str(np.asarray(infos['case_id']).reshape(-1)[env]),
                                         origins=[row['origin'] for row in candidates]))
                    for candidate in candidates:
                        first = iterator.frozen_actions.copy()
                        first[env] = actions[env]
                        first[env, resources, 0], first[env, resources, 1] = candidate['action'], 0
                        queries.append((first, env))
                if queries:
                    break
            prior, types = obs, infos['agent_types']
            obs, _, dones, infos = runner.envs.step(actions)
            iterator.finish_step(prior, active, history, types, dones)
            next_hidden[dones] = 0.
            hidden, previous = next_hidden, actions
        else:
            raise ValueError('No fixed nontrivial verification fixture within 128 events.')
        snapshots = runner.envs.call_each('stage2_cost_branch_capture',
            [(str(directory / f'env{env:02}.pkl.gz'),) for env in range(batch_width)])
        if prefix_steps:
            runner.episode_length = prefix_steps
        context = dict(policy_sha256=iterator.model_sha256,
            batch_snapshot_sha256=[row['sha256'] for row in snapshots],
            post_forward_recurrent_sha256=array_digest(iterator.next_rnn),
            history_sha256=array_digest(history), batch_width=batch_width,
            max_steps=runner.episode_length, arithmetic=iterator.arithmetic)
        with (directory / 'fixture.pt').open('xb') as handle:
            torch.save(dict(queries=queries, context=context, post_forward_rnn=iterator.next_rnn,
                            history=history, selected=selected, event_step=step), handle)
        print(f'[AccelerationProof] batch={batch_width} queries={len(queries)} event={step} serial', flush=True)
        original, reference_traces, serial_seconds = serial_reference(iterator, queries)
        jobs = coalesce_queries(queries)
        previous_result = None
        if manifest['cost_executor'].get('inference_mode', 'legacy') != 'legacy':
            from onpolicy.utils.stage2_cost_actor_pool import PrivateActorPool
            previous_pool = PrivateActorPool(iterator.policy, 2)
            selected_pool = iterator.actor_pool
            previous_hashes = [hashlib.sha256() for _ in jobs]
            previous_traces = [None] * len(queries)

            def observe_previous(job, event, first, rnn, rows):
                trace_update(previous_hashes[job], first, rnn, rows)
                for query, target in jobs[job]['consumers']:
                    if event == original[query]['steps']:
                        previous_traces[query] = previous_hashes[job].hexdigest()

            previous_context = dict(context, arithmetic=dict(iterator.arithmetic,
                actor_lanes=2, fanout_width=8, inference_mode='legacy', timeout_contract=LEGACY_TIMEOUT_CONTRACT))
            previous_namespace = json_digest(dict(source=manifest['cost_executor']['source_namespace'],
                                                  runtime=previous_context['arithmetic']))
            try:
                iterator.actor_pool = previous_pool
                print(f'[AccelerationProof] batch={batch_width} previous_fanout_8_lanes_2', flush=True)
                previous_outcomes, previous_timings = run_fanout(iterator, queries, width=8,
                    context=previous_context,
                    cache=ExactCostCache(directory / 'previous_cold_cache', previous_namespace),
                    observer=observe_previous)
                previous_result = dict(fanout_width=8, actor_lanes=2, inference_mode='legacy',
                    execution=previous_timings, traces=previous_traces,
                    trace_exact=previous_traces == reference_traces,
                    outcomes_exact=[semantic_outcome(x) for x in previous_outcomes]
                                   == [semantic_outcome(x) for x in original])
            finally:
                iterator.actor_pool = selected_pool
                previous_pool.close()
        hashes = [hashlib.sha256() for _ in jobs]
        accelerated_traces = [None] * len(queries)

        def observe(job, event, first, rnn, rows):
            trace_update(hashes[job], first, rnn, rows)
            for query, target in jobs[job]['consumers']:
                if event == original[query]['steps']:
                    accelerated_traces[query] = hashes[job].hexdigest()

        cache = ExactCostCache(directory / 'cold_cache', iterator.cache.namespace)
        print(f'[AccelerationProof] batch={batch_width} fanout_cold', flush=True)
        accelerated, timings = run_fanout(iterator, queries, width=manifest['cost_executor']['fanout_width'],
                                         context=context, cache=cache, observer=observe)
        reused, cached_timings = run_fanout(iterator, queries, width=manifest['cost_executor']['fanout_width'],
                                          context=context, cache=cache)
        completed = all(row['completed'] for row in original + accelerated)
        result = dict(batch_width=batch_width, selected=selected, query_count=len(queries),
            prefix_steps=prefix_steps, completed=completed,
            trace_exact=reference_traces == accelerated_traces,
            outcomes_exact=[semantic_outcome(row) for row in original] == [semantic_outcome(row) for row in accelerated],
            cache_exact=completed and cached_timings['cache_hits'] == len(queries)
                        and [semantic_outcome(row) for row in reused] == [semantic_outcome(row) for row in accelerated],
            serial_seconds=serial_seconds, fanout_seconds=timings['wall_seconds'],
            speedup=serial_seconds / max(1e-9, timings['wall_seconds']),
            execution=timings, cache_execution=cached_timings,
            serial_outcomes=original, fanout_outcomes=accelerated,
            serial_traces=reference_traces, fanout_traces=accelerated_traces,
            source_weights_unchanged=policy_digest(runner.policy) == before)
        if previous_result is not None:
            result.update(previous_executor=previous_result,
                previous_executor_speedup=previous_result['execution']['wall_seconds']
                                           / max(1e-9, timings['wall_seconds']))
        atomic_json(directory / 'report.json', result)
        if not result['source_weights_unchanged']:
            raise ValueError('Verification changed source weights.')
        return result
    finally:
        iterator.close()
        try:
            runner.envs.call('stage2_cost_branch_clear')
        finally:
            runner.envs.close()


def benchmark(cli):
    path = cli.manifest.resolve()
    manifest = json.loads(path.read_text())
    if cli.smoke_share_pid and not cli.smoke_prefix_steps:
        raise ValueError('A shared-GPU prefix smoke cannot certify production acceleration.')
    verify_resources(manifest, check_gpu=not cli.smoke_share_pid)
    if cli.smoke_share_pid:
        busy = subprocess.check_output(['nvidia-smi', '--id=0', '--query-compute-apps=pid',
            '--format=csv,noheader,nounits'], text=True).strip().splitlines()
        if {int(pid) for pid in busy if pid.strip()} != {cli.smoke_share_pid}:
            raise ValueError('Unexpected GPU0 owner; do not share with unrelated jobs.')
        os.sched_setaffinity(0, {30, 31, 94, 95})
    output = path.parent / ('acceleration_smoke' if cli.smoke_prefix_steps else 'acceleration')
    output.mkdir(exist_ok=False)
    config = manifest['cost_executor']
    load_config(config['path'], config['sha256'])
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.20 if cli.smoke_share_pid else .70, device=0)
    report = dict(manifest=str(path), status='running', fanout_width=config['fanout_width'],
                  actor_lanes=config['actor_lanes'], fixtures=[],
                  inference_mode=config.get('inference_mode', 'legacy'),
                  timeout_contract=config.get('timeout_contract', LEGACY_TIMEOUT_CONTRACT),
                  reference_actor='unchanged_legacy_forward_and_matching',
                  acceleration_gate_passed=False, started_unix_time=time.time(), scientific_result=False)
    atomic_json(output / 'report.json', report)
    try:
        for width in (2, 24):
            report['fixtures'].append(fixture(manifest, path, output, width, cli.smoke_prefix_steps))
            atomic_json(output / 'report.json', report)
        # Recheck source at the end. Concurrent edits invalidate the proof.
        load_config(config['path'], config['sha256'])
        report['prefix_equivalence_passed'] = all(row['trace_exact'] and row['outcomes_exact'] for row in report['fixtures'])
        report['acceleration_gate_passed'] = not cli.smoke_prefix_steps and all(
            row['completed'] and row['trace_exact'] and row['outcomes_exact'] and row['cache_exact']
            and row['speedup'] > 1.
            and (config.get('inference_mode', 'legacy') == 'legacy' or
                 (row['previous_executor']['trace_exact'] and row['previous_executor']['outcomes_exact']
                  and row['previous_executor_speedup'] > 1.)) for row in report['fixtures'])
        report.update(status='completed', ended_unix_time=time.time(),
            note='Timing is an observed matched-host benchmark, not a guaranteed pilot speedup. '
                 'Prefix smoke never authorizes cost training.')
        atomic_json(output / 'report.json', report)
        return 0 if report['acceleration_gate_passed'] or (
            cli.smoke_prefix_steps and report['prefix_equivalence_passed']) else 2
    except BaseException as error:
        report.update(status='failed', error=str(error), ended_unix_time=time.time())
        atomic_json(output / 'report.json', report)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--smoke-prefix-steps', type=int, default=0)
    parser.add_argument('--smoke-share-pid', type=int)
    args = parser.parse_args()
    if args.smoke_prefix_steps < 0 or args.smoke_prefix_steps > 64:
        parser.error('Smoke prefix must be in [1, 64], or zero for the complete proof.')
    raise SystemExit(benchmark(args))
