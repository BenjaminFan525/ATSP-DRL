#!/usr/bin/env python3
"""Create an immutable, manually authorized train240/tune60 V6 manifest."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_v6_full import (
    CONTRACT, PROTOCOL, RESOURCE, USER_REQUEST, execution_contract,
    pilot_observation, validate_plan, validate_teacher_parts,
)


def binding(path):
    path = Path(path).resolve()
    return dict(path=str(path), sha256=file_sha(path))


def prepare(destination, pilot_path, regression_path, authorized):
    if not authorized:
        raise ValueError('Explicit full train240 launch authorization is required.')
    destination, pilot_path = destination.resolve(), pilot_path.resolve()
    if destination.exists():
        raise FileExistsError('Use a new directory; never overwrite or retry a full experiment.')
    pilot_root = pilot_path.parent
    pilot = json.loads(pilot_path.read_text())
    status = json.loads((pilot_root / 'run_status.json').read_text())
    report = json.loads((pilot_root / 'pilot_report.json').read_text())
    if (status['status'] != 'completed' or status['actor_steps'] != {'S1': 80, 'S2': 80}
            or status['completed_physical_case_episodes'] != 172):
        raise ValueError('The preserved pilot must have actually completed.')
    for name, digest in pilot['code_fingerprint'].items():
        if file_sha(ROOT / name) != digest:
            raise ValueError(f'Pilot implementation changed; cache reuse is unsafe: {name}')
    proof = json.loads(regression_path.read_text())
    if not proof['passed'] or not proof.get('checked_sources'):
        raise ValueError('Passed version-pinned full-data regression tests are required.')
    for name, digest in proof['checked_sources'].items():
        if file_sha(ROOT / name) != digest:
            raise ValueError(f'Regression proof predates current code: {name}')
    engineering = json.loads(Path(pilot['engineering_proof']['path']).read_text())
    if not engineering['passed'] or not engineering['scientific_updates_discarded']:
        raise ValueError('The unchanged V6 learner needs its passed GPU engineering proof.')
    for name, digest in engineering['checked_sources'].items():
        if file_sha(ROOT / name) != digest:
            raise ValueError(f'GPU proof does not cover current learner: {name}')
    inherited = ('source', 'stage1_source', 'ready_source', 'teacher_index',
        'teacher_index_sha256', 'teacher_files', 'environment_argv', 'train', 'evaluation',
        'iga_reference', 'archived_teachers', 'diagnostic_cases', 'engineering_proof')
    manifest = {k: copy.deepcopy(pilot[k]) for k in inherited}
    for field in ('source', 'stage1_source', 'ready_source', 'engineering_proof', 'iga_reference'):
        entry = manifest[field]
        if file_sha(entry['path']) != entry['sha256']:
            raise ValueError(f'Pinned input changed: {field}')
    if file_sha(manifest['teacher_index']) != manifest['teacher_index_sha256']:
        raise ValueError('Pinned teacher index changed.')
    for role in ('train', 'evaluation'):
        validate_case_content(manifest[role]['cases'], manifest[role]['dataset'])
    for name, digest in manifest['teacher_files']['hashes'].items():
        if file_sha(Path(manifest['teacher_files']['directory']) / (name + '.json')) != digest:
            raise ValueError(f'Teacher changed for {name}.')
    teacher_path = pilot_root / 'teacher_data/manifest.json'
    teacher = json.loads(teacher_path.read_text())
    if (teacher['physical_case_episodes'] != 48 or not teacher['includes_complete_prefix']
            or teacher['source'] != 'pinned_IGA1800_live_AR_projected_teacher'):
        raise ValueError('Only complete pinned teacher48 trajectories may be reused.')
    validate_teacher_parts(teacher['parts'], manifest['train']['cases'][:48])
    for index, part in enumerate(teacher['parts'], 1):
        print(f'Verifying read-only teacher cache {index}/8', flush=True)
        for path_key, hash_key in (('path', 'sha256'), ('stateless_path', 'stateless_sha256')):
            if file_sha(part[path_key]) != part[hash_key]:
                raise ValueError('A reused teacher artifact changed.')
    manifest.update(protocol=PROTOCOL, schema_version=1, run_tag=destination.name,
        created_at=datetime.now(timezone.utc).isoformat(),
        material_passport=dict(origin_skill='academic-research-suite/experiment-agent',
            origin_mode='run', origin_date='2026-09-11', verification_status='UNVERIFIED',
            version_label='stage2_v6_train240_v1'),
        authorization=dict(user_request=USER_REQUEST, date='2026-09-11',
            mode='explicit_manual_exploratory_extension', automatic_promotion=False,
            pilot_failure_disclosed=True, initial_weights='same_B0_not_pilot_checkpoint'),
        pilot_manifest=binding(pilot_path), pilot_status=binding(pilot_root / 'run_status.json'),
        pilot_report=binding(pilot_root / 'pilot_report.json'),
        pilot_teacher_manifest=binding(teacher_path),
        pilot_b0_evaluation=binding(pilot_root / 'evaluations/B0_AR_dev12.json'),
        pilot_source_archive=copy.deepcopy(pilot['source_archive']),
        regression_proof=binding(regression_path), pilot_observation=pilot_observation(report),
        teacher_reuse=dict(parts=copy.deepcopy(teacher['parts']), case_episodes=48,
            read_only=True, counted_as_new_environment_episodes=False),
        training_contract=copy.deepcopy(CONTRACT), resource_contract=copy.deepcopy(RESOURCE),
        execution=execution_contract(),
        data_roles=dict(train_cases=240, development_cases=60, historical_case_order_preserved=True,
            development_only=True, gate120_accessed=False, finalblind60_accessed=False,
            selection_uses_outcomes=False),
        screen=pilot['screen'] | {'minimum_gradient_steps': 400,
            'scientific_goal_certified_by_full_run': False},
        goal=pilot['goal'], confirmed_scientific_success=False)
    validate_plan(manifest, pilot, report)
    fingerprints = code_fingerprint()
    for name in ('STAGE2_RESOURCE_V6_TRAIN240_20260911.md',
                 'onpolicy/scripts/train/launch_stage2_resource_v6_full_gpu0.sh'):
        fingerprints[name] = file_sha(ROOT / name)
    manifest['code_fingerprint'] = fingerprints
    destination.mkdir(parents=True, exist_ok=False)
    archive = destination / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as stream:
        for name, digest in fingerprints.items():
            content = (ROOT / name).read_bytes()
            if hashlib.sha256(content).hexdigest() != digest:
                raise ValueError('Source changed during immutable snapshot.')
            stream.addfile(stream.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(content))
    manifest['source_archive'] = binding(archive)
    atomic_json(destination / 'manifest.json', manifest)
    print(destination / 'manifest.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--pilot-manifest', type=Path, required=True)
    parser.add_argument('--regression-proof', type=Path, required=True)
    parser.add_argument('--authorize-full-train240', action='store_true', required=True)
    args = parser.parse_args()
    prepare(args.suite_dir, args.pilot_manifest, args.regression_proof, args.authorize_full_train240)
