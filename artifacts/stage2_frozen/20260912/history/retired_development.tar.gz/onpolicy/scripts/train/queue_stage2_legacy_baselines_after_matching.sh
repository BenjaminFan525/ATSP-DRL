#!/usr/bin/env bash
set -euo pipefail

# Queue the matched-budget legacy baselines behind the currently running
# five-arm matching wave.  The queue itself is CPU/GPU-negligible and never
# overlaps two training suites on GPU0.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
LAUNCHER="${ROOT_DIR}/onpolicy/scripts/train/launch_stage2_legacy_baselines_gpu0.sh"
WAIT_PREFIX="${WAIT_PREFIX:-hkbz-s2-match-20260902-r1}"
QUEUE_UNIT="${QUEUE_UNIT:-hkbz-s2-legacy-queue-20260903-r1}"
QUEUE_CPUS="${QUEUE_CPUS:-70-71,142-143}"
POLL_SECONDS="${POLL_SECONDS:-30}"
QUEUE_LOG="${QUEUE_LOG:-${ROOT_DIR}/result/hkbz_train_logs/stage2_legacy_baselines_20260903_r1.queue.log}"

matching_units_active() {
  local lane state
  for lane in 0 1 2 3 4; do
    state="$(systemctl --user is-active "${WAIT_PREFIX}-g0l${lane}.service" 2>/dev/null || true)"
    if [[ "${state}" == active || "${state}" == activating || "${state}" == deactivating ]]; then
      return 0
    fi
  done
  return 1
}

support_units_active() {
  local suffix state
  for suffix in g0eval monitor; do
    state="$(systemctl --user is-active "${WAIT_PREFIX}-${suffix}.service" 2>/dev/null || true)"
    if [[ "${state}" == active || "${state}" == activating || "${state}" == deactivating ]]; then
      return 0
    fi
  done
  return 1
}

gpu0_busy() {
  local pids
  pids="$(nvidia-smi --id=0 --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null || true)"
  [[ -n "${pids//[[:space:]]/}" ]]
}

queue_worker() {
  local started last_report elapsed
  started="$(date +%s)"
  last_report=0
  echo "[Queue] waiting for ${WAIT_PREFIX} at $(date --iso-8601=seconds)"
  while matching_units_active; do
    elapsed=$(($(date +%s) - started))
    if (( elapsed - last_report >= 300 )); then
      echo "[Queue] matching trainers still active; waited=${elapsed}s"
      last_report="${elapsed}"
    fi
    sleep "${POLL_SECONDS}"
  done

  echo "[Queue] trainers stopped; waiting for shared evaluator/monitor shutdown"
  while support_units_active; do
    sleep 5
  done
  echo "[Queue] matching suite released its services; waiting for GPU0 to be idle"
  while gpu0_busy; do
    sleep "${POLL_SECONDS}"
  done

  echo "[Queue] launching legacy baselines at $(date --iso-8601=seconds)"
  exec /bin/bash "${LAUNCHER}"
}

schedule_queue() {
  local load_state
  [[ -x "${LAUNCHER}" ]] || {
    echo "[Error] launcher is missing or not executable: ${LAUNCHER}" >&2
    exit 1
  }
  mkdir -p "$(dirname -- "${QUEUE_LOG}")"
  load_state="$(systemctl --user show "${QUEUE_UNIT}.service" -p LoadState --value 2>/dev/null || true)"
  [[ -z "${load_state}" || "${load_state}" == not-found ]] || {
    echo "[Error] queue unit already exists: ${QUEUE_UNIT}.service" >&2
    exit 1
  }
  systemd-run --user --unit="${QUEUE_UNIT}" --same-dir \
    --setenv=HKBZ_STAGE2_LEGACY_QUEUE_WORKER=1 \
    --setenv="WAIT_PREFIX=${WAIT_PREFIX}" \
    --setenv="QUEUE_UNIT=${QUEUE_UNIT}" \
    --setenv="QUEUE_CPUS=${QUEUE_CPUS}" \
    --setenv="POLL_SECONDS=${POLL_SECONDS}" \
    --setenv="QUEUE_LOG=${QUEUE_LOG}" \
    --property=Type=exec --property=Restart=no --property=KillMode=control-group \
    --property="AllowedCPUs=${QUEUE_CPUS}" \
    --property="CPUAffinity=${QUEUE_CPUS}" \
    --property="StandardOutput=append:${QUEUE_LOG}" \
    --property="StandardError=append:${QUEUE_LOG}" \
    /bin/bash "${BASH_SOURCE[0]}" >/dev/null
  echo "[Queued] ${QUEUE_UNIT}.service"
  echo "[Queued] waits for ${WAIT_PREFIX}, then launches ${LAUNCHER}"
  echo "[Queued] log=${QUEUE_LOG}"
}

if [[ "${HKBZ_STAGE2_LEGACY_QUEUE_WORKER:-0}" == 1 ]]; then
  queue_worker
else
  schedule_queue
fi
