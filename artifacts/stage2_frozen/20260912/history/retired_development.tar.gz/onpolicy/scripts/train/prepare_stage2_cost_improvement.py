#!/usr/bin/env python3
"""Pin Phase-A diagnostics -> four-arm canary -> conditional N0-N3 pilot."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shlex
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.config.config import get_config
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.prepare_stage2_policy_transfer import digest
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import set_option, set_switch
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args as training_args
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_cost_improvement import COST_CONTRACT, LOSS_CONTRACT

PARENT = ROOT / 'result/hkbz_train_logs/stage2_matching_gap_20260906_gpu0_half_pilot_r2'
ARMS = {'N0_BC_teacher': (False, [1., 1.]), 'N1_BC_dagger': (False, [.75, .5]),
        'N2_cost_teacher': (True, [1., 1.]), 'N3_cost_dagger': (True, [.75, .5])}
DOC = 'STAGE2_COST_IMPROVEMENT_IMPLEMENTATION_20260907.md'
LAUNCHER = 'onpolicy/scripts/train/launch_stage2_cost_improvement_gpu0.sh'


def locked_rows(dataset, names):
    rows = []
    for name in names:
        metadata = json.loads((dataset / name / 'metadata.json').read_text())
        if metadata['split'] != 'train':
            raise ValueError('Diagnostic/canary input is not train-only.')
        rows.append({'case_dir': name, 'case_sha256': metadata['fingerprints']['case_sha256'],
            'fingerprints': metadata['fingerprints'], 'distribution': metadata['distribution'],
            'profile': metadata['profile']})
    validate_case_content(rows, dataset)
    return {'split': 'train', 'dataset': str(dataset), 'outcome_selected': False, 'cases': rows}


def proof(path, field, fingerprints, family='stage2_cost_improvement'):
    path = Path(path).resolve()
    report = json.loads(path.read_text())
    source = Path(report['manifest'])
    manifest = json.loads(source.read_text())
    if (report.get(field) is not True or manifest['code_fingerprint'] != fingerprints
            or manifest['research_family'] != family):
        raise ValueError(f'Unpassed or source-mismatched proof: {path}')
    if field == 'canary_contract_passed' and report.get('cost_integrity_passed') is not True:
        raise ValueError('Canary proof lacks the completed cost-integrity audit.')
    return {'path': str(path), 'sha256': digest(path), 'manifest': str(source),
            'manifest_sha256': digest(source)}


def prepare(cli):
    suite = cli.suite_dir.resolve()
    if suite.exists():
        raise FileExistsError(f'Never overwrite a suite: {suite}')
    old = json.loads((PARENT / 'manifest.json').read_text())
    fingerprints = code_fingerprint()
    for path in (DOC, LAUNCHER):
        fingerprints[path] = digest(ROOT / path)
    diagnostic_proof = canary_proof = None
    if cli.profile != 'diagnostic':
        if not cli.diagnostic_proof:
            raise ValueError('Training requires completed Phase-A proof.')
        diagnostic_proof = proof(cli.diagnostic_proof, 'diagnostic_gate_passed', fingerprints)
    if cli.profile == 'pilot':
        if not cli.canary_proof:
            raise ValueError('Pilot requires a four-arm canary.')
        canary_proof = proof(cli.canary_proof, 'canary_contract_passed', fingerprints)
    manifest = copy.deepcopy(old)
    canary = cli.profile == 'canary'
    diagnostic = cli.profile == 'diagnostic'
    workers, cases, eval_workers, eval_cases, rollouts = (2, 2, 2, 4, 1) if canary else (24, 240, 12, 60, 10)
    dataset = Path(json.loads(Path(old['teacher_index']).read_text())['dataset_dir']).resolve()
    order = old['sampling_audits']['11']['case_order']
    # Fixed before any new outcomes: select in the already locked pilot order.
    quotas = {'iid': 12, 'ood_stress': 10, 'ood_scale': 2}
    selected = []
    for name in order:
        metadata = json.loads((dataset / name / 'metadata.json').read_text())
        distribution = metadata['distribution']
        if quotas[distribution] > 0 and name not in ('case_0343', 'case_0444'):
            selected.append(name)
            quotas[distribution] -= 1
    if any(quotas.values()):
        raise ValueError('Fixed pilot pool cannot supply the preregistered diagnostic strata.')
    diagnostic_cases = locked_rows(dataset, selected)
    regression_cases = locked_rows(dataset, ['case_0343', 'case_0444'])
    commands = {}
    for arm, (cost, schedule) in ARMS.items():
        command = list(old['commands']['M1_full_edge_seed11']['argv'])
        command[:2] = [str(cli.python.resolve()), str(ROOT / 'onpolicy/scripts/train/train_hkbz.py')]
        name = f'{cli.run_tag}_{arm}_seed11'
        if (ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / name).exists():
            raise FileExistsError(name)
        source = old['warmstart_sources']['B0_none']
        options = {'--experiment_name': name, '--device_bc_pretrain_epochs': 2,
            '--n_rollout_threads': workers, '--max_train_cases': cases, '--train_sampling_size': cases,
            '--device_bc_min_rollouts_per_epoch': rollouts, '--device_bc_max_rollouts_per_epoch': rollouts,
            '--n_eval_rollout_threads': eval_workers, '--max_eval_cases': eval_cases,
            '--device_bc_dagger_schedule': ','.join(map(str, schedule)),
            '--device_bc_full_edge_loss_coef': 1., '--device_bc_empty_wait_loss_coef': 0.,
            '--device_bc_min_wait_groups_per_epoch': 0, '--cuda_memory_fraction': .35,
            '--stage2_policy_warmstart_evaluation': '' if canary else source['evaluation'],
            '--stage2_policy_warmstart_evaluation_sha256': '' if canary else source['evaluation_sha256'],
            '--stage2_research_train_cases': str(suite / 'regression_cases.json') if canary else '',
            '--stage2_cost_scale_seconds': 120., '--stage2_cost_weight_clip': 4.,
            '--stage2_cost_tie_seconds': 1., '--stage2_cost_loss_coef': 1.,
            '--stage2_cost_snapshot_horizon': 256, '--stage2_cost_branch_timeout_seconds': 600.,
            '--mini_batch_size': min(7, workers)}
        for key, value in options.items():
            set_option(command, key, value)
        set_switch(command, '--stage2_policy_improvement_protocol', True)
        set_switch(command, '--stage2_cost_improvement', cost)
        parser = get_config()
        parsed = training_args(command[2:], parser)
        _, unknown = parser.parse_known_args(command[2:])
        if unknown or not parsed.stage2_bc_deterministic or not parsed.device_bc_plane_deterministic:
            raise ValueError(f'Unknown/nondeterministic command: {unknown}')
        commands[arm + '_seed11'] = dict(argv=command, shell=shlex.join(command), arm=arm,
            seed=11, experiment_name=name, injection='none', warmstart_arm='B0_none', warmstart_source=source,
            teacher_execution_schedule=schedule, full_edge_coef=1., empty_wait_coef=0., cost_improvement=cost)
    manifest.update(schema_version=1, research_family='stage2_cost_improvement', run_tag=cli.run_tag,
        profile=cli.profile, scientific_result=cli.profile == 'pilot',
        created_at=datetime.now(timezone.utc).isoformat(), commands=commands,
        parent_manifest=str(PARENT / 'manifest.json'), parent_manifest_sha256=digest(PARENT / 'manifest.json'),
        code_fingerprint=fingerprints, diagnostic_proof=diagnostic_proof, canary_proof=canary_proof,
        analysis_script='onpolicy/scripts/train/analyze_stage2_cost_improvement.py')
    manifest['resource_contract'].update(allowed_cpus='0-31,64-95',
        train_cpu_sets=['0-11,64-75', '12-23,76-87'], max_concurrent_trainers=2,
        eval_cpu_set='24-29,88-93', monitor_cpu_set='30-31,94-95', hard_timeout_seconds=172800)
    manifest['training_contract'].update(epochs=2, workers=workers, rollouts_per_epoch=rollouts,
        scope='policy_frozen_ready', ppo_epochs=0)
    manifest['evaluation_contract'].update(workers=eval_workers, cases=eval_cases,
        per_job_zero_tolerance_replay=not canary, gate_access=False, finalblind_access=False)
    manifest['matching_contract'].update(teacher_execution='per_arm_environment_level',
        cost_contract=COST_CONTRACT, cost_loss_contract=LOSS_CONTRACT)
    manifest['analysis_contract'].update(contrasts=[['N1_BC_dagger', 'N0_BC_teacher'],
        ['N2_cost_teacher', 'N0_BC_teacher'], ['N3_cost_dagger', 'N1_BC_dagger'],
        ['N3_cost_dagger', 'N2_cost_teacher']], automatic_promotion=False)
    manifest['cost_contract'] = dict(continuation=COST_CONTRACT, loss=LOSS_CONTRACT,
        max_states_per_case_iteration=2, max_candidates_per_state=4,
        full_state_evidence_budget_bytes_per_iteration=16 * 1024**3,
        candidate_continuation_budget=64 if canary else 7680,
        scale_seconds=120., clip=4., tie_seconds=1., normalization_source='a_priori_train_only_no_tune_fit',
        sample_resource_decision_ordinals=[4, 16], snapshot_event_horizon=256,
        incomplete='whole_group_abstention', conflicts='suppress_all_legacy_joint_losses_including_ties',
        rnn='exact_current_prefix_at_selected_states; legacy_truncated_BPTT_for_uncovered_BC',
        arithmetic='unchanged_full_heterogeneous_rollout_batch_cuda0; one_env_intervention',
        frozen_target='each_epoch; both_GRUs; current_state_history; no_teacher_resource_continuation',
        not_exhaustive=True, not_matching_probability=True,
        budget_note='7680 bounds pilot candidate continuations only, not diagnostics or companion environment steps')
    manifest['diagnostic_contract'] = dict(cases=24, strata={'iid': 12, 'ood_stress': 10, 'ood_scale': 2},
        outcome_selected=False, excluded_regressions=['case_0343', 'case_0444'],
        canary_regression_cases=['case_0343', 'case_0444'],
        zero_intervention_replay_tolerance=0., max_microfit_samples=4, microfit_steps=100,
        microfit_lr=.001, microfit_loss_ratio_max=.5, min_non_tied_microfit_samples=1,
        pilot_wall_estimate_limit_seconds=172800, scientific_result=False)
    if canary:
        manifest['sampling_audits']['11'].update(case_order=['case_0343', 'case_0444'])
    suite.mkdir(parents=True, exist_ok=False)
    for filename, payload in [('diagnostic_cases.json', diagnostic_cases), ('regression_cases.json', regression_cases)]:
        atomic_json(suite / filename, payload)
    manifest['research_case_files'] = {name: {'path': str(suite / name), 'sha256': digest(suite / name)}
        for name in ('diagnostic_cases.json', 'regression_cases.json')}
    atomic_json(suite / 'iga_reference_audit.json', json.loads(Path(old['iga_reference_audit']['path']).read_text()))
    manifest['iga_reference_audit'] = {'path': str(suite / 'iga_reference_audit.json'),
                                      'sha256': digest(suite / 'iga_reference_audit.json')}
    archive = suite / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for relative, expected in fingerprints.items():
            data = (ROOT / relative).read_bytes()
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError(f'Source changed while archiving: {relative}')
            info = handle.gettarinfo(str(ROOT / relative), arcname=relative)
            handle.addfile(info, io.BytesIO(data))
    manifest['source_archive'] = {'path': str(archive), 'sha256': digest(archive)}
    atomic_json(suite / 'manifest.json', manifest)
    atomic_json(suite / 'evaluator_source.json', {'command': next(iter(commands.values()))['argv']})
    print(suite / 'manifest.json', flush=True)
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--profile', choices=['diagnostic', 'canary', 'pilot'], default='diagnostic')
    parser.add_argument('--diagnostic-proof', type=Path)
    parser.add_argument('--canary-proof', type=Path)
    parser.add_argument('--python', type=Path, default=Path(sys.executable))
    prepare(parser.parse_args())
