#!/usr/bin/env python3
"""Complete the real 16-live-branch timeout regression; no shortened horizon."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from onpolicy.config.config import get_config
from onpolicy.scripts.train.benchmark_stage2_cost_execution import trace_update
from onpolicy.scripts.train.diagnose_stage2_cost_improvement import make_runner
from onpolicy.scripts.train.run_stage2_bc_injection_suite import verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism
from onpolicy.utils.stage2_cost_accelerated import AcceleratedCostIteration, load_config
from onpolicy.utils.stage2_cost_continuation import digest
from onpolicy.utils.stage2_cost_execution import array_digest, coalesce_queries, json_digest, run_fanout, semantic_outcome
from onpolicy.utils.stage2_cost_improvement import actor_forward, policy_digest
from onpolicy.utils.stage2_cost_timeout import TIMEOUT_CONTRACT
from onpolicy.utils.stage2_cost_timeout_reference import intervention_signature


def verify(cli):
    path = cli.manifest.resolve()
    manifest = json.loads(path.read_text())
    verify_resources(manifest)
    executor = manifest['cost_executor']
    config = load_config(executor['path'], executor['sha256'])
    if (config.get('timeout_contract') != TIMEOUT_CONTRACT or config['fanout_width'] != 16
            or config['actor_lanes'] != 4):
        raise ValueError('The real-load timeout regression requires the declared 16-branch/4-lane fix.')
    reference = manifest['timeout_reference']
    for file, sha in reference['artifacts'].items():
        if digest(file) != sha:
            raise ValueError(f'Regression input changed: {file}')
    rows = [json.loads(line) for line in Path(reference['evidence']).read_text().splitlines()]
    first = rows[0]
    with gzip.open(first['state_path'], 'rb') as handle:
        state = torch.load(handle, map_location='cpu', weights_only=False)
    output = path.parent / ('timeout_regression_smoke' if cli.smoke_prefix_steps else 'timeout_regression')
    output.mkdir(exist_ok=False)
    report = dict(manifest=str(path), status='running', started_unix_time=time.time(),
        timeout_gate_passed=False, scientific_result=False, timeout_contract=TIMEOUT_CONTRACT,
        reference=reference, fanout_width=16, actor_lanes=4,
        smoke_prefix_steps=cli.smoke_prefix_steps,
        note='Terminal costs/steps compared with complete archived r3 results; '
             'new trace hashes are archived, not claimed to match unavailable old full-load traces.')
    atomic_json(output / 'report.json', report)
    runner = iterator = None
    try:
        configure_bc_determinism(True)
        torch.set_num_threads(1)
        torch.cuda.set_per_process_memory_fraction(.70, device=0)
        torch.manual_seed(11)
        torch.cuda.manual_seed_all(11)
        args = parse_args(manifest['commands']['N2_cost_teacher_seed11']['argv'][2:], get_config())
        args.n_rollout_threads = args.max_train_cases = args.train_sampling_size = 24
        args.stage2_research_train_cases = str(path.parent / 'diagnostic_cases.json')
        runner = make_runner(args, manifest, output)
        before = policy_digest(runner.policy)
        iterator = AcceleratedCostIteration(runner, 1)
        # This fixture starts at an archived state, not through prepare().
        # Populate its progress-only metadata without resetting either GRU.
        iterator.step, iterator.rollout = int(first['step']), 1
        if before != first['policy_sha256'] or iterator.model_sha256 != before:
            raise ValueError('Regression must use the exact same frozen student.')
        actual_actions, actual_hidden = actor_forward(iterator.policy, state['obs'], state['target_rnn'],
            state['active'], state['history'], state['agent_types'])
        if (not np.array_equal(actual_actions, state['frozen_actions'])
                or not np.array_equal(actual_hidden, state['target_post_forward_rnn'])):
            raise ValueError('Archived initial action or both-GRU state differs from the legacy actor.')
        iterator.next_rnn = actual_hidden.copy()
        snapshots = first['environment_snapshots']
        loaded = runner.envs.call_each('stage2_cost_load_regression_snapshot',
            [(x['path'], x['file_sha256'], x['sha256']) for x in snapshots])
        if loaded != first['batch_snapshot_sha256']:
            raise ValueError('Regression companions changed or were reordered.')
        queries, expected = [], []
        for row in rows:
            for candidate, sha, outcome in zip(row['candidates'], row['first_actions_sha256'], row['outcomes']):
                action = state['frozen_actions'].copy()
                env, resources = row['env'], row['rows']
                action[env] = state['student'][env]
                action[env, resources, 0], action[env, resources, 1] = candidate, 0
                if array_digest(action) != sha:
                    raise ValueError('Regression full intervention differs from its archived identity.')
                queries.append((action, env))
                expected.append(outcome)
        jobs = coalesce_queries(queries)
        if len(queries) != 29 or len(jobs) != 20:
            raise ValueError('The production-load regression must retain all 29 queries/20 distinct jobs.')
        context = dict(first['cache_context'], arithmetic=iterator.arithmetic)
        if (context['max_steps'] != runner.episode_length
                or array_digest(iterator.next_rnn) != context['post_forward_recurrent_sha256']):
            raise ValueError('Regression cannot shorten the full terminal horizon or change recurrent state.')
        if cli.smoke_prefix_steps:
            runner.episode_length = cli.smoke_prefix_steps
            context['max_steps'] = cli.smoke_prefix_steps
        hashes = [hashlib.sha256() for _ in jobs]
        traces = [None] * len(queries)

        def observe(job, step, action, rnn, results):
            trace_update(hashes[job], action, rnn, results)
            for index, target in jobs[job]['consumers']:
                if step == expected[index]['steps']:
                    traces[index] = hashes[job].hexdigest()

        actual, metrics = run_fanout(iterator, queries, width=16, context=context,
                                    cache=iterator.cache, observer=observe)
        reused, warm = run_fanout(iterator, queries, width=16, context=context, cache=iterator.cache)
        complete = all(row['completed'] for row in actual)
        exact = [semantic_outcome(row) for row in actual] == [semantic_outcome(row) for row in expected]
        cache_exact = warm['cache_hits'] == 29 and [semantic_outcome(row) for row in actual] == [semantic_outcome(row) for row in reused]
        unchanged = policy_digest(runner.policy) == before
        passed = (not cli.smoke_prefix_steps and complete and exact and cache_exact and unchanged and metrics['cache_hits'] == 0
                  and metrics['physical_jobs'] == 20 and metrics['peak_live_jobs'] == 16
                  and all(trace is not None for trace in traces)
                  and metrics['charged_work_seconds'] <= metrics['wall_seconds'] + 1e-6)
        report.update(status='completed', ended_unix_time=time.time(), timeout_gate_passed=passed,
            completed=complete, outcomes_exact=exact, cache_exact=cache_exact, source_weights_unchanged=unchanged,
            logical_queries=29, batch_width=24, execution=metrics, cache_execution=warm,
            branch_budget_seconds=args.stage2_cost_branch_timeout_seconds,
            cache_context=context, intervention_signature=intervention_signature(rows),
            actual_outcomes=actual, expected_outcomes=expected, full_load_traces=traces)
        load_config(executor['path'], executor['sha256'])
        atomic_json(output / 'report.json', report)
        smoke_ok = (cli.smoke_prefix_steps and unchanged and metrics['peak_live_jobs'] == 16
                    and all(row['reason'] == 'step_limit' for row in actual))
        return 0 if passed or smoke_ok else 2
    except BaseException as error:
        report.update(status='failed', error=str(error), ended_unix_time=time.time())
        atomic_json(output / 'report.json', report)
        raise
    finally:
        if iterator is not None:
            iterator.close()
        if runner is not None:
            runner.envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--smoke-prefix-steps', type=int, default=0)
    cli = parser.parse_args()
    if not 0 <= cli.smoke_prefix_steps <= 16:
        parser.error('Use zero for the complete proof, or 1-16 steps for a non-gating smoke.')
    raise SystemExit(verify(cli))
