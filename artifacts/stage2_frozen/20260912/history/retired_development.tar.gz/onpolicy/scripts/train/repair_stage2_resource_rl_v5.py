#!/usr/bin/env python3
"""Explicit r3 initial-audit repair; retain engineering and the original clock."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from onpolicy.scripts.train.continue_stage2_resource_rl_v5 import BudgetController, validate_stop_point
from onpolicy.scripts.train.control_stage2_resource_rl_v5 import Controller
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL
from onpolicy.utils.stage2_resource_rl_v5_zero import VERSION, non_audit_code_sha

CHANGED_FILE = 'onpolicy/utils/stage2_resource_rl_v5.py'
HELPER = 'onpolicy/utils/stage2_resource_rl_v5_zero.py'
DOC = 'STAGE2_SPLIT_ENCODER_V5_ZERO_AUDIT_REPAIR_20260909.md'
LAUNCHER = 'onpolicy/scripts/train/launch_stage2_resource_rl_v5_repair_gpu0.sh'


def validate_failed_stop(m, status, worker):
    if (m.get('protocol') != PROTOCOL or m.get('training_contract') != DEFAULTS
            or status.get('status') != 'failed' or status.get('phase') != 'initial_evaluation_and_reference'
            or status.get('completed_training_case_episodes') != 0
            or status.get('completed_physical_case_episodes') != 96
            or status.get('attempted_physical_case_episodes') != 108
            or status.get('completed_physical_case_episodes_this_process') != 0
            or worker.get('status') != 'failed' or worker.get('evaluation_label') != 'E0_initial_AR'
            or worker.get('attempted_physical_case_episodes') != 12
            or worker.get('completed_physical_case_episodes', 0) != 0
            or worker.get('error') != 'Copied architecture is not zero-update equivalent to B0.'):
        raise ValueError('Repair adapter accepts only r3 first-batch initial-audit failure, with no training.')
    return True


def read_failed_parent(parent, proof_path):
    m = json.loads((parent / 'manifest.json').read_text())
    status = json.loads((parent / 'run_status.json').read_text())
    worker = json.loads((parent / 'workers/setup/run_status.json').read_text())
    validate_failed_stop(m, status, worker)
    if (parent / 'reference').exists() or list((parent / 'evaluations').glob('*.json')):
        raise ValueError('Advanced reference/evaluation results cannot be silently repeated.')
    if any((parent / 'workers' / a).exists() or (parent / a).exists() for a in ARMS[1:]):
        raise ValueError('Unexpected advanced arm output.')
    c = m['budget_continuation']
    engineering_parent = Path(c['parent'])
    for name, digest in c['retained_artifacts'].items():
        if file_sha(engineering_parent / name) != digest:
            raise ValueError('Retained original engineering artifact changed.')
    for name in c['copied_artifacts']:
        if file_sha(parent / name) != c['retained_artifacts'][name]:
            raise ValueError('Retained engineering report copy changed.')
    reports = {a: json.loads((parent / 'engineering' / a / 'report.json').read_text()) for a in ARMS}
    validate_stop_point(m, json.loads((engineering_parent / 'run_status.json').read_text()), reports)
    for key in ('source', 'stage1_source', 'source_archive', 'parent_manifest', 'historical_b0_ar', 'iga_reference'):
        if file_sha(m[key]['path']) != m[key]['sha256']:
            raise ValueError(f'Immutable source changed: {key}')
    for name, digest in {**c['immutable_prior_code_fingerprint'], **m['code_fingerprint']}.items():
        if name != CHANGED_FILE and file_sha(ROOT / name) != digest:
            raise ValueError(f'Old source changed outside the isolated audit: {name}')
    with tarfile.open(m['source_archive']['path']) as archive:
        old_source = archive.extractfile(CHANGED_FILE).read().decode()
    signature = non_audit_code_sha(old_source)
    if signature != non_audit_code_sha((ROOT / CHANGED_FILE).read_text()):
        raise ValueError('Cannot reuse engineering after a non-audit scientific code change.')
    proof = json.loads(proof_path.read_text())
    if (proof.get('passed') is not True or proof.get('version') != VERSION
            or proof.get('source_manifest_sha256') != file_sha(parent / 'manifest.json')
            or proof.get('non_audit_code_sha256') != signature
            or proof.get('changed_file_sha256') != file_sha(ROOT / CHANGED_FILE)
            or proof.get('repair_helper_sha256') != file_sha(ROOT / HELPER)
            or proof.get('environment_case_episodes') != 0 or proof.get('scientific_updates') != 0
            or set(proof.get('arms', {})) != set(ARMS)):
        raise ValueError('Missing exact-code, four-arm GPU repair proof.')
    for a, result in proof['arms'].items():
        if (result.get('passed') is not True or result.get('genuine_drift_rejected') is not True
                or result.get('reference_frozen_after') is not True or result.get('reference_weights_unchanged') is not True
                or result.get('actor_steps') != 0 or result.get('critic_steps') != 0
                or any(r.get('equal') is not True for k in ('repaired_reference', 'behavior_unchanged') for r in result[k].values())):
            raise ValueError(f'Incomplete positive/negative repair proof for {a}.')
    if file_sha(proof['fixture']) != proof['fixture_sha256']:
        raise ValueError('Failure fixture changed.')
    reproduction_path = Path(proof['fixture']).parent / 'report.json'
    reproduction = json.loads(reproduction_path.read_text())
    if (reproduction.get('reproduced') is not True or reproduction.get('failing_event') != 247
            or reproduction.get('attempted_case_episodes') != 12 or reproduction.get('completed_case_episodes') != 0
            or reproduction.get('actor_steps') != 0 or reproduction.get('critic_steps') != 0):
        raise ValueError('Missing bounded reproduction/case accounting.')
    checkpoint = torch.load(parent / 'E0/checkpoint_interrupted.pt', map_location='cpu', weights_only=True)
    contract = checkpoint['split_encoder_contract']
    if any(contract.get(k) != 0 for k in ('actor_steps', 'critic_steps', 'completed_rounds', 'case_episodes')):
        raise ValueError('Cannot discard an already-updated scientific checkpoint.')
    source = torch.load(m['source']['path'], map_location='cpu', weights_only=True)['model']
    if set(checkpoint['model']) != set(source) or any(
            not torch.equal(checkpoint['model'][k], v) for k, v in source.items() if not k.startswith('team_critic.')):
        raise ValueError('Interrupted E0 actor is not the original B0.')
    return m, status, proof, reproduction_path


def prepare(parent, output, tag, proof_path, service_deadline):
    parent, output, proof_path = parent.resolve(), output.resolve(), proof_path.resolve()
    if output.exists() or not tag.replace('_', '').replace('-', '').isalnum():
        raise ValueError('New output directory and safe run tag required.')
    old, status, proof, reproduction = read_failed_parent(parent, proof_path)
    control = json.loads((parent / 'control.json').read_text())
    if not time.time() < service_deadline <= control['hard_deadline_unix']:
        raise ValueError('Original service deadline must not be extended or expired.')
    m = copy.deepcopy(old)
    m.update(run_tag=tag, created_at=datetime.now(timezone.utc).isoformat())
    m['repair_of'] = dict(path=str(parent), manifest_sha256=file_sha(parent / 'manifest.json'),
        control_sha256=file_sha(parent / 'control.json'), status_sha256=file_sha(parent / 'run_status.json'),
        original_started_unix=control['started_unix'], hard_deadline_unix=control['hard_deadline_unix'])
    copies = old['budget_continuation']['copied_artifacts']
    retained = ['manifest.json', 'control.json', 'run_status.json', 'controller.log',
        'workers/setup/run_status.json', 'logs/setup_E0.log', 'halt_after_current_round.json',
        'E0/checkpoint_interrupted.pt', 'E0/checkpoint_interrupted.handoff.json',
        'checks/preliminary_budget_gate.json'] + copies
    m['zero_audit_repair'] = dict(version=VERSION, user_request='排查并修复问题，然后继续实验',
        parent=str(parent), gpu_proof=dict(path=str(proof_path), sha256=file_sha(proof_path)),
        reproduction=dict(path=str(reproduction), sha256=file_sha(reproduction)),
        retained_artifacts={name: file_sha(parent / name) for name in retained}, copied_artifacts=copies,
        inherited_worker_exit_records=status['worker_exit_records'], non_audit_code_sha256=proof['non_audit_code_sha256'],
        original_service_hard_deadline_unix=service_deadline, new_time_budget=False,
        retained_engineering_case_episodes=96, prior_failed_setup_attempted_case_episodes=12,
        diagnostic_attempted_case_episodes=12, diagnostic_completed_case_episodes=0,
        new_production_case_episode_limit=2220, lifetime_attempted_case_episode_limit=2340,
        formal_training_case_episodes=960, automatic_retry=False, engineering_weights_loaded=False,
        interrupted_weights_loaded=False, old_artifacts_retained=True)
    m['material_passport']['version_label'] = VERSION
    m['code_fingerprint'] = code_fingerprint()
    for name in ('STAGE2_SPLIT_ENCODER_V5_20260909.md',
                 'STAGE2_SPLIT_ENCODER_V5_BUDGET_CONTINUATION_20260909.md', DOC, LAUNCHER):
        m['code_fingerprint'][name] = file_sha(ROOT / name)
    output.mkdir(parents=True, exist_ok=False)
    for name in copies:
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(parent / name, target)
        if file_sha(target) != m['zero_audit_repair']['retained_artifacts'][name]:
            raise ValueError('Copied engineering evidence changed.')
    archive_path = output / 'source_bundle.tar.gz'
    with tarfile.open(archive_path, 'x:gz') as archive:
        for name, digest in m['code_fingerprint'].items():
            data = (ROOT / name).read_bytes()
            if file_sha(ROOT / name) != digest:
                raise ValueError('Source changed during archival.')
            archive.addfile(archive.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(data))
    m['source_archive'] = dict(path=str(archive_path), sha256=file_sha(archive_path))
    atomic_json(output / 'checks/retained_engineering.json', dict(passed=True,
        retained_case_episodes=96, non_audit_code_unchanged=True, non_audit_code_sha256=proof['non_audit_code_sha256'],
        repair_proof=m['zero_audit_repair']['gpu_proof']))
    atomic_json(output / 'manifest.json', m)
    print(output / 'manifest.json', flush=True)


class AuditRepairController(BudgetController):
    def __init__(self, manifest):
        # The ordinary controller preserves repair_of's original started/deadline.
        # Do NOT invoke BudgetController.__init__, which creates a fresh clock.
        Controller.__init__(self, manifest)
        repair = self.m.get('zero_audit_repair', {})
        if repair.get('version') != VERSION or repair.get('new_time_budget') is not False:
            raise ValueError('Explicit audit-only repair authorization required.')
        self.records = [{**r, 'retained_from_previous_process': True} for r in repair['inherited_worker_exit_records']]

    def validate_continuation(self):
        r = self.m['zero_audit_repair']
        parent = Path(r['parent'])
        old, _, _, _ = read_failed_parent(parent, Path(r['gpu_proof']['path']))
        for key in ('training_contract', 'source', 'stage1_source', 'train', 'evaluation', 'execution', 'screen', 'resource_contract'):
            if self.m[key] != old[key]:
                raise ValueError(f'Audit-only repair cannot change {key}.')
        if (self.started != json.loads((parent / 'control.json').read_text())['started_unix']
                or self.deadline != json.loads((parent / 'control.json').read_text())['hard_deadline_unix']
                or not time.time() < r['original_service_hard_deadline_unix'] <= self.deadline):
            raise ValueError('Original time authorization changed/expired.')
        for name, digest in r['retained_artifacts'].items():
            if file_sha(parent / name) != digest:
                raise ValueError('Old failure/evidence artifact changed.')
        for name in r['copied_artifacts']:
            if file_sha(self.root / name) != r['retained_artifacts'][name]:
                raise ValueError('Copied evidence changed.')
        for item in (r['gpu_proof'], r['reproduction'], self.m['source_archive']):
            if file_sha(item['path']) != item['sha256']:
                raise ValueError('Pinned proof/archive changed.')
        for name, digest in self.m['code_fingerprint'].items():
            if file_sha(ROOT / name) != digest:
                raise ValueError(f'Pinned repaired code changed: {name}')

    def status(self, **extra):
        attempts = 0
        for name in ('setup', *ARMS):
            path = self.root / 'workers' / name / 'run_status.json'
            if path.exists():
                attempts += json.loads(path.read_text()).get('attempted_physical_case_episodes', 0)
        return super().status(repair_parent=self.m['zero_audit_repair']['parent'], new_time_budget=False,
            prior_failed_setup_attempted_case_episodes=12, diagnostic_attempted_case_episodes=12,
            lifetime_attempted_physical_case_episodes=96 + 12 + 12 + attempts,
            lifetime_attempted_case_episode_limit=2340, **extra)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    prep = sub.add_parser('prepare')
    prep.add_argument('--parent', type=Path, required=True)
    prep.add_argument('--output', type=Path, required=True)
    prep.add_argument('--run-tag', required=True)
    prep.add_argument('--proof', type=Path, required=True)
    prep.add_argument('--service-deadline', type=float, required=True)
    run = sub.add_parser('run')
    run.add_argument('--manifest', type=Path, required=True)
    cli = parser.parse_args()
    if cli.mode == 'prepare':
        prepare(cli.parent, cli.output, cli.run_tag, cli.proof, cli.service_deadline)
    else:
        sys.exit(AuditRepairController(cli.manifest).run())
