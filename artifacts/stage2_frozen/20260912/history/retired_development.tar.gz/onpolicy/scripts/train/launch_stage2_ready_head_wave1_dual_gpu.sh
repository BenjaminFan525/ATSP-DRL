#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARE="${ROOT}/onpolicy/scripts/train/prepare_stage2_ready_head_wave1.py"
TRIAL_RUNNER="${ROOT}/onpolicy/scripts/train/run_stage2_ready_head_trial.py"
RUN_TAG="${RUN_TAG:-stage2_ready_head_20260903_r1}"
SUITE_DIR="${SUITE_DIR:-${ROOT}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT_PREFIX="${UNIT_PREFIX:-hkbz-s2-ready-20260903-r1}"
DRY_RUN="${DRY_RUN:-0}"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-10}"

METHODS=(
  P0_log_lr3e5
  P1_log_lr3e4
  P2_log_lr1e3
  P3_hybrid_lr3e4
  P4_h2x3_lr3e4
  P5_hybrid_h2x3_lr3e4
)
GPUS=(0 0 0 1 1 1)
CPU_SETS=(
  0-11,72-83
  12-23,84-95
  24-35,96-107
  36-47,108-119
  48-59,120-131
  60-71,132-143
)
NUMA_NODES=(0 0 0 1 1 1)

manifest_path() {
  printf '%s/ready_head_wave1_manifest.json' "${SUITE_DIR}"
}

unit_name() {
  local lane="$1"
  printf '%s-g%s-l%s' "${UNIT_PREFIX}" "${GPUS[${lane}]}" "${lane}"
}

verify_inputs() {
  [[ -x "${PYTHON}" ]] || { echo "[Error] Python missing: ${PYTHON}" >&2; exit 1; }
  [[ -f "${PREPARE}" ]] || { echo "[Error] prepare script missing" >&2; exit 1; }
  [[ -f "${TRIAL_RUNNER}" ]] || { echo "[Error] trial runner missing" >&2; exit 1; }
}

verify_cpu_partition() {
  "${PYTHON}" - "${CPU_SETS[@]}" <<'PY'
import os
import sys

def expand(spec):
    result = set()
    for part in spec.split(','):
        left, separator, right = part.partition('-')
        result.update(
            range(int(left), int(right) + 1)
            if separator else (int(left),)
        )
    return result

groups = [expand(value) for value in sys.argv[1:]]
if len(groups) != 6 or any(len(group) != 24 for group in groups):
    raise SystemExit(f'expected six 24-CPU groups, got {[len(x) for x in groups]}')
union = set()
for index, group in enumerate(groups):
    overlap = union & group
    if overlap:
        raise SystemExit(f'CPU overlap in lane {index}: {sorted(overlap)}')
    union |= group
    for cpu in group:
        sibling = cpu + 72 if cpu < 72 else cpu - 72
        if sibling not in group:
            raise SystemExit(f'lane {index} splits SMT siblings {cpu}/{sibling}')
available = set(os.sched_getaffinity(0))
if union != available:
    raise SystemExit(
        f'partition differs from launcher affinity: '
        f'missing={sorted(available-union)}, extra={sorted(union-available)}'
    )
print('[CPU] six isolated lanes, 12 physical/24 logical CPUs each; all CPUs covered')
PY
}

verify_gpus() {
  local gpu row busy
  for gpu in 0 1; do
    row="$(nvidia-smi --id="${gpu}" --query-gpu=index,name,memory.total --format=csv,noheader,nounits)"
    [[ "${row}" == "${gpu},"* ]] && [[ "${row}" == *"A800 80GB"* ]] || {
      echo "[Error] GPU${gpu} differs from calibration: ${row}" >&2
      exit 1
    }
    busy="$(nvidia-smi --id="${gpu}" --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null || true)"
    [[ -z "${busy//[[:space:]]/}" ]] || {
      echo "[Error] GPU${gpu} has active compute PIDs: ${busy}" >&2
      exit 1
    }
  done
}

require_fresh_run() {
  [[ ! -e "${SUITE_DIR}" ]] || {
    echo "[Error] suite already exists: ${SUITE_DIR}" >&2
    exit 1
  }
  local lane state unit
  for lane in 0 1 2 3 4 5; do
    unit="$(unit_name "${lane}").service"
    state="$(systemctl --user show "${unit}" -p LoadState --value 2>/dev/null || true)"
    [[ -z "${state}" || "${state}" == not-found ]] || {
      echo "[Error] systemd unit already exists: ${unit}" >&2
      exit 1
    }
  done
}

prepare_manifest() {
  mkdir -p "${SUITE_DIR}"/{records,service_logs,hardware}
  "${PYTHON}" "${PREPARE}" \
    --run-tag "${RUN_TAG}" \
    --suite-dir "${SUITE_DIR}" \
    --output "$(manifest_path)"
}

launch_lane() {
  local lane="$1"
  local method="${METHODS[${lane}]}"
  local gpu="${GPUS[${lane}]}"
  local cpus="${CPU_SETS[${lane}]}"
  local node="${NUMA_NODES[${lane}]}"
  local unit="$(unit_name "${lane}")"
  local log="${SUITE_DIR}/service_logs/${unit}.log"
  local delay=$((lane % 3 * START_STAGGER_SECONDS))
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv="CUDA_VISIBLE_DEVICES=${gpu}" \
    --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 \
    --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 \
    --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv=MPLCONFIGDIR=/tmp/hkbz-mpl \
    --property=Type=exec \
    --property=Restart=no \
    --property=KillMode=control-group \
    --property=TimeoutStopSec=180 \
    --property=LimitNOFILE=65536 \
    --property="AllowedCPUs=${cpus}" \
    --property="CPUAffinity=${cpus}" \
    --property=NUMAPolicy=bind \
    --property="NUMAMask=${node}" \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "$(manifest_path)" \
      --command-key "${method}" \
      --gpu "${gpu}" \
      --cpu-set "${cpus}" \
      --start-delay-seconds "${delay}" \
      --record "${SUITE_DIR}/records/g${gpu}l${lane}.json" >/dev/null
  echo "[Launch] ${unit}.service ${method} GPU=${gpu} CPUs=${cpus} NUMA=${node} delay=${delay}s"
}

verify_services() {
  local lane state unit
  sleep 4
  for lane in 0 1 2 3 4 5; do
    unit="$(unit_name "${lane}")"
    state="$(systemctl --user is-active "${unit}.service" 2>/dev/null || true)"
    [[ "${state}" == active || "${state}" == activating ]] || {
      echo "[Error] ${unit}.service failed initial health check (${state})" >&2
      return 1
    }
  done
}

stop_started_units() {
  local lane
  for lane in 0 1 2 3 4 5; do
    systemctl --user stop "$(unit_name "${lane}").service" >/dev/null 2>&1 || true
  done
}

main() {
  local lane
  cd "${ROOT}"
  verify_inputs
  verify_cpu_partition
  require_fresh_run
  prepare_manifest
  if [[ "${DRY_RUN}" == 1 ]]; then
    echo "[DryRun] manifest=$(manifest_path)"
    echo "[DryRun] methods=${METHODS[*]}"
    return 0
  fi
  verify_gpus
  trap stop_started_units ERR INT TERM
  for lane in 0 1 2 3 4 5; do
    launch_lane "${lane}"
  done
  verify_services
  trap - ERR INT TERM
  echo "[Started] suite=${SUITE_DIR}"
}

main "$@"
