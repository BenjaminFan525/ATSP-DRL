#!/usr/bin/env python3
"""Explicit accelerated entry point; the original train_hkbz entry is unchanged."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main(argv):
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--stage2-cost-executor-config', type=Path, required=True)
    parser.add_argument('--stage2-cost-executor-sha256', required=True)
    executor, training = parser.parse_known_args(argv)
    from onpolicy.utils.stage2_cost_accelerated import load_config
    config = load_config(executor.stage2_cost_executor_config, executor.stage2_cost_executor_sha256)
    if '--stage2_cost_improvement' in training and not config['cost_training_allowed']:
        raise ValueError('Cost training requires acceleration, diagnostic and stage-specific canary proofs.')
    from onpolicy.scripts.train.train_hkbz import main as train
    return train(training)


if __name__ == '__main__':
    main(sys.argv[1:])
