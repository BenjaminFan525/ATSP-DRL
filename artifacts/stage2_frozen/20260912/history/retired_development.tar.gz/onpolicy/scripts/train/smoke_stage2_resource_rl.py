#!/usr/bin/env python3
"""Two-case GPU engineering test, discarded weights, no scientific selection."""
import argparse
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.prepare_stage2_resource_rl import B0, B0_SHA, PARENT, case_record
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, seed
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_resource_rl import DEFAULTS, ResourceLearner, file_sha, reset_critic, summary


def main(cli):
    if cli.output.exists() or os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('Fresh output and GPU0-only environment are required.')
    cli.output.mkdir(parents=True)
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    parent = json.loads((PARENT / 'manifest.json').read_text())
    contract = {**DEFAULTS, 'ppo_passes': 1, 'critic_warmup_steps': 2, 'chunk_length': 8}
    args = arguments(dict(environment_argv=parent['commands']['B0_none_seed11']['argv'][2:], training_contract=contract))
    args.max_train_cases = args.train_sampling_size = args.n_rollout_threads = 2
    source = B0 / 'models/checkpoint_Best.pt'
    assert file_sha(source) == B0_SHA
    payload = torch.load(source, map_location='cpu', weights_only=True)
    for key, value in ready_head_config(payload).items():
        setattr(args, key, value)
    teacher = json.loads(Path(parent['teacher_index']).read_text())
    rows = [case_record(Path(teacher['dataset_dir']) / name) for name in ('case_0001', 'case_0003')]
    policy = GNN_MAPPOPolicy(args, yaml.safe_load(Path(args.ac_config).read_text()), torch.device('cuda:0'))
    last = [0.]
    def progress(event, force=False, **values):
        if force or time.time() - last[0] > 20:
            last[0] = time.time()
            print(event, values, flush=True)
            atomic_json(cli.output / 'progress.json', dict(event=event, **values))
    report = dict(passed=False, scientific_result=False, arms={})
    atomic_json(cli.output / 'report.json', report)
    for arm in ('S2RL_BC', 'S2RL_PPO'):
        policy.load_model_state(payload['model'])
        policy.ac.device_global_matching = False
        policy.ac.tau = args.evaluation_tau
        seed(11)
        if arm == 'S2RL_PPO':
            reset_critic(policy.ac)
            policy.capture_bc_reference(payload['model'])
            policy.bc_reference_ac.device_global_matching = False
        learner = ResourceLearner(policy, args, contract, progress)
        progress('arm_start', force=True, arm=arm)
        envs, _ = make_train_env(args, case_records=rows)
        try:
            rollout = learner.collect(envs, training=True, bc=arm == 'S2RL_BC', audit=True)
        finally:
            envs.close()
        atomic_json(cli.output / f'{arm}_rollout.json',
                    {k: v for k, v in rollout.items() if k not in ('frames', 'targets')})
        update = learner.update(rollout, bc=arm == 'S2RL_BC', warmup=True)
        report['arms'][arm] = dict(cases=rollout['cases'], update=update,
            probability_checks=learner.probability_checks, protected_unchanged=True)
        atomic_json(cli.output / 'report.json', report)
        torch.save({'model': policy.ac.state_dict(), 'engineering_only': True}, cli.output / f'{arm}_engineering.pt')
        del rollout
    report['passed'] = True
    atomic_json(cli.output / 'report.json', report)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    cli = parser.parse_args()
    try:
        main(cli)
    except BaseException:
        if cli.output.is_dir():
            atomic_json(cli.output / 'engineering_failure.json',
                        dict(passed=False, traceback=traceback.format_exc()))
        raise
