#!/usr/bin/env python3
"""Eight-case-episode GPU0 engineering proof; discard scientific claims."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.prepare_stage2_resource_rl import B0, B0_SHA, PARENT, case_record
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, seed, cpus
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_resource_rl import file_sha, reset_critic, summary, RESOURCE_PREFIXES
from onpolicy.utils.stage2_resource_rl_v4 import ARMS, DEFAULTS, PROTOCOL, CaseMinibatchLearner, case_minibatches
from onpolicy.utils.training_stage import validate_stage2_joint_finetune_checkpoint


def main(cli):
    if cli.output.exists() or os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('New output and physical GPU0 required.')
    if not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Engineering test must also respect the original CPU half.')
    cli.output.mkdir(parents=True)
    fingerprints = code_fingerprint()
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    parent = json.loads((PARENT / 'manifest.json').read_text())
    contract = {**DEFAULTS, 'minibatch_cases': 1, 'critic_warmup_steps': 20,
                'rounds': 1, 'epochs': 1, 'rollout_cases': 2, 'evaluation_rounds': [1],
                'critic_steps_per_round': 2, 'minibatch_audit_prefix': 64}
    args = arguments(dict(environment_argv=parent['commands']['B0_none_seed11']['argv'][2:], training_contract=contract))
    source = B0 / 'models/checkpoint_Best.pt'
    if file_sha(source) != B0_SHA:
        raise ValueError('B0 source changed.')
    payload = torch.load(source, map_location='cpu', weights_only=True)
    for k, v in ready_head_config(payload).items():
        setattr(args, k, v)
    teacher = json.loads(Path(parent['teacher_index']).read_text())
    rows = [case_record(Path(teacher['dataset_dir']) / name) for name in ('case_0001', 'case_0003')]
    args.max_train_cases = args.train_sampling_size = args.n_rollout_threads = 2
    policy = GNN_MAPPOPolicy(args, yaml.safe_load(Path(args.ac_config).read_text()), torch.device('cuda:0'))
    policy.load_model_state(payload['model'])
    policy.ac.tau = args.evaluation_tau
    last = [0.]
    def progress(event, force=False, **values):
        if force or time.time() - last[0] > 20:
            last[0] = time.time()
            print(event, values, flush=True)
            atomic_json(cli.output / 'progress.json', dict(event=event, **values))
    report = dict(passed=False, scientific_result=False, arms={}, case_episode_limit=8,
                  resources=dict(gpu=0, allowed_cpus='0-31,64-95'))
    atomic_json(cli.output / 'report.json', report)
    learner = CaseMinibatchLearner(policy, args, {**contract, 'baseline': 'rollout'}, progress)
    policy.ac.device_global_matching = True
    seed(1)
    envs, _ = make_train_env(args, case_records=rows)
    try:
        baseline = learner.collect(envs, training=False, hungarian=True, capture_values=True, trace_indices=[0])
    finally:
        envs.close()
    reference = {r['case_dir']: r['makespan'] for r in baseline['cases']}
    atomic_json(cli.output / 'reference.json', {k: v for k, v in baseline.items() if k not in ('frames', 'targets', 'value_data')})
    first_signature = None
    for arm in ARMS:
        policy.load_model_state(payload['model'])
        policy.ac.device_global_matching = False
        seed(200011)
        reset_critic(policy.ac)
        policy.capture_bc_reference(payload['model'])
        policy.bc_reference_ac.device_global_matching = False
        learner = CaseMinibatchLearner(policy, args,
            {**contract, 'baseline': 'rollout' if arm == ARMS[0] else 'value'}, progress)
        if arm == ARMS[1]:
            warmup = learner.warmup_value(baseline['value_data'], [1])
            atomic_json(cli.output / 'critic_warmup.json', warmup)
        progress('arm_start', force=True, arm=arm)
        envs, _ = make_train_env(args, case_records=rows)
        seed(300012)
        try:
            rollout = learner.collect(envs, training=True, audit=True, trace_indices=[0])
        finally:
            envs.close()
        signature = (rollout['trajectory_action_sha256'], [(r['makespan'], r['steps']) for r in rollout['cases']])
        if first_signature is None:
            first_signature = signature
        elif signature != first_signature:
            raise RuntimeError('Separated RNG streams did not give identical initial trajectories.')
        # Exact same recurrent inputs, cached vs freshly encoded graph, before updates.
        cache_error = 0.
        with torch.no_grad():
            for indices in case_minibatches(2, contract['minibatch_cases'], 0):
                hidden = learner._hidden(len(indices))
                for frame in rollout['frames'][:8]:
                    cached = learner._forward_subset(frame, hidden, indices)
                    fresh = learner._forward_subset(frame, hidden, indices, use_cache=False)
                    cache_error = max(cache_error, float((cached['log_probs'] - fresh['log_probs']).abs().max()))
                    if not torch.equal(cached['actions'], fresh['actions']):
                        raise RuntimeError('Encoding cache changed an action.')
                    hidden = cached['rnn_states'] * (~torch.as_tensor(frame['dones'][indices], device=policy.device)).unsqueeze(-1).unsqueeze(-1)
        if cache_error > 1e-6:
            raise RuntimeError(f'Encoding cache changed likelihoods: {cache_error}')
        update = learner.update(rollout, reference_cmax=reference, round_index=1)
        if update['actor_steps'] != 4 or update['paused_for_kl']:
            raise RuntimeError('Engineering test did not finish four safe case-minibatch updates.')
        checkpoint = {**payload, 'model': policy.ac.state_dict(),
            'training_stage': 'resource_joint', 'stage2_training_mode': 'bc_resource_rl',
            'phase': 'resource_rl_completed', 'resource_deployment_decoder': 'autoregressive',
            'device_global_matching': False, 'confirmed_scientific_success': False,
            'stage2_scientific_gate': {'passed': False},
            'resource_rl_contract': dict(protocol=PROTOCOL, arm=arm,
                source=dict(path=str(source), sha256=B0_SHA), training=learner.contract,
                actor_steps=learner.actor_steps, critic_steps=learner.critic_steps,
                completed_rounds=1, case_episodes=2, teacher_execution=False, cost_queries=0,
                behavior_decoder='autoregressive', evaluation_decoder='autoregressive_argmax',
                probability_checks=learner.probability_checks, minibatch_checks=learner.minibatch_checks,
                protected_before=learner.protected, protected_after=summary(policy.ac, protected=True),
                actor_before=learner.source_actor, actor_after=summary(policy.ac, RESOURCE_PREFIXES),
                value_head_status='not_used_untrained' if arm == ARMS[0] else 'trained_value_baseline',
                stage3_requires_fresh_critic=True)}
        handoff = validate_stage2_joint_finetune_checkpoint(checkpoint, policy.ac.state_dict(),
            plane_order_mode=policy.ac.plane_order_mode, plane_pair_decoder=policy.ac.plane_pair_decoder,
            global_feature_mode=args.global_feature_mode, planning_contract=payload['resource_lookahead_contract'],
            request_ready_time_scale=policy.ac.request_ready_time_scale, resource_decoder='autoregressive')
        report['arms'][arm] = dict(cases=rollout['cases'], update=update,
            probability_checks=learner.probability_checks, encoding_cache=rollout['encoding_cache'],
            encoding_cache_logp_error=cache_error, trajectory_signature=signature,
            protected_unchanged=True, static_handoff=handoff)
        atomic_json(cli.output / f'{arm}_rollout.json',
                    {k: v for k, v in rollout.items() if k not in ('frames', 'targets')})
        atomic_json(cli.output / 'report.json', report)
        torch.save({'model': policy.ac.state_dict(), 'engineering_only': True}, cli.output / f'{arm}_engineering.pt')
        del rollout
        eval_args = type(args)(**vars(args))
        eval_args.max_train_cases = eval_args.train_sampling_size = eval_args.n_rollout_threads = 1
        envs, _ = make_train_env(eval_args, case_records=rows[:1])
        try:
            post = learner.collect(envs, training=False, trace_indices=[0])
        finally:
            envs.close()
        atomic_json(cli.output / f'{arm}_post_eval.json', {k: v for k, v in post.items() if k != 'frames'})
    changed = [name for name, expected in fingerprints.items() if file_sha(ROOT / name) != expected]
    if changed:
        raise RuntimeError(f'Source changed during engineering verification: {changed}')
    report.update(passed=True, identical_first_rollout=True, completed_case_episodes=8,
                  code_fingerprint=fingerprints, source_unchanged_during_verification=True)
    atomic_json(cli.output / 'report.json', report)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    cli = parser.parse_args()
    def timeout(signum, frame):
        raise TimeoutError('V4 engineering test reached its 45-minute hard limit.')
    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(2700)
    try:
        main(cli)
    except BaseException:
        if cli.output.is_dir():
            atomic_json(cli.output / 'engineering_failure.json', dict(passed=False, traceback=traceback.format_exc()))
        raise
    finally:
        signal.alarm(0)
