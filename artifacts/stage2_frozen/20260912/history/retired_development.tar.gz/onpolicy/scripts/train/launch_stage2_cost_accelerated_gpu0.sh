#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_PYTHON="${PYTHON:-${TASK_ROOT}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
TASK_TAG="${RUN_TAG:-stage2_cost_accelerated_20260907_gpu0_half_r1}"
[[ "${TASK_TAG}" =~ ^[a-zA-Z0-9_-]+$ ]] || { echo 'Invalid run tag' >&2; exit 1; }
TASK_SUITE="${TASK_ROOT}/result/hkbz_train_logs/${TASK_TAG}"
TASK_UNIT="hkbz-${TASK_TAG//_/-}"
[[ ! -e "${TASK_SUITE}" ]] || { echo 'Never reuse an experiment directory' >&2; exit 1; }
# User services do not inherit the invoking shell's PATH. Pin it for this unit
# and its children only; never change the user manager's global environment.
TASK_SERVICE_PATH="${PATH:-/usr/local/bin:/usr/bin:/bin}"
export PATH="${TASK_SERVICE_PATH}"
[[ -f "${TASK_PYTHON}" && -x "${TASK_PYTHON}" ]] || {
  printf 'Python is not an executable file: %s\n' "${TASK_PYTHON}" >&2; exit 1;
}
for TASK_COMMAND in rg taskset nvidia-smi bash systemd-run; do
  type -P "${TASK_COMMAND}" >/dev/null || {
    printf 'Missing required command in Stage2 service PATH: %s\n' "${TASK_COMMAND}" >&2; exit 1;
  }
done
export CUDA_VISIBLE_DEVICES=0 CUDA_DEVICE_ORDER=PCI_BUS_ID
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
TASK_EXTRA_ARGS=(--fanout-width "${FANOUT_WIDTH:-8}" --actor-lanes "${ACTOR_LANES:-2}"
                 --inference-mode "${INFERENCE_MODE:-legacy}")
if [[ -n "${CONTINUE_FROM:-}" ]]; then
  TASK_EXTRA_ARGS+=(--continue-from "${CONTINUE_FROM}")
fi
if [[ -n "${TIMEOUT_CONTRACT:-}" ]]; then
  TASK_EXTRA_ARGS+=(--timeout-contract "${TIMEOUT_CONTRACT}")
fi
taskset -c 30-31,94-95 "${TASK_PYTHON}" \
  "${TASK_ROOT}/onpolicy/scripts/train/prepare_stage2_cost_accelerated.py" \
  --run-tag "${TASK_TAG}" --suite-dir "${TASK_SUITE}" --stage pipeline --python "${TASK_PYTHON}" \
  "${TASK_EXTRA_ARGS[@]}"
if [[ "${DRY_RUN:-0}" == 1 ]]; then exit 0; fi
TASK_RUNTIME=172800
if [[ -n "${CONTINUE_FROM:-}" ]]; then
  TASK_RUNTIME="$("${TASK_PYTHON}" -c 'import json,sys,time; m=json.load(open(sys.argv[1])); print(max(0,int(m["continuation"]["hard_deadline_unix_time"]-time.time())))' "${TASK_SUITE}/manifest.json")"
  [[ "${TASK_RUNTIME}" =~ ^[0-9]+$ && "${TASK_RUNTIME}" -gt 0 && "${TASK_RUNTIME}" -le 172800 ]] || exit 1
fi
systemd-run --user --unit="${TASK_UNIT}" --working-directory="${TASK_ROOT}" \
  --setenv=PATH="${TASK_SERVICE_PATH}" \
  --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
  --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 --setenv=OPENBLAS_NUM_THREADS=1 \
  --setenv=NUMEXPR_NUM_THREADS=1 --setenv=PYTHONHASHSEED=0 \
  --setenv=CUBLAS_WORKSPACE_CONFIG=:4096:8 --setenv=PYTHONDONTWRITEBYTECODE=1 \
  --setenv=MPLCONFIGDIR="${TASK_SUITE}/mplconfig" \
  --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
  --property=Type=exec --property=Restart=no --property=KillMode=control-group \
  --property=RuntimeMaxSec="${TASK_RUNTIME}" --property=TimeoutStopSec=180 --property=LimitNOFILE=65536 \
  --property=AllowedCPUs=0-31,64-95 --property=CPUAffinity=0-31,64-95 \
  --property="StandardOutput=append:${TASK_SUITE}/controller.log" \
  --property="StandardError=append:${TASK_SUITE}/controller.log" \
  "${TASK_PYTHON}" -u "${TASK_ROOT}/onpolicy/scripts/train/run_stage2_cost_accelerated_pipeline.py" \
  --manifest "${TASK_SUITE}/manifest.json"
printf 'Started %s\nManifest: %s\n' "${TASK_UNIT}" "${TASK_SUITE}/manifest.json"
