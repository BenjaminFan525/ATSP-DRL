#!/usr/bin/env python3
"""One bounded V5 engineering/setup/training worker. No automatic retries."""
from __future__ import annotations

import argparse
import copy
import fcntl
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.run_stage2_resource_rl import Progress, arguments, cpus, seed
from onpolicy.scripts.train.run_stage2_resource_rl_v4 import Suite as V4Suite, save_tensor_artifact
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_policy_transfer import verified_frozen_ready_source
from onpolicy.utils.stage2_resource_rl import file_sha, reset_critic, summary
from onpolicy.utils.stage2_resource_rl_handoff import validate_frozen_lineage
from onpolicy.utils.stage2_resource_rl_v4_fast import prepared_forward
from onpolicy.utils.stage2_resource_rl_v4_resume import assert_tree_equal
from onpolicy.utils.stage2_resource_rl_v5 import (
    ACTOR, ARMS, DEFAULTS, PROTOCOL, SplitEncoderLearner, architecture_manifest, clean_cases,
    protected_summary, restore_training_state, training_state,
)
from onpolicy.utils.stage2_resource_rl_v5_handoff import validate_split_handoff


class SplitSuite(V4Suite):
    def __init__(self, manifest, phase, arm, slot):
        super().__init__(manifest)
        self.phase, self.arm, self.slot = phase, arm, slot
        self.worker_root = self.root / ('engineering' if phase == 'engineering' else 'workers') / (arm if phase != 'setup' else 'setup')
        self.limit = 24 if phase == 'engineering' else 540 if phase == 'setup' else 420
        self.m['resource_contract']['train_cpus'] = self.m['resource_contract']['trainer_slots'][slot]
        self.learner = None
        self.completed_rounds = self.case_episodes = 0

    def validate_manifest(self):
        if self.m['protocol'] != PROTOCOL or self.c != DEFAULTS or self.m['execution']['arms'] != list(ARMS):
            raise ValueError('Unapproved split-encoder experiment contract.')
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
            raise ValueError('GPU0 / original CPU half required.')
        if (self.worker_root / 'run_status.json').exists():
            raise FileExistsError('No automatic retry or worker-directory reuse.')
        for name, digest in self.m['code_fingerprint'].items():
            if file_sha(ROOT / name) != digest:
                raise ValueError(f'Pinned source changed: {name}')
        for key in ('source', 'stage1_source', 'source_archive', 'parent_manifest', 'historical_b0_ar', 'iga_reference'):
            item = self.m[key]
            if file_sha(item['path']) != item['sha256']:
                raise ValueError(f'Immutable input changed: {key}')
        for key in ('train', 'evaluation'):
            validate_case_content(self.m[key]['cases'], self.m[key]['dataset'])
        parent = json.loads(Path(self.m['parent_manifest']['path']).read_text())
        if self.m['train'] != parent['train'] or self.m['evaluation'] != parent['evaluation']:
            raise ValueError('Historical data content/order altered.')

    def policy(self, arm):
        seed(self.c['seed'] + 100000)
        policy = GNN_MAPPOPolicy(self.args, self.ac_config, torch.device('cuda:0'))
        policy.load_model_state(self.payload['model'])
        if summary(policy.ac) != summary(self.payload['model']):
            raise ValueError('Loaded B0 model differs from source.')
        policy.ac.tau, policy.ac.device_global_matching = self.args.evaluation_tau, False
        policy.capture_bc_reference(self.payload['model'])
        policy.bc_reference_ac.device_global_matching = False
        seed(self.c['seed'] + 200000)
        reset_critic(policy.ac)
        return SplitEncoderLearner(policy, self.args, self.c, self.progress, arm=arm)

    def collect_batch(self, learner, rows, *, training=False, hungarian=False, evaluation=False,
                      capture_values=False, audit=False, rollout_seed=1, traces=False):
        if self.attempted_episodes + len(rows) > self.limit:
            raise RuntimeError('Worker physical case budget exceeded.')
        args = copy.copy(self.args)
        args.seed = rollout_seed
        args.max_train_cases = args.train_sampling_size = args.n_rollout_threads = len(rows)
        os.sched_setaffinity(0, cpus(self.m['resource_contract']['eval_cpus' if evaluation else 'train_cpus']))
        self.envs, _ = make_train_env(args, case_records=rows,
            dataset_override=self.m['evaluation' if evaluation else 'train']['dataset'], evaluation=evaluation)
        learner.policy.ac.device_global_matching = hungarian
        seed(rollout_seed)
        self.attempted_episodes += len(rows)
        self.progress('case_batch_start', force=True, phase=self.phase, arm=learner.arm,
            attempted_physical_case_episodes=self.attempted_episodes,
            current_batch_cases=[r['case_dir'] for r in rows])
        try:
            result = learner.collect(self.envs, training=training, hungarian=hungarian,
                capture_values=capture_values, audit=audit,
                trace_indices=[i for i, r in enumerate(rows) if traces and r['case_dir'] in self.m['diagnostics']['trace_cases']])
        finally:
            self.envs.close()
            self.envs = None
            learner.policy.ac.device_global_matching = False
        result['cases'] = clean_cases(result['cases'], rows)
        self.total_episodes += len(rows)
        self.training_episodes += len(rows) if training and self.phase == 'train' else 0
        self.progress('case_batch_completed', force=True, completed_physical_case_episodes=self.total_episodes,
                      completed_training_case_episodes=self.training_episodes)
        return result

    def evaluate(self, learner, label, **kwargs):
        # At most one evaluator even when both training slots are occupied.
        with (self.root / 'evaluation.lock').open('a') as lock:
            while True:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    self.progress('waiting_for_serial_evaluation', phase='waiting_for_evaluation', evaluation_label=label)
                    time.sleep(1)
            try:
                return super().evaluate(learner, label, **kwargs)
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)
                os.sched_setaffinity(0, cpus(self.m['resource_contract']['train_cpus']))

    def checkpoint(self, learner, filename, *, completed=False):
        contract = dict(protocol=PROTOCOL, arm=learner.arm, source=self.m['source'], training=self.c,
            completed_rounds=self.completed_rounds, case_episodes=self.case_episodes,
            actor_steps=learner.actor_steps, critic_steps=learner.critic_steps,
            architecture=architecture_manifest(learner.policy.ac), initial_architecture=learner.initial_architecture,
            protected_before=learner.protected, protected_after=protected_summary(learner.policy.ac),
            actor_before=learner.source_actor, actor_after=summary(learner.policy.ac, ACTOR),
            probability_checks=learner.probability_checks, minibatch_checks=learner.minibatch_checks,
            gradient_checks=learner.gradient_checks, stage3_requires_fresh_critic_and_optimizers=True,
            optimizer_state_archival_only=True, scientific_gate_passed=False)
        state = training_state(learner)
        payload = {**self.payload, 'model': state.pop('model'), 'split_encoder_contract': contract,
            'split_encoder_training_state': state, 'phase': 'split_encoder_stage_b_completed' if completed else 'split_encoder_running',
            'stage2_training_mode': 'split_encoder_ppo_v5', 'training_stage': 'resource_joint',
            'resource_deployment_decoder': 'autoregressive', 'device_global_matching': False,
            'stage2_scientific_gate': {'passed': False}, 'confirmed_scientific_success': False,
            'manifest_sha256': file_sha(self.path), 'resume_requires_explicit_new_manifest': True}
        path = self.worker_root / filename if self.phase == 'engineering' else self.root / learner.arm / filename
        save_tensor_artifact(payload, path)
        report = validate_split_handoff(payload, learner.policy.ac, require_completed=completed)
        atomic_json(path.with_suffix('.handoff.json'), report)
        return str(path)

    @staticmethod
    def conditional_plane_check(learner, rollout, prefix=64):
        learner.clear_replay_cache()
        learner.policy.ac.eval()
        hidden, reference_hidden = learner._hidden(6), learner._hidden(6)
        maximum = 0.
        with torch.no_grad():
            for frame in rollout['frames'][:prefix]:
                entry = learner._entry(frame, list(range(6)))
                out = learner._forward_subset(frame, hidden, list(range(6)))
                ref, _ = prepared_forward(learner.policy, entry['data'], entry['info'], reference_hidden,
                    actions=entry['actions'], encoded=entry['encoded'], reference=True)
                p = learner.args.max_agent_num
                for key in ('actions', 'decision_mask', 'log_probs', 'rnn_states'):
                    error = float((out[key][:, :p].float() - ref[key][:, :p].float()).abs().max())
                    maximum = max(maximum, error)
                if maximum > 1e-6:
                    raise RuntimeError('Original conditional plane policy/history changed.')
                hidden = out['rnn_states'] * (~entry['dones']).unsqueeze(-1).unsqueeze(-1)
                reference_hidden = ref['rnn_states'] * (~entry['dones']).unsqueeze(-1).unsqueeze(-1)
        learner.clear_replay_cache()
        return dict(passed=True, max_error=maximum, prefix=prefix,
                    contract='same_observation_and_history_not_same_closed_loop_state_after_resource_changes')

    def engineering(self):
        learner = self.learner = self.policy(self.arm)
        atomic_json(self.worker_root / 'architecture_initial.json', learner.initial_architecture)
        rows = [self.m['train']['cases'][i] for i in self.m['train']['collection_batches'][0]]
        torch.cuda.reset_peak_memory_stats()
        began = time.monotonic()
        rollout = self.collect_batch(learner, rows, training=True, audit=True,
                                     rollout_seed=self.c['seed'] + 300001)
        atomic_json(self.worker_root / 'rollout.json', {k: v for k, v in rollout.items() if k not in ('frames', 'targets')})
        # Keep a small raw observable fixture for diagnosing proof failures.
        save_tensor_artifact(dict(frames=rollout['frames'][:2], targets=rollout['targets'][:2]), self.worker_root / 'raw_fixture.pt')
        plane_before = self.conditional_plane_check(learner, rollout)
        start = time.monotonic()
        update = learner.update(rollout, round_index=1)
        update_seconds = time.monotonic() - start
        atomic_json(self.worker_root / 'update.json', update)
        plane_after = self.conditional_plane_check(learner, rollout)
        frozen_reference = summary(learner.policy.bc_reference_ac) == summary(self.payload['model'])
        if not frozen_reference or learner.actor_steps != 8 or learner.critic_steps != 50:
            raise RuntimeError('Full engineering update/reference proof incomplete.')
        checkpoint_path = self.checkpoint(learner, 'discarded_engineering_checkpoint.pt')
        state = training_state(learner)
        # Read the actual file rather than proving an in-memory-only restore.
        saved = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
        restored = self.policy(self.arm)
        restore_training_state(restored, {**saved['split_encoder_training_state'], 'model': saved['model']})
        assert_tree_equal(state, training_state(restored), 'V5 disk checkpoint/Adam/RNG')
        learner.policy.ac.eval()
        restored.policy.ac.eval()
        hidden, other_hidden = learner._hidden(6), restored._hidden(6)
        with torch.no_grad():
            for frame in rollout['frames'][:64]:
                left = learner._forward_subset(frame, hidden, list(range(6)))
                right = restored._forward_subset(frame, other_hidden, list(range(6)))
                assert_tree_equal(left, right, 'restored action/logp/hidden')
                done = torch.as_tensor(frame['dones'][:6], device=learner.device)
                hidden = left['rnn_states'] * (~done).unsqueeze(-1).unsqueeze(-1)
                other_hidden = right['rnn_states'] * (~done).unsqueeze(-1).unsqueeze(-1)
        learner.clear_replay_cache()
        restored.clear_replay_cache()
        result = dict(passed=True, arm=self.arm, completed_case_episodes=24,
            seconds=time.monotonic() - began, collection_seconds=rollout['seconds'], update_seconds=update_seconds,
            critic_50_steps_seconds=learner.critic_seconds,
            peak_allocated_bytes=torch.cuda.max_memory_allocated(), peak_reserved_bytes=torch.cuda.max_memory_reserved(),
            trajectory_action_sha256=rollout['trajectory_action_sha256'],
            trajectory_cases=[(r['case_dir'], r['makespan'], r['steps']) for r in rollout['cases']],
            initial_architecture=learner.initial_architecture, gradient_checks=learner.gradient_checks,
            plane_before=plane_before, plane_after=plane_after, restored_weights_adam_rng_and_forward_equal=True,
            frozen_reference_unchanged=frozen_reference, learned_encoder_outputs_cached=False,
            recurrent_hidden_cached=False, probability_checks=learner.probability_checks,
            minibatch_checks=learner.minibatch_checks, scientific_updates_discarded=True,
            source_checkpoint=self.m['source'], fresh_production_initialization_required=True)
        atomic_json(self.worker_root / 'report.json', result)

    def setup(self):
        for arm in ARMS:
            if not json.loads((self.root / 'engineering' / arm / 'report.json').read_text())['passed']:
                raise ValueError('All four engineering arms must pass before initial evaluation.')
        zero = {}
        for arm in ARMS:
            learner = self.learner = self.policy(arm)
            learner.verify_initial_reference = True
            actual = self.evaluate(learner, arm + '_initial_AR', audit=True)
            learner.verify_initial_reference = False
            expected = json.loads(Path(self.m['historical_b0_ar']['path']).read_text())['cases']
            ref = {r['case_sha256']: r for r in expected}
            errors = [r['case_dir'] for r in actual if r['makespan'] != ref[r['case_sha256']]['makespan']
                      or r['steps'] != ref[r['case_sha256']]['steps']]
            if errors:
                raise ValueError(f'Initial {arm} differs from historical B0 AR: {errors}')
            zero[arm] = dict(passed=True, cases=60, conditional_reference=learner.initial_reference_checks,
                             replay_checks=learner.probability_checks)
            atomic_json(self.root / 'checks/zero_update.json', zero)
            self.learner = None
            del learner
        learner = self.learner = self.policy('E0')
        actual = self.evaluate(learner, 'B0_H', hungarian=True)
        expected = {r['case_sha256']: r for r in self.m['evaluation']['cases']}
        if any(r['makespan'] != expected[r['case_sha256']]['makespan'] or
               r['steps'] != expected[r['case_sha256']]['finish_steps'] for r in actual):
            raise ValueError('B0 full tune60 Hungarian strict replay failed.')
        atomic_json(self.root / 'checks/b0_hungarian.json', dict(passed=True, cases=60, tolerance=0.))
        pool_parts, reports = [], []
        for batch, indices in enumerate(self.m['train']['collection_batches'], 1):
            rows = [self.m['train']['cases'][i] for i in indices]
            self.progress('reference_batch_start', force=True, phase='reference', batch=batch, total_batches=10)
            rollout = self.collect_batch(learner, rows, hungarian=True, capture_values=True)
            pool = rollout.pop('raw_value_pool')
            pool['case_indices'] = torch.tensor(indices)[pool['case_indices']]
            path = self.root / 'reference' / f'raw_graph_pool_{batch}.pt'
            save_tensor_artifact(pool, path)
            pool_parts.append(dict(path=str(path), sha256=file_sha(path), states=len(pool['targets'])))
            report = {k: v for k, v in rollout.items() if k not in ('frames', 'targets')}
            atomic_json(self.root / 'reference' / f'batch_{batch}.json', report)
            reports.append(report)
            del pool, rollout
        atomic_json(self.root / 'reference/manifest.json', dict(parts=pool_parts, case_episodes=240,
            max_states_per_case=32, source=self.m['source'], observable_only=True, decoder='hungarian',
            seconds=sum(r['seconds'] for r in reports), cost_labels=0))
        atomic_json(self.root / 'checks/setup_complete.json', dict(passed=True, completed_case_episodes=self.total_episodes))

    def train_one(self):
        gate = json.loads((self.root / 'checks/budget_gate.json').read_text())
        if not gate['passed'] or not json.loads((self.root / 'checks/setup_complete.json').read_text())['passed']:
            raise ValueError('Engineering/zero-update/time-budget gates have not passed.')
        learner = self.learner = self.policy(self.arm)
        atomic_json(self.root / self.arm / 'architecture_initial.json', learner.initial_architecture)
        reference = json.loads((self.root / 'reference/manifest.json').read_text())
        parts = []
        for item in reference['parts']:
            if file_sha(item['path']) != item['sha256']:
                raise ValueError('Raw reference pool changed.')
            # HeteroData is a pinned local artifact, not an untrusted checkpoint.
            parts.append(torch.load(item['path'], map_location='cpu', weights_only=False))
        pool = dict(graphs=[g for p in parts for g in p['graphs']],
            embeddings=torch.cat([p['embeddings'] for p in parts]),
            targets=torch.cat([p['targets'] for p in parts]), case_indices=torch.cat([p['case_indices'] for p in parts]))
        del parts
        validation = sorted(range(240), key=lambda i: self.m['train']['cases'][i]['case_sha256'])[::4]
        self.progress('critic_warmup_start', force=True, phase='critic_warmup', arm=self.arm)
        warmup = learner.warmup_value(pool, validation)
        atomic_json(self.root / self.arm / 'critic_warmup.json', warmup)
        del pool
        checkpoint_path = self.checkpoint(learner, 'checkpoint_warmup.pt')
        for round_index, indices in enumerate(self.m['train']['collection_batches'], 1):
            if (self.root / 'halt_after_current_round.json').exists():
                raise RuntimeError('Controller halted new rounds after another worker failed.')
            self.progress('round_start', force=True, phase='training', arm=self.arm,
                          collection_round=round_index, total_rounds=10, actor_steps=learner.actor_steps)
            rollout = self.collect_batch(learner, [self.m['train']['cases'][i] for i in indices], training=True,
                                         rollout_seed=self.c['seed'] + 300000 + round_index)
            self.case_episodes += 24
            atomic_json(self.root / self.arm / f'round_{round_index}_rollout.json',
                        {k: v for k, v in rollout.items() if k not in ('frames', 'targets')})
            started = time.monotonic()
            update = learner.update(rollout, round_index=round_index)
            update['seconds'] = time.monotonic() - started
            atomic_json(self.root / self.arm / f'round_{round_index}_update.json', update)
            del rollout
            self.completed_rounds = round_index
            complete = round_index == 10 and not update['paused_for_kl']
            checkpoint_path = self.checkpoint(learner, f'checkpoint_round_{round_index}.pt', completed=complete)
            atomic_json(self.root / self.arm / 'result.json', dict(status='completed' if complete else
                'paused_for_kl' if update['paused_for_kl'] else 'running', completed_rounds=round_index,
                case_episodes=self.case_episodes, checkpoint=checkpoint_path,
                actor_steps=learner.actor_steps, critic_steps=learner.critic_steps))
            if update['paused_for_kl']:
                return False
            if round_index in (5, 10):
                self.evaluate(learner, f'{self.arm}_round_{round_index}_AR')
            if complete:
                self.evaluate(learner, f'{self.arm}_round_10_H', hungarian=True)
        return True

    def run(self):
        self.validate_manifest()
        control = json.loads((self.root / 'control.json').read_text())
        remaining = int(control['hard_deadline_unix'] - time.time())
        if remaining <= 0:
            raise TimeoutError('Global first-batch deadline expired.')
        self.worker_root.mkdir(parents=True, exist_ok=True)
        self.progress = Progress(self.worker_root, remaining)
        def stop(signum, frame):
            if signum == signal.SIGALRM:
                raise TimeoutError('Global first-batch 24-hour deadline reached.')
            raise KeyboardInterrupt(f'Operator/service signal {signum}')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGALRM, stop)
        signal.alarm(remaining)
        try:
            configure_bc_determinism(True)
            torch.set_num_threads(1)
            torch.cuda.set_per_process_memory_fraction(.42, 0)
            if str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') != self.m['resource_contract']['gpu_uuid'].removeprefix('GPU-'):
                raise ValueError('Physical GPU UUID differs from authorized GPU0.')
            self.args = arguments(self.m)
            self.payload = torch.load(self.m['source']['path'], map_location='cpu', weights_only=True)
            verified_frozen_ready_source(self.payload)
            for key, value in ready_head_config(self.payload).items():
                setattr(self.args, key, value)
            self.ac_config = yaml.safe_load(Path(self.args.ac_config).read_text())
            atomic_json(self.worker_root / 'frozen_lineage.json', validate_frozen_lineage(self.payload, self.m['stage1_source']))
            completed = True
            if self.phase == 'engineering':
                self.engineering()
            elif self.phase == 'setup':
                self.setup()
            else:
                completed = self.train_one()
            self.progress('completed' if completed else 'paused_for_kl', force=True,
                status='completed' if completed else 'paused_for_kl', phase=self.phase, arm=self.arm,
                completed_physical_case_episodes=self.total_episodes, scientific_success_confirmed=False)
            return 0  # A predeclared KL pause is not a crash or automatic restart.
        except BaseException as exc:
            self.progress.state.update(event='worker_stopped', status='timeout' if isinstance(exc, TimeoutError) else 'failed',
                                       error=str(exc), traceback=traceback.format_exc())
            self.progress.write()
            if self.learner is not None:
                try:
                    self.checkpoint(self.learner, 'checkpoint_interrupted.pt')
                except Exception as save_error:
                    print('Could not save interruption checkpoint:', save_error, flush=True)
            print(traceback.format_exc(), flush=True)
            return 1
        finally:
            signal.alarm(0)
            self.progress.stop.set()
            if self.envs is not None:
                self.envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--phase', choices=('engineering', 'setup', 'train'), required=True)
    parser.add_argument('--arm', choices=ARMS, default='E0')
    parser.add_argument('--slot', type=int, choices=(0, 1), default=0)
    cli = parser.parse_args()
    sys.exit(SplitSuite(cli.manifest, cli.phase, cli.arm, cli.slot).run())
