#!/usr/bin/env python3
"""Two-slot Stage A+B controller. All gates fail closed; never retries/promotes."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl import cpus, metrics
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v4 import compare_cases, screen_candidate
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, PROTOCOL


def budget_projection(reports, remaining, eval_seconds_per_case=0.):
    per_arm = {a: 10 * (r['collection_seconds'] + r['update_seconds'])
               + 6 * r['critic_50_steps_seconds'] for a, r in reports.items()}
    # Measurements already came from the same two concurrent slots. Use fixed
    # pairs for an intentionally conservative upper estimate, not ideal scaling.
    training = max(per_arm['E0'], per_arm['E1']) + max(per_arm['E2'], per_arm['E3'])
    evaluations = 720 * eval_seconds_per_case  # serialized AR5/10 + H10, all arms
    estimate = 1.25 * (training + evaluations)
    return dict(passed=estimate <= remaining, remaining_seconds=remaining,
        projected_seconds=estimate, training_two_slot_seconds=training,
        serialized_evaluation_seconds=evaluations, safety_multiplier=1.25,
        per_arm_training_warmup_seconds=per_arm, benchmark_concurrency=2,
        silent_scope_reduction=False, optional_stage_c_authorized=False)


def analyze(root, m):
    def rows(label):
        path = root / 'evaluations' / (label + '.json')
        return json.loads(path.read_text())['cases'] if path.exists() else None
    ar, h, e0 = rows('E0_initial_AR'), rows('B0_H'), rows('E0_round_10_AR')
    report = dict(protocol=PROTOCOL, primary_endpoint='round10_AR', monitoring_endpoint='round5_AR',
        scientific_success_confirmed=False, automatic_stage_c=False, stage3_started=False, methods={})
    if ar is not None and h is not None:
        iga = json.loads(Path(m['iga_reference']['path']).read_text())['baselines']
        for arm in ARMS:
            current = rows(arm + '_round_10_AR')
            if current is None:
                report['methods'][arm] = dict(candidate_complete=False)
                continue
            vs_ar, vs_h = compare_cases(ar, current), compare_cases(h, current)
            vs_e0 = compare_cases(e0, current) if e0 else None
            report['methods'][arm] = dict(candidate_complete=True, summary=metrics(current),
                versus_B0_AR=vs_ar, versus_B0_H=vs_h, versus_matched_E0=vs_e0,
                baseline_screen_passed=screen_candidate(vs_ar, vs_h),
                eligible_for_future_stage_c_decision=bool(arm != 'E0' and vs_e0 and
                    vs_e0['mean_delta'] < 0 and screen_candidate(vs_ar, vs_h)),
                historical_iga={name: compare_cases(value['cases'], current) for name, value in iga.items()},
                formal_iga_goal_certifiable=False, independent_confirmation=False)
    atomic_json(root / 'analysis.json', report)


class Controller:
    def __init__(self, manifest):
        self.path, self.root = manifest.resolve(), manifest.resolve().parent
        self.m = json.loads(self.path.read_text())
        self.started = time.time()
        self.process_started = self.started
        self.deadline = self.started + 86400
        if 'repair_of' in self.m:
            prior = self.m['repair_of']
            self.started, self.deadline = prior['original_started_unix'], prior['hard_deadline_unix']
            for name, key in (('manifest.json', 'manifest_sha256'), ('control.json', 'control_sha256'),
                              ('run_status.json', 'status_sha256')):
                if file_sha(Path(prior['path']) / name) != prior[key]:
                    raise ValueError('Prior failed-run lineage changed.')
            if self.deadline <= time.time():
                raise ValueError('Original first-batch deadline expired; new time budget needs approval.')
        self.jobs, self.records = {}, []
        self.phase = 'engineering'

    def status(self, **extra):
        status = extra.pop('status', 'running')
        workers = {}
        for phase, arm in [(p, a) for p in ('engineering', 'train') for a in ARMS] + [('setup', 'E0')]:
            path = self.root / ('engineering' if phase == 'engineering' else 'workers') / (arm if phase != 'setup' else 'setup') / 'run_status.json'
            if path.exists():
                workers[phase + '/' + arm] = json.loads(path.read_text())
        atomic_json(self.root / 'run_status.json', dict(status=status, phase=self.phase, pid=os.getpid(),
            started_unix=self.started, updated_unix=time.time(), hard_deadline_unix=self.deadline,
            process_started_unix=getattr(self, 'process_started', self.started),
            process_elapsed_seconds=time.time() - getattr(self, 'process_started', self.started),
            budget_elapsed_seconds=time.time() - self.started,
            elapsed_seconds=time.time() - self.started, workers=workers, worker_exit_records=self.records,
            completed_physical_case_episodes=sum(w.get('completed_physical_case_episodes', 0) for w in workers.values()),
            attempted_physical_case_episodes=sum(w.get('attempted_physical_case_episodes', 0) for w in workers.values()),
            completed_training_case_episodes=sum(w.get('completed_training_case_episodes', 0) for k, w in workers.items() if k.startswith('train/')),
            allowed_stages=['A', 'B'], automatic_retry=False, automatic_stage_c=False, stage3_started=False,
            scientific_success_confirmed=False, **extra))

    def launch(self, phase, arm, slot):
        cpu = self.m['resource_contract']['trainer_slots'][slot]
        logpath = self.root / 'logs' / f'{phase}_{arm}.log'
        logpath.parent.mkdir(parents=True, exist_ok=True)
        log = logpath.open('x')
        command = ['taskset', '-c', cpu, sys.executable, '-u', str(ROOT / 'onpolicy/scripts/train/run_stage2_resource_rl_v5.py'),
                   '--manifest', str(self.path), '--phase', phase, '--arm', arm, '--slot', str(slot)]
        proc = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        self.jobs[slot] = (proc, log, phase, arm)
        print(json.dumps(dict(event='worker_started', phase=phase, arm=arm, slot=slot, pid=proc.pid,
                              cpu=cpu, command=command)), flush=True)

    def batch(self, phase, arms):
        pending = list(arms)
        failed, last = False, 0.
        while pending or self.jobs:
            if time.time() >= self.deadline:
                raise TimeoutError('First-batch 24-hour hard deadline reached.')
            for slot in (0, 1):
                if pending and slot not in self.jobs and not failed:
                    self.launch(phase, pending.pop(0), slot)
                if slot in self.jobs:
                    proc, log, jobphase, arm = self.jobs[slot]
                    code = proc.poll()
                    if code is not None:
                        log.close()
                        del self.jobs[slot]
                        self.records.append(dict(phase=jobphase, arm=arm, exit_code=code, completed_unix=time.time()))
                        if code:
                            failed = True
                            pending.clear()
                            atomic_json(self.root / 'halt_after_current_round.json', dict(failed_phase=phase, arm=arm,
                                no_retry=True, safe_boundary_stop=True))
            if time.time() - last >= 30:
                self.status()
                if phase == 'train':
                    analyze(self.root, self.m)
                last = time.time()
            if self.jobs:
                time.sleep(2)
        if failed:
            raise RuntimeError(f'{phase} worker failed; no retry or later stage was scheduled.')

    def run(self):
        if self.m['protocol'] != PROTOCOL or (self.root / 'control.json').exists():
            raise ValueError('New V5 manifest required; no implicit resume/retry.')
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
            raise ValueError('Only GPU0 and original CPU half authorized.')
        atomic_json(self.root / 'control.json', dict(started_unix=self.started, hard_deadline_unix=self.deadline,
            process_started_unix=self.process_started,
            pid=os.getpid(), manifest_sha256=file_sha(self.path), automatic_retry=False))
        os.sched_setaffinity(0, cpus(self.m['resource_contract']['monitor_cpus']))
        def stop(signum, frame):
            raise KeyboardInterrupt(f'Operator/service signal {signum}')
        signal.signal(signal.SIGTERM, stop)
        try:
            self.status()
            # Fixed pairs make measured dual-slot throughput reproducible.
            self.batch('engineering', ['E0', 'E1'])
            self.batch('engineering', ['E2', 'E3'])
            reports = {a: json.loads((self.root / 'engineering' / a / 'report.json').read_text()) for a in ARMS}
            if not all(r['passed'] for r in reports.values()):
                raise ValueError('Engineering proof incomplete.')
            if len({r['trajectory_action_sha256'] for r in reports.values()}) != 1 or any(
                    r['trajectory_cases'] != reports['E0']['trajectory_cases'] for r in reports.values()):
                raise ValueError('Independent init/critic RNG changed first-collection actor trajectories.')
            for pair in (('E0', 'E1'), ('E2', 'E3')):
                if sum(reports[a]['peak_allocated_bytes'] for a in pair) > .8 * 49140 * 1024**2:
                    raise ValueError('Dual-trainer GPU memory headroom gate failed; no automatic scale change.')
            preliminary = budget_projection(reports, self.deadline - time.time())
            atomic_json(self.root / 'checks/preliminary_budget_gate.json', preliminary)
            if not preliminary['passed']:
                self.status(status='budget_blocked', reason='Training alone exceeds remaining budget; scope/time decision required.')
                return 2
            self.phase = 'initial_evaluation_and_reference'
            self.batch('setup', ['E0'])
            eval_rate = max(json.loads((self.root / 'evaluations' / f'{a}_initial_AR.json').read_text())['seconds'] / 60 for a in ARMS)
            eval_rate = max(eval_rate, json.loads((self.root / 'evaluations/B0_H.json').read_text())['seconds'] / 60)
            projection = budget_projection(reports, self.deadline - time.time(), eval_rate)
            atomic_json(self.root / 'checks/budget_gate.json', projection)
            if not projection['passed']:
                self.status(status='budget_blocked', reason='Measured full Stage B exceeds remaining budget; no training launched.')
                return 2
            self.phase = 'stage_b_training'
            self.batch('train', ['E0', 'E1'])
            self.batch('train', ['E2', 'E3'])
            analyze(self.root, self.m)
            paused = any(json.loads((self.root / a / 'result.json').read_text())['status'] == 'paused_for_kl' for a in ARMS)
            self.phase = 'stage_b_completed_with_paused_arm' if paused else 'stage_b_completed'
            self.status(status='completed_with_paused_arm' if paused else 'completed', optional_stage_c='requires_new_user_authorization')
            return 0
        except BaseException as exc:
            # Signal only for the authorized hard deadline or an operator stop.
            if isinstance(exc, (TimeoutError, KeyboardInterrupt)):
                for proc, *_ in self.jobs.values():
                    proc.terminate()
                stop_by = time.monotonic() + 10
                while any(p.poll() is None for p, *_ in self.jobs.values()) and time.monotonic() < stop_by:
                    time.sleep(.2)
                for proc, *_ in self.jobs.values():
                    if proc.poll() is None:
                        proc.kill()
            self.status(status='timeout' if isinstance(exc, TimeoutError) else 'stopped' if isinstance(exc, KeyboardInterrupt) else 'failed',
                        error=str(exc), traceback=traceback.format_exc())
            print(traceback.format_exc(), flush=True)
            return 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    sys.exit(Controller(parser.parse_args().manifest).run())
