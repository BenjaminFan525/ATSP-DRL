#!/usr/bin/env python3
"""Explicit four-arm scheduling override; retain all original scientific workers.

Only the r7 scheduler is paused. Its E0/E1 children continue without restart;
E2/E3 run the identical pinned worker/manifest and share the original CPU pools.
Exclusive original log claims prevent the old queue from ever duplicating them.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.continue_stage2_resource_rl_v5_unlimited import (
    PinnedProcess, UnlimitedController, check_hashes, read, service_value,
)
from onpolicy.scripts.train.control_stage2_resource_rl_v5 import analyze
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl import cpus
from onpolicy.scripts.train.run_stage2_resource_rl_v5_unlimited import require_time_authorization
from onpolicy.utils.stage2_process_control import pidfd_open
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL

VERSION = 'v5_four_arm_explicit_dispatch_v1'
REQUEST = 'E2/E3现在可以一起启动'
PARENT_UNIT = 'hkbz-stage2-split-v5-20260909-gpu0-half-r7.service'
UNIT = 'hkbz-stage2-split-v5-20260909-gpu0-half-r8.service'
PARENT_NAME = 'stage2_split_encoder_v5_20260909_gpu0_half_train240_r7'
WORKER = ROOT / 'onpolicy/scripts/train/run_stage2_resource_rl_v5_unlimited.py'
SCRIPT = 'onpolicy/scripts/train/expedite_stage2_resource_rl_v5.py'
LAUNCHER = 'onpolicy/scripts/train/launch_stage2_resource_rl_v5_four_gpu0.sh'
TEST = 'onpolicy/envs/HKBZ/test/test_stage2_resource_rl_v5_four.py'
DOC = 'STAGE2_SPLIT_ENCODER_V5_FOUR_ARM_20260909.md'
SLOTS = {'E0': 0, 'E1': 1, 'E2': 0, 'E3': 1}
GIB = 1024 ** 3


def validate_scope(m):
    require_time_authorization(m)
    expected = dict(gpu=0, gpu_uuid='GPU-744c1334-98c8-5318-e799-7ad15eea1fbf',
        allowed_cpus='0-31,64-95', trainer_slots=['0-11,64-75', '12-23,76-87'],
        eval_cpus='24-29,88-93', monitor_cpus='30-31,94-95',
        max_concurrent_trainers=2, serialized_evaluation=True, runtime_max_seconds=None)
    if (m.get('protocol') != PROTOCOL or m.get('training_contract') != DEFAULTS
            or m.get('resource_contract') != expected
            or m['execution']['arms'] != list(ARMS)
            or m['execution']['total_training_case_episodes'] != 960
            or m['execution']['ar_training_evaluation_case_episodes'] != 480
            or m['execution']['hungarian_final_evaluation_case_episodes'] != 240
            or m['execution']['automatic_retry'] is not False
            or m['execution']['automatic_stage_c'] is not False):
        raise ValueError('Only concurrency of the unchanged r7 Stage B is authorized.')


def validate_pending(suite):
    state = read(suite / 'run_status.json')
    if (state.get('status') != 'running' or state.get('phase') != 'stage_b_training'
            or time.time() - state['updated_unix'] > 120
            or (suite / 'halt_after_current_round.json').exists()):
        raise ValueError('The original two-arm run is not healthy and current.')
    for arm in ('E0', 'E1'):
        worker = read(suite / 'workers' / arm / 'run_status.json')
        if worker.get('status') != 'running' or worker.get('arm') != arm:
            raise ValueError('Retained E0/E1 must still be running; no implicit resume.')
    for arm in ('E2', 'E3'):
        for path in (suite / arm, suite / 'workers' / arm, suite / 'logs' / f'train_{arm}.log'):
            if path.exists():
                raise FileExistsError(f'Arm already claimed; no duplicate or retry: {path}')
    return state


def authorize(suite, output):
    suite, output = suite.resolve(), output.resolve()
    if suite.name != PARENT_NAME or output.parent != suite.parent or output.name != PARENT_NAME[:-1] + '8':
        raise ValueError('Only the exact r7 experiment and its new r8 control directory are authorized.')
    m = read(suite / 'manifest.json')
    validate_scope(m)
    UnlimitedController(suite / 'manifest.json').validate_continuation()
    state = validate_pending(suite)
    hashes = {name: file_sha(ROOT / name) for name in (SCRIPT, LAUNCHER, TEST, DOC)}
    output.mkdir(exist_ok=False)
    archive = output / 'administrative_source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for name in hashes:
            handle.add(ROOT / name, arcname=name)
    request = dict(version=VERSION, user_request=REQUEST, suite=str(suite),
        parent_unit=PARENT_UNIT, unit=UNIT, original_controller_pid=state['pid'],
        manifest_sha256=file_sha(suite / 'manifest.json'),
        control_sha256=file_sha(suite / 'control.json'),
        source_archive=dict(path=str(archive), sha256=file_sha(archive)),
        code_fingerprint=hashes, max_concurrent_trainers=4, slots=SLOTS,
        original_resource_contract=m['resource_contract'],
        retained_workers=['E0', 'E1'], new_workers=['E2', 'E3'],
        training_case_episodes=960, evaluation_case_episodes=720,
        wall_clock_limit_enabled=False, automatic_retry=False, automatic_stage_c=False,
        shared_cpu_pools=True, serialized_evaluation=True,
        created_unix=time.time(), material_passport=dict(origin_skill='academic-research-suite',
            origin_mode='run', verification_status='UNVERIFIED', version_label=VERSION))
    atomic_json(output / 'authorization.json', request)
    atomic_json(output / 'original_status_before_handoff.json', state)
    return output / 'authorization.json'


def validate_request(path):
    path = path.resolve()
    r = read(path)
    suite = Path(r['suite'])
    if (r.get('version') != VERSION or r.get('user_request') != REQUEST
            or r.get('parent_unit') != PARENT_UNIT or r.get('unit') != UNIT
            or suite.name != PARENT_NAME or r.get('max_concurrent_trainers') != 4
            or r.get('slots') != SLOTS or r.get('retained_workers') != ['E0', 'E1']
            or r.get('new_workers') != ['E2', 'E3'] or r.get('training_case_episodes') != 960
            or r.get('evaluation_case_episodes') != 720
            or any(r.get(k) is not False for k in ('wall_clock_limit_enabled', 'automatic_retry', 'automatic_stage_c'))
            or r.get('serialized_evaluation') is not True or r.get('shared_cpu_pools') is not True):
        raise ValueError('Explicit, unchanged-scope four-arm dispatch authorization required.')
    m = read(suite / 'manifest.json')
    validate_scope(m)
    if r['original_resource_contract'] != m['resource_contract']:
        raise ValueError('CPU/GPU allocation changed.')
    check_hashes(suite, {'manifest.json': r['manifest_sha256'], 'control.json': r['control_sha256']})
    check_hashes(ROOT, r['code_fingerprint'])
    check_hashes(ROOT, m['code_fingerprint'])
    if file_sha(r['source_archive']['path']) != r['source_archive']['sha256']:
        raise ValueError('Administrative source archive changed.')
    return r, m


class Scheduler(PinnedProcess):
    """r7 entered through --authorization, unlike its scientific children."""
    def __init__(self, pid, suite):
        self.pid = int(pid)
        self.fd = pidfd_open(self.pid)
        try:
            args = (Path('/proc') / str(self.pid) / 'cmdline').read_bytes().decode().split('\0')
            script = str(ROOT / 'onpolicy/scripts/train/continue_stage2_resource_rl_v5_unlimited.py')
            if (script not in args or 'handoff' not in args or '--authorization' not in args
                    or args[args.index('--authorization') + 1] != str(suite / 'authorization.json')):
                raise ValueError('The scheduler does not belong to the exact r7 authorization.')
            self.start_ticks = self.info()['start_ticks']
        except BaseException:
            os.close(self.fd)
            raise


def pin_worker(suite, arm, parent_pid):
    state = read(suite / 'workers' / arm / 'run_status.json')
    process = PinnedProcess(state['pid'], suite / 'manifest.json', WORKER.name,
                            phase='train', parent_pid=parent_pid)
    args = (Path('/proc') / str(process.pid) / 'cmdline').read_bytes().decode().split('\0')
    if '--arm' not in args or args[args.index('--arm') + 1] != arm:
        process.close()
        raise ValueError('Wrong retained arm process.')
    return process


def memory_gate(reports, gpu, available_bytes):
    required = sum(reports[a]['peak_reserved_bytes'] for a in ARMS) + 4 * GIB
    additional = sum(reports[a]['peak_reserved_bytes'] for a in ('E2', 'E3')) + 2 * GIB
    if (gpu['uuid'] != 'GPU-744c1334-98c8-5318-e799-7ad15eea1fbf'
            or required > .8 * gpu['total_bytes']
            or additional > gpu['free_bytes'] - 4 * GIB or available_bytes < 64 * GIB):
        raise ValueError('Four-arm GPU/host-memory headroom is insufficient.')
    return dict(passed=True, four_arm_peak_reserved_plus_context_bytes=required,
        additional_required_bytes=additional, host_available_bytes=available_bytes, gpu=gpu,
        historical_peak_is_not_a_guarantee=True)


def preflight(path):
    r, m = validate_request(path)
    suite = Path(r['suite'])
    state = validate_pending(suite)
    if (service_value('MainPID', PARENT_UNIT) != str(r['original_controller_pid'])
            or state['pid'] != r['original_controller_pid']
            or service_value('RuntimeMaxUSec', PARENT_UNIT) != 'infinity'):
        raise ValueError('The original unlimited controller identity changed.')
    scheduler = Scheduler(state['pid'], suite)
    retained = {}
    try:
        if scheduler.info()['state'] in ('T', 't', 'Z', 'X'):
            raise ValueError('The old scheduler is not running normally.')
        for arm in ('E0', 'E1'):
            retained[arm] = pin_worker(suite, arm, scheduler.pid)
        raw = subprocess.check_output(['nvidia-smi', '-i', '0',
            '--query-gpu=uuid,memory.total,memory.free,utilization.gpu',
            '--format=csv,noheader,nounits'], text=True, timeout=15).strip().split(',')
        gpu = dict(uuid=raw[0].strip(), total_bytes=int(raw[1]) * 1024**2,
                   free_bytes=int(raw[2]) * 1024**2, utilization_percent=int(raw[3]))
        info = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
        available = int(info['MemAvailable'].split()[0]) * 1024
        proof = memory_gate({a: read(suite / 'engineering' / a / 'report.json') for a in ARMS}, gpu, available)
        proof.update(checked_unix=time.time(), scheduler_pid=scheduler.pid,
            scheduler_start_ticks=scheduler.start_ticks,
            retained_workers={a: dict(pid=p.pid, start_ticks=p.start_ticks) for a, p in retained.items()})
        return proof
    finally:
        scheduler.close()
        for process in retained.values():
            process.close()


def claim_logs(suite):
    """The original queue also uses open('x'); claims survive all error paths."""
    logs = {}
    try:
        for arm in ('E2', 'E3'):
            logs[arm] = (suite / 'logs' / f'train_{arm}.log').open('x')
    except BaseException:
        for handle in logs.values():
            handle.close()
        raise
    return logs


def recovery(path):
    """ExecStopPost: fail closed, then release the old scheduler; never retry."""
    root, r = path.resolve().parent, read(path)
    active = root / 'checks/active_handoff.json'
    if not active.exists() or (root / 'checks/retired_scheduler.json').exists():
        return
    suite, proof = Path(r['suite']), read(active)
    if (r.get('version') != VERSION or r.get('parent_unit') != PARENT_UNIT
            or file_sha(suite / 'control.json') != r['control_sha256']
            or service_value('MainPID', PARENT_UNIT) != str(proof['scheduler_pid'])):
        raise ValueError('Refusing recovery of an unrelated scheduler.')
    # Once either arm has been claimed, a failure stops future rounds. The
    # original exclusive logs additionally prevent any duplicate E2/E3 launch.
    claimed = any((suite / 'logs' / f'train_{a}.log').exists() for a in ('E2', 'E3'))
    if claimed:
        atomic_json(suite / 'halt_after_current_round.json', dict(failed_phase='four_arm_controller',
            no_retry=True, safe_boundary_stop=True, authorization=str(path)))
    scheduler = Scheduler(proof['scheduler_pid'], suite)
    try:
        if scheduler.start_ticks != proof['scheduler_start_ticks']:
            raise ValueError('Scheduler start identity changed.')
        if scheduler.info()['state'] in ('T', 't'):
            scheduler.send(signal.SIGCONT)
        atomic_json(root / 'checks/recovery.json', dict(old_scheduler_released=True,
            new_rounds_halted=claimed, automatic_retry=False, updated_unix=time.time()))
    finally:
        scheduler.close()


class FourArmController(UnlimitedController):
    def __init__(self, path):
        self.request_path = path.resolve()
        self.request, _ = validate_request(self.request_path)
        self.admin_root = self.request_path.parent
        super().__init__(Path(self.request['suite']) / 'manifest.json')
        self.records = read(self.root / 'run_status.json')['worker_exit_records']
        self.retained, self.spawned, self.logs = {}, {}, {}
        self.scheduler = None
        self.has_control = False
        self.phase = 'stage_b_training_four_arm'

    def status(self, **extra):
        if not self.has_control:
            atomic_json(self.admin_root / 'run_status.json', dict(status=extra.pop('status', 'running'),
                phase=self.phase, pid=os.getpid(), updated_unix=time.time(),
                original_run_not_taken_over=True, original_status=str(self.root / 'run_status.json'),
                automatic_retry=False, scientific_success_confirmed=False, **extra))
            return
        super().status(effective_max_concurrent_trainers=4, shared_cpu_pools=True,
            concurrency_authorization=str(self.request_path),
            original_scheduler_paused=not (self.admin_root / 'checks/retired_scheduler.json').exists(),
            original_scheduler_pid=self.request['original_controller_pid'], **extra)
        atomic_json(self.admin_root / 'run_status.json', read(self.root / 'run_status.json'))

    def launch_new(self, arm):
        if arm not in ('E2', 'E3') or arm in self.spawned:
            raise ValueError('Only one initial launch of E2/E3 is authorized.')
        slot = SLOTS[arm]
        cpu = self.m['resource_contract']['trainer_slots'][slot]
        command = ['taskset', '-c', cpu, sys.executable, '-u', str(WORKER),
            '--manifest', str(self.path), '--phase', 'train', '--arm', arm, '--slot', str(slot)]
        self.spawned[arm] = subprocess.Popen(command, cwd=ROOT, stdout=self.logs[arm], stderr=subprocess.STDOUT)
        print(json.dumps(dict(event='worker_started', arm=arm, pid=self.spawned[arm].pid,
            cpu=cpu, command=command, scientific_worker_unchanged=True)), flush=True)

    def retire_scheduler(self):
        # E0/E1 must have exited before r7's own SIGTERM cleanup is allowed.
        if any(p.info()['state'] != 'Z' for p in self.retained.values()):
            raise RuntimeError('Cannot retire the old scheduler while its workers are alive.')
        self.scheduler.send(signal.SIGTERM)
        self.scheduler.send(signal.SIGCONT)
        for _ in range(100):
            if service_value('MainPID', PARENT_UNIT) == '0':
                atomic_json(self.admin_root / 'checks/retired_scheduler.json', dict(
                    passed=True, retained_workers_finished_before_scheduler_stop=True,
                    scheduler_pid=self.scheduler.pid, updated_unix=time.time()))
                return
            time.sleep(.2)
        raise RuntimeError('Old scheduler has not retired.')

    def run_four(self):
        if (os.environ.get('CUDA_VISIBLE_DEVICES') != '0'
                or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95'))
                or service_value('MainPID', UNIT) != str(os.getpid())
                or service_value('RuntimeMaxUSec', UNIT) != 'infinity'):
            raise ValueError('Exact unlimited r8 service on GPU0/original CPU half required.')
        os.sched_setaffinity(0, cpus(self.m['resource_contract']['monitor_cpus']))
        with (self.admin_root / 'started.json').open('x') as handle:
            json.dump(dict(pid=os.getpid(), started_unix=time.time()), handle)

        def stop(signum, frame):
            raise KeyboardInterrupt(f'Operator/service signal {signum}')

        signal.signal(signal.SIGTERM, stop)
        try:
            proof = preflight(self.request_path)
            atomic_json(self.admin_root / 'checks/preflight.json', proof)
            self.scheduler = Scheduler(self.request['original_controller_pid'], self.root)
            for arm in ('E0', 'E1'):
                self.retained[arm] = pin_worker(self.root, arm, self.scheduler.pid)
            # Publish exact recovery identities before SIGSTOP to close the
            # interruption window between pausing and writing a recovery marker.
            atomic_json(self.admin_root / 'checks/active_handoff.json', dict(
                scheduler_pid=self.scheduler.pid, scheduler_start_ticks=self.scheduler.start_ticks,
                retained_workers=proof['retained_workers'], updated_unix=time.time()))
            self.scheduler.send(signal.SIGSTOP)
            for _ in range(50):
                if self.scheduler.info()['state'] in ('T', 't'):
                    break
                time.sleep(.05)
            else:
                raise RuntimeError('Old scheduler did not pause.')
            self.has_control = True
            self.logs = claim_logs(self.root)
            atomic_json(self.root / 'concurrency_override.json', dict(version=VERSION,
                authorization=str(self.request_path), authorization_sha256=file_sha(self.request_path),
                max_concurrent_trainers=4, slots=SLOTS, original_manifest_unchanged=True,
                authoritative_status=str(self.admin_root / 'run_status.json')))
            for arm in ('E2', 'E3'):
                self.launch_new(arm)
            atomic_json(self.admin_root / 'checks/activated.json', dict(passed=True,
                E0_E1_restarted=False, E2_E3_launched=True, scientific_worker_unchanged=True,
                retained_workers=proof['retained_workers'],
                new_workers={a: p.pid for a, p in self.spawned.items()}, updated_unix=time.time()))
            completed, failed, last = set(), False, 0.
            while len(completed) != 4:
                for arm in ARMS:
                    if arm in completed:
                        continue
                    if arm in self.retained:
                        info = self.retained[arm].info()
                        code = os.waitstatus_to_exitcode(info['exit_wait_status']) if info['state'] == 'Z' else None
                    else:
                        code = self.spawned[arm].poll()
                    if code is not None:
                        state_path = self.root / 'workers' / arm / 'run_status.json'
                        state = read(state_path) if state_path.exists() else {}
                        terminal_ok = code == 0 and state.get('status') in ('completed', 'paused_for_kl')
                        self.records.append(dict(phase='train', arm=arm, exit_code=code,
                            terminal_status=state.get('status'), completed_unix=time.time(),
                            retained_original_process=arm in self.retained))
                        completed.add(arm)
                        if not terminal_ok:
                            failed = True
                            atomic_json(self.root / 'halt_after_current_round.json', dict(
                                failed_phase='train', arm=arm, no_retry=True, safe_boundary_stop=True))
                if time.time() - last >= 30:
                    self.status(status='draining_after_failure' if failed else 'running')
                    analyze(self.root, self.m)
                    last = time.time()
                if len(completed) != 4:
                    time.sleep(2)
            self.retire_scheduler()
            analyze(self.root, self.m)
            paused = any(read(self.root / a / 'result.json').get('status') == 'paused_for_kl'
                         for a in ARMS if (self.root / a / 'result.json').exists())
            outcome = 'failed' if failed else 'completed_with_paused_arm' if paused else 'completed'
            self.phase = 'stage_b_' + outcome
            self.status(status=outcome, optional_stage_c='requires_new_user_authorization')
            return 1 if failed else 0
        except BaseException as exc:
            self.phase = 'four_arm_dispatch_failed'
            self.status(status='failed', error=str(exc), traceback=traceback.format_exc())
            print(traceback.format_exc(), flush=True)
            recovery(self.request_path)
            return 1
        finally:
            for handle in self.logs.values():
                handle.close()
            for process in self.retained.values():
                process.close()
            if self.scheduler is not None:
                self.scheduler.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest='mode', required=True)
    maker = modes.add_parser('authorize')
    maker.add_argument('--suite', type=Path, required=True)
    maker.add_argument('--output', type=Path, required=True)
    for name in ('preflight', 'run', 'recover'):
        item = modes.add_parser(name)
        item.add_argument('--authorization', type=Path, required=True)
    args = parser.parse_args()
    if args.mode == 'authorize':
        print(authorize(args.suite, args.output))
    elif args.mode == 'preflight':
        print(json.dumps(preflight(args.authorization), indent=2))
    elif args.mode == 'recover':
        recovery(args.authorization)
    else:
        sys.exit(FourArmController(args.authorization).run_four())
