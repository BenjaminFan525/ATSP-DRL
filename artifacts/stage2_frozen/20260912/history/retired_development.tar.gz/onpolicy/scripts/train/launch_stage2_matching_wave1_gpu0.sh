#!/usr/bin/env bash
set -euo pipefail

# One-command five-arm Stage2 supervised screen on GPU0.  Each cgroup owns
# complete SMT sibling pairs; one persistent validator is shared by all arms.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARE="${ROOT_DIR}/onpolicy/scripts/train/prepare_stage2_matching_wave1.py"
TRIAL_RUNNER="${ROOT_DIR}/onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
EVALUATOR="${ROOT_DIR}/onpolicy/scripts/train/shared_hkbz_evaluator.py"

RUN_TAG="${RUN_TAG:-stage2_matching_wave1_20260902_r1}"
SUITE_DIR="${SUITE_DIR:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT_PREFIX="${UNIT_PREFIX:-hkbz-s2-match-20260902-r1}"
VALIDATION_DIR="${VALIDATION_DIR:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-12}"
DRY_RUN="${DRY_RUN:-0}"

METHODS=(
  A0_sequential_categorical
  A1_global_categorical
  A2_final_matching
  A3_matching_margin
  A4_resource_adapter
)
TRAIN_CPUS=(
  0-11,72-83
  12-23,84-95
  24-35,96-107
  36-47,108-119
  48-59,120-131
)
VAL_CPUS="60-69,132-141"
MONITOR_CPUS="70-71,142-143"

manifest_path() { echo "${SUITE_DIR}/commands/matching_wave1.json"; }
trainer_unit() { echo "${UNIT_PREFIX}-g0l$1"; }
evaluator_unit() { echo "${UNIT_PREFIX}-g0eval"; }
monitor_unit() { echo "${UNIT_PREFIX}-monitor"; }

numa_for_lane() {
  if (( $1 < 3 )); then echo 0; else echo 1; fi
}

verify_inputs() {
  local path
  for path in "${PYTHON}" "${PREPARE}" "${TRIAL_RUNNER}" \
    "${EVALUATOR}" "${VALIDATION_DIR}"; do
    [[ -e "${path}" ]] || { echo "[Error] missing ${path}" >&2; exit 1; }
  done
  [[ "$(nproc)" -eq 144 ]] || {
    echo "[Error] expected 144 logical CPUs, got $(nproc)" >&2; exit 1;
  }
}

verify_cpu_partition() {
  "${PYTHON}" - "${TRAIN_CPUS[@]}" "${VAL_CPUS}" "${MONITOR_CPUS}" <<'PY'
import os, sys
def expand(spec):
    values=set()
    for part in spec.split(','):
        lo, sep, hi=part.partition('-')
        values.update(range(int(lo), int(hi)+1) if sep else (int(lo),))
    return values
groups=[expand(value) for value in sys.argv[1:]]
widths=[24,24,24,24,24,20,4]
if [len(group) for group in groups] != widths:
    raise SystemExit(f'CPU widths mismatch: {[len(g) for g in groups]}')
union=set()
for index, group in enumerate(groups):
    if union & group:
        raise SystemExit(f'CPU overlap in group {index}: {sorted(union & group)}')
    union |= group
    for cpu in group:
        sibling=cpu+72 if cpu < 72 else cpu-72
        if sibling not in group:
            raise SystemExit(f'group {index} splits SMT siblings {cpu}/{sibling}')
if union != set(range(144)):
    raise SystemExit(f'CPU partition does not cover host: missing={sorted(set(range(144))-union)}')
print('[CPU] 5x24 trainer + 20 shared validator + 4 OS/monitor = 144 logical CPUs')
PY
}

verify_gpu0() {
  local row busy
  row="$(nvidia-smi --id=0 --query-gpu=index,name,memory.total --format=csv,noheader,nounits)"
  [[ "${row}" == 0,* ]] && [[ "${row}" == *"A800 80GB"* ]] || {
    echo "[Error] GPU0 hardware differs from calibration: ${row}" >&2; exit 1;
  }
  busy="$(nvidia-smi --id=0 --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null || true)"
  [[ -z "${busy//[[:space:]]/}" ]] || {
    echo "[Error] GPU0 has active compute PIDs: ${busy}" >&2; exit 1;
  }
}

require_fresh_run() {
  [[ ! -e "${SUITE_DIR}" ]] || {
    echo "[Error] suite already exists: ${SUITE_DIR}" >&2; exit 1;
  }
  local lane unit state
  for lane in 0 1 2 3 4; do
    unit="$(trainer_unit "${lane}").service"
    state="$(systemctl --user show "${unit}" -p LoadState --value 2>/dev/null || true)"
    [[ -z "${state}" || "${state}" == not-found ]] || {
      echo "[Error] systemd unit already exists: ${unit}" >&2; exit 1;
    }
  done
  for unit in "$(evaluator_unit).service" "$(monitor_unit).service"; do
    state="$(systemctl --user show "${unit}" -p LoadState --value 2>/dev/null || true)"
    [[ -z "${state}" || "${state}" == not-found ]] || {
      echo "[Error] systemd unit already exists: ${unit}" >&2; exit 1;
    }
  done
}

prepare_manifest() {
  mkdir -p "${SUITE_DIR}"/{commands,records,service_logs,shared_evaluator,hardware}
  "${PYTHON}" "${PREPARE}" --run-tag "${RUN_TAG}" \
    --suite-dir "${SUITE_DIR}" --output "$(manifest_path)"
}

launch_evaluator() {
  local unit socket log
  unit="$(evaluator_unit)"
  socket="/tmp/${unit}.sock"
  log="${SUITE_DIR}/service_logs/${unit}.log"
  [[ ! -e "${socket}" ]] || { echo "[Error] stale socket ${socket}" >&2; exit 1; }
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv=MPLCONFIGDIR=/tmp/hkbz-mpl \
    --property=Type=exec --property=Restart=no --property=KillMode=control-group \
    --property=TimeoutStopSec=180 --property=LimitNOFILE=65536 \
    --property="AllowedCPUs=${VAL_CPUS}" --property="CPUAffinity=${VAL_CPUS}" \
    --property=NUMAPolicy=bind --property=NUMAMask=1 \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    "${PYTHON}" -u "${EVALUATOR}" \
      --source-command-json "$(manifest_path)" --socket-path "${socket}" \
      --cpu-pool "${VAL_CPUS}" \
      --run-dir "${SUITE_DIR}/shared_evaluator/gpu0" \
      --eval-dataset-dir "${VALIDATION_DIR}" --max-eval-cases 60 \
      --cuda-memory-fraction 0.04 --eval-partition-seed 20260811 \
      --eval-partition-stratify-by distribution >/dev/null
  echo "${socket}"
}

wait_evaluator() {
  local socket="$1" deadline unit
  unit="$(evaluator_unit)"
  deadline=$((SECONDS+1200))
  while (( SECONDS < deadline )); do
    [[ "$(systemctl --user is-active "${unit}.service" 2>/dev/null || true)" == active ]] || {
      echo "[Error] evaluator stopped before ready" >&2; return 1;
    }
    if [[ -S "${socket}" ]] && "${PYTHON}" - "${socket}" <<'PY'
import sys
from onpolicy.utils.shared_eval import SharedEvalClient
r=SharedEvalClient(sys.argv[1], timeout_seconds=5).ping()
raise SystemExit(0 if int(r.get('worker_count', -1)) == 20 else 1)
PY
    then
      echo "[Ready] ${unit}.service workers=20 CPUs=${VAL_CPUS}" >&2
      return 0
    fi
    sleep 2
  done
  echo "[Error] evaluator readiness timeout" >&2
  return 1
}

launch_trainer() {
  local lane="$1" socket="$2" method cpus node unit log delay
  method="${METHODS[${lane}]}"
  cpus="${TRAIN_CPUS[${lane}]}"
  node="$(numa_for_lane "${lane}")"
  unit="$(trainer_unit "${lane}")"
  log="${SUITE_DIR}/service_logs/${unit}.log"
  delay=$((lane*START_STAGGER_SECONDS))
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv=MPLCONFIGDIR=/tmp/hkbz-mpl \
    --property=Type=exec --property=Restart=no --property=KillMode=control-group \
    --property=TimeoutStopSec=180 --property=LimitNOFILE=65536 \
    --property="AllowedCPUs=${cpus}" --property="CPUAffinity=${cpus}" \
    --property=NUMAPolicy=bind --property="NUMAMask=${node}" \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "$(manifest_path)" --command-key "${method}" \
      --gpu 0 --cpu-set "${cpus}" \
      --shared-eval-socket "${socket}" --shared-eval-cpu-set "${VAL_CPUS}" \
      --eval-workers 20 --start-delay-seconds "${delay}" \
      --record "${SUITE_DIR}/records/g0l${lane}.json" >/dev/null
  echo "[Launch] ${unit}.service ${method} CPUs=${cpus} NUMA=${node} delay=${delay}s"
}

stop_started_units() {
  local lane
  systemctl --user stop "$(monitor_unit).service" >/dev/null 2>&1 || true
  for lane in 0 1 2 3 4; do
    systemctl --user stop "$(trainer_unit "${lane}").service" >/dev/null 2>&1 || true
  done
  systemctl --user stop "$(evaluator_unit).service" >/dev/null 2>&1 || true
}

monitor_main() {
  local output active lane state gpu_mem gpu_util mem_available swap_used
  output="${SUITE_DIR}/hardware/runtime_usage.csv"
  echo 'unix_time,gpu0_memory_used_mib,gpu0_util_percent,mem_available_mib,swap_used_mib,active_trainers' >"${output}"
  while true; do
    active=0
    for lane in 0 1 2 3 4; do
      state="$(systemctl --user is-active "$(trainer_unit "${lane}").service" 2>/dev/null || true)"
      [[ "${state}" == active || "${state}" == activating ]] && active=$((active+1))
    done
    gpu_mem="$(nvidia-smi --id=0 --query-gpu=memory.used --format=csv,noheader,nounits | tr -d ' ')"
    gpu_util="$(nvidia-smi --id=0 --query-gpu=utilization.gpu --format=csv,noheader,nounits | tr -d ' ')"
    mem_available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap_used="$(awk '/SwapTotal:/ {t=$2} /SwapFree:/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)"
    echo "$(date +%s),${gpu_mem},${gpu_util},${mem_available},${swap_used},${active}" >>"${output}"
    if (( active == 0 )); then
      systemctl --user stop "$(evaluator_unit).service" >/dev/null 2>&1 || true
      break
    fi
    sleep 30
  done
}

launch_monitor() {
  local unit log
  unit="$(monitor_unit)"
  log="${SUITE_DIR}/service_logs/${unit}.log"
  systemd-run --user --unit="${unit}" --same-dir \
    --setenv=HKBZ_STAGE2_MATCH_MONITOR=1 --setenv="RUN_TAG=${RUN_TAG}" \
    --setenv="SUITE_DIR=${SUITE_DIR}" --setenv="UNIT_PREFIX=${UNIT_PREFIX}" \
    --property=Type=exec --property=Restart=no --property=KillMode=control-group \
    --property="AllowedCPUs=${MONITOR_CPUS}" \
    --property="CPUAffinity=${MONITOR_CPUS}" \
    --property=NUMAPolicy=bind --property=NUMAMask=1 \
    --property="StandardOutput=append:${log}" \
    --property="StandardError=append:${log}" \
    /bin/bash "${BASH_SOURCE[0]}" >/dev/null
}

verify_services() {
  local lane unit state
  sleep 3
  for lane in 0 1 2 3 4; do
    unit="$(trainer_unit "${lane}")"
    state="$(systemctl --user is-active "${unit}.service" 2>/dev/null || true)"
    [[ "${state}" == active || "${state}" == activating ]] || {
      echo "[Error] ${unit}.service failed initial health check (${state})" >&2
      return 1
    }
  done
}

main() {
  local socket lane
  verify_inputs
  verify_cpu_partition
  require_fresh_run
  prepare_manifest
  if [[ "${DRY_RUN}" == 1 ]]; then
    echo "[DryRun] manifest=$(manifest_path)"
    echo "[DryRun] methods=${METHODS[*]}"
    return 0
  fi
  verify_gpu0
  trap stop_started_units ERR INT TERM
  socket="$(launch_evaluator)"
  wait_evaluator "${socket}"
  for lane in 0 1 2 3 4; do launch_trainer "${lane}" "${socket}"; done
  verify_services
  launch_monitor
  trap - ERR INT TERM
  echo "[Started] Stage2 matching Wave1 on GPU0"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] CPU=5x24 isolated trainers + 20 shared validator + 4 reserved"
}

if [[ "${HKBZ_STAGE2_MATCH_MONITOR:-0}" == 1 ]]; then
  monitor_main
else
  main "$@"
fi
