#!/usr/bin/env bash
set -euo pipefail

# Stage2 Wave1: a three-lane canary followed by six full-data trust/critic
# arms.  Each GPU owns three disjoint physical-core trainer pools and one
# persistent shared validation pool.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARER="${ROOT_DIR}/onpolicy/scripts/train/prepare_stage2_adaptive_trust.py"
TRIAL_RUNNER="${ROOT_DIR}/onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
EVALUATOR="${ROOT_DIR}/onpolicy/scripts/train/shared_hkbz_evaluator.py"

RUN_TAG="${RUN_TAG:-stage2_adaptive_trust_20260830_r1}"
SUITE_DIR="${SUITE_DIR:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT="${UNIT:-hkbz-s2-adaptive-trust-20260830-r1}"
SOURCE_MANIFEST="${SOURCE_MANIFEST:-${ROOT_DIR}/result/hkbz_train_logs/stage2_structured_credit_20260830_r3/commands/wave_b.json}"
BC_SELECTION="${BC_SELECTION:-${ROOT_DIR}/result/hkbz_train_logs/stage2_structured_credit_20260830_r3/analysis/wave_a_bc_selection.json}"
BC_CHECKPOINT="${BC_CHECKPOINT:-${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo/stage2_structured_credit_20260830_r3_waveA_B0_categorical_control_seed1/run1/models/checkpoint_DeviceBC.pt}"
PAIRED_BASELINE="${PAIRED_BASELINE:-${ROOT_DIR}/result/hkbz_train_logs/stage2_structured_credit_20260830_r3/artifacts/train600_iga1800_baseline.json}"
MATCHED_IGA="${MATCHED_IGA:-${ROOT_DIR}/result/hkbz_train_logs/stage2_matched_iga_tune60_20260827_r1/analysis/matched_iga_comparison.json}"
VALIDATION_DIR="${VALIDATION_DIR:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
CANARY_MANIFEST="${SUITE_DIR}/commands/canary.json"
WAVE_MANIFEST="${SUITE_DIR}/commands/wave1.json"
ANALYSIS_OUTPUT="${SUITE_DIR}/analysis/wave1_selection.json"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-15}"
GPU_MODE="${GPU_MODE:-dual}"
CANARY_EVIDENCE_RUN_TAG="${CANARY_EVIDENCE_RUN_TAG:-}"

TRAIN_CPUS=(
  "0-9,72-81" "10-19,82-91" "20-29,92-101"
  "36-45,108-117" "46-55,118-127" "56-65,128-137"
)
VAL_CPUS=("30-35,102-107" "66-71,138-143")
EVALUATOR_PIDS=()
EVALUATOR_SOCKETS=()
TRAINER_PIDS=()
MONITOR_PID=""

stop_children() {
  local pid
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}"; do
    [[ -n "${pid}" ]] || continue
    kill "${pid}" >/dev/null 2>&1 || true
  done
  [[ -z "${MONITOR_PID}" ]] || kill "${MONITOR_PID}" >/dev/null 2>&1 || true
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}" "${MONITOR_PID}"; do
    [[ -n "${pid}" ]] || continue
    wait "${pid}" >/dev/null 2>&1 || true
  done
  TRAINER_PIDS=()
  EVALUATOR_PIDS=()
  EVALUATOR_SOCKETS=()
  MONITOR_PID=""
}

controller_exit() {
  local status=$?
  stop_children
  if (( status != 0 )); then
    "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; p=Path(sys.argv[1]); old=json.loads(p.read_text()) if p.exists() else {}; old.update({"status":"failed","failed_unix_time":time.time(),"exit_status":int(sys.argv[2])}); p.write_text(json.dumps(old,indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json" "${status}" || true
  fi
}

verify_cpu_topology() {
  "${PYTHON}" - "${TRAIN_CPUS[@]}" "${VAL_CPUS[@]}" <<'PY'
import os, sys
def expand(spec):
    result=set()
    for part in spec.split(','):
        lo, sep, hi=part.partition('-')
        result.update(range(int(lo), int(hi)+1) if sep else [int(lo)])
    return result
if os.cpu_count() != 144:
    raise SystemExit(f'expected 144 logical CPUs, got {os.cpu_count()}')
groups=[expand(spec) for spec in sys.argv[1:]]
trainers, evaluators=groups[:6], groups[6:]
for gpu in range(2):
    local=trainers[gpu*3:(gpu+1)*3]+[evaluators[gpu]]
    if [len(item) for item in local] != [20,20,20,12]:
        raise SystemExit(f'GPU{gpu} CPU widths are invalid')
    if sum(map(len, local)) != len(set().union(*local)):
        raise SystemExit(f'GPU{gpu} CPU sets overlap')
for group in groups:
    for cpu in group:
        sibling=cpu+72 if cpu < 72 else cpu-72
        if sibling not in group:
            raise SystemExit(f'CPU set splits SMT siblings {cpu}/{sibling}')
print('[CPU] verified two NUMA-local 3x20+12 logical-CPU partitions')
PY
}

trainer_cpu_set() {
  local gpu="$1" lane="$2" index
  [[ "${gpu}" =~ ^[01]$ && "${lane}" =~ ^[0-2]$ ]] || return 2
  index=$((gpu * 3 + lane))
  printf '%s\n' "${TRAIN_CPUS[$index]}"
}

preparer_args() {
  PREPARER_ARGS=(
    --run-tag "${RUN_TAG}" --source-manifest "${SOURCE_MANIFEST}"
    --bc-selection "${BC_SELECTION}" --bc-checkpoint "${BC_CHECKPOINT}"
    --paired-baseline "${PAIRED_BASELINE}" --python "${PYTHON}"
    --canary-output "${CANARY_MANIFEST}" --wave-output "${WAVE_MANIFEST}"
    --analysis-output "${ANALYSIS_OUTPUT}" --matched-iga "${MATCHED_IGA}"
  )
}

write_status() {
  local status="$1" phase="$2"
  "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; p=Path(sys.argv[1]); old=json.loads(p.read_text()) if p.exists() else {}; old.update({"status":sys.argv[2],"phase":sys.argv[3],"runtime_gpu_mode":sys.argv[4],"updated_unix_time":time.time()}); p.write_text(json.dumps(old,indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json" "${status}" "${phase}" "${GPU_MODE}"
}

monitor_phase() {
  local phase="$1"
  local output="${SUITE_DIR}/hardware/${phase}_usage.csv"
  mkdir -p "${SUITE_DIR}/hardware"
  echo "unix_time,gpu0_mem_mib,gpu0_util,gpu1_mem_mib,gpu1_util,mem_available_mib,swap_used_mib" >"${output}"
  while true; do
    local rows g0m g0u g1m g1u available swap
    rows="$(nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader,nounits)"
    g0m="$(sed -n '1{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g0u="$(sed -n '1{s/.*,//;s/ //g;p}' <<<"${rows}")"
    g1m="$(sed -n '2{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g1u="$(sed -n '2{s/.*,//;s/ //g;p}' <<<"${rows}")"
    available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap="$(awk '/SwapTotal:/ {t=$2} /SwapFree:/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)"
    echo "$(date +%s),${g0m},${g0u},${g1m},${g1u},${available},${swap}" >>"${output}"
    sleep 30
  done
}

start_evaluator() {
  local phase="$1" manifest="$2" gpu="$3"
  local eval_cases=60
  [[ "${phase}" == canary ]] && eval_cases=12
  local cpus="${VAL_CPUS[$gpu]}" socket="/tmp/${UNIT}-${phase}-g${gpu}.sock"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}_eval.log"
  rm -f -- "${socket}"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${EVALUATOR}" \
      --source-command-json "${manifest}" --socket-path "${socket}" \
      --cpu-pool "${cpus}" \
      --run-dir "${SUITE_DIR}/shared_evaluator/${phase}_g${gpu}" \
      --eval-dataset-dir "${VALIDATION_DIR}" --max-eval-cases "${eval_cases}" \
      --cuda-memory-fraction 0.08 --eval-partition-seed 20260811 \
      --eval-partition-stratify-by distribution >"${log}" 2>&1 &
  EVALUATOR_PIDS[$gpu]="$!"
  local deadline=$((SECONDS + 1200))
  while (( SECONDS < deadline )); do
    kill -0 "${EVALUATOR_PIDS[$gpu]}" >/dev/null 2>&1 || {
      echo "[Error] ${phase} GPU${gpu} evaluator exited" >&2; return 1;
    }
    if [[ -S "${socket}" ]] && "${PYTHON}" - "${socket}" <<'PY'
import sys
from onpolicy.utils.shared_eval import SharedEvalClient
reply=SharedEvalClient(sys.argv[1], timeout_seconds=5).ping()
raise SystemExit(0 if int(reply.get('worker_count', -1)) == 12 else 1)
PY
    then
      EVALUATOR_SOCKETS[$gpu]="${socket}"
      echo "[SharedEval] ${phase} GPU${gpu} ready"
      return 0
    fi
    sleep 2
  done
  echo "[Error] ${phase} GPU${gpu} evaluator readiness timeout" >&2
  return 1
}

launch_trial() {
  local phase="$1" manifest="$2" key="$3" gpu="$4" lane="$5" delay="$6"
  local cpus log record
  cpus="$(trainer_cpu_set "${gpu}" "${lane}")"
  log="${SUITE_DIR}/service_logs/${phase}_g${gpu}l${lane}_${key}.log"
  record="${SUITE_DIR}/records/${phase}_${key}.json"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "${manifest}" --command-key "${key}" \
      --gpu "${gpu}" --cpu-set "${cpus}" \
      --shared-eval-socket "${EVALUATOR_SOCKETS[$gpu]}" \
      --shared-eval-cpu-set "${VAL_CPUS[$gpu]}" --eval-workers 12 \
      --start-delay-seconds "${delay}" --record "${record}" \
      >"${log}" 2>&1 &
  LAST_LAUNCHED_PID="$!"
  TRAINER_PIDS+=("${LAST_LAUNCHED_PID}")
  echo "[Launch] ${phase} GPU${gpu} lane=${lane} ${key} CPUs=${cpus} pid=${LAST_LAUNCHED_PID}"
}

run_three_lane_canary() {
  local keys=(
    C_T0_backtrack_no_bc
    C_T2_backtrack_adaptive_soft_bc
    C_T5_adaptive_actor_only_paired
  )
  local lane failed=0 pids=() canary_gpu=0
  if [[ "${GPU_MODE}" == gpu1_sequential || "${GPU_MODE}" == gpu1_only \
        || "${GPU_MODE}" == dual_shared_gpu0 ]]; then
    canary_gpu=1
  fi
  start_evaluator canary "${CANARY_MANIFEST}" "${canary_gpu}"
  monitor_phase canary & MONITOR_PID="$!"
  for lane in 0 1 2; do
    launch_trial canary "${CANARY_MANIFEST}" "${keys[$lane]}" "${canary_gpu}" "${lane}" "$((lane * START_STAGGER_SECONDS))"
    pids+=("${LAST_LAUNCHED_PID}")
  done
  for lane in 0 1 2; do wait "${pids[$lane]}" || failed=1; done
  stop_children
  (( failed == 0 )) || return 1
}

validate_canary_evidence() {
  local evidence_tag="$1"
  local results_root="${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo"
  local output="${SUITE_DIR}/canary_reuse.json"
  "${PYTHON}" - "${results_root}" "${evidence_tag}" "${output}" <<'PY'
import json
import sys
from pathlib import Path

root, tag, output = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
methods = (
    'T0_backtrack_no_bc',
    'T2_backtrack_adaptive_soft_bc',
    'T5_adaptive_actor_only_paired',
)
records = []
for method in methods:
    path = root / f'{tag}_wave1_{method}_seed1_canary' / 'run1' / 'run_status.json'
    if not path.is_file():
        raise SystemExit(f'missing canary evidence: {path}')
    status = json.loads(path.read_text(encoding='utf-8'))
    health = status.get('actor_update_health', {})
    record = {
        'method': method,
        'path': str(path.resolve()),
        'status': status.get('status'),
        'completion_rate': float(status.get('eval_completion_rate', 0.0)),
        'cycle_count': int(status.get('eval_cycle_count', -1)),
        'actor_step_completion_rate': float(health.get('step_completion_rate', 0.0)),
        'zero_update_shards': int(health.get('zero_update_shards', -1)),
        'backtrack_failed_groups': float(health.get('backtrack_failed_groups', 0.0)),
        'backtrack_groups': float(health.get('backtrack_groups', 0.0)),
        'peak_allocated_gib': float(status.get('peak_allocated_gib', 0.0)),
    }
    reasons = []
    if record['status'] != 'completed': reasons.append('not_completed')
    if record['completion_rate'] < 1.0: reasons.append('incomplete_evaluation')
    if record['cycle_count'] != 0: reasons.append('cycles')
    if record['actor_step_completion_rate'] < 0.90: reasons.append('low_actor_completion')
    if record['zero_update_shards'] != 0: reasons.append('zero_update_shards')
    # The 30-case layout canary has only 12 Actor groups, so one rolled-back
    # group is retained as a coarse-sample tolerance.  The formal analyzer
    # still enforces the preregistered <=5% failed-group gate.
    if record['backtrack_failed_groups'] > 1.0: reasons.append('too_many_failed_groups')
    record['gate_reasons'] = reasons
    records.append(record)
failed = [record for record in records if record['gate_reasons']]
payload = {
    'schema_version': 1,
    'source_run_tag': tag,
    'purpose': 'reuse_completed_production_layout_canary',
    'formal_backtrack_failed_group_fraction_gate': 0.05,
    'records': records,
    'accepted': not failed,
}
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
if failed:
    raise SystemExit('canary evidence failed: ' + json.dumps(failed))
print(f'[Canary] reused verified evidence from {tag}')
PY
}

gpu_is_idle() {
  local gpu="$1" uuid
  uuid="$(nvidia-smi -i "${gpu}" --query-gpu=uuid --format=csv,noheader,nounits)"
  ! nvidia-smi --query-compute-apps=gpu_uuid --format=csv,noheader,nounits \
    | grep -Fxq -- "${uuid}"
}

run_three_arm_batch() {
  local phase="$1" gpu="$2"; shift 2
  local keys=("$@") lane failed=0 pids=()
  [[ "${#keys[@]}" -eq 3 ]] || return 2
  start_evaluator "${phase}" "${WAVE_MANIFEST}" "${gpu}"
  monitor_phase "${phase}" & MONITOR_PID="$!"
  for lane in 0 1 2; do
    launch_trial "${phase}" "${WAVE_MANIFEST}" "${keys[$lane]}" "${gpu}" "${lane}" "$((lane * START_STAGGER_SECONDS))"
    pids+=("${LAST_LAUNCHED_PID}")
  done
  for lane in 0 1 2; do wait "${pids[$lane]}" || failed=1; done
  stop_children
  (( failed == 0 )) || return 1
}

run_wave1() {
  local keys=(
    T0_backtrack_no_bc T1_backtrack_fixed_soft_bc
    T2_backtrack_adaptive_soft_bc T3_adaptive_raw_critic_calibration
    T4_adaptive_paired_residual_critic T5_adaptive_actor_only_paired
  )
  local index gpu lane failed=0 pids=()
  if [[ "${GPU_MODE}" == gpu1_sequential || "${GPU_MODE}" == gpu1_only ]]; then
    write_status running wave1_batch1_gpu1
    run_three_arm_batch wave1_batch1 1 \
      "${keys[0]}" "${keys[1]}" "${keys[2]}"
    gpu=1
    if [[ "${GPU_MODE}" == gpu1_sequential ]] && gpu_is_idle 0; then gpu=0; fi
    write_status running "wave1_batch2_gpu${gpu}"
    run_three_arm_batch wave1_batch2 "${gpu}" \
      "${keys[3]}" "${keys[4]}" "${keys[5]}"
    return
  fi
  start_evaluator wave1 "${WAVE_MANIFEST}" 0
  start_evaluator wave1 "${WAVE_MANIFEST}" 1
  monitor_phase wave1 & MONITOR_PID="$!"
  for index in 0 1 2 3 4 5; do
    gpu=$((index / 3)); lane=$((index % 3))
    launch_trial wave1 "${WAVE_MANIFEST}" "${keys[$index]}" "${gpu}" "${lane}" "$((lane * START_STAGGER_SECONDS))"
    pids+=("${LAST_LAUNCHED_PID}")
  done
  for index in 0 1 2 3 4 5; do wait "${pids[$index]}" || failed=1; done
  stop_children
  (( failed == 0 )) || return 1
}

controller() {
  trap controller_exit EXIT
  trap 'exit 130' INT TERM
  mkdir -p "${SUITE_DIR}"/{commands,analysis,service_logs,records,shared_evaluator,hardware}
  preparer_args
  write_status running prepare
  "${PYTHON}" -u "${PREPARER}" --mode prepare "${PREPARER_ARGS[@]}" >"${SUITE_DIR}/service_logs/prepare.log" 2>&1
  if [[ -n "${CANARY_EVIDENCE_RUN_TAG}" ]]; then
    write_status running validate_reused_canary
    validate_canary_evidence "${CANARY_EVIDENCE_RUN_TAG}"
  else
    write_status running production_canary
    run_three_lane_canary
  fi
  write_status running wave1_adaptive_trust
  run_wave1
  write_status running wave1_analysis
  "${PYTHON}" -u "${PREPARER}" --mode analyze "${PREPARER_ARGS[@]}" >"${SUITE_DIR}/service_logs/analyze.log" 2>&1
  write_status completed wave1_analyzed
  echo "[Pipeline] Stage2 adaptive-trust Wave1 completed and exact checkpoint was bound"
}

validate_launcher_contract() {
  verify_cpu_topology
  "${PYTHON}" -m py_compile "${PREPARER}"
  bash -n "${BASH_SOURCE[0]}"
  echo "[Launcher] syntax and CPU topology contract passed"
}

initial_launch() {
  local required load_state compute_pids
  for required in "${PYTHON}" "${PREPARER}" "${TRIAL_RUNNER}" "${EVALUATOR}" \
    "${SOURCE_MANIFEST}" "${BC_SELECTION}" "${BC_CHECKPOINT}" \
    "${PAIRED_BASELINE}" "${MATCHED_IGA}" "${VALIDATION_DIR}" \
    /usr/bin/taskset /usr/bin/nvidia-smi; do
    [[ -e "${required}" ]] || { echo "[Error] missing input ${required}" >&2; exit 1; }
  done
  [[ "${RUN_TAG}" =~ ^[A-Za-z0-9._-]+$ && "${UNIT}" =~ ^[A-Za-z0-9._-]+$ ]] || {
    echo "[Error] RUN_TAG/UNIT is not path safe" >&2; exit 1;
  }
  verify_cpu_topology
  systemctl --user show-environment >/dev/null
  load_state="$(systemctl --user show "${UNIT}.service" --property=LoadState --value 2>/dev/null || true)"
  [[ -z "${load_state}" || "${load_state}" == not-found ]] || {
    echo "[Error] systemd unit already exists: ${UNIT}.service" >&2; exit 1;
  }
  [[ "$(nvidia-smi --query-gpu=index --format=csv,noheader,nounits | wc -l)" -ge 2 ]] || {
    echo "[Error] two CUDA GPUs are required" >&2; exit 1;
  }
  if [[ "${GPU_MODE}" == gpu1_sequential || "${GPU_MODE}" == gpu1_only ]]; then
    gpu_is_idle 1 || {
      echo "[Error] GPU1 must be idle for ${GPU_MODE} mode" >&2; exit 1;
    }
    if [[ "${GPU_MODE}" == gpu1_only ]]; then
      echo "[GPU] strict GPU1-only mode; GPU0 will never be selected"
    else
      echo "[GPU] GPU0 is externally occupied; using GPU1 sequential fallback"
    fi
  elif [[ "${GPU_MODE}" == dual_shared_gpu0 ]]; then
    gpu_is_idle 1 || {
      echo "[Error] GPU1 must be idle for dual_shared_gpu0 mode" >&2; exit 1;
    }
    local gpu0_free_mib
    gpu0_free_mib="$(nvidia-smi -i 0 --query-gpu=memory.free --format=csv,noheader,nounits | tr -d ' ')"
    [[ "${gpu0_free_mib}" =~ ^[0-9]+$ && "${gpu0_free_mib}" -ge 60000 ]] || {
      echo "[Error] dual_shared_gpu0 requires at least 60000 MiB free on GPU0; got ${gpu0_free_mib}" >&2
      exit 1
    }
    echo "[GPU] sharing GPU0 with an external workload (${gpu0_free_mib} MiB free); GPU1 is dedicated"
  else
    [[ "${GPU_MODE}" == dual ]] || {
      echo "[Error] GPU_MODE must be dual, dual_shared_gpu0, gpu1_sequential, or gpu1_only" >&2; exit 1;
    }
    compute_pids="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | sed '/^[[:space:]]*$/d')"
    [[ -z "${compute_pids}" ]] || {
      echo "[Error] refusing launch while GPU compute processes exist: ${compute_pids//$'\n'/,}" >&2; exit 1;
    }
  fi
  mkdir -p "${SUITE_DIR}/service_logs" "/tmp/${UNIT}/matplotlib"
  systemd-run --user --unit="${UNIT}" --same-dir \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv="MPLCONFIGDIR=/tmp/${UNIT}/matplotlib" \
    --setenv="RUN_TAG=${RUN_TAG}" --setenv="SUITE_DIR=${SUITE_DIR}" \
    --setenv="UNIT=${UNIT}" --setenv="GPU_MODE=${GPU_MODE}" \
    --setenv="CANARY_EVIDENCE_RUN_TAG=${CANARY_EVIDENCE_RUN_TAG}" \
    --property=Type=exec --property=Restart=no \
    --property=KillMode=control-group --property=TimeoutStopSec=300 \
    --property=LimitNOFILE=65536 \
    --property=AllowedCPUs=0-143 --property=CPUAffinity=0-143 \
    --property="StandardOutput=append:${SUITE_DIR}/service_logs/controller.log" \
    --property="StandardError=append:${SUITE_DIR}/service_logs/controller.log" \
    /bin/bash "${BASH_SOURCE[0]}" --controller >/dev/null
  echo "[Started] ${UNIT}.service"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] phase=production canary -> Wave1 six-arm adaptive trust screen"
}

if [[ "${1:-}" == --controller ]]; then
  [[ $# -eq 1 ]] || { echo "Usage: $0 --controller" >&2; exit 2; }
  controller
elif [[ "${1:-}" == --validate ]]; then
  [[ $# -eq 1 ]] || { echo "Usage: $0 --validate" >&2; exit 2; }
  validate_launcher_contract
elif [[ $# -eq 0 ]]; then
  initial_launch
else
  echo "Usage: $0 [--controller|--validate]" >&2
  exit 2
fi
