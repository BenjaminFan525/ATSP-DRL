#!/usr/bin/env python3
"""Same fixed Phase-A scientific checks, with a separate measured-work estimate."""
import argparse
import copy
import json
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from onpolicy.config.config import get_config
from onpolicy.scripts.train.diagnose_stage2_cost_improvement import audit_old_wait, make_runner, microfit
from onpolicy.scripts.train.run_stage2_bc_injection_suite import verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism
from onpolicy.utils.stage2_cost_accelerated import AcceleratedCostIteration, load_config
from onpolicy.utils.stage2_cost_improvement import actor_forward, policy_digest
from onpolicy.utils.stage2_cost_schedule import workload_estimate
from onpolicy.utils.stage2_cost_timeout_reference import intervention_signature


def diagnose(cli):
    path = cli.manifest.resolve()
    manifest = json.loads(path.read_text())
    if manifest.get('execution_stage') != 'cost_diagnostic' or 'acceleration' not in manifest['stage_proofs']:
        raise ValueError('Cost diagnosis needs a passed, source-bound full acceleration proof.')
    verify_resources(manifest)
    config = manifest['cost_executor']
    load_config(config['path'], config['sha256'])
    output = path.parent / 'diagnostics'
    output.mkdir(exist_ok=False)
    report_path = output / 'report.json'
    report = dict(manifest=str(path), status='running', started_unix_time=time.time(),
        diagnostic_gate_passed=False, correctness_gate_passed=False, learnability_gate_passed=False,
        budget_is_scientific_gate=False, scientific_result=False, phases={})
    atomic_json(report_path, report)
    runner = iterator = None
    try:
        report['phases']['A2_old_label_audit'] = audit_old_wait()
        configure_bc_determinism(True)
        torch.set_num_threads(1)
        torch.cuda.set_per_process_memory_fraction(.70, device=0)
        random.seed(11)
        np.random.seed(11)
        torch.manual_seed(11)
        torch.cuda.manual_seed_all(11)
        args = parse_args(manifest['commands']['N2_cost_teacher_seed11']['argv'][2:], get_config())
        args.n_rollout_threads = args.max_train_cases = args.train_sampling_size = 24
        args.stage2_research_train_cases = str(path.parent / 'diagnostic_cases.json')
        runner = make_runner(args, manifest, output)
        before = policy_digest(runner.policy)
        iterator = AcceleratedCostIteration(runner, 1)
        prepaid = manifest.get('stage_proofs', {}).get('timeout_regression')
        prepaid = json.loads(Path(prepaid['path']).read_text()) if prepaid else None
        reused_cold_work_seconds = 0.
        runner.envs.call('reset_data_cursor')
        obs, dones, infos = runner.envs.reset()
        hidden = np.zeros((24, runner.num_agents, args.recurrent_N, args.hidden_size), np.float32)
        previous = -np.ones((24, runner.num_agents, 2), np.int64)
        iterator.reset_rollout(hidden)
        samples, replay = [], None
        for step in range(runner.episode_length):
            active = runner._active_masks_from_info(infos)
            history = runner._authoritative_policy_history(infos, previous, args.max_agent_num)
            hidden = iterator.prepare(obs, active, history, infos, hidden)
            actions, next_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            if step == 0:
                runner.envs.call('stage2_cost_branch_capture')
                replay = iterator.branch(obs, infos, history, actions, None)
                runner.envs.call('stage2_cost_branch_clear')
                if not replay['completed']:
                    raise ValueError('No-intervention replay did not complete.')
            labels = runner.envs.call('resource_iga_teacher_actions', return_info=True,
                include_ready_targets=False, deployment_projection=True)
            teacher = np.stack([row['actions'] for row in labels])
            evidence = iterator.evidence(obs, active, history, infos, actions, teacher)
            if (evidence and prepaid and not reused_cold_work_seconds
                    and evidence[0]['cache_context'] == prepaid['cache_context']
                    and intervention_signature(evidence) == prepaid['intervention_signature']
                    and all(outcome['cache_hit'] for item in evidence for outcome in item['outcomes'])):
                # Reuse only current-source exact cache entries. The cold work
                # was measured by the full-load gate: include it in projections
                # so cached diagnostic states cannot make cold training look free.
                reused_cold_work_seconds = prepaid['execution']['wall_seconds']
            for item in evidence:
                if (len(samples) < manifest['diagnostic_contract']['max_microfit_samples']
                        and all(value is not None for value in item['costs'])
                        and max(item['costs']) - min(item['costs']) > args.stage2_cost_tie_seconds):
                    samples.append(([g.clone() for g in obs], active.copy(), history.copy(),
                        np.asarray(infos['agent_types']).copy(), actions.copy(), copy.deepcopy(iterator.prefix), item))
            old_obs, old_types = obs, infos['agent_types']
            obs, _, dones, infos = runner.envs.step(actions)
            iterator.finish_step(old_obs, active, history, old_types, dones)
            next_hidden[dones] = 0.
            hidden, previous = next_hidden, actions
            if evidence or step % 25 == 0:
                report.update(phase='A1_student_and_candidate_costs', event_step=step,
                    queries=iterator.counts['candidate_queries'], execution=iterator.execution_counts,
                    current_source_cache_cold_work_seconds=reused_cold_work_seconds)
                atomic_json(report_path, report)
            if np.all(dones):
                break
        else:
            raise ValueError('Student trajectory did not complete.')
        statuses = runner.envs.call('stage2_cost_live_status')
        if not all(x['completed'] and x['makespan'] == y['makespan']
                   for x, y in zip(statuses, replay['case_statuses'])):
            raise ValueError('Full-batch no-intervention replay differs from live rollout.')
        iterator.finish_epoch()
        report['phases']['A1_student'] = dict(cases=statuses, replay=replay,
            zero_intervention_replay_exact=True, costs=iterator.counts, execution=iterator.execution_counts)
        report.update(phase='A1_derived_IGA_teacher')
        atomic_json(report_path, report)
        runner.envs.call('reset_data_cursor')
        obs, dones, infos = runner.envs.reset()
        hidden[:] = 0.
        previous[:] = -1
        for step in range(runner.episode_length):
            active = runner._active_masks_from_info(infos)
            history = runner._authoritative_policy_history(infos, previous, args.max_agent_num)
            actions, next_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            labels = runner.envs.call('resource_iga_teacher_actions', return_info=True,
                include_ready_targets=False, deployment_projection=True)
            teacher = np.stack([row['actions'] for row in labels])
            resources = active[..., 0] > 0
            resources[:, :args.max_agent_num] = False
            actions[resources] = teacher[resources]
            obs, _, dones, infos = runner.envs.step(actions)
            next_hidden[dones] = 0.
            hidden, previous = next_hidden, actions
            if step % 100 == 0:
                print(f'[TeacherDiagnosis] step={step}', flush=True)
            if np.all(dones):
                break
        else:
            raise ValueError('Derived teacher did not complete.')
        teachers = runner.envs.call('stage2_cost_live_status')
        if not all(row['completed'] for row in teachers):
            raise ValueError('Incomplete derived teacher diagnosis.')
        report['phases']['A1_projected_teacher'] = dict(cases=teachers,
            baseline_mean=float(np.mean([row['makespan'] for row in statuses])),
            teacher_mean=float(np.mean([row['makespan'] for row in teachers])),
            empirical_reference_not_upper_bound=True, historical_IGA1800_is_not_same_runtime_reference=True)
        report.update(phase='A3_recurrent_microfit')
        atomic_json(report_path, report)
        fit = microfit(runner, samples, manifest['diagnostic_contract'])
        if policy_digest(runner.policy) != before:
            raise ValueError('Diagnostic changed source weights.')
        report['phases']['A3_microfit'] = fit
        report['correctness_gate_passed'] = iterator.counts['incomplete'] == 0
        report['learnability_gate_passed'] = fit['passed']
        report['diagnostic_gate_passed'] = bool(report['correctness_gate_passed'] and fit['passed'])
        report['cost_work_estimate'] = workload_estimate(
            iterator.execution_counts['wall_seconds'] + reused_cold_work_seconds,
                                                        iterator.counts['candidate_queries'])
        report['cost_work_estimate'].update(
            actual_diagnostic_collection_seconds=iterator.execution_counts['wall_seconds'],
            current_source_cached_regression_cold_seconds=reused_cold_work_seconds,
            cold_equivalent_collection_seconds=iterator.execution_counts['wall_seconds'] + reused_cold_work_seconds)
        report.update(status='completed', phase='finished', ended_unix_time=time.time(),
            pilot_launch_allowed=False, next_stage='cost_canary' if report['diagnostic_gate_passed'] else 'held',
            limitation='Learnability is not generalization; measured cost work is not the full training ETA.')
        atomic_json(report_path, report)
        return 0 if report['diagnostic_gate_passed'] else 2
    except BaseException as error:
        report.update(status='failed', error=str(error), ended_unix_time=time.time())
        atomic_json(report_path, report)
        raise
    finally:
        if iterator is not None:
            iterator.close()
        if runner is not None:
            runner.envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    raise SystemExit(diagnose(parser.parse_args()))
