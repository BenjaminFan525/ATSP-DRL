#!/usr/bin/env python3
"""Audit every BC/DAgger outcome, including unchanged-source fallbacks."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.analyze_stage2_bc_injection import analyze as integrity_audit, evaluation_cases, paired_comparison
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import json_safe
from onpolicy.utils.stage2_policy_transfer import selection_with_fallback
from onpolicy.utils.training_stage import validate_stage2_joint_finetune_checkpoint


def dataset_metrics(evaluation):
    cases = evaluation['cases']
    values = np.array([c['makespan'] for c in cases], dtype=float)
    result = {'raw': float(values.mean()), 'tail10': float(np.sort(values)[-max(1, int(np.ceil(len(values) * .1))):].mean())}
    for group in ('iid', 'ood_stress', 'ood_scale'):
        selected = [c['makespan'] for c in cases if c['distribution'] == group]
        result[group] = float(np.mean(selected)) if selected else None
    return result


def analyze(manifest_path):
    manifest_path = Path(manifest_path)
    manifest = json.loads(manifest_path.read_text())
    suite = manifest_path.parent
    report = integrity_audit(manifest_path)
    methods, selected, rows = report['methods'], {}, []
    is_scientific = manifest['scientific_result']
    strong = json.loads(Path(manifest['warmstart_sources']['B2_R1']['evaluation']).read_text())
    strong_cases = evaluation_cases(strong, 60)
    strong_metrics = dataset_metrics(strong)
    for key, method in methods.items():
        entry = manifest['commands'][key]
        run = Path(method['run_dir'])
        pre_checkpoint = torch.load(run / 'models/checkpoint_PreSupervised.pt', map_location='cpu', weights_only=True)
        origin = torch.load(entry['warmstart_source']['path'], map_location='cpu', weights_only=True)
        if hashlib.sha256(Path(entry['warmstart_source']['path']).read_bytes()).hexdigest() != entry['warmstart_source']['sha256']:
            raise ValueError('Warm-start source was modified.')
        if set(pre_checkpoint['model']) != set(origin['model']) or any(
            not torch.equal(tensor, origin['model'][name]) for name, tensor in pre_checkpoint['model'].items()
        ):
            raise ValueError(f'{key} did not start from exact source weights.')
        fork = pre_checkpoint.get('stage2_policy_warmstart') or {}
        if fork.get('optimizer_restored') is not False or fork.get('rng_restored') is not False:
            raise ValueError(f'{key} did not record a fresh optimizer/RNG fork.')
        if pre_checkpoint['stage2_bc_state']['completed_epochs'] != 0:
            raise ValueError(f'{key} inherited an old epoch cursor.')
        if pre_checkpoint.get('supervised_optimizer') is not None:
            raise ValueError(f'{key} inherited a supervised optimizer at its initial boundary.')
        if pre_checkpoint.get('device_bc_skip_ready_targets') is not True:
            raise ValueError(f'{key} did not explicitly disable trajectory-bound ready labels.')
        pre = json.loads((run / 'evaluations/pre_supervised.json').read_text())
        if is_scientific:
            replay = pre_checkpoint.get('stage2_policy_warmstart_replay') or {}
            if not replay.get('passed') or replay.get('max_absolute_case_delta_seconds') != 0.0:
                raise ValueError(f'{key} lacks zero-tolerance pre-gradient replay.')
        choice = selection_with_fallback(method['epoch_metrics'], pre['summary'])
        effective_epoch = choice['epoch']
        evaluation = pre if effective_epoch == 0 else json.loads((run / 'evaluations' / f'bc_epoch_{effective_epoch}.json').read_text())
        selected[key] = evaluation_cases(evaluation, manifest['evaluation_contract']['cases'])
        trained = [json.loads(line) for line in (run / 'logs/request_ready_epoch_metrics.jsonl').read_text().splitlines()]
        if [v['device_bc_epoch'] for v in trained] != [1, 2]:
            raise ValueError(f'{key} has missing/duplicated training epochs.')
        for epoch, metrics in enumerate(trained):
            if metrics['device_bc_rollouts'] != manifest['training_contract']['rollouts_per_epoch'] or metrics['device_bc_optimizer_steps'] <= 0:
                raise ValueError(f'{key} did not complete its rollout/optimizer budget.')
            target = entry['teacher_execution_schedule'][epoch]
            if metrics['device_bc_teacher_execution_target'] != target:
                raise ValueError(f'{key} changed its teacher schedule.')
            if metrics['request_ready_total_labels'] != 0:
                raise ValueError(f'{key} used factual ready labels on policy-training trajectories.')
            if target == 1.0 and metrics['student_executed_envs'] != 0:
                raise ValueError(f'{key} teacher control executed student resources.')
            if target < 1.0 and (metrics['student_executed_envs'] <= 0 or metrics['teacher_executed_envs'] <= 0):
                raise ValueError(f'{key} mixed arm did not exercise both action sources.')
        checkpoint_path = Path(entry['warmstart_source']['path']) if effective_epoch == 0 else run / 'models/checkpoint_Best.pt'
        checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
        handoff = validate_stage2_joint_finetune_checkpoint(
            checkpoint, checkpoint['model'], plane_order_mode=checkpoint['plane_order_mode'],
            plane_pair_decoder=checkpoint['plane_pair_decoder'], global_feature_mode=checkpoint['global_feature_mode'],
            planning_contract=checkpoint['resource_lookahead_contract'],
            request_ready_time_scale=checkpoint['request_ready_time_scale'],
        )
        method.update({
            'effective_epoch': effective_epoch, 'retained_source': choice['retained_source'],
            'effective_checkpoint': str(checkpoint_path), 'warmstart_exact': True,
            'baseline_metrics': pre['summary'], 'selected_metrics': choice['metrics'],
            'stage3_static_handoff_passed': True,
            'stage3_ready_source': handoff.get('frozen_ready_source_verified'),
            'stage3_dynamic_transfer_tested': False,
            'training_budget': [{k: v[k] for k in (
                'device_bc_epoch', 'device_bc_rollouts', 'device_bc_optimizer_steps',
                'device_bc_total_labels', 'device_bc_assignment_total_labels',
                'device_bc_teacher_execution_target', 'device_bc_teacher_execution_rate',
                'teacher_executed_envs', 'student_executed_envs', 'device_bc_elapsed_seconds',
            )} for v in trained],
            'versus_own_source': paired_comparison(selected[key], evaluation_cases(pre, len(pre['cases']))),
        })
        if is_scientific:
            comparison = paired_comparison(selected[key], strong_cases)
            effect = -comparison['mean_delta_seconds'] / strong_metrics['raw']
            metrics = dataset_metrics(evaluation)
            safety = all(metrics[group] is not None and metrics[group] <= strong_metrics[group] * (
                1 + manifest['analysis_contract']['max_group_regression_fraction']) for group in ('ood_stress', 'tail10'))
            method.update({
                'versus_frozen_strong_B2': comparison, 'gain_fraction_vs_frozen_strong_B2': effect,
                'distribution_metrics': metrics, 'ood_tail_point_safety_passed': safety,
                'screen_threshold_passed': effect >= manifest['analysis_contract']['screen_gain_fraction'] and safety,
                'practical_target_point_estimate_passed': effect >= manifest['analysis_contract']['practical_gain_fraction'] and safety,
                'case_ci_excludes_zero': comparison['case_bootstrap_95ci_seconds'][1] < 0,
                'confirmed_scientific_success': False,
            })
        for epoch in (0, 1, 2):
            value = pre if epoch == 0 else json.loads((run / 'evaluations' / f'bc_epoch_{epoch}.json').read_text())
            for case in value['cases']:
                rows.append({'method': key, 'epoch': epoch, 'case_sha256': case['case_sha256'],
                             'distribution': case['distribution'], 'profile': case['profile'],
                             'cmax': case['makespan'], 'effective_selection': epoch == effective_epoch})
    report['paired_comparisons'] = {
        f'{left}_minus_{right}': paired_comparison(selected[left + '_seed11'], selected[right + '_seed11'])
        for left, right in manifest['analysis_contract']['contrasts']
    }
    report.update({'analysis_contract': manifest['analysis_contract'],
                   'scientific_result': is_scientific, 'formal_promotion': False,
                   'stage3_training_started': False,
                   'note': 'One shared source/training seed, tune-selected exploratory results. All epochs retained; static handoff is not dynamic Stage3 validation.'})
    atomic_json(suite / 'analysis/comparison.json', json_safe(report))
    with (suite / 'analysis/all_epoch_cases.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({'integrity_passed': True, 'methods': len(methods), 'stage3_static_handoff_passed': True,
                      'formal_promotion': False}))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    analyze(parser.parse_args().manifest)
