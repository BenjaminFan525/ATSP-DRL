#!/usr/bin/env python3
"""Discarded GPU0 engineering prefix: teacher masks, plane, gradient and restore.

Six training cases, at most64 events each. These are NOT completed trajectories
or scientific PPO updates. Two diagnostic BC updates are discarded.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.algorithms.utils.resource_actor_v6 import install_resource_v6
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.prepare_stage2_resource_v6 import PARENT
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, cpus, seed
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_resource_rl import file_sha, forward, resource_mask, summary
from onpolicy.utils.stage2_resource_rl_v4_fast import prepared_forward
from onpolicy.utils.stage2_resource_rl_v4_resume import assert_tree_equal
from onpolicy.utils.stage2_resource_v6 import DEFAULTS, V6Learner, semantic_labels


def run(output):
    if output.exists():
        raise FileExistsError('New engineering report path required.')
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('GPU0/original CPU half only.')
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    if str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') != '744c1334-98c8-5318-e799-7ad15eea1fbf':
        raise ValueError('Unexpected physical GPU.')
    m = json.loads(PARENT.read_text())
    m['training_contract'] = dict(DEFAULTS)
    args = arguments(m)
    args.stage2_resource_v6_observations = True
    args.max_train_cases = args.train_sampling_size = args.n_rollout_threads = 6
    payload = torch.load(m['source']['path'], map_location='cpu', weights_only=True)
    for key, value in ready_head_config(payload).items():
        setattr(args, key, value)
    ac_config = yaml.safe_load(Path(args.ac_config).read_text())
    def learner(arm=None):
        seed(11)
        policy = GNN_MAPPOPolicy(args, ac_config, torch.device('cuda:0'))
        policy.load_model_state(payload['model'])
        policy.ac.tau, policy.ac.device_global_matching = args.evaluation_tau, False
        if arm:
            install_resource_v6(policy.ac, arm)
        return V6Learner(policy, args, dict(DEFAULTS), lambda *a, **k: None, arm)
    base = learner()
    rows = m['train']['cases'][:6]
    envs, _ = make_train_env(args, case_records=rows, dataset_override=m['train']['dataset'])
    started = time.monotonic()
    frames, actual_labels, maximum, history_slots = [], 0, 0., 0
    try:
        obs, _, info = envs.reset()
        hidden = np.zeros((6, 104, 1, 64), np.float32)
        previous = np.full((6, 104, 2), -1, np.int64)
        done_cases = np.zeros(6, bool)
        base.policy.ac.eval()
        for step in range(64):
            active = np.asarray(info['active_agents'], np.float32).reshape(6, 104, 1).copy()
            active[done_cases] = 0
            history = HKBZ_Runner._authoritative_policy_history(info, previous, 24)
            types = np.asarray(info['agent_types']).copy()
            with torch.no_grad():
                out, enc = base.collect_forward(base.policy, obs, hidden, active, history, types, deterministic=True)
                actions = out['actions'].cpu().numpy()
                labels = envs.call('resource_iga_teacher_actions', return_info=True,
                    include_ready_targets=False, deployment_projection=True)
                for i, label in enumerate(labels):
                    if not label['info']['available']:
                        raise ValueError('Missing pilot teacher.')
                    mask = active[i, 24:, 0].astype(bool)
                    actions[i, 24:, :2][mask] = np.asarray(label['actions'])[24:, :2][mask]
                out, _ = base.collect_forward(base.policy, obs, hidden, active, history, types, actions=actions, encoded=enc)
                for i, label in enumerate(semantic_labels(obs, labels, 24)):
                    for decision in label['decisions']:
                        agent = decision['agent']
                        if not active[i, agent, 0]:
                            continue
                        expected = set(decision['legal']) | ({0} if decision['allow_noop'] else set())
                        actual = set(torch.isfinite(out['resource_logits'][i, agent]).nonzero().flatten().cpu().tolist())
                        if actual != expected:
                            raise ValueError('Teacher prefix support mismatch.')
                        actual_labels += 1
            new_obs, _, dones, new_info = envs.step(actions)
            history_slots += sum(int(g.v6_history[0, :, -2].sum()) for g in obs)
            frames.append(dict(obs=list(obs), active=active, history=history.copy(), types=types,
                actions=actions.copy(), teacher_actions=actions.copy(), dones=np.asarray(dones).copy(),
                encoded={'case_group_encodings': {key: {k: v.detach().cpu() for k, v in value.items()}
                    for key, value in enc['case_group_encodings'].items()}},
                mask=resource_mask(out['decision_mask'], 24).cpu(),
                legal=torch.isfinite(out['resource_logits']).cpu(), old_logp=out['log_probs'].cpu()))
            hidden = out['rnn_states'].cpu().numpy()
            hidden[np.asarray(dones)] = 0
            done_cases |= np.asarray(dones).reshape(6, -1).all(-1)
            previous, obs, info = actions, new_obs, new_info
            if (step + 1) % 16 == 0:
                print(json.dumps(dict(phase='engineering_prefix', events=step + 1, teacher_decisions=actual_labels)), flush=True)
        if actual_labels == 0 or history_slots == 0:
            raise ValueError('Engineering prefix exercised no teacher/history decisions.')
        rollout = dict(frames=frames, cases=rows, teacher_execution=True, engineering_prefix_only=True)
        reports = {}
        for arm in ('S1', 'S2'):
            current = learner(arm)
            current.policy.ac.eval()
            hidden_current = current._hidden(6)
            hidden_base = base._hidden(6)
            for frame in frames[:16]:
                entry = current.entry(frame)
                with torch.no_grad():
                    out, _ = prepared_forward(current.policy, entry['data'], entry['info'], hidden_current,
                        actions=entry['actions'], encoded=entry['encoded'])
                    ref, _ = prepared_forward(base.policy, entry['data'], entry['info'], hidden_base,
                        actions=entry['actions'], encoded=entry['encoded'])
                    replay, _ = prepared_forward(current.policy, entry['data'], entry['info'], hidden_current,
                        actions=entry['actions'], encoded=entry['encoded'])
                    delta = out['log_probs'] - replay['log_probs']
                    maximum = max(maximum, float(delta.abs().max()))
                    if maximum > 1e-6:
                        raise ValueError('GPU zero-update replay failed.')
                    for key in ('actions', 'log_probs', 'rnn_states', 'decision_mask'):
                        assert_tree_equal(ref[key][:, :24], out[key][:, :24], 'frozen conditional plane')
                    hidden_current = out['rnn_states'] * (~entry['dones']).unsqueeze(-1).unsqueeze(-1)
                    hidden_base = ref['rnn_states'] * (~entry['dones']).unsqueeze(-1).unsqueeze(-1)
            current.clear_cache()
            update = current.bc_epoch_batch(rollout)
            state = current.checkpoint_state()
            restored = learner(arm)
            restored.policy.ac.load_state_dict(state['model'], strict=True)
            restored.actor_optim.load_state_dict(copy.deepcopy(state['actor_optimizer']))
            assert_tree_equal(state['model'], restored.policy.ac.state_dict(), 'V6 model restore')
            assert_tree_equal(state['actor_optimizer'], restored.actor_optim.state_dict(), 'V6 Adam restore')
            current.assert_protected()
            reports[arm] = dict(update=update, frozen_parameters_unchanged=True,
                model_and_adam_restore=True, conditional_plane_equal=True, discarded=True)
            del current, restored
        report = dict(passed=True, arms=reports, teacher_decisions=actual_labels, history_slots=history_slots,
            max_logp_error=maximum, seconds=time.monotonic() - started, prefix_cases=6,
            events_per_case=64, completed_scientific_episodes=0, scientific_updates_discarded=True,
            gpu=0, cpus=sorted(os.sched_getaffinity(0)), search_calls=0, cost_label_queries=0)
        report['checked_sources'] = {name: file_sha(ROOT / name) for name in (
            'onpolicy/utils/stage2_resource_v6_observation.py', 'onpolicy/utils/stage2_resource_v6.py',
            'onpolicy/algorithms/utils/resource_actor_v6.py', 'onpolicy/envs/HKBZ/environment.py',
            'onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py',
            'onpolicy/scripts/train/train_hkbz.py', 'onpolicy/scripts/train/check_stage2_resource_v6.py')}
        report['real_transporter_free_decisions_exercised'] = reports['S1']['update']['role_metrics']['transporter']['count']
        atomic_json(output, report)
        print(json.dumps(report), flush=True)
    finally:
        envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    run(parser.parse_args().output)
