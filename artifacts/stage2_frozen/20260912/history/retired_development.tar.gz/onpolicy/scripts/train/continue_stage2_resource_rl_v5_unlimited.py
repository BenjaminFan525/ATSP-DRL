#!/usr/bin/env python3
"""One-shot, fixed-scope V5 handoff with user-disabled wall-clock gates.

The old scheduler is paused, not its setup worker. After that worker exits
successfully, retire the old scheduler and reuse every passed setup artifact.
No scientific source, training method, case order or retry policy is changed.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.control_stage2_resource_rl_v5 import Controller, analyze, budget_projection
from onpolicy.scripts.train.continue_stage2_resource_rl_v5 import validate_stop_point
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl import cpus
from onpolicy.scripts.train.run_stage2_resource_rl_v5_unlimited import VERSION, require_time_authorization
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL
from onpolicy.utils.stage2_process_control import pidfd_open, pidfd_send_signal

DOC = 'STAGE2_SPLIT_ENCODER_V5_TIME_LIMIT_REMOVAL_20260909.md'
LAUNCHER = 'onpolicy/scripts/train/launch_stage2_resource_rl_v5_unlimited_gpu0.sh'
PARENT_UNIT = 'hkbz-stage2-split-v5-20260909-gpu0-half-r4.service'
CHANGED_MANIFEST_KEYS = {'run_tag', 'created_at', 'material_passport', 'source_archive',
                         'code_fingerprint', 'resource_contract'}


def read(path):
    return json.loads(Path(path).read_text())


def check_hashes(root, hashes):
    for name, digest in hashes.items():
        if file_sha(Path(root) / name) != digest:
            raise ValueError(f'Pinned artifact changed: {name}')


def validate_parent(parent):
    m = read(parent / 'manifest.json')
    if (m.get('protocol') != PROTOCOL or m.get('training_contract') != DEFAULTS
            or m['execution']['arms'] != list(ARMS) or 'zero_audit_repair' not in m):
        raise ValueError('Only the exact unchanged r4 V5 experiment may continue.')
    check_hashes(ROOT, m['code_fingerprint'])
    for key in ('source', 'stage1_source', 'source_archive', 'parent_manifest', 'historical_b0_ar', 'iga_reference'):
        if file_sha(m[key]['path']) != m[key]['sha256']:
            raise ValueError(f'Immutable input changed: {key}')
    reports = {a: read(parent / 'engineering' / a / 'report.json') for a in ARMS}
    validate_stop_point(m, read(Path(m['budget_continuation']['parent']) / 'run_status.json'), reports)
    if any((parent / 'workers' / a).exists() or (parent / a).exists() for a in ARMS):
        raise ValueError('Training has already started; this setup-boundary adapter cannot replay it.')
    worker = read(parent / 'workers/setup/run_status.json')
    if (worker.get('status') not in ('running', 'completed')
            or worker.get('completed_training_case_episodes', 0) != 0
            or worker.get('attempted_physical_case_episodes', 0) > 540):
        raise ValueError('Failed, partial-training or over-budget setup cannot be silently retried.')
    return m


def validate_completed_setup(parent, m):
    worker = read(parent / 'workers/setup/run_status.json')
    complete = read(parent / 'checks/setup_complete.json')
    if (worker.get('status') != 'completed' or worker.get('phase') != 'setup'
            or worker.get('completed_physical_case_episodes') != 540
            or worker.get('attempted_physical_case_episodes') != 540
            or worker.get('completed_training_case_episodes', 0) != 0
            or complete.get('passed') is not True or complete.get('completed_case_episodes') != 540):
        raise ValueError('All 540 setup cases must finish successfully before handoff.')
    zero = read(parent / 'checks/zero_update.json')
    if set(zero) != set(ARMS):
        raise ValueError('All four initial zero-update proofs are mandatory.')
    historical = {r['case_sha256']: r for r in read(m['historical_b0_ar']['path'])['cases']}
    for arm in ARMS:
        proof = zero[arm]
        conditional, replay = proof['conditional_reference'], proof['replay_checks']
        if (proof.get('passed') is not True or proof.get('cases') != 60
                or conditional.get('events', 0) <= 0 or replay.get('events', 0) <= 0
                or not 0 <= conditional.get('max_logp_error', math.inf) <= 1e-6
                or not 0 <= conditional.get('max_hidden_error', math.inf) <= 1e-6
                or not 0 <= replay.get('max_logp_error', math.inf) <= 1e-6
                or not 0 <= replay.get('max_ratio_error', math.inf) <= 1e-5
                or replay.get('masks_equal') is not True or replay.get('actions_equal') is not True):
            raise ValueError(f'Initial numerical proof failed for {arm}.')
        rows = read(parent / 'evaluations' / f'{arm}_initial_AR.json')['cases']
        if (len(rows) != 60 or {r['case_sha256'] for r in rows} != set(historical)
                or any(r['makespan'] != historical[r['case_sha256']]['makespan']
                       or r['steps'] != historical[r['case_sha256']]['steps'] for r in rows)):
            raise ValueError(f'Historical B0 AR identity failed for {arm}.')
    h = read(parent / 'checks/b0_hungarian.json')
    rows = read(parent / 'evaluations/B0_H.json')['cases']
    expected = {r['case_sha256']: r for r in m['evaluation']['cases']}
    if (h.get('passed') is not True or h.get('cases') != 60 or h.get('tolerance') != 0
            or len(rows) != 60 or {r['case_sha256'] for r in rows} != set(expected)
            or any(r['makespan'] != expected[r['case_sha256']]['makespan']
                   or r['steps'] != expected[r['case_sha256']]['finish_steps'] for r in rows)):
        raise ValueError('Historical B0 Hungarian identity failed.')
    reference = read(parent / 'reference/manifest.json')
    if (reference.get('case_episodes') != 240 or reference.get('max_states_per_case') != 32
            or reference.get('source') != m['source'] or reference.get('observable_only') is not True
            or reference.get('decoder') != 'hungarian' or reference.get('cost_labels') != 0
            or len(reference['parts']) != 10):
        raise ValueError('Complete original B0 observable reference pool required.')
    for index, part in enumerate(reference['parts'], 1):
        path = (parent / 'reference' / f'raw_graph_pool_{index}.pt').resolve()
        if (Path(part['path']).resolve() != path or file_sha(path) != part['sha256']
                or not 0 < part['states'] <= 24 * 32):
            raise ValueError('Raw graph reference content/order changed.')
        batch = read(parent / 'reference' / f'batch_{index}.json')['cases']
        wanted = [m['train']['cases'][i] for i in m['train']['collection_batches'][index - 1]]
        if (len(batch) != 24 or [r['case_sha256'] for r in batch] != [r['case_sha256'] for r in wanted]
                or any(not r['completed'] or r['timeout'] or r['cycle_terminated'] for r in batch)):
            raise ValueError('Incomplete/reordered reference trajectories cannot be reused.')
    return dict(passed=True, retained_engineering_case_episodes=96, retained_setup_case_episodes=540,
        remaining_training_case_episodes=960, remaining_evaluation_case_episodes=720,
        remaining_case_episodes=1680, scientific_code_unchanged=True, setup_repeated=False)


def authorize(parent, output, tag, deployment_repair_of=None):
    parent, output = parent.resolve(), output.resolve()
    if output.exists() or not tag.replace('_', '').replace('-', '').isalnum():
        raise ValueError('A new request directory and safe run tag are required.')
    old = validate_parent(parent)
    fingerprints = {**old['code_fingerprint'], **code_fingerprint()}
    for name in (DOC, LAUNCHER):
        fingerprints[name] = file_sha(ROOT / name)
    output.mkdir(parents=True, exist_ok=False)
    archive = output / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for name, digest in fingerprints.items():
            content = (ROOT / name).read_bytes()
            if file_sha(ROOT / name) != digest:
                raise ValueError('Code changed while archiving authorization.')
            handle.addfile(handle.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(content))
    request = dict(version=VERSION, user_request='解除超时门禁', parent=str(parent), parent_unit=PARENT_UNIT,
        run_tag=tag, authorized_at=datetime.now(timezone.utc).isoformat(),
        parent_manifest_sha256=file_sha(parent / 'manifest.json'),
        parent_control_sha256=file_sha(parent / 'control.json'), code_fingerprint=fingerprints,
        source_archive=dict(path=str(archive), sha256=file_sha(archive)),
        wall_clock_limit_enabled=False, projected_time_gate_enabled=False,
        original_control=read(parent / 'control.json'), remaining_after_setup_case_episodes=1680,
        automatic_retry=False, additional_rounds=False, stage3_started=False,
        material_passport=dict(origin_skill='academic-research-suite/experiment-agent', origin_mode='run',
            origin_date='2026-09-09', verification_status='UNVERIFIED', version_label=VERSION))
    if deployment_repair_of is not None:
        failed = deployment_repair_of.resolve()
        status = read(failed / 'run_status.json')
        prior = read(failed / 'authorization.json')
        allowed_errors = (
            "module 'os' has no attribute 'pidfd_open'",
            "Command '['systemctl', '--user', 'set-property', '--runtime', "
            "'hkbz-stage2-split-v5-20260909-gpu0-half-r4.service', "
            "'RuntimeMaxSec=infinity']' returned non-zero exit status 1.",
        )
        if (status.get('status') != 'failed' or status.get('phase') != 'time_limit_handoff'
                or status.get('error') not in allowed_errors
                or prior.get('parent') != str(parent)
                or any((failed / name).exists() for name in
                       ('checks/active_handoff.json', 'manifest.json', 'control.json'))
                or file_sha(prior['source_archive']['path']) != prior['source_archive']['sha256']):
            raise ValueError('Only the known untouched pre-signal deployment failure may be corrected here.')
        names = ('authorization.json', 'handoff_started.json', 'run_status.json', 'controller.log', 'source_bundle.tar.gz')
        request['deployment_repair_of'] = dict(path=str(failed),
            retained_artifacts={name: file_sha(failed / name) for name in names},
            scientific_case_episodes_repeated=0, scientific_updates=0,
            old_scheduler_was_paused=False, setup_worker_was_interrupted=False)
    atomic_json(output / 'authorization.json', request)
    print(output / 'authorization.json', flush=True)


def validate_request(path):
    request = read(path)
    if (request.get('version') != VERSION or request.get('user_request') != '解除超时门禁'
            or request.get('parent_unit') != PARENT_UNIT
            or request.get('wall_clock_limit_enabled') is not False
            or request.get('projected_time_gate_enabled') is not False
            or request.get('remaining_after_setup_case_episodes') != 1680
            or request.get('automatic_retry') is not False):
        raise ValueError('Invalid fixed-scope time-limit removal request.')
    parent = Path(request['parent'])
    if (file_sha(parent / 'manifest.json') != request['parent_manifest_sha256']
            or file_sha(parent / 'control.json') != request['parent_control_sha256']):
        raise ValueError('Parent experiment identity changed after authorization.')
    check_hashes(ROOT, request['code_fingerprint'])
    if file_sha(request['source_archive']['path']) != request['source_archive']['sha256']:
        raise ValueError('Authorized source snapshot changed.')
    if 'deployment_repair_of' in request:
        failure = request['deployment_repair_of']
        check_hashes(failure['path'], failure['retained_artifacts'])
    return request, validate_parent(parent)


def finalize_manifest(request_path, exit_evidence):
    request, old = validate_request(request_path)
    root, parent = request_path.parent, Path(request['parent'])
    if (root / 'manifest.json').exists():
        raise FileExistsError('Never repeat a handoff or overwrite its manifest.')
    proof = validate_completed_setup(parent, old)
    copies = [f'engineering/{a}/{name}' for a in ARMS for name in ('report.json', 'run_status.json')]
    copies += ['workers/setup/run_status.json', 'checks/zero_update.json', 'checks/b0_hungarian.json',
               'checks/setup_complete.json', 'reference/manifest.json']
    copies += [f'evaluations/{a}_initial_AR.json' for a in ARMS] + ['evaluations/B0_H.json']
    copies += [f'reference/batch_{i}.json' for i in range(1, 11)]
    copies += [str(p.relative_to(parent)) for p in sorted((parent / 'traces').rglob('*.json'))]
    retained = list(dict.fromkeys(copies + ['manifest.json', 'control.json', 'run_status.json',
                                           'controller.log', 'logs/setup_E0.log']))
    hashes = {name: file_sha(parent / name) for name in retained}
    for name in copies:
        destination = root / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(parent / name, destination)
        if file_sha(destination) != hashes[name]:
            raise ValueError('Completed setup changed while copying.')
    m = copy.deepcopy(old)
    m.update(run_tag=request['run_tag'], created_at=datetime.now(timezone.utc).isoformat(),
        material_passport=request['material_passport'], code_fingerprint=request['code_fingerprint'],
        source_archive=request['source_archive'])
    m['resource_contract']['runtime_max_seconds'] = None
    m['time_limit_removal'] = dict(version=VERSION, user_request=request['user_request'],
        wall_clock_limit_enabled=False, projected_time_gate_enabled=False,
        parent=str(parent), authorization=dict(path=str(request_path), sha256=file_sha(request_path)),
        superseded_deadline_unix=request['original_control']['hard_deadline_unix'],
        retained_artifacts=hashes, copied_artifacts=copies, setup_exit_evidence=exit_evidence,
        original_started_unix=request['original_control']['started_unix'],
        inherited_worker_exit_records=read(parent / 'run_status.json')['worker_exit_records'],
        remaining_case_episode_limit=1680, retained_case_episodes=636,
        prior_failed_and_diagnostic_attempts=24, lifetime_attempted_case_episode_limit=2340,
        automatic_retry=False, old_artifacts_retained=True)
    validate_unchanged_scope(m, old)
    atomic_json(root / 'checks/retained_setup.json', proof)
    atomic_json(root / 'manifest.json', m)
    return root / 'manifest.json'


def validate_unchanged_scope(m, old):
    require_time_authorization(m)
    for key in old:
        if key not in CHANGED_MANIFEST_KEYS and m.get(key) != old[key]:
            raise ValueError(f'Time-limit removal cannot change {key}.')
    if m['resource_contract'] != {**old['resource_contract'], 'runtime_max_seconds': None}:
        raise ValueError('GPU, CPU, concurrency and evaluation isolation must remain unchanged.')
    if any(m['code_fingerprint'].get(name) != digest for name, digest in old['code_fingerprint'].items()):
        raise ValueError('Time-limit removal cannot change any previously pinned scientific code.')


def informational_budget(reports, old_remaining, eval_rate):
    projection = budget_projection(reports, old_remaining, eval_rate)
    projection.update(would_pass_superseded_deadline=projection['passed'],
        superseded_remaining_seconds=projection['remaining_seconds'], remaining_seconds=None,
        passed=True, enforced=False, wall_clock_limit_enabled=False,
        user_authorization='解除超时门禁', time_authorization_version=VERSION)
    return projection


class UnlimitedController(Controller):
    def __init__(self, manifest):
        self.path, self.root = manifest.resolve(), manifest.resolve().parent
        self.m = read(self.path)
        authorization = require_time_authorization(self.m)
        self.started = authorization['original_started_unix']
        self.process_started = time.time()
        self.deadline = math.inf  # Internal sentinel only; JSON uses null, never Infinity.
        self.jobs = {}
        self.records = [{**r, 'retained_from_previous_process': True}
                        for r in authorization['inherited_worker_exit_records']]
        if not any(r.get('phase') == 'setup' and r.get('exit_code') == 0 for r in self.records):
            self.records.append(dict(phase='setup', arm='E0', exit_code=0,
                completed_unix=authorization['setup_exit_evidence']['verified_at'],
                retained_from_previous_process=True, verified_by='pidfd_setup_boundary_handoff'))
        self.phase = 'stage_b_training'

    def status(self, **extra):
        workers = {}
        for phase, arm in [(p, a) for p in ('engineering', 'train') for a in ARMS] + [('setup', 'E0')]:
            path = self.root / ('engineering' if phase == 'engineering' else 'workers') / (arm if phase != 'setup' else 'setup') / 'run_status.json'
            if path.exists():
                workers[phase + '/' + arm] = read(path)
        completed = sum(w.get('completed_physical_case_episodes', 0) for w in workers.values())
        attempts = sum(w.get('attempted_physical_case_episodes', 0) for w in workers.values())
        atomic_json(self.root / 'run_status.json', dict(status=extra.pop('status', 'running'), phase=self.phase,
            pid=os.getpid(), started_unix=self.started, process_started_unix=self.process_started,
            process_elapsed_seconds=time.time() - self.process_started, elapsed_seconds=time.time() - self.started,
            updated_unix=time.time(), hard_deadline_unix=None, wall_clock_limit_enabled=False,
            projected_time_gate_enabled=False, time_authorization_version=VERSION,
            workers=workers, worker_exit_records=self.records, completed_physical_case_episodes=completed,
            attempted_physical_case_episodes=attempts, lifetime_attempted_physical_case_episodes=attempts + 24,
            lifetime_attempted_case_episode_limit=2340, retained_case_episodes=636,
            completed_training_case_episodes=sum(w.get('completed_training_case_episodes', 0)
                for key, w in workers.items() if key.startswith('train/')),
            allowed_stages=['A', 'B'], automatic_retry=False, automatic_stage_c=False,
            stage3_started=False, scientific_success_confirmed=False, **extra))

    def launch(self, phase, arm, slot):
        if phase != 'train':
            raise RuntimeError('Completed engineering/setup cannot be launched again.')
        cpu = self.m['resource_contract']['trainer_slots'][slot]
        path = self.root / 'logs' / f'{phase}_{arm}.log'
        path.parent.mkdir(parents=True, exist_ok=True)
        log = path.open('x')
        command = ['taskset', '-c', cpu, sys.executable, '-u',
            str(ROOT / 'onpolicy/scripts/train/run_stage2_resource_rl_v5_unlimited.py'),
            '--manifest', str(self.path), '--phase', phase, '--arm', arm, '--slot', str(slot)]
        proc = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        self.jobs[slot] = (proc, log, phase, arm)
        print(json.dumps(dict(event='worker_started', phase=phase, arm=arm, slot=slot,
                              pid=proc.pid, cpu=cpu, command=command)), flush=True)

    def validate_continuation(self):
        auth = self.m['time_limit_removal']
        parent = Path(auth['parent'])
        old = validate_parent(parent)
        validate_unchanged_scope(self.m, old)
        validate_completed_setup(parent, old)
        check_hashes(parent, auth['retained_artifacts'])
        check_hashes(self.root, {name: auth['retained_artifacts'][name] for name in auth['copied_artifacts']})
        check_hashes(ROOT, self.m['code_fingerprint'])
        if file_sha(auth['authorization']['path']) != auth['authorization']['sha256']:
            raise ValueError('User authorization record changed.')
        if file_sha(self.m['source_archive']['path']) != self.m['source_archive']['sha256']:
            raise ValueError('Unlimited-controller source snapshot changed.')

    def run(self):
        self.validate_continuation()
        if (self.root / 'control.json').exists():
            raise FileExistsError('No automatic controller retry.')
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
            raise ValueError('Only GPU0 and the original CPU half are authorized.')
        os.sched_setaffinity(0, cpus(self.m['resource_contract']['monitor_cpus']))
        atomic_json(self.root / 'control.json', dict(started_unix=self.started,
            process_started_unix=self.process_started, pid=os.getpid(), hard_deadline_unix=None,
            manifest_sha256=file_sha(self.path), automatic_retry=False, time_authorization_version=VERSION))

        def stop(signum, frame):
            raise KeyboardInterrupt(f'Operator/service signal {signum}')

        signal.signal(signal.SIGTERM, stop)
        try:
            reports = {a: read(self.root / 'engineering' / a / 'report.json') for a in ARMS}
            for pair in (('E0', 'E1'), ('E2', 'E3')):
                if sum(reports[a]['peak_allocated_bytes'] for a in pair) > .8 * 49140 * 1024**2:
                    raise ValueError('Dual-trainer GPU memory headroom gate failed.')
            rate = max(read(self.root / 'evaluations' / f'{a}_initial_AR.json')['seconds'] / 60 for a in ARMS)
            rate = max(rate, read(self.root / 'evaluations/B0_H.json')['seconds'] / 60)
            projection = informational_budget(reports,
                self.m['time_limit_removal']['superseded_deadline_unix'] - time.time(), rate)
            atomic_json(self.root / 'checks/budget_gate.json', projection)
            self.status()
            self.batch('train', ['E0', 'E1'])
            self.batch('train', ['E2', 'E3'])
            analyze(self.root, self.m)
            paused = any(read(self.root / a / 'result.json')['status'] == 'paused_for_kl' for a in ARMS)
            self.phase = 'stage_b_completed_with_paused_arm' if paused else 'stage_b_completed'
            self.status(status='completed_with_paused_arm' if paused else 'completed',
                        optional_stage_c='requires_new_user_authorization')
            return 0
        except BaseException as exc:
            if isinstance(exc, (TimeoutError, KeyboardInterrupt)):
                for proc, *_ in self.jobs.values():
                    proc.terminate()
                stop_by = time.monotonic() + 10
                while any(p.poll() is None for p, *_ in self.jobs.values()) and time.monotonic() < stop_by:
                    time.sleep(.2)
                for proc, *_ in self.jobs.values():
                    if proc.poll() is None:
                        proc.kill()
            self.status(status='stopped' if isinstance(exc, KeyboardInterrupt) else 'failed',
                        error=str(exc), traceback=traceback.format_exc())
            print(traceback.format_exc(), flush=True)
            return 1


class PinnedProcess:
    """pidfd prevents signaling a reused PID; commands/parentage must also match."""
    def __init__(self, pid, manifest, script, phase=None, parent_pid=None):
        self.pid = int(pid)
        self.fd = pidfd_open(self.pid)
        try:
            arguments = (Path('/proc') / str(self.pid) / 'cmdline').read_bytes().decode().split('\0')
            if (str(ROOT / 'onpolicy/scripts/train' / script) not in arguments
                    or '--manifest' not in arguments
                    or arguments[arguments.index('--manifest') + 1] != str(manifest)
                    or (phase and ('--phase' not in arguments or arguments[arguments.index('--phase') + 1] != phase))):
                raise ValueError('Refusing to signal a process with a different command/manifest.')
            info = self.info()
            if parent_pid is not None and info['ppid'] != parent_pid:
                raise ValueError('Setup worker is not a child of the exact old controller.')
            self.start_ticks = info['start_ticks']
        except BaseException:
            os.close(self.fd)
            raise

    def info(self):
        raw = (Path('/proc') / str(self.pid) / 'stat').read_text()
        fields = raw[raw.rfind(')') + 2:].split()
        return dict(state=fields[0], ppid=int(fields[1]), start_ticks=int(fields[19]),
                    exit_wait_status=int(fields[49]))

    def send(self, signum):
        pidfd_send_signal(self.fd, signum)

    def close(self):
        os.close(self.fd)


def service_value(name, unit=PARENT_UNIT):
    return subprocess.check_output(['systemctl', '--user', 'show', unit,
                                    '--property=' + name, '--value'], text=True, timeout=15).strip()


def recover_paused_scheduler(request_path):
    """ExecStopPost fallback: never leave the old scheduler frozen on failure."""
    root = request_path.resolve().parent
    if not (root / 'checks/active_handoff.json').exists() or (root / 'checks/handoff_completed.json').exists():
        return
    request = read(request_path)
    parent = Path(request['parent'])
    if (request.get('version') != VERSION or request.get('parent_unit') != PARENT_UNIT
            or file_sha(parent / 'control.json') != request['parent_control_sha256']):
        raise ValueError('Refusing recovery of an unrelated scheduler.')
    pid = request['original_control']['pid']
    if service_value('MainPID') != str(pid):
        return
    process = PinnedProcess(pid, parent / 'manifest.json', 'repair_stage2_resource_rl_v5.py')
    try:
        if process.info()['state'] in ('T', 't'):
            process.send(signal.SIGCONT)
    finally:
        process.close()


def handoff(request_path):
    request_path = request_path.resolve()
    request, _ = validate_request(request_path)
    root, parent = request_path.parent, Path(request['parent'])
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Only GPU0 and the original CPU half are authorized.')
    os.sched_setaffinity(0, cpus('30-31,94-95'))
    marker = root / 'handoff_started.json'
    with marker.open('x') as handle:
        json.dump(dict(pid=os.getpid(), started_unix=time.time(), authorization_sha256=file_sha(request_path)), handle)
    scheduler = worker = None
    paused, retired = False, False
    started = time.time()

    def stop(signum, frame):
        raise KeyboardInterrupt(f'Operator/service signal {signum}')

    signal.signal(signal.SIGTERM, stop)
    try:
        own_unit = os.environ.get('STAGE2_TIME_WAIVER_UNIT', '')
        if (not re.fullmatch(r'hkbz-stage2-split-v5-20260909-gpu0-half-r[0-9]+\.service', own_unit)
                or service_value('MainPID', own_unit) != str(os.getpid())
                or service_value('RuntimeMaxUSec', own_unit) != 'infinity'):
            raise ValueError('The exact new controller service must have no wall-clock limit.')
        old_pid = int(service_value('MainPID'))
        if old_pid:
            if old_pid != request['original_control']['pid']:
                raise ValueError('Old systemd service MainPID changed.')
            scheduler = PinnedProcess(old_pid, parent / 'manifest.json', 'repair_stage2_resource_rl_v5.py')
            worker = PinnedProcess(read(parent / 'workers/setup/run_status.json')['pid'],
                parent / 'manifest.json', 'run_stage2_resource_rl_v5.py', phase='setup', parent_pid=old_pid)
            # RuntimeMaxUSec is not live-settable on this host. The legacy
            # service exists only until its already-running setup completes;
            # neither that service nor its deadline is reused for Stage B.
            old_runtime_max = service_value('RuntimeMaxUSec')
            scheduler.send(signal.SIGSTOP)
            paused = True
            for _ in range(50):
                if scheduler.info()['state'] in ('T', 't'):
                    break
                time.sleep(.1)
            else:
                raise RuntimeError('Could not pause only the old scheduler.')
            atomic_json(root / 'checks/active_handoff.json', dict(passed=True,
                old_controller_pid=old_pid, setup_worker_pid=worker.pid,
                setup_worker_start_ticks=worker.start_ticks, controller_paused=True,
                setup_worker_interrupted=False, old_service_runtime_max=old_runtime_max,
                new_service_unit=own_unit, new_service_runtime_max='infinity',
                retained_setup_legacy_clock=True, old_deadline_not_inherited_by_training=True,
                user_request=request['user_request'], updated_unix=time.time()))
            while True:
                state = read(parent / 'workers/setup/run_status.json')
                info = worker.info()
                if state['status'] not in ('running', 'completed'):
                    raise RuntimeError('Original setup failed; no retry or scientific training is authorized.')
                if info['state'] == 'Z':
                    if state['status'] != 'completed' or info['exit_wait_status'] != 0:
                        raise RuntimeError('Setup did not exit successfully; no automatic retry.')
                    exit_evidence = dict(pid=worker.pid, start_ticks=worker.start_ticks,
                                         exit_code=0, raw_wait_status=0, verified_at=time.time())
                    break
                if state['status'] == 'completed' and info['state'] in ('T', 't'):
                    raise RuntimeError('Setup was unexpectedly stopped externally.')
                atomic_json(root / 'run_status.json', dict(status='running', phase='waiting_for_retained_setup',
                    pid=os.getpid(), started_unix=request['original_control']['started_unix'],
                    process_started_unix=started, process_elapsed_seconds=time.time() - started,
                    updated_unix=time.time(), hard_deadline_unix=None, wall_clock_limit_enabled=False,
                    projected_time_gate_enabled=False, time_authorization_version=VERSION,
                    parent=str(parent), live_setup=state, old_scheduler_paused=True,
                    retained_setup_timer_changed=False,
                    retained_setup_internal_deadline_unix=state.get('hard_deadline_unix'),
                    completed_physical_case_episodes=96 + state.get('completed_physical_case_episodes', 0),
                    completed_training_case_episodes=0, automatic_retry=False, scientific_success_confirmed=False))
                time.sleep(15)
            validate_completed_setup(parent, read(parent / 'manifest.json'))
            # Queue TERM while stopped, then CONT: the Python handler executes
            # before the old scheduler can dispatch any formal training worker.
            scheduler.send(signal.SIGTERM)
            scheduler.send(signal.SIGCONT)
            paused = False
            for _ in range(100):
                if service_value('MainPID') == '0':
                    retired = True
                    break
                time.sleep(.2)
            if not retired:
                raise RuntimeError('Old scheduler has not exited; refusing competing training controllers.')
        else:
            status = read(parent / 'run_status.json')
            if status.get('status') != 'budget_blocked' or status.get('phase') != 'initial_evaluation_and_reference':
                raise ValueError('Inactive parent is not a completed-setup budget stop.')
            records = [r for r in status['worker_exit_records'] if r.get('phase') == 'setup'
                       and r.get('exit_code') == 0 and not r.get('retained_from_previous_process')]
            if len(records) != 1:
                raise ValueError('Missing successful setup process exit.')
            exit_evidence = {**records[0], 'verified_at': time.time()}
        manifest = finalize_manifest(request_path, exit_evidence)
        atomic_json(root / 'checks/handoff_completed.json', dict(passed=True,
            setup_worker_restarted=False, engineering_repeated=False, setup_repeated=False,
            old_products_retained=True, scientific_code_unchanged=True, updated_unix=time.time()))
        return UnlimitedController(manifest).run()
    except BaseException as exc:
        atomic_json(root / 'run_status.json', dict(status='stopped' if isinstance(exc, KeyboardInterrupt) else 'failed',
            phase='time_limit_handoff', pid=os.getpid(), updated_unix=time.time(), error=str(exc),
            traceback=traceback.format_exc(), automatic_retry=False, scientific_success_confirmed=False))
        print(traceback.format_exc(), flush=True)
        return 1
    finally:
        if scheduler is not None:
            if paused and not retired:
                try:
                    scheduler.send(signal.SIGCONT)
                except ProcessLookupError:
                    pass
            scheduler.close()
        if worker is not None:
            worker.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest='mode', required=True)
    prepare = modes.add_parser('authorize')
    prepare.add_argument('--parent', type=Path, required=True)
    prepare.add_argument('--output', type=Path, required=True)
    prepare.add_argument('--run-tag', required=True)
    prepare.add_argument('--deployment-repair-of', type=Path)
    run = modes.add_parser('handoff')
    run.add_argument('--authorization', type=Path, required=True)
    recovery = modes.add_parser('recover')
    recovery.add_argument('--authorization', type=Path, required=True)
    cli = parser.parse_args()
    if cli.mode == 'authorize':
        authorize(cli.parent, cli.output, cli.run_tag, cli.deployment_repair_of)
    elif cli.mode == 'recover':
        recover_paused_scheduler(cli.authorization)
    else:
        sys.exit(handoff(cli.authorization))
