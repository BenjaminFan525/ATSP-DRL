#!/usr/bin/env python3
"""Model-only CUDA initialization/restore check. Zero environment episodes."""
import argparse
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, cpus, seed
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_resource_rl import file_sha, reset_critic
from onpolicy.utils.stage2_resource_rl_v4_resume import assert_tree_equal
from onpolicy.utils.stage2_resource_rl_v5 import (
    ARMS, DEFAULTS, SplitEncoderLearner, assert_no_alias, restore_training_state, training_state,
)


def main(manifest, output):
    if output.exists() or os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('New report and physical GPU0 required.')
    if not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Outside authorized CPU half.')
    m = json.loads(manifest.read_text())
    m['training_contract'] = dict(DEFAULTS)
    source = torch.load(m['source']['path'], map_location='cpu', weights_only=True)
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.2, 0)
    args = arguments(m)
    for k, v in ready_head_config(source).items():
        setattr(args, k, v)
    config = yaml.safe_load(Path(args.ac_config).read_text())
    results = {}
    def make(arm):
        seed(DEFAULTS['seed'] + 100000)
        policy = GNN_MAPPOPolicy(args, config, torch.device('cuda:0'))
        policy.load_model_state(source['model'])
        policy.ac.tau, policy.ac.device_global_matching = args.evaluation_tau, False
        policy.capture_bc_reference(source['model'])
        seed(DEFAULTS['seed'] + 200000)
        reset_critic(policy.ac)
        return SplitEncoderLearner(policy, args, dict(DEFAULTS), lambda *a, **k: None, arm=arm)
    for arm in ARMS:
        original, restored = make(arm), make(arm)
        count = assert_no_alias(original.policy.ac, original.policy.bc_reference_ac)
        sum(p.square().sum() for p in original.actor_params).backward()
        original.actor_optim.step()
        original.actor_optim.zero_grad(set_to_none=True)
        original.actor_steps = 1
        state = training_state(original)
        restore_training_state(restored, state)
        assert_tree_equal(state, training_state(restored), 'CUDA optimizer/weights/RNG')
        results[arm] = dict(passed=True, nonoverlapping_tensors=count, restore_equal=True,
                            copied_encoders=original.initial_architecture['encoders'])
        del original, restored, state
    atomic_json(output, dict(passed=True, updated_unix=time.time(), arms=results,
        environment_case_episodes=0, scientific_updates=0, synthetic_test_updates_discarded=True,
        code_fingerprint={p: file_sha(ROOT / p) for p in (
            'onpolicy/utils/stage2_resource_rl_v5.py',
            'onpolicy/scripts/train/check_stage2_resource_rl_v5_gpu.py')},
        gpu_uuid=str(torch.cuda.get_device_properties(0).uuid), cpu_affinity=sorted(os.sched_getaffinity(0))))
    print(output, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    cli = parser.parse_args()
    main(cli.manifest, cli.output)
