#!/usr/bin/env python3
"""Finite, non-retrying Phase A -> canary -> pilot controller, GPU0 only."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from onpolicy.scripts.train.run_stage2_bc_injection_suite import stop_owned, verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json


def run(cli):
    manifest_path = cli.manifest.resolve()
    manifest = json.loads(manifest_path.read_text())
    verify_resources(manifest)
    if manifest['profile'] != 'diagnostic':
        raise ValueError('The pipeline must start at Phase A.')
    suite = manifest_path.parent
    state_path = suite / 'pipeline_state.json'
    if state_path.exists():
        raise FileExistsError('No automatic controller restart/retry.')
    state = dict(status='running', phase='diagnostic', started_unix_time=time.time(),
        manifest=str(manifest_path), physical_gpu=0, allowed_cpus='0-31,64-95',
        stage3_started=False, rl_started=False, automatic_retry=False, phases={})
    child = None
    hard_timeout = manifest['resource_contract']['hard_timeout_seconds']
    deadline = time.monotonic() + hard_timeout

    def execute(command, label):
        nonlocal child
        log = suite / f'{label}.log'
        with log.open('x') as handle:
            child = subprocess.Popen(command, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            state['phase'] = label
            state['phases'][label] = dict(command=command, pid=child.pid, status='running',
                started_unix_time=time.time(), log=str(log))
            while child.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Declared 48-hour pipeline limit reached; no retry.')
                state['updated_unix_time'] = time.time()
                state['output_stall_advisory'] = time.time() - log.stat().st_mtime > 300
                atomic_json(state_path, state)
                print(f'[CostPipeline] phase={label} pid={child.pid} '
                      f'elapsed={time.time()-state["started_unix_time"]:.0f}s', flush=True)
                time.sleep(30)
            code = child.returncode
            state['phases'][label].update(status='completed' if code == 0 else 'failed',
                exit_code=code, ended_unix_time=time.time())
            child = None
            atomic_json(state_path, state)
            return code

    try:
        code = execute([sys.executable, '-u', str(ROOT / 'onpolicy/scripts/train/diagnose_stage2_cost_improvement.py'),
                        '--manifest', str(manifest_path)], 'diagnostic')
        diagnostic_proof = suite / 'diagnostics/report.json'
        if code:
            state.update(status='held_at_diagnostic_gate' if code == 2 else 'failed',
                reason='No training was started. Inspect the Phase-A report; no automatic retry.')
            return code
        prior_canary = None
        for profile in ('canary', 'pilot'):
            tag = manifest['run_tag'] + '_' + profile
            destination = suite.parent / tag
            command = [sys.executable, str(ROOT / 'onpolicy/scripts/train/prepare_stage2_cost_improvement.py'),
                '--profile', profile, '--run-tag', tag, '--suite-dir', str(destination),
                '--python', sys.executable, '--diagnostic-proof', str(diagnostic_proof)]
            if prior_canary:
                command += ['--canary-proof', str(prior_canary)]
            if execute(command, f'prepare_{profile}'):
                state.update(status='failed', reason=f'{profile} preparation failed; not retried.')
                return 1
            if execute([sys.executable, '-u', str(ROOT / 'onpolicy/scripts/train/run_stage2_bc_injection_suite.py'),
                        '--manifest', str(destination / 'manifest.json')], profile):
                state.update(status='failed', reason=f'{profile} failed; later stages not started.')
                return 1
            prior_canary = destination / 'analysis/comparison.json'
        state.update(status='completed', reason='N0-N3 pilot and analysis completed; no RL/Stage3 promotion.')
        return 0
    except BaseException as error:
        state.update(status='failed', error=str(error))
        raise
    finally:
        if child is not None:
            stop_owned(child)
        state['ended_unix_time'] = time.time()
        atomic_json(state_path, state)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    raise SystemExit(run(parser.parse_args()))
