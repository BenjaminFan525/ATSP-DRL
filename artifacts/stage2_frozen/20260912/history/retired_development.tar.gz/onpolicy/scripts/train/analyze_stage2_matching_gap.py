#!/usr/bin/env python3
"""Audit all matching/wait arms and report exploratory, hash-paired IGA gaps."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys

import torch

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.analyze_stage2_bc_injection import analyze as integrity_audit
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import json_safe
from onpolicy.utils.stage2_blocking_audit import audit_blocking_coverage, uses_fixed_blocking_coverage
from onpolicy.utils.stage2_iga_contract import (
    GROUPS, file_digest, checked_cases, distribution_metrics,
    paired_iga_comparison, iga_target_diagnostics,
)
from onpolicy.utils.stage2_matching import MATCHING_CONTRACT, SUPERVISION_CONTRACT
from onpolicy.utils.training_stage import validate_stage2_joint_finetune_checkpoint


def select_safe_epoch(evaluations, eligible_epochs):
    """A single whole-dataset checkpoint, with a strict unchanged-source fallback."""
    origin = distribution_metrics(evaluations[0])
    candidates = [(origin['raw'], 0)]
    for epoch in eligible_epochs:
        metrics = distribution_metrics(evaluations[epoch])
        if all(origin[key] is None or (metrics[key] is not None and metrics[key] <= origin[key])
               for key in ('raw', *GROUPS, 'tail10')):
            candidates.append((metrics['raw'], epoch))
    return min(candidates)[1]


def analyze(manifest_path, *, canary_gate=True, publish=True):
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text())
    suite = manifest_path.parent
    for relative, expected in manifest['code_fingerprint'].items():
        if file_digest(ROOT / relative) != expected:
            raise ValueError(f'Source changed during experiment: {relative}')
    reference = manifest['iga_reference_audit']
    if file_digest(reference['path']) != reference['sha256']:
        raise ValueError('IGA audit changed.')
    baselines = json.loads(Path(reference['path']).read_text())['baselines']
    for baseline in baselines.values():
        for path, expected in baseline['source_files'].items():
            if file_digest(path) != expected:
                raise ValueError(f'IGA source changed: {path}')
    fixed_coverage = uses_fixed_blocking_coverage(manifest)
    report = integrity_audit(manifest_path, publish=False)
    scientific = manifest['scientific_result']
    references = {name: json.loads(Path(source['evaluation']).read_text())
                  for name, source in manifest['warmstart_sources'].items()}
    selected, all_rows = {}, []
    for key, method in report['methods'].items():
        entry = manifest['commands'][key]
        run = Path(method['run_dir'])
        source = entry['warmstart_source']
        if file_digest(source['path']) != source['sha256']:
            raise ValueError('Warm-start source changed.')
        pre = torch.load(run / 'models/checkpoint_PreSupervised.pt', map_location='cpu', weights_only=True)
        origin = torch.load(source['path'], map_location='cpu', weights_only=True)
        if set(pre['model']) != set(origin['model']) or any(
                not torch.equal(value, origin['model'][name]) for name, value in pre['model'].items()):
            raise ValueError(f'{key} did not start from exact B0 source weights.')
        fork = pre.get('stage2_policy_warmstart') or {}
        if (fork.get('optimizer_restored') is not False or fork.get('rng_restored') is not False
                or pre['stage2_bc_state']['completed_epochs'] != 0
                or pre.get('supervised_optimizer') is not None
                or pre.get('device_bc_skip_ready_targets') is not True):
            raise ValueError(f'{key} violated the fresh-fork/no-ready-label contract.')
        expected_contract = {'decoder': MATCHING_CONTRACT, 'supervision': SUPERVISION_CONTRACT,
                             'teacher_decoder': manifest['matching_contract']['teacher_decoder'],
                             'audit': True, 'full_edge_coef': entry['full_edge_coef'],
                             'empty_wait_coef': entry['empty_wait_coef']}
        for field, value in expected_contract.items():
            if pre.get('stage2_matching_contract', {}).get(field) != value:
                raise ValueError(f'{key} checkpoint has a different matching contract: {field}')
        if scientific:
            replay = pre.get('stage2_policy_warmstart_replay') or {}
            if not replay.get('passed') or replay.get('max_absolute_case_delta_seconds') != 0.:
                raise ValueError(f'{key} lacks an exact 60-case pre-gradient replay.')
        evaluations = {epoch: json.loads((run / 'evaluations' / (
            'pre_supervised.json' if epoch == 0 else f'bc_epoch_{epoch}.json')).read_text())
            for epoch in (0, 1, 2)}
        trained = [json.loads(line) for line in
                   (run / 'logs/request_ready_epoch_metrics.jsonl').read_text().splitlines()]
        if [row['device_bc_epoch'] for row in trained] != [1, 2]:
            raise ValueError(f'{key} has missing or duplicate training epochs.')
        for training_index, metrics in enumerate(trained):
            teacher_rate = entry.get('teacher_execution_schedule', [1., 1.])[training_index]
            if (metrics['device_bc_rollouts'] != manifest['training_contract']['rollouts_per_epoch']
                    or metrics['device_bc_optimizer_steps'] <= 0
                    or metrics['device_bc_teacher_execution_target'] != teacher_rate
                    or (teacher_rate == 1. and metrics['student_executed_envs'] != 0)
                    or (teacher_rate < 1. and metrics['student_executed_envs'] <= 0)
                    or metrics['teacher_executed_envs'] <= 0
                    or metrics['request_ready_total_labels'] != 0
                    or metrics.get('device_bc_matching_audit_passed') is not True
                    or metrics.get('device_bc_deploy_rows', 0) <= 0):
                raise ValueError(f'{key} violated training/teacher/matching audit budget.')
            if metrics.get('teacher_projection_checked', 0) <= 0:
                raise ValueError(f'{key} did not execute the explicit derived-teacher contract.')
            if (manifest['profile'] == 'canary' and not fixed_coverage
                    and metrics.get('teacher_projection_events', 0) <= 0):
                raise ValueError(f'{key} canary never exercised the Blocking repair.')
            if entry['full_edge_coef'] > 0 and metrics.get('device_bc_full_edge_groups', 0) <= 0:
                raise ValueError(f'{key} did not exercise physical-edge supervision.')
            if scientific and entry['empty_wait_coef'] > 0 and metrics.get('device_bc_wait_eligible_groups', 0) < 1:
                raise ValueError(f'{key} has no meaningful all-wait supervision in an epoch.')
        eligible = [row['epoch'] for row in method['epoch_metrics'] if row['gate']['passed']]
        epoch = select_safe_epoch(evaluations, eligible)
        selected[key] = evaluations[epoch]
        checkpoint_path = Path(source['path']) if epoch == 0 else run / f'models/checkpoint_BCEpoch{epoch}.pt'
        if epoch > 0 and epoch == method['selected_epoch']:
            checkpoint_path = run / 'models/checkpoint_Best.pt'
        checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
        # A stricter group/tail selection can nominate a different saved epoch.
        # Check its prospective payload, without rewriting a raw epoch as a
        # completed/approved Stage3 artifact or promoting it automatically.
        exported_handoff = checkpoint.get('phase') == 'resource_supervised_completed'
        handoff_payload = checkpoint if exported_handoff else {
            **checkpoint, 'phase': 'resource_supervised_completed', 'selected_bc_epoch': epoch}
        validate_stage2_joint_finetune_checkpoint(
            handoff_payload, checkpoint['model'], plane_order_mode=checkpoint['plane_order_mode'],
            plane_pair_decoder=checkpoint['plane_pair_decoder'], global_feature_mode=checkpoint['global_feature_mode'],
            planning_contract=checkpoint['resource_lookahead_contract'],
            request_ready_time_scale=checkpoint['request_ready_time_scale'])
        method.update({
            'effective_epoch': epoch, 'retained_source': epoch == 0,
            'effective_checkpoint': str(checkpoint_path), 'warmstart_exact': True,
            'distribution_metrics': distribution_metrics(evaluations[epoch]),
            'versus_own_source': paired_iga_comparison(evaluations[epoch], evaluations[0]),
            'matching_training_metrics': [{name: value for name, value in row.items()
                if name.startswith(('device_bc_', 'teacher_executed_', 'student_executed_', 'teacher_projection_'))} for row in trained],
            'legacy_metrics_note': 'assignment_exact/f1 retain the legacy request-set definition; deploy_* use the actual Blocking-priority decoder.',
            'stage3_static_handoff_passed': exported_handoff,
            'stage3_prospective_payload_compatible': True, 'stage3_dynamic_transfer_tested': False,
            'confirmed_scientific_success': False,
        })
        if scientific:
            method['iga_diagnostics'] = iga_target_diagnostics(evaluations[epoch], baselines)
            method['all_epoch_iga_diagnostics'] = {str(i): iga_target_diagnostics(value, baselines)
                                                  for i, value in evaluations.items()}
            method['versus_frozen_references'] = {name: paired_iga_comparison(evaluations[epoch], value)
                                                  for name, value in references.items()}
            strong = distribution_metrics(references['D_B0'])
            target = distribution_metrics(baselines['IGA1800'])
            gap = strong['raw'] - target['raw']
            closed = (strong['raw'] - method['distribution_metrics']['raw']) / gap if gap > 0 else None
            method['iga1800_gap_closed_fraction_vs_D_B0'] = closed
            method['screen_threshold_passed'] = bool(closed is not None
                and closed >= manifest['analysis_contract']['gap_closure_screen_fraction']
                and method['versus_frozen_references']['D_B0']['all_group_tail_point_nonworse'])
        for index, evaluation in evaluations.items():
            for row in checked_cases(evaluation).values():
                all_rows.append({'method': key, 'epoch': index, 'case_sha256': row['case_sha256'],
                    'distribution': row['distribution'], 'profile': row.get('profile'),
                    'cmax': row['makespan'], 'effective_selection': index == epoch})
    if fixed_coverage and manifest['profile'] == 'canary':
        report['blocking_repair_coverage'] = audit_blocking_coverage(manifest, report['methods'])
    report.update({
        'research_family': manifest['research_family'], 'analysis_contract': manifest['analysis_contract'],
        'scientific_result': scientific, 'canary_contract_passed': manifest['profile'] == 'canary' and canary_gate,
        'confirmed_scientific_success': False, 'formal_promotion': False, 'stage3_training_started': False,
        'iga_reference_audit': reference,
        'paired_comparisons': {f'{left}_minus_{right}': paired_iga_comparison(
            selected[left + '_seed11'], selected[right + '_seed11'])
            for left, right in manifest['analysis_contract']['contrasts']},
        'note': 'Engineering canary or tune-selected one-seed pilot. IGA comparisons are historical-budget diagnostics, not formal confirmation.',
    })
    if publish:
        atomic_json(suite / 'analysis/comparison.json', json_safe(report))
    # CSV contains observations only, never a success/approval flag.
    (suite / 'analysis').mkdir(parents=True, exist_ok=True)
    with (suite / 'analysis/all_epoch_cases.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_rows[0]))
        writer.writeheader()
        writer.writerows(all_rows)
    if publish:
        print(json.dumps({'integrity_passed': True, 'methods': len(report['methods']),
                          'canary_contract_passed': report['canary_contract_passed'],
                          'confirmed_scientific_success': False}))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    analyze(parser.parse_args().manifest)
