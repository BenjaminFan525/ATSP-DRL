#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_PYTHON=/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11
TASK_REQUEST="$(realpath -- "${1:?Pass the explicit four-arm authorization}")"
TASK_OUTPUT="$(dirname -- "${TASK_REQUEST}")"
TASK_UNIT=hkbz-stage2-split-v5-20260909-gpu0-half-r8
[[ -f "${TASK_REQUEST}" && ! -e "${TASK_OUTPUT}/started.json" ]] || { echo 'One-shot authorization required; no retry' >&2; exit 1; }
systemd-run --user --unit="${TASK_UNIT}" --working-directory="${TASK_ROOT}" \
  --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
  --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 --setenv=OPENBLAS_NUM_THREADS=1 \
  --setenv=NUMEXPR_NUM_THREADS=1 --setenv=PYTHONHASHSEED=0 --setenv=PYTHONDONTWRITEBYTECODE=1 \
  --setenv=CUBLAS_WORKSPACE_CONFIG=:4096:8 --setenv=MPLCONFIGDIR="${TASK_OUTPUT}/mplconfig" \
  --property=Type=exec --property=Restart=no --property=KillMode=control-group \
  --property=RuntimeMaxSec=infinity --property=TimeoutStopSec=30 --property=LimitNOFILE=65536 \
  --property=AllowedCPUs=0-31,64-95 --property=CPUAffinity=0-31,64-95 \
  --property="ExecStopPost=${TASK_PYTHON} ${TASK_ROOT}/onpolicy/scripts/train/expedite_stage2_resource_rl_v5.py recover --authorization ${TASK_REQUEST}" \
  --property="StandardOutput=append:${TASK_OUTPUT}/controller.log" \
  --property="StandardError=append:${TASK_OUTPUT}/controller.log" \
  "${TASK_PYTHON}" -u "${TASK_ROOT}/onpolicy/scripts/train/expedite_stage2_resource_rl_v5.py" \
  run --authorization "${TASK_REQUEST}"
printf 'Started %s: retain E0/E1, start E2/E3 once; GPU0/original CPU half; serialized evaluation; no wall-clock gate\n' "${TASK_UNIT}"
