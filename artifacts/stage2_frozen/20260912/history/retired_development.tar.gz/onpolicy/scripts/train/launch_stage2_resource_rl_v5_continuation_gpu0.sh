#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_PYTHON="${PYTHON:-/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
TASK_MANIFEST="$(realpath -- "${1:?Pass a newly authorized V5 continuation manifest}")"
TASK_SUITE="$(dirname -- "${TASK_MANIFEST}")"
TASK_UNIT="${UNIT_NAME:-hkbz-stage2-split-v5-20260909-gpu0-half-r3}"
[[ "${TASK_UNIT}" =~ ^[a-zA-Z0-9_-]+$ ]] || exit 1
[[ -f "${TASK_MANIFEST}" && ! -e "${TASK_SUITE}/control.json" ]] || { echo 'New continuation only; no auto-retry' >&2; exit 1; }
TASK_LIMIT="$("${TASK_PYTHON}" -c 'import json,sys; m=json.load(open(sys.argv[1])); print(m["budget_continuation"]["authorized_runtime_seconds"])' "${TASK_MANIFEST}")"
[[ "${TASK_LIMIT}" == 108000 ]] || { echo 'Expected explicit 30-hour continuation authorization' >&2; exit 1; }
systemd-run --user --unit="${TASK_UNIT}" --working-directory="${TASK_ROOT}" \
  --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
  --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 --setenv=OPENBLAS_NUM_THREADS=1 \
  --setenv=NUMEXPR_NUM_THREADS=1 --setenv=PYTHONHASHSEED=0 --setenv=PYTHONDONTWRITEBYTECODE=1 \
  --setenv=CUBLAS_WORKSPACE_CONFIG=:4096:8 --setenv=MPLCONFIGDIR="${TASK_SUITE}/mplconfig" \
  --property=Type=exec --property=Restart=no --property=KillMode=control-group \
  --property=RuntimeMaxSec="${TASK_LIMIT}" --property=TimeoutStopSec=10 --property=LimitNOFILE=65536 \
  --property=AllowedCPUs=0-31,64-95 --property=CPUAffinity=0-31,64-95 \
  --property="StandardOutput=append:${TASK_SUITE}/controller.log" \
  --property="StandardError=append:${TASK_SUITE}/controller.log" \
  "${TASK_PYTHON}" -u "${TASK_ROOT}/onpolicy/scripts/train/continue_stage2_resource_rl_v5.py" \
  run --manifest "${TASK_MANIFEST}"
printf 'Started %s: new 30-hour budget, retain engineering96, GPU0 + CPU 0-31,64-95\n' "${TASK_UNIT}"
