#!/usr/bin/env python3
"""Bounded, read-only-model reproduction of r3's first zero-update audit error.

Runs at most the first 260 steps of the original 12-case evaluation batch.
No optimizer steps, no training, no automatic retries. All diagnostic artifacts
go to a new directory; original experiment artifacts are never modified.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import signal
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import yaml
from onpolicy.scripts.train.run_stage2_resource_rl import Progress, arguments, cpus
from onpolicy.scripts.train.run_stage2_resource_rl_v5 import SplitSuite
from onpolicy.scripts.train.run_stage2_resource_rl_v4 import save_tensor_artifact
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v4_fast import FastCaseMinibatchLearner


def differences(actual, reference):
    result = {}
    for key in ('log_probs', 'rnn_states', 'actions', 'decision_mask', 'resource_logits'):
        x, y = actual[key], reference[key]
        finite = torch.isfinite(x) & torch.isfinite(y)
        delta = torch.where(finite, (x.float() - y.float()).abs(), torch.zeros_like(x, dtype=torch.float32))
        mismatches = torch.nonzero((x != y) & finite)
        result[key] = dict(max_error=float(delta.max()), equal=torch.equal(x, y),
            finite_support_equal=torch.equal(torch.isfinite(x), torch.isfinite(y)),
            differing_entries=int(mismatches.shape[0]), locations=mismatches[:12].cpu().tolist())
    return result


class PrefixComplete(Exception):
    pass


def inspect_fixture(manifest, fixture_path, output):
    """Localize the first differing module using a saved input, no environment."""
    if output.exists() or os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('New output and GPU0 required.')
    if not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Outside authorized CPU half.')
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.2, 0)
    suite = SplitSuite(manifest, 'setup', 'E0', 0)
    suite.args = arguments(suite.m)
    suite.payload = torch.load(suite.m['source']['path'], map_location='cpu', weights_only=True)
    for k, v in ready_head_config(suite.payload).items():
        setattr(suite.args, k, v)
    suite.ac_config = yaml.safe_load(Path(suite.args.ac_config).read_text())
    suite.progress = lambda *a, **k: None
    learner = suite.policy('E0')
    policy = learner.policy
    policy.ac.eval()
    policy.bc_reference_ac.eval()
    # This is our own just-created local graph fixture, not an external pickle.
    fixture = torch.load(fixture_path, map_location='cpu', weights_only=False)
    args = [fixture['obs']] + [fixture[k].numpy() for k in ('hidden', 'active', 'history', 'types')]
    traces = {'current': [], 'reference': []}
    def tensors(value):
        if isinstance(value, torch.Tensor):
            return [value.detach().clone().cpu()]
        if isinstance(value, (list, tuple)):
            return [t for v in value for t in tensors(v)]
        if isinstance(value, dict):
            return [t for v in value.values() for t in tensors(v)]
        return []
    handles = []
    for label, model in (('current', policy.ac), ('reference', policy.bc_reference_ac)):
        for name, module in model.named_modules():
            if name.startswith(('device_actor.', 'transporter_actor.', 'device_sel_enc.', 'transporter_sel_enc.')):
                def hook(mod, a, kw, out, label=label, name=name):
                    traces[label].append((name, tensors((a, kw)), tensors(out)))
                handles.append(module.register_forward_hook(hook, with_kwargs=True))
    try:
        with torch.no_grad():
            current, encoded = FastCaseMinibatchLearner.collect_forward(learner, policy, *args, deterministic=True)
            reference, _ = FastCaseMinibatchLearner.collect_forward(learner, policy, *args,
                deterministic=True, reference=True, encoded=encoded)
    finally:
        for handle in handles:
            handle.remove()
    def delta(xs, ys):
        if len(xs) != len(ys) or any(x.shape != y.shape for x, y in zip(xs, ys)):
            return 'shape_or_count_mismatch'
        return max([0.] + [float(torch.where(torch.isfinite(x) & torch.isfinite(y),
            (x.float() - y.float()).abs(), torch.zeros_like(x, dtype=torch.float32)).max())
            for x, y in zip(xs, ys) if x.numel()])
    differing = []
    for i, (cur, ref) in enumerate(zip(traces['current'], traces['reference'])):
        if cur[0] != ref[0]:
            raise ValueError('Different module call order.')
        error = delta(cur[2], ref[2])
        if error != 0.:
            differing.append(dict(call_index=i, module=cur[0], input_error=delta(cur[1], ref[1]), output_error=error))
    ref_parameters = dict(policy.bc_reference_ac.named_parameters())
    layouts = [dict(name=n, current_stride=list(p.stride()), reference_stride=list(ref_parameters[n].stride()),
                    current_offset=p.storage_offset(), reference_offset=ref_parameters[n].storage_offset())
               for n, p in policy.ac.named_parameters() if n in ref_parameters and
               (p.stride() != ref_parameters[n].stride() or p.storage_offset() != ref_parameters[n].storage_offset())]
    report = dict(fixture=str(fixture_path.resolve()), fixture_sha256=file_sha(fixture_path),
        new_environment_case_episodes=0, scientific_updates=0, differences=differences(current, reference),
        trace_lengths={k: len(v) for k, v in traces.items()}, first_differing_modules=differing[:30],
        parameter_layout_differences=layouts)
    first_attention = next((d for d in differing if d['module'].endswith('req_query_attn')), None)
    if first_attention:
        name, inputs, _ = traces['current'][first_attention['call_index']]
        q, k, _, mask = [x.to('cuda:0') for x in inputs]
        linear = torch.nn.functional.linear
        operations, variant_outputs = {}, {}
        for label in ('current', 'reference', 'reference_gradflags'):
            model = policy.ac if label == 'current' else policy.bc_reference_ac
            attention = dict(model.named_modules())[name]
            flags = [p.requires_grad for p in attention.parameters()]
            operations[label] = []
            def trace_linear(x, w, b=None):
                y = linear(x, w, b)
                operations[label].append(dict(input=x.detach().cpu().clone(), weight=w.detach().cpu().clone(),
                    bias=None if b is None else b.detach().cpu().clone(), output=y.detach().cpu().clone(),
                    input_stride=list(x.stride()), weight_stride=list(w.stride()),
                    bias_requires_grad=None if b is None else b.requires_grad,
                    weight_requires_grad=w.requires_grad))
                return y
            try:
                if label == 'reference_gradflags':
                    for p in attention.parameters():
                        p.requires_grad_(True)
                with torch.no_grad(), patch.object(torch.nn.functional, 'linear', trace_linear):
                    variant_outputs[label] = attention(q, k, k, key_padding_mask=mask)[0].detach().cpu()
            finally:
                for p, enabled in zip(attention.parameters(), flags):
                    p.requires_grad_(enabled)
        report['attention_variants'] = {label: float((v - variant_outputs['current']).abs().max())
                                        for label, v in variant_outputs.items()}
        report['linear_operations'] = {label: [dict(input_error=float((a['input'] - b['input']).abs().max()),
            weight_error=float((a['weight'] - b['weight']).abs().max()),
            output_error=float((a['output'] - b['output']).abs().max()),
            current_input_stride=a['input_stride'], other_input_stride=b['input_stride'],
            current_weight_stride=a['weight_stride'], other_weight_stride=b['weight_stride'])
            for a, b in zip(operations['current'], ops)] for label, ops in operations.items()}
    output.mkdir(parents=True, exist_ok=False)
    save_tensor_artifact(traces, output / 'layer_traces.pt')
    if first_attention:
        save_tensor_artifact(operations, output / 'attention_linear_traces.pt')
    atomic_json(output / 'report.json', report)
    print(json.dumps(report, indent=2), flush=True)
    return 0


def main(manifest, output):
    if output.exists() or os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('A new diagnostic directory and physical GPU0 are required.')
    if not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Outside the authorized CPU half.')
    suite = SplitSuite(manifest, 'setup', 'E0', 0)
    m = suite.m
    for name, digest in m['code_fingerprint'].items():
        if file_sha(ROOT / name) != digest:
            raise ValueError(f'Reproduction needs unchanged r3 code: {name}')
    if file_sha(m['source']['path']) != m['source']['sha256']:
        raise ValueError('B0 source changed.')
    rows = m['evaluation']['cases'][:12]
    validate_case_content(rows, m['evaluation']['dataset'])
    output.mkdir(parents=True, exist_ok=False)
    suite.root = suite.worker_root = output
    monitor = Progress(output, 600)
    def progress(event, **values):
        monitor(event, **values)
        if event == 'collect' and values.get('event_step', 0) >= 260:
            raise PrefixComplete('260-step diagnostic limit reached.')
    suite.progress = progress
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.2, 0)
    if str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') != m['resource_contract']['gpu_uuid'].removeprefix('GPU-'):
        raise ValueError('Wrong physical GPU.')
    suite.args = arguments(m)
    suite.payload = torch.load(m['source']['path'], map_location='cpu', weights_only=True)
    for k, v in ready_head_config(suite.payload).items():
        setattr(suite.args, k, v)
    suite.ac_config = yaml.safe_load(Path(suite.args.ac_config).read_text())
    learner = suite.policy('E0')
    learner.verify_initial_reference = True
    original = FastCaseMinibatchLearner.collect_forward
    state = dict(events=0)
    report = dict(version='v5_zero_update_reproduction_v1', source_manifest=str(manifest.resolve()),
        source_manifest_sha256=file_sha(manifest), source=m['source'], arm='E0',
        attempted_case_episodes=12, completed_case_episodes=0, scientific_updates=0,
        step_limit=260, hard_timeout_seconds=600, old_artifacts_retained=True,
        original_code_fingerprint=m['code_fingerprint'])
    def observed(self, policy, obs, hidden, active, history, types, **kwargs):
        result = original(self, policy, obs, hidden, active, history, types, **kwargs)
        if kwargs.get('actions') is None and not kwargs.get('reference', False):
            state['current'], state['encoded'] = result
        elif kwargs.get('actions') is None and kwargs.get('reference', False):
            state['events'] += 1
            diff = differences(state['current'], result[0])
            if (diff['log_probs']['max_error'] > 1e-6 or diff['rnn_states']['max_error'] > 1e-6
                    or not diff['actions']['equal'] or not diff['decision_mask']['equal']):
                fixture = dict(obs=[g.clone().cpu() for g in obs], hidden=torch.as_tensor(hidden).clone().cpu(),
                    active=torch.as_tensor(active).clone().cpu(), history=torch.as_tensor(history).clone().cpu(),
                    types=torch.as_tensor(types).clone().cpu(), cases=rows,
                    current={k: v.detach().clone().cpu() for k, v in state['current'].items()},
                    reference={k: v.detach().clone().cpu() for k, v in result[0].items()})
                save_tensor_artifact(fixture, output / 'failure_fixture.pt')
                cur_again = original(self, policy, obs, hidden, active, history, types,
                                     deterministic=True, encoded=state['encoded'])[0]
                ref_again = original(self, policy, obs, hidden, active, history, types,
                                     deterministic=True, reference=True, encoded=state['encoded'])[0]
                ref_fresh = original(self, policy, obs, hidden, active, history, types,
                                     deterministic=True, reference=True)[0]
                a, b = policy.ac.state_dict(), policy.bc_reference_ac.state_dict()
                report.update(reproduced=True, failing_event=state['events'], differences=diff,
                    same_current_repeated=differences(state['current'], cur_again),
                    same_reference_repeated=differences(result[0], ref_again),
                    fresh_reference_encoding=differences(state['current'], ref_fresh),
                    different_parameter_names=[k for k in b if not torch.equal(a[k], b[k])],
                    tau=[policy.ac.tau, policy.bc_reference_ac.tau],
                    module_mode_differences=[n for n, mod in policy.ac.named_modules()
                        if n in dict(policy.bc_reference_ac.named_modules())
                        and mod.training != dict(policy.bc_reference_ac.named_modules())[n].training])
                atomic_json(output / 'failure_details.json', report)
        return result
    def deadline(signum, frame):
        raise TimeoutError('Bounded diagnostic reached 600 seconds.')
    signal.signal(signal.SIGALRM, deadline)
    signal.alarm(600)
    try:
        with patch.object(FastCaseMinibatchLearner, 'collect_forward', observed):
            suite.collect_batch(learner, rows, evaluation=True, audit=True)
    except RuntimeError as exc:
        if str(exc) != 'Copied architecture is not zero-update equivalent to B0.' or not report.get('reproduced'):
            raise
        report['expected_original_error'] = str(exc)
    except PrefixComplete:
        report.update(reproduced=False, events=state['events'])
    finally:
        signal.alarm(0)
        monitor.stop.set()
        if suite.envs is not None:
            suite.envs.close()
    report.update(finished_unix=time.time(), actor_steps=learner.actor_steps, critic_steps=learner.critic_steps,
                  seconds=time.time() - monitor.started)
    atomic_json(output / 'report.json', report)
    print(json.dumps({k: v for k, v in report.items() if k != 'original_code_fingerprint'}, indent=2), flush=True)
    return 0 if report.get('reproduced') else 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--fixture', type=Path)
    args = parser.parse_args()
    sys.exit(inspect_fixture(args.manifest, args.fixture, args.output) if args.fixture else main(args.manifest, args.output))
