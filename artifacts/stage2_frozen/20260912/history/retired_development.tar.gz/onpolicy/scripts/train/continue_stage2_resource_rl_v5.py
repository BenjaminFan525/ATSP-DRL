#!/usr/bin/env python3
"""Explicit 30-hour V5 continuation after the completed engineering budget gate.

Only orchestration changes. All previously fingerprinted scientific code must
remain identical. The 96 passed engineering episodes are retained, never rerun;
their disposable weights are never used to initialize the scientific arms.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.control_stage2_resource_rl_v5 import Controller
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL

VERSION = 'v5_explicit_budget_continuation_v1'
AUTHORIZED_SECONDS = 30 * 3600
PROTOCOL_FILE = 'STAGE2_SPLIT_ENCODER_V5_BUDGET_CONTINUATION_20260909.md'
LAUNCHER = 'onpolicy/scripts/train/launch_stage2_resource_rl_v5_continuation_gpu0.sh'


def validate_stop_point(manifest, status, reports):
    if (manifest.get('protocol') != PROTOCOL or manifest.get('training_contract') != DEFAULTS
            or status.get('status') != 'budget_blocked'
            or status.get('phase') != 'engineering'
            or status.get('completed_training_case_episodes') != 0
            or status.get('attempted_physical_case_episodes') != 96
            or status.get('completed_physical_case_episodes') != 96
            or set(reports) != set(ARMS)):
        raise ValueError('Only the completed 96-case pre-training budget stop can continue here.')
    for arm, report in reports.items():
        if (report.get('arm') != arm or report.get('passed') is not True
                or report.get('completed_case_episodes') != 24
                or report.get('source_checkpoint') != manifest['source']
                or report.get('restored_weights_adam_rng_and_forward_equal') is not True
                or report.get('frozen_reference_unchanged') is not True
                or report.get('scientific_updates_discarded') is not True
                or report.get('fresh_production_initialization_required') is not True):
            raise ValueError(f'Incomplete retained engineering evidence for {arm}.')
        checks = report.get('minibatch_checks', {})
        if (checks.get('events', 0) <= 0
                or not 0 <= checks.get('max_logp_error', float('inf')) <= 1e-6
                or not 0 <= checks.get('max_ratio_error', float('inf')) <= 1e-5):
            raise ValueError(f'Probability audit failed for retained {arm}.')
        gradients = report.get('gradient_checks', {})
        if gradients.get('actor_backwards') != 8 or gradients.get('critic_updates') != 50:
            raise ValueError('Retained engineering did not run the full update.')
        if arm in ('E1', 'E3') and gradients.get('resource_encoder_nonzero') != 8:
            raise ValueError('Resource-encoder gradient evidence missing.')
        if arm in ('E2', 'E3') and gradients.get('value_encoder_nonzero') != 50:
            raise ValueError('Value-encoder gradient evidence missing.')
    records = status.get('worker_exit_records', [])
    if (len(records) != 4 or {r.get('arm') for r in records} != set(ARMS)
            or any(r.get('phase') != 'engineering' or r.get('exit_code') != 0 for r in records)):
        raise ValueError('Not all engineering workers exited successfully.')
    if len({r['trajectory_action_sha256'] for r in reports.values()}) != 1 or any(
            r['trajectory_cases'] != reports['E0']['trajectory_cases'] for r in reports.values()):
        raise ValueError('Retained same-seed initial trajectories differ.')
    return dict(passed=True, retained_engineering_case_episodes=96,
                remaining_case_episodes=2316 - 96, remaining_training_case_episodes=960,
                repeat_engineering=False, initialize_training_from='immutable_B0')


def read_parent(parent):
    manifest = json.loads((parent / 'manifest.json').read_text())
    status = json.loads((parent / 'run_status.json').read_text())
    reports = {a: json.loads((parent / 'engineering' / a / 'report.json').read_text()) for a in ARMS}
    proof = validate_stop_point(manifest, status, reports)
    if any((parent / name).exists() for name in ('workers', 'reference')):
        raise ValueError('Setup already started; refusing to repeat its cases.')
    if list((parent / 'evaluations').glob('*.json')) or any((parent / a).exists() for a in ARMS):
        raise ValueError('Evaluation/training artifacts already exist; this stop-point adapter cannot replay them.')
    for path, digest in manifest['code_fingerprint'].items():
        if file_sha(ROOT / path) != digest:
            raise ValueError(f'Code changed since the passed GPU engineering proof: {path}')
    for key in ('source', 'stage1_source', 'source_archive', 'parent_manifest', 'historical_b0_ar', 'iga_reference'):
        item = manifest[key]
        if file_sha(item['path']) != item['sha256']:
            raise ValueError(f'Immutable source changed: {key}')
    return manifest, status, reports, proof


def prepare(parent, suite, tag):
    parent, suite = parent.resolve(), suite.resolve()
    if suite.exists() or not tag.replace('_', '').replace('-', '').isalnum():
        raise ValueError('New directory and safe run tag required.')
    old, status, reports, proof = read_parent(parent)
    manifest = copy.deepcopy(old)
    manifest.pop('repair_of', None)  # Superseded only by the user's NEW time authorization.
    manifest['run_tag'] = tag
    manifest['created_at'] = datetime.now(timezone.utc).isoformat()
    manifest['resource_contract']['runtime_max_seconds'] = AUTHORIZED_SECONDS
    manifest['material_passport'] = dict(origin_skill='academic-research-suite/experiment-agent',
        origin_mode='run', origin_date='2026-09-09', verification_status='UNVERIFIED', version_label=VERSION)
    copies = [f'engineering/{a}/{name}' for a in ARMS for name in ('report.json', 'run_status.json')]
    retained = ['manifest.json', 'control.json', 'run_status.json', 'checks/preliminary_budget_gate.json'] + copies
    retained += [f'engineering/{a}/{name}' for a in ARMS for name in
                 ('update.json', 'discarded_engineering_checkpoint.pt', 'discarded_engineering_checkpoint.handoff.json')]
    manifest['budget_continuation'] = dict(version=VERSION, parent=str(parent),
        user_request='重新授权时间预算，然后继续实验', authorized_runtime_seconds=AUTHORIZED_SECONDS,
        clock_origin='new_controller_start_after_user_reauthorization',
        superseded_deadline_unix=status['hard_deadline_unix'],
        parent_status_sha256=file_sha(parent / 'run_status.json'),
        retained_artifacts={name: file_sha(parent / name) for name in retained}, copied_artifacts=copies,
        inherited_worker_exit_records=status['worker_exit_records'],
        immutable_prior_code_fingerprint=old['code_fingerprint'],
        first_phase='initial_evaluation_and_reference', prior_case_episodes=96,
        remaining_case_episode_limit=2220, remaining_training_case_episodes=960,
        engineering_weights_used_for_training=False, automatic_retry=False,
        no_automatic_stage_c=True, no_additional_seeds=True, source_artifacts_retained=True)
    fingerprints = code_fingerprint()
    for name in ('STAGE2_SPLIT_ENCODER_V5_20260909.md', PROTOCOL_FILE, LAUNCHER):
        fingerprints[name] = file_sha(ROOT / name)
    manifest['code_fingerprint'] = fingerprints
    suite.mkdir(parents=True, exist_ok=False)
    for name in copies:
        target = suite / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(parent / name, target)
        if file_sha(target) != manifest['budget_continuation']['retained_artifacts'][name]:
            raise ValueError('Retained engineering artifact changed while copying.')
    archive = suite / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for name, digest in fingerprints.items():
            content = (ROOT / name).read_bytes()
            if file_sha(ROOT / name) != digest:
                raise ValueError('Source changed during archive.')
            handle.addfile(handle.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(content))
    manifest['source_archive'] = dict(path=str(archive), sha256=file_sha(archive))
    atomic_json(suite / 'checks/retained_engineering.json', {**proof,
        'parent': str(parent), 'copied_artifacts': copies, 'scientific_code_unchanged': True})
    atomic_json(suite / 'manifest.json', manifest)
    print(suite / 'manifest.json', flush=True)


class BudgetController(Controller):
    def __init__(self, manifest):
        super().__init__(manifest)
        continuation = self.m.get('budget_continuation', {})
        if (continuation.get('version') != VERSION
                or continuation.get('authorized_runtime_seconds') != AUTHORIZED_SECONDS
                or 'repair_of' in self.m
                or continuation.get('remaining_case_episode_limit') != 2220
                or self.m['resource_contract']['runtime_max_seconds'] != AUTHORIZED_SECONDS):
            raise ValueError('Explicit unchanged-scope 30-hour authorization required.')
        self.deadline = self.started + AUTHORIZED_SECONDS
        self.records = [{**r, 'retained_from_previous_process': True}
                        for r in continuation['inherited_worker_exit_records']]

    def validate_continuation(self):
        c = self.m['budget_continuation']
        parent = Path(c['parent'])
        old, _, _, _ = read_parent(parent)
        for key in ('training_contract', 'source', 'stage1_source', 'train', 'evaluation', 'execution', 'screen'):
            if self.m[key] != old[key]:
                raise ValueError(f'Time reauthorization cannot change {key}.')
        expected_resources = {**old['resource_contract'], 'runtime_max_seconds': AUTHORIZED_SECONDS}
        if self.m['resource_contract'] != expected_resources:
            raise ValueError('Time reauthorization cannot change GPU/CPU/concurrency.')
        for name, digest in c['retained_artifacts'].items():
            if file_sha(parent / name) != digest:
                raise ValueError('Retained parent artifact changed.')
        for name in c['copied_artifacts']:
            if file_sha(self.root / name) != c['retained_artifacts'][name]:
                raise ValueError('Copied engineering artifact changed.')
        for name, digest in self.m['code_fingerprint'].items():
            if file_sha(ROOT / name) != digest:
                raise ValueError(f'Continuation code changed: {name}')

    def launch(self, phase, arm, slot):
        if phase == 'engineering':
            raise RuntimeError('Recollecting passed engineering cases is forbidden.')
        return super().launch(phase, arm, slot)

    def batch(self, phase, arms):
        if phase == 'engineering':
            if list(arms) not in (['E0', 'E1'], ['E2', 'E3']):
                raise ValueError('Unexpected retained engineering group.')
            print(json.dumps(dict(event='retained_engineering_reused', arms=list(arms),
                                  new_case_episodes=0, engineering_weights_loaded=False)), flush=True)
            return
        try:
            return super().batch(phase, arms)
        except TimeoutError as exc:
            raise TimeoutError('New user-authorized 30-hour deadline reached.') from exc

    def status(self, **extra):
        new_episodes = 0
        for name in ('setup', *ARMS):
            path = self.root / 'workers' / name / 'run_status.json'
            if path.exists():
                new_episodes += json.loads(path.read_text()).get('completed_physical_case_episodes', 0)
        return super().status(retained_engineering_case_episodes=96,
            completed_physical_case_episodes_this_process=new_episodes,
            remaining_case_episode_limit_this_process=2220,
            authorized_runtime_seconds=AUTHORIZED_SECONDS,
            continuation_parent=self.m['budget_continuation']['parent'], **extra)

    def run(self):
        self.validate_continuation()
        # Parent run retains every numerical/time gate and the existing two-slot
        # schedule. Only its completed engineering batches are skipped above.
        return super().run()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    maker = sub.add_parser('prepare')
    maker.add_argument('--parent', type=Path, required=True)
    maker.add_argument('--suite-dir', type=Path, required=True)
    maker.add_argument('--run-tag', required=True)
    runner = sub.add_parser('run')
    runner.add_argument('--manifest', type=Path, required=True)
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare(args.parent, args.suite_dir, args.run_tag)
    else:
        sys.exit(BudgetController(args.manifest).run())
