#!/usr/bin/env python3
"""Discarded train-only, zero-update prefixes for all H/F configurations."""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.prepare_stage2_bc_hf import fingerprints, inputs
from onpolicy.scripts.train.run_stage2_bc_hf import FrozenEvaluator, load_policy, verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl import seed
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_hf import GRID, binding, configure_args
from onpolicy.utils.stage2_resource_rl import summary


def run(output):
    if output.exists():
        raise FileExistsError('Never overwrite engineering evidence.')
    verify_resources()
    output.parent.mkdir(parents=True, exist_ok=True)
    started, before_sources = time.monotonic(), fingerprints()
    tests = ['onpolicy.envs.HKBZ.test.test_stage2_bc_hf',
             'onpolicy.envs.HKBZ.test.test_stage2_resource_rl_v4',
             'onpolicy.envs.HKBZ.test.test_stage2_resource_rl_v5_zero',
             'onpolicy.envs.HKBZ.test.test_stage2_matching_gap']
    test_log = output.with_suffix('.unittest.log')
    test_env = {**os.environ, 'CUDA_VISIBLE_DEVICES': ''}
    with test_log.open('x') as log:
        result = subprocess.run([sys.executable, '-m', 'unittest', '-v', *tests], cwd=ROOT,
                                stdout=log, stderr=subprocess.STDOUT, env=test_env)
    if result.returncode:
        atomic_json(output, dict(passed=False, regression_passed=False,
                    regression_log=binding(test_log), exit_code=result.returncode))
        return 1
    m = inputs()
    policy, args, source_check = load_policy(m)
    records = m['train']['cases'][:6]
    arms, envs = {}, None
    try:
        for arm in GRID:
            local = configure_args(copy.copy(args), arm)
            local.seed = 1
            local.max_train_cases = local.train_sampling_size = local.n_rollout_threads = 6
            learner = FrozenEvaluator(policy, local, lambda *a, **k: None)
            envs, _ = make_train_env(local, case_records=records,
                dataset_override=m['train']['dataset'])
            seed(1)
            obs, _, info = envs.reset()
            count = local.max_agent_num + local.max_device_num
            hidden = np.zeros((6, count, local.recurrent_N, local.hidden_size), np.float32)
            previous = np.full((6, count, 2), -1, np.int64)
            completed = np.zeros(6, bool)
            for step in range(64):
                active = np.asarray(info['active_agents'], np.float32).reshape(6, count, 1).copy()
                active[completed] = 0
                history = HKBZ_Runner._authoritative_policy_history(info, previous, local.max_agent_num)
                types = np.asarray(info['agent_types']).copy()
                with torch.no_grad():
                    out, _ = learner.collect_forward(policy, obs, hidden, active, history, types,
                        deterministic=True, hungarian=True)
                actions = out['actions'].cpu().numpy()
                obs, _, dones, info = envs.step(actions)
                hidden = out['rnn_states'].cpu().numpy()
                hidden[np.asarray(dones)] = 0
                completed |= np.asarray(dones).reshape(6, -1).all(-1)
                previous = actions
            envs.close(); envs = None
            if summary(policy.ac) != source_check['tensor_summary']:
                raise ValueError('Zero-update engineering changed source weights.')
            arms[arm] = dict(passed=True, prefix_case_count=6, event_steps=64,
                complete_scientific_episodes=0, diagnostics=learner.diagnostics,
                frozen_weights_unchanged=True)
            print(json.dumps(dict(phase='hf_engineering', arm=arm, passed=True,
                                  completed_arms=len(arms), total_arms=12)), flush=True)
        if fingerprints() != before_sources:
            raise ValueError('Source files changed during engineering.')
        report = dict(passed=True, regression_passed=True, regression_log=binding(test_log),
            arms=arms, source_check=source_check, prefix_train_cases=[r['case_sha256'] for r in records],
            full_evaluation=False, actor_updates=0, critic_updates=0, teacher_queries=0,
            search_calls=0, seconds=time.monotonic() - started, gpu=0,
            cpus=sorted(os.sched_getaffinity(0)), checked_sources=before_sources)
        atomic_json(output, report)
        print(json.dumps(dict(passed=True, output=str(output), seconds=report['seconds'])), flush=True)
        return 0
    except BaseException as exc:
        atomic_json(output, dict(passed=False, regression_passed=True, arms=arms,
            error=str(exc), traceback=traceback.format_exc(), checked_sources=before_sources,
            actor_updates=0, teacher_queries=0, full_evaluation=False))
        raise
    finally:
        if envs is not None:
            envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    sys.exit(run(parser.parse_args().output.resolve()))
