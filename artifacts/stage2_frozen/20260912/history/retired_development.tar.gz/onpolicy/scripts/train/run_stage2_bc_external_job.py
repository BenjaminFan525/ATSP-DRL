#!/usr/bin/env python3
"""Expedite B2 without restarting B0/B1 or duplicating the original queue job."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.shared_eval import parse_cpu_set, format_cpu_set
from onpolicy.utils.stage2_external_dispatch import acquire_job_lock, marker_path, process_identity

CPU_PLAN = {'B0_none_seed11': '0-7,64-71', 'B1_dag_seed11': '12-19,76-83',
            'B2_R1_seed11': '8-11,20-23,72-75,84-87'}
MONITOR_CPUS = '30-31,94-95'
EVAL_CPUS = '24-29,88-93'
LAUNCHER = 'onpolicy/scripts/train/run_stage2_resource_manifest_trial.py'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def group_members(root_pid):
    members = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == root_pid and fields[0] != 'Z':
                if path.stat().st_uid != os.getuid():
                    raise RuntimeError('Unexpected process owner in the training group.')
                members.append(int(path.name))
        except (FileNotFoundError, ProcessLookupError):
            pass
    return members


def rebalance_existing(state):
    """Pin the two existing process groups and every thread, without signals."""
    roots = {}
    original = {}
    for key in ('B0_none_seed11', 'B1_dag_seed11'):
        job = state['jobs'][key]
        pid = job['pid']
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        if int(fields[1]) != state['controller_pid'] or int(fields[2]) != pid:
            raise RuntimeError(f'{key} process ownership changed.')
        roots[key] = process_identity(pid)
        if roots[key] is None or job['status'] != 'running':
            raise RuntimeError(f'{key} is no longer running.')
    try:
        for _ in range(3):
            for key, identity in roots.items():
                if process_identity(identity['pid']) != identity:
                    raise RuntimeError(f'{key} root process changed during CPU reassignment.')
                old_pool = parse_cpu_set(state['jobs'][key]['cpu_set'])
                target = parse_cpu_set(CPU_PLAN[key])
                for pid in group_members(identity['pid']):
                    for path in Path(f'/proc/{pid}/task').iterdir():
                        tid = int(path.name)
                        try:
                            previous = os.sched_getaffinity(tid)
                            if not previous.issubset(old_pool):
                                raise RuntimeError(f'Unexpected affinity for training thread {tid}.')
                            original.setdefault(tid, (process_identity(tid), previous))
                            os.sched_setaffinity(tid, target)
                        except ProcessLookupError:
                            continue
        audit = {}
        for key, identity in roots.items():
            members = group_members(identity['pid'])
            count = 0
            for pid in members:
                for path in Path(f'/proc/{pid}/task').iterdir():
                    try:
                        if os.sched_getaffinity(int(path.name)) != parse_cpu_set(CPU_PLAN[key]):
                            raise RuntimeError('A training thread escaped the revised CPU lane.')
                        count += 1
                    except ProcessLookupError:
                        pass
            audit[key] = {'root_identity': identity, 'processes': len(members),
                          'threads': count, 'cpu_set': CPU_PLAN[key]}
        return audit
    except BaseException:
        for tid, (identity, cpus) in original.items():
            if identity is not None and process_identity(tid) == identity:
                try:
                    os.sched_setaffinity(tid, cpus)
                except ProcessLookupError:
                    pass
        raise


def preflight(manifest_path):
    manifest = json.loads(manifest_path.read_text())
    suite = manifest_path.parent
    state = json.loads((suite / 'suite_status.json').read_text())
    key = 'B2_R1_seed11'
    if (manifest.get('profile') != 'pilot' or state['status'] != 'running'
            or key not in state.get('pending', []) or key in state['jobs']
            or not state.get('reference_validation', {}).get('passed')):
        raise RuntimeError('Expedited launch requires a validated pilot with B2 still pending.')
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise RuntimeError('Only physical GPU0 is authorized.')
    contract = manifest['resource_contract']
    pools = [parse_cpu_set(s) for s in (*CPU_PLAN.values(), EVAL_CPUS, MONITOR_CPUS)]
    if (sum(map(len, pools)) != 64 or set().union(*pools) != set(range(32)) | set(range(64, 96))
            or contract['allowed_cpus'] != '0-31,64-95'
            or contract['eval_cpu_set'] != EVAL_CPUS):
        raise RuntimeError('Revised lanes exceed the original CPU half or overlap.')
    for pool in pools:
        for cpu in pool:
            siblings = parse_cpu_set(Path(f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list').read_text().strip())
            if not siblings.issubset(pool):
                raise RuntimeError('Revised CPU lane splits SMT siblings.')
    delta = {}
    for name, expected in manifest['code_fingerprint'].items():
        actual = sha(ROOT / name)
        if actual != expected:
            if name != LAUNCHER:
                raise RuntimeError(f'Frozen numerical/training source changed: {name}')
            delta[name] = {'original_sha256': expected, 'runtime_sha256': actual}
    for entry in (manifest['source'], manifest['ready_source']):
        if sha(entry['path']) != entry['sha256']:
            raise RuntimeError('A frozen model source changed.')
    if sha(manifest['teacher_index']) != manifest['teacher_index_sha256']:
        raise RuntimeError('Teacher index changed.')
    if sha(manifest['source_archive']['path']) != manifest['source_archive']['sha256']:
        raise RuntimeError('Original source archive changed.')
    experiment = manifest['commands'][key]['experiment_name']
    run = ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / experiment
    if run.exists():
        raise FileExistsError(f'B2 output already exists; refusing another run: {run}')
    if process_identity(state['controller_pid']) is None or process_identity(state['evaluator_pid']) is None:
        raise RuntimeError('The original controller/evaluator is unavailable.')
    return manifest, state, delta


def run(args):
    manifest_path = args.manifest.resolve()
    manifest, suite_state, delta = preflight(manifest_path)
    key = 'B2_R1_seed11'
    suite = manifest_path.parent
    lock_fd = acquire_job_lock(manifest_path, key)
    path = marker_path(manifest_path, key)
    if path.exists():
        os.close(lock_fd)
        raise FileExistsError('An expedited B2 claim already exists; no automatic retries.')
    supplemental_archive = suite / 'b2_external_source_bundle.tar.gz'
    with tarfile.open(supplemental_archive, 'x:gz') as archive:
        for name in (LAUNCHER, 'onpolicy/utils/stage2_external_dispatch.py',
                     'onpolicy/scripts/train/run_stage2_bc_external_job.py',
                     'onpolicy/envs/HKBZ/test/test_stage2_external_dispatch.py'):
            archive.add(ROOT / name, arcname=name, recursive=False)
    deadline = suite_state['started_unix_time'] + manifest['resource_contract']['hard_timeout_seconds']
    status = {'schema_version': 1, 'manifest': str(manifest_path),
              'manifest_sha256': sha(manifest_path), 'command_key': key,
              'status': 'launching', 'supervisor_identity': process_identity(os.getpid()),
              'controller_identity': process_identity(suite_state['controller_pid']),
              'evaluator_identity': process_identity(suite_state['evaluator_pid']),
              'cpu_set': CPU_PLAN[key], 'cpu_plan': CPU_PLAN,
              'eval_cpu_set': EVAL_CPUS, 'monitor_cpu_set': MONITOR_CPUS,
              'gpu': 0, 'cuda_memory_fraction': args.cuda_memory_fraction,
              'created_unix_time': time.time(), 'deadline_unix_time': deadline,
              'orchestration_source_amendment': delta,
              'supplemental_source_archive': {'path': str(supplemental_archive),
                                              'sha256': sha(supplemental_archive)},
              'extra_source_sha256': {name: sha(ROOT / name) for name in (
                  'onpolicy/utils/stage2_external_dispatch.py',
                  'onpolicy/scripts/train/run_stage2_bc_external_job.py')},
              'note': 'Original controller adopts this exact job when its lane becomes free; '
                      'its pending list is not the authoritative external-job status.'}
    atomic_json(path, status)
    process = None
    handle = None
    code = 1
    try:
        if time.time() >= deadline:
            raise TimeoutError('The original suite deadline has already elapsed.')
        status['cpu_rebalance_audit'] = rebalance_existing(suite_state)
        atomic_json(path, status)
        python = manifest['commands'][key]['argv'][0]
        socket_path = json.loads((suite / 'shared_evaluator/service_status.json').read_text())['socket_path']
        command = ['taskset', '-c', CPU_PLAN[key], python, '-u', str(ROOT / LAUNCHER),
                   '--manifest', str(manifest_path), '--command-key', key, '--gpu', '0',
                   '--cpu-set', CPU_PLAN[key], '--shared-eval-socket', socket_path,
                   '--shared-eval-cpu-set', EVAL_CPUS, '--eval-workers', '12',
                   '--record', str(suite / 'records' / f'{key}.external.json'),
                   '--external-owner-pid', str(os.getpid()),
                   '--cuda-memory-fraction', str(args.cuda_memory_fraction)]
        handle = (suite / 'service_logs' / f'{key}.external.log').open('x', buffering=1)
        process = subprocess.Popen(command, cwd=ROOT, stdout=handle,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        # Keep status=launching until the child passes its parent-identity guard.
        status.update({'trainer_pid': process.pid, 'started_unix_time': time.time(),
                       'launch_command': command})
        atomic_json(path, status)
        print(f'[ExternalJob] B2 launched: pid={process.pid} cpus={CPU_PLAN[key]} GPU0.', flush=True)
        last_heartbeat = 0.0
        while process.poll() is None:
            if time.time() >= deadline:
                raise TimeoutError('Original 48-hour suite deadline reached.')
            if time.monotonic() - last_heartbeat >= 30:
                last_heartbeat = time.monotonic()
                record_path = suite / 'records' / f'{key}.external.json'
                if record_path.exists():
                    status['status'] = 'running'
                status['updated_unix_time'] = time.time()
                atomic_json(path, status)
                print(f'[ExternalJob] alive pid={process.pid}; original queue will adopt, not relaunch.', flush=True)
            time.sleep(2)
        code = process.returncode if process.returncode >= 0 else 128 - process.returncode
        return code
    except BaseException as error:
        status['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=10)
        status.update({'status': 'completed' if code == 0 else 'failed',
                       'exit_code': code, 'ended_unix_time': time.time()})
        atomic_json(path, status)
        if handle is not None:
            handle.close()
        os.close(lock_fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--cuda-memory-fraction', type=float, default=0.10)
    args = parser.parse_args()
    if not 0 < args.cuda_memory_fraction <= 0.10:
        raise ValueError('B2 must fit the remaining 10% allocator budget.')
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())
