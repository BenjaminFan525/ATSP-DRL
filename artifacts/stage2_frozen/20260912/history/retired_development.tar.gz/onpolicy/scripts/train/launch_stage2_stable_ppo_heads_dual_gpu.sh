#!/usr/bin/env bash
set -euo pipefail

# One-command Stage2 causal screen:
#   1. replay train600 IGA-1800 and fit Resource Potential V2;
#   2. run a three-process memory/functional canary on GPU0;
#   3. run M0-M3 PPO and S0-S2 DeviceBC comparisons on two GPUs.
# Each GPU has three physically isolated trainer slices and one persistent
# validation pool.  S2 starts in S0's lane as soon as S0 completes.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PREPARER="${ROOT_DIR}/onpolicy/scripts/train/prepare_stage2_stable_ppo_heads.py"
FITTER="${ROOT_DIR}/onpolicy/envs/HKBZ/experiment/fit_stage2_resource_potential_v2.py"
TRIAL_RUNNER="${ROOT_DIR}/onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
EVALUATOR="${ROOT_DIR}/onpolicy/scripts/train/shared_hkbz_evaluator.py"

RUN_TAG="${RUN_TAG:-stage2_stable_ppo_heads_20260828_r1}"
SUITE_DIR="${SUITE_DIR:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT="${UNIT:-hkbz-s2-stable-ppo-heads-20260828-r1}"
DATASET="${DATASET:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train}"
VALIDATION_DIR="${VALIDATION_DIR:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
OLD_SUITE="${OLD_SUITE:-${ROOT_DIR}/result/hkbz_train_logs/stage2_iga_distill_cf_20260828_r1}"
OLD_PPO_MANIFEST="${OLD_PPO_MANIFEST:-${OLD_SUITE}/commands/resource_ppo_screen.json}"
OLD_BC_MANIFEST="${OLD_BC_MANIFEST:-${OLD_SUITE}/commands/device_bc_screen.json}"
SELECTION="${SELECTION:-${OLD_SUITE}/analysis/device_bc_selection.json}"
TEACHER_INDEX="${TEACHER_INDEX:-${OLD_SUITE}/artifacts/resource_iga1800_index.json}"
ENV_CONFIG="${ENV_CONFIG:-${ROOT_DIR}/onpolicy/config/env_resource_joint.yaml}"
POTENTIAL="${POTENTIAL:-${SUITE_DIR}/artifacts/resource_potential_v2.json}"
POTENTIAL_ROWS="${POTENTIAL_ROWS:-${SUITE_DIR}/artifacts/resource_potential_v2_trajectories.jsonl}"
CANARY_MANIFEST="${CANARY_MANIFEST:-${SUITE_DIR}/commands/memory_functional_canary.json}"
WAVE_MANIFEST="${WAVE_MANIFEST:-${SUITE_DIR}/commands/wave1.json}"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-15}"

TRAIN_CPUS=(
  "0-9,72-81" "10-19,82-91" "20-29,92-101"
  "36-45,108-117" "46-55,118-127" "56-65,128-137"
)
VAL_CPUS=("30-35,102-107" "66-71,138-143")
EVALUATOR_PIDS=()
EVALUATOR_SOCKETS=()
TRAINER_PIDS=()
MONITOR_PID=""

controller_exit() {
  local status=$?
  stop_children
  if (( status != 0 )); then
    "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"failed","failed_unix_time":time.time(),"exit_status":int(sys.argv[2])},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json" "${status}" || true
  fi
}

stop_children() {
  local pid wait_pids=()
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}"; do
    [[ -n "${pid}" ]] || continue
    kill "${pid}" >/dev/null 2>&1 || true
    wait_pids+=("${pid}")
  done
  if [[ -n "${MONITOR_PID}" ]]; then
    kill "${MONITOR_PID}" >/dev/null 2>&1 || true
    wait_pids+=("${MONITOR_PID}")
  fi
  for pid in "${wait_pids[@]:-}"; do
    [[ -n "${pid}" ]] || continue
    wait "${pid}" >/dev/null 2>&1 || true
  done
  TRAINER_PIDS=()
  EVALUATOR_PIDS=()
  EVALUATOR_SOCKETS=()
  MONITOR_PID=""
}

verify_cpu_topology() {
  "${PYTHON}" - "${TRAIN_CPUS[@]}" "${VAL_CPUS[@]}" <<'PY'
import os, sys

def expand(spec):
    result=set()
    for part in spec.split(','):
        lo, sep, hi=part.partition('-')
        result.update(range(int(lo), int(hi)+1) if sep else [int(lo)])
    return result

if os.cpu_count() != 144:
    raise SystemExit(f'expected 144 logical CPUs, got {os.cpu_count()}')
groups=[expand(spec) for spec in sys.argv[1:]]
trainers, evaluators=groups[:6], groups[6:]
for gpu in range(2):
    local=trainers[gpu*3:(gpu+1)*3]+[evaluators[gpu]]
    if [len(item) for item in local] != [20,20,20,12]:
        raise SystemExit(f'GPU{gpu} CPU widths are invalid')
    if sum(map(len, local)) != len(set().union(*local)):
        raise SystemExit(f'GPU{gpu} CPU sets overlap')
for group in groups:
    for cpu in group:
        sibling=cpu+72 if cpu < 72 else cpu-72
        if sibling not in group:
            raise SystemExit(f'CPU set splits SMT siblings {cpu}/{sibling}')
print('[CPU] verified two NUMA-local 3x20+12 physical-core partitions')
PY
}

fit_potential() {
  if [[ -s "${POTENTIAL}" && -s "${POTENTIAL_ROWS}" ]]; then
    echo "[PotentialV2] reusing verified output ${POTENTIAL}"
    return
  fi
  echo "[PotentialV2] replaying 600 verified IGA-1800 trajectories"
  /usr/bin/taskset --cpu-list 0-143 \
    "${PYTHON}" -u "${FITTER}" \
      --dataset-dir "${DATASET}" --teacher-index "${TEACHER_INDEX}" \
      --env-config "${ENV_CONFIG}" --output-json "${POTENTIAL}" \
      --trajectory-jsonl "${POTENTIAL_ROWS}" --workers 72 \
      --max-cases 0 --min-heldout-r2 0.75 \
      >"${SUITE_DIR}/service_logs/potential_v2.log" 2>&1
  echo "[PotentialV2] calibration and heldout gate passed"
}

prepare_manifests() {
  "${PYTHON}" -u "${PREPARER}" \
    --run-tag "${RUN_TAG}" --suite-dir "${SUITE_DIR}" \
    --old-ppo-manifest "${OLD_PPO_MANIFEST}" \
    --old-bc-manifest "${OLD_BC_MANIFEST}" \
    --selection "${SELECTION}" --potential "${POTENTIAL}" \
    --dataset-dir "${DATASET}" --python "${PYTHON}" \
    --wave-output "${WAVE_MANIFEST}" \
    --canary-output "${CANARY_MANIFEST}" \
    >"${SUITE_DIR}/service_logs/prepare.log" 2>&1
  echo "[Manifest] canary and Wave1 causal contracts prepared"
}

monitor_phase() {
  local phase="$1"
  local output="${SUITE_DIR}/hardware/${phase}_usage.csv"
  mkdir -p "${SUITE_DIR}/hardware"
  echo "unix_time,gpu0_mem_mib,gpu0_util,gpu1_mem_mib,gpu1_util,mem_available_mib,swap_used_mib" >"${output}"
  while true; do
    local rows g0m g0u g1m g1u available swap
    rows="$(nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader,nounits)"
    g0m="$(sed -n '1{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g0u="$(sed -n '1{s/.*,//;s/ //g;p}' <<<"${rows}")"
    g1m="$(sed -n '2{s/,.*//;s/ //g;p}' <<<"${rows}")"
    g1u="$(sed -n '2{s/.*,//;s/ //g;p}' <<<"${rows}")"
    available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap="$(awk '/SwapTotal:/ {t=$2} /SwapFree:/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)"
    echo "$(date +%s),${g0m},${g0u},${g1m},${g1u},${available},${swap}" >>"${output}"
    sleep 30
  done
}

start_evaluator() {
  local phase="$1" manifest="$2" gpu="$3"
  local cpus="${VAL_CPUS[$gpu]}" socket="/tmp/${UNIT}-${phase}-g${gpu}.sock"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}_eval.log"
  rm -f -- "${socket}"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${EVALUATOR}" \
      --source-command-json "${manifest}" --socket-path "${socket}" \
      --cpu-pool "${cpus}" \
      --run-dir "${SUITE_DIR}/shared_evaluator/${phase}_g${gpu}" \
      --eval-dataset-dir "${VALIDATION_DIR}" --max-eval-cases 60 \
      --cuda-memory-fraction 0.08 \
      --eval-partition-seed 20260811 \
      --eval-partition-stratify-by distribution \
      >"${log}" 2>&1 &
  EVALUATOR_PIDS[$gpu]="$!"
  local deadline=$((SECONDS + 1200))
  while (( SECONDS < deadline )); do
    kill -0 "${EVALUATOR_PIDS[$gpu]}" >/dev/null 2>&1 || {
      echo "[Error] ${phase} GPU${gpu} evaluator exited" >&2
      return 1
    }
    if [[ -S "${socket}" ]] && "${PYTHON}" - "${socket}" <<'PY'
import sys
from onpolicy.utils.shared_eval import SharedEvalClient
reply=SharedEvalClient(sys.argv[1], timeout_seconds=5).ping()
raise SystemExit(0 if int(reply.get('worker_count', -1)) == 12 else 1)
PY
    then
      EVALUATOR_SOCKETS[$gpu]="${socket}"
      echo "[SharedEval] ${phase} GPU${gpu} ready"
      return 0
    fi
    sleep 2
  done
  echo "[Error] ${phase} GPU${gpu} evaluator readiness timeout" >&2
  return 1
}

launch_trial() {
  local phase="$1" manifest="$2" key="$3" gpu="$4" lane="$5" delay="$6"
  local index=$((gpu * 3 + lane))
  local cpus="${TRAIN_CPUS[$index]}"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}l${lane}_${key}.log"
  local record="${SUITE_DIR}/records/${phase}_${key}.json"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${TRIAL_RUNNER}" \
      --manifest "${manifest}" --command-key "${key}" \
      --gpu "${gpu}" --cpu-set "${cpus}" \
      --shared-eval-socket "${EVALUATOR_SOCKETS[$gpu]}" \
      --shared-eval-cpu-set "${VAL_CPUS[$gpu]}" --eval-workers 12 \
      --start-delay-seconds "${delay}" --record "${record}" \
      >"${log}" 2>&1 &
  LAST_LAUNCHED_PID="$!"
  TRAINER_PIDS+=("${LAST_LAUNCHED_PID}")
  echo "[Launch] ${phase} GPU${gpu} lane=${lane} ${key} CPUs=${cpus} pid=${LAST_LAUNCHED_PID}"
}

canary_artifacts_complete() {
  local key="$1" experiment="" log=""
  case "${key}" in
    C_S1_type_adapter)
      experiment="${RUN_TAG}_wave1_S1_type_adapter_seed1_canary"
      ;;
    C_S2_per_type)
      experiment="${RUN_TAG}_wave1_S2_per_type_seed1_canary"
      ;;
    C_M3_bc_kl_potential_v2)
      experiment="${RUN_TAG}_wave1_M3_bc_kl_potential_v2_seed1_canary"
      ;;
    *) return 1 ;;
  esac
  local run_dir="${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo/${experiment}/run1"
  log="${SUITE_DIR}/service_logs/canary_g0l1_${key}.log"
  [[ "${key}" == C_S2_per_type ]] && \
    log="${SUITE_DIR}/service_logs/canary_g0l2_${key}.log"
  if [[ "${key}" == C_M3_bc_kl_potential_v2 ]]; then
    [[ -s "${run_dir}/models/checkpoint_Last.pt" ]]
  else
    [[ -s "${run_dir}/models/checkpoint_DeviceBC.pt" \
       && -s "${run_dir}/evaluations/pre_ppo.json" \
       && -s "${log}" ]] \
      && grep -q 'BC-only screening completed' "${log}"
  fi
}

run_canary() {
  local all_keys=(
    C_M3_bc_kl_potential_v2 C_S1_type_adapter C_S2_per_type
  ) keys=() pids=() key lane failed=0
  for key in "${all_keys[@]}"; do
    if canary_artifacts_complete "${key}"; then
      echo "[Canary] reusing completed ${key} artifacts"
    else
      keys+=("${key}")
    fi
  done
  if (( ${#keys[@]} == 0 )); then
    echo "[Canary] all functional/memory gates already passed"
    return 0
  fi
  start_evaluator canary "${CANARY_MANIFEST}" 0
  monitor_phase canary & MONITOR_PID="$!"
  for ((lane=0; lane<${#keys[@]}; lane++)); do
    key="${keys[$lane]}"
    launch_trial canary "${CANARY_MANIFEST}" "${key}" 0 "${lane}" "$((lane * START_STAGGER_SECONDS))"
    pids+=("${LAST_LAUNCHED_PID}")
  done
  for ((lane=0; lane<${#keys[@]}; lane++)); do
    if ! wait "${pids[$lane]}"; then
      echo "[Error] canary ${keys[$lane]} failed" >&2
      failed=1
    fi
  done
  stop_children
  (( failed == 0 )) || return 1
  echo "[Canary] role BC-KL/Potential and both new head families passed"
}

run_wave1() {
  local failed=0 pid key
  declare -A pids=()
  start_evaluator wave1 "${WAVE_MANIFEST}" 0
  start_evaluator wave1 "${WAVE_MANIFEST}" 1
  monitor_phase wave1 & MONITOR_PID="$!"

  launch_trial wave1 "${WAVE_MANIFEST}" M0_stable_control 0 0 0
  pids[M0_stable_control]="${LAST_LAUNCHED_PID}"
  launch_trial wave1 "${WAVE_MANIFEST}" M1_bc_kl 0 1 "${START_STAGGER_SECONDS}"
  pids[M1_bc_kl]="${LAST_LAUNCHED_PID}"
  launch_trial wave1 "${WAVE_MANIFEST}" S0_shared 0 2 "$((2 * START_STAGGER_SECONDS))"
  pids[S0_shared]="${LAST_LAUNCHED_PID}"
  launch_trial wave1 "${WAVE_MANIFEST}" M2_potential_v2 1 0 0
  pids[M2_potential_v2]="${LAST_LAUNCHED_PID}"
  launch_trial wave1 "${WAVE_MANIFEST}" M3_bc_kl_potential_v2 1 1 "${START_STAGGER_SECONDS}"
  pids[M3_bc_kl_potential_v2]="${LAST_LAUNCHED_PID}"
  launch_trial wave1 "${WAVE_MANIFEST}" S1_type_adapter 1 2 "$((2 * START_STAGGER_SECONDS))"
  pids[S1_type_adapter]="${LAST_LAUNCHED_PID}"

  if ! wait "${pids[S0_shared]}"; then
    echo "[Error] Wave1 S0_shared failed; S2 lane is not safe to reuse" >&2
    failed=1
  else
    unset 'pids[S0_shared]'
    launch_trial wave1 "${WAVE_MANIFEST}" S2_per_type 0 2 0
    pids[S2_per_type]="${LAST_LAUNCHED_PID}"
  fi
  for key in "${!pids[@]}"; do
    if ! wait "${pids[$key]}"; then
      echo "[Error] Wave1 ${key} failed" >&2
      failed=1
    fi
  done
  stop_children
  (( failed == 0 )) || return 1
  echo "[Wave1] all four training-method and three architecture arms completed"
}

controller() {
  trap controller_exit EXIT
  trap 'exit 130' INT TERM
  mkdir -p "${SUITE_DIR}"/{commands,artifacts,service_logs,records,shared_evaluator,hardware,analysis}
  "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"running","started_unix_time":time.time()},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json"
  fit_potential
  prepare_manifests
  run_canary
  run_wave1
  "${PYTHON}" -c 'import json,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(json.dumps({"status":"completed","completed_unix_time":time.time()},indent=2)+"\n")' "${SUITE_DIR}/pipeline_status.json"
  echo "[Pipeline] Stage2 Wave1 completed"
}

initial_launch() {
  local required load_state compute_pids status
  for required in "${PYTHON}" "${PREPARER}" "${FITTER}" "${TRIAL_RUNNER}" \
    "${EVALUATOR}" "${DATASET}" "${VALIDATION_DIR}" "${OLD_PPO_MANIFEST}" \
    "${OLD_BC_MANIFEST}" "${SELECTION}" "${TEACHER_INDEX}" "${ENV_CONFIG}" \
    /usr/bin/taskset /usr/bin/nvidia-smi; do
    [[ -e "${required}" ]] || { echo "[Error] missing input ${required}" >&2; exit 1; }
  done
  [[ "${RUN_TAG}" =~ ^[A-Za-z0-9._-]+$ && "${UNIT}" =~ ^[A-Za-z0-9._-]+$ ]] || {
    echo "[Error] RUN_TAG/UNIT is not path safe" >&2; exit 1;
  }
  verify_cpu_topology
  if [[ -f "${SUITE_DIR}/pipeline_status.json" ]]; then
    status="$("${PYTHON}" -c 'import json,sys; print(json.load(open(sys.argv[1])).get("status",""))' "${SUITE_DIR}/pipeline_status.json")"
    [[ "${status}" != running ]] || {
      echo "[Error] suite already reports a running controller" >&2; exit 1;
    }
  fi
  systemctl --user show-environment >/dev/null
  load_state="$(systemctl --user show "${UNIT}.service" --property=LoadState --value 2>/dev/null || true)"
  [[ -z "${load_state}" || "${load_state}" == not-found ]] || {
    echo "[Error] systemd unit already exists: ${UNIT}.service" >&2; exit 1;
  }
  [[ "$(nvidia-smi --query-gpu=index --format=csv,noheader,nounits | wc -l)" -ge 2 ]] || {
    echo "[Error] two CUDA GPUs are required" >&2; exit 1;
  }
  compute_pids="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | sed '/^[[:space:]]*$/d')"
  [[ -z "${compute_pids}" ]] || {
    echo "[Error] refusing launch while GPU compute processes exist: ${compute_pids//$'\n'/,}" >&2; exit 1;
  }
  mkdir -p "${SUITE_DIR}/service_logs" "/tmp/${UNIT}/matplotlib"
  systemd-run --user --unit="${UNIT}" --same-dir \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv="MPLCONFIGDIR=/tmp/${UNIT}/matplotlib" \
    --setenv="RUN_TAG=${RUN_TAG}" --setenv="SUITE_DIR=${SUITE_DIR}" \
    --setenv="UNIT=${UNIT}" \
    --property=Type=exec --property=Restart=no \
    --property=KillMode=control-group --property=TimeoutStopSec=300 \
    --property=LimitNOFILE=65536 \
    --property=AllowedCPUs=0-143 --property=CPUAffinity=0-143 \
    --property="StandardOutput=append:${SUITE_DIR}/service_logs/controller.log" \
    --property="StandardError=append:${SUITE_DIR}/service_logs/controller.log" \
    /bin/bash "${BASH_SOURCE[0]}" --controller >/dev/null
  echo "[Started] ${UNIT}.service"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] phase=PotentialV2/prepare, followed by three-lane canary"
}

if [[ "${1:-}" == --controller ]]; then
  [[ $# -eq 1 ]] || { echo "Usage: $0 --controller" >&2; exit 2; }
  controller
elif [[ $# -eq 0 ]]; then
  initial_launch
else
  echo "Usage: $0" >&2
  exit 2
fi
