#!/usr/bin/env python3
"""Prepare matched BC/DAgger forks; no gate/blind access or automatic promotion."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shlex
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.config.config import get_config
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import set_option, set_switch
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args as parse_train_args, select_train_case_dirs
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.training_stage import source_checkpoint_metadata

PARENT = ROOT / 'result/hkbz_train_logs/stage2_bc_injection_20260905_gpu0_half_pilot_r2'
METHODS = [('C_B0', 'B0_none', '1.0,1.0'), ('D_B0', 'B0_none', '0.75,0.50'),
           ('D_B2', 'B2_R1', '0.75,0.50'), ('C_B2', 'B2_R1', '1.0,1.0')]
TRAIN_CPUS = ['0-7,64-71', '8-15,72-79', '16-23,80-87']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare(args):
    suite = args.suite_dir.resolve()
    if suite.exists():
        raise FileExistsError(f'Never reuse a suite: {suite}')
    old = json.loads((args.parent_suite / 'manifest.json').read_text())
    old_report = json.loads((args.parent_suite / 'analysis/comparison.json').read_text())
    if not old_report.get('complete') or any(not v['integrity_passed'] for v in old_report['methods'].values()):
        raise ValueError('Parent pilot is not complete and audited.')
    canary = args.profile == 'canary'
    workers, cases, eval_workers, eval_cases, rollouts = (2, 2, 2, 4, 1) if canary else (24, 240, 12, 60, 10)
    teacher = json.loads(Path(old['teacher_index']).read_text())
    selected, audit = select_train_case_dirs(
        sorted(Path(teacher['dataset_dir']).glob('case_*')),
        mode='uniform' if canary else 'distribution_balanced',
        weights_spec='iid=0.50,ood_stress=0.45,ood_scale=0.05', seed=1,
        max_cases=cases, sample_size=cases,
    )
    order = [Path(p).name for p in selected]
    if not canary and order != old['sampling_audits']['11']['case_order']:
        raise ValueError('Training cases/order differ from the parent pilot.')
    audit.update(case_order=order, sampling_seed=1,
                 case_order_sha256=hashlib.sha256('\n'.join(order).encode()).hexdigest())
    commands, sources = {}, {}
    for arm, source_arm, schedule in METHODS:
        method = old_report['methods'][source_arm + '_seed11']
        run = Path(method['run_dir'])
        source = source_checkpoint_metadata(run / 'models/checkpoint_Best.pt')
        epoch = method['selected_epoch']
        evaluation = run / 'evaluations' / f'bc_epoch_{epoch}.json'
        rows = json.loads(evaluation.read_text())['cases']
        if not canary:
            validate_case_content(rows, old['evaluation_contract']['dataset'])
        sources[source_arm] = {**source, 'selected_epoch': epoch,
                               'evaluation': str(evaluation), 'evaluation_sha256': digest(evaluation)}
        command = list(old['commands'][source_arm + '_seed11']['argv'])
        command[0] = str(args.python.resolve())
        experiment = f'{args.run_tag}_{arm}_seed11'
        if (ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / experiment).exists():
            raise FileExistsError(f'Experiment already exists: {experiment}')
        options = {
            '--experiment_name': experiment, '--seed': 11, '--train_sampling_seed': 1,
            '--train_sampling_mode': 'uniform' if canary else 'distribution_balanced',
            '--max_train_cases': cases, '--train_sampling_size': cases,
            '--n_rollout_threads': workers, '--n_eval_rollout_threads': eval_workers,
            '--max_eval_cases': eval_cases, '--mini_batch_size': min(7, workers),
            '--device_bc_min_rollouts_per_epoch': rollouts,
            '--device_bc_max_rollouts_per_epoch': rollouts,
            '--device_bc_pretrain_epochs': 2, '--device_bc_lr': 1e-5,
            '--request_ready_min_labels_per_epoch': 0,
            '--device_bc_dagger_schedule': schedule, '--cuda_memory_fraction': 0.25,
            '--stage2_policy_warmstart_checkpoint': source['path'],
            '--stage2_policy_warmstart_sha256': source['sha256'],
            '--stage2_policy_warmstart_evaluation': '' if canary else str(evaluation),
            '--stage2_policy_warmstart_evaluation_sha256': '' if canary else digest(evaluation),
        }
        for name, value in options.items():
            set_option(command, name, value)
        # The public CLI has an inverse switch, not --device_bc_plane_deterministic.
        set_switch(command, '--device_bc_stochastic_plane', False)
        set_switch(command, '--device_bc_skip_ready_targets', True)
        parser = get_config()
        parsed = parse_train_args(command[2:], parser)
        _, unknown = parser.parse_known_args(command[2:])
        if unknown or not parsed.device_bc_plane_deterministic:
            raise ValueError(f'Invalid/non-deterministic training command: {unknown}')
        commands[arm + '_seed11'] = {
            'argv': command, 'shell': shlex.join(command), 'experiment_name': experiment,
            'arm': arm, 'seed': 11, 'injection': old['commands'][source_arm + '_seed11']['injection'],
            'warmstart_arm': source_arm, 'warmstart_source': sources[source_arm],
            'teacher_execution_schedule': [float(x) for x in schedule.split(',')],
        }
    fingerprints = code_fingerprint()
    for extra in ['STAGE2_TO_STAGE3_RESEARCH_PLAN_20260906.md',
                  'onpolicy/scripts/train/launch_stage2_policy_transfer_gpu0.sh']:
        fingerprints[extra] = digest(ROOT / extra)
    manifest = {
        'schema_version': 1, 'run_tag': args.run_tag, 'profile': args.profile,
        'research_family': 'stage2_policy_transfer', 'scientific_result': not canary,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'parent_manifest': str(args.parent_suite / 'manifest.json'),
        'parent_manifest_sha256': digest(args.parent_suite / 'manifest.json'),
        'commands': commands, 'source': old['source'], 'ready_source': old['ready_source'],
        'teacher_index': old['teacher_index'], 'teacher_index_sha256': old['teacher_index_sha256'],
        'warmstart_sources': sources, 'sampling_audits': {'11': audit},
        'training_contract': {'epochs': 2, 'workers': workers, 'rollouts_per_epoch': rollouts,
                              'scope': 'policy_frozen_ready', 'ppo_epochs': 0,
                              'warmstart': 'weights_only_fork', 'shared_initial_seed': 11,
                              'optimizer_restored': False, 'rng_restored': False},
        'ready_target_contract': {'collection': False, 'regression': False,
                                  'reason': 'Frozen R1; factual teacher timestamps are not valid on student trajectories.'},
        'evaluation_contract': {**old['evaluation_contract'], 'workers': eval_workers,
                                'cases': eval_cases, 'gate_access': False,
                                'per_job_zero_tolerance_replay': not canary},
        'resource_contract': {**old['resource_contract'], 'train_cpu_sets': TRAIN_CPUS,
                              'max_concurrent_trainers': 3},
        'analysis_contract': {'contrasts': [['D_B0', 'C_B0'], ['D_B2', 'C_B2']],
                              'frozen_strong_reference': 'B2_R1',
                              'practical_gain_fraction': 0.01, 'aspirational_gain_fraction': 0.02,
                              'screen_gain_fraction': 0.005, 'max_group_regression_fraction': 0.005,
                              'resampling_unit': 'paired case, conditional on one initial/training seed',
                              'retain_unchanged_source': True, 'automatic_promotion': False},
        'analysis_script': 'onpolicy/scripts/train/analyze_stage2_policy_transfer.py',
        'code_commit': old['code_commit'], 'code_fingerprint': fingerprints,
        'note': 'First-wave screen only. No resource RL, Stage3 update, gate/blind access or formal auto-launch.',
    }
    suite.mkdir(parents=True, exist_ok=False)
    archive = suite / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for relative, expected in fingerprints.items():
            path = ROOT / relative
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError(f'Source changed during preparation: {relative}')
            info = handle.gettarinfo(str(path), arcname=relative)
            info.size = len(data)
            handle.addfile(info, io.BytesIO(data))
    manifest['source_archive'] = {'path': str(archive), 'sha256': digest(archive)}
    atomic_json(suite / 'manifest.json', manifest)
    atomic_json(suite / 'evaluator_source.json', {'command': next(iter(commands.values()))['argv']})
    print(suite / 'manifest.json')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--profile', choices=['canary', 'pilot'], default='pilot')
    parser.add_argument('--parent-suite', type=Path, default=PARENT)
    parser.add_argument('--python', type=Path, default=Path(sys.executable))
    prepare(parser.parse_args())
