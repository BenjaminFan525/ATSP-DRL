#!/usr/bin/env python3
"""Read archived real full batches; measure actor-only changes, never gate training.

Independent repeats use unchanged inputs. This is a performance screen, not
the subsequent mandatory terminal-trajectory/cost verification.
"""
import argparse
import gzip
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.config.config import get_config
from onpolicy.scripts.train.run_stage2_bc_injection_suite import verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_cost_actor_pool import PrivateActorPool
from onpolicy.utils.stage2_cost_actor_process import ProcessActorPool
from onpolicy.utils.stage2_cost_improvement import actor_forward, policy_digest


def run(cli):
    manifest = json.loads(cli.manifest.read_text())
    verify_resources(manifest)
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.70, device=0)
    args = parse_args(manifest['commands']['N2_cost_teacher_seed11']['argv'][2:], get_config())
    payload = torch.load(manifest['warmstart_sources']['B0_none']['path'], map_location='cpu', weights_only=True)
    for key, value in ready_head_config(payload).items():
        setattr(args, key, value)
    policy = GNN_MAPPOPolicy(args, yaml.safe_load(Path(args.ac_config).read_text()), device=torch.device('cuda:0'))
    policy.load_model_state(payload['model'])
    policy.ac.eval()
    policy.ac.tau = args.evaluation_tau
    for parameter in policy.ac.parameters():
        parameter.requires_grad_(False)
    before = policy_digest(policy)
    samples = []
    for path in cli.states:
        with gzip.open(path, 'rb') as handle:
            state = torch.load(handle, map_location='cpu', weights_only=False)
        samples.append((state['obs'], state['target_rnn'], state['active'], state['history'], state['agent_types']))
    references = [actor_forward(policy, *sample) for sample in samples]
    report = dict(status='running', scientific_result=False, training_gate_passed=False,
                  manifest=str(cli.manifest.resolve()), states=[str(p.resolve()) for p in cli.states], modes=[])
    atomic_json(cli.output, report)
    for backend, fast, lanes in (('threads', False, 2), ('threads', True, 1),
                                 ('threads', True, 2), ('threads', True, 4)):
        pool = (ProcessActorPool(policy, lanes, memory_budget=.70) if backend == 'processes'
                else PrivateActorPool(policy, lanes, fast_matching=fast))
        try:
            requests = [(i, *samples[i % len(samples)]) for i in range(8)]
            for _, actions, hidden, _ in pool.run(requests):
                pass
            durations = []
            exact = True
            for repeat in range(cli.repeats):
                start = time.monotonic()
                outputs = pool.run(requests)
                durations.append(time.monotonic() - start)
                for index, actions, hidden, _ in outputs:
                    ref_actions, ref_hidden = references[index % len(samples)]
                    exact &= np.array_equal(actions, ref_actions) and np.array_equal(hidden, ref_hidden)
            row = dict(actor_backend=backend, fast_matching=fast, actor_lanes=lanes, requests_per_repeat=len(requests),
                       seconds=durations, median_seconds=float(np.median(durations)), outputs_exact=bool(exact))
            report['modes'].append(row)
            atomic_json(cli.output, report)
            print(json.dumps(row), flush=True)
            if not exact:
                raise ValueError('Actor actions or full recurrent tensor differ from legacy.')
        finally:
            pool.close()
            torch.cuda.empty_cache()
    report.update(status='completed', source_weights_unchanged=policy_digest(policy) == before,
                  gpu_peak_allocated_bytes=torch.cuda.max_memory_allocated())
    atomic_json(cli.output, report)
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--states', type=Path, nargs='+', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, default=5)
    raise SystemExit(run(parser.parse_args()))
