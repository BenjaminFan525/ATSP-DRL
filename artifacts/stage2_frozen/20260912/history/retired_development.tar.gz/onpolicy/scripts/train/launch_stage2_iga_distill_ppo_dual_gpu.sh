#!/usr/bin/env bash
set -euo pipefail

# One-command, resumable Stage2 research pipeline:
#   matched train600 IGA-180 -> nested IGA-1800
#   six causally isolated, tail-complete 240-case DeviceBC-only arms
#   hard-gated BC selection
#   six 240-case PPO arms restored from the exact same DeviceBC checkpoint
#
# Each GPU owns one NUMA node, three isolated trainers and one persistent
# validator.  Teacher generation uses eight case-parallel shards and all 72
# physical cores.  PYTORCH_CUDA_ALLOC_CONF is inherited by every child.

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
IGA_RUNNER="${ROOT_DIR}/onpolicy/envs/HKBZ/experiment/generate_stage2_resource_iga_labels.py"
PREPARER="${ROOT_DIR}/onpolicy/scripts/train/prepare_stage2_iga_distill_ppo.py"
TRIAL_RUNNER="${ROOT_DIR}/onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
EVALUATOR="${ROOT_DIR}/onpolicy/scripts/train/shared_hkbz_evaluator.py"

DATASET="${DATASET:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train}"
VALIDATION_DIR="${VALIDATION_DIR:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
CHECKPOINT="${CHECKPOINT:-${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo/stage1_departure_reward_formal_dual_20260816_r1_formal_P5_team_time_potential_fixed_seed3/run1/models/checkpoint_Best.pt}"
SOURCE_COMMAND="${SOURCE_COMMAND:-${ROOT_DIR}/result/hkbz_train_logs/stage1_departure_reward_formal_dual_20260816_r1/commands/formal_P5.json}"
SOURCE_COMMAND_KEY="${SOURCE_COMMAND_KEY:-P5_team_time_potential_fixed_seed3}"
HANDOFF="${HANDOFF:-${ROOT_DIR}/onpolicy/config/stage1_m2_handoff.json}"

RUN_TAG="${RUN_TAG:-stage2_iga_distill_cf_20260828_r1}"
SUITE_DIR="${SUITE_DIR:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT="${UNIT:-hkbz-s2-iga-distill-cf-20260828-r1}"
START_STAGGER_SECONDS="${START_STAGGER_SECONDS:-15}"

IGA180_DIR="${SUITE_DIR}/teachers/matched_hard/iga180"
IGA1800_DIR="${SUITE_DIR}/teachers/matched_hard/iga1800"
BC_MANIFEST="${SUITE_DIR}/commands/device_bc_screen.json"
BC_SELECTION="${SUITE_DIR}/analysis/device_bc_selection.json"
PPO_CANARY_MANIFEST="${SUITE_DIR}/commands/resource_ppo_memory_canary.json"
PPO_MANIFEST="${SUITE_DIR}/commands/resource_ppo_screen.json"

SHARD_COUNT=8
SHARD_GPUS=(0 0 0 0 1 1 1 1)
SHARD_CPUS=(
  "0-8,72-80" "9-17,81-89" "18-26,90-98" "27-35,99-107"
  "36-44,108-116" "45-53,117-125" "54-62,126-134" "63-71,135-143"
)
TRAIN_CPUS=(
  "0-9,72-81" "10-19,82-91" "20-29,92-101"
  "36-45,108-117" "46-55,118-127" "56-65,128-137"
)
VAL_CPUS=("30-35,102-107" "66-71,138-143")
BC_METHODS=(
  T0_heuristic_role T1_iga_plain T2_iga_role
  T3_iga_timing T4_iga_role_timing T5_iga_confident
)
PPO_METHODS=(
  P0_legacy P1_role_atomic P2_role_event
  P3_critic_calibrated P4_counterfactual_q P5_sequential_roles
)
PPO_CANARY_METHODS=(
  C3_critic_calibrated C4_counterfactual_q C5_sequential_roles
)

EVALUATOR_PIDS=()
EVALUATOR_SOCKETS=()
TRAINER_PIDS=()
MONITOR_PID=""

teacher_common_args() {
  printf '%s\n' \
    --dataset-dir "${DATASET}" \
    --checkpoint "${CHECKPOINT}" \
    --source-command "${SOURCE_COMMAND}" \
    --source-command-key "${SOURCE_COMMAND_KEY}" \
    --handoff "${HANDOFF}" \
    --device cuda:0 \
    --evaluation-tau 0.3 \
    --device-lookahead-safety-margin 60 \
    --device-deadline-aware-dispatch \
    --device-future-intent-horizon 1 \
    --device-future-intent-mode bounded_frontier \
    --device-frontier-max-requests 2 \
    --resource-release-aware-eta \
    --device-lookahead-reservation-mode hard \
    --device-reservation-grace-seconds 300 \
    --device-departure-lookahead \
    --population 20 \
    --case-batch-size 16 \
    --max-generations 100000 \
    --seed 20260828 \
    --max-steps 4000 \
    --max-cases 0
}

run_teacher_stage() {
  local shard="$1" gpu="$2" cpus="$3" output="$4"
  local added_budget="$5" cumulative_budget="$6"
  shift 6
  local args=()
  mapfile -t args < <(teacher_common_args)
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${IGA_RUNNER}" \
      "${args[@]}" \
      --output-dir "${output}" \
      --time-budget-seconds "${added_budget}" \
      --cumulative-budget-seconds "${cumulative_budget}" \
      --shard-index "${shard}" --shard-count "${SHARD_COUNT}" "$@"
}

teacher_worker() {
  local shard="$1" gpu="${SHARD_GPUS[$1]}" cpus="${SHARD_CPUS[$1]}"
  run_teacher_stage "${shard}" "${gpu}" "${cpus}" "${IGA180_DIR}" 180 180
  run_teacher_stage \
    "${shard}" "${gpu}" "${cpus}" "${IGA1800_DIR}" 1620 1800 \
    --warm-start-dir "${IGA180_DIR}" --warm-start-budget-seconds 180
}

summarize_teacher_stage() {
  local output="$1" added_budget="$2" cumulative_budget="$3"
  shift 3
  local args=()
  mapfile -t args < <(teacher_common_args)
  /usr/bin/taskset --cpu-list 0,72 \
    "${PYTHON}" -u "${IGA_RUNNER}" \
      "${args[@]}" --output-dir "${output}" \
      --time-budget-seconds "${added_budget}" \
      --cumulative-budget-seconds "${cumulative_budget}" \
      --summarize-only "$@"
}

run_teachers() {
  local shard failed=0 pids=()
  mkdir -p "${SUITE_DIR}/service_logs/teachers"
  for ((shard=0; shard<SHARD_COUNT; shard++)); do
    teacher_worker "${shard}" \
      >"${SUITE_DIR}/service_logs/teachers/shard${shard}.log" 2>&1 &
    pids+=("$!")
  done
  for ((shard=0; shard<SHARD_COUNT; shard++)); do
    if ! wait "${pids[$shard]}"; then
      echo "[Error] matched IGA shard ${shard} failed" >&2
      failed=1
    fi
  done
  (( failed == 0 )) || return 1
  summarize_teacher_stage "${IGA180_DIR}" 180 180 \
    >"${SUITE_DIR}/service_logs/teachers/iga180_summary.log" 2>&1
  summarize_teacher_stage \
    "${IGA1800_DIR}" 1620 1800 \
    --warm-start-dir "${IGA180_DIR}" --warm-start-budget-seconds 180 \
    >"${SUITE_DIR}/service_logs/teachers/iga1800_summary.log" 2>&1
  echo "[Teacher] matched hard train600 IGA-1800 complete and replay verified"
}

run_teacher_canary() {
  local output="${SUITE_DIR}/teachers/canary_5s" args=()
  mapfile -t args < <(teacher_common_args)
  mkdir -p "${SUITE_DIR}/service_logs/teachers"
  env CUDA_VISIBLE_DEVICES=0 CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "0-3,72-75" \
    "${PYTHON}" -u "${IGA_RUNNER}" \
      "${args[@]}" --output-dir "${output}" \
      --population 4 --case-batch-size 1 --max-generations 1000 \
      --max-cases 1 --time-budget-seconds 5 \
      --cumulative-budget-seconds 5 --shard-index 0 --shard-count 1 \
      >"${SUITE_DIR}/service_logs/teachers/canary.log" 2>&1
  env CUDA_VISIBLE_DEVICES=0 CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "0,72" \
    "${PYTHON}" -u "${IGA_RUNNER}" \
      "${args[@]}" --output-dir "${output}" \
      --population 4 --case-batch-size 1 --max-generations 1000 \
      --max-cases 1 --time-budget-seconds 5 \
      --cumulative-budget-seconds 5 --summarize-only \
      >>"${SUITE_DIR}/service_logs/teachers/canary.log" 2>&1
  echo "[Canary] one-case matched teacher search/replay passed"
}

prepare_bc() {
  "${PYTHON}" -u "${PREPARER}" \
    --phase bc --run-tag "${RUN_TAG}" --suite-dir "${SUITE_DIR}" \
    --source-teacher-dir "${IGA1800_DIR}/teachers" \
    --dataset-dir "${DATASET}" --handoff "${HANDOFF}" \
    --python "${PYTHON}" --output "${BC_MANIFEST}"
}

prepare_ppo() {
  "${PYTHON}" -u "${PREPARER}" \
    --phase select --bc-manifest "${BC_MANIFEST}" \
    --output "${BC_SELECTION}"
  "${PYTHON}" -u "${PREPARER}" \
    --phase ppo_memory_canary --run-tag "${RUN_TAG}" \
    --suite-dir "${SUITE_DIR}" --bc-manifest "${BC_MANIFEST}" \
    --selection "${BC_SELECTION}" --dataset-dir "${DATASET}" \
    --handoff "${HANDOFF}" --python "${PYTHON}" \
    --output "${PPO_CANARY_MANIFEST}"
  "${PYTHON}" -u "${PREPARER}" \
    --phase ppo --run-tag "${RUN_TAG}" --suite-dir "${SUITE_DIR}" \
    --bc-manifest "${BC_MANIFEST}" --selection "${BC_SELECTION}" \
    --dataset-dir "${DATASET}" --handoff "${HANDOFF}" \
    --python "${PYTHON}" --output "${PPO_MANIFEST}"
}

stop_phase_children() {
  local pid wait_pids=()
  for pid in "${TRAINER_PIDS[@]:-}" "${EVALUATOR_PIDS[@]:-}"; do
    [[ -n "${pid}" ]] || continue
    kill "${pid}" >/dev/null 2>&1 || true
    wait_pids+=("${pid}")
  done
  if [[ -n "${MONITOR_PID}" ]]; then
    kill "${MONITOR_PID}" >/dev/null 2>&1 || true
    wait_pids+=("${MONITOR_PID}")
  fi
  for pid in "${wait_pids[@]:-}"; do
    [[ -n "${pid}" ]] || continue
    wait "${pid}" >/dev/null 2>&1 || true
  done
  TRAINER_PIDS=()
  EVALUATOR_PIDS=()
  EVALUATOR_SOCKETS=()
  MONITOR_PID=""
}

monitor_phase() {
  local phase="$1" output="${SUITE_DIR}/hardware/${phase}_usage.csv"
  mkdir -p "${SUITE_DIR}/hardware"
  echo "unix_time,gpu0_mem_mib,gpu0_util,gpu1_mem_mib,gpu1_util,mem_available_mib,swap_used_mib" >"${output}"
  while true; do
    local gpu_rows g0m g0u g1m g1u mem_available swap_used
    gpu_rows="$(nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader,nounits)"
    g0m="$(sed -n '1{s/,.*//;s/ //g;p}' <<<"${gpu_rows}")"
    g0u="$(sed -n '1{s/.*,//;s/ //g;p}' <<<"${gpu_rows}")"
    g1m="$(sed -n '2{s/,.*//;s/ //g;p}' <<<"${gpu_rows}")"
    g1u="$(sed -n '2{s/.*,//;s/ //g;p}' <<<"${gpu_rows}")"
    mem_available="$(awk '/MemAvailable:/ {printf "%d", $2/1024}' /proc/meminfo)"
    swap_used="$(awk '/SwapTotal:/ {t=$2} /SwapFree:/ {f=$2} END {printf "%d", (t-f)/1024}' /proc/meminfo)"
    echo "$(date +%s),${g0m},${g0u},${g1m},${g1u},${mem_available},${swap_used}" >>"${output}"
    sleep 30
  done
}

start_evaluator() {
  local phase="$1" manifest="$2" gpu="$3"
  local cpus="${VAL_CPUS[$gpu]}" socket="/tmp/${UNIT}-${phase}-g${gpu}.sock"
  local log="${SUITE_DIR}/service_logs/${phase}_g${gpu}_eval.log"
  rm -f -- "${socket}"
  env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
    /usr/bin/taskset --cpu-list "${cpus}" \
    "${PYTHON}" -u "${EVALUATOR}" \
      --source-command-json "${manifest}" --socket-path "${socket}" \
      --cpu-pool "${cpus}" \
      --run-dir "${SUITE_DIR}/shared_evaluator/${phase}_g${gpu}" \
      --eval-dataset-dir "${VALIDATION_DIR}" --max-eval-cases 60 \
      --eval-partition-seed 20260811 \
      --eval-partition-stratify-by distribution \
      >"${log}" 2>&1 &
  EVALUATOR_PIDS[$gpu]="$!"
  local deadline=$((SECONDS + 1200))
  while (( SECONDS < deadline )); do
    kill -0 "${EVALUATOR_PIDS[$gpu]}" >/dev/null 2>&1 || {
      echo "[Error] ${phase} GPU${gpu} evaluator exited" >&2
      return 1
    }
    if [[ -S "${socket}" ]] && "${PYTHON}" - "${socket}" <<'PY'
import sys
from onpolicy.utils.shared_eval import SharedEvalClient
reply = SharedEvalClient(sys.argv[1], timeout_seconds=5.0).ping()
raise SystemExit(0 if int(reply.get('worker_count', -1)) == 12 else 1)
PY
    then
      printf '%s\n' "${socket}"
      EVALUATOR_SOCKETS[$gpu]="${socket}"
      return 0
    fi
    sleep 2
  done
  echo "[Error] ${phase} GPU${gpu} evaluator readiness timeout" >&2
  return 1
}

run_training_phase() {
  local phase="$1" manifest="$2"
  shift 2
  local methods=("$@") sockets=("" "")
  local gpu lane method cpus delay log record failed=0
  mkdir -p "${SUITE_DIR}/service_logs" "${SUITE_DIR}/records"
  start_evaluator "${phase}" "${manifest}" 0
  start_evaluator "${phase}" "${manifest}" 1
  sockets[0]="${EVALUATOR_SOCKETS[0]}"
  sockets[1]="${EVALUATOR_SOCKETS[1]}"
  monitor_phase "${phase}" &
  MONITOR_PID="$!"
  for lane in 0 1 2 3 4 5; do
    gpu=$((lane / 3))
    method="${methods[$lane]}"
    cpus="${TRAIN_CPUS[$lane]}"
    delay=$(((lane % 3) * START_STAGGER_SECONDS))
    log="${SUITE_DIR}/service_logs/${phase}_g${gpu}l$((lane % 3))_${method}.log"
    record="${SUITE_DIR}/records/${phase}_g${gpu}l$((lane % 3)).json"
    env CUDA_VISIBLE_DEVICES="${gpu}" CUDA_DEVICE_ORDER=PCI_BUS_ID \
      /usr/bin/taskset --cpu-list "${cpus}" \
      "${PYTHON}" -u "${TRIAL_RUNNER}" \
        --manifest "${manifest}" --command-key "${method}" \
        --gpu "${gpu}" --cpu-set "${cpus}" \
        --shared-eval-socket "${sockets[$gpu]}" \
        --shared-eval-cpu-set "${VAL_CPUS[$gpu]}" --eval-workers 12 \
        --start-delay-seconds "${delay}" --record "${record}" \
        >"${log}" 2>&1 &
    TRAINER_PIDS+=("$!")
    echo "[Launch] ${phase} GPU${gpu} lane=$((lane % 3)) ${method} CPUs=${cpus}"
  done
  for lane in 0 1 2 3 4 5; do
    if ! wait "${TRAINER_PIDS[$lane]}"; then
      echo "[Error] ${phase} method ${methods[$lane]} failed" >&2
      failed=1
    fi
  done
  stop_phase_children
  (( failed == 0 )) || return 1
  echo "[Phase] ${phase} all six methods completed"
}

run_ppo_memory_canary() {
  local socket method cpus log record lane failed=0
  start_evaluator canary "${PPO_CANARY_MANIFEST}" 0
  socket="${EVALUATOR_SOCKETS[0]}"
  monitor_phase ppo_memory_canary &
  MONITOR_PID="$!"
  for lane in 0 1 2; do
    method="${PPO_CANARY_METHODS[$lane]}"
    cpus="${TRAIN_CPUS[$lane]}"
    log="${SUITE_DIR}/service_logs/ppo_memory_canary_g0l${lane}_${method}.log"
    record="${SUITE_DIR}/records/ppo_memory_canary_g0l${lane}.json"
    env CUDA_VISIBLE_DEVICES=0 CUDA_DEVICE_ORDER=PCI_BUS_ID \
      /usr/bin/taskset --cpu-list "${cpus}" \
      "${PYTHON}" -u "${TRIAL_RUNNER}" \
        --manifest "${PPO_CANARY_MANIFEST}" --command-key "${method}" \
        --gpu 0 --cpu-set "${cpus}" --shared-eval-socket "${socket}" \
        --shared-eval-cpu-set "${VAL_CPUS[0]}" --eval-workers 12 \
        --start-delay-seconds "$((lane * START_STAGGER_SECONDS))" \
        --record "${record}" >"${log}" 2>&1 &
    TRAINER_PIDS+=("$!")
  done
  for lane in 0 1 2; do
    if ! wait "${TRAINER_PIDS[$lane]}"; then
      echo "[Error] PPO memory canary ${PPO_CANARY_METHODS[$lane]} failed" >&2
      failed=1
    fi
  done
  stop_phase_children
  (( failed == 0 )) || return 1
  echo "[Canary] P3/P4/P5 three-lane graph=1500 updates passed"
}

controller() {
  trap stop_phase_children EXIT INT TERM
  mkdir -p "${SUITE_DIR}"/{commands,analysis,artifacts,service_logs,records,shared_evaluator,hardware,teachers}
  echo "[Pipeline] phase=teacher_canary"
  run_teacher_canary
  echo "[Pipeline] phase=matched_train600_iga"
  run_teachers
  echo "[Pipeline] phase=device_bc_screen"
  prepare_bc
  run_training_phase bc "${BC_MANIFEST}" "${BC_METHODS[@]}"
  echo "[Pipeline] phase=device_bc_selection"
  prepare_ppo
  echo "[Pipeline] phase=ppo_memory_canary"
  run_ppo_memory_canary
  echo "[Pipeline] phase=resource_ppo_screen"
  run_training_phase ppo "${PPO_MANIFEST}" "${PPO_METHODS[@]}"
  "${PYTHON}" - "${SUITE_DIR}/pipeline_completed.json" "${BC_SELECTION}" <<'PY'
import json, os, sys, time
from pathlib import Path
target, selection_path = map(Path, sys.argv[1:])
payload = {
    'status': 'completed',
    'completed_unix_time': time.time(),
    'device_bc_selection': json.loads(selection_path.read_text()),
}
temporary = target.with_name(f'.{target.name}.tmp.{os.getpid()}')
temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
os.replace(temporary, target)
PY
  echo "[Pipeline] all matched-IGA DeviceBC and PPO experiments completed"
}

verify_cpu_topology() {
  "${PYTHON}" - "${SHARD_CPUS[@]}" "${TRAIN_CPUS[@]}" "${VAL_CPUS[@]}" <<'PY'
import os, sys

def expand(spec):
    values=set()
    for part in spec.split(','):
        lo, sep, hi = part.partition('-')
        values.update(range(int(lo), int(hi)+1) if sep else [int(lo)])
    return values

if os.cpu_count() != 144:
    raise SystemExit(f'expected 144 logical CPUs, got {os.cpu_count()}')
groups=[expand(value) for value in sys.argv[1:]]
shards, trainers, validators = groups[:8], groups[8:14], groups[14:]
if any(len(group) != 18 for group in shards):
    raise SystemExit('every IGA shard must own 18 logical CPUs')
if len(set().union(*shards)) != 144 or sum(map(len, shards)) != 144:
    raise SystemExit('IGA shard CPU partition must cover 144 CPUs without overlap')
for node in range(2):
    phase_groups = trainers[node*3:(node+1)*3] + [validators[node]]
    if [len(group) for group in phase_groups] != [20,20,20,12]:
        raise SystemExit(f'GPU{node} training partition widths are invalid')
    if len(set().union(*phase_groups)) != 72:
        raise SystemExit(f'GPU{node} training partition overlaps')
for group in shards + trainers + validators:
    for cpu in group:
        sibling = cpu + 72 if cpu < 72 else cpu - 72
        if sibling not in group:
            raise SystemExit(f'CPU set splits SMT siblings {cpu}/{sibling}')
print('[CPU] verified 8x18 IGA and per-GPU 3x20+12 training partitions')
PY
}

initial_launch() {
  local required load_state compute_pids
  for required in "${PYTHON}" "${IGA_RUNNER}" "${PREPARER}" \
    "${TRIAL_RUNNER}" "${EVALUATOR}" "${DATASET}" "${VALIDATION_DIR}" \
    "${CHECKPOINT}" "${SOURCE_COMMAND}" "${HANDOFF}" \
    /usr/bin/taskset /usr/bin/nvidia-smi; do
    [[ -e "${required}" ]] || {
      echo "[Error] missing input: ${required}" >&2
      exit 1
    }
  done
  [[ "${RUN_TAG}" =~ ^[A-Za-z0-9._-]+$ && "${UNIT}" =~ ^[A-Za-z0-9._-]+$ ]] || {
    echo "[Error] RUN_TAG/UNIT is not path safe" >&2
    exit 1
  }
  verify_cpu_topology
  [[ ! -e "${SUITE_DIR}" ]] || {
    echo "[Error] refusing existing suite: ${SUITE_DIR}" >&2
    exit 1
  }
  systemctl --user show-environment >/dev/null
  load_state="$(systemctl --user show "${UNIT}.service" --property=LoadState --value 2>/dev/null || true)"
  [[ -z "${load_state}" || "${load_state}" == not-found ]] || {
    echo "[Error] systemd unit already exists: ${UNIT}.service" >&2
    exit 1
  }
  [[ "$(nvidia-smi --query-gpu=index --format=csv,noheader,nounits | wc -l)" -ge 2 ]] || {
    echo "[Error] two CUDA GPUs are required" >&2
    exit 1
  }
  compute_pids="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | sed '/^[[:space:]]*$/d')"
  [[ -z "${compute_pids}" ]] || {
    echo "[Error] refusing launch while GPU compute processes exist: ${compute_pids//$'\n'/,}" >&2
    exit 1
  }
  mkdir -p "${SUITE_DIR}/service_logs" "/tmp/${UNIT}/matplotlib"
  systemd-run --user --unit="${UNIT}" --same-dir \
    --setenv=PYTHONHASHSEED=0 \
    --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
    --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 \
    --setenv=OPENBLAS_NUM_THREADS=1 --setenv=NUMEXPR_NUM_THREADS=1 \
    --setenv="MPLCONFIGDIR=/tmp/${UNIT}/matplotlib" \
    --setenv="RUN_TAG=${RUN_TAG}" --setenv="SUITE_DIR=${SUITE_DIR}" \
    --setenv="UNIT=${UNIT}" \
    --property=Type=exec --property=Restart=no \
    --property=KillMode=control-group --property=TimeoutStopSec=300 \
    --property=LimitNOFILE=65536 \
    --property=AllowedCPUs=0-143 --property=CPUAffinity=0-143 \
    --property="StandardOutput=append:${SUITE_DIR}/service_logs/controller.log" \
    --property="StandardError=append:${SUITE_DIR}/service_logs/controller.log" \
    /bin/bash "${BASH_SOURCE[0]}" --controller >/dev/null
  echo "[Started] ${UNIT}.service"
  echo "[Started] suite=${SUITE_DIR}"
  echo "[Started] phase 1 is matched hard train600 IGA-180 -> IGA-1800"
}

if [[ "${1:-}" == --controller ]]; then
  [[ $# -eq 1 ]] || { echo "Usage: $0 --controller" >&2; exit 2; }
  controller
elif [[ $# -eq 0 ]]; then
  initial_launch
else
  echo "Usage: $0" >&2
  exit 2
fi
