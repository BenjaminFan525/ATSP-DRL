#!/usr/bin/env python3
"""Train-only causal-label/recurrent learnability checks, with no promotion."""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from torch_geometric.data import Batch
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.config.config import get_config
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.run_stage2_bc_injection_suite import verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import parse_args, make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config, supervised_optimizer_step
from onpolicy.utils.stage2_cost_improvement import (
    CostIteration, actor_forward, cost_preference_loss, policy_digest, deterministic_learner_mode,
)

OLD_WAIT = ROOT / ('onpolicy/scripts/results/HKBZ/simple/gnn_mappo/'
    'stage2_wait_accel_20260906_gpu0_half_pilot_r1_M3_edge_wait_seed11/run1/logs/wait_counterfactual_evidence.jsonl')


def audit_old_wait():
    """Recover both directions; do not relabel this teacher evidence as Q_pi."""
    rows = [json.loads(line) for line in OLD_WAIT.read_text().splitlines()]
    unique = {}
    for row in rows:
        unique.setdefault(row['evidence_id'], row)
    counts = dict(wait_better=0, dispatch_better=0, tie=0, other=0, incomplete=0,
                  accepted=0, physically_different_dispatch_ties=0)
    strict = {'dispatch_better': 0, 'tie': 0}
    for row in unique.values():
        outcomes = [row['wait'], *row['dispatches']]
        if not all(x['completed'] and np.isfinite(x['makespan']) for x in outcomes):
            counts['incomplete'] += 1
            continue
        wait = row['wait']['makespan']
        dispatch = min(x['makespan'] for x in row['dispatches'])
        delta = dispatch - wait
        strict['dispatch_better'] += int(delta < -1e-6)
        strict['tie'] += int(abs(delta) <= 1e-6)
        if delta < -1.:
            counts['dispatch_better'] += 1
        elif abs(delta) <= 1.:
            counts['tie'] += 1
        elif row['accepted']:
            counts['wait_better'] += 1
        else:
            counts['other'] += 1
        counts['accepted'] += int(row['accepted'])
        values = [x['makespan'] for x in row['dispatches']]
        counts['physically_different_dispatch_ties'] += int(any(
            abs(values[i] - values[j]) <= 1. for i in range(len(values)) for j in range(i)))
    if len(unique) != 1159 or counts['accepted'] != 509 or counts['incomplete']:
        raise ValueError(f'Historical evidence corpus differs from the reviewed 1159/509: {counts}')
    return dict(path=str(OLD_WAIT), sha256=hashlib.sha256(OLD_WAIT.read_bytes()).hexdigest(),
        unique_states=len(unique), counts_with_one_second_tie_band=counts,
        strict_comparison_tolerance_seconds=1e-6, strict_direction_counts=strict,
        measured_gradient_conflict_frequency=None,
        finding='Negative-direction evidence cannot be discarded; old set/full-edge targets can oppose '
                'completed-cost order; snapshot-specific gradients were not archived in the old run',
        mitigation='new loss masks every old resource loss on the whole evidenced joint action, including ties',
        limitation='old CPU frozen-S1 + projected-teacher continuation is NOT frozen-student cost evidence')


def make_runner(args, manifest, output):
    payload = torch.load(manifest['warmstart_sources']['B0_none']['path'], map_location='cpu', weights_only=True)
    for key, value in ready_head_config(payload).items():
        setattr(args, key, value)
    envs, _ = make_train_env(args)
    try:
        policy = GNN_MAPPOPolicy(args, yaml.safe_load(Path(args.ac_config).read_text()), device=torch.device('cuda:0'))
        policy.load_model_state(payload['model'])
        policy.ac.eval()
        policy.ac.tau = args.evaluation_tau
        runner = SimpleNamespace(all_args=args, policy=policy, envs=envs, device=torch.device('cuda:0'),
            n_rollout_threads=args.n_rollout_threads, num_agents=args.max_agent_num + args.max_device_num,
            episode_length=args.rollout_max_steps, request_ready_loss_coef=0.,
            device_bc_training_scope='policy_frozen_ready', exact_resume_stage2_supervised=False,
            log_dir=output)
        runner._active_masks_from_info = lambda infos: HKBZ_Runner._active_masks_from_info(runner, infos)
        runner._authoritative_policy_history = HKBZ_Runner._authoritative_policy_history
        return runner
    except BaseException:
        envs.close()
        raise


def microfit(runner, samples, contract):
    """Discarded diagnostic copy, exact current-parameter prefix before EVERY update."""
    if not samples:
        return dict(passed=False, reason='no_non_tied_cost_samples')
    policy = copy.copy(runner.policy)
    policy.ac = copy.deepcopy(runner.policy.ac)
    fake = SimpleNamespace(policy=policy, device_bc_training_scope='policy_frozen_ready',
                           device_bc_train_gnn=False, training_stage='resource_joint')
    modules = HKBZ_Runner._device_bc_trainable_modules(fake)
    allowed = {id(p) for module in modules for p in module.parameters()}
    for p in policy.ac.parameters():
        p.requires_grad_(id(p) in allowed)
    deterministic_learner_mode(policy)
    for module in policy.ac.modules():
        if isinstance(module, torch.nn.RNNBase):
            module.flatten_parameters()
    optimizer = torch.optim.Adam([p for p in policy.ac.parameters() if p.requires_grad],
        lr=contract['microfit_lr'])

    def measure(sample):
        obs, active, history, types, labels, prefix, item = sample
        hidden = np.zeros((len(obs), runner.num_agents, runner.all_args.recurrent_N,
                           runner.all_args.hidden_size), np.float32)
        for graphs, masks, past, kinds, dones in prefix:
            _, hidden = actor_forward(policy, graphs, hidden, masks, past, kinds)
            hidden[dones] = 0.
        resources = active.copy()
        resources[:, :policy.ac.max_plane_agents] = 0.
        outputs = policy.evaluate_actions(Batch.from_data_list(obs), hidden, resources,
            history[..., 0], history[..., 1], labels, agent_types=types,
            return_decision_mask=True, return_log_prob_components=True)
        scores = outputs[3]['resource_action_logits'][item['env'], item['rows']]
        return cost_preference_loss(scores, item['candidates'], item['costs'],
            scale=runner.all_args.stage2_cost_scale_seconds, clip=runner.all_args.stage2_cost_weight_clip,
            tie_seconds=runner.all_args.stage2_cost_tie_seconds)

    def summary():
        with torch.no_grad():
            values = [measure(sample) for sample in samples]
        return dict(loss=float(np.mean([float(loss) for loss, _ in values])),
                    mean_candidate_regret=float(np.mean([m['regret'] for _, m in values])))

    before = summary()
    steps = 0
    for step in range(contract['microfit_steps']):
        loss, _ = measure(samples[step % len(samples)])
        _, did_step = supervised_optimizer_step(loss, optimizer, enabled=True, max_grad_norm=1.)
        steps += int(did_step)
        if step % 10 == 0:
            print(f'[CostMicrofit] update={step} loss={float(loss.detach()):.6f}', flush=True)
    after = summary()
    passed = bool(steps == contract['microfit_steps'] and before['loss'] > 0
        and after['loss'] <= before['loss'] * contract['microfit_loss_ratio_max']
        and after['mean_candidate_regret'] <= before['mean_candidate_regret'])
    return dict(passed=passed, samples=len(samples), optimizer_steps=steps, before=before, after=after,
        prefix_contract='exact_current_parameters_from_zero_before_every_step',
        weights_discarded=True, scientific_generalization_claim=False)


def diagnose(cli):
    manifest_path = cli.manifest.resolve()
    manifest = json.loads(manifest_path.read_text())
    if manifest['profile'] != 'diagnostic':
        raise ValueError('Phase A requires a diagnostic manifest.')
    verify_resources(manifest)
    output = manifest_path.parent / 'diagnostics'
    output.mkdir(exist_ok=False)
    report_path = output / 'report.json'
    report = dict(manifest=str(manifest_path), status='running', started_unix_time=time.time(),
        diagnostic_gate_passed=False, scientific_result=False, phases={})
    atomic_json(report_path, report)
    runner = None
    try:
        report['phases']['A2_old_label_audit'] = audit_old_wait()
        atomic_json(report_path, report)
        configure_bc_determinism(True)
        torch.set_num_threads(1)
        torch.cuda.set_per_process_memory_fraction(.70, device=0)
        random.seed(11)
        np.random.seed(11)
        torch.manual_seed(11)
        torch.cuda.manual_seed_all(11)
        args = parse_args(manifest['commands']['N2_cost_teacher_seed11']['argv'][2:], get_config())
        args.n_rollout_threads = args.max_train_cases = args.train_sampling_size = 24
        args.stage2_research_train_cases = str(manifest_path.parent / 'diagnostic_cases.json')
        runner = make_runner(args, manifest, output)
        before_sha = policy_digest(runner.policy)
        iterator = CostIteration(runner, 1)
        runner.envs.call('reset_data_cursor')
        obs, dones, infos = runner.envs.reset()
        hidden = np.zeros((24, runner.num_agents, args.recurrent_N, args.hidden_size), np.float32)
        previous = -np.ones((24, runner.num_agents, 2), np.int64)
        iterator.reset_rollout(hidden)
        baseline_replay, samples, baseline = None, [], {}
        started = time.monotonic()
        for step in range(runner.episode_length):
            active = runner._active_masks_from_info(infos)
            history = runner._authoritative_policy_history(infos, previous, args.max_agent_num)
            hidden = iterator.prepare(obs, active, history, infos, hidden)
            actions, next_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            if step == 0:
                runner.envs.call('stage2_cost_branch_capture')
                baseline_replay = iterator.branch(obs, infos, history, actions, None)
                runner.envs.call('stage2_cost_branch_clear')
                if not baseline_replay['completed']:
                    raise ValueError('No-intervention frozen-student replay did not complete.')
            labels = runner.envs.call('resource_iga_teacher_actions', return_info=True,
                include_ready_targets=False, deployment_projection=True)
            teacher_actions = np.stack([x['actions'] for x in labels])
            evidence = iterator.evidence(obs, active, history, infos, actions, teacher_actions)
            for item in evidence:
                if (len(samples) < manifest['diagnostic_contract']['max_microfit_samples']
                        and all(x is not None for x in item['costs'])
                        and max(item['costs']) - min(item['costs']) > args.stage2_cost_tie_seconds):
                    samples.append(([g.clone() for g in obs], active.copy(), history.copy(),
                        np.asarray(infos['agent_types']).copy(), actions.copy(),
                        copy.deepcopy(iterator.prefix), item))
            old_obs, old_types = obs, infos['agent_types']
            obs, _, dones, infos = runner.envs.step(actions)
            iterator.finish_step(old_obs, active, history, old_types, dones)
            next_hidden[dones] = 0.
            hidden, previous = next_hidden, actions
            if step % 25 == 0:
                report.update(phase='A1_student_and_candidate_costs', event_step=step,
                    queries=iterator.counts['candidate_queries'], elapsed_seconds=time.monotonic()-started)
                atomic_json(report_path, report)
                print(f'[CostDiagnosis] step={step} queries={iterator.counts["candidate_queries"]}', flush=True)
            if np.all(dones):
                break
        else:
            raise ValueError('Student diagnostic trajectory did not complete.')
        statuses = runner.envs.call('stage2_cost_live_status')
        expected = baseline_replay['case_statuses']
        if not all(x['completed'] and x['makespan'] == y['makespan'] for x, y in zip(statuses, expected)):
            raise ValueError('Full-batch snapshot/no-intervention replay was not exactly equal to live rollout.')
        iterator.finish_epoch()
        baseline = [dict(case=x['case'], makespan=x['makespan']) for x in statuses]
        report['phases']['A1_student'] = dict(cases=baseline, zero_intervention_replay_exact=True,
            replay=baseline_replay, costs=iterator.counts)
        report.update(phase='A1_derived_IGA_teacher')
        atomic_json(report_path, report)
        runner.envs.call('reset_data_cursor')
        obs, dones, infos = runner.envs.reset()
        hidden[:] = 0.
        previous[:] = -1
        for step in range(runner.episode_length):
            active = runner._active_masks_from_info(infos)
            history = runner._authoritative_policy_history(infos, previous, args.max_agent_num)
            actions, next_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            labels = runner.envs.call('resource_iga_teacher_actions', return_info=True,
                include_ready_targets=False, deployment_projection=True)
            teacher = np.stack([x['actions'] for x in labels])
            resource_active = active[..., 0] > 0
            resource_active[:, :args.max_agent_num] = False
            actions[resource_active] = teacher[resource_active]
            obs, _, dones, infos = runner.envs.step(actions)
            next_hidden[dones] = 0.
            hidden, previous = next_hidden, actions
            if step % 100 == 0:
                print(f'[TeacherDiagnosis] step={step}', flush=True)
            if np.all(dones):
                break
        else:
            raise ValueError('Deployment-compatible IGA teacher did not complete.')
        teachers = runner.envs.call('stage2_cost_live_status')
        if not all(x['completed'] for x in teachers):
            raise ValueError('Incomplete derived teacher diagnosis.')
        report['phases']['A1_projected_teacher'] = dict(cases=teachers,
            baseline_mean=float(np.mean([x['makespan'] for x in baseline])),
            teacher_mean=float(np.mean([x['makespan'] for x in teachers])),
            empirical_reference_not_upper_bound=True,
            historical_IGA1800_is_not_same_runtime_reference=True)
        report.update(phase='A3_recurrent_microfit')
        atomic_json(report_path, report)
        fit = microfit(runner, samples, manifest['diagnostic_contract'])
        report['phases']['A3_microfit'] = fit
        if policy_digest(runner.policy) != before_sha:
            raise ValueError('Diagnostic changed source policy weights.')
        counts = iterator.counts
        # Predict actual work from the locked 24-case sample, not by pretending
        # every selected state necessarily has four distinct legal candidates.
        candidate_seconds = counts['continuation_wall_seconds'] - baseline_replay['wall_seconds']
        query_seconds = candidate_seconds / max(1, counts['candidate_queries'])
        estimate = candidate_seconds * (240 / 24) * 2 * 2
        report['pilot_cost_only_sequential_estimate_seconds'] = estimate
        report['pilot_cost_upper_budget_sequential_estimate_seconds'] = 7680 * query_seconds
        report['pilot_estimate_contract'] = 'observed_candidate_density_x10_cases_x2_epochs_x2_cost_arms; no parallel speedup assumed'
        report['diagnostic_gate_passed'] = bool(fit['passed'] and counts['incomplete'] == 0
            and estimate <= manifest['diagnostic_contract']['pilot_wall_estimate_limit_seconds'])
        report.update(status='completed', phase='finished', ended_unix_time=time.time(),
            pilot_launch_allowed=report['diagnostic_gate_passed'],
            limitation='Historical IGA costs retain the old runtime/budget caveat; formal target not certified.')
        atomic_json(report_path, report)
        print(json.dumps({'diagnostic_gate_passed': report['diagnostic_gate_passed'],
                          'microfit': fit, 'pilot_cost_estimate_seconds': estimate}), flush=True)
        return 0 if report['diagnostic_gate_passed'] else 2
    except BaseException as error:
        report.update(status='failed', error=str(error), ended_unix_time=time.time())
        atomic_json(report_path, report)
        raise
    finally:
        if runner is not None:
            runner.envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    raise SystemExit(diagnose(parser.parse_args()))
