#!/usr/bin/env python3
"""Freeze a new, evaluation-only H/F manifest after passed GPU engineering."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_hf import (
    ALLOWED_CPUS, CAPACITY, GPU_UUID, GRID, PARENT, PLAN, PROTOCOL, SLOTS,
    SOURCE_SHA, TRAIN_ARMS, WORKERS, binding, evaluation_jobs, sha, validate_manifest,
)
from onpolicy.utils.stage2_bc_replay import validate_case_content


def inputs():
    path = ROOT / PARENT
    parent = json.loads(path.read_text())
    if sha(parent['source']['path']) != SOURCE_SHA:
        raise ValueError('Immutable B0 checkpoint changed.')
    payload = torch.load(parent['source']['path'], map_location='cpu', weights_only=True)
    return dict(parent_manifest=binding(path), source=copy.deepcopy(parent['source']),
        stage1_source=copy.deepcopy(parent['stage1_source']),
        source_planning_contract=copy.deepcopy(payload['resource_lookahead_contract']),
        model_arguments={k: copy.deepcopy(parent[k]) for k in ('environment_argv', 'training_contract')},
        train=copy.deepcopy(parent['train']), evaluation=copy.deepcopy(parent['evaluation']))


def fingerprints():
    result = code_fingerprint()
    for name in (PLAN, 'onpolicy/scripts/train/launch_stage2_bc_hf_gpu0.sh'):
        result[name] = sha(ROOT / name)
    return result


def prepare(destination, proof_path):
    destination, proof_path = destination.resolve(), proof_path.resolve()
    if destination.exists():
        raise FileExistsError('A fresh output directory is required; no retry or overwrite.')
    proof = json.loads(proof_path.read_text())
    if (proof.get('passed') is not True or set(proof.get('arms', {})) != set(GRID)
            or proof.get('actor_updates') != 0 or proof.get('teacher_queries') != 0
            or proof.get('full_evaluation') is not False
            or not proof.get('regression_passed')):
        raise ValueError('Complete zero-update engineering and regression proofs are required.')
    current = fingerprints()
    if proof.get('checked_sources') != current:
        raise ValueError('Implementation changed after engineering/regression checks.')
    m = inputs()
    for role in ('train', 'evaluation'):
        validate_case_content(m[role]['cases'], m[role]['dataset'])
    m.update(schema_version=1, protocol=PROTOCOL, run_tag=destination.name,
        created_at=datetime.now(timezone.utc).isoformat(),
        authorization=dict(user_request='按照上述思路制定计划并启动，使用GPU0和剩下一半CPU',
            initial_launch_scope='A_only_frozen_HF_grid', future_training_requires_teacher_audit=True),
        material_passport=dict(origin_skill='academic-research-suite/experiment-agent',
            origin_mode='run', origin_date='2026-09-12', verification_status='UNVERIFIED',
            version_label='stage2_bc_hf_v1'),
        jobs=evaluation_jobs(), train_anchors=list(TRAIN_ARMS),
        engineering_proof=binding(proof_path), code_fingerprint=current,
        execution=dict(evaluation_workers=WORKERS, fixed_request_capacity=CAPACITY,
            max_parallel_evaluators=2, total_case_episode_limit=840, evaluation_jobs=14,
            actor_updates=0, critic_updates=0, teacher_queries=0, search_calls=0,
            automatic_training=False, automatic_retry=False, automatic_stage3=False,
            rollout_max_steps=4000, runtime_max_seconds=None),
        resource_contract=dict(gpu=0, gpu_uuid=GPU_UUID, allowed_cpus=ALLOWED_CPUS,
            slots=list(SLOTS), monitor_cpus='30-31,94-95', cuda_memory_fraction=.40,
            blas_threads=1, heartbeat_seconds=30), confirmed_scientific_success=False)
    validate_manifest(m)
    destination.mkdir(parents=True, exist_ok=False)
    archive = destination / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for name, digest in current.items():
            data = (ROOT / name).read_bytes()
            if sha(ROOT / name) != digest:
                raise ValueError('Source changed while archiving.')
            handle.addfile(handle.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(data))
    m['source_archive'] = binding(archive)
    atomic_json(destination / 'manifest.json', m)
    print(destination / 'manifest.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--engineering-proof', type=Path, required=True)
    cli = parser.parse_args()
    prepare(cli.suite_dir, cli.engineering_proof)
