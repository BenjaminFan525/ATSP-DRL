#!/usr/bin/env python3
"""Two isolated V4 workers, explicitly resumed once within the old deadline."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import copy
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.run_stage2_resource_rl import Progress, arguments, cpus, seed
from onpolicy.scripts.train.run_stage2_resource_rl_v4 import Suite
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_resource_rl import file_sha, summary
from onpolicy.utils.stage2_resource_rl_v4 import ARMS
from onpolicy.utils.stage2_resource_rl_v4_fast import FastCaseMinibatchLearner
from onpolicy.utils.stage2_resource_rl_v4_resume import pending_evaluations, restore_learner


def validate_inputs(manifest):
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('Only physical GPU0 is authorized.')
    if not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Process escaped original CPU half.')
    x = manifest['continuation']
    if time.time() >= x['hard_deadline_unix']:
        raise TimeoutError('The original experiment deadline has already expired.')
    for path, expected in x['immutable_inputs'].items():
        if file_sha(path) != expected:
            raise ValueError(f'Pinned continuation input changed: {path}')
    for path, expected in manifest['code_fingerprint'].items():
        if file_sha(ROOT / path) != expected:
            raise ValueError(f'Original pinned source changed: {path}')
    for path, expected in x['new_code_fingerprint'].items():
        if file_sha(ROOT / path) != expected:
            raise ValueError(f'Accelerated pinned source changed: {path}')
    proof = json.loads(Path(x['engineering_proof']['path']).read_text())
    if not proof.get('passed') or set(proof.get('arms', {})) != set(ARMS):
        raise ValueError('Missing passed two-baseline acceleration proof.')


class WorkerSuite(Suite):
    def __init__(self, manifest, arm):
        super().__init__(manifest)
        self.suite_root, self.arm = self.root, arm
        self.x = self.m['continuation']
        self.root = self.suite_root / 'workers' / arm
        self.m = copy.deepcopy(self.m)
        self.m['resource_contract']['train_cpus'] = self.x['worker_cpus'][arm]
        self.m['execution']['total_case_episode_limit'] = self.x['budget']['remaining_by_arm'][arm]['total']
        self.m['execution']['total_training_case_episodes'] = self.x['budget']['remaining_by_arm'][arm]['training']

    @contextmanager
    def phase(self, evaluation=False):
        # The two CUDA allocators are independently capped at 43% each. A
        # tune60 evaluation may overlap the other arm's training, but two
        # evaluations must not compete for the same reserved evaluation CPUs.
        # Neither path changes canonical AR groups or legacy H batch shapes.
        if not evaluation:
            self.progress('gpu_phase_acquired', force=True, phase='training')
            try:
                yield
            finally:
                torch.cuda.empty_cache()
            return
        lock = (self.suite_root / 'gpu_phase.lock').open('a')
        try:
            self.progress('waiting_for_evaluation_slot', force=True, phase='phase_queue')
            fcntl.flock(lock, fcntl.LOCK_EX)
            self.progress('gpu_phase_acquired', force=True, phase='evaluation')
            try:
                yield
            finally:
                torch.cuda.empty_cache()
                fcntl.flock(lock, fcntl.LOCK_UN)
        finally:
            lock.close()

    def evaluate_missing(self):
        state = self.arm_state[self.arm]
        labels = pending_evaluations(self.arm, state['completed_rounds'], self.evaluations,
            self.c, state['status'] == 'paused_for_kl')
        if labels:
            with self.phase(evaluation=True):
                for label in labels:
                    self.evaluate(self.learners[self.arm], label, hungarian=label.endswith('_H_DIAGNOSTIC'))

    def resume_policy(self):
        seed(self.c['seed'] + 100000)
        policy = GNN_MAPPOPolicy(self.args, self.ac_config, torch.device('cuda:0'))
        policy.load_model_state(self.payload['model'])
        policy.ac.tau, policy.ac.device_global_matching = self.args.evaluation_tau, False
        policy.capture_bc_reference(self.payload['model'])
        policy.bc_reference_ac.device_global_matching = False
        baseline = 'rollout' if self.arm == ARMS[0] else 'value'
        learner = FastCaseMinibatchLearner(policy, self.args, {**self.c, 'baseline': baseline}, self.progress,
            cache_max_bytes=self.x['acceleration']['replay_gpu_cache_bytes'])
        selected = self.x['checkpoints'][self.arm]
        checkpoint = torch.load(selected['path'], map_location='cpu', weights_only=True)
        report = restore_learner(learner, checkpoint, self.arm)
        if summary(policy.bc_reference_ac) != summary(self.payload['model']):
            raise ValueError('Reference is not the exact original B0.')
        atomic_json(self.root / 'checks/full_checkpoint_restore.json', report)
        self.learners[self.arm] = learner
        self.arm_state[self.arm] = copy.deepcopy(selected['state'])

    def train_remaining(self):
        self.evaluate_missing()
        state, learner = self.arm_state[self.arm], self.learners[self.arm]
        train = self.m['train']['cases']
        batches = self.m['train']['collection_batches']
        for round_index in range(state['completed_rounds'] + 1, self.c['rounds'] + 1):
            if state['status'] == 'paused_for_kl':
                break
            rows = [train[i] for i in batches[(round_index - 1) % len(batches)]]
            with self.phase():
                state['status'] = 'running'
                self.progress('round_start', force=True, phase='training', arm=self.arm,
                    collection_round=round_index, total_rounds=self.c['rounds'], actor_steps=learner.actor_steps,
                    completed_rounds=state['completed_rounds'], critic_steps=learner.critic_steps)
                rollout = self.collect_batch(learner, rows, training=True,
                    rollout_seed=self.c['seed'] + 300000 + round_index)
                state['case_episodes'] += len(rows)
                atomic_json(self.root / self.arm / f'round_{round_index}_rollout.json',
                    {k: v for k, v in rollout.items() if k not in ('frames', 'targets')})
                started = time.monotonic()
                update = learner.update(rollout, round_index=round_index, reference_cmax=self.reference_cmax)
                update['seconds'] = time.monotonic() - started
                atomic_json(self.root / self.arm / f'round_{round_index}_update.json', update)
                state['rounds'].append(dict(round=round_index, collection_seconds=rollout['seconds'], update=update))
                del rollout
                state['completed_rounds'] = round_index
                paused = update['paused_for_kl']
                complete = round_index == self.c['rounds'] and not paused
                state['status'] = 'paused_for_kl' if paused else 'completed' if complete else 'running'
                state['checkpoint'] = self.checkpoint(self.arm, round_index, completed=complete)
                atomic_json(self.root / self.arm / 'result.json', state)
                self.progress('round_completed', force=True, completed_rounds=round_index,
                    actor_steps=learner.actor_steps, critic_steps=learner.critic_steps)
            self.evaluate_missing()
        return state['status'] == 'completed'

    def run(self):
        validate_inputs(self.m)
        self.root.mkdir(parents=True, exist_ok=False)
        (self.root / self.arm).mkdir()
        self.progress = Progress(self.root, self.c['hard_timeout_seconds'])
        self.progress.started = self.x['original_started_unix']
        self.progress.limit = self.x['hard_deadline_unix'] - self.progress.started
        self.progress.state.update(started_unix=self.progress.started, resumed_unix=time.time(),
            original_parent=self.x['parent_manifest'], arm=self.arm, automatic_retry=False)
        def stop(signum, frame):
            if signum == signal.SIGALRM:
                raise TimeoutError('Original Stage2 hard deadline reached; no automatic retry.')
            raise KeyboardInterrupt(f'Operator/service signal {signum}')
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGALRM, stop)
        signal.alarm(max(1, int(self.x['hard_deadline_unix'] - time.time())))
        try:
            os.sched_setaffinity(0, cpus(self.x['worker_cpus'][self.arm]))
            configure_bc_determinism(True)
            torch.set_num_threads(1)
            torch.cuda.set_per_process_memory_fraction(self.x['acceleration']['cuda_memory_fraction_per_worker'], 0)
            self.args = arguments(self.m)
            self.args.safe_async_graph_clone_workers = self.x['acceleration']['async_graph_clone_workers']
            self.payload = torch.load(self.m['source']['path'], map_location='cpu', weights_only=True)
            for key, value in ready_head_config(self.payload).items():
                setattr(self.args, key, value)
            self.ac_config = yaml.safe_load(Path(self.args.ac_config).read_text())
            self.reference_cmax = {r['case_dir']: r['makespan'] for r in json.loads(
                Path(self.x['reference_summary']).read_text())['cases']}
            self.evaluations = {label: json.loads(Path(item['path']).read_text())['cases']
                for label, item in self.x['preserved_evaluations'].items()}
            self.resume_policy()
            state = self.arm_state[self.arm]
            atomic_json(self.root / self.arm / 'result.json', state)
            self.progress('checkpoint_restored', force=True, completed_rounds=state['completed_rounds'],
                actor_steps=self.learners[self.arm].actor_steps, critic_steps=self.learners[self.arm].critic_steps,
                checkpoint=self.x['checkpoints'][self.arm]['path'])
            completed = self.train_remaining()
            self.progress('completed', force=True, phase='completed',
                status='completed' if completed else 'completed_with_paused_arm',
                completed_physical_case_episodes=self.total_episodes, completed_training_case_episodes=self.training_episodes)
            return 0 if completed else 2
        except BaseException as exc:
            status = 'operator_stopped' if isinstance(exc, KeyboardInterrupt) else 'timeout' if isinstance(exc, TimeoutError) else 'failed'
            self.progress.state.update(status=status, error=str(exc), traceback=traceback.format_exc())
            self.progress.write()
            if self.arm in self.learners:
                try:
                    self.checkpoint(self.arm, self.arm_state[self.arm]['completed_rounds'], completed=False,
                        suffix='checkpoint_interrupted.pt')
                except Exception as save_error:
                    print(f'Interruption save failed: {save_error}', flush=True)
            traceback.print_exc()
            return 1
        finally:
            signal.alarm(0)
            self.progress.stop.set()
            if self.envs is not None:
                self.envs.close()


def aggregate(path, processes, final=False):
    suite = Suite(path)
    x = suite.m['continuation']
    suite.evaluations = {label: json.loads(Path(item['path']).read_text())['cases']
        for label, item in x['preserved_evaluations'].items()}
    suite.attempted_episodes = x['budget']['parent_attempted']
    suite.total_episodes = x['budget']['parent_committed_physical']
    suite.training_episodes = x['budget']['parent_committed_training']
    statuses = {}
    for arm in ARMS:
        root = suite.root / 'workers' / arm
        status_path, result_path = root / 'run_status.json', root / arm / 'result.json'
        status = json.loads(status_path.read_text()) if status_path.exists() else {'status': 'starting'}
        statuses[arm] = {k: status[k] for k in ('status', 'event', 'phase', 'pid', 'collection_round',
            'completed_rounds', 'event_step', 'replay_step', 'actor_steps', 'critic_steps', 'updated_unix', 'error') if k in status}
        suite.arm_state[arm] = json.loads(result_path.read_text()) if result_path.exists() else x['checkpoints'][arm]['state']
        suite.attempted_episodes += status.get('attempted_physical_case_episodes', 0)
        suite.total_episodes += status.get('completed_physical_case_episodes', 0)
        suite.training_episodes += status.get('completed_training_case_episodes', 0)
        for output in (root / 'evaluations').glob('*.json'):
            evaluation = json.loads(output.read_text())
            suite.evaluations[evaluation['label']] = evaluation['cases']
    suite.analyze()
    success = all(p.poll() == 0 for p in processes.values())
    terminal = 'completed' if success else 'completed_with_paused_arm' if all(
        p.poll() in (0, 2) for p in processes.values()) else 'failed'
    atomic_json(suite.root / 'run_status.json', dict(status=terminal if final else 'running',
        pid=os.getpid(), started_unix=x['original_started_unix'], resumed_unix=x['prepared_unix'],
        hard_deadline_unix=x['hard_deadline_unix'], updated_unix=time.time(), arms=statuses,
        process_exit_codes={arm: p.poll() for arm, p in processes.items()},
        attempted_physical_case_episodes=suite.attempted_episodes,
        completed_training_case_episodes=suite.training_episodes,
        original_training_case_limit=960, physical_budget=x['budget'],
        automatic_retry=False, automatic_promotion=False, stage3_started=False))


def supervise(path):
    manifest = json.loads(path.read_text())
    validate_inputs(manifest)
    root = path.parent
    if (root / 'run_status.json').exists():
        raise FileExistsError('A continuation cannot be automatically restarted or overwritten.')
    # Do not overlap old training with its continuation, even on accidental launch.
    old = subprocess.run(['systemctl', '--user', 'is-active', manifest['continuation']['parent_service']],
        capture_output=True, text=True, check=False)
    if old.stdout.strip() in ('active', 'activating', 'deactivating'):
        raise RuntimeError('Original Stage2 service has not fully stopped.')
    os.sched_setaffinity(0, cpus('30-31,94-95'))
    processes, streams = {}, []
    stopping = [False]
    def stop(signum, frame):
        if stopping[0]:
            return
        stopping[0] = True
        for process in processes.values():
            if process.poll() is None:
                process.terminate()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        for arm in ARMS:
            stream = (root / f'{arm}.log').open('x')
            streams.append(stream)
            processes[arm] = subprocess.Popen([sys.executable, '-u', str(Path(__file__).resolve()),
                '--manifest', str(path), '--arm', arm], stdout=stream, stderr=subprocess.STDOUT)
        while any(p.poll() is None for p in processes.values()):
            if time.time() >= manifest['continuation']['hard_deadline_unix']:
                stop(signal.SIGALRM, None)
            aggregate(path, processes)
            # No retry. Stop the sibling on an unexpected worker failure so
            # an engineering failure cannot silently become a one-arm study.
            if any(p.poll() not in (None, 0, 2) for p in processes.values()):
                stop(signal.SIGTERM, None)
            time.sleep(10)
        aggregate(path, processes, final=True)
        return 0 if all(p.returncode == 0 for p in processes.values()) else 2 if all(
            p.returncode in (0, 2) for p in processes.values()) else 1
    finally:
        if any(p.poll() is None for p in processes.values()):
            stop(signal.SIGTERM, None)
        for stream in streams:
            stream.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--arm', choices=ARMS)
    cli = parser.parse_args()
    sys.exit(WorkerSuite(cli.manifest, cli.arm).run() if cli.arm else supervise(cli.manifest.resolve()))
