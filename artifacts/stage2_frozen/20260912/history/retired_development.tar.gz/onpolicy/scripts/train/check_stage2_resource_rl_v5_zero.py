#!/usr/bin/env python3
"""Four-arm, zero-environment GPU regression on the exact saved r3 failure."""
import argparse
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import yaml
from onpolicy.scripts.train.diagnose_stage2_resource_rl_v5_zero import differences
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, cpus
from onpolicy.scripts.train.run_stage2_resource_rl_v5 import SplitSuite
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_resource_rl import file_sha, summary
from onpolicy.utils.stage2_resource_rl_v4_fast import FastCaseMinibatchLearner
from onpolicy.utils.stage2_resource_rl_v5 import ARMS
from onpolicy.utils.stage2_resource_rl_v5_zero import VERSION, initial_reference_kernel_context, non_audit_code_sha

CHANGED_FILE = 'onpolicy/utils/stage2_resource_rl_v5.py'


def main(manifest, fixture_path, output):
    if output.exists() or os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('New report and physical GPU0 required.')
    if not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Outside authorized CPU half.')
    m = json.loads(manifest.read_text())
    if file_sha(m['source']['path']) != m['source']['sha256'] or file_sha(m['source_archive']['path']) != m['source_archive']['sha256']:
        raise ValueError('Immutable prior source changed.')
    with tarfile.open(m['source_archive']['path']) as archive:
        previous_code = archive.extractfile(CHANGED_FILE).read().decode()
    signature = non_audit_code_sha(previous_code)
    if signature != non_audit_code_sha((ROOT / CHANGED_FILE).read_text()):
        raise ValueError('The repair changed the engineering/learning implementation.')
    for name, digest in m['code_fingerprint'].items():
        if name != CHANGED_FILE and file_sha(ROOT / name) != digest:
            raise ValueError(f'Unapproved additional old-code change: {name}')
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.2, 0)
    if str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') != m['resource_contract']['gpu_uuid'].removeprefix('GPU-'):
        raise ValueError('Wrong GPU.')
    # Own local fixture from the recorded failure reproduction, never an external pickle.
    fixture = torch.load(fixture_path, map_location='cpu', weights_only=False)
    args = [fixture['obs']] + [fixture[k].numpy() for k in ('hidden', 'active', 'history', 'types')]
    suite = SplitSuite(manifest, 'setup', 'E0', 0)
    suite.args = arguments(m)
    suite.payload = torch.load(m['source']['path'], map_location='cpu', weights_only=True)
    for k, v in ready_head_config(suite.payload).items():
        setattr(suite.args, k, v)
    suite.ac_config = yaml.safe_load(Path(suite.args.ac_config).read_text())
    suite.progress = lambda *a, **k: None
    results = {}
    for arm in ARMS:
        learner = suite.policy(arm)
        policy = learner.policy
        policy.ac.eval()
        policy.bc_reference_ac.eval()
        actor_before, reference_before = summary(policy.ac), summary(policy.bc_reference_ac)
        with torch.no_grad():
            before, encoded = FastCaseMinibatchLearner.collect_forward(learner, policy, *args, deterministic=True)
            old_reference, _ = FastCaseMinibatchLearner.collect_forward(learner, policy, *args,
                deterministic=True, reference=True, encoded=encoded)
            learner.verify_initial_reference = True
            actual, _ = learner.collect_forward(policy, *args, deterministic=True)
            with initial_reference_kernel_context(policy):
                matched, _ = FastCaseMinibatchLearner.collect_forward(learner, policy, *args,
                    deterministic=True, reference=True, encoded=encoded)
            repaired = differences(actual, matched)
            unchanged = differences(before, actual)
            if any(not repaired[k]['equal'] or not unchanged[k]['equal'] for k in repaired):
                raise ValueError(f'Not bit-exact for {arm}: {repaired}, {unchanged}')
            recorded = {k: v.to(learner.device) for k, v in fixture['current'].items()}
            if arm == 'E0' and any(not r['equal'] for r in differences(recorded, actual).values()):
                raise ValueError('E0 behavior differs from the original failing execution.')
            perturb = policy.bc_reference_ac.transporter_actor.req_query_attn.in_proj_weight
            backup = perturb.detach().clone()
            rejected = False
            try:
                perturb.add_(.1)
                try:
                    learner.collect_forward(policy, *args, deterministic=True)
                except RuntimeError as exc:
                    rejected = 'not zero-update equivalent' in str(exc)
            finally:
                perturb.copy_(backup)
            if not rejected:
                raise ValueError('The audit accepted a genuinely changed reference actor.')
        if (summary(policy.ac) != actor_before or summary(policy.bc_reference_ac) != reference_before
                or any(p.requires_grad or p.grad is not None for p in policy.bc_reference_ac.parameters())):
            raise ValueError('Audit leaked changes into a policy/reference.')
        results[arm] = dict(passed=True, old_frozen_reference=differences(before, old_reference),
            repaired_reference=repaired, behavior_unchanged=unchanged, genuine_drift_rejected=rejected,
            reference_weights_unchanged=True, reference_frozen_after=True,
            actor_steps=learner.actor_steps, critic_steps=learner.critic_steps)
        del learner, policy
    atomic_json(output, dict(passed=True, version=VERSION, arms=results, finished_unix=time.time(),
        source_manifest=str(manifest.resolve()), source_manifest_sha256=file_sha(manifest),
        fixture=str(fixture_path.resolve()), fixture_sha256=file_sha(fixture_path),
        environment_case_episodes=0, scientific_updates=0, synthetic_perturbation_restored=True,
        non_audit_code_sha256=signature, old_changed_file_sha256=m['code_fingerprint'][CHANGED_FILE],
        changed_file_sha256=file_sha(ROOT / CHANGED_FILE),
        repair_helper_sha256=file_sha(ROOT / 'onpolicy/utils/stage2_resource_rl_v5_zero.py'),
        gpu_uuid=str(torch.cuda.get_device_properties(0).uuid), cpu_affinity=sorted(os.sched_getaffinity(0))))
    print(json.dumps(dict(passed=True, arms=list(results), old_logp_error=results['E0']['old_frozen_reference']['log_probs']['max_error'],
        repaired_logp_errors={a:r['repaired_reference']['log_probs']['max_error'] for a,r in results.items()}, output=str(output)), indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    cli = parser.parse_args()
    main(cli.manifest, cli.fixture, cli.output)
