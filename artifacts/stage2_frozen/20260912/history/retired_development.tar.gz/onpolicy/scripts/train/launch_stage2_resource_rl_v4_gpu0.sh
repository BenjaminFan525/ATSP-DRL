#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_PYTHON="${PYTHON:-/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
TASK_TAG="${RUN_TAG:-stage2_bc_rl_v4_20260908_gpu0_half_train240_r1}"
[[ "${TASK_TAG}" =~ ^[a-zA-Z0-9_-]+$ ]] || exit 1
[[ -f "${ENGINEERING_REPORT:-}" ]] || { echo 'ENGINEERING_REPORT must name a passed V4 GPU smoke report' >&2; exit 1; }
TASK_SUITE="${TASK_ROOT}/result/hkbz_train_logs/${TASK_TAG}"
TASK_UNIT="hkbz-${TASK_TAG//_/-}"
[[ ! -e "${TASK_SUITE}" ]] || { echo 'Never reuse an experiment directory' >&2; exit 1; }
export CUDA_VISIBLE_DEVICES=0 CUDA_DEVICE_ORDER=PCI_BUS_ID
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
taskset -c 30-31,94-95 "${TASK_PYTHON}" \
  "${TASK_ROOT}/onpolicy/scripts/train/prepare_stage2_resource_rl_v4.py" \
  --run-tag "${TASK_TAG}" --suite-dir "${TASK_SUITE}" --engineering-report "${ENGINEERING_REPORT}"
if [[ "${DRY_RUN:-0}" == 1 ]]; then exit 0; fi
systemd-run --user --unit="${TASK_UNIT}" --working-directory="${TASK_ROOT}" \
  --setenv=PATH="${PATH}" --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
  --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 --setenv=OPENBLAS_NUM_THREADS=1 \
  --setenv=NUMEXPR_NUM_THREADS=1 --setenv=PYTHONHASHSEED=0 \
  --setenv=CUBLAS_WORKSPACE_CONFIG=:4096:8 --setenv=PYTHONDONTWRITEBYTECODE=1 \
  --setenv=MPLCONFIGDIR="${TASK_SUITE}/mplconfig" \
  --property=Type=exec --property=Restart=no --property=KillMode=control-group \
  --property=RuntimeMaxSec=86400 --property=TimeoutStopSec=20 --property=LimitNOFILE=65536 \
  --property=AllowedCPUs=0-31,64-95 --property=CPUAffinity=0-31,64-95 \
  --property="StandardOutput=append:${TASK_SUITE}/controller.log" \
  --property="StandardError=append:${TASK_SUITE}/controller.log" \
  "${TASK_PYTHON}" -u "${TASK_ROOT}/onpolicy/scripts/train/run_stage2_resource_rl_v4.py" \
  --manifest "${TASK_SUITE}/manifest.json"
printf 'Started %s\nManifest: %s\n' "${TASK_UNIT}" "${TASK_SUITE}/manifest.json"
