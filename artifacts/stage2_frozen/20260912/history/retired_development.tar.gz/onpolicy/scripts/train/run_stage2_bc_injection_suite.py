#!/usr/bin/env python3
"""Run a frozen manifest with bounded GPU0 lanes and an isolated shared evaluator."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json as _atomic_json
from onpolicy.utils.shared_eval import parse_cpu_set
from onpolicy.utils.stage2_bc_contract import json_safe, compare_reference_cases
from onpolicy.utils.stage2_bc_replay import (
    evaluation_rows, verify_local_reference_runtime, validate_case_content,
)


def atomic_json(path, value):
    _atomic_json(path, json_safe(value))


def verify_resources(manifest, *, check_gpu=True):
    contract = manifest['resource_contract']
    expected = parse_cpu_set(contract['allowed_cpus'])
    if len(expected) != 64 or expected != set(range(32)) | set(range(64, 96)):
        raise ValueError('This launcher owns only CPU 0-31,64-95.')
    if not expected.issubset(os.sched_getaffinity(0)):
        raise ValueError('Requested CPU half exceeds the process allowance.')
    groups = [parse_cpu_set(value) for value in (
        *contract['train_cpu_sets'], contract['eval_cpu_set'], contract['monitor_cpu_set']
    )]
    seen = set()
    for cpus in groups:
        if cpus & seen:
            raise ValueError('CPU lane overlap.')
        seen |= cpus
        for cpu in cpus:
            siblings = parse_cpu_set(Path(f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list').read_text().strip())
            if not siblings.issubset(cpus):
                raise ValueError('A CPU lane splits SMT siblings.')
    if seen != expected:
        raise ValueError('CPU lane partition differs from the reserved half.')
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('CUDA_VISIBLE_DEVICES must be exactly 0.')
    for relative, expected_sha in manifest['code_fingerprint'].items():
        if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != expected_sha:
            raise ValueError(f'Code changed after preflight: {relative}')
    archive = manifest.get('source_archive')
    if archive and hashlib.sha256(Path(archive['path']).read_bytes()).hexdigest() != archive['sha256']:
        raise ValueError('Source snapshot changed after preflight.')
    for source in (manifest['source'], manifest['ready_source']):
        if hashlib.sha256(Path(source['path']).read_bytes()).hexdigest() != source['sha256']:
            raise ValueError('Model source changed after manifest creation.')
    if hashlib.sha256(Path(manifest['teacher_index']).read_bytes()).hexdigest() != manifest['teacher_index_sha256']:
        raise ValueError('Teacher index changed after manifest creation.')
    for source in manifest.get('warmstart_sources', {}).values():
        for path_key, sha_key in (('path', 'sha256'), ('evaluation', 'evaluation_sha256')):
            if hashlib.sha256(Path(source[path_key]).read_bytes()).hexdigest() != source[sha_key]:
                raise ValueError(f'Policy warm-start {path_key} changed after manifest creation.')
    iga_audit = manifest.get('iga_reference_audit')
    if iga_audit:
        if hashlib.sha256(Path(iga_audit['path']).read_bytes()).hexdigest() != iga_audit['sha256']:
            raise ValueError('IGA audit changed after manifest creation.')
        for baseline in json.loads(Path(iga_audit['path']).read_text())['baselines'].values():
            for path, expected_sha in baseline['source_files'].items():
                if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected_sha:
                    raise ValueError(f'IGA reference changed: {path}')
    proof = manifest.get('canary_proof')
    if proof:
        for path_key, sha_key in (('path', 'sha256'), ('manifest', 'manifest_sha256')):
            if hashlib.sha256(Path(proof[path_key]).read_bytes()).hexdigest() != proof[sha_key]:
                raise ValueError('Canary proof changed after manifest creation.')
    proof = manifest.get('diagnostic_proof')
    if proof:
        for path_key, sha_key in (('path', 'sha256'), ('manifest', 'manifest_sha256')):
            if hashlib.sha256(Path(proof[path_key]).read_bytes()).hexdigest() != proof[sha_key]:
                raise ValueError('Phase-A proof changed after manifest creation.')
    for item in manifest.get('research_case_files', {}).values():
        if hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('Fixed research case file changed after preparation.')
    analysis_script = manifest.get('analysis_script', 'onpolicy/scripts/train/analyze_stage2_bc_injection.py')
    if analysis_script not in manifest['code_fingerprint'] or Path(analysis_script).parent.as_posix() != 'onpolicy/scripts/train':
        raise ValueError('Analyzer is not part of the pinned training source bundle.')
    reference = manifest.get('reference_validation')
    if reference:
        for field in ('checkpoint', 'expected_evaluation'):
            if hashlib.sha256(Path(reference[field]).read_bytes()).hexdigest() != reference[f'{field}_sha256']:
                raise ValueError(f'Reference {field} changed after manifest creation.')
        verify_local_reference_runtime(reference)
        if reference.get('mode') == 'local_exact_after_environment_diagnosis':
            if (os.environ.get('CUBLAS_WORKSPACE_CONFIG') != reference['cublas_workspace_config']
                    or manifest['evaluation_contract']['workers'] != reference['evaluation_workers']
                    or any('--stage2_bc_deterministic' not in command['argv']
                           for command in manifest['commands'].values())):
                raise ValueError('The local reference requires the pinned strict-12 arithmetic contract.')
            validate_case_content(evaluation_rows(json.loads(Path(reference['expected_evaluation']).read_text())),
                                  manifest['evaluation_contract']['dataset'])
    if check_gpu:
        busy = subprocess.check_output([
            'nvidia-smi', '--id=0', '--query-compute-apps=pid', '--format=csv,noheader,nounits'
        ], text=True).strip()
        if busy:
            raise RuntimeError(f'GPU0 is not empty; refusing to share it: {busy}')
    return expected


def stop_owned(process):
    if process.poll() is not None:
        return
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=20)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=10)


def run(args):
    manifest_path = args.manifest.resolve()
    suite = manifest_path.parent
    manifest = json.loads(manifest_path.read_text())
    if args.resume_checkpoint and (manifest['profile'] != 'canary' or len(manifest['commands']) != 1):
        raise ValueError('Explicit recovery is supported only for a single canary job.')
    verify_resources(manifest)
    contract = manifest['resource_contract']
    os.sched_setaffinity(0, parse_cpu_set(contract['monitor_cpu_set']))
    state_path = suite / 'suite_status.json'
    if state_path.exists():
        raise FileExistsError('Suite already started; automatic retries are forbidden.')
    for name in ('records', 'service_logs', 'hardware', 'shared_evaluator'):
        (suite / name).mkdir(exist_ok=True)
    socket = Path('/tmp') / f'hkbz-bci-{hashlib.sha256(str(suite).encode()).hexdigest()[:16]}.sock'
    if socket.exists():
        raise FileExistsError(f'Evaluator socket already exists: {socket}')
    python = next(iter(manifest['commands'].values()))['argv'][0]
    state = {'status': 'starting', 'started_unix_time': time.time(),
             'manifest': str(manifest_path), 'controller_pid': os.getpid(),
             'resource_contract': contract, 'jobs': {}, 'alerts': []}
    atomic_json(state_path, state)
    logs, owned = [], []

    def spawn(command, cpus, log_name):
        handle = (suite / 'service_logs' / log_name).open('x', buffering=1)
        logs.append(handle)
        proc = subprocess.Popen(['taskset', '-c', cpus, *command], cwd=ROOT,
                                stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
        owned.append(proc)
        return proc

    try:
        evaluator = spawn([
            python, '-u', str(ROOT / 'onpolicy/scripts/train/shared_hkbz_evaluator.py'),
            '--source-command-json', str(suite / 'evaluator_source.json'),
            '--socket-path', str(socket), '--cpu-pool', contract['eval_cpu_set'],
            '--run-dir', str(suite / 'shared_evaluator'),
            '--eval-dataset-dir', manifest['evaluation_contract']['dataset'],
            '--max-eval-cases', str(manifest['evaluation_contract']['cases']),
            '--cuda-memory-fraction', '0.10',
        ], contract['eval_cpu_set'], 'evaluator.log')
        state['evaluator_pid'] = evaluator.pid
        deadline = time.monotonic() + 600
        while not socket.exists():
            if evaluator.poll() is not None:
                raise RuntimeError(f'Shared evaluator failed during startup: {evaluator.returncode}')
            if time.monotonic() >= deadline:
                raise TimeoutError('Shared evaluator startup exceeded 600 seconds.')
            time.sleep(1)
        reference = manifest.get('reference_validation')
        if reference:
            reference_output = suite / 'reference_a3.json'
            reference_process = spawn([
                python, '-u', str(ROOT / 'onpolicy/scripts/train/evaluate_stage1_shared_checkpoint.py'),
                '--socket-path', str(socket), '--checkpoint', reference['checkpoint'],
                '--cpu-set', contract['eval_cpu_set'], '--seed', str(reference['seed']),
                '--output', str(reference_output), '--label', 'reference_a3',
                '--evaluation-tau', str(reference['evaluation_tau']),
                '--n-eval-rollout-threads', str(manifest['evaluation_contract']['workers']),
            ], contract['monitor_cpu_set'], 'reference_a3.log')
            state.update({'status': 'reference_validation', 'reference_pid': reference_process.pid})
            reference_heartbeat = 0.0
            while reference_process.poll() is None:
                if evaluator.poll() is not None:
                    raise RuntimeError('Shared evaluator exited during reference replay.')
                if time.time() - state['started_unix_time'] > contract['hard_timeout_seconds']:
                    raise TimeoutError('Suite hard timeout reached during reference replay.')
                if time.monotonic() - reference_heartbeat >= contract['heartbeat_seconds']:
                    reference_heartbeat = time.monotonic()
                    state['updated_unix_time'] = time.time()
                    atomic_json(state_path, state)
                    print('[BCSuite] validating A3 on tune60 before training; '
                          f'reference_mode={reference.get("mode", "historical")}', flush=True)
                time.sleep(2)
            if reference_process.returncode:
                raise RuntimeError(f'A3 reference evaluation failed: {reference_process.returncode}')
            expected = json.loads(Path(reference['expected_evaluation']).read_text())
            actual = json.loads(reference_output.read_text())
            replay = compare_reference_cases(
                evaluation_rows(expected), evaluation_rows(actual),
                case_count=reference['cases'], tolerance_seconds=reference['case_tolerance_seconds'],
            )
            replay['reference_mode'] = reference.get('mode', 'historical')
            if reference.get('historical_evaluation'):
                historical = json.loads(Path(reference['historical_evaluation']).read_text())
                replay['historical_comparison_diagnostic_only'] = compare_reference_cases(
                    evaluation_rows(historical), evaluation_rows(actual), case_count=60,
                    tolerance_seconds=1e-5,
                )
            atomic_json(suite / 'reference_a3_integrity.json', replay)
            state['reference_validation'] = replay
            if not replay['passed']:
                raise RuntimeError('A3 replay differs from the pinned case-level evaluation; training not started.')
        pending = list(manifest['commands'])
        active = {}
        failed = False
        state['status'] = 'running'
        last_monitor = 0.0
        while pending or active:
            if evaluator.poll() is not None:
                raise RuntimeError('Shared evaluator exited while the suite was active.')
            for lane in range(contract['max_concurrent_trainers']):
                if lane in active or not pending or failed:
                    continue
                key = pending.pop(0)
                command = [
                    python, '-u', str(ROOT / 'onpolicy/scripts/train/run_stage2_resource_manifest_trial.py'),
                    '--manifest', str(manifest_path), '--command-key', key,
                    '--gpu', '0', '--cpu-set', contract['train_cpu_sets'][lane],
                    '--shared-eval-socket', str(socket),
                    '--shared-eval-cpu-set', contract['eval_cpu_set'],
                    '--eval-workers', str(manifest['evaluation_contract']['workers']),
                    '--record', str(suite / 'records' / f'{key}.json'),
                ]
                if args.resume_checkpoint:
                    if len(manifest['commands']) != 1:
                        raise ValueError('An explicit recovery checkpoint is only valid for a single canary job.')
                    command += ['--resume-checkpoint', str(args.resume_checkpoint.resolve())]
                proc = spawn(command, contract['train_cpu_sets'][lane], f'{key}.log')
                active[lane] = (key, proc)
                state['jobs'][key] = {'pid': proc.pid, 'lane': lane, 'status': 'running',
                                      'started_unix_time': time.time(),
                                      'cpu_set': contract['train_cpu_sets'][lane]}
            for lane, (key, proc) in list(active.items()):
                code = proc.poll()
                if code is None:
                    continue
                state['jobs'][key].update({'status': 'completed' if code == 0 else 'failed',
                                           'exit_code': code, 'ended_unix_time': time.time()})
                failed |= code != 0
                del active[lane]
            if failed and not active:
                for key in pending:
                    state['jobs'][key] = {'status': 'not_started_after_failure'}
                pending.clear()
            if time.time() - state['started_unix_time'] > contract['hard_timeout_seconds']:
                raise TimeoutError('Declared 48-hour suite hard timeout reached.')
            if time.monotonic() - last_monitor >= contract['heartbeat_seconds']:
                last_monitor = time.monotonic()
                state['updated_unix_time'] = time.time()
                state['pending'] = list(pending)
                for key, proc in active.values():
                    experiment = manifest['commands'][key]['experiment_name']
                    status_path = ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / experiment / 'run1/run_status.json'
                    if status_path.is_file():
                        try:
                            state['jobs'][key]['progress'] = json.loads(status_path.read_text())
                        except json.JSONDecodeError:
                            pass
                    log_path = suite / 'service_logs' / f'{key}.log'
                    stale_seconds = time.time() - log_path.stat().st_mtime
                    state['jobs'][key]['output_stall_advisory'] = stale_seconds > 300
                atomic_json(state_path, state)
                gpu = subprocess.run([
                    'nvidia-smi', '--id=0', '--query-gpu=memory.used,utilization.gpu',
                    '--format=csv,noheader,nounits'
                ], capture_output=True, text=True, timeout=15)
                with (suite / 'hardware/runtime_usage.csv').open('a') as handle:
                    csv.writer(handle).writerow([time.time(), *gpu.stdout.strip().split(',')])
                print(f'[BCSuite] active={list(active)} pending={pending} failed={failed}', flush=True)
            time.sleep(2)
        state['status'] = 'failed' if failed else 'completed'
        state['ended_unix_time'] = time.time()
        atomic_json(state_path, state)
        if not failed:
            analysis = subprocess.run([
                python, str(ROOT / manifest.get('analysis_script', 'onpolicy/scripts/train/analyze_stage2_bc_injection.py')),
                '--manifest', str(manifest_path),
            ], cwd=ROOT)
            if analysis.returncode:
                raise RuntimeError(f'Post-run integrity analysis failed: {analysis.returncode}')
        return 1 if failed else 0
    except BaseException as error:
        state.update({'status': 'failed', 'error': str(error), 'ended_unix_time': time.time()})
        atomic_json(state_path, state)
        raise
    finally:
        for proc in reversed(owned):
            stop_owned(proc)
        for handle in logs:
            handle.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--resume-checkpoint', type=Path)
    args = parser.parse_args()
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())
