#!/usr/bin/env python3
"""Stage-specific integrity audits; partial N results are never called four-arm results."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.analyze_stage2_matching_gap import analyze as base_analyze
from onpolicy.scripts.train.prepare_stage2_cost_accelerated import digest
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_cost_execution import CACHE_CONTRACT, EXECUTION_CONTRACT, json_digest, semantic_outcome
from onpolicy.utils.stage2_cost_improvement import COST_CONTRACT
from onpolicy.utils.stage2_cost_schedule import BASELINE_ARMS, COST_ARMS, arms_for_stage
from onpolicy.utils.stage2_bc_contract import json_safe
from onpolicy.utils.stage2_iga_contract import paired_iga_comparison
from onpolicy.utils.stage2_cost_continuation import validate_baseline


def audit_cached_outcome(row, index, outcome):
    if not outcome.get('cache_hit'):
        return
    path = Path(outcome['cache_path'])
    payload = json.loads(path.read_text())
    body = {key: payload[key] for key in ('binding', 'outcome')}
    binding = body['binding']
    expected = dict(contract=CACHE_CONTRACT, source_namespace=row['cache_source_namespace'],
        context=row['cache_context'], first_actions_sha256=row['first_actions_sha256'][index], target=row['env'])
    if (binding != expected or payload['sha256'] != json_digest(body)
            or payload['sha256'] != outcome['cache_sha256'] or path.stem != json_digest(binding)
            or semantic_outcome(body['outcome']) != semantic_outcome(outcome)):
        raise ValueError('Cached outcome is corrupt or bound to a different intervention.')


def analyze(path):
    path = Path(path).resolve()
    manifest = json.loads(path.read_text())
    expected = {arm + '_seed11' for arm in arms_for_stage(manifest['execution_stage'])}
    if manifest['research_family'] != 'stage2_cost_accelerated' or set(manifest['commands']) != expected:
        raise ValueError('Wrong or incomplete stage-specific arm set.')
    # Do not publish an intermediate `complete=true` before all cost/coverage
    # checks have passed. A failed analyzer must never leave a success report.
    report = base_analyze(path, canary_gate=False, publish=False)
    total_queries, checked = 0, set()
    for key, method in report['methods'].items():
        run = Path(method['run_dir'])
        entry = manifest['commands'][key]
        summaries, execution_summaries = [], []
        for epoch in (1, 2):
            summary = json.loads((run / f'logs/cost_summary_epoch{epoch}.json').read_text())
            execution = json.loads((run / f'logs/cost_execution_epoch{epoch}.json').read_text())
            if (summary['contract'] != COST_CONTRACT or execution['contract'] != EXECUTION_CONTRACT
                    or summary['enabled'] != entry['cost_improvement'] or execution['enabled'] != summary['enabled']
                    or summary['epoch'] != epoch or execution['epoch'] != epoch
                    or any(n > 2 for n in summary['case_counts'].values())):
                raise ValueError('Cost/executor contract or state budget differs.')
            if entry['cost_improvement']:
                evidence = run / f'logs/cost_evidence_epoch{epoch}.jsonl'
                if digest(evidence) != summary['evidence_sha256']:
                    raise ValueError('Cost evidence changed after training.')
                rows = [json.loads(line) for line in evidence.read_text().splitlines()]
                queries = sum(len(row['candidates']) for row in rows)
                counts = execution['counts']
                if (queries <= 0 or queries != summary['counts']['candidate_queries']
                        or queries != counts['logical_queries']
                        or queries != counts['physical_jobs'] + counts['cache_hits'] + counts['coalesced_queries']
                        or summary['counts']['incomplete']
                        or method['matching_training_metrics'][epoch - 1].get('device_bc_cost_pairs', 0) <= 0):
                    raise ValueError('Missing completed cost learning or inconsistent logical/physical query ledger.')
                for row in rows:
                    if (row['contract'] != COST_CONTRACT or row['execution_contract'] != EXECUTION_CONTRACT
                            or row['policy_sha256'] != summary['policy_sha256']
                            or row['batch_width'] != manifest['training_contract']['workers']
                            or not 2 <= len(row['candidates']) <= 4 or row['origins'][0] != 'student'
                            or len(row['outcomes']) != len(row['candidates'])
                            or row['costs'] != [x['makespan'] for x in row['outcomes']]
                            or any(not x['completed'] for x in row['outcomes'])):
                        raise ValueError('Cost candidate, target policy or full-batch contract differs.')
                    context = row['cache_context']
                    namespace = json_digest(dict(source=manifest['cost_executor']['source_namespace'],
                                                 runtime=context['arithmetic']))
                    if (context['policy_sha256'] != row['policy_sha256']
                            or context['batch_snapshot_sha256'] != row['batch_snapshot_sha256']
                            or context['batch_width'] != row['batch_width']
                            or namespace != row['cache_source_namespace']
                            or context['arithmetic']['actor_lanes'] != manifest['cost_executor']['actor_lanes']
                            or context['arithmetic']['fanout_width'] != manifest['cost_executor']['fanout_width']):
                        raise ValueError('Cost cache source/runtime/state namespace differs from the arm.')
                    artifacts = [(row['state_path'], row['state_sha256']),
                                 (row['target_checkpoint'], row['target_file_sha256'])]
                    artifacts += [(x['path'], x['file_sha256']) for x in row['environment_snapshots']]
                    for artifact, sha in artifacts:
                        if artifact not in checked and digest(artifact) != sha:
                            raise ValueError('Full-state cost evidence artifact changed.')
                        checked.add(artifact)
                    for index, outcome in enumerate(row['outcomes']):
                        audit_cached_outcome(row, index, outcome)
                total_queries += queries
            elif summary['counts']['candidate_queries'] or execution['counts']['logical_queries']:
                raise ValueError('A BC-only control consumed cost labels.')
            summaries.append(summary)
            execution_summaries.append(execution)
        method.update(cost_iteration_summaries=summaries, cost_execution_summaries=execution_summaries)
    if total_queries > manifest['cost_contract']['candidate_continuation_budget']:
        raise ValueError('Candidate continuation budget exceeded.')
    report.update(manifest=str(path), total_candidate_continuations=total_queries,
        cost_integrity_passed=True, execution_stage=manifest['execution_stage'],
        canary_contract_passed=manifest['profile'] == 'canary',
        four_arm_comparison_complete=False, confirmed_scientific_success=False,
        stage3_training_started=False, formal_promotion=False)
    # The base audit returns optional, unavailable composite/best metrics as
    # inf, although its disk report uses null. Critical Cmax/model values have
    # already been validated; retain the established null serialization here.
    report = json_safe(report)
    atomic_json(path.parent / 'analysis/comparison.json', report)
    return report


def combine(bc_path, cost_path, output):
    reports = [json.loads(Path(path).read_text()) for path in (bc_path, cost_path)]
    manifests = [json.loads(Path(report['manifest']).read_text()) for report in reports]
    if [manifest['execution_stage'] for manifest in manifests] != ['bc_pilot', 'cost_pilot']:
        raise ValueError('Combine only the independently completed BC and cost pilots.')
    continuation = manifests[1].get('continuation')
    if continuation:
        if Path(continuation['baseline_report']).resolve() != Path(bc_path).resolve():
            raise ValueError('Continuation binds a different baseline report.')
        validate_baseline(continuation, manifests[1])
    for key in ('source', 'ready_source', 'warmstart_sources',
                'sampling_audits', 'training_contract', 'evaluation_contract'):
        if manifests[0][key] != manifests[1][key]:
            raise ValueError(f'Cannot pair pilots with different {key}.')
    if not continuation and manifests[0]['code_fingerprint'] != manifests[1]['code_fingerprint']:
        raise ValueError('Cannot pair pilots with different code_fingerprint without audited continuation.')
    for index, (manifest, report) in enumerate(zip(manifests, reports)):
        if not report.get('cost_integrity_passed') or report.get('research_family') != 'stage2_cost_accelerated':
            raise ValueError('Incomplete pilot integrity report.')
        for relative, expected in manifest['code_fingerprint'].items():
            if continuation and index == 0:
                # Old controls remain bound to their original immutable source
                # archive and artifact hashes; never claim they ran new code.
                continue
            if digest(ROOT / relative) != expected:
                raise ValueError('Pilot source changed before comparison.')
    methods = {key: value for report in reports for key, value in report['methods'].items()}
    if set(methods) != {arm + '_seed11' for arm in BASELINE_ARMS + COST_ARMS}:
        raise ValueError('Missing or duplicate N0-N3 methods.')
    selected = {}
    for key, method in methods.items():
        epoch = method['effective_epoch']
        name = 'pre_supervised.json' if epoch == 0 else f'bc_epoch_{epoch}.json'
        selected[key] = json.loads((Path(method['run_dir']) / 'evaluations' / name).read_text())
    pairs = [('N1_BC_dagger', 'N0_BC_teacher'), ('N2_cost_teacher', 'N0_BC_teacher'),
             ('N3_cost_dagger', 'N1_BC_dagger'), ('N3_cost_dagger', 'N2_cost_teacher')]
    report = dict(research_family='stage2_cost_accelerated', methods=methods,
        baseline_continuation=continuation,
        paired_comparisons={f'{left}_minus_{right}': paired_iga_comparison(
            selected[left + '_seed11'], selected[right + '_seed11']) for left, right in pairs},
        source_reports=[dict(path=str(Path(path).resolve()), sha256=digest(path)) for path in (bc_path, cost_path)],
        four_arm_comparison_complete=True, confirmed_scientific_success=False, formal_promotion=False,
        stage3_training_started=False, scientific_result=True,
        note='One-seed tune-selected pilot; no confirmed IGA180/1800 superiority or Stage3 promotion.')
    report = json_safe(report)
    atomic_json(output, report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--bc-report', type=Path)
    parser.add_argument('--cost-report', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.manifest:
        analyze(args.manifest)
    elif args.bc_report and args.cost_report and args.output:
        combine(args.bc_report, args.cost_report, args.output)
    else:
        parser.error('Provide --manifest, or both pilot reports and --output.')
