#!/usr/bin/env python3
"""Prepare a new bounded E0-E3 Stage A+B experiment, reusing exact train240."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL

PARENT = ROOT / 'result/hkbz_train_logs/stage2_bc_rl_v4_20260908_gpu0_half_train240_r1'
PROTOCOL_FILE = 'STAGE2_SPLIT_ENCODER_V5_20260909.md'


def prepare(path, tag, repair_of=None):
    path = path.resolve()
    if path.exists() or not tag.replace('_', '').replace('-', '').isalnum():
        raise ValueError('A new directory and safe experiment tag are required.')
    parent = json.loads((PARENT / 'manifest.json').read_text())
    keep = ('source', 'stage1_source', 'ready_source', 'teacher_index', 'teacher_index_sha256',
            'environment_argv', 'train', 'evaluation', 'iga_reference')
    m = {k: copy.deepcopy(parent[k]) for k in keep}
    for item in (m['source'], m['stage1_source'], m['iga_reference']):
        if file_sha(item['path']) != item['sha256']:
            raise ValueError('Immutable historical input changed.')
    for key in ('train', 'evaluation'):
        validate_case_content(m[key]['cases'], m[key]['dataset'])
    train_hashes = {r['case_sha256'] for r in m['train']['cases']}
    tune_hashes = {r['case_sha256'] for r in m['evaluation']['cases']}
    if len(train_hashes) != 240 or len(tune_hashes) != 60 or train_hashes & tune_hashes:
        raise ValueError('Exact disjoint train240/tune60 required.')
    old_ar = PARENT / 'evaluations/S2RL_F_AR.json'
    m.update(protocol=PROTOCOL, run_tag=tag, schema_version=1,
        material_passport=dict(origin_skill='academic-research-suite/experiment-agent', origin_mode='run',
            origin_date='2026-09-09', verification_status='UNVERIFIED', version_label='split_encoder_v5'),
        created_at=datetime.now(timezone.utc).isoformat(), training_contract=copy.deepcopy(DEFAULTS),
        parent_manifest=dict(path=str(PARENT / 'manifest.json'), sha256=file_sha(PARENT / 'manifest.json')),
        historical_b0_ar=dict(path=str(old_ar), sha256=file_sha(old_ar)),
        data_alignment={**parent['data_alignment'], 'user_amendment':
            'E0-E3 each first epoch train240; optional second epoch requires a separate decision.'},
        resource_contract=dict(gpu=0, gpu_uuid='GPU-744c1334-98c8-5318-e799-7ad15eea1fbf',
            allowed_cpus='0-31,64-95', trainer_slots=['0-11,64-75', '12-23,76-87'],
            eval_cpus='24-29,88-93', monitor_cpus='30-31,94-95',
            max_concurrent_trainers=2, serialized_evaluation=True, runtime_max_seconds=86400),
        diagnostics=dict(trace_cases=['case_0001', 'case_0021', 'case_0054', 'case_0058']),
        execution=dict(arms=list(ARMS), allowed_stages=['A', 'B'], engineering_case_episodes=96,
            initial_evaluation_case_episodes=300, frozen_reference_case_episodes=240,
            total_training_case_episodes=960, training_case_episodes_per_arm=240,
            actor_steps_per_arm=80, critic_steps_per_arm=700,
            ar_training_evaluation_case_episodes=480, hungarian_final_evaluation_case_episodes=240,
            total_case_episode_limit=2316, candidate_round=10, monitoring_rounds=[5],
            automatic_retry=False, automatic_promotion=False, automatic_stage_c=False,
            cost_label_queries=0, teacher_execution=False, stage3_started=False),
        screen=dict(mean_gain_vs_both=.005, group_nonregression=True, tail_nonregression=True,
            maximum_paired_relative_regression_vs_B0_H=.01, zero_failures=True,
            matched_E0_required=True, not_iga_certification=True),
        goal='fully_better_IGA180_and_at_least_IGA1800', confirmed_scientific_success=False)
    if repair_of is not None:
        repair_of = repair_of.resolve()
        prior_manifest = json.loads((repair_of / 'manifest.json').read_text())
        prior_status = json.loads((repair_of / 'run_status.json').read_text())
        control = json.loads((repair_of / 'control.json').read_text())
        if (prior_manifest['protocol'] != PROTOCOL or prior_status['status'] != 'failed'
                or prior_status.get('attempted_physical_case_episodes', 0) != 0
                or prior_status.get('completed_training_case_episodes', 0) != 0
                or any(w.get('attempted_physical_case_episodes', 0) != 0 for w in prior_status.get('workers', {}).values())
                or prior_manifest['source'] != m['source'] or prior_manifest['train'] != m['train']):
            raise ValueError('This explicit repair path is restricted to failed zero-episode initialization.')
        m['repair_of'] = dict(path=str(repair_of), manifest_sha256=file_sha(repair_of / 'manifest.json'),
            control_sha256=file_sha(repair_of / 'control.json'), status_sha256=file_sha(repair_of / 'run_status.json'),
            original_started_unix=control['started_unix'], hard_deadline_unix=control['hard_deadline_unix'],
            prior_attempted_case_episodes=0, prior_training_updates=0, old_artifacts_retained=True,
            automatic_retry=False, requires_explicit_user_relaunch_authorization=True)
    fingerprints = code_fingerprint()
    for name in (PROTOCOL_FILE, 'onpolicy/scripts/train/launch_stage2_resource_rl_v5_gpu0.sh'):
        fingerprints[name] = file_sha(ROOT / name)
    m['code_fingerprint'] = fingerprints
    path.mkdir(parents=True, exist_ok=False)
    archive = path / 'source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for name, digest in fingerprints.items():
            content = (ROOT / name).read_bytes()
            if file_sha(ROOT / name) != digest:
                raise ValueError('Code changed during snapshot.')
            handle.addfile(handle.gettarinfo(str(ROOT / name), arcname=name), io.BytesIO(content))
    m['source_archive'] = dict(path=str(archive), sha256=file_sha(archive))
    atomic_json(path / 'manifest.json', m)
    print(path / 'manifest.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--run-tag', required=True)
    parser.add_argument('--repair-of', type=Path)
    cli = parser.parse_args()
    prepare(cli.suite_dir, cli.run_tag, cli.repair_of)
