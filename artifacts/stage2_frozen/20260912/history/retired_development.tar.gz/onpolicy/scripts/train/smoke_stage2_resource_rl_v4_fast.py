#!/usr/bin/env python3
"""Bounded GPU0 old/new execution proof (18 episodes), never production updates."""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, cpus, seed
from onpolicy.scripts.train.run_stage2_resource_rl_v4 import save_tensor_artifact
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_resource_rl import file_sha, summary
from onpolicy.utils.stage2_resource_rl_v4 import ARMS, CaseMinibatchLearner
from onpolicy.utils.stage2_resource_rl_v4_fast import FastCaseMinibatchLearner
from onpolicy.utils.stage2_resource_rl_v4_resume import assert_tree_equal, restore_learner, select_committed_checkpoint


def without_time(value):
    if isinstance(value, dict):
        return {k: without_time(v) for k, v in value.items() if k not in ('seconds', 'acceleration')}
    if isinstance(value, list):
        return [without_time(v) for v in value]
    return value


def main(cli):
    if cli.output.exists() or os.environ.get('CUDA_VISIBLE_DEVICES') != '0':
        raise ValueError('New output and physical GPU0 required.')
    if not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
        raise ValueError('Engineering proof escaped original CPU half.')
    cli.output.mkdir(parents=True)
    manifest = json.loads((cli.parent / 'manifest.json').read_text())
    paths = list(manifest['code_fingerprint']) + ['onpolicy/utils/stage2_resource_rl_v4_fast.py',
        'onpolicy/utils/stage2_resource_rl_v4_resume.py', 'onpolicy/scripts/train/smoke_stage2_resource_rl_v4_fast.py']
    fingerprints = {p: file_sha(ROOT / p) for p in paths}
    if any(fingerprints[p] != h for p, h in manifest['code_fingerprint'].items()):
        raise ValueError('Original production source changed.')
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.26, 0)
    args = arguments(manifest)
    args.max_train_cases = args.train_sampling_size = args.n_rollout_threads = 6
    source = torch.load(manifest['source']['path'], map_location='cpu', weights_only=True)
    for key, value in ready_head_config(source).items():
        setattr(args, key, value)
    config = yaml.safe_load(Path(args.ac_config).read_text())
    reference = {r['case_dir']: r['makespan'] for r in json.loads((cli.parent / 'reference/summary.json').read_text())['cases']}
    selected = {arm: select_committed_checkpoint(cli.parent, arm) for arm in ARMS}
    report = dict(passed=False, scientific_result=False, case_episode_limit=18,
        completed_case_episodes=0, arms={}, code_fingerprint=fingerprints,
        production_minibatch_cases=6, production_ppo_passes=2, automatic_retry=False)
    atomic_json(cli.output / 'report.json', report)
    last = [0.]
    def progress(event, force=False, **values):
        if force or time.time() - last[0] > 20:
            last[0] = time.time()
            atomic_json(cli.output / 'progress.json', dict(event=event, updated_unix=time.time(), **values))
            print(event, values, flush=True)
    def make(arm, fast, checkpoint):
        seed(manifest['training_contract']['seed'] + 100000)
        policy = GNN_MAPPOPolicy(args, config, torch.device('cuda:0'))
        policy.load_model_state(source['model'])
        policy.ac.tau, policy.ac.device_global_matching = args.evaluation_tau, False
        policy.capture_bc_reference(source['model'])
        policy.bc_reference_ac.device_global_matching = False
        cls = FastCaseMinibatchLearner if fast else CaseMinibatchLearner
        learner = cls(policy, args, checkpoint['resource_rl_contract']['training'], progress)
        proof = restore_learner(learner, checkpoint, arm)
        if summary(policy.bc_reference_ac) != summary(source['model']):
            raise ValueError('Frozen B0 reference changed on restore.')
        return learner, proof
    def collect(learner, rows, clone_workers, round_index):
        args.safe_async_graph_clone_workers = clone_workers
        envs, _ = make_train_env(args, case_records=rows, dataset_override=manifest['train']['dataset'])
        seed(manifest['training_contract']['seed'] + 300000 + round_index)
        try:
            output = learner.collect(envs, training=True, audit=True)
        finally:
            envs.close()
        report['completed_case_episodes'] += len(rows)
        if report['completed_case_episodes'] > report['case_episode_limit']:
            raise RuntimeError('Engineering episode budget exceeded.')
        return output
    for arm in ARMS:
        progress('engineering_arm_start', force=True, arm=arm)
        checkpoint = torch.load(selected[arm]['path'], map_location='cpu', weights_only=True)
        next_round = checkpoint['resource_rl_contract']['completed_rounds'] + 1
        indices = manifest['train']['collection_batches'][(next_round - 1) % 10][:6]
        rows = [manifest['train']['cases'][i] for i in indices]
        old, restored_old = make(arm, False, checkpoint)
        fast, restored_fast = make(arm, True, checkpoint)
        rollout = collect(old, rows, 0, next_round)
        # Preserve expensive observable trajectories for failure diagnosis;
        # a numerical discrepancy must not force another environment rollout.
        save_tensor_artifact(rollout, cli.output / f'{arm}_diagnostic_rollout.pt')
        collect_proof = None
        if arm == ARMS[0]:
            repeated = collect(fast, rows, 2, next_round)
            if repeated['trajectory_action_sha256'] != rollout['trajectory_action_sha256'] or repeated['cases'] != rollout['cases']:
                raise ValueError('Prepared inputs/async graph cloning changed the sampled trajectory.')
            if len(repeated['frames']) != len(rollout['frames']):
                raise ValueError('Trajectory lengths changed.')
            for a, b in zip(rollout['frames'], repeated['frames']):
                for key in ('old_logp', 'mask', 'reference_logits', 'global_emb', 'encoded'):
                    assert_tree_equal(a[key], b[key], key)
                for key in ('actions', 'dones', 'active', 'history', 'types', 'times'):
                    if not np.array_equal(a[key], b[key]):
                        raise ValueError(f'Collection metadata changed: {key}')
            collect_proof = dict(bitwise_equal=True, action_sha256=rollout['trajectory_action_sha256'],
                legacy_seconds=rollout['seconds'], accelerated_seconds=repeated['seconds'],
                async_clone_workers=2, frames=len(rollout['frames']))
            del repeated
            atomic_json(cli.output / 'collection_equivalence.json', collect_proof)
        # Both optimizers see the exact same full episodes, frozen reference,
        # advantages and canonical six-case group. These updates are discarded.
        old_started = time.monotonic()
        old_update = old.update(rollout, round_index=next_round, reference_cmax=reference)
        old_seconds = time.monotonic() - old_started
        fast_started = time.monotonic()
        fast_update = fast.update(rollout, round_index=next_round, reference_cmax=reference)
        fast_seconds = time.monotonic() - fast_started
        atomic_json(cli.output / f'{arm}_old_update.json', old_update)
        atomic_json(cli.output / f'{arm}_fast_update.json', fast_update)
        save_tensor_artifact(dict(old_model=old.policy.ac.state_dict(), fast_model=fast.policy.ac.state_dict(),
            old_actor_adam=old.actor_optim.state_dict(), fast_actor_adam=fast.actor_optim.state_dict(),
            old_critic_adam=old.critic_optim.state_dict(), fast_critic_adam=fast.critic_optim.state_dict()),
            cli.output / f'{arm}_updated_states.pt')
        assert_tree_equal(old.policy.ac.state_dict(), fast.policy.ac.state_dict(), 'updated model')
        assert_tree_equal(old.actor_optim.state_dict(), fast.actor_optim.state_dict(), 'updated actor Adam')
        assert_tree_equal(old.critic_optim.state_dict(), fast.critic_optim.state_dict(), 'updated critic Adam')
        # Collection audits were run an extra time for the fast R learner;
        # minibatch/update metrics, however, must match exactly.
        assert_tree_equal(without_time(old_update), without_time(fast_update), 'update metrics')
        if old_update['paused_for_kl'] or old_update['skipped_remaining_minibatches_for_kl']:
            raise ValueError('Equivalence proof did not complete both PPO steps safely.')
        report['arms'][arm] = dict(checkpoint=selected[arm]['path'], checkpoint_sha256=selected[arm]['sha256'],
            restore=restored_fast, full_episode_cases=6, collection_equivalence=collect_proof,
            updated_model_bitwise_equal=True, actor_adam_bitwise_equal=True, critic_adam_bitwise_equal=True,
            update_metrics_bitwise_equal=True, legacy_update_seconds=old_seconds,
            accelerated_update_seconds=fast_seconds, acceleration=fast_update['acceleration'],
            actor_steps_delta=fast_update['actor_steps'] - checkpoint['resource_rl_contract']['actor_steps'],
            critic_steps_delta=fast_update['critic_steps'] - checkpoint['resource_rl_contract']['critic_steps'],
            max_logp_error=fast.minibatch_checks['max_logp_error'],
            max_ratio_error=fast.minibatch_checks['max_ratio_error'])
        atomic_json(cli.output / 'report.json', report)
        del old, fast, rollout, checkpoint
        torch.cuda.empty_cache()
    if any(file_sha(ROOT / p) != h for p, h in fingerprints.items()):
        raise ValueError('Source changed during verification.')
    report.update(passed=True, source_unchanged_during_verification=True,
        cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(),
        cuda_peak_reserved_bytes=torch.cuda.max_memory_reserved())
    atomic_json(cli.output / 'report.json', report)
    progress('engineering_passed', force=True, completed_case_episodes=report['completed_case_episodes'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    cli = parser.parse_args()
    def stop(signum, frame):
        raise TimeoutError('Acceleration proof reached its 20-minute hard timeout.')
    signal.signal(signal.SIGALRM, stop)
    signal.alarm(1200)
    try:
        main(cli)
    except BaseException:
        if cli.output.is_dir():
            atomic_json(cli.output / 'engineering_failure.json', dict(passed=False, traceback=traceback.format_exc()))
        raise
    finally:
        signal.alarm(0)
