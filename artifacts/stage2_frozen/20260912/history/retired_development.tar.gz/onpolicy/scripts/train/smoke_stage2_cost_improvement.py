#!/usr/bin/env python3
"""Bounded real-GPU engineering probe on train0343/0444, not a research pilot."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from torch_geometric.data import Batch
from onpolicy.config.config import get_config
from onpolicy.scripts.train.train_hkbz import parse_args
from onpolicy.scripts.train.diagnose_stage2_cost_improvement import make_runner, microfit
from onpolicy.scripts.train.run_stage2_bc_injection_suite import verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism
from onpolicy.utils.stage2_cost_improvement import (CostIteration, actor_forward, apply_cost_evidence,
                                                 policy_digest, deterministic_learner_mode)


def smoke(cli):
    manifest = json.loads(cli.manifest.read_text())
    verify_resources(manifest)
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.manual_seed(11)
    torch.cuda.manual_seed_all(11)
    output = cli.manifest.parent / 'gpu_smoke'
    output.mkdir(exist_ok=False)
    args = parse_args(manifest['commands']['N2_cost_teacher_seed11']['argv'][2:], get_config())
    args.n_rollout_threads = args.max_train_cases = args.train_sampling_size = 2
    args.stage2_research_train_cases = str(cli.manifest.parent / 'regression_cases.json')
    runner = make_runner(args, manifest, output)
    before = policy_digest(runner.policy)
    report = {'status': 'running', 'scientific_result': False}
    try:
        iterator = CostIteration(runner, 1)
        obs, dones, infos = runner.envs.reset()
        hidden = np.zeros((2, runner.num_agents, args.recurrent_N, args.hidden_size), np.float32)
        previous = -np.ones((2, runner.num_agents, 2), np.int64)
        iterator.reset_rollout(hidden)
        for step in range(128):
            active = runner._active_masks_from_info(infos)
            history = runner._authoritative_policy_history(infos, previous, args.max_agent_num)
            hidden = iterator.prepare(obs, active, history, infos, hidden)
            actions, next_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            repeat, repeat_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            if not np.array_equal(actions, repeat) or not np.array_equal(next_hidden, repeat_hidden):
                raise ValueError('Identical GPU actor inputs were not bitwise repeatable.')
            runner.policy.ac.eval()
            deployed, deployed_hidden = actor_forward(runner.policy, obs, hidden, active, history, infos['agent_types'])
            deterministic_learner_mode(runner.policy)
            if not np.array_equal(actions, deployed) or not np.array_equal(next_hidden, deployed_hidden):
                raise ValueError('cuDNN backward-ready resource GRUs differ from deployed eval arithmetic.')
            labels = runner.envs.call('resource_iga_teacher_actions', return_info=True,
                include_ready_targets=False, deployment_projection=True)
            teacher = np.stack([x['actions'] for x in labels])
            iterator.selected = iterator.selected[:1]
            evidence = iterator.evidence(obs, active, history, infos, actions, teacher)
            if evidence:
                resources = active.copy()
                resources[:, :args.max_agent_num] = 0.
                with torch.no_grad():
                    outputs = runner.policy.evaluate_actions(Batch.from_data_list(obs), hidden,
                        resources, history[..., 0], history[..., 1], teacher,
                        agent_types=infos['agent_types'], return_decision_mask=True,
                        return_log_prob_components=True)
                    scores = outputs[3]['resource_action_logits']
                loss, anchor, metrics = apply_cost_evidence(scores, resources[..., 0] > 0, evidence,
                    scale=args.stage2_cost_scale_seconds, clip=args.stage2_cost_weight_clip,
                    tie_seconds=args.stage2_cost_tie_seconds)
                if any(not x['completed'] for item in evidence for x in item['outcomes']):
                    raise ValueError('Engineering cost branch did not complete.')
                if not metrics['device_bc_cost_covered_joints']:
                    raise ValueError('No whole-joint anchor suppression exercised.')
                report.update(status='completed', event_step=step, evidence=evidence,
                    loss=float(loss), metrics=metrics, actor_repeat_bitwise_exact=True,
                    source_unchanged=policy_digest(runner.policy) == before)
                # Exercise the real recurrent gradient path on a discarded
                # copy. This tiny regression fixture is not the Phase-A gate.
                samples = [(list(obs), active.copy(), history.copy(), infos['agent_types'].copy(),
                            actions.copy(), list(iterator.prefix), evidence[0])]
                report['microfit_engineering_probe'] = microfit(runner, samples,
                    {**manifest['diagnostic_contract'], 'microfit_steps': 20})
                report['source_unchanged'] = policy_digest(runner.policy) == before
                if not report['source_unchanged']:
                    raise ValueError('Smoke probe changed source policy.')
                break
            prior, types = obs, infos['agent_types']
            obs, _, dones, infos = runner.envs.step(actions)
            iterator.finish_step(prior, active, history, types, dones)
            next_hidden[dones] = 0.
            hidden, previous = next_hidden, actions
        else:
            raise ValueError('No nontrivial candidate set exercised within128 events.')
        atomic_json(output / 'report.json', report)
        print(json.dumps({key: report[key] for key in ('status', 'event_step', 'metrics', 'source_unchanged')}))
    except BaseException as error:
        report.update(status='failed', error=str(error))
        atomic_json(output / 'report.json', report)
        raise
    finally:
        runner.envs.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    smoke(parser.parse_args())
