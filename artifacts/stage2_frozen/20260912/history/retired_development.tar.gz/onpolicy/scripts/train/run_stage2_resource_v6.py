#!/usr/bin/env python3
"""V6 semantic/reference audit and shared-data S1/S2 pilot; no auto-promotion."""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml
from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.algorithms.utils.resource_actor_v6 import install_resource_v6
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, cpus, metrics, seed
from onpolicy.scripts.train.run_stage2_resource_rl_v4 import save_tensor_artifact
from onpolicy.scripts.train.run_stage2_resource_rl_v5_unlimited import UnlimitedProgress
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_policy_transfer import verified_frozen_ready_source
from onpolicy.utils.stage2_resource_rl import file_sha, summary
from onpolicy.utils.stage2_resource_rl_handoff import validate_frozen_lineage
from onpolicy.utils.stage2_resource_rl_v4 import compare_cases
from onpolicy.utils.stage2_resource_rl_v5 import clean_cases
from onpolicy.utils.stage2_resource_rl_v4_resume import assert_tree_equal
from onpolicy.utils.stage2_resource_v6 import ARMS, DEFAULTS, PROTOCOL, V6Learner


class V6Progress(UnlimitedProgress):
    def __call__(self, event, force=False, **values):
        values['last_work_progress_unix'] = time.time()
        return super().__call__(event, force=force, **values)

    def write(self):
        with self.lock:
            stalled = time.time() - self.state.get('last_work_progress_unix', self.started)
            self.state.update(updated_unix=time.time(), elapsed_seconds=time.time() - self.started,
                hard_deadline_unix=None, wall_clock_limit_enabled=False,
                time_authorization_version='approved_stage2_v6_plan_20260910',
                seconds_since_work_progress=stalled, stall_suspected=stalled > 90,
                stall_action='advisory_only_no_kill_or_retry')
            atomic_json(self.suite / 'run_status.json', self.state)


class Suite:
    def __init__(self, manifest):
        self.path = manifest.resolve()
        self.root = self.path.parent
        self.m = json.loads(self.path.read_text())
        self.c = self.m['training_contract']
        self.progress, self.envs = None, None
        self.attempted, self.completed = 0, 0
        self.ledger, self.learners = [], {}

    def validate(self):
        if self.m['protocol'] != PROTOCOL or self.c != DEFAULTS or self.m['execution']['arms'] != list(ARMS):
            raise ValueError('Unapproved V6 experiment contract.')
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95')):
            raise ValueError('GPU0 and original CPU half are required.')
        if (self.root / 'run_status.json').exists():
            raise FileExistsError('No automatic retries or run-directory reuse.')
        if self.m['resource_contract']['runtime_max_seconds'] is not None:
            raise ValueError('The approved V6 plan has no restored wall-clock kill gate.')
        for name, digest in self.m['code_fingerprint'].items():
            if file_sha(ROOT / name) != digest:
                raise ValueError(f'Pinned source changed: {name}')
        for key in ('source', 'stage1_source', 'source_archive', 'parent_manifest', 'iga_reference', 'engineering_proof'):
            item = self.m[key]
            if file_sha(item['path']) != item['sha256']:
                raise ValueError(f'Changed immutable input: {key}')
        proof = json.loads(Path(self.m['engineering_proof']['path']).read_text())
        if not proof['passed'] or any(file_sha(ROOT / name) != digest for name, digest in proof['checked_sources'].items()):
            raise ValueError('Passed GPU engineering proof does not cover the current implementation.')
        if file_sha(self.m['teacher_index']) != self.m['teacher_index_sha256']:
            raise ValueError('Teacher index changed.')
        for key in ('train', 'evaluation'):
            validate_case_content(self.m[key]['cases'], self.m[key]['dataset'])
        from onpolicy.scripts.train.prepare_stage2_resource_v6 import select_dev
        parent = json.loads(Path(self.m['parent_manifest']['path']).read_text())
        if (self.m['train'] != parent['train'] or self.m['evaluation'] != parent['evaluation']
                or self.m['pilot_train'] != self.m['train']['cases'][:48]
                or self.m['pilot_dev'] != select_dev(self.m['evaluation']['cases'])
                or self.m['execution']['total_case_episode_limit'] != 172):
            raise ValueError('V6 case selection, historical alignment or budget changed.')

    def policy(self, arm=None):
        seed(self.c['seed'] + 100000)
        policy = GNN_MAPPOPolicy(self.args, self.ac_config, torch.device('cuda:0'))
        policy.load_model_state(self.payload['model'])
        policy.ac.tau, policy.ac.device_global_matching = self.args.evaluation_tau, False
        if summary(policy.ac) != summary(self.payload['model']):
            raise ValueError('Legacy B0 load changed source tensors.')
        if arm:
            seed(self.c['seed'] + 200000)
            install_resource_v6(policy.ac, arm)
        return V6Learner(policy, self.args, self.c, self.progress, arm)

    def collect(self, learner, rows, label, *, evaluation=False, store=False, teacher=False, archived=None, projected=True):
        if self.attempted + len(rows) > self.m['execution']['total_case_episode_limit']:
            raise RuntimeError('V6 physical case budget exhausted; no silent extension.')
        args = copy.copy(self.args)
        args.seed = 1
        args.max_train_cases = args.train_sampling_size = args.n_rollout_threads = len(rows)
        os.sched_setaffinity(0, cpus(self.m['resource_contract']['eval_cpus' if evaluation else 'train_cpus']))
        self.envs, _ = make_train_env(args, case_records=rows,
            dataset_override=self.m['evaluation' if evaluation else 'train']['dataset'], evaluation=evaluation)
        seed(1)
        self.attempted += len(rows)
        self.progress('case_batch_start', force=True, phase=label, current_cases=[r['case_dir'] for r in rows],
            attempted_physical_case_episodes=self.attempted, completed_physical_case_episodes=self.completed)
        try:
            result = learner.collect(self.envs, store=store, teacher=teacher, archived=archived, projected=projected)
        finally:
            self.envs.close(); self.envs = None
        result['cases'] = clean_cases(result['cases'], rows)
        self.completed += len(rows)
        self.ledger.append(dict(label=label, attempted_cases=len(rows), completed_cases=len(rows),
            seconds=result['seconds'], environment_events=result['environment_events'], teacher_execution=teacher))
        atomic_json(self.root / 'resource_ledger.json', dict(attempted=self.attempted, completed=self.completed,
            entries=self.ledger, actor_steps={a: l.actor_steps for a, l in self.learners.items()},
            search_calls=0, cost_label_queries=0, wall_clock_timeout=False))
        self.progress('case_batch_completed', force=True, completed_physical_case_episodes=self.completed)
        return result

    def evaluate(self, learner, label, rows=None):
        rows = self.m['pilot_dev'] if rows is None else rows
        result = self.collect(learner, rows, label, evaluation=True)
        atomic_json(self.root / 'evaluations' / (label + '.json'),
            {**{k: v for k, v in result.items() if k not in ('frames', 'label_audit')},
             'summary': metrics(result['cases']), 'development_only': True})
        return result['cases']

    def checkpoint(self, learner, name):
        state = learner.checkpoint_state()
        state.update(source=self.m['source'], manifest_sha256=file_sha(self.path),
            stage2_training_mode=PROTOCOL, training_stage='resource_joint',
            input_schema='resource_semantic_pair_view_v6_1', training_contract=self.c,
            completed_bc_epochs=learner.actor_steps // 8, updates_in_current_epoch=learner.actor_steps % 8,
            teacher_data_manifest_sha256=file_sha(self.root / 'teacher_data/manifest.json'))
        path = self.root / learner.arm / name
        save_tensor_artifact(state, path)
        return path

    def run(self):
        self.validate()
        self.progress = V6Progress(self.root)
        # Explicitly replace the inherited V5 status label, not its unlimited-time behavior.
        self.progress.state.update(protocol=PROTOCOL, time_authorization='approved_V6_plan', automatic_promotion=False)
        def stop(signum, frame):
            raise KeyboardInterrupt('Operator stop')
        signal.signal(signal.SIGTERM, stop)
        signal.alarm(0)
        try:
            configure_bc_determinism(True)
            torch.set_num_threads(1)
            torch.cuda.set_per_process_memory_fraction(.85, 0)
            if str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') != self.m['resource_contract']['gpu_uuid'].removeprefix('GPU-'):
                raise ValueError('Wrong physical GPU UUID.')
            self.args = arguments(self.m)
            self.args.stage2_resource_v6_observations = True
            self.payload = torch.load(self.m['source']['path'], map_location='cpu', weights_only=True)
            verified_frozen_ready_source(self.payload)
            for key, value in ready_head_config(self.payload).items():
                setattr(self.args, key, value)
            self.ac_config = yaml.safe_load(Path(self.args.ac_config).read_text())
            atomic_json(self.root / 'checks/frozen_lineage.json', validate_frozen_lineage(self.payload, self.m['stage1_source']))
            base = self.policy()
            reference = {}
            for name, archive in self.m['archived_teachers'].items():
                variants = {}
                for projected in (False, True):
                    label = name + ('_projected' if projected else '_production')
                    result = self.collect(base, self.m['diagnostic_cases'], label, evaluation=True,
                        teacher=True, archived=archive, projected=projected)
                    variants[str(projected)] = result['cases']
                    atomic_json(self.root / 'references' / (label + '.json'),
                        {k: v for k, v in result.items() if k != 'frames'})
                comparison = compare_cases(variants['False'], variants['True'])
                archived_deltas = {row['case_dir']: row['makespan'] - archive['archived_makespans'][row['case_dir']]
                                   for row in variants['False']}
                comparison['archived_replay_deltas'] = archived_deltas
                comparison['archived_cmax_reproduced'] = all(abs(x) <= 1e-5 for x in archived_deltas.values())
                comparison['current_runtime_reference_used'] = True
                reference[name] = comparison
                if comparison['relative_improvement'] < -self.m['screen']['projected_teacher_maximum_mean_regression']:
                    atomic_json(self.root / 'checks/teacher_projection.json', dict(passed=False, comparisons=reference))
                    raise RuntimeError('Teacher projection loses >0.5%; do not train the degraded expert.')
            atomic_json(self.root / 'checks/teacher_projection.json', dict(passed=True, comparisons=reference,
                cases=4, diagnostic_only=True, strict_search_budget_certified=False, search_calls=0))
            baseline = self.evaluate(base, 'B0_AR_dev12')
            dataset = []
            for start in range(0, 48, 6):
                result = self.collect(base, self.m['pilot_train'][start:start + 6], f'teacher_batch_{start // 6 + 1}',
                    store=True, teacher=True)
                labels = result.pop('label_audit')
                path = self.root / 'teacher_data' / f'batch_{start // 6 + 1}.pt'
                save_tensor_artifact(result, path)
                atomic_json(path.with_suffix('.labels.json'), labels)
                packed = base.pack_stateless(result)
                packed_path = path.with_name(path.stem + '_stateless.pt')
                save_tensor_artifact(packed, packed_path)
                dataset.append(dict(path=str(path), sha256=file_sha(path),
                    stateless_path=str(packed_path), stateless_sha256=file_sha(packed_path),
                    role_free_counts={r: len(v['target']) for r, v in packed['stateless_records'].items()},
                    cases=[r['case_dir'] for r in result['cases']]))
                del packed
                del result
            atomic_json(self.root / 'teacher_data/manifest.json', dict(parts=dataset, physical_case_episodes=48,
                source='pinned_IGA1800_live_AR_projected_teacher', includes_complete_prefix=True, cost_branches=0))
            role_counts = {role: sum(part['role_free_counts'].get(role, 0) for part in dataset)
                           for role in ('ordinary', 'transporter')}
            atomic_json(self.root / 'checks/teacher_role_coverage.json', dict(passed=all(role_counts.values()), counts=role_counts))
            if not all(role_counts.values()):
                raise RuntimeError('Pilot teacher data has no free labels for one resource role.')
            for arm in ARMS:
                self.learners[arm] = self.policy(arm)
                self.evaluate(self.learners[arm], arm + '_epoch_0_dev12')
            all_updates, finals = {a: [] for a in ARMS}, {}
            for epoch in range(1, self.c['bc_epochs'] + 1):
                for batch, part in enumerate(dataset, 1):
                    if file_sha(part['path']) != part['sha256']:
                        raise ValueError('Shared teacher dataset changed.')
                    # Locally generated, hash-verified PyG artifacts require full object loading.
                    rollout = torch.load(part['path'], map_location='cpu', weights_only=False)
                    for arm in ARMS:
                        learner = self.learners[arm]
                        os.sched_setaffinity(0, cpus(self.m['resource_contract']['train_cpus']))
                        self.progress('bc_batch_start', force=True, phase='pilot_bc', arm=arm, epoch=epoch,
                            batch=batch, total_batches=8, completed_training_case_episodes=0,
                            teacher_case_episodes=48, supervised_case_presentations=(epoch - 1) * 48 + batch * 6)
                        started = time.monotonic()
                        if arm == 'S2':
                            if file_sha(part['stateless_path']) != part['stateless_sha256']:
                                raise ValueError('Stateless teacher input cache changed.')
                            packed = torch.load(part['stateless_path'], map_location='cpu', weights_only=False)
                            update = learner.bc_epoch_batch(packed)
                            del packed
                        else:
                            update = learner.bc_epoch_batch(rollout)
                        update.update(epoch=epoch, batch=batch, seconds=time.monotonic() - started)
                        all_updates[arm].append(update)
                        atomic_json(self.root / arm / f'epoch_{epoch}_batch_{batch}.json', update)
                    del rollout
                for arm, learner in self.learners.items():
                    path = self.checkpoint(learner, f'checkpoint_epoch_{epoch}.pt')
                    if epoch == 1:
                        saved = torch.load(path, map_location='cpu', weights_only=False)
                        assert_tree_equal(saved['model'], {k: v.cpu() for k, v in learner.policy.ac.state_dict().items()}, 'V6 checkpoint')
                        atomic_json(self.root / arm / 'checkpoint_disk_check.json', dict(passed=True,
                            sha256=file_sha(path), weights_roundtrip=True, optimizer_saved=True))
                    if epoch in self.c['evaluation_epochs']:
                        finals[arm] = self.evaluate(learner, f'{arm}_epoch_{epoch}_dev12')
            results = {}
            for arm, learner in self.learners.items():
                comparison = compare_cases(baseline, finals[arm])
                before, after = metrics(baseline), metrics(finals[arm])
                early_loss = float(np.mean([u['loss'] for u in all_updates[arm] if u['epoch'] == 1]))
                final_loss = float(np.mean([u['loss'] for u in all_updates[arm] if u['epoch'] == 10]))
                passed = (comparison['relative_improvement'] >= -.005 and learner.actor_steps == 80
                    and all(after['groups'][g] <= before['groups'][g] * 1.01 for g in before['groups'])
                    and after['tail10'] <= before['tail10'] * 1.01 and final_loss < early_loss)
                results[arm] = dict(screen_passed=passed, comparison=comparison,
                    actor_steps=learner.actor_steps, updates=all_updates[arm], checks=learner.checks,
                    first_epoch_online_training_loss=early_loss, final_epoch_online_training_loss=final_loss)
            atomic_json(self.root / 'pilot_report.json', dict(results=results,
                eligible_arms=[a for a in ARMS if results[a]['screen_passed']],
                endpoint=10, development_only=True, confirmed_scientific_success=False,
                automatic_train240=False, automatic_ppo=False, next_stage_requires_decision=True))
            self.progress('pilot_completed', force=True, status='completed', phase='awaiting_pilot_review',
                completed_physical_case_episodes=self.completed, actor_steps={a: l.actor_steps for a, l in self.learners.items()},
                full_train240_started=False, ppo_started=False, stage3_started=False)
            return 0
        except BaseException as exc:
            self.progress.state.update(status='failed', error=str(exc), traceback=traceback.format_exc(), automatic_retry=False)
            self.progress.write()
            for arm, learner in self.learners.items():
                try:
                    self.checkpoint(learner, 'checkpoint_interrupted.pt')
                except Exception as save_error:
                    print(f'Failed to preserve {arm} interruption: {save_error}', flush=True)
            print(traceback.format_exc(), flush=True)
            return 1
        finally:
            if self.envs is not None:
                self.envs.close()
            self.progress.stop.set()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    sys.exit(Suite(parser.parse_args().manifest).run())
