#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
PYTHON="${PYTHON:-${ROOT_DIR}/../conda/envs/maia-hkbz-cu124-20260903/bin/python}"
RUNNER="${RUNNER:-${ROOT_DIR}/onpolicy/envs/HKBZ/experiment/generate_stage2_resource_iga_labels.py}"
ANALYZER="${ANALYZER:-${ROOT_DIR}/onpolicy/envs/HKBZ/experiment/analyze_stage2_matched_iga.py}"
DATASET="${DATASET:-${ROOT_DIR}/onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune}"
CHECKPOINT="${CHECKPOINT:-${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo/stage1_departure_reward_formal_dual_20260816_r1_formal_P5_team_time_potential_fixed_seed3/run1/models/checkpoint_Best.pt}"
SOURCE_COMMAND="${SOURCE_COMMAND:-${ROOT_DIR}/result/hkbz_train_logs/stage1_departure_reward_formal_dual_20260816_r1/commands/formal_P5.json}"
SOURCE_COMMAND_KEY="${SOURCE_COMMAND_KEY:-P5_team_time_potential_fixed_seed3}"
HANDOFF="${HANDOFF:-${ROOT_DIR}/onpolicy/config/stage1_m2_handoff.json}"

RUN_TAG="${RUN_TAG:-stage2_matched_iga_tune60_20260827_r1}"
OUTPUT_ROOT="${OUTPUT_ROOT:-${ROOT_DIR}/result/hkbz_train_logs/${RUN_TAG}}"
UNIT="${UNIT:-hkbz-s2-matched-iga-tune60-20260827-r1}"
POPULATION="${POPULATION:-20}"
CASE_BATCH_SIZE="${CASE_BATCH_SIZE:-16}"
MAX_GENERATIONS="${MAX_GENERATIONS:-100000}"
IGA_SEED="${IGA_SEED:-20260820}"
MAX_STEPS="${MAX_STEPS:-4000}"
EVALUATION_TAU="${EVALUATION_TAU:-0.3}"
SHARD_COUNT=4
SERVICE_CPUS="0-35,72-107"
SHARD_CPUS=(
  "0-8,72-80"
  "9-17,81-89"
  "18-26,90-98"
  "27-35,99-107"
)

F1_EVAL="${F1_EVAL:-${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo/stage2_full_formal_three_20260823_r2_planning_formal_full_selected_three_F1_hard_reservation_seed1_ppo30/run1/evaluations/epoch_3.json}"
F2_EVAL="${F2_EVAL:-${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo/stage2_full_formal_three_20260823_r2_planning_formal_full_selected_three_F2_iga_flow_bc_seed1_ppo30/run1/evaluations/epoch_1.json}"
F3_EVAL="${F3_EVAL:-${ROOT_DIR}/onpolicy/scripts/results/HKBZ/simple/gnn_mappo/stage2_full_formal_three_20260823_r2_planning_formal_full_selected_three_F3_wait_constraint_seed1_ppo30/run1/evaluations/epoch_5.json}"
LEGACY_IGA="${LEGACY_IGA:-${ROOT_DIR}/result/hkbz_train_logs/stage2_lateness_wave2_tune60_iga_compare_20260820_r1/iga1800}"

common_args() {
  local reservation_mode="$1"
  printf '%s\n' \
    --dataset-dir "${DATASET}" \
    --checkpoint "${CHECKPOINT}" \
    --source-command "${SOURCE_COMMAND}" \
    --source-command-key "${SOURCE_COMMAND_KEY}" \
    --handoff "${HANDOFF}" \
    --device cuda:0 \
    --evaluation-tau "${EVALUATION_TAU}" \
    --device-lookahead-safety-margin 60 \
    --device-deadline-aware-dispatch \
    --device-future-intent-horizon 1 \
    --device-future-intent-mode bounded_frontier \
    --device-frontier-max-requests 2 \
    --resource-release-aware-eta \
    --device-lookahead-reservation-mode "${reservation_mode}" \
    --device-reservation-grace-seconds 300 \
    --device-departure-lookahead \
    --population "${POPULATION}" \
    --case-batch-size "${CASE_BATCH_SIZE}" \
    --max-generations "${MAX_GENERATIONS}" \
    --seed "${IGA_SEED}" \
    --max-steps "${MAX_STEPS}" \
    --max-cases 0
}

run_shard() {
  local reservation_mode="$1"
  local shard="$2"
  local cpu_set="$3"
  local output_dir="$4"
  local additional_budget="$5"
  local cumulative_budget="$6"
  shift 6
  local args=()
  mapfile -t args < <(common_args "${reservation_mode}")
  /usr/bin/taskset --cpu-list "${cpu_set}" \
    "${PYTHON}" -u "${RUNNER}" \
      "${args[@]}" \
      --output-dir "${output_dir}" \
      --time-budget-seconds "${additional_budget}" \
      --cumulative-budget-seconds "${cumulative_budget}" \
      --shard-index "${shard}" \
      --shard-count "${SHARD_COUNT}" \
      "$@"
}

summarize_stage() {
  local reservation_mode="$1"
  local output_dir="$2"
  local additional_budget="$3"
  local cumulative_budget="$4"
  shift 4
  local args=()
  mapfile -t args < <(common_args "${reservation_mode}")
  /usr/bin/taskset --cpu-list 0,72 \
    "${PYTHON}" -u "${RUNNER}" \
      "${args[@]}" \
      --output-dir "${output_dir}" \
      --time-budget-seconds "${additional_budget}" \
      --cumulative-budget-seconds "${cumulative_budget}" \
      --summarize-only \
      "$@"
}

run_parallel_stage() {
  local profile="$1"
  local reservation_mode="$2"
  local stage="$3"
  local output_dir="$4"
  local additional_budget="$5"
  local cumulative_budget="$6"
  shift 6
  local extra_args=("$@")
  local pids=()
  local shard log_path failed=0
  mkdir -p "${output_dir}" "${OUTPUT_ROOT}/logs/${profile}"
  echo "[MatchedIGA] profile=${profile} stage=${stage} starting four shards"
  for ((shard = 0; shard < SHARD_COUNT; shard++)); do
    log_path="${OUTPUT_ROOT}/logs/${profile}/${stage}_shard${shard}.log"
    run_shard \
      "${reservation_mode}" "${shard}" "${SHARD_CPUS[$shard]}" \
      "${output_dir}" "${additional_budget}" "${cumulative_budget}" \
      "${extra_args[@]}" >"${log_path}" 2>&1 &
    pids+=("$!")
  done
  for ((shard = 0; shard < SHARD_COUNT; shard++)); do
    if ! wait "${pids[$shard]}"; then
      echo "[MatchedIGA][Error] ${profile}/${stage} shard ${shard} failed" >&2
      failed=1
    fi
  done
  if (( failed != 0 )); then
    return 1
  fi
  summarize_stage \
    "${reservation_mode}" "${output_dir}" \
    "${additional_budget}" "${cumulative_budget}" \
    "${extra_args[@]}" \
    >"${OUTPUT_ROOT}/logs/${profile}/${stage}_summary.log" 2>&1
  echo "[MatchedIGA] profile=${profile} stage=${stage} complete"
}

run_profile() {
  local profile="$1"
  local reservation_mode="$2"
  local output_180="${OUTPUT_ROOT}/${profile}/iga180"
  local output_1800="${OUTPUT_ROOT}/${profile}/iga1800"
  run_parallel_stage \
    "${profile}" "${reservation_mode}" iga180 \
    "${output_180}" 180 180
  run_parallel_stage \
    "${profile}" "${reservation_mode}" iga1800 \
    "${output_1800}" 1620 1800 \
    --warm-start-dir "${output_180}" \
    --warm-start-budget-seconds 180
}

controller() {
  run_profile hard_F1 hard
  run_profile soft_F2F3 soft
  "${PYTHON}" -u "${ANALYZER}" \
    --hard-iga-dir "${OUTPUT_ROOT}/hard_F1/iga1800" \
    --soft-iga-dir "${OUTPUT_ROOT}/soft_F2F3/iga1800" \
    --legacy-iga-dir "${LEGACY_IGA}" \
    --f1-evaluation "${F1_EVAL}" \
    --f2-evaluation "${F2_EVAL}" \
    --f3-evaluation "${F3_EVAL}" \
    --output-dir "${OUTPUT_ROOT}/analysis" \
    >"${OUTPUT_ROOT}/logs/analysis.log" 2>&1
  echo "[MatchedIGA] all matched tests and paired analysis complete"
}

if [[ "${1:-}" == "--controller" ]]; then
  if [[ "$#" -ne 1 ]]; then
    echo "Usage: $0 --controller" >&2
    exit 2
  fi
  controller
  exit 0
fi

if [[ "$#" -ne 0 ]]; then
  echo "Usage: $0" >&2
  exit 2
fi

for required in \
  "${PYTHON}" "${RUNNER}" "${ANALYZER}" "${DATASET}" \
  "${CHECKPOINT}" "${SOURCE_COMMAND}" "${HANDOFF}" \
  "${F1_EVAL}" "${F2_EVAL}" "${F3_EVAL}" "${LEGACY_IGA}" \
  /usr/bin/taskset /usr/bin/nvidia-smi; do
  if [[ ! -e "${required}" ]]; then
    echo "[Error] Missing required input: ${required}" >&2
    exit 1
  fi
done
if ! [[ "${RUN_TAG}" =~ ^[A-Za-z0-9._-]+$ && "${UNIT}" =~ ^[A-Za-z0-9._-]+$ ]]; then
  echo "[Error] RUN_TAG and UNIT must be path/unit safe." >&2
  exit 1
fi
if [[ "$(nproc --all)" -ne 144 ]]; then
  echo "[Error] Expected this server's 144 logical CPUs." >&2
  exit 1
fi
if ! systemctl --user show-environment >/dev/null 2>&1; then
  echo "[Error] User systemd manager is unavailable." >&2
  exit 1
fi
load_state="$(systemctl --user show "${UNIT}.service" --property=LoadState --value 2>/dev/null || true)"
if [[ -n "${load_state}" && "${load_state}" != "not-found" ]]; then
  echo "[Error] Refusing to reuse existing unit ${UNIT}.service." >&2
  exit 1
fi
compute_pids="$(/usr/bin/nvidia-smi -i 0 --query-compute-apps=pid --format=csv,noheader,nounits | sed '/^[[:space:]]*$/d')"
if [[ -n "${compute_pids}" ]]; then
  echo "[Error] GPU0 is not idle: ${compute_pids//$'\n'/,}" >&2
  exit 1
fi

mkdir -p "${OUTPUT_ROOT}/logs" "/tmp/${UNIT}/matplotlib"
systemd-run --user \
  --unit="${UNIT}" \
  --collect \
  --same-dir \
  --property=Type=exec \
  --property=Restart=on-failure \
  --property=RestartSec=30 \
  --property=KillMode=control-group \
  --property=TimeoutStopSec=120 \
  --property=LimitNOFILE=262144 \
  --property=TasksMax=2048 \
  --property="AllowedCPUs=${SERVICE_CPUS}" \
  --property="CPUAffinity=${SERVICE_CPUS}" \
  --property=CPUWeight=100 \
  --property=NUMAPolicy=preferred \
  --property=NUMAMask=0 \
  --property="StandardOutput=append:${OUTPUT_ROOT}/logs/controller.log" \
  --property="StandardError=append:${OUTPUT_ROOT}/logs/controller.log" \
  --setenv=CUDA_VISIBLE_DEVICES=0 \
  --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
  --setenv=PYTHONUNBUFFERED=1 \
  --setenv=PYTHONHASHSEED=0 \
  --setenv=OMP_NUM_THREADS=1 \
  --setenv=MKL_NUM_THREADS=1 \
  --setenv=OPENBLAS_NUM_THREADS=1 \
  --setenv=NUMEXPR_NUM_THREADS=1 \
  --setenv="PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True,max_split_size_mb:512" \
  --setenv="MPLCONFIGDIR=/tmp/${UNIT}/matplotlib" \
  --setenv="TMPDIR=/tmp/${UNIT}" \
  /bin/bash "$0" --controller

echo "[Launch] ${UNIT}.service"
echo "[GPU] GPU0 only; GPU1 and its Stage3 jobs are untouched"
echo "[CPU] 36 physical / 72 logical CPUs on NUMA0, four isolated shards"
echo "[Profiles] F1-matched hard, then F2/F3-matched soft"
echo "[Budgets] nested IGA-180 then +1620s = cumulative IGA-1800"
echo "[Output] ${OUTPUT_ROOT}"
