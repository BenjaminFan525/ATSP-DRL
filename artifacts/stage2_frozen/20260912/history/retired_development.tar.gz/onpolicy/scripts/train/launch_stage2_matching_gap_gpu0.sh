#!/usr/bin/env bash
set -euo pipefail

TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../../.." && pwd)"
TASK_PYTHON="${PYTHON:-${TASK_ROOT}/../conda/envs/maia-hkbz-cu124-20260903/bin/python3.11}"
PROFILE="${PROFILE:-canary}"
RUN_TAG="${RUN_TAG:-stage2_matching_gap_20260906_gpu0_half_${PROFILE}_r1}"
TASK_SUITE="${TASK_ROOT}/result/hkbz_train_logs/${RUN_TAG}"
TASK_UNIT="hkbz-${RUN_TAG//_/-}"
[[ "${RUN_TAG}" =~ ^[a-zA-Z0-9_-]+$ ]] || { echo 'Invalid run tag' >&2; exit 1; }
[[ ! -e "${TASK_SUITE}" ]] || { echo "Suite already exists: ${TASK_SUITE}" >&2; exit 1; }
TASK_EXTRA=()
if [[ "${PROFILE}" == pilot ]]; then
  [[ -n "${CANARY_PROOF:-}" ]] || { echo 'Pilot requires CANARY_PROOF' >&2; exit 1; }
  TASK_EXTRA+=(--canary-proof "${CANARY_PROOF}")
fi
export CUDA_VISIBLE_DEVICES=0 CUDA_DEVICE_ORDER=PCI_BUS_ID
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
taskset -c 30-31,94-95 "${TASK_PYTHON}" \
  "${TASK_ROOT}/onpolicy/scripts/train/prepare_stage2_matching_gap.py" \
  --run-tag "${RUN_TAG}" --suite-dir "${TASK_SUITE}" --profile "${PROFILE}" --python "${TASK_PYTHON}" \
  "${TASK_EXTRA[@]}"
if [[ "${DRY_RUN:-0}" == 1 ]]; then exit 0; fi
systemd-run --user --unit="${TASK_UNIT}" --working-directory="${TASK_ROOT}" \
  --setenv=CUDA_VISIBLE_DEVICES=0 --setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID \
  --setenv=OMP_NUM_THREADS=1 --setenv=MKL_NUM_THREADS=1 --setenv=OPENBLAS_NUM_THREADS=1 \
  --setenv=NUMEXPR_NUM_THREADS=1 --setenv=PYTHONHASHSEED=0 \
  --setenv=CUBLAS_WORKSPACE_CONFIG=:4096:8 --setenv=PYTHONDONTWRITEBYTECODE=1 \
  --setenv=MPLCONFIGDIR="${TASK_SUITE}/mplconfig" \
  --setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
  --property=Type=exec --property=Restart=no --property=KillMode=control-group \
  --property=TimeoutStopSec=180 --property=LimitNOFILE=65536 \
  --property=AllowedCPUs=0-31,64-95 --property=CPUAffinity=0-31,64-95 \
  --property="StandardOutput=append:${TASK_SUITE}/controller.log" \
  --property="StandardError=append:${TASK_SUITE}/controller.log" \
  "${TASK_PYTHON}" -u "${TASK_ROOT}/onpolicy/scripts/train/run_stage2_bc_injection_suite.py" \
  --manifest "${TASK_SUITE}/manifest.json"
printf 'Started %s\nManifest: %s\n' "${TASK_UNIT}" "${TASK_SUITE}/manifest.json"
