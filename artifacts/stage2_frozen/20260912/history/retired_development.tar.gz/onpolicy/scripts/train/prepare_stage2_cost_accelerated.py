#!/usr/bin/env python3
"""Prepare immutable, independently gated BC and cost stages; never launch here."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import shlex
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage2_cost_improvement import prepare as prepare_prototype
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import set_option
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_cost_execution import EXECUTION_CONTRACT, json_digest
from onpolicy.utils.stage2_cost_schedule import arms_for_stage, check_proof, prerequisites
from onpolicy.utils.stage2_blocking_audit import BLOCKING_COVERAGE_CONTRACT
from onpolicy.utils.stage2_cost_continuation import build_continuation
from onpolicy.utils.stage2_cost_inference import INFERENCE_CONTRACT
from onpolicy.utils.stage2_cost_timeout import LEGACY_TIMEOUT_CONTRACT, TIMEOUT_CONTRACT
from onpolicy.utils.stage2_cost_timeout_reference import bind_timeout_reference

DOC = 'STAGE2_COST_ACCELERATION_IMPLEMENTATION_20260907.md'
LAUNCHER = 'onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare(cli):
    inference_mode = getattr(cli, 'inference_mode', 'legacy')
    timeout_contract = getattr(cli, 'timeout_contract', LEGACY_TIMEOUT_CONTRACT)
    if timeout_contract not in (LEGACY_TIMEOUT_CONTRACT, TIMEOUT_CONTRACT):
        raise ValueError('Unknown timeout contract.')
    if timeout_contract == TIMEOUT_CONTRACT and (cli.fanout_width, cli.actor_lanes) != (16, 4):
        raise ValueError('This timeout amendment is bound to the 16-branch/4-lane production-load proof.')
    if inference_mode not in ('legacy', 'host_matching'):
        raise ValueError('Unknown frozen inference mode.')
    if not 1 <= cli.fanout_width <= 16 or not 1 <= cli.actor_lanes <= min(4, cli.fanout_width):
        raise ValueError('Fanout width must be in [1,16], actor lanes in [1,min(4,fanout)].')
    supplied = dict(bc_canary=cli.bc_canary_proof, acceleration=cli.acceleration_proof,
                    cost_diagnostic=cli.diagnostic_proof, cost_canary=cli.cost_canary_proof,
                    timeout_regression=getattr(cli, 'timeout_proof', None))
    for required in prerequisites(cli.stage, timeout_contract):
        if not supplied.get(required):
            raise ValueError(f'{cli.stage} requires {required}; no gate is bypassed.')
    # Reuse only the already-pinned B0/R1/case/resource contracts. This prototype
    # has no execution side effects; its legacy archive is retained, not replaced.
    prototype_args = argparse.Namespace(suite_dir=cli.suite_dir, run_tag=cli.run_tag,
        python=cli.python, profile='diagnostic', diagnostic_proof=None, canary_proof=None)
    manifest = prepare_prototype(prototype_args)
    suite = cli.suite_dir.resolve()
    fingerprints = dict(manifest['code_fingerprint'])
    for relative in (DOC, LAUNCHER):
        fingerprints[relative] = digest(ROOT / relative)
    proofs = {}
    for required in prerequisites(cli.stage, timeout_contract):
        if not supplied.get(required):
            raise ValueError(f'{cli.stage} requires {required}; no gate is bypassed.')
        path = supplied[required].resolve()
        report = json.loads(path.read_text())
        source = Path(report['manifest']).resolve()
        proof_manifest = json.loads(source.read_text())
        check_proof(required, report, proof_manifest, fingerprints, cli.fanout_width, cli.actor_lanes,
                    inference_mode, timeout_contract)
        proofs[required] = dict(path=str(path), sha256=digest(path),
                                manifest=str(source), manifest_sha256=digest(source))
    canary = cli.stage.endswith('_canary')
    pilot = cli.stage.endswith('_pilot')
    arms = arms_for_stage(cli.stage)
    manifest.update(research_family='stage2_cost_accelerated', execution_stage=cli.stage,
        profile='canary' if canary else ('pilot' if pilot else 'diagnostic'),
        scientific_result=pilot, code_fingerprint=fingerprints, stage_proofs=proofs,
        analysis_script='onpolicy/scripts/train/analyze_stage2_cost_accelerated.py',
        diagnostic_proof=proofs.get('cost_diagnostic'),
        canary_proof=proofs.get('bc_canary') or proofs.get('cost_canary'),
        commands={key: value for key, value in manifest['commands'].items() if value['arm'] in arms})
    manifest['analysis_contract']['contrasts'] = [pair for pair in manifest['analysis_contract']['contrasts']
                                                if all(arm in arms for arm in pair)]
    manifest['analysis_contract']['blocking_repair_coverage'] = BLOCKING_COVERAGE_CONTRACT
    manifest['diagnostic_contract'].pop('pilot_wall_estimate_limit_seconds', None)
    manifest['diagnostic_contract'].update(budget_is_scientific_gate=False,
        estimation='actual_nonoverlapping_fanout_wall_time; concurrency_not_assumed')
    manifest['cost_contract']['execution'] = EXECUTION_CONTRACT
    manifest['cost_contract']['candidate_continuation_budget'] = 64 if canary else 7680
    if not any(entry['cost_improvement'] for entry in manifest['commands'].values()):
        manifest['cost_contract']['candidate_continuation_budget'] = 0
    manifest['schedule_contract'] = dict(order='bc_canary,bc_pilot,acceleration,cost_diagnostic,cost_canary,cost_pilot',
        baseline_independent_of_cost=True, max_concurrent_trainers=2,
        simultaneous_cost_diagnostic_and_bc=False, automatic_retry=False,
        hard_timeout_seconds=172800, estimate_is_not_training_eta=True)
    if getattr(cli, 'continue_from', None):
        manifest['continuation'] = build_continuation(cli.continue_from, manifest)
        manifest['schedule_contract'].update(
            order='reuse_completed_bc,acceleration,cost_diagnostic,cost_canary,cost_pilot',
            hard_deadline_unix_time=manifest['continuation']['hard_deadline_unix_time'])
        for index, (path, sha) in enumerate(manifest['continuation']['artifacts'].items()):
            manifest['research_case_files'][f'continuation_{index:03}'] = dict(path=path, sha256=sha)
    config = dict(contract=EXECUTION_CONTRACT, fanout_width=cli.fanout_width, actor_lanes=cli.actor_lanes,
        inference_mode=inference_mode,
        timeout_contract=timeout_contract,
        inference_contract=INFERENCE_CONTRACT if inference_mode == 'host_matching' else 'legacy',
        code_fingerprint=fingerprints, source_namespace=json_digest(fingerprints),
        cache_dir=str((cli.shared_cache or suite / 'cost_cache').resolve()),
        cost_training_allowed=cli.stage in ('cost_canary', 'cost_pilot'),
        execution_stage=cli.stage)
    config_path = suite / 'cost_executor.json'
    atomic_json(config_path, config)
    config_sha = digest(config_path)
    manifest['cost_executor'] = dict(path=str(config_path), sha256=config_sha,
                                     source_namespace=config['source_namespace'], fanout_width=cli.fanout_width,
                                     inference_mode=inference_mode,
                                     timeout_contract=timeout_contract,
                                     actor_lanes=cli.actor_lanes)
    if timeout_contract == TIMEOUT_CONTRACT:
        manifest['timeout_reference'] = bind_timeout_reference(manifest)
        for index, (path, sha) in enumerate(manifest['timeout_reference']['artifacts'].items()):
            manifest['research_case_files'][f'timeout_reference_{index:03}'] = dict(path=path, sha256=sha)
        manifest['schedule_contract']['timeout_regression_before_cost_diagnostic'] = True
        manifest['schedule_contract']['order'] = manifest['schedule_contract']['order'].replace(
            'acceleration,', 'timeout_regression,acceleration,', 1)
    manifest['research_case_files']['cost_executor'] = dict(path=str(config_path), sha256=config_sha)
    for name, proof in proofs.items():
        manifest['research_case_files'][name + '_proof'] = {key: proof[key] for key in ('path', 'sha256')}
        manifest['research_case_files'][name + '_manifest'] = dict(path=proof['manifest'], sha256=proof['manifest_sha256'])
    if canary:
        manifest['training_contract'].update(workers=2, rollouts_per_epoch=1)
        manifest['evaluation_contract'].update(workers=2, cases=4, per_job_zero_tolerance_replay=False)
        # This is a two-case engineering canary, not the pilot's tune60 replay.
        manifest['reference_validation'] = None
        manifest['sampling_audits']['11']['case_order'] = ['case_0343', 'case_0444']
    for entry in manifest['commands'].values():
        command = entry['argv']
        command[1] = str(ROOT / 'onpolicy/scripts/train/train_stage2_cost_accelerated.py')
        command += ['--stage2-cost-executor-config', str(config_path),
                    '--stage2-cost-executor-sha256', config_sha]
        if canary:
            changes = {'--n_rollout_threads': 2, '--max_train_cases': 2, '--train_sampling_size': 2,
                '--device_bc_min_rollouts_per_epoch': 1, '--device_bc_max_rollouts_per_epoch': 1,
                '--n_eval_rollout_threads': 2, '--max_eval_cases': 4, '--mini_batch_size': 2,
                '--stage2_policy_warmstart_evaluation': '', '--stage2_policy_warmstart_evaluation_sha256': '',
                '--stage2_research_train_cases': str(suite / 'regression_cases.json')}
            for key, value in changes.items():
                set_option(command, key, value)
        entry['shell'] = shlex.join(command)
    archive = suite / 'accelerated_source_bundle.tar.gz'
    with tarfile.open(archive, 'x:gz') as handle:
        for relative, expected in fingerprints.items():
            path = ROOT / relative
            data = path.read_bytes()
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError('Source changed during preparation.')
            handle.addfile(handle.gettarinfo(str(path), arcname=relative), io.BytesIO(data))
    manifest['source_archive'] = dict(path=str(archive), sha256=digest(archive))
    atomic_json(suite / 'manifest.json', manifest)
    atomic_json(suite / 'evaluator_source.json', {'command': next(iter(manifest['commands'].values()))['argv']})
    print(json.dumps({'prepared': str(suite / 'manifest.json'), 'stage': cli.stage, 'arms': list(arms)}))
    return manifest


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument('--stage', choices=['pipeline', 'bc_canary', 'bc_pilot', 'acceleration',
                        'cost_diagnostic', 'cost_canary', 'cost_pilot'], default='pipeline')
    result.add_argument('--run-tag', required=True)
    result.add_argument('--suite-dir', type=Path, required=True)
    result.add_argument('--python', type=Path, default=Path(sys.executable))
    result.add_argument('--fanout-width', type=int, default=8)
    result.add_argument('--actor-lanes', type=int, default=2)
    result.add_argument('--inference-mode', choices=['legacy', 'host_matching'], default='legacy')
    result.add_argument('--continue-from', type=Path,
                        help='Stopped pipeline manifest: reuse compatible completed BC, not old cost gates.')
    result.add_argument('--timeout-contract', choices=[LEGACY_TIMEOUT_CONTRACT, TIMEOUT_CONTRACT],
                        default=LEGACY_TIMEOUT_CONTRACT)
    result.add_argument('--timeout-proof', type=Path)
    result.add_argument('--shared-cache', type=Path)
    result.add_argument('--bc-canary-proof', type=Path)
    result.add_argument('--acceleration-proof', type=Path)
    result.add_argument('--diagnostic-proof', type=Path)
    result.add_argument('--cost-canary-proof', type=Path)
    return result


if __name__ == '__main__':
    prepare(parser().parse_args())
