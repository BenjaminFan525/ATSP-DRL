#!/usr/bin/env python3
"""Finite baseline-first controller; a failed cost path cannot hold N0/N1."""
import argparse
import json
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_stage2_bc_injection_suite import stop_owned, verify_resources
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_cost_schedule import STAGES, capacity_decision
from onpolicy.utils.stage2_cost_continuation import validate_baseline
from onpolicy.utils.stage2_cost_timeout import LEGACY_TIMEOUT_CONTRACT, TIMEOUT_CONTRACT


def run(cli):
    manifest_path = cli.manifest.resolve()
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('execution_stage') != 'pipeline':
        raise ValueError('Use a fresh accelerated pipeline manifest.')
    verify_resources(manifest)
    suite = manifest_path.parent
    state_path = suite / 'pipeline_state.json'
    if state_path.exists():
        raise FileExistsError('Controller restart/retry is not automatic.')
    started, deadline = time.time(), time.monotonic() + manifest['resource_contract']['hard_timeout_seconds']
    continuation = manifest.get('continuation')
    if continuation:
        validate_baseline(continuation, manifest)
        remaining = continuation['hard_deadline_unix_time'] - started
        if remaining <= 0:
            raise TimeoutError('Original experiment deadline expired; no budget reset.')
        deadline = time.monotonic() + min(remaining, manifest['resource_contract']['hard_timeout_seconds'])
    state = dict(status='running', phase='bc_canary', started_unix_time=started,
        manifest=str(manifest_path), physical_gpu=0, allowed_cpus='0-31,64-95', phases={},
        baseline_completed=False, cost_completed=False, baseline_independent_of_cost=True,
        automatic_retry=False, rl_started=False, stage3_started=False)
    child = None
    reports = {}
    stages = STAGES
    if continuation:
        reports['bc_pilot'] = Path(continuation['baseline_report'])
        state.update(baseline_completed=True, baseline_reused=True,
            baseline_report=str(reports['bc_pilot']),
            hard_deadline_unix_time=continuation['hard_deadline_unix_time'],
            parent_manifest=continuation['parent_manifest'])
        stages = tuple(stage for stage in STAGES if stage not in ('bc_canary', 'bc_pilot'))
    if manifest['cost_executor'].get('timeout_contract') == TIMEOUT_CONTRACT:
        index = stages.index('acceleration')
        stages = stages[:index] + ('timeout_regression',) + stages[index:]
    state['source_reports'] = {name: str(path) for name, path in reports.items()}

    def execute(command, label):
        nonlocal child
        log = suite / f'{label}.log'
        with log.open('x') as handle:
            child = subprocess.Popen(command, cwd=ROOT, stdout=handle,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            state['phase'] = label
            state['phases'][label] = dict(status='running', pid=child.pid, command=command,
                                         log=str(log), started_unix_time=time.time())
            while child.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Declared 48-hour global deadline; outputs preserved, no retry.')
                state.update(updated_unix_time=time.time(),
                    output_stall_advisory=time.time() - log.stat().st_mtime > 300)
                atomic_json(state_path, state)
                print(f'[CostAccelerationPipeline] phase={label} pid={child.pid} '
                      f'elapsed={time.time()-started:.0f}s baseline_completed={state["baseline_completed"]}', flush=True)
                time.sleep(30)
            code = child.returncode
            state['phases'][label].update(status='completed' if code == 0 else 'failed',
                                         exit_code=code, ended_unix_time=time.time())
            child = None
            atomic_json(state_path, state)
            return code

    def hold(stage, code):
        state.update(status='held_on_cost_path' if state['baseline_completed'] else 'failed',
            failed_stage=stage, exit_code=code, source_reports={key: str(value) for key, value in reports.items()},
            reason='No automatic retry or gate bypass. Completed N0/N1 outputs remain available.'
                   if state['baseline_completed'] else 'BC prerequisite failed; no later training started.')
        return code

    try:
        for stage in stages:
            if stage == 'timeout_regression':
                code = execute([sys.executable, '-u',
                    str(ROOT / 'onpolicy/scripts/train/verify_stage2_cost_timeout.py'),
                    '--manifest', str(manifest_path)], stage)
                if code:
                    return hold(stage, code)
                reports[stage] = suite / 'timeout_regression/report.json'
                continue
            if stage == 'cost_pilot':
                diagnosis = json.loads(reports['cost_diagnostic'].read_text())
                capacity = capacity_decision(diagnosis['cost_work_estimate'],
                                             max(0., deadline - time.monotonic()))
                state['cost_capacity'] = capacity
                atomic_json(suite / 'cost_capacity.json', capacity)
                if not capacity['cost_pilot_launch_allowed']:
                    state.update(status='held_on_estimated_cost_capacity',
                        reason='N0/N1 and the cost canary are retained. Cost scientific checks passed, '
                               'but even optimistic label work exceeds remaining time; no budget expansion or retry.')
                    return 2
            if stage == 'acceleration':
                code = execute([sys.executable, '-u', str(ROOT / 'onpolicy/scripts/train/benchmark_stage2_cost_execution.py'),
                                '--manifest', str(manifest_path)], stage)
                if code:
                    return hold(stage, code)
                reports[stage] = suite / 'acceleration/report.json'
                continue
            destination = suite.parent / (manifest['run_tag'] + '_' + stage)
            command = [sys.executable, str(ROOT / 'onpolicy/scripts/train/prepare_stage2_cost_accelerated.py'),
                '--stage', stage, '--run-tag', destination.name, '--suite-dir', str(destination),
                '--python', sys.executable, '--fanout-width', str(manifest['cost_executor']['fanout_width']),
                '--actor-lanes', str(manifest['cost_executor']['actor_lanes']),
                '--inference-mode', manifest['cost_executor'].get('inference_mode', 'legacy'),
                '--timeout-contract', manifest['cost_executor'].get('timeout_contract', LEGACY_TIMEOUT_CONTRACT),
                '--shared-cache', str(suite / 'cost_cache')]
            if continuation:
                command += ['--continue-from', continuation['parent_manifest']]
            flags = dict(bc_canary='--bc-canary-proof', acceleration='--acceleration-proof',
                         cost_diagnostic='--diagnostic-proof', cost_canary='--cost-canary-proof',
                         timeout_regression='--timeout-proof')
            for name, flag in flags.items():
                if name in reports:
                    command += [flag, str(reports[name])]
            code = execute(command, 'prepare_' + stage)
            if code:
                return hold(stage, code)
            child_manifest = destination / 'manifest.json'
            script = ('diagnose_stage2_cost_accelerated.py' if stage == 'cost_diagnostic'
                      else 'run_stage2_bc_injection_suite.py')
            code = execute([sys.executable, '-u', str(ROOT / 'onpolicy/scripts/train' / script),
                            '--manifest', str(child_manifest)], stage)
            if code:
                return hold(stage, code)
            reports[stage] = destination / ('diagnostics/report.json' if stage == 'cost_diagnostic'
                                            else 'analysis/comparison.json')
            if stage == 'bc_pilot':
                state['baseline_completed'] = True
            if stage == 'cost_pilot':
                state['cost_completed'] = True
        output = suite / 'analysis/comparison.json'
        code = execute([sys.executable, str(ROOT / 'onpolicy/scripts/train/analyze_stage2_cost_accelerated.py'),
            '--bc-report', str(reports['bc_pilot']), '--cost-report', str(reports['cost_pilot']),
            '--output', str(output)], 'four_arm_analysis')
        if code:
            return hold('four_arm_analysis', code)
        state.update(status='completed', comparison=str(output), four_arm_comparison_complete=True)
        return 0
    except BaseException as error:
        state.update(status='failed', error=str(error))
        raise
    finally:
        if child is not None:
            stop_owned(child)
        state['ended_unix_time'] = time.time()
        atomic_json(state_path, state)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    raise SystemExit(run(parser.parse_args()))
