#!/usr/bin/env python3
"""Explicit V6 train240/tune60 BC run; keep pilot, learner and safety rules intact."""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml

from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, cpus, metrics
from onpolicy.scripts.train.run_stage2_resource_rl_v4 import save_tensor_artifact
from onpolicy.scripts.train.run_stage2_resource_v6 import Suite, V6Progress
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_bc_replay import validate_case_content
from onpolicy.utils.stage2_policy_transfer import verified_frozen_ready_source
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_handoff import validate_frozen_lineage
from onpolicy.utils.stage2_resource_rl_v4 import compare_cases
from onpolicy.utils.stage2_resource_rl_v4_resume import assert_tree_equal
from onpolicy.utils.stage2_resource_v6 import ARMS
from onpolicy.utils.stage2_resource_v6_full import (
    PROTOCOL, assert_replayed_subset, case_batches, checkpoint_progress,
    validate_plan, validate_teacher_parts,
)


class FullProgress(V6Progress):
    def __call__(self, event, force=False, **values):
        if event == 'case_batch_start':
            values = dict(arm=None, epoch=None, batch=None, total_batches=None,
                replay_step=None, replay_total=None, actor_steps=None,
                completed_cases=0, event_step=0) | values
        elif event == 'bc_batch_start':
            values = dict(replay_step=0, replay_total=None, event_step=None,
                completed_cases=None, total_cases=None) | values
        return super().__call__(event, force=force, **values)

    def write(self):
        with self.lock:
            stalled = time.time() - self.state.get('last_work_progress_unix', self.started)
            self.state.update(protocol=PROTOCOL, updated_unix=time.time(),
                elapsed_seconds=time.time() - self.started, hard_deadline_unix=None,
                wall_clock_limit_enabled=False, time_authorization_version='user_train240_20260911',
                seconds_since_work_progress=stalled, stall_suspected=stalled > 90,
                stall_action='advisory_only_no_kill_or_retry')
            atomic_json(self.suite / 'run_status.json', self.state)


class FullSuite(Suite):
    def __init__(self, manifest):
        super().__init__(manifest)
        self.reused_teacher_cases = 0
        self.new_teacher_cases = 0

    def validate(self):
        pilot = json.loads(Path(self.m['pilot_manifest']['path']).read_text())
        report = json.loads(Path(self.m['pilot_report']['path']).read_text())
        validate_plan(self.m, pilot, report)
        if (os.environ.get('CUDA_VISIBLE_DEVICES') != '0'
                or not set(os.sched_getaffinity(0)).issubset(cpus('0-31,64-95'))):
            raise ValueError('GPU0 and original CPU half are required.')
        if (self.root / 'run_status.json').exists():
            raise FileExistsError('No automatic retry or output-directory reuse.')
        for name, digest in self.m['code_fingerprint'].items():
            if file_sha(ROOT / name) != digest:
                raise ValueError(f'Pinned full-run code changed: {name}')
        for name, digest in pilot['code_fingerprint'].items():
            if file_sha(ROOT / name) != digest:
                raise ValueError(f'Pilot learner or environment changed: {name}')
        for field in ('source', 'stage1_source', 'ready_source', 'source_archive', 'iga_reference',
                      'engineering_proof', 'regression_proof', 'pilot_manifest', 'pilot_status',
                      'pilot_report', 'pilot_teacher_manifest', 'pilot_b0_evaluation', 'pilot_source_archive'):
            item = self.m[field]
            if file_sha(item['path']) != item['sha256']:
                raise ValueError(f'Immutable input changed: {field}')
        for field in ('engineering_proof', 'regression_proof'):
            proof = json.loads(Path(self.m[field]['path']).read_text())
            if not proof['passed'] or any(file_sha(ROOT / n) != d for n, d in proof['checked_sources'].items()):
                raise ValueError(f'Passed proof does not cover the current sources: {field}')
        if file_sha(self.m['teacher_index']) != self.m['teacher_index_sha256']:
            raise ValueError('Teacher index changed.')
        for role in ('train', 'evaluation'):
            validate_case_content(self.m[role]['cases'], self.m[role]['dataset'])
        teacher = json.loads(Path(self.m['pilot_teacher_manifest']['path']).read_text())
        if teacher['parts'] != self.m['teacher_reuse']['parts']:
            raise ValueError('The read-only reused cache manifest changed.')
        for part in teacher['parts']:
            for key, digest in (('path', 'sha256'), ('stateless_path', 'stateless_sha256')):
                if file_sha(part[key]) != part[digest]:
                    raise ValueError('A read-only reused teacher artifact changed.')

    def write_ledger(self):
        atomic_json(self.root / 'resource_ledger.json', dict(attempted=self.attempted,
            completed=self.completed, entries=self.ledger,
            actor_steps={a: l.actor_steps for a, l in self.learners.items()},
            reused_teacher_case_episodes=self.reused_teacher_cases,
            new_teacher_case_episodes=self.new_teacher_cases,
            teacher_dataset_case_episodes=self.reused_teacher_cases + self.new_teacher_cases,
            total_case_episode_limit=self.m['execution']['total_case_episode_limit'],
            logical_case_episode_budget_including_reuse=796,
            search_calls=0, cost_label_queries=0, wall_clock_timeout=False))

    def collect(self, learner, rows, label, **kwargs):
        result = super().collect(learner, rows, label, **kwargs)
        if kwargs.get('teacher') and kwargs.get('store'):
            self.new_teacher_cases += len(rows)
        self.write_ledger()
        return result

    def evaluate(self, learner, label, rows=None):
        rows = self.m['evaluation']['cases'] if rows is None else rows
        groups = case_batches(rows, self.c['evaluation_workers'])
        started = time.monotonic()
        cases, parts = [], []
        for number, group in enumerate(groups, 1):
            result = self.collect(learner, group, f'{label}_batch_{number}', evaluation=True)
            current = {k: v for k, v in result.items() if k not in ('frames', 'label_audit')}
            atomic_json(self.root / 'evaluations' / label / f'batch_{number}.json', current)
            cases.extend(result['cases'])
            parts.append(dict(batch=number, seconds=result['seconds'], cases=len(group),
                environment_events=result['environment_events'], checks=result['checks']))
            self.progress('full_evaluation_batch_completed', force=True, phase=label,
                evaluation_completed_cases=len(cases), evaluation_total_cases=len(rows),
                evaluation_batch=number, evaluation_total_batches=len(groups),
                actor_steps_by_arm={a: l.actor_steps for a, l in self.learners.items()})
        if [r['case_dir'] for r in cases] != [r['case_dir'] for r in rows]:
            raise ValueError('Full tune60 case order or coverage changed.')
        atomic_json(self.root / 'evaluations' / f'{label}.json', dict(cases=cases,
            summary=metrics(cases), seconds=time.monotonic() - started,
            collection_seconds=sum(p['seconds'] for p in parts), batches=parts,
            development_only=True, independent_confirmation=False, teacher_execution=False))
        return cases

    def checkpoint(self, learner, name):
        state = learner.checkpoint_state()
        state.update(learner_protocol=state['protocol'], protocol=PROTOCOL,
            source=self.m['source'], manifest_sha256=file_sha(self.path),
            stage2_training_mode=PROTOCOL, training_stage='resource_joint',
            input_schema='resource_semantic_pair_view_v6_1', training_contract=self.c,
            **checkpoint_progress(learner.actor_steps),
            teacher_data_manifest_sha256=file_sha(self.root / 'teacher_data/manifest.json'),
            pilot_observation=self.m['pilot_observation'], automatic_promotion=False,
            confirmed_scientific_success=False, ppo_started=False)
        path = self.root / learner.arm / name
        save_tensor_artifact(state, path)
        return path

    def reference_audit(self, base):
        reference = {}
        for name, archive in self.m['archived_teachers'].items():
            variants = {}
            for projected in (False, True):
                label = name + ('_projected' if projected else '_production')
                result = self.collect(base, self.m['diagnostic_cases'], label, evaluation=True,
                    teacher=True, archived=archive, projected=projected)
                variants[str(projected)] = result['cases']
                atomic_json(self.root / 'references' / f'{label}.json',
                    {k: v for k, v in result.items() if k not in ('frames', 'label_audit')})
            comparison = compare_cases(variants['False'], variants['True'])
            deltas = {r['case_dir']: r['makespan'] - archive['archived_makespans'][r['case_dir']]
                      for r in variants['False']}
            comparison.update(archived_replay_deltas=deltas,
                archived_cmax_reproduced=all(abs(v) <= 1e-5 for v in deltas.values()),
                current_runtime_reference_used=True)
            reference[name] = comparison
            if comparison['relative_improvement'] < -.005:
                atomic_json(self.root / 'checks/teacher_projection.json', dict(passed=False, comparisons=reference))
                raise RuntimeError('Teacher projection loses >0.5%; do not train the degraded expert.')
        atomic_json(self.root / 'checks/teacher_projection.json', dict(passed=True,
            comparisons=reference, cases=4, diagnostic_only=True,
            strict_search_budget_certified=False, search_calls=0))

    def teacher_data(self, base):
        dataset = copy.deepcopy(self.m['teacher_reuse']['parts'])
        self.reused_teacher_cases = sum(len(p['cases']) for p in dataset)
        self.ledger.append(dict(label='read_only_teacher48_reuse', attempted_cases=0,
            completed_cases=0, reused_cases=self.reused_teacher_cases, seconds=0,
            source=self.m['pilot_teacher_manifest']))
        self.write_ledger()
        groups = case_batches(self.m['train']['cases'], self.c['minibatch_cases'])
        for number, group in enumerate(groups, 1):
            if number <= len(self.m['teacher_reuse']['parts']):
                continue
            result = self.collect(base, group, f'teacher_batch_{number}', store=True, teacher=True)
            labels = result.pop('label_audit')
            path = self.root / 'teacher_data' / f'batch_{number}.pt'
            save_tensor_artifact(result, path)
            atomic_json(path.with_suffix('.labels.json'), labels)
            packed = base.pack_stateless(result)
            packed_path = path.with_name(path.stem + '_stateless.pt')
            save_tensor_artifact(packed, packed_path)
            dataset.append(dict(path=str(path), sha256=file_sha(path),
                stateless_path=str(packed_path), stateless_sha256=file_sha(packed_path),
                role_free_counts={r: len(v['target']) for r, v in packed['stateless_records'].items()},
                cases=[r['case_dir'] for r in result['cases']]))
            del packed, result, labels
        validate_teacher_parts(dataset, self.m['train']['cases'])
        atomic_json(self.root / 'teacher_data/manifest.json', dict(parts=dataset,
            teacher_dataset_case_episodes=240, physical_case_episodes_this_run=self.new_teacher_cases,
            reused_physical_case_episodes=self.reused_teacher_cases, reused_source=self.m['pilot_teacher_manifest'],
            source='pinned_IGA1800_live_AR_projected_teacher', includes_complete_prefix=True, cost_branches=0))
        counts = {role: sum(p['role_free_counts'].get(role, 0) for p in dataset)
                  for role in ('ordinary', 'transporter')}
        atomic_json(self.root / 'checks/teacher_role_coverage.json', dict(passed=all(counts.values()), counts=counts))
        if not all(counts.values()) or self.new_teacher_cases != 192 or self.reused_teacher_cases != 48:
            raise RuntimeError('Full teacher data lacks required role labels or exact episode coverage.')
        return dataset

    def train(self, dataset, baseline):
        for arm in ARMS:
            self.learners[arm] = self.policy(arm)
            self.evaluate(self.learners[arm], f'{arm}_epoch_0_tune60')
        updates, finals = {a: [] for a in ARMS}, {}
        for epoch in range(1, self.c['bc_epochs'] + 1):
            for batch, part in enumerate(dataset, 1):
                os.sched_setaffinity(0, cpus(self.m['resource_contract']['train_cpus']))
                self.progress('teacher_batch_load', force=True, phase='full_bc', epoch=epoch,
                    batch=batch, total_batches=len(dataset), arm=None,
                    actor_steps_by_arm={a: l.actor_steps for a, l in self.learners.items()})
                if file_sha(part['path']) != part['sha256']:
                    raise ValueError('Shared teacher trajectories changed.')
                rollout = torch.load(part['path'], map_location='cpu', weights_only=False)
                for arm in ARMS:
                    learner = self.learners[arm]
                    self.progress('bc_batch_start', force=True, phase='full_bc', arm=arm,
                        epoch=epoch, batch=batch, total_batches=len(dataset), actor_steps=learner.actor_steps,
                        teacher_case_episodes=240, supervised_case_presentations=(epoch - 1) * 240 + batch * 6,
                        actor_steps_by_arm={a: l.actor_steps for a, l in self.learners.items()})
                    started = time.monotonic()
                    if arm == 'S2':
                        if file_sha(part['stateless_path']) != part['stateless_sha256']:
                            raise ValueError('Stateless raw teacher features changed.')
                        packed = torch.load(part['stateless_path'], map_location='cpu', weights_only=False)
                        update = learner.bc_epoch_batch(packed)
                        del packed
                    else:
                        update = learner.bc_epoch_batch(rollout)
                    update.update(epoch=epoch, batch=batch, seconds=time.monotonic() - started)
                    updates[arm].append(update)
                    atomic_json(self.root / arm / f'epoch_{epoch}_batch_{batch}.json', update)
                    self.progress('bc_batch_completed', force=True, actor_steps=learner.actor_steps,
                        actor_steps_by_arm={a: l.actor_steps for a, l in self.learners.items()})
                del rollout
            # Preserve both endpoints before entering potentially long development evaluations.
            for arm, learner in self.learners.items():
                path = self.checkpoint(learner, f'checkpoint_epoch_{epoch}.pt')
                if epoch == 1:
                    saved = torch.load(path, map_location='cpu', weights_only=False)
                    assert_tree_equal(saved['model'], {k: v.cpu() for k, v in learner.policy.ac.state_dict().items()},
                        'V6 full-data checkpoint')
                    atomic_json(self.root / arm / 'checkpoint_disk_check.json', dict(passed=True,
                        sha256=file_sha(path), weights_roundtrip=True, optimizer_saved=True))
                    del saved
            self.write_ledger()
            if epoch in self.c['evaluation_epochs']:
                for arm, learner in self.learners.items():
                    finals[arm] = self.evaluate(learner, f'{arm}_epoch_{epoch}_tune60')
        results = {}
        for arm, learner in self.learners.items():
            comparison = compare_cases(baseline, finals[arm])
            before, after = metrics(baseline), metrics(finals[arm])
            first_loss = float(np.mean([u['loss'] for u in updates[arm] if u['epoch'] == 1]))
            final_loss = float(np.mean([u['loss'] for u in updates[arm] if u['epoch'] == 10]))
            screen = self.m['screen']
            passed = (comparison['relative_improvement'] >= -screen['maximum_mean_regression_vs_b0']
                and learner.actor_steps == 400
                and all(after['groups'][g] <= before['groups'][g] * (1 + screen['maximum_group_regression'])
                        for g in before['groups'])
                and after['tail10'] <= before['tail10'] * (1 + screen['maximum_tail_regression'])
                and final_loss < first_loss)
            results[arm] = dict(development_screen_passed=passed, comparison=comparison,
                actor_steps=learner.actor_steps, updates=updates[arm], checks=learner.checks,
                first_epoch_training_loss=first_loss, final_epoch_training_loss=final_loss,
                baseline_summary=before, final_summary=after)
        if self.completed != self.m['execution']['total_case_episode_limit']:
            raise RuntimeError('Full experiment did not complete its exact physical-case budget.')
        atomic_json(self.root / 'full_report.json', dict(results=results, endpoint=10,
            development_only=True, confirmed_scientific_success=False,
            manual_exploratory_extension=True, pilot_observation=self.m['pilot_observation'],
            completed_physical_case_episodes=self.completed, reused_teacher_case_episodes=48,
            automatic_ppo=False, automatic_stage3=False, next_stage_requires_decision=True))

    def run(self):
        self.validate()
        self.progress = FullProgress(self.root)
        self.progress.state.update(full_train240_started=True, ppo_started=False, stage3_started=False,
            manual_exploratory_extension=True, pilot_observation=self.m['pilot_observation'],
            automatic_promotion=False, total_physical_case_episode_budget=748)

        def stop(signum, frame):
            raise KeyboardInterrupt(f'Operator/service signal {signum}')

        signal.signal(signal.SIGTERM, stop)
        signal.alarm(0)
        try:
            self.progress('full_preflight', force=True, phase='preflight')
            configure_bc_determinism(True)
            torch.set_num_threads(1)
            torch.cuda.set_per_process_memory_fraction(.85, 0)
            if str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') != self.m['resource_contract']['gpu_uuid'].removeprefix('GPU-'):
                raise ValueError('Wrong physical GPU UUID.')
            self.args = arguments(self.m)
            self.args.stage2_resource_v6_observations = True
            self.payload = torch.load(self.m['source']['path'], map_location='cpu', weights_only=True)
            verified_frozen_ready_source(self.payload)
            for key, value in ready_head_config(self.payload).items():
                setattr(self.args, key, value)
            self.ac_config = yaml.safe_load(Path(self.args.ac_config).read_text())
            atomic_json(self.root / 'checks/frozen_lineage.json', validate_frozen_lineage(self.payload, self.m['stage1_source']))
            base = self.policy()
            self.reference_audit(base)
            baseline = self.evaluate(base, 'B0_AR_tune60')
            old = json.loads(Path(self.m['pilot_b0_evaluation']['path']).read_text())['cases']
            atomic_json(self.root / 'checks/pilot_b0_replay.json', assert_replayed_subset(old, baseline))
            dataset = self.teacher_data(base)
            self.train(dataset, baseline)
            self.write_ledger()
            self.progress('full_completed', force=True, status='completed', phase='awaiting_full_review',
                completed_physical_case_episodes=self.completed, reused_teacher_case_episodes=48,
                actor_steps={a: l.actor_steps for a, l in self.learners.items()},
                actor_steps_by_arm={a: l.actor_steps for a, l in self.learners.items()})
            return 0
        except BaseException as exc:
            self.progress.state.update(status='failed', error=str(exc), traceback=traceback.format_exc(),
                automatic_retry=False)
            self.progress.write()
            for arm, learner in self.learners.items():
                try:
                    self.checkpoint(learner, 'checkpoint_interrupted.pt')
                except Exception as save_error:
                    print(f'Could not save {arm} interruption: {save_error}', flush=True)
            print(traceback.format_exc(), flush=True)
            return 1
        finally:
            if self.envs is not None:
                self.envs.close()
            self.progress.stop.set()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    suite = FullSuite(args.manifest)
    if args.validate_only:
        suite.validate()
        print('Full train240/tune60 manifest and immutable input checks passed.', flush=True)
    else:
        sys.exit(suite.run())
