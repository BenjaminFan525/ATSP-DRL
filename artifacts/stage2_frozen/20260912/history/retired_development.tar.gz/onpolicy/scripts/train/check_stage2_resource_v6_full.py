#!/usr/bin/env python3
"""Run selected CPU regressions, preserving a source-bound prelaunch report."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_resource_rl import file_sha

MODULES = ('test_stage2_resource_v6_full', 'test_stage2_resource_v6',
    'test_stage2_resource_rl', 'test_stage2_resource_rl_v4_fast',
    'test_stage2_bc_replay', 'test_stage2_resource_rl_v5', 'test_device_lookahead_dispatch')


def run(output):
    if output.exists():
        raise FileExistsError('Use a new regression proof path.')
    torch.set_num_threads(1)
    started = time.monotonic()
    fingerprints = code_fingerprint()
    for name in ('onpolicy/scripts/train/launch_stage2_resource_v6_full_gpu0.sh',
                 'STAGE2_RESOURCE_V6_TRAIN240_20260911.md'):
        fingerprints[name] = file_sha(ROOT / name)
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(
        'onpolicy.envs.HKBZ.test.' + name) for name in MODULES)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    unchanged = all(file_sha(ROOT / name) == digest for name, digest in fingerprints.items())
    passed = result.wasSuccessful() and unchanged and result.testsRun > 0
    atomic_json(output, dict(passed=passed, tests_run=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        modules=list(MODULES), seconds=time.monotonic() - started,
        checked_sources=fingerprints, sources_unchanged_during_tests=unchanged,
        scientific_updates=0, scientific_case_episodes=0, gpu_engineering_rerun=False))
    return 0 if passed else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    sys.exit(run(parser.parse_args().output))
