"""V5 scope/routing/cache/critic/restore regressions; no complete-case episodes."""
import copy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import numpy as np
import torch
import yaml
from torch_geometric.data import Batch

from onpolicy.envs.HKBZ.test.test_joint_training import _make_env, _make_policy
from onpolicy.envs.HKBZ.test.test_stage2_resource_rl import TinyModel
from onpolicy.utils.stage2_resource_rl import forward, learner_mode, resource_mask, summary
from onpolicy.utils.stage2_resource_rl_v4_fast import prepared_forward
from onpolicy.utils.stage2_resource_rl_v4_resume import assert_tree_equal
from onpolicy.utils.stage2_resource_rl_v5 import (
    ACTOR, VALUE, ARMS, DEFAULTS, SplitEncoderLearner, architecture_manifest,
    assert_no_alias, balanced_indices, clean_cases, install_encoders,
    protected_summary, restore_training_state, training_state,
)
from onpolicy.scripts.train.control_stage2_resource_rl_v5 import Controller, budget_projection


def tiny(arm='E3'):
    torch.manual_seed(11)
    model = TinyModel()
    model.resource_residual_adapter = None
    reference = copy.deepcopy(model)
    for p in reference.parameters():
        p.requires_grad_(False)
    policy = SimpleNamespace(ac=model, bc_reference_ac=reference, device=torch.device('cpu'))
    args = SimpleNamespace(max_agent_num=1, max_device_num=1, recurrent_N=1, hidden_size=2)
    return SplitEncoderLearner(policy, args, dict(DEFAULTS), lambda *a, **k: None, arm=arm)


class SplitTests(unittest.TestCase):
    def test_arms_exact_deep_copy_whitelist_and_learning_rates(self):
        for arm in ARMS:
            learner = tiny(arm)
            ac = learner.policy.ac
            self.assertEqual(hasattr(ac, 'resource_encoder'), arm in ('E1', 'E3'))
            self.assertEqual(hasattr(ac, 'value_encoder'), arm in ('E2', 'E3'))
            self.assertFalse(any(p.requires_grad for p in ac.encoder.parameters()))
            for n, p in ac.named_parameters():
                self.assertEqual(p.requires_grad, n.startswith(ACTOR + VALUE))
            for name in ('resource_encoder', 'value_encoder'):
                if hasattr(ac, name):
                    self.assertEqual(summary(getattr(ac, name)), summary(ac.encoder))
            self.assertTrue(assert_no_alias(ac, learner.policy.bc_reference_ac))
            self.assertEqual(learner.actor_optim.param_groups[0]['lr'], 3e-5)
            self.assertEqual(learner.critic_optim.param_groups[0]['lr'], 1e-4)
            if arm in ('E1', 'E3'):
                self.assertEqual(learner.actor_optim.param_groups[1]['lr'], 3e-6)
            if arm in ('E2', 'E3'):
                self.assertEqual(learner.critic_optim.param_groups[1]['lr'], 1e-5)

    def test_alias_and_double_install_rejected(self):
        learner = tiny()
        with self.assertRaises(ValueError):
            install_encoders(learner.policy.ac, 'E3')
        learner.policy.ac.value_encoder = learner.policy.ac.encoder
        with self.assertRaises(RuntimeError):
            assert_no_alias(learner.policy.ac)

    def test_flattened_gru_style_storage_allows_disjoint_not_overlapping_views(self):
        buffer = torch.arange(12, dtype=torch.float32)
        model = torch.nn.Module()
        model.register_parameter('first', torch.nn.Parameter(buffer[:6].view(2, 3)))
        model.register_parameter('second', torch.nn.Parameter(buffer[6:].view(2, 3)))
        self.assertEqual(assert_no_alias(model), 2)
        model.second = torch.nn.Parameter(buffer[5:11].view(2, 3))
        with self.assertRaisesRegex(RuntimeError, 'Overlapping'):
            assert_no_alias(model)

    def test_clean_metrics_do_not_inherit_runtime_or_stale_delta(self):
        old = dict(case_dir='case_1', case_sha256='abc', distribution='iid', makespan=100.,
                   resource_wait_seconds=999., finish_steps=777, delta_vs_pre_ppo=444.)
        current = dict(case_dir='case_1', makespan=90., completed=True, timeout=False,
                       cycle_terminated=False, steps=5, resource_wait_seconds=3.)
        actual = clean_cases([current], [old])[0]
        self.assertEqual(actual['runtime_metrics']['resource_wait_seconds'], 3.)
        self.assertEqual(actual['baseline_metrics']['resource_wait_seconds'], 999.)
        self.assertNotIn('finish_steps', actual['runtime_metrics'])
        self.assertNotIn('delta_vs_pre_ppo', actual['runtime_metrics'])
        self.assertEqual(actual['comparison_metrics']['makespan_delta_vs_manifest_baseline'], -10.)
        current['case_sha256'] = 'different'
        with self.assertRaises(ValueError):
            clean_cases([current], [old])

    def test_uniform_cases_not_event_count_and_reproducible_time_sampling(self):
        pool = dict(case_indices=torch.tensor([0] + [1] * 100 + [2] * 10))
        a = balanced_indices(pool, 48, np.random.default_rng(1))
        b = balanced_indices(pool, 48, np.random.default_rng(1))
        self.assertEqual(a, b)
        self.assertEqual(torch.bincount(pool['case_indices'][a]).tolist(), [16, 16, 16])
        indices = balanced_indices(pool, 48, np.random.default_rng(2), [0, 2])
        self.assertNotIn(1, pool['case_indices'][indices].tolist())

    def test_disk_style_restore_no_adam_alias_and_no_encoder_merging(self):
        first = tiny()
        sum(p.sum() for p in first.actor_params).backward()
        first.actor_optim.step()
        first.actor_optim.zero_grad(set_to_none=True)
        first.actor_steps = 1
        source = training_state(first)
        second, third = tiny(), tiny()
        restore_training_state(second, source)
        restore_training_state(third, source)
        assert_tree_equal(source, training_state(second))
        p, q = second.actor_params[0], third.actor_params[0]
        self.assertNotEqual(second.actor_optim.state[p]['step'].data_ptr(), third.actor_optim.state[q]['step'].data_ptr())
        p.sum().backward()
        second.actor_optim.step()
        self.assertEqual(float(third.actor_optim.state[q]['step']), 1.)
        self.assertEqual(float(source['actor_optim']['state'][0]['step']), 1.)
        with self.assertRaises(ValueError):
            restore_training_state(tiny('E0'), source)

    def test_budget_includes_warmup_serial_eval_and_headroom(self):
        reports = {a: dict(collection_seconds=100, update_seconds=200, critic_50_steps_seconds=10) for a in ARMS}
        result = budget_projection(reports, 20000, 2.)
        self.assertEqual(result['training_two_slot_seconds'], 6120.)
        self.assertEqual(result['serialized_evaluation_seconds'], 1440.)
        self.assertEqual(result['projected_seconds'], 9450.)
        self.assertTrue(result['passed'])
        self.assertFalse(budget_projection(reports, 9000, 2.)['passed'])

    def test_controller_status_override_and_total_case_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            controller = Controller.__new__(Controller)
            controller.root, controller.phase = Path(tmp), 'test'
            controller.started, controller.deadline = 0., 86400.
            controller.jobs, controller.records = {}, []
            controller.status(status='budget_blocked')
            status = json.loads((Path(tmp) / 'run_status.json').read_text())
            self.assertEqual(status['status'], 'budget_blocked')
        self.assertEqual(4 * 24 + 5 * 60 + 240 + 4 * 240 + 4 * 3 * 60, 2316)
        self.assertEqual(DEFAULTS['rounds'], 10)
        self.assertEqual(DEFAULTS['evaluation_rounds'], [5, 10])

    def test_real_b0_versioned_checkpoint_and_strict_lineage(self):
        from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
        from onpolicy.scripts.train.prepare_stage2_resource_rl_v5 import PARENT
        from onpolicy.scripts.train.run_stage2_resource_rl import arguments
        from onpolicy.scripts.train.run_stage2_resource_rl_v5 import SplitSuite
        from onpolicy.utils.stage2_bc_contract import ready_head_config
        from onpolicy.utils.stage2_resource_rl_v5_handoff import validate_split_handoff
        manifest = json.loads((PARENT / 'manifest.json').read_text())
        manifest['training_contract'] = dict(DEFAULTS)
        payload = torch.load(manifest['source']['path'], map_location='cpu', weights_only=True)
        args = arguments(manifest)
        for key, value in ready_head_config(payload).items():
            setattr(args, key, value)
        for arm in ARMS:
            with tempfile.TemporaryDirectory() as tmp:
                policy = GNN_MAPPOPolicy(args, yaml.safe_load(Path(args.ac_config).read_text()))
                policy.load_model_state(payload['model'])
                policy.ac.device_global_matching = False
                policy.capture_bc_reference(payload['model'])
                learner = SplitEncoderLearner(policy, args, dict(DEFAULTS), lambda *a, **k: None, arm=arm)
                suite = SplitSuite.__new__(SplitSuite)
                suite.phase, suite.payload, suite.m, suite.c = 'engineering', payload, manifest, dict(DEFAULTS)
                suite.completed_rounds = suite.case_episodes = 0
                suite.path, suite.worker_root = PARENT / 'manifest.json', Path(tmp)
                saved_path = suite.checkpoint(learner, 'initial.pt')
                saved = torch.load(saved_path, map_location='cpu', weights_only=True)
                self.assertTrue(validate_split_handoff(saved, policy.ac, require_completed=False)['passed'])
                with self.assertRaises(ValueError):
                    validate_split_handoff(saved, policy.ac, require_completed=True)
                saved['model']['encoder.' + next(iter(policy.ac.encoder.state_dict()))].flatten()[0] += 1
                with self.assertRaises(ValueError):
                    validate_split_handoff(saved, policy.ac, require_completed=False)

    def test_real_graph_zero_equality_resource_grad_and_frozen_cache_isolation(self):
        env = _make_env()
        try:
            policy = _make_policy()
            policy.ac.request_ready_policy_injection = 'none'
            policy.capture_bc_reference()
            args = SimpleNamespace(max_agent_num=24, max_device_num=80, recurrent_N=1, hidden_size=64)
            learner = SplitEncoderLearner(policy, args, dict(DEFAULTS), lambda *a, **k: None, arm='E3')
            obs, _, info = env.reset()
            hidden = learner._hidden(1)
            previous = np.full((1, 104, 2), -1, np.int64)
            found = False
            for _ in range(24):
                active = np.asarray(info['active_agents'])[None, :, None]
                types = np.asarray(info['agent_types'])[None]
                data, meta = policy._build_inputs(Batch.from_data_list([obs]), hidden, active,
                                                  previous[..., 0], previous[..., 1], agent_types=types)
                with torch.no_grad():
                    original, frozen = prepared_forward(policy, data, meta, hidden, deterministic=True, reference=True)
                    copied, _ = prepared_forward(policy, data, meta, hidden, deterministic=True, encoded=frozen)
                assert_tree_equal(original, copied, 'copied real-graph policy')
                mask = resource_mask(copied['decision_mask'], 24)
                if mask.any():
                    found = True
                    learner_mode(policy.ac)
                    output, _ = prepared_forward(policy, data, meta, hidden, actions=copied['actions'], encoded=frozen)
                    loss = -(output['log_probs'] * mask).sum()
                    loss.backward()
                    self.assertTrue(any(p.grad is not None and p.grad.abs().max() > 0 for p in policy.ac.resource_encoder.parameters()))
                    self.assertTrue(all(p.grad is None for p in learner.critic_params))
                    protected = protected_summary(policy.ac)
                    learner.actor_optim.step()
                    learner.actor_optim.zero_grad(set_to_none=True)
                    policy.ac.eval()
                    with torch.no_grad():
                        changed, _ = prepared_forward(policy, data, meta, hidden, actions=copied['actions'], encoded=frozen)
                        ref_after, _ = prepared_forward(policy, data, meta, hidden, deterministic=True, reference=True, encoded=frozen)
                    assert_tree_equal(original, ref_after, 'B0 reference after resource update')
                    self.assertFalse(torch.equal(changed['log_probs'][mask], copied['log_probs'][mask]))
                    self.assertTrue(torch.equal(changed['rnn_states'][:, :24], copied['rnn_states'][:, :24]))
                    self.assertEqual(protected, protected_summary(policy.ac))
                    # Critic training recomputes graph features and must not touch the actor.
                    before = summary(policy.ac, ACTOR)
                    learner._value_pool = dict(graphs=[obs], embeddings=frozen['global_emb'].cpu(),
                                               targets=torch.tensor([-1.]), case_indices=torch.tensor([0]))
                    learner.critic_update(None, None, 1)
                    self.assertEqual(summary(policy.ac, ACTOR), before)
                    self.assertEqual(learner.critic_steps, 1)
                    self.assertEqual(learner.gradient_checks['value_encoder_nonzero'], 1)
                    break
                previous = copied['actions'].numpy()
                hidden = copied['rnn_states']
                obs, _, _, info = env.step(previous[0])
            self.assertTrue(found, 'Test must execute a non-forced resource decision.')
        finally:
            env.close()


if __name__ == '__main__':
    torch.set_num_threads(1)
    unittest.main()
