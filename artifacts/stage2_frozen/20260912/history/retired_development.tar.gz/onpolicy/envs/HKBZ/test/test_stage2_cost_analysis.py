"""Audit integration regressions; legacy run artifacts are read-only fixtures."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from onpolicy.scripts.train.analyze_stage2_cost_accelerated import analyze
from onpolicy.scripts.train.prepare_stage2_bc_injection import code_fingerprint
from onpolicy.utils.stage2_blocking_audit import BLOCKING_COVERAGE_CONTRACT


ROOT = Path(__file__).resolve().parents[4]
HISTORICAL = ROOT / 'result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r2_bc_canary/manifest.json'


class CostAnalysisTest(unittest.TestCase):
    def test_cost_failure_does_not_publish_intermediate_success(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            manifest = dict(research_family='stage2_cost_accelerated', execution_stage='bc_canary',
                commands={key: {'cost_improvement': False}
                          for key in ('N0_BC_teacher_seed11', 'N1_BC_dagger_seed11')})
            path = root / 'manifest.json'
            path.write_text(json.dumps(manifest))
            partial = dict(complete=True, methods={
                'N0_BC_teacher_seed11': dict(run_dir=str(root / 'missing-run'))})
            with patch('onpolicy.scripts.train.analyze_stage2_cost_accelerated.base_analyze',
                       return_value=partial) as base:
                with self.assertRaises(FileNotFoundError):
                    analyze(path)
                base.assert_called_once_with(path, canary_gate=False, publish=False)
            self.assertFalse((root / 'analysis/comparison.json').exists())

    @unittest.skipUnless(HISTORICAL.is_file(), 'Local r2 canary artifacts are optional integration fixtures.')
    def test_completed_r2_data_passes_repaired_audit_without_overwriting_history(self):
        original = HISTORICAL.read_bytes()
        manifest = json.loads(original)
        observed_paths = [HISTORICAL, HISTORICAL.parent / 'analysis/comparison.json']
        for entry in manifest['commands'].values():
            run = ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo' / entry['experiment_name'] / 'run1'
            observed_paths.extend(path for path in run.rglob('*') if path.is_file())
        before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in observed_paths}
        # An isolated ANALYZER TEST, not a rewritten run manifest or a new
        # production proof. Only its temporary report is published, then removed.
        manifest = copy.deepcopy(manifest)
        fingerprints = code_fingerprint()
        for relative in manifest['code_fingerprint']:
            fingerprints[relative] = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
        manifest['code_fingerprint'] = fingerprints
        manifest['analysis_contract']['blocking_repair_coverage'] = BLOCKING_COVERAGE_CONTRACT
        with tempfile.TemporaryDirectory(prefix='stage2-audit-regression-') as root:
            path = Path(root) / 'manifest.json'
            path.write_text(json.dumps(manifest))
            report = analyze(path)
            self.assertTrue(report['canary_contract_passed'])
            self.assertTrue(report['cost_integrity_passed'])
            self.assertFalse(report['scientific_result'])
            self.assertFalse(report['four_arm_comparison_complete'])
            self.assertEqual(report['total_candidate_continuations'], 0)
            rows = report['blocking_repair_coverage']['per_arm_epoch_counts']['N1_BC_dagger_seed11']
            self.assertEqual([row['events'] for row in rows], [0, 0])
            self.assertEqual([row['checked'] for row in rows], [979, 931])
            self.assertTrue((Path(root) / 'analysis/comparison.json').is_file())
            # Unavailable four-case composite metrics must not break strict
            # JSON after the scientific/model-finiteness checks have passed.
            json.dumps(report, allow_nan=False)
        after = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in observed_paths}
        self.assertEqual(before, after)


if __name__ == '__main__':
    unittest.main()
