"""Weights-only forks, immutable ready provenance, replay, and honest selection."""

import copy
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np
import torch

from onpolicy.config.config import get_config
from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.analyze_stage2_bc_injection import paired_comparison
from onpolicy.scripts.train.prepare_stage2_policy_transfer import prepare, PARENT
from onpolicy.utils.stage2_bc_contract import ready_head_config
from onpolicy.utils.stage2_policy_transfer import (
    validate_policy_warmstart, verified_frozen_ready_source, warmstart_replay,
    selection_with_fallback, validate_ready_target_collection,
)
from onpolicy.utils.training_stage import (
    STAGE2_SUPERVISION_CONTRACT, protected_parameter_summary,
    validate_stage2_joint_finetune_checkpoint,
)


class PolicyTransferTest(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.teacher = self.directory / 'teacher.json'
        self.teacher.write_text('{}')
        self.model = {'encoder.weight': torch.ones(2, 2), 'actor.weight': torch.ones(2, 2),
                      'device_critic.weight': torch.ones(2, 2), 'device_actor.weight': torch.ones(2, 2),
                      'request_ready_head.weight': torch.ones(1, 2),
                      'request_ready_feature.weight': torch.zeros(2, 2)}
        self.common = {
            'source_m2_sha256': 'a' * 64, 'resource_lookahead_contract': {'H': 2, 'F': 4},
            'request_ready_time_scale': 3600., 'resource_iga_teacher_index': str(self.teacher),
            **ready_head_config({}),
        }
        ready = {**self.common, 'model': self.model, 'stage2_training_mode': 'ready_predictor_only'}
        before_model = copy.deepcopy(self.model)
        before_model['request_ready_head.weight'].zero_()
        ready.update(request_ready_total_labels=100,
            request_ready_predictor_summary_before=protected_parameter_summary(
                before_model, prefixes=('request_ready_head.', 'request_ready_feature.')),
            request_ready_predictor_summary_after=protected_parameter_summary(
                self.model, prefixes=('request_ready_head.', 'request_ready_feature.')))
        for prefix in ('protected_parameter_summary', 'resource_actor_summary'):
            ready[prefix + '_before_bc'] = {'sha256': 'frozen'}
            ready[prefix + '_after_bc'] = {'sha256': 'frozen'}
        self.ready_path = self.directory / 'ready.pt'
        torch.save(ready, self.ready_path)
        self.ready_sha = hashlib.sha256(self.ready_path.read_bytes()).hexdigest()
        self.checkpoint = {
            **self.common, 'training_stage': 'resource_joint', 'stage2_training_mode': 'supervised_only',
            'device_bc_training_scope': 'policy_frozen_ready',
            'stage2_supervision_contract': STAGE2_SUPERVISION_CONTRACT,
            'stage2_scientific_gate': {'passed': True}, 'selected_bc_epoch': 1,
            'request_ready_policy_injection': 'none', 'device_global_matching': True,
            'model': copy.deepcopy(self.model),
            'frozen_ready_source': {'path': str(self.ready_path), 'sha256': self.ready_sha,
                                    'teacher_index_sha256': hashlib.sha256(self.teacher.read_bytes()).hexdigest()},
            'frozen_ready_head_summary': protected_parameter_summary(self.model, prefixes=('request_ready_head.',)),
        }

    def validate(self, checkpoint=None, current=None, **changes):
        args = dict(source_sha256='a' * 64, ready_sha256=self.ready_sha,
                    planning_contract={'H': 2, 'F': 4}, injection='none',
                    head_config=ready_head_config({}), teacher_index=self.teacher)
        args.update(changes)
        return validate_policy_warmstart(checkpoint or self.checkpoint, current or self.model, **args)

    def test_exact_policy_source_is_accepted_without_optimizer_or_rng_loading(self):
        self.checkpoint['supervised_optimizer'] = {'state': {'not_restored': 1}}
        self.checkpoint['stage2_bc_state'] = {'completed_epochs': 1, 'rng': 'not_restored'}
        before = torch.get_rng_state().clone()
        self.assertIn('sha256', self.validate())
        self.assertTrue(torch.equal(before, torch.get_rng_state()))
        self.assertEqual(self.checkpoint['stage2_bc_state']['completed_epochs'], 1)

    def test_resource_weights_may_differ_but_all_frozen_tensors_must_match(self):
        self.checkpoint['model']['device_actor.weight'].add_(1)
        self.validate()
        for name in ('encoder.weight', 'actor.weight', 'device_critic.weight', 'request_ready_head.weight'):
            bad = copy.deepcopy(self.checkpoint)
            bad['model'][name].add_(1)
            with self.assertRaisesRegex(ValueError, 'frozen tensor'):
                self.validate(bad)

    def test_wrong_source_and_decoder_modes_are_rejected(self):
        for key, value in [('source_m2_sha256', 'b' * 64), ('selected_bc_epoch', None),
                           ('stage2_scientific_gate', {'passed': False}), ('request_ready_policy_injection', 'learned'),
                           ('device_global_matching', False), ('device_bc_training_scope', 'policy_and_ready')]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.validate({**self.checkpoint, key: value})
        with self.assertRaisesRegex(ValueError, 'planning'):
            self.validate(planning_contract={'H': 3})

    def test_nonfinite_and_missing_tensors_fail(self):
        bad = copy.deepcopy(self.checkpoint)
        bad['model']['device_actor.weight'][0, 0] = float('nan')
        with self.assertRaises(ValueError):
            self.validate(bad)
        del bad['model']['device_actor.weight']
        with self.assertRaises(ValueError):
            self.validate(bad)

    def test_actual_predictor_source_and_teacher_digests_are_required(self):
        self.assertTrue(verified_frozen_ready_source(self.checkpoint)['verified'])
        self.teacher.write_text('{"changed":true}')
        with self.assertRaisesRegex(ValueError, 'teacher index digest'):
            verified_frozen_ready_source(self.checkpoint)

    def test_changed_head_cannot_be_blessed_by_changing_only_recorded_summary(self):
        bad = copy.deepcopy(self.checkpoint)
        bad['model']['request_ready_head.weight'].add_(1)
        bad['frozen_ready_head_summary'] = protected_parameter_summary(bad['model'], prefixes=('request_ready_head.',))
        with self.assertRaisesRegex(ValueError, 'changed predictor tensor'):
            verified_frozen_ready_source(bad)

    def test_projection_change_alone_is_not_predictor_training_evidence(self):
        ready = torch.load(self.ready_path, map_location='cpu', weights_only=True)
        ready['request_ready_predictor_summary_before']['groups']['request_ready_head'] = (
            ready['request_ready_predictor_summary_after']['groups']['request_ready_head'])
        torch.save(ready, self.ready_path)
        bad = copy.deepcopy(self.checkpoint)
        bad['frozen_ready_source']['sha256'] = hashlib.sha256(self.ready_path.read_bytes()).hexdigest()
        with self.assertRaisesRegex(ValueError, 'training evidence'):
            verified_frozen_ready_source(bad)

    def test_replay_uses_zero_tolerance_and_hash_paired_complete_cases(self):
        rows = [{'case_sha256': 'a', 'makespan': 10., 'completed': True},
                {'case_sha256': 'b', 'makespan': 20., 'completed': True}]
        path = self.directory / 'eval.json'
        path.write_text(json.dumps({'cases': rows}))
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        self.assertTrue(warmstart_replay(path, sha, list(reversed(rows)))['passed'])
        changed = [rows[0], {**rows[1], 'makespan': 20.000000000001}]
        self.assertFalse(warmstart_replay(path, sha, changed)['passed'])
        with self.assertRaises(ValueError):
            warmstart_replay(path, sha, [rows[0], {**rows[1], 'completed': False}])
        with self.assertRaises(ValueError):
            warmstart_replay(path, 'b' * 64, rows)

    def test_all_worse_or_ineligible_epochs_keep_the_source_in_analysis(self):
        baseline = {'eval_raw_makespan': 8000.}
        records = [{'epoch': 1, 'metrics': {'eval_raw_makespan': 8100.}, 'gate': {'passed': True}},
                   {'epoch': 2, 'metrics': {'eval_raw_makespan': 7900.}, 'gate': {'passed': False}}]
        self.assertTrue(selection_with_fallback(records, baseline)['retained_source'])
        records[1]['gate']['passed'] = True
        self.assertEqual(selection_with_fallback(records, baseline)['epoch'], 2)
        with self.assertRaises(ValueError):
            selection_with_fallback([], {'eval_raw_makespan': float('nan')})

    def test_stage3_accepts_verified_frozen_head_without_projection_updates(self):
        checkpoint = {**self.checkpoint, 'phase': 'resource_supervised_completed',
            'source_m2_path': '/tmp/source.pt', 'request_ready_prediction': True,
            'plane_order_mode': 'fixed', 'plane_pair_decoder': 'joint_pair',
            'global_feature_mode': 'f1f2', 'resource_bc_total_labels': 100,
            'resource_dense_ranking_total_labels': 80, 'request_ready_total_labels': 0,
            'resource_actor_summary_before_bc': {'sha256': 'before'},
            'resource_actor_summary_after_bc': {'sha256': 'after'},
            'request_ready_predictor_summary_before': {'sha256': 'unchanged'},
            'request_ready_predictor_summary_after': {'sha256': 'unchanged'}}
        arguments = dict(plane_order_mode='fixed', plane_pair_decoder='joint_pair',
                         global_feature_mode='f1f2', planning_contract={'H': 2, 'F': 4},
                         request_ready_time_scale=3600.)
        result = validate_stage2_joint_finetune_checkpoint(checkpoint, self.model, **arguments)
        self.assertTrue(result['frozen_ready_source_verified']['verified'])
        self.assertFalse(result['request_ready_predictor_updated'])
        checkpoint['frozen_ready_source'] = {**checkpoint['frozen_ready_source'], 'sha256': 'b' * 64}
        with self.assertRaisesRegex(ValueError, 'source digest'):
            validate_stage2_joint_finetune_checkpoint(checkpoint, self.model, **arguments)

    def test_win_ties_do_not_change_effect_estimates(self):
        result = paired_comparison({'a': 10.-1e-12, 'b': 18.}, {'a': 10., 'b': 20.})
        self.assertEqual((result['left_wins'], result['ties'], result['right_wins']), (1, 1, 0))
        self.assertAlmostEqual(result['mean_delta_seconds'], -1.)

    def test_schedule_and_source_bind_the_new_resume_contract(self):
        args = get_config().parse_args(['--stage2_policy_warmstart_checkpoint', '/tmp/policy.pt',
                                        '--stage2_policy_warmstart_sha256', 'a' * 64])
        runner = object.__new__(HKBZ_Runner)
        runner.all_args = args
        runner.policy = SimpleNamespace(ac=SimpleNamespace())
        first = runner._stage2_bc_run_contract()
        args.device_bc_dagger_schedule = '0.75,0.5'
        self.assertNotEqual(first, runner._stage2_bc_run_contract())
        self.assertEqual(get_config().parse_args([]).stage2_policy_warmstart_checkpoint, '')

    def test_joint_action_mixing_never_splices_individual_resource_actions(self):
        runner = object.__new__(HKBZ_Runner)
        runner.policy = SimpleNamespace(ac=SimpleNamespace(max_plane_agents=1))
        runner.num_agents = 3
        actions = np.zeros((2, 3, 2), dtype=np.int64)
        labels = [{'actions': np.full((3, 2), 2, dtype=np.int64), 'info': {}} for _ in range(2)]
        mixed, _, stats = runner._merge_device_bc_actions(actions, labels,
            teacher_execution_mask=[True, False], active_env_mask=[True, True])
        self.assertTrue(np.array_equal(mixed[0, 1:], labels[0]['actions'][1:]))
        self.assertTrue(np.array_equal(mixed[1], actions[1]))
        self.assertEqual((stats['teacher_executed_envs'], stats['student_executed_envs']), (1, 1))

    def test_prepare_canary_never_opens_blind_or_claims_scientific_success(self):
        if not (PARENT / 'analysis/comparison.json').is_file():
            self.skipTest('Local parent pilot not available')
        manifest = prepare(SimpleNamespace(suite_dir=self.directory / 'suite', parent_suite=PARENT,
            run_tag='stage2_transfer_unit_fixture', profile='canary', python=Path('/usr/bin/python3')))
        self.assertEqual(len(manifest['commands']), 4)
        self.assertEqual(manifest['resource_contract']['max_concurrent_trainers'], 3)
        self.assertFalse(manifest['scientific_result'])
        self.assertFalse(manifest['evaluation_contract']['finalblind_access'])
        self.assertFalse(manifest['evaluation_contract']['gate_access'])
        for entry in manifest['commands'].values():
            argv = entry['argv']
            self.assertIn('--stage2_policy_warmstart_checkpoint', argv)
            self.assertNotIn('--resume_stage2', argv)
            self.assertEqual(argv[argv.index('--device_bc_lr') + 1], '1e-05')
            self.assertIn('--device_bc_skip_ready_targets', argv)
            self.assertEqual(argv[argv.index('--request_ready_min_labels_per_epoch') + 1], '0')

    def test_dagger_requires_explicitly_disabled_factual_ready_labels(self):
        args = dict(skip=True, stage='resource_joint', scope='policy_frozen_ready',
                    ready_loss=0., minimum_labels=0, teacher='iga', teacher_rates=[.75, .5])
        validate_ready_target_collection(**args)
        for changes in ({'skip': False}, {'scope': 'ready_only'}, {'ready_loss': 1.},
                        {'minimum_labels': 64}, {'teacher': 'heuristic'}, {'stage': 'joint_finetune'}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                validate_ready_target_collection(**{**args, **changes})
        validate_ready_target_collection(**{**args, 'skip': False, 'teacher_rates': [1., 1.],
                                           'scope': 'policy_and_ready', 'ready_loss': 1., 'minimum_labels': 64})

    def test_student_state_teacher_never_queries_factual_timestamps(self):
        env = object.__new__(AircraftScheduleEnv)
        env.n_agents = 3
        env._load_resource_iga_teacher = Mock(return_value={
            'backends': {}, 'decoded': {}, 'path': 'fixture', 'teacher_sha256': 'fixture', 'teacher_cmax': 1.})
        env._request_ready_supervision_targets = Mock(side_effect=ValueError('off-trajectory timestamp'))
        with patch('onpolicy.envs.HKBZ.environment.mixed_resource_actions',
                   return_value=(np.zeros((3, 2), dtype=np.int64), [])):
            result = env.resource_iga_teacher_actions(return_info=True, include_ready_targets=False)
            self.assertTrue(result['info']['available'])
            self.assertEqual(result['info']['request_ready_targets'], [])
            env._request_ready_supervision_targets.assert_not_called()
            with self.assertRaisesRegex(ValueError, 'off-trajectory'):
                env.resource_iga_teacher_actions(return_info=True)


if __name__ == '__main__':
    unittest.main()
