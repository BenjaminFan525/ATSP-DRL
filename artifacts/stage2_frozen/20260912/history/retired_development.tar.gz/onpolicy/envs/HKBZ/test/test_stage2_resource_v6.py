"""V6 semantic identity, opt-in isolation, scoring and protocol regressions."""
import copy
from pathlib import Path
from types import SimpleNamespace
import unittest

import numpy as np
import torch
from torch_geometric.data import Batch

from onpolicy.algorithms.utils.resource_actor_v6 import (
    install_resource_v6, masked_pool, pair_inputs, resource_context,
)
from onpolicy.envs.HKBZ.test.test_joint_training import _make_env, _make_policy
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.utils.stage2_resource_rl import forward, resource_mask, summary
from onpolicy.utils.stage2_resource_v6 import DEFAULTS, V6Learner, actor_prefixes, semantic_labels
from onpolicy.utils.stage2_resource_v6_observation import HISTORY_DIM, PAIR_DIM, REQUEST_DIM, capture_dispatches


def fixture():
    env = _make_env()
    env.config['stage2_resource_v6_observations'] = True
    obs, _, info = env.reset()
    policy = _make_policy()
    policy.ac.request_ready_policy_injection = 'none'
    policy.ac.device_global_matching = False
    policy.ac.tau = .3
    policy.ac.eval()
    hidden = np.zeros((1, 104, 1, 64), np.float32)
    previous = np.full((1, 104, 2), -1, np.int64)
    for _ in range(100):
        active = np.asarray(info['active_agents']).reshape(1, 104, 1)
        types = np.asarray(info['agent_types']).reshape(1, 104)
        batch_info = {k: np.asarray(info[k])[None] for k in ('last_op_indices', 'last_site_indices')}
        history = HKBZ_Runner._authoritative_policy_history(batch_info, previous, 24)
        with torch.no_grad():
            out, enc = forward(policy, [obs], hidden, active, history, types, deterministic=True)
        if resource_mask(out['decision_mask'], 24).any():
            return env, policy, obs, info, hidden, history, types, active
        actions = out['actions'].numpy()
        obs, _, done, info = env.step(actions[0])
        hidden, previous = out['rnn_states'].numpy(), actions
        hidden[:, np.asarray(done)] = 0
    env.close()
    raise AssertionError('Fixture did not reach a free device decision.')


class V6Tests(unittest.TestCase):
    def test_opt_in_metadata_never_changes_legacy_tensors(self):
        env = _make_env()
        try:
            old, _, _ = env.reset()
            env.config['stage2_resource_v6_observations'] = True
            new = env._get_obs()
            for store, values in old.to_dict().items():
                for name, tensor in values.items():
                    if torch.is_tensor(tensor):
                        self.assertTrue(torch.equal(tensor, new.to_dict()[store][name]), (store, name))
            batch = Batch.from_data_list([new, new.clone()])
            self.assertEqual(batch.v6_requests.shape, (2, env.max_request_num, REQUEST_DIM))
            self.assertEqual(batch.v6_history.shape, (2, 80, HISTORY_DIM))
        finally:
            env.close()

    def test_masked_pool_excludes_padding_and_handles_empty(self):
        x = torch.tensor([[[2., 3.], [100., 200.], [4., 1.]]])
        self.assertTrue(torch.equal(masked_pool(x, torch.tensor([[True, False, True]])),
                                    torch.tensor([[3., 2., 4., 3.]])))
        self.assertTrue(torch.equal(masked_pool(x, torch.zeros((1, 3), dtype=torch.bool)), torch.zeros((1, 4))))

    def test_history_survives_request_removal_noop_and_reset(self):
        env = _make_env()
        try:
            env.config['stage2_resource_v6_observations'] = True
            env.reset()
            device = env.device_list[0]
            raw = np.arange(REQUEST_DIM, dtype=np.float32) / 100.
            env._v6_dispatch_history[device.code] = dict(features=raw.copy(),
                identity=('already_removed_plane', 'old_job', 'old_site'),
                time=env.total_time, case=str(env.current_case_path))
            env._execute_device_action_plan([])
            graph = env._get_obs()
            np.testing.assert_array_equal(graph.v6_history[0, 0, :REQUEST_DIM], raw)
            self.assertEqual(float(graph.v6_history[0, 0, -2]), 1.)
            env.reset()
            self.assertFalse(env._v6_dispatch_history)
            self.assertEqual(float(env._get_obs().v6_history.abs().sum()), 0.)
        finally:
            env.close()

    def test_capture_is_pre_mutation_copy_and_missing_identity_fails(self):
        raw = np.arange(REQUEST_DIM, dtype=np.float32)
        env = SimpleNamespace(config={'stage2_resource_v6_observations': True},
            _v6_request_snapshots={('p', 'j', 's'): raw}, total_time=123., current_case_path='case',
            _request_identity=lambda request: request['identity'])
        dev = SimpleNamespace(code='device')
        snap = capture_dispatches(env, [(dev, {'identity': ('p', 'j', 's')}, 3)])
        raw[0] = 999.
        self.assertEqual(snap['device']['features'][0], 0.)
        with self.assertRaises(RuntimeError):
            capture_dispatches(env, [(dev, {'identity': ('other', 'j', 's')}, 3)])

    def test_history_cross_case_is_rejected(self):
        env = _make_env()
        try:
            env.config['stage2_resource_v6_observations'] = True
            env.reset()
            env._v6_dispatch_history[env.device_list[0].code] = dict(
                case='wrong_case', features=np.zeros(REQUEST_DIM), time=0.)
            with self.assertRaisesRegex(RuntimeError, 'across cases'):
                env._get_obs()
        finally:
            env.close()

    def test_roles_plane_isolation_history_alias_and_probability_replay(self):
        env, base, obs, info, hidden, history, types, active = fixture()
        try:
            with torch.no_grad():
                legacy, encoded = forward(base, [obs], hidden, active, history, types, deterministic=True)
            for arm in ('S1', 'S2'):
                policy = copy.deepcopy(base)
                install_resource_v6(policy.ac, arm)
                learner = V6Learner(policy, SimpleNamespace(max_agent_num=24, max_device_num=80,
                    recurrent_N=1, hidden_size=64), dict(DEFAULTS), lambda *a, **k: None, arm)
                with torch.no_grad():
                    out, _ = forward(policy, [obs], hidden, active, history, types, deterministic=True, encoded=encoded)
                    replay, _ = forward(policy, [obs], hidden, active, history, types,
                        actions=out['actions'], encoded=encoded)
                    altered = history.copy()
                    altered[:, 24:, 0] = obs.v6_requests.shape[1] - 1
                    other, _ = forward(policy, [obs], hidden, active, altered, types, deterministic=True, encoded=encoded)
                self.assertTrue(torch.equal(out['actions'][:, :24], legacy['actions'][:, :24]))
                self.assertTrue(torch.equal(out['log_probs'][:, :24], legacy['log_probs'][:, :24]))
                self.assertTrue(torch.equal(out['rnn_states'][:, :24], legacy['rnn_states'][:, :24]))
                self.assertLessEqual(float((out['log_probs'] - replay['log_probs']).abs().max()), 1e-6)
                self.assertTrue(torch.equal(out['log_probs'][:, 24:], other['log_probs'][:, 24:]))
                self.assertTrue(torch.equal(out['rnn_states'][:, 24:], other['rnn_states'][:, 24:]))
                if arm == 'S2':
                    np.testing.assert_array_equal(out['rnn_states'][:, 24:], hidden[:, 24:])
                self.assertTrue(all(p.requires_grad == n.startswith(actor_prefixes(arm))
                                    for n, p in policy.ac.named_parameters()))
                learner.assert_protected()
        finally:
            env.close()

    def test_pair_features_padding_and_gradient_ownership(self):
        env, policy, obs, info, hidden, history, types, active = fixture()
        try:
            install_resource_v6(policy.ac, 'S2')
            learner = V6Learner(policy, SimpleNamespace(max_agent_num=24, max_device_num=80,
                recurrent_N=1, hidden_size=64), dict(DEFAULTS), lambda *a, **k: None, 'S2')
            graph = Batch.from_data_list([obs])
            context = resource_context(graph)
            original = context['global_values'].clone()
            pad = (graph.v6_requests[..., 0] == 0) & (graph.v6_requests[..., 1] == 0)
            graph.v6_requests[..., 2:][pad] = 1234.
            self.assertTrue(torch.equal(original, resource_context(graph)['global_values']))
            with torch.no_grad():
                out, _ = forward(policy, [obs], hidden, active, history, types, deterministic=True)
            rows, agents = resource_mask(out['decision_mask'], 24).nonzero(as_tuple=True)
            agent = int(agents[0])
            legal = torch.isfinite(out['resource_logits'][:, agent])
            features = pair_inputs(context, torch.tensor([0]), agent - 24, legal)
            self.assertEqual(features.shape[-1], PAIR_DIM)
            role = 'transporter' if int(types[0, agent]) == 2 else 'ordinary'
            dist = policy.ac.resource_v6.distribution(features, legal, role, .3)
            selected = out['actions'][0, agent, 0]
            (-dist[0, selected]).backward()
            self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in learner.actor_params))
            self.assertTrue(all(p.grad is None for n, p in policy.ac.named_parameters() if not n.startswith('resource_v6.')))
            learner.assert_protected()
        finally:
            env.close()

    def test_preregistered_budget_and_no_automatic_promotion(self):
        self.assertEqual(4 * 4 + 12 + 48 + 2 * 12 * 4, 172)
        self.assertEqual(48 // 6 * DEFAULTS['bc_epochs'], 80)
        root = Path(__file__).resolve().parents[4]
        launcher = (root / 'onpolicy/scripts/train/launch_stage2_resource_v6_gpu0.sh').read_text()
        self.assertIn('CUDA_VISIBLE_DEVICES=0', launcher)
        self.assertIn('AllowedCPUs=0-31,64-95', launcher)
        self.assertIn('Restart=no', launcher)
        self.assertIn('RuntimeMaxSec=infinity', launcher)

    def test_live_teacher_identity_must_match_observation(self):
        graph = SimpleNamespace(v6_request_keys=torch.tensor([[[-1, -1, -1], [2, 3, 4]]]))
        decision = dict(agent_id=24, role='ordinary', selected_request_id=1,
            legal_request_ids=[1], allow_noop=False, selected_request_semantic_key=[2, 3, 4])
        label = dict(info=dict(decisions=[decision]))
        self.assertEqual(semantic_labels([graph], [label], 24)[0]['decisions'][0]['identity'], [2, 3, 4])
        decision['selected_request_semantic_key'] = [8, 3, 4]
        with self.assertRaisesRegex(RuntimeError, 'identity differs'):
            semantic_labels([graph], [label], 24)

    def test_packed_stateless_probabilities_match_production(self):
        env, policy, obs, info, hidden, history, types, active = fixture()
        try:
            install_resource_v6(policy.ac, 'S2')
            learner = V6Learner(policy, SimpleNamespace(max_agent_num=24, max_device_num=80,
                recurrent_N=1, hidden_size=64), dict(DEFAULTS), lambda *a, **k: None, 'S2')
            with torch.no_grad():
                out, _ = forward(policy, [obs], hidden, active, history, types, deterministic=True)
            mask = resource_mask(out['decision_mask'], 24)
            rollout = dict(cases=[{}], teacher_execution=True, frames=[dict(obs=[obs], types=types,
                actions=out['actions'].numpy(), mask=mask, legal=torch.isfinite(out['resource_logits']))])
            packed = learner.pack_stateless(rollout)
            for ri, role in enumerate(('ordinary', 'transporter')):
                if role not in packed['stateless_records']:
                    continue
                record = packed['stateless_records'][role]
                with torch.no_grad():
                    dist = policy.ac.resource_v6.distribution(record['features'], record['legal'], role, .3)
                rows, agents = (mask & (torch.as_tensor(types) == ri + 1)).nonzero(as_tuple=True)
                expected = out['resource_logits'][rows, agents]
                self.assertTrue(torch.equal(torch.isfinite(expected), torch.isfinite(dist)))
                finite = torch.isfinite(dist)
                self.assertLessEqual(float((expected[finite] - dist[finite]).abs().max()), 1e-6)
            self.assertAlmostEqual(packed['case_role_weight_mass'], 1., places=6)
            features = torch.randn(2, 3, PAIR_DIM)
            legal = torch.tensor([[True, True, False], [True, False, True]])
            for role in ('ordinary', 'transporter'):
                policy.ac.zero_grad(set_to_none=True)
                (-policy.ac.resource_v6.distribution(features, legal, role, .3)[:, 0].mean()).backward()
                self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0
                    for p in policy.ac.resource_v6.heads[role].parameters()))
        finally:
            env.close()


if __name__ == '__main__':
    torch.set_num_threads(1)
    unittest.main()
