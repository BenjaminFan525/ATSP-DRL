"""V4 budget, recurrent replay, baseline, and selection regressions."""
import copy
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch

from onpolicy.envs.HKBZ.test.test_stage2_resource_rl import TinyModel
from onpolicy.scripts.train.prepare_stage2_resource_rl_v4 import (
    align_legacy_cases, execution_budget, legacy_collection_batches, validate_historical_case_hashes,
)
from onpolicy.utils.stage2_resource_rl_v4 import (
    ARMS, DEFAULTS, CaseMinibatchLearner, case_minibatches, compare_cases,
    minibatch_scale, rollout_baseline_advantages, screen_candidate,
)


def row(name, makespan, group='iid'):
    return dict(case_dir=name, case_sha256=name, distribution=group,
                makespan=float(makespan), completed=True, cycle_terminated=False, timeout=False)


class ResourceRLV4Tests(unittest.TestCase):
    def learner(self, **changes):
        ac = TinyModel()
        policy = SimpleNamespace(ac=ac, device=torch.device('cpu'))
        args = SimpleNamespace(max_agent_num=1, max_device_num=1, recurrent_N=1, hidden_size=1)
        c = {**DEFAULTS, 'minibatch_cases': 2, 'chunk_length': 1, **changes}
        return CaseMinibatchLearner(policy, args, c, lambda *a, **kw: None)

    def rollout(self):
        mask = torch.tensor([[False, True]] * 4)
        frame = dict(mask=mask, dones=np.ones((4, 2), bool))
        return dict(cases=[row(str(i), 100 + i * 10) for i in range(4)],
                    frames=[frame], environment_events=4)

    def test_exact_historical_data_volume_budget(self):
        budget = execution_budget(240, 60, DEFAULTS)
        self.assertEqual(budget['case_episodes_per_arm'], 480)
        self.assertEqual(budget['actor_steps_per_arm'], 160)
        self.assertEqual(budget['total_training_case_episodes'], 960)
        self.assertEqual(budget['total_case_episode_limit'], 1708)
        self.assertFalse(budget['automatic_promotion'])
        with self.assertRaises(ValueError):
            execution_budget(96, 12, DEFAULTS)

    def test_historical_vector_worker_shards_are_not_contiguous_round_batches(self):
        batches = legacy_collection_batches(240, 24)
        self.assertEqual(len(batches), 10)
        self.assertEqual(batches[0], list(range(0, 240, 10)))
        self.assertEqual(batches[-1], list(range(9, 240, 10)))
        self.assertEqual(sorted(i for batch in batches for i in batch), list(range(240)))
        historical_workers = np.array_split(np.arange(240), 24)
        self.assertEqual(batches, [[int(worker[t]) for worker in historical_workers] for t in range(10)])

    def test_historical_data_alignment_checks_content_not_only_case_names(self):
        rows = [row('a', 100)]
        validate_historical_case_hashes(rows, {'entries': {'a': {'case_sha256': 'a'}}})
        with self.assertRaisesRegex(ValueError, 'content changed'):
            validate_historical_case_hashes(rows, {'entries': {'a': {'case_sha256': 'different'}}})

    def test_aligns_actual_240_not_source_pool_600(self):
        groups = ['iid'] * 120 + ['ood_stress'] * 108 + ['ood_scale'] * 12
        rows = [row(f'case_{i:04}', 100, g) for i, g in enumerate(groups)]
        order = [r['case_dir'] for r in reversed(rows)]
        parent = {'sampling_audits': {'11': dict(source_cases=600, selected_cases=240, case_order=order)}}
        selected = align_legacy_cases(parent, rows)
        self.assertEqual([r['case_dir'] for r in selected], order)
        rows[0]['distribution'] = 'ood_scale'
        with self.assertRaises(ValueError):
            align_legacy_cases(parent, rows)

    def test_minibatch_partition_and_normalization(self):
        batches = case_minibatches(24, 6, 11)
        self.assertEqual(sorted(i for b in batches for i in b), list(range(24)))
        self.assertTrue(all(len(b) == 6 for b in batches))
        self.assertEqual(batches, case_minibatches(24, 6, 11))
        # Deliberately unequal event counts: no per-case 1/T reweighting.
        sums = np.arange(1, 25, dtype=float) ** 2
        total_events = 999
        batched = np.mean([sums[b].sum() * minibatch_scale(24, len(b), total_events) for b in batches])
        self.assertAlmostEqual(batched, sums.sum() / total_events)

    def test_minibatch_membership_and_row_order_stay_identical_to_behavior(self):
        expected = [tuple(range(start, start + 6)) for start in range(0, 24, 6)]
        for seed_value in range(10):
            self.assertEqual(sorted(tuple(group) for group in case_minibatches(24, 6, seed_value)), expected)

    def test_behavior_and_replay_share_canonical_encoding_groups(self):
        learner = self.learner()
        obs = list(range(4))
        active, history, types = np.ones((4, 2, 1)), np.zeros((4, 2, 2)), np.zeros((4, 2))
        actions = np.zeros((4, 2, 2), np.int64)
        seen = []
        def fake_forward(policy, selected, hidden, *args, **kwargs):
            seen.append(list(selected))
            n = len(selected)
            return dict(actions=torch.zeros(n, 2, 2), log_probs=torch.zeros(n, 2)), {'global_emb': torch.ones(n, 3)}
        with patch('onpolicy.utils.stage2_resource_rl_v4.forward', side_effect=fake_forward):
            out, encoded = learner.collect_forward(learner.policy, obs, np.zeros((4, 2, 1, 1)), active, history, types)
            self.assertEqual(seen, [[0, 1], [2, 3]])
            self.assertEqual(out['actions'].shape[0], 4)
            cached, count = learner.cache_encoding(encoded)
            self.assertEqual(count, 4 * 3 * 4)
            frame = dict(obs=obs, active=active, history=history, types=types, actions=actions, encoded=cached)
            learner._forward_subset(frame, learner._hidden(2), [0, 1])
            with self.assertRaisesRegex(ValueError, 'canonical'):
                learner._forward_subset(frame, learner._hidden(2), [0, 2])

    def test_rollout_baseline_sign_and_forced_event_mask(self):
        rows = [row('a', 90), row('b', 120)]
        valid = torch.tensor([[True, True], [False, True]])
        raw, info = rollout_baseline_advantages(rows, {'a': 100, 'b': 100}, valid, 100)
        torch.testing.assert_close(raw, torch.tensor([.1, -.2, -.2]))
        self.assertEqual(info['cases_better_than_frozen_baseline'], 1)
        self.assertEqual(info['cases_worse_than_frozen_baseline'], 1)
        rows[0]['completed'] = False
        with self.assertRaises(ValueError):
            rollout_baseline_advantages(rows, {'a': 100, 'b': 100}, valid)

    def test_maximum_case_regret_is_not_maximum_cmax_delta(self):
        reference = [row('a', 100), row('b', 80)]
        candidate = [row('a', 99), row('b', 90)]
        report = compare_cases(reference, candidate)
        self.assertEqual(report['maximum_cmax_delta'], -1)
        self.assertEqual(report['maximum_paired_delta'], 10)
        self.assertAlmostEqual(report['maximum_relative_paired_delta'], .125)
        self.assertFalse(screen_candidate(report, report))
        with self.assertRaises(ValueError):
            compare_cases(reference, [candidate[0], candidate[0]])

    def test_screen_cannot_hide_regression_with_average_gain(self):
        baseline = [row(str(i), 1000, g) for i, g in enumerate(['iid', 'iid', 'ood_stress', 'ood_scale'])]
        candidate = [row(str(i), c, g) for i, (c, g) in enumerate(zip([1020, 950, 980, 990],
                    ['iid', 'iid', 'ood_stress', 'ood_scale']))]
        report = compare_cases(baseline, candidate)
        self.assertGreater(report['relative_improvement'], .005)
        self.assertFalse(screen_candidate(report, report))

    def test_steps_happen_per_minibatch_not_per_full_pass(self):
        learner = self.learner()
        calls = []
        def replay(rollout, indices, advantages, *, gradient, bc=False):
            if gradient:
                calls.append((learner.actor_steps, indices))
                learner.policy.ac.device_actor.weight.sum().backward()
            return dict(approx_kl=0., kl_sum=0., joint_count=len(indices), policy_loss=0.,
                        clip_count=0, reference_kl=0., entropy=0.)
        with patch.object(learner, 'audit_minibatches'), patch.object(learner, '_replay', side_effect=replay):
            result = learner.update(self.rollout(), reference_cmax={str(i): 110 for i in range(4)})
        self.assertEqual([step for step, _ in calls], [0, 1, 2, 3])
        self.assertEqual(result['actor_steps'], 4)
        self.assertEqual(result['critic_steps'], 0)
        self.assertEqual(float(learner.actor_optim.state[learner.policy.ac.device_actor.weight]['step']), 4)

    def test_pre_kl_stops_remaining_steps_without_retry(self):
        learner = self.learner()
        count = [0]
        def replay(rollout, indices, advantages, *, gradient, bc=False):
            if gradient:
                count[0] += 1
                learner.policy.ac.device_actor.weight.sum().backward()
            return dict(approx_kl=.02, kl_sum=.02, joint_count=1, policy_loss=0.,
                        clip_count=0, reference_kl=0., entropy=0.)
        with patch.object(learner, 'audit_minibatches'), patch.object(learner, '_replay', side_effect=replay):
            result = learner.update(self.rollout(), reference_cmax={str(i): 110 for i in range(4)})
        self.assertEqual(count[0], 1)
        self.assertEqual(learner.actor_steps, 0)
        self.assertTrue(result['paused_for_kl'])

    def test_each_replay_starts_with_current_weights_and_zero_hidden(self):
        learner = self.learner(minibatch_cases=1)
        frames = []
        for t in range(2):
            frames.append(dict(obs=[t], active=np.ones((1, 2, 1)), history=np.zeros((1, 2, 2)),
                types=np.zeros((1, 2)), actions=np.zeros((1, 2, 2), dtype=np.int64),
                old_logp=torch.zeros(1, 2), mask=torch.tensor([[False, True]]),
                reference_logits=torch.full((1, 2, 2), -np.log(2)),
                dones=np.full((1, 2), t == 1)))
        rollout = dict(cases=[row('a', 100)], frames=frames, environment_events=2)
        starts = []
        def fake_forward(policy, obs, hidden, active, history, types, **kwargs):
            if obs[0] == 0:
                starts.append(hidden.detach().clone())
            theta = policy.ac.device_actor.weight[0, 0]
            z = theta + hidden[:, 1, 0, 0]
            logits = torch.log_softmax(torch.stack([z, -z], -1), -1).unsqueeze(1).expand(-1, 2, -1)
            return dict(log_probs=logits[..., 0], decision_mask=torch.tensor([[False, True]]),
                        resource_logits=logits, rnn_states=hidden + theta), None
        with patch('onpolicy.utils.stage2_resource_rl_v4.forward', side_effect=fake_forward):
            learner._replay(rollout, [0], torch.ones(2, 1), gradient=True)
            self.assertEqual(learner.actor_steps, 0)
            learner.actor_optim.step()
            learner.actor_optim.zero_grad(set_to_none=True)
            learner._replay(rollout, [0], torch.ones(2, 1), gradient=True)
        self.assertEqual(len(starts), 2)
        self.assertTrue(all(not h.any() for h in starts))

    def test_value_baseline_is_computed_before_current_rollout_fit(self):
        learner = self.learner(baseline='value', critic_steps_per_round=2, ppo_passes=1)
        data = self.rollout()
        embeddings = torch.ones(4, 3)
        targets = torch.arange(4, dtype=torch.float32)
        valid = torch.ones(1, 4, dtype=torch.bool)
        # TinyModel's critic has two outputs; replace with the real scalar form.
        learner.policy.ac.team_critic = torch.nn.Linear(3, 1)
        with torch.no_grad():
            expected = learner.value_metrics(learner.policy.ac.team_critic(embeddings).flatten(), targets)
        def replay(*a, gradient, **kw):
            if gradient:
                learner.policy.ac.device_actor.weight.sum().backward()
            return dict(approx_kl=0., kl_sum=0., joint_count=4, policy_loss=0.,
                        clip_count=0, reference_kl=0., entropy=0.)
        with patch.object(learner, 'audit_minibatches'), patch.object(learner, '_critic_batch', return_value=(embeddings, targets, valid)), \
             patch.object(learner, '_replay', side_effect=replay), patch.object(learner, 'critic_update', return_value=[0., 0.]):
            result = learner.update(data)
        self.assertEqual(result['signal_metrics']['value_mean'], expected['value_mean'])
        self.assertEqual(result['signal_metrics']['value_snapshot'], 'before_fitting_this_rollout')


if __name__ == '__main__':
    unittest.main()
