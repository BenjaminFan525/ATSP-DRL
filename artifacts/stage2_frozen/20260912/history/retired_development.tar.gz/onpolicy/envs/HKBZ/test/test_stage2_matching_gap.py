"""Physical assignment identity, wait eligibility and deployed decoding."""

import unittest
import copy
import json
import itertools
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
from scipy.optimize import linear_sum_assignment
import torch

from onpolicy.config.config import get_config
from onpolicy.algorithms.gnn_mappo.algorithm.gnn_actor_critic import GNN_Actor_Critic
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.utils.stage2_matching import (
    solve_resource_matching, validate_teacher_matching,
    full_matching_supervision, finalize_matching_metrics,
    project_teacher_matching,
)
from onpolicy.utils.stage2_iga_contract import checked_cases, paired_iga_comparison, iga_target_diagnostics
from onpolicy.scripts.train.analyze_stage2_matching_gap import select_safe_epoch
from onpolicy.scripts.train.prepare_stage2_matching_gap import prepare, PARENT, METHODS, validate_canary_proof


def historical_decoder(scores, lookahead):
    """Frozen copy of the pre-refactor numerical matrix construction."""
    row_count, requests = scores.shape
    real_count = requests - 1
    matrix = np.full((row_count, real_count + row_count), -1.0e30, dtype=np.float64)
    if real_count:
        matrix[:, :real_count] = scores[:, 1:]
        legal = np.isfinite(scores[:, 1:])
        matrix[:, :real_count][legal & ~lookahead[None, 1:]] += 1.0e6
    for row in range(row_count):
        matrix[row, real_count + row] = scores[row, 0]
    matrix[~np.isfinite(matrix)] = -1.0e30
    rows, columns = linear_sum_assignment(matrix, maximize=True)
    assignments = np.full(row_count, -1, dtype=np.int64)
    assignments[rows] = columns
    return np.where(assignments < real_count, assignments + 1, 0)


class MatchingGapTest(unittest.TestCase):
    def supervision(self, raw, target, *, causes=None, lookahead=None, groups=None,
                    edge=True, wait=True):
        if lookahead is None:
            lookahead = np.ones(raw.shape[1], dtype=bool)
        return full_matching_supervision(
            torch.log_softmax(raw, dim=-1), target, lookahead,
            groups or [list(range(raw.shape[0]))], causes or [''] * raw.shape[0],
            edge_enabled=edge, wait_enabled=wait,
        )

    def test_decoder_refactor_is_exact_on_random_and_tied_scores(self):
        rng = np.random.default_rng(139)
        for index in range(400):
            rows, cols = rng.integers(1, 8), rng.integers(1, 10)
            scores = rng.normal(size=(rows, cols))
            if index % 4 == 0:
                scores[:] = 0.0
            scores[rng.random(scores.shape) < .25] = -np.inf
            scores[:, 0] = 0.0
            lookahead = rng.random(cols) < .5
            np.testing.assert_array_equal(
                solve_resource_matching(scores, lookahead), historical_decoder(scores, lookahead))

    def test_physical_assignment_swap_changes_loss_and_gradient(self):
        raw = torch.tensor([[-8., 0., 4.], [-8., 4., 0.]], requires_grad=True)
        wrong, _, metrics = self.supervision(raw, [1, 2])
        right, _, _ = self.supervision(raw, [2, 1])
        self.assertGreater(float(wrong), 4.)
        self.assertEqual(float(right), 0.)
        wrong.backward()
        self.assertGreater(float(raw.grad.abs().sum()), 0.)
        self.assertEqual(metrics['device_bc_deploy_set_correct'], 1)
        self.assertEqual(metrics['device_bc_deploy_edge_correct'], 0)

    def test_synchronized_device_renaming_preserves_supervision(self):
        raw = torch.tensor([[-2., 1., 3.], [-1., 4., 2.]], requires_grad=True)
        loss, _, _ = self.supervision(raw, [1, 2])
        permuted = raw.detach().flip(0).requires_grad_(True)
        other, _, _ = self.supervision(permuted, [2, 1])
        torch.testing.assert_close(loss, other, rtol=0, atol=0)
        loss.backward()
        other.backward()
        torch.testing.assert_close(raw.grad, permuted.grad.flip(0), rtol=0, atol=0)

    def test_all_wait_gets_gradient_only_with_typed_legal_choice(self):
        raw = torch.tensor([[0., 2.], [0., 3.]], requires_grad=True)
        _, wait, metrics = self.supervision(raw, [0, 0], causes=['temporal_defer'] * 2)
        self.assertGreater(float(wait), 2.)
        wait.backward()
        self.assertTrue(torch.isfinite(raw.grad).all())
        self.assertEqual(metrics['device_bc_wait_eligible_groups'], 1)
        self.assertEqual(metrics['device_bc_wait_eligible_rows'], 2)
        for causes in (['capacity_unmatched'] * 2, ['deferred_noop'] * 2, ['claimed_noop'] * 2):
            _, other, values = self.supervision(raw, [0, 0], causes=causes)
            self.assertFalse(other.requires_grad)
            self.assertEqual(values['device_bc_wait_untyped_choice_groups'], 1)

    def test_structural_noop_is_counted_without_timing_gradient(self):
        raw = torch.tensor([[0., -torch.inf]], requires_grad=True)
        edge, wait, metrics = self.supervision(raw, [0], causes=['temporal_defer'])
        self.assertFalse(edge.requires_grad or wait.requires_grad)
        self.assertEqual(metrics['device_bc_wait_structural_groups'], 1)

    def test_mixed_group_keeps_identity_of_the_waiting_device(self):
        raw = torch.tensor([[4., 0.], [0., 4.]], requires_grad=True)
        loss, wait, metrics = self.supervision(raw, [1, 0], causes=['', 'capacity_unmatched'])
        self.assertGreater(float(loss), 4.)
        self.assertEqual(float(wait), 0.)
        self.assertEqual(metrics['device_bc_matching_nonempty_groups'], 1)

    def test_metric_really_uses_blocking_priority(self):
        raw = torch.tensor([[5., 0.]], requires_grad=True)
        edge, _, metrics = self.supervision(raw, [1], lookahead=[False, False])
        self.assertEqual(metrics['device_bc_deploy_joint_correct'], 1)
        self.assertEqual(float(edge), 0.)
        actor = SimpleNamespace(max_plane_agents=1)
        logits = torch.zeros((1, 2, 2))
        logits[0, 1] = torch.log_softmax(raw.detach()[0], dim=-1)
        action = torch.full((1, 2), -1, dtype=torch.long)
        log_prob, valid = torch.zeros((1, 2)), torch.zeros((1, 2), dtype=torch.bool)
        GNN_Actor_Critic._apply_device_global_matching(
            actor, resource_action_logits=logits, request_is_lookahead=torch.zeros((1, 2), dtype=torch.bool),
            active_agents=torch.tensor([[False, True]]), op_choice=action,
            log_prob=log_prob, decision_validated=valid,
        )
        self.assertEqual(action[0, 1].item(), 1)

    def test_unrepresentable_teacher_is_not_silently_rematched(self):
        for scores, target, lookahead, message in (
            ([[0., -np.inf]], [1], [False, True], 'identity edge'),
            ([[0., 0.], [0., 0.]], [1, 1], [False, True], 'duplicates'),
            ([[0., 0.]], [0], [False, False], 'Blocking priority'),
        ):
            with self.subTest(message=message), self.assertRaisesRegex(ValueError, message):
                validate_teacher_matching(np.asarray(scores), target, lookahead)

    def test_multitype_request_is_supervised_jointly_without_duplicate_claims(self):
        raw = torch.tensor([[2., 0.], [0., 3.]], requires_grad=True)
        edge, wait, metrics = self.supervision(raw, [1, 0], groups=[[0], [1]],
                                               causes=['', 'claimed_noop'])
        self.assertGreater(float(edge), 2.)
        self.assertEqual(float(wait), 0.)
        self.assertEqual(metrics['device_bc_full_edge_groups'], 1)
        self.assertEqual(metrics['device_bc_wait_eligible_groups'], 0)
        edge.backward()
        self.assertGreater(float(raw.grad.abs().sum()), 0.)

    def test_audit_only_does_not_add_a_training_objective(self):
        raw = torch.tensor([[0., 1.]], requires_grad=True)
        edge, wait, metrics = self.supervision(raw, [1], edge=False, wait=False)
        self.assertFalse(edge.requires_grad or wait.requires_grad)
        self.assertEqual(metrics['device_bc_deploy_rows'], 1)

    def test_metrics_use_counts_and_keep_missing_denominators_null(self):
        result = finalize_matching_metrics({'device_bc_deploy_choice_rows': 4,
                                           'device_bc_deploy_choice_edge_correct': 3})
        self.assertEqual(result['device_bc_deploy_choice_edge_exact'], .75)
        self.assertIsNone(result['device_bc_empty_wait_loss_group_mean'])

    def test_new_loss_contract_binds_recovery_and_defaults_are_legacy(self):
        runner = object.__new__(HKBZ_Runner)
        runner.all_args = get_config().parse_args([])
        runner.policy = SimpleNamespace(ac=SimpleNamespace())
        old = runner._stage2_bc_run_contract()
        self.assertNotIn('full_matching_supervision', old)
        runner.all_args.device_bc_matching_audit = True
        first = runner._stage2_bc_run_contract()
        runner.all_args.device_bc_full_edge_loss_coef = 1.
        self.assertNotEqual(first, runner._stage2_bc_run_contract())
        second = runner._stage2_bc_run_contract()
        runner.all_args.device_bc_teacher_deployment_projection = True
        self.assertNotEqual(second, runner._stage2_bc_run_contract())

    def test_case_0343_priority_conflict_repairs_only_one_physical_edge(self):
        legal = np.zeros((5, 24), dtype=bool)
        for row, requests in enumerate(([0, 1, 2, 11, 13, 17, 20, 21],
                                       [0, 1, 2, 5, 11, 13, 17], [0, 23], [0, 23], [0, 19])):
            legal[row, requests] = True
        lookahead = np.ones(24, dtype=bool)
        lookahead[[0, 1, 2]] = False
        original = np.array([20, 1, 0, 0, 0])
        with self.assertRaisesRegex(ValueError, 'Blocking priority'):
            validate_teacher_matching(np.where(legal, 0., -np.inf), original, lookahead)
        projected, stats = project_teacher_matching(legal, original, lookahead)
        np.testing.assert_array_equal(projected, [2, 1, 0, 0, 0])
        np.testing.assert_array_equal(original, [20, 1, 0, 0, 0])
        self.assertEqual(stats['teacher_projection_changed_rows'], 1)
        self.assertEqual(stats['teacher_projection_added_blocking'], 1)

    def test_teacher_projection_exhaustive_small_matching_and_serial_legality(self):
        rng = np.random.default_rng(207)
        repairs = 0
        for _ in range(350):
            rows, columns = int(rng.integers(1, 5)), int(rng.integers(2, 6))
            legal = rng.random((rows, columns)) < .6
            legal[:, 0] = True
            lookahead = rng.random(columns) < .5
            lookahead[0] = False

            def options(row, claimed):
                allowed = legal[row].copy()
                allowed[list(claimed)] = False
                last = allowed & ~lookahead & ~legal[row + 1:].any(axis=0)
                last[0] = False
                return last if last.any() else allowed

            target, claimed = [], set()
            for row in range(rows):
                selected = int(rng.choice(np.flatnonzero(options(row, claimed))))
                target.append(selected)
                if selected:
                    claimed.add(selected)
            projected, stats = project_teacher_matching(legal, target, lookahead)
            feasible = [assignment for assignment in itertools.product(range(columns), repeat=rows)
                        if all(legal[row, action] for row, action in enumerate(assignment))
                        and len({a for a in assignment if a}) == sum(a > 0 for a in assignment)]
            count = lambda assignment: sum(a > 0 and not lookahead[a] for a in assignment)
            maximum = max(map(count, feasible))
            self.assertEqual(count(projected), maximum)
            claimed = set()
            for row, action in enumerate(projected):
                self.assertTrue(options(row, claimed)[action])
                if action:
                    claimed.add(int(action))
            if count(target) == maximum:
                np.testing.assert_array_equal(projected, target)
            again, second = project_teacher_matching(legal, projected, lookahead)
            np.testing.assert_array_equal(again, projected)
            self.assertEqual(second['teacher_projection_events'], 0)
            repairs += stats['teacher_projection_events']
        self.assertGreater(repairs, 0)

    def test_projection_reconciles_serial_last_chance_without_losing_blocking(self):
        legal = [[1, 0, 0, 0, 0, 0, 0, 1], [1, 1, 0, 1, 0, 1, 0, 1],
                 [1, 0, 0, 1, 1, 1, 1, 0], [1, 0, 0, 1, 1, 1, 1, 0]]
        projected, stats = project_teacher_matching(legal, [0, 7, 0, 5], [0, 0, 0, 0, 1, 0, 0, 0])
        np.testing.assert_array_equal(projected, [7, 1, 3, 5])
        self.assertEqual(stats['teacher_projection_serial_resolves'], 1)
        self.assertEqual(stats['teacher_projection_added_blocking'], 2)

    def test_environment_teacher_projection_is_opt_in_and_provenance_is_not_reused(self):
        from onpolicy.envs.HKBZ.test.test_resource_iga_ablation import (
            _make_env, _create_r008_request, ARM_BACKENDS, GenomeLayout, mixed_resource_actions)
        env = _make_env()
        try:
            _create_r008_request(env)
            backends = ARM_BACKENDS['iga_all']
            layout = GenomeLayout.from_env(env, backends)
            decoded = layout.decode(np.full(layout.n_var, .5))
            env._load_resource_iga_teacher = lambda: {
                'backends': backends, 'decoded': decoded, 'path': 'fixture',
                'teacher_sha256': 'fixture-sha', 'teacher_cmax': 123.}
            original, decisions = mixed_resource_actions(env, backends, decoded, record=True)
            legacy = env.resource_iga_teacher_actions(return_info=True, include_ready_targets=False)
            np.testing.assert_array_equal(legacy['actions'], original)
            self.assertEqual(legacy['info']['decisions'], decisions)
            derived = env.resource_iga_teacher_actions(return_info=True, include_ready_targets=False,
                                                       deployment_projection=True)
            np.testing.assert_array_equal(derived['actions'], original)
            self.assertEqual(derived['info']['teacher_projection_events'], 0)
            self.assertEqual(derived['info']['original_teacher_cmax'], 123.)
            self.assertIsNone(derived['info']['teacher_cmax'])
            self.assertIsNone(derived['info']['derived_teacher_cmax'])
            self.assertEqual(derived['info']['request_ready_targets'], [])
            with self.assertRaisesRegex(ValueError, 'factual Ready'):
                env.resource_iga_teacher_actions(deployment_projection=True)
        finally:
            env.close()

    def test_teacher_projection_does_not_hide_other_invalid_labels(self):
        for legal, target, lookahead, error in (
            ([[True, True], [True, True]], [1, 1], [False, True], 'duplicate'),
            ([[True, False]], [1], [False, True], 'identity'),
            ([[True, True]], [0], [False, False], 'last-chance'),
        ):
            with self.subTest(error=error), self.assertRaisesRegex(ValueError, error):
                project_teacher_matching(legal, target, lookahead)


class IGAGapContractTest(unittest.TestCase):
    def rows(self, values=(10., 20., 30.)):
        return {'cases': [{'case_sha256': str(i), 'makespan': value, 'completed': True,
            'cycle_terminated': False, 'timeout': False, 'distribution': group, 'profile': group}
            for i, (value, group) in enumerate(zip(values, ('iid', 'ood_stress', 'ood_scale')))]}

    def test_pairing_rejects_duplicate_invalid_and_different_content(self):
        rows = self.rows()
        for change in ('duplicate', 'invalid', 'incomplete'):
            bad = copy.deepcopy(rows)
            if change == 'duplicate':
                bad['cases'][1]['case_sha256'] = '0'
            elif change == 'invalid':
                bad['cases'][0]['makespan'] = float('nan')
            else:
                bad['cases'][0]['completed'] = False
            with self.assertRaises(ValueError):
                checked_cases(bad)
        bad = copy.deepcopy(rows)
        bad['cases'][0]['case_sha256'] = 'changed'
        with self.assertRaises(ValueError):
            paired_iga_comparison(bad, rows, samples=100)
        bad['cases'][0]['case_sha256'] = '0'
        bad['cases'][0]['profile'] = 'changed'
        with self.assertRaises(ValueError):
            paired_iga_comparison(bad, rows, samples=100)

    def test_point_success_never_certifies_historical_tune_as_formal(self):
        result = iga_target_diagnostics(self.rows((9., 19., 29.)),
            {'IGA180': self.rows(), 'IGA1800': self.rows()}, samples=100)
        self.assertTrue(result['historical_iga180_point_requirement_met'])
        self.assertTrue(result['historical_iga1800_point_requirement_met'])
        self.assertFalse(result['confirmed_scientific_success'])
        comparison = result['comparisons']['IGA180']
        self.assertEqual(comparison['mean_delta_seconds'], -1.)
        self.assertEqual(comparison['case_bootstrap_95ci_seconds'], [-1., -1.])

    def test_display_ties_do_not_allow_positive_goal_tolerance(self):
        result = iga_target_diagnostics(self.rows((10. + 1e-8, 19., 29.)),
            {'IGA180': self.rows(), 'IGA1800': self.rows()}, samples=100)
        self.assertEqual(result['comparisons']['IGA180']['losses'], 0)
        self.assertEqual(result['comparisons']['IGA180']['strict_positive_delta_count'], 1)
        self.assertFalse(result['historical_iga180_point_requirement_met'])

    def test_safe_selection_keeps_source_and_rejects_group_regression(self):
        values = {0: self.rows(), 1: self.rows((8., 18., 31.)), 2: self.rows((9., 19., 29.))}
        self.assertEqual(select_safe_epoch(values, [1]), 0)
        self.assertEqual(select_safe_epoch(values, [1, 2]), 2)
        values[1] = self.rows()
        self.assertEqual(select_safe_epoch(values, [1]), 0)

    def test_missing_or_changed_canary_cannot_start_pilot(self):
        with self.assertRaisesRegex(ValueError, 'requires'):
            validate_canary_proof(None, {})
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / 'analysis').mkdir()
            path = root / 'analysis/comparison.json'
            path.write_text(json.dumps({'canary_contract_passed': True, 'complete': True,
                'methods': {arm + '_seed11': {} for arm in METHODS}}))
            (root / 'manifest.json').write_text(json.dumps({'profile': 'canary',
                'research_family': 'stage2_matching_gap', 'code_fingerprint': {'a': 'hash'}}))
            self.assertIn('manifest_sha256', validate_canary_proof(path, {'a': 'hash'}))
            with self.assertRaisesRegex(ValueError, 'differs'):
                validate_canary_proof(path, {'a': 'changed'})

    def test_real_local_manifest_preparation_pins_historical_budget_and_four_arms(self):
        if not (PARENT / 'analysis/comparison.json').exists():
            self.skipTest('Local historical pilot is unavailable')
        with TemporaryDirectory() as temporary:
            manifest = prepare(SimpleNamespace(suite_dir=Path(temporary) / 'suite', parent_suite=PARENT,
                run_tag='stage2_matching_gap_unit_fixture', profile='canary',
                canary_proof=None, python=Path('/usr/bin/python3')))
            self.assertEqual(set(manifest['commands']), {name + '_seed11' for name in METHODS})
            self.assertFalse(manifest['scientific_result'])
            self.assertFalse(manifest['evaluation_contract']['finalblind_access'])
            self.assertEqual(manifest['resource_contract']['max_concurrent_trainers'], 3)
            audit = json.loads(Path(manifest['iga_reference_audit']['path']).read_text())
            self.assertFalse(audit['formal_iga_goal_certifiable'])
            self.assertTrue(audit['nested_incumbent_checked'])
            self.assertEqual(len(audit['baselines']['IGA180']['cases']), 60)
            self.assertGreater(audit['baselines']['IGA180']['budget_audit']['mean_additional_wall_seconds'], 180)
            sources = {entry['warmstart_source']['sha256'] for entry in manifest['commands'].values()}
            self.assertEqual(len(sources), 1)


if __name__ == '__main__':
    unittest.main()
