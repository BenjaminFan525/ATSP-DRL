"""Administrative four-arm dispatch tests; no scientific case is executed."""
import copy
import json
import os
from pathlib import Path
import signal
import tempfile
import time
import unittest
from unittest.mock import Mock, patch

from onpolicy.scripts.train import expedite_stage2_resource_rl_v5 as four
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl_v5_unlimited import VERSION as TIME_VERSION
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL


def manifest():
    return dict(protocol=PROTOCOL, training_contract=copy.deepcopy(DEFAULTS),
        resource_contract=dict(gpu=0, gpu_uuid='GPU-744c1334-98c8-5318-e799-7ad15eea1fbf',
            allowed_cpus='0-31,64-95', trainer_slots=['0-11,64-75', '12-23,76-87'],
            eval_cpus='24-29,88-93', monitor_cpus='30-31,94-95',
            max_concurrent_trainers=2, serialized_evaluation=True, runtime_max_seconds=None),
        time_limit_removal=dict(version=TIME_VERSION, user_request='解除超时门禁',
            wall_clock_limit_enabled=False, projected_time_gate_enabled=False),
        execution=dict(arms=list(ARMS), total_training_case_episodes=960,
            ar_training_evaluation_case_episodes=480, hungarian_final_evaluation_case_episodes=240,
            automatic_retry=False, automatic_stage_c=False))


def pending_fixture(root):
    state = dict(status='running', phase='stage_b_training', pid=100,
                 updated_unix=time.time(), worker_exit_records=[])
    atomic_json(root / 'run_status.json', state)
    atomic_json(root / 'control.json', {'pid': 100})
    (root / 'logs').mkdir()
    for i, arm in enumerate(('E0', 'E1')):
        atomic_json(root / 'workers' / arm / 'run_status.json', dict(
            status='running', arm=arm, pid=101+i, completed_training_case_episodes=24,
            completed_physical_case_episodes=24))
    return state


class FourArmTests(unittest.TestCase):
    def test_scientific_scope_and_resource_boundary_remain_exact(self):
        m = manifest()
        four.validate_scope(m)
        for section, key, value in [
            ('training_contract', 'rounds', 11), ('training_contract', 'rollout_cases', 12),
            ('training_contract', 'actor_lr', .1), ('resource_contract', 'gpu', 1),
            ('resource_contract', 'allowed_cpus', '0-127'),
            ('resource_contract', 'serialized_evaluation', False),
            ('resource_contract', 'max_concurrent_trainers', 4),
            ('resource_contract', 'runtime_max_seconds', 3600),
            ('execution', 'total_training_case_episodes', 1920),
            ('execution', 'automatic_retry', True), ('execution', 'automatic_stage_c', True),
        ]:
            altered = copy.deepcopy(m)
            altered[section][key] = value
            with self.subTest(section=section, key=key), self.assertRaises(ValueError):
                four.validate_scope(altered)

    def test_four_arms_share_original_cpu_pools_without_expansion(self):
        resources = manifest()['resource_contract']
        self.assertEqual(four.SLOTS, {'E0': 0, 'E1': 1, 'E2': 0, 'E3': 1})
        train = set().union(*(four.cpus(p) for p in resources['trainer_slots']))
        evaluation, monitor = four.cpus(resources['eval_cpus']), four.cpus(resources['monitor_cpus'])
        self.assertFalse(train & evaluation or train & monitor or evaluation & monitor)
        self.assertEqual(train | evaluation | monitor, four.cpus('0-31,64-95'))

    def test_memory_gate_includes_context_reserve_and_host_memory(self):
        reports = {a: {'peak_reserved_bytes': 7 * four.GIB} for a in ARMS}
        gpu = dict(uuid=manifest()['resource_contract']['gpu_uuid'],
                   total_bytes=48 * four.GIB, free_bytes=36 * four.GIB)
        self.assertTrue(four.memory_gate(reports, gpu, 100 * four.GIB)['passed'])
        for changed, ram in [({**gpu, 'free_bytes': 19 * four.GIB}, 100 * four.GIB),
            ({**gpu, 'total_bytes': 32 * four.GIB}, 100 * four.GIB),
            ({**gpu, 'uuid': 'GPU1'}, 100 * four.GIB), (gpu, 63 * four.GIB)]:
            with self.assertRaises(ValueError):
                four.memory_gate(reports, changed, ram)

    def test_existing_arm_artifacts_forbid_duplicate_dispatch(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            pending_fixture(root)
            four.validate_pending(root)
            (root / 'E2').mkdir()
            with self.assertRaises(FileExistsError):
                four.validate_pending(root)

    def test_unhealthy_or_stale_original_run_is_not_taken_over(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            state = pending_fixture(root)
            for changed in ({**state, 'status': 'failed'}, {**state, 'updated_unix': time.time()-121}):
                atomic_json(root / 'run_status.json', changed)
                with self.assertRaises(ValueError):
                    four.validate_pending(root)

    def test_exclusive_log_claims_survive_failure_and_block_original_launcher(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'logs').mkdir()
            handles = four.claim_logs(root)
            for handle in handles.values():
                handle.close()
            for arm in ('E2', 'E3'):
                with self.assertRaises(FileExistsError):
                    (root / 'logs' / f'train_{arm}.log').open('x')
            with self.assertRaises(FileExistsError):
                four.claim_logs(root)

    def test_launch_uses_identical_pinned_worker_manifest_and_original_slot(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'logs').mkdir()
            controller = four.FourArmController.__new__(four.FourArmController)
            controller.root, controller.path, controller.m = root, root/'manifest.json', manifest()
            controller.logs, controller.spawned = four.claim_logs(root), {}
            try:
                with patch.object(four.subprocess, 'Popen', return_value=Mock(pid=200)) as popen:
                    controller.launch_new('E2')
                    command = popen.call_args.args[0]
                    self.assertIn(str(four.WORKER), command)
                    self.assertEqual(command[command.index('--manifest')+1], str(controller.path))
                    self.assertEqual(command[-4:], ['--arm', 'E2', '--slot', '0'])
                    self.assertEqual(command[2], '0-11,64-75')
                    with self.assertRaises(ValueError):
                        controller.launch_new('E2')
                    with self.assertRaises(ValueError):
                        controller.launch_new('E0')
            finally:
                for handle in controller.logs.values():
                    handle.close()

    def test_preflight_failure_does_not_overwrite_running_parent_status(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            suite, admin = root/'suite', root/'admin'
            atomic_json(suite/'run_status.json', {'status': 'running', 'pid': 100})
            original = file_sha(suite/'run_status.json')
            controller = four.FourArmController.__new__(four.FourArmController)
            controller.root, controller.admin_root = suite, admin
            controller.has_control, controller.phase = False, 'four_arm_dispatch_failed'
            controller.status(status='failed', error='insufficient memory')
            self.assertEqual(file_sha(suite/'run_status.json'), original)
            self.assertTrue(four.read(admin/'run_status.json')['original_run_not_taken_over'])

    def test_scheduler_cannot_be_retired_while_retained_workers_live(self):
        controller = four.FourArmController.__new__(four.FourArmController)
        controller.retained = {'E0': Mock(info=lambda: {'state': 'R'})}
        controller.scheduler = Mock()
        with self.assertRaises(RuntimeError):
            controller.retire_scheduler()
        controller.scheduler.send.assert_not_called()

    def test_recovery_never_relaunches_and_halts_rounds_only_after_claim(self):
        for claimed in (False, True):
            with self.subTest(claimed=claimed), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                suite, admin = root/'suite', root/'admin'
                pending_fixture(suite)
                request_path = admin/'authorization.json'
                atomic_json(request_path, dict(version=four.VERSION, parent_unit=four.PARENT_UNIT,
                    suite=str(suite), control_sha256=file_sha(suite/'control.json')))
                atomic_json(admin/'checks/active_handoff.json', dict(scheduler_pid=100, scheduler_start_ticks=900))
                if claimed:
                    handles = four.claim_logs(suite)
                    for handle in handles.values():
                        handle.close()
                scheduler = Mock(start_ticks=900, info=lambda: {'state': 'T'})
                with patch.object(four, 'service_value', return_value='100'), \
                     patch.object(four, 'Scheduler', return_value=scheduler), \
                     patch.object(four.subprocess, 'Popen') as popen:
                    four.recovery(request_path)
                scheduler.send.assert_called_once_with(signal.SIGCONT)
                self.assertEqual((suite/'halt_after_current_round.json').exists(), claimed)
                popen.assert_not_called()

    def test_retired_scheduler_recovery_is_noop(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            atomic_json(root/'authorization.json', {})
            atomic_json(root/'checks/active_handoff.json', {})
            atomic_json(root/'checks/retired_scheduler.json', {'passed': True})
            with patch.object(four, 'Scheduler') as scheduler:
                four.recovery(root/'authorization.json')
                scheduler.assert_not_called()

    def test_all_four_exit_monitoring_and_no_retained_worker_signals(self):
        for fail in (False, True):
            with self.subTest(fail=fail), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                suite, admin = root/'suite', root/'admin'
                pending_fixture(suite)
                admin.mkdir()
                controller = four.FourArmController.__new__(four.FourArmController)
                controller.root, controller.admin_root = suite, admin
                controller.path, controller.request_path = suite/'manifest.json', admin/'authorization.json'
                atomic_json(controller.request_path, {})
                controller.request = {'original_controller_pid': 100}
                controller.m = manifest()
                controller.records, controller.retained, controller.spawned, controller.logs = [], {}, {}, {}
                controller.scheduler, controller.has_control = None, False
                controller.status = Mock()
                scheduler = Mock(pid=100, start_ticks=900, info=lambda: {'state': 'T'})
                retained = {a: Mock(pid=101+i, info=lambda: {'state': 'Z', 'exit_wait_status': 0})
                            for i, a in enumerate(('E0', 'E1'))}
                for arm in ARMS:
                    atomic_json(suite/'workers'/arm/'run_status.json', dict(status='completed', arm=arm))
                    atomic_json(suite/arm/'result.json', dict(status='completed'))
                new = [Mock(pid=201, poll=lambda: 1 if fail else 0), Mock(pid=202, poll=lambda: 0)]
                def retire():
                    self.assertEqual(len(controller.records), 4)
                    atomic_json(admin/'checks/retired_scheduler.json', {'passed': True})
                controller.retire_scheduler = Mock(side_effect=retire)
                with patch.dict(os.environ, {'CUDA_VISIBLE_DEVICES': '0'}), \
                     patch.object(four.os, 'sched_getaffinity', return_value=four.cpus('0-31,64-95')), \
                     patch.object(four.os, 'sched_setaffinity'), \
                     patch.object(four.signal, 'signal'), \
                     patch.object(four, 'service_value', side_effect=lambda name, unit: str(os.getpid()) if name=='MainPID' else 'infinity'), \
                     patch.object(four, 'preflight', return_value={'retained_workers': {}}), \
                     patch.object(four, 'Scheduler', return_value=scheduler), \
                     patch.object(four, 'pin_worker', side_effect=lambda root, arm, parent: retained[arm]), \
                     patch.object(four.subprocess, 'Popen', side_effect=new), \
                     patch.object(four, 'analyze'):
                    self.assertEqual(controller.run_four(), 1 if fail else 0)
                scheduler.send.assert_called_once_with(signal.SIGSTOP)
                for process in retained.values():
                    process.send.assert_not_called()
                controller.retire_scheduler.assert_called_once()
                self.assertEqual((suite/'halt_after_current_round.json').exists(), fail)
                self.assertEqual(controller.status.call_args.kwargs['status'], 'failed' if fail else 'completed')


if __name__ == '__main__':
    unittest.main()
