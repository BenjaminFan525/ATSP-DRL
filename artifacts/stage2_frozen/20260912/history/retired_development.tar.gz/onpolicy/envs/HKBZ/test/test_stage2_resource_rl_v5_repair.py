"""Repair orchestration regressions; no system service or environment execution."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from onpolicy.scripts.train.repair_stage2_resource_rl_v5 import AuditRepairController, validate_failed_stop
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.control_stage2_resource_rl_v5 import Controller
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL
from onpolicy.utils.stage2_resource_rl_v5_zero import VERSION


def stop_point():
    m = dict(protocol=PROTOCOL, training_contract=copy.deepcopy(DEFAULTS))
    s = dict(status='failed', phase='initial_evaluation_and_reference',
             completed_training_case_episodes=0, completed_physical_case_episodes=96,
             attempted_physical_case_episodes=108, completed_physical_case_episodes_this_process=0)
    w = dict(status='failed', evaluation_label='E0_initial_AR', attempted_physical_case_episodes=12,
             error='Copied architecture is not zero-update equivalent to B0.')
    return m, s, w


class AuditRepairTests(unittest.TestCase):
    def test_only_the_exact_initial_stop_is_repairable(self):
        self.assertTrue(validate_failed_stop(*stop_point()))
        for key, value in [('completed_training_case_episodes', 24), ('completed_physical_case_episodes', 108),
                           ('attempted_physical_case_episodes', 120), ('status', 'running')]:
            m, s, w = stop_point()
            s[key] = value
            with self.assertRaises(ValueError):
                validate_failed_stop(m, s, w)

    def test_unrelated_failure_or_advanced_setup_is_rejected(self):
        for key, value in [('error', 'CUDA out of memory'), ('evaluation_label', 'E1_initial_AR'),
                           ('completed_physical_case_episodes', 12), ('attempted_physical_case_episodes', 24)]:
            m, s, w = stop_point()
            w[key] = value
            with self.assertRaises(ValueError):
                validate_failed_stop(m, s, w)

    def test_clock_is_not_restarted_and_failed_attempts_are_visible(self):
        with tempfile.TemporaryDirectory() as tmp:
            root, parent = Path(tmp) / 'new', Path(tmp) / 'old'
            for name in ('manifest.json', 'control.json', 'run_status.json'):
                atomic_json(parent / name, dict(original=True))
            m = dict(protocol=PROTOCOL, budget_continuation=dict(parent='engineering_source'),
                repair_of=dict(path=str(parent), manifest_sha256=file_sha(parent / 'manifest.json'),
                    control_sha256=file_sha(parent / 'control.json'), status_sha256=file_sha(parent / 'run_status.json'),
                    original_started_unix=1000., hard_deadline_unix=109000.),
                zero_audit_repair=dict(version=VERSION, new_time_budget=False, parent=str(parent),
                    inherited_worker_exit_records=[dict(phase='setup', arm='E0', exit_code=1)]))
            atomic_json(root / 'manifest.json', m)
            with patch('onpolicy.scripts.train.control_stage2_resource_rl_v5.time.time', return_value=20000.):
                controller = AuditRepairController(root / 'manifest.json')
                self.assertEqual(controller.started, 1000.)
                self.assertEqual(controller.process_started, 20000.)
                self.assertEqual(controller.deadline, 109000.)
                for a in ARMS:
                    atomic_json(root / 'engineering' / a / 'run_status.json', dict(
                        completed_physical_case_episodes=24, attempted_physical_case_episodes=24))
                atomic_json(root / 'workers/setup/run_status.json', dict(attempted_physical_case_episodes=12))
                controller.status()
            status = json.loads((root / 'run_status.json').read_text())
            self.assertEqual(status['lifetime_attempted_physical_case_episodes'], 132)
            self.assertEqual(status['completed_physical_case_episodes'], 96)
            self.assertEqual(status['completed_training_case_episodes'], 0)
            self.assertEqual(status['lifetime_attempted_case_episode_limit'], 2340)
            self.assertFalse(status['new_time_budget'])
            self.assertEqual(status['budget_elapsed_seconds'], 19000.)
            self.assertEqual(status['process_elapsed_seconds'], 0.)

    def test_engineering_cannot_be_launched_and_run_keeps_all_gates(self):
        controller = AuditRepairController.__new__(AuditRepairController)
        with self.assertRaises(RuntimeError):
            controller.launch('engineering', 'E0', 0)
        with patch.object(controller, 'validate_continuation') as validate, patch.object(Controller, 'run', return_value=2):
            self.assertEqual(controller.run(), 2)
            validate.assert_called_once()


if __name__ == '__main__':
    unittest.main()
