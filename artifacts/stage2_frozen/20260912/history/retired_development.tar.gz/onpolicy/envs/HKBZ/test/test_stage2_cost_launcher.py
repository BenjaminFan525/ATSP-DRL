"""Exercise the launcher without a GPU, a real service, or training outputs."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[4]
LAUNCHER = ROOT / 'onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh'

STUB = r'''
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

name, args = Path(sys.argv[0]).name, sys.argv[1:]
event = dict(command=name, args=args, path=os.environ['PATH'])
if name == 'systemd-run':
    # A user manager starts with a different, minimal PATH unless explicitly set.
    service_env = {'PATH': '/usr/bin:/bin'}
    for arg in args:
        if arg.startswith('--setenv='):
            key, value = arg[len('--setenv='):].split('=', 1)
            service_env[key] = value
    event['service_path'] = service_env['PATH']
    event['service_rg'] = shutil.which('rg', path=service_env['PATH'])
with open(os.environ['STAGE2_TEST_EVENTS'], 'a') as handle:
    handle.write(json.dumps(event) + '\n')
if name == 'taskset':
    assert args[:2] == ['-c', '30-31,94-95']
    raise SystemExit(subprocess.run(args[2:], check=False).returncode)
if name == 'fake-python':
    suite = Path(args[args.index('--suite-dir') + 1])
    suite.mkdir(parents=True, exist_ok=False)
    (suite / 'manifest.json').write_text('{}')
if name == 'systemd-run' and event['service_rg'] is None:
    raise SystemExit('The service cannot resolve rg')
'''


class CostLauncherTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='stage2 launcher ')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.launcher = self.root / LAUNCHER.relative_to(ROOT)
        self.launcher.parent.mkdir(parents=True)
        shutil.copyfile(LAUNCHER, self.launcher)
        self.bin = self.root / 'tools with spaces'
        self.bin.mkdir()
        for command in ('bash', 'dirname'):
            (self.bin / command).symlink_to(shutil.which(command))
        for command in ('rg', 'taskset', 'nvidia-smi', 'systemd-run', 'fake-python'):
            path = self.bin / command
            path.write_text(f'#!{sys.executable}\n' + STUB)
            path.chmod(0o755)
        self.events = self.root / 'events.jsonl'
        self.tag = 'stage2_cost_launcher_test_r2'
        self.suite = self.root / 'result/hkbz_train_logs' / self.tag
        self.env = dict(os.environ, PATH=str(self.bin), RUN_TAG=self.tag,
                        PYTHON=str(self.bin / 'fake-python'), DRY_RUN='0',
                        STAGE2_TEST_EVENTS=str(self.events))

    def launch(self, **environment):
        return subprocess.run([str(self.bin / 'bash'), str(self.launcher)],
                              env=dict(self.env, **environment), text=True,
                              capture_output=True, timeout=10, check=False)

    def read_events(self):
        return [json.loads(row) for row in self.events.read_text().splitlines()]

    def test_service_inherits_checked_path_and_keeps_resource_contract(self):
        result = self.launch()
        self.assertEqual(result.returncode, 0, result.stderr)
        events = self.read_events()
        service = next(row for row in events if row['command'] == 'systemd-run')
        prepare = next(row for row in events if row['command'] == 'fake-python')
        self.assertEqual(service['service_path'], prepare['path'])
        self.assertEqual(service['service_rg'], str(self.bin / 'rg'))
        for option in ('--user', '--setenv=CUDA_VISIBLE_DEVICES=0',
                       '--property=AllowedCPUs=0-31,64-95',
                       '--property=CPUAffinity=0-31,64-95',
                       '--property=Restart=no', '--property=RuntimeMaxSec=172800'):
            self.assertIn(option, service['args'])
        self.assertEqual(service['args'].count('--setenv=PATH=' + str(self.bin)), 1)

    def test_missing_dependency_fails_before_preparation(self):
        (self.bin / 'rg').unlink()
        result = self.launch()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Missing required command in Stage2 service PATH: rg', result.stderr)
        self.assertFalse(self.events.exists())
        self.assertFalse(self.suite.exists())

    def test_missing_python_fails_before_preparation(self):
        result = self.launch(PYTHON=str(self.root / 'missing-python'))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Python is not an executable file', result.stderr)
        self.assertFalse(self.events.exists())
        self.assertFalse(self.suite.exists())

    def test_existing_suite_is_preserved(self):
        self.suite.mkdir(parents=True)
        artifact = self.suite / 'existing.txt'
        artifact.write_text('preserve me')
        result = self.launch()
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Never reuse an experiment directory', result.stderr)
        self.assertEqual(artifact.read_text(), 'preserve me')
        self.assertFalse(self.events.exists())

    def test_dry_run_prepares_without_starting_service(self):
        result = self.launch(DRY_RUN='1')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue((self.suite / 'manifest.json').exists())
        self.assertNotIn('systemd-run', [row['command'] for row in self.read_events()])

    def test_invalid_run_tag_cannot_create_output(self):
        result = self.launch(RUN_TAG='../invalid')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Invalid run tag', result.stderr)
        self.assertFalse(self.events.exists())


if __name__ == '__main__':
    unittest.main()
