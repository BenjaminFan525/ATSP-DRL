"""Bounded orchestration-only tests: no CUDA, environment episodes, or updates."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from onpolicy.scripts.train import continue_stage2_resource_rl_v5 as continuation
from onpolicy.scripts.train.control_stage2_resource_rl_v5 import Controller
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS, PROTOCOL


def evidence():
    manifest = dict(protocol=PROTOCOL, training_contract=copy.deepcopy(DEFAULTS),
                    source=dict(path='immutable_B0.pt', sha256='unchanged'))
    reports = {a: dict(arm=a, passed=True, completed_case_episodes=24,
        source_checkpoint=copy.deepcopy(manifest['source']),
        restored_weights_adam_rng_and_forward_equal=True, frozen_reference_unchanged=True,
        scientific_updates_discarded=True, fresh_production_initialization_required=True,
        minibatch_checks=dict(events=945, max_logp_error=0., max_ratio_error=0.),
        gradient_checks=dict(actor_backwards=8, critic_updates=50,
            resource_encoder_nonzero=8 if a in ('E1', 'E3') else 0,
            value_encoder_nonzero=50 if a in ('E2', 'E3') else 0),
        trajectory_action_sha256='same_initial_trajectory',
        trajectory_cases=[[f'case_{i:04d}', 100., 10] for i in range(24)]) for a in ARMS}
    status = dict(status='budget_blocked', phase='engineering', completed_training_case_episodes=0,
                  completed_physical_case_episodes=96, attempted_physical_case_episodes=96,
                  worker_exit_records=[dict(phase='engineering', arm=a, exit_code=0) for a in ARMS])
    return manifest, status, reports


class ContinuationTests(unittest.TestCase):
    def test_only_remaining_original_scope_is_authorized(self):
        m, s, r = evidence()
        proof = continuation.validate_stop_point(m, s, r)
        self.assertTrue(proof['passed'])
        self.assertEqual(proof['remaining_case_episodes'], 300 + 240 + 960 + 720)
        self.assertEqual(proof['remaining_training_case_episodes'], 960)
        self.assertEqual(proof['initialize_training_from'], 'immutable_B0')
        self.assertFalse(proof['repeat_engineering'])

    def test_advanced_or_incomplete_stop_is_rejected(self):
        for key, value in [('status', 'running'), ('phase', 'initial_evaluation_and_reference'),
                           ('completed_training_case_episodes', 24),
                           ('completed_physical_case_episodes', 95),
                           ('attempted_physical_case_episodes', 120)]:
            with self.subTest(key=key):
                m, s, r = evidence()
                s[key] = value
                with self.assertRaises(ValueError):
                    continuation.validate_stop_point(m, s, r)

    def test_incomplete_or_reused_engineering_weights_rejected(self):
        for key, value in [('passed', False), ('completed_case_episodes', 23),
                           ('source_checkpoint', {}),
                           ('restored_weights_adam_rng_and_forward_equal', False),
                           ('frozen_reference_unchanged', False),
                           ('scientific_updates_discarded', False),
                           ('fresh_production_initialization_required', False)]:
            with self.subTest(key=key):
                m, s, r = evidence()
                r['E0'][key] = value
                with self.assertRaises(ValueError):
                    continuation.validate_stop_point(m, s, r)

    def test_probability_and_nan_evidence_fail_closed(self):
        for key, value in [('events', 0), ('max_logp_error', 2e-6),
                           ('max_ratio_error', 2e-5), ('max_logp_error', float('nan'))]:
            with self.subTest(key=key, value=value):
                m, s, r = evidence()
                r['E1']['minibatch_checks'][key] = value
                with self.assertRaises(ValueError):
                    continuation.validate_stop_point(m, s, r)

    def test_gradient_restore_and_exit_evidence_required(self):
        for arm, key in [('E0', 'actor_backwards'), ('E0', 'critic_updates'),
                         ('E1', 'resource_encoder_nonzero'), ('E2', 'value_encoder_nonzero')]:
            with self.subTest(arm=arm, key=key):
                m, s, r = evidence()
                r[arm]['gradient_checks'][key] = 0
                with self.assertRaises(ValueError):
                    continuation.validate_stop_point(m, s, r)
        m, s, r = evidence()
        s['worker_exit_records'][0]['exit_code'] = 1
        with self.assertRaises(ValueError):
            continuation.validate_stop_point(m, s, r)

    def test_actor_trajectory_and_contract_must_be_unchanged(self):
        m, s, r = evidence()
        r['E3']['trajectory_action_sha256'] = 'different'
        with self.assertRaises(ValueError):
            continuation.validate_stop_point(m, s, r)
        m, s, r = evidence()
        m['training_contract']['rounds'] += 1
        with self.assertRaises(ValueError):
            continuation.validate_stop_point(m, s, r)

    def test_engineering_never_launched_and_other_phases_delegate(self):
        controller = continuation.BudgetController.__new__(continuation.BudgetController)
        with patch.object(Controller, 'batch', return_value='delegated') as batch:
            controller.batch('engineering', ['E0', 'E1'])
            controller.batch('engineering', ['E2', 'E3'])
            batch.assert_not_called()
            self.assertEqual(controller.batch('setup', ['E0']), 'delegated')
            batch.assert_called_once_with('setup', ['E0'])
        with self.assertRaises(RuntimeError):
            controller.launch('engineering', 'E0', 0)
        with self.assertRaises(ValueError):
            controller.batch('engineering', ['E0', 'E3'])

    def test_inherited_budget_gates_still_block(self):
        controller = continuation.BudgetController.__new__(continuation.BudgetController)
        with patch.object(Controller, 'batch', side_effect=TimeoutError('old error text')):
            with self.assertRaisesRegex(TimeoutError, '30-hour'):
                controller.batch('train', ['E0', 'E1'])
        with patch.object(controller, 'validate_continuation') as check:
            with patch.object(Controller, 'run', return_value=2) as run:
                self.assertEqual(controller.run(), 2)
                check.assert_called_once()
                run.assert_called_once()

    def test_new_clock_and_cumulative_status_include_retained_cases_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            m, _, _ = evidence()
            m.update(resource_contract=dict(runtime_max_seconds=108000),
                budget_continuation=dict(version=continuation.VERSION, parent='old_run',
                    authorized_runtime_seconds=108000, remaining_case_episode_limit=2220,
                    inherited_worker_exit_records=[dict(phase='engineering', arm=a, exit_code=0) for a in ARMS]))
            atomic_json(root / 'manifest.json', m)
            with patch('onpolicy.scripts.train.control_stage2_resource_rl_v5.time.time', return_value=200000.):
                controller = continuation.BudgetController(root / 'manifest.json')
                self.assertEqual(controller.started, 200000.)
                self.assertEqual(controller.deadline, 308000.)
                self.assertEqual(controller.process_started, controller.started)
                for a in ARMS:
                    atomic_json(root / 'engineering' / a / 'run_status.json', dict(
                        completed_physical_case_episodes=24, attempted_physical_case_episodes=24))
                atomic_json(root / 'workers/setup/run_status.json', dict(
                    completed_physical_case_episodes=12, attempted_physical_case_episodes=24))
                controller.status(status='running')
            status = json.loads((root / 'run_status.json').read_text())
            self.assertEqual(status['completed_physical_case_episodes'], 108)
            self.assertEqual(status['attempted_physical_case_episodes'], 120)
            self.assertEqual(status['completed_physical_case_episodes_this_process'], 12)
            self.assertEqual(status['completed_training_case_episodes'], 0)
            self.assertEqual(status['retained_engineering_case_episodes'], 96)
            self.assertEqual(status['authorized_runtime_seconds'], 108000)
            self.assertTrue(all(r['retained_from_previous_process'] for r in status['worker_exit_records']))

    def test_new_clock_cannot_be_silently_extended(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            m, _, _ = evidence()
            m.update(resource_contract=dict(runtime_max_seconds=108001),
                budget_continuation=dict(version=continuation.VERSION,
                    authorized_runtime_seconds=108001, remaining_case_episode_limit=2220))
            atomic_json(root / 'manifest.json', m)
            with self.assertRaises(ValueError):
                continuation.BudgetController(root / 'manifest.json')

    def test_changed_data_or_resource_scope_cannot_validate(self):
        old, _, _ = evidence()
        old.update(stage1_source={}, train={'cases': []}, evaluation={}, execution={}, screen={},
                   resource_contract=dict(gpu=0, runtime_max_seconds=86400))
        for key in ('train', 'resource_contract'):
            with self.subTest(key=key):
                controller = continuation.BudgetController.__new__(continuation.BudgetController)
                controller.m = copy.deepcopy(old)
                controller.m['resource_contract']['runtime_max_seconds'] = 108000
                controller.m['budget_continuation'] = dict(parent='parent')
                controller.m[key]['unauthorized_change'] = True
                with patch.object(continuation, 'read_parent', return_value=(old, None, None, None)):
                    with self.assertRaises(ValueError):
                        controller.validate_continuation()


if __name__ == '__main__':
    unittest.main()
