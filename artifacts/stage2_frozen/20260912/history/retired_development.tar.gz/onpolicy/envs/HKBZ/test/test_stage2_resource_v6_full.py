"""CPU-only full-data orchestration contracts; no scientific episodes or updates."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from onpolicy.scripts.train.run_stage2_resource_v6_full import FullSuite
from onpolicy.utils.stage2_resource_v6_full import (
    CONTRACT, PROTOCOL, RESOURCE, USER_REQUEST, assert_replayed_subset,
    case_batches, checkpoint_progress, execution_contract, pilot_observation,
    validate_plan, validate_teacher_parts,
)


def fixture():
    def rows(prefix, count):
        return [dict(case_dir=f'{prefix}_{i}', case_sha256=hashlib.sha256(f'{prefix}_{i}'.encode()).hexdigest(),
            distribution=('iid', 'ood_stress', 'ood_scale')[i % 3]) for i in range(count)]
    train, dev = rows('train', 240), rows('dev', 60)
    pilot = {k: dict(identity=k) for k in ('source', 'stage1_source', 'ready_source',
        'teacher_index', 'teacher_index_sha256', 'teacher_files', 'environment_argv',
        'archived_teachers', 'diagnostic_cases', 'iga_reference')}
    pilot.update(train=dict(cases=train), evaluation=dict(cases=dev), pilot_train=train[:48],
        screen=dict(maximum_mean_regression_vs_b0=.005, maximum_group_regression=.01,
            maximum_tail_regression=.01, minimum_gradient_steps=80))
    report = dict(endpoint=10, results={arm: dict(actor_steps=80, screen_passed=False,
        comparison=dict(relative_improvement=-.02), first_epoch_online_training_loss=1.,
        final_epoch_online_training_loss=.8) for arm in ('S1', 'S2')})
    parts = [dict(path=f'batch_{i}.pt', stateless_path=f'batch_{i}_stateless.pt',
        sha256='a' * 64, stateless_sha256='a' * 64, cases=[r['case_dir'] for r in group],
        role_free_counts=dict(ordinary=1, transporter=1))
        for i, group in enumerate(case_batches(train[:48], 6), 1)]
    manifest = copy.deepcopy(pilot)
    manifest.update(protocol=PROTOCOL, training_contract=copy.deepcopy(CONTRACT),
        resource_contract=copy.deepcopy(RESOURCE), execution=execution_contract(),
        authorization=dict(user_request=USER_REQUEST, mode='explicit_manual_exploratory_extension',
            automatic_promotion=False), pilot_observation=pilot_observation(report),
        teacher_reuse=dict(parts=parts, case_episodes=48, read_only=True,
            counted_as_new_environment_episodes=False),
        pilot_teacher_manifest=dict(path='pilot_teacher.json', sha256='a' * 64),
        data_roles=dict(train_cases=240, development_cases=60,
            historical_case_order_preserved=True, development_only=True,
            gate120_accessed=False, finalblind60_accessed=False, selection_uses_outcomes=False),
        screen=pilot['screen'] | {'minimum_gradient_steps': 400, 'scientific_goal_certified_by_full_run': False})
    return manifest, pilot, report


class FullContractTests(unittest.TestCase):
    def test_explicit_extension_preserves_failed_pilot(self):
        m, p, report = fixture()
        before = copy.deepcopy(report)
        validate_plan(m, p, report)
        self.assertEqual(report, before)
        self.assertFalse(m['pilot_observation']['S1']['screen_passed'])
        self.assertFalse(m['pilot_observation']['S2']['screen_passed'])

    def test_no_silent_promotion_or_relabelled_result(self):
        for field in ('authorization', 'pilot_observation'):
            with self.subTest(field=field):
                m, p, report = fixture()
                if field == 'authorization':
                    m[field]['automatic_promotion'] = True
                else:
                    m[field]['S1']['screen_passed'] = True
                with self.assertRaises(ValueError):
                    validate_plan(m, p, report)

    def test_incomplete_pilot_cannot_be_relabelled_complete(self):
        _, _, report = fixture()
        report['results']['S1']['actor_steps'] = 79
        with self.assertRaises(ValueError):
            pilot_observation(report)

    def test_contract_rejects_wrong_data_budget_and_resources(self):
        for field in ('train', 'training_contract', 'execution', 'resource_contract', 'data_roles'):
            with self.subTest(field=field):
                m, p, report = fixture()
                if field == 'train':
                    m[field]['cases'].reverse()
                elif field == 'training_contract':
                    m[field]['training_cases'] = 600
                elif field == 'execution':
                    m[field]['automatic_ppo'] = True
                elif field == 'resource_contract':
                    m[field]['gpu'] = 1
                else:
                    m[field]['finalblind60_accessed'] = True
                with self.assertRaises(ValueError):
                    validate_plan(m, p, report)

    def test_environment_reuse_and_offline_budgets_are_distinct(self):
        e = execution_contract()
        self.assertEqual(e['total_case_episode_limit'], 16 + 60 + 192 + 2 * 60 * 4)
        self.assertEqual(e['logical_case_episode_budget_including_reuse'], 748 + 48)
        self.assertEqual(e['actor_steps_per_arm'], 240 // 6 * 10)
        self.assertEqual(e['total_supervised_case_presentations'], 240 * 10 * 2)

    def test_checkpoint_counts_use_40_not_eight(self):
        self.assertEqual(checkpoint_progress(40)['completed_bc_epochs'], 1)
        self.assertEqual(checkpoint_progress(80)['completed_bc_epochs'], 2)
        self.assertEqual(checkpoint_progress(399)['updates_in_current_epoch'], 39)
        self.assertEqual(checkpoint_progress(400)['completed_bc_epochs'], 10)
        with self.assertRaises(ValueError):
            checkpoint_progress(401)

    def test_tune_groups_preserve_canonical_six_case_membership(self):
        m, _, _ = fixture()
        rows = m['evaluation']['cases']
        groups = case_batches(rows, 12)
        self.assertEqual(len(groups), 5)
        self.assertEqual([half for g in groups for half in case_batches(g, 6)], case_batches(rows, 6))
        with self.assertRaises(ValueError):
            case_batches(rows[:-1], 12)

    def test_reused_teacher_order_and_hash_are_required(self):
        m, _, _ = fixture()
        parts = m['teacher_reuse']['parts']
        validate_teacher_parts(parts, m['train']['cases'][:48])
        parts[0]['cases'].reverse()
        with self.assertRaises(ValueError):
            validate_teacher_parts(parts, m['train']['cases'][:48])

    def test_overlap_baseline_replay_is_strict(self):
        old = [dict(case_dir='one', case_sha256='one_hash', makespan=10., steps=3)]
        self.assertTrue(assert_replayed_subset(old, copy.deepcopy(old))['passed'])
        for change in ({'makespan': 10.01}, {'steps': 4}, {'case_sha256': 'different'}):
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                assert_replayed_subset(old, [old[0] | change])

    def test_full_evaluation_covers_all60_without_extra_concurrency(self):
        m, _, _ = fixture()
        with tempfile.TemporaryDirectory() as temporary:
            suite = FullSuite.__new__(FullSuite)
            suite.m, suite.c, suite.root = m, CONTRACT, Path(temporary)
            suite.learners, suite.progress = {}, Mock()
            observed = []
            def collect(learner, group, label, **kwargs):
                observed.append(group)
                return dict(cases=[r | dict(makespan=100 + int(r['case_dir'].split('_')[-1]),
                    steps=3, completed=True, timeout=False, cycle_terminated=False) for r in group],
                    frames=[], label_audit=[], seconds=1., environment_events=36, checks={})
            suite.collect = collect
            result = suite.evaluate(None, 'B0_AR_tune60')
            output = json.loads((suite.root / 'evaluations/B0_AR_tune60.json').read_text())
            self.assertEqual([len(g) for g in observed], [12] * 5)
            self.assertEqual(len(result), 60)
            self.assertEqual(output['summary']['mean'], 129.5)
            self.assertEqual(output['summary']['tail10'], 156.5)
            self.assertTrue(output['development_only'])
            self.assertFalse(output['independent_confirmation'])

    def test_complete_schedule_is_400_steps_each_and_evaluates_fixed_epochs(self):
        m, _, _ = fixture()
        rows = [r | dict(makespan=100., steps=3, completed=True, timeout=False, cycle_terminated=False)
                for r in m['evaluation']['cases']]
        calls = []
        class Learner:
            def __init__(self, arm):
                self.arm, self.actor_steps, self.checks = arm, 0, {}
                self.policy = SimpleNamespace(ac=SimpleNamespace(state_dict=lambda: {}))
            def bc_epoch_batch(self, rollout):
                self.actor_steps += 1
                calls.append(('update', self.arm, self.actor_steps))
                return dict(loss=1 / self.actor_steps, actor_steps=self.actor_steps)
        with tempfile.TemporaryDirectory() as temporary:
            suite = FullSuite.__new__(FullSuite)
            suite.m, suite.c, suite.root = m, CONTRACT, Path(temporary)
            suite.completed, suite.learners, suite.progress = 748, {}, Mock()
            suite.write_ledger = Mock()
            suite.policy = Learner
            def checkpoint(learner, name):
                calls.append(('checkpoint', learner.arm, name))
                return suite.root / learner.arm / name
            def evaluate(learner, label):
                calls.append(('evaluate', learner.arm, label))
                return rows
            suite.checkpoint, suite.evaluate = checkpoint, evaluate
            dataset = [dict(path='teacher.pt', sha256='a' * 64,
                stateless_path='stateless.pt', stateless_sha256='a' * 64)] * 40
            with patch('onpolicy.scripts.train.run_stage2_resource_v6_full.file_sha', return_value='a' * 64), \
                 patch('onpolicy.scripts.train.run_stage2_resource_v6_full.torch.load', return_value={'model': {}}), \
                 patch('onpolicy.scripts.train.run_stage2_resource_v6_full.os.sched_setaffinity'):
                suite.train(dataset, rows)
            self.assertEqual({a: l.actor_steps for a, l in suite.learners.items()}, {'S1': 400, 'S2': 400})
            steps = [r[1] for r in calls if r[0] == 'update']
            self.assertEqual(steps, ['S1', 'S2'] * 400)
            evaluated = [r[2] for r in calls if r[0] == 'evaluate']
            self.assertEqual(evaluated, [f'{a}_epoch_{e}_tune60' for e in (0, 1, 5, 10) for a in ('S1', 'S2')])
            for e in (1, 5, 10):
                first_eval = calls.index(('evaluate', 'S1', f'S1_epoch_{e}_tune60'))
                for a in ('S1', 'S2'):
                    self.assertLess(calls.index(('checkpoint', a, f'checkpoint_epoch_{e}.pt')), first_eval)
            final = json.loads((suite.root / 'full_report.json').read_text())
            self.assertFalse(final['confirmed_scientific_success'])
            self.assertFalse(final['automatic_ppo'])
            self.assertTrue(final['manual_exploratory_extension'])

    def test_teacher_reuse_collects_only_the_other192_cases(self):
        m, _, _ = fixture()
        with tempfile.TemporaryDirectory() as temporary:
            suite = FullSuite.__new__(FullSuite)
            suite.m, suite.c, suite.root = m, CONTRACT, Path(temporary)
            suite.reused_teacher_cases, suite.new_teacher_cases = 0, 0
            suite.ledger, suite.write_ledger = [], Mock()
            collected = []
            def collect(learner, group, label, **kwargs):
                self.assertTrue(kwargs['store'] and kwargs['teacher'])
                suite.new_teacher_cases += len(group)
                collected.extend(r['case_dir'] for r in group)
                return dict(cases=group, label_audit=[])
            suite.collect = collect
            base = SimpleNamespace(pack_stateless=lambda _: dict(stateless_records={
                r: dict(target=[1]) for r in ('ordinary', 'transporter')}))
            with patch('onpolicy.scripts.train.run_stage2_resource_v6_full.save_tensor_artifact'), \
                 patch('onpolicy.scripts.train.run_stage2_resource_v6_full.file_sha', return_value='a' * 64):
                parts = suite.teacher_data(base)
            self.assertEqual(len(parts), 40)
            self.assertEqual(parts[:8], m['teacher_reuse']['parts'])
            self.assertEqual(collected, [r['case_dir'] for r in m['train']['cases'][48:]])
            self.assertEqual((suite.reused_teacher_cases, suite.new_teacher_cases), (48, 192))
            saved = json.loads((suite.root / 'teacher_data/manifest.json').read_text())
            self.assertEqual(saved['teacher_dataset_case_episodes'], 240)
            self.assertEqual(saved['physical_case_episodes_this_run'], 192)
            self.assertEqual(saved['reused_physical_case_episodes'], 48)

    def test_launcher_is_gpu0_original_half_no_auto_retry(self):
        root = Path(__file__).resolve().parents[4]
        text = (root / 'onpolicy/scripts/train/launch_stage2_resource_v6_full_gpu0.sh').read_text()
        for expected in ('CUDA_VISIBLE_DEVICES=0', 'AllowedCPUs=0-31,64-95',
                         'CPUAffinity=0-31,64-95', 'Restart=no', 'RuntimeMaxSec=infinity'):
            self.assertIn(expected, text)


if __name__ == '__main__':
    unittest.main()
