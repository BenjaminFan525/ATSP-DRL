"""No GPU/environment execution: explicit wall-clock waiver and safe handoff."""
import ast
import copy
import inspect
import json
import math
import signal
from pathlib import Path
import tempfile
import textwrap
import unittest
from unittest.mock import Mock, patch

from onpolicy.scripts.train import continue_stage2_resource_rl_v5_unlimited as continuation
from onpolicy.scripts.train.control_stage2_resource_rl_v5 import Controller
from onpolicy.scripts.train.run_stage2_resource_manifest_trial import atomic_json
from onpolicy.scripts.train.run_stage2_resource_rl_v5 import SplitSuite
from onpolicy.scripts.train.run_stage2_resource_rl_v5_unlimited import (
    UnlimitedProgress, UnlimitedSplitSuite, VERSION, require_time_authorization,
)
from onpolicy.utils.stage2_resource_rl import file_sha
from onpolicy.utils.stage2_resource_rl_v5 import ARMS, DEFAULTS


def authorized_scope():
    old = dict(training_contract=copy.deepcopy(DEFAULTS), source={'sha256': 'B0'},
        train={'cases': list(range(240))}, evaluation={'cases': list(range(60))},
        execution=dict(arms=list(ARMS), total_training_case_episodes=960, automatic_retry=False),
        code_fingerprint={'science.py': 'unchanged'}, resource_contract=dict(gpu=0,
            allowed_cpus='0-31,64-95', max_concurrent_trainers=2, runtime_max_seconds=108000))
    new = copy.deepcopy(old)
    new['resource_contract']['runtime_max_seconds'] = None
    new['time_limit_removal'] = dict(version=VERSION, user_request='解除超时门禁',
        wall_clock_limit_enabled=False, projected_time_gate_enabled=False)
    return old, new


def setup_evidence(root):
    rows = [dict(case_sha256=f'eval_{i}', makespan=100 + i, steps=10) for i in range(60)]
    historical = root / 'historical.json'
    atomic_json(historical, {'cases': rows})
    m = dict(historical_b0_ar={'path': str(historical)}, source={'sha256': 'B0'},
        evaluation={'cases': [{**r, 'finish_steps': r['steps']} for r in rows]},
        train=dict(cases=[dict(case_sha256=f'train_{i}') for i in range(240)],
                   collection_batches=[list(range(i, i + 24)) for i in range(0, 240, 24)]))
    atomic_json(root / 'workers/setup/run_status.json', dict(status='completed', phase='setup',
        completed_physical_case_episodes=540, attempted_physical_case_episodes=540,
        completed_training_case_episodes=0))
    atomic_json(root / 'checks/setup_complete.json', dict(passed=True, completed_case_episodes=540))
    zero = {a: dict(passed=True, cases=60,
        conditional_reference=dict(events=2958, max_logp_error=0, max_hidden_error=0),
        replay_checks=dict(events=320, max_logp_error=0, max_ratio_error=0,
                           masks_equal=True, actions_equal=True)) for a in ARMS}
    atomic_json(root / 'checks/zero_update.json', zero)
    for arm in ARMS:
        atomic_json(root / 'evaluations' / f'{arm}_initial_AR.json', {'cases': rows})
    atomic_json(root / 'evaluations/B0_H.json', {'cases': rows})
    atomic_json(root / 'checks/b0_hungarian.json', dict(passed=True, cases=60, tolerance=0))
    parts = []
    for index, indices in enumerate(m['train']['collection_batches'], 1):
        path = root / 'reference' / f'raw_graph_pool_{index}.pt'
        atomic_json(path, dict(synthetic_hash_fixture=index))
        parts.append(dict(path=str(path), sha256=file_sha(path), states=768))
        cases = [dict(case_sha256=m['train']['cases'][i]['case_sha256'],
                      completed=True, timeout=False, cycle_terminated=False) for i in indices]
        atomic_json(root / 'reference' / f'batch_{index}.json', {'cases': cases})
    atomic_json(root / 'reference/manifest.json', dict(case_episodes=240, max_states_per_case=32,
        source=m['source'], observable_only=True, decoder='hungarian', cost_labels=0, parts=parts))
    return m


class UnlimitedTimeTests(unittest.TestCase):
    def test_explicit_authorization_is_mandatory(self):
        old, new = authorized_scope()
        require_time_authorization(new)
        with self.assertRaises(ValueError):
            require_time_authorization(old)
        for key, value in [('user_request', 'continue'), ('wall_clock_limit_enabled', True),
                           ('projected_time_gate_enabled', True), ('version', 'unknown')]:
            changed = copy.deepcopy(new)
            changed['time_limit_removal'][key] = value
            with self.assertRaises(ValueError):
                require_time_authorization(changed)

    def test_only_wallclock_can_change(self):
        old, new = authorized_scope()
        continuation.validate_unchanged_scope(new, old)
        for section, key, value in [('training_contract', 'rounds', 20),
            ('resource_contract', 'gpu', 1), ('resource_contract', 'max_concurrent_trainers', 4),
            ('resource_contract', 'allowed_cpus', '0-127'), ('execution', 'automatic_retry', True),
            ('execution', 'total_training_case_episodes', 1920), ('code_fingerprint', 'science.py', 'modified')]:
            changed = copy.deepcopy(new)
            changed[section][key] = value
            with self.assertRaises(ValueError):
                continuation.validate_unchanged_scope(changed, old)

    def test_expired_budget_is_informational_without_changing_projection(self):
        reports = {a: dict(collection_seconds=100, update_seconds=200,
                          critic_50_steps_seconds=10) for a in ARMS}
        projection = continuation.informational_budget(reports, -100, 20)
        self.assertTrue(projection['passed'])
        self.assertFalse(projection['enforced'])
        self.assertFalse(projection['would_pass_superseded_deadline'])
        self.assertEqual(projection['projected_seconds'], 1.25 * (6120 + 14400))
        self.assertIsNone(projection['remaining_seconds'])
        json.dumps(projection, allow_nan=False)

    def test_progress_never_times_out_and_json_has_no_infinity(self):
        with tempfile.TemporaryDirectory() as temp, patch('onpolicy.scripts.train.run_stage2_resource_rl.threading.Thread'):
            progress = UnlimitedProgress(Path(temp))
            progress.started -= 10**12
            progress('collect', force=True, completed_cases=1)
            state = json.loads((Path(temp) / 'run_status.json').read_text())
            self.assertIsNone(state['hard_deadline_unix'])
            self.assertFalse(state['wall_clock_limit_enabled'])
            self.assertGreater(state['elapsed_seconds'], 10**11)
            json.dumps(state, allow_nan=False)
            progress.stop.set()

    def test_scientific_methods_and_batch_failure_logic_are_inherited(self):
        for name in ('policy', 'train_one', 'collect_batch', 'evaluate', 'checkpoint'):
            self.assertIs(getattr(UnlimitedSplitSuite, name), getattr(SplitSuite, name))
        self.assertIs(continuation.UnlimitedController.batch, Controller.batch)
        controller = continuation.UnlimitedController.__new__(continuation.UnlimitedController)
        with self.assertRaises(RuntimeError):
            controller.launch('setup', 'E0', 0)
        with self.assertRaises(RuntimeError):
            controller.launch('engineering', 'E0', 0)

    def test_worker_initialization_and_error_cleanup_remain_identical(self):
        def body(method):
            return ast.parse(textwrap.dedent(inspect.getsource(method))).body[0].body
        old = next(node for node in body(SplitSuite.run) if isinstance(node, ast.Try))
        new = next(node for node in body(UnlimitedSplitSuite.run) if isinstance(node, ast.Try))
        def first_completed(nodes):
            return next(i for i, node in enumerate(nodes) if isinstance(node, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == 'completed' for t in node.targets))
        oi, ni = first_completed(old.body), first_completed(new.body)
        dump = lambda nodes: ast.dump(ast.Module(body=nodes, type_ignores=[]), include_attributes=False)
        self.assertEqual(dump(old.body[:oi]), dump(new.body[:ni]))
        self.assertEqual(dump(old.body[oi + 2:]), dump(new.body[ni + 1:]))
        self.assertEqual(dump(old.handlers), dump(new.handlers))
        self.assertEqual(dump(old.finalbody), dump(new.finalbody))
        self.assertEqual(ast.unparse(new.body[ni].value), 'self.train_one()')
        alarms = [node for node in ast.walk(ast.Module(body=body(UnlimitedSplitSuite.run), type_ignores=[]))
                  if isinstance(node, ast.Call) and ast.unparse(node.func) == 'signal.alarm']
        self.assertTrue(alarms)
        self.assertTrue(all(len(n.args) == 1 and isinstance(n.args[0], ast.Constant) and n.args[0].value == 0 for n in alarms))

    def test_all_complete_setup_evidence_is_required(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            m = setup_evidence(root)
            proof = continuation.validate_completed_setup(root, m)
            self.assertEqual(proof['remaining_case_episodes'], 1680)
            self.assertFalse(proof['setup_repeated'])
            state = continuation.read(root / 'workers/setup/run_status.json')
            for key, value in [('status', 'failed'), ('completed_physical_case_episodes', 539),
                               ('attempted_physical_case_episodes', 552), ('completed_training_case_episodes', 24)]:
                atomic_json(root / 'workers/setup/run_status.json', {**state, key: value})
                with self.assertRaises(ValueError):
                    continuation.validate_completed_setup(root, m)
            atomic_json(root / 'workers/setup/run_status.json', state)

    def test_non_time_numerical_and_raw_pool_gates_remain_strict(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            m = setup_evidence(root)
            zero = continuation.read(root / 'checks/zero_update.json')
            for value in (1.01e-6, float('nan')):
                changed = copy.deepcopy(zero)
                changed['E3']['conditional_reference']['max_logp_error'] = value
                original_read = continuation.read
                with patch.object(continuation, 'read', side_effect=lambda path:
                        changed if path == root / 'checks/zero_update.json' else original_read(path)):
                    with self.assertRaises(ValueError):
                        continuation.validate_completed_setup(root, m)
            atomic_json(root / 'checks/zero_update.json', zero)
            atomic_json(root / 'reference/raw_graph_pool_1.pt', {'changed': True})
            with self.assertRaises(ValueError):
                continuation.validate_completed_setup(root, m)

    def test_wrong_or_incomplete_reference_trajectory_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            m = setup_evidence(root)
            path = root / 'reference/batch_1.json'
            original = continuation.read(path)
            for key, value in [('completed', False), ('timeout', True), ('cycle_terminated', True),
                               ('case_sha256', 'other_case')]:
                changed = copy.deepcopy(original)
                changed['cases'][0][key] = value
                atomic_json(path, changed)
                with self.assertRaises(ValueError):
                    continuation.validate_completed_setup(root, m)

    def test_controller_status_records_no_deadline_and_full_accounting(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            controller = continuation.UnlimitedController.__new__(continuation.UnlimitedController)
            controller.root, controller.started, controller.process_started = root, 0, 0
            controller.deadline, controller.records, controller.phase = math.inf, [], 'stage_b_training'
            for arm in ARMS:
                atomic_json(root / 'engineering' / arm / 'run_status.json', dict(
                    completed_physical_case_episodes=24, attempted_physical_case_episodes=24))
            atomic_json(root / 'workers/setup/run_status.json', dict(
                completed_physical_case_episodes=540, attempted_physical_case_episodes=540))
            controller.status()
            state = continuation.read(root / 'run_status.json')
            self.assertEqual(state['completed_physical_case_episodes'], 636)
            self.assertEqual(state['lifetime_attempted_physical_case_episodes'], 660)
            self.assertEqual(state['lifetime_attempted_case_episode_limit'], 2340)
            self.assertIsNone(state['hard_deadline_unix'])
            self.assertFalse(state['automatic_retry'])
            json.dumps(state, allow_nan=False)

    def test_original_failure_halts_pending_training_even_without_deadline(self):
        with tempfile.TemporaryDirectory() as temp:
            controller = continuation.UnlimitedController.__new__(continuation.UnlimitedController)
            controller.root, controller.deadline = Path(temp), math.inf
            controller.jobs, controller.records, controller.m = {}, [], {}
            controller.status = Mock()
            def launch(phase, arm, slot):
                controller.jobs[slot] = (Mock(poll=Mock(return_value=1)), Mock(), phase, arm)
            controller.launch = Mock(side_effect=launch)
            with patch('onpolicy.scripts.train.control_stage2_resource_rl_v5.analyze'):
                with self.assertRaises(RuntimeError):
                    controller.batch('train', ['E0', 'E1'])
            self.assertEqual(controller.launch.call_count, 1)
            self.assertTrue((Path(temp) / 'halt_after_current_round.json').exists())

    def test_recovery_never_signals_after_handoff_or_changed_pid(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with patch.object(continuation, 'PinnedProcess') as process:
                continuation.recover_paused_scheduler(root / 'authorization.json')
                process.assert_not_called()
            atomic_json(root / 'checks/active_handoff.json', {'passed': True})
            atomic_json(root / 'checks/handoff_completed.json', {'passed': True})
            with patch.object(continuation, 'PinnedProcess') as process:
                continuation.recover_paused_scheduler(root / 'authorization.json')
                process.assert_not_called()

    def test_handoff_pauses_only_scheduler_and_waits_for_successful_setup(self):
        with tempfile.TemporaryDirectory() as temp:
            root, parent = Path(temp), Path(temp) / 'parent'
            request = dict(parent=str(parent), original_control=dict(pid=100, started_unix=1),
                           user_request='解除超时门禁')
            atomic_json(root / 'authorization.json', request)
            atomic_json(parent / 'workers/setup/run_status.json', dict(pid=200, status='completed'))
            atomic_json(parent / 'manifest.json', {})
            scheduler = Mock(info=Mock(return_value={'state': 'T'}))
            worker = Mock(pid=200, start_ticks=123, info=Mock(return_value=dict(state='Z', exit_wait_status=0)))
            with patch.object(continuation, 'validate_request', return_value=(request, {})), \
                    patch.object(continuation, 'service_value', side_effect=['300', 'infinity', '100', '27h', '0']), \
                    patch.object(continuation, 'PinnedProcess', side_effect=[scheduler, worker]), \
                    patch.object(continuation.subprocess, 'run') as systemd, \
                    patch.object(continuation, 'validate_completed_setup'), \
                    patch.object(continuation, 'finalize_manifest', return_value=root / 'manifest.json') as finalize, \
                    patch.object(continuation, 'UnlimitedController') as controller, \
                    patch.object(continuation.os, 'sched_setaffinity'), \
                    patch.object(continuation.os, 'sched_getaffinity', return_value={30}), \
                    patch.object(continuation.os, 'getpid', return_value=300), \
                    patch.object(continuation.signal, 'signal'), \
                    patch.dict(continuation.os.environ, {'CUDA_VISIBLE_DEVICES': '0',
                        'STAGE2_TIME_WAIVER_UNIT': 'hkbz-stage2-split-v5-20260909-gpu0-half-r7.service'}):
                controller.return_value.run.return_value = 0
                self.assertEqual(continuation.handoff(root / 'authorization.json'), 0)
                self.assertEqual([c.args[0] for c in scheduler.send.call_args_list],
                                 [signal.SIGSTOP, signal.SIGTERM, signal.SIGCONT])
                worker.send.assert_not_called()
                systemd.assert_not_called()
                self.assertEqual(finalize.call_args.args[1]['exit_code'], 0)
                controller.return_value.run.assert_called_once()

    def test_failed_setup_resumes_scheduler_and_never_starts_new_training(self):
        with tempfile.TemporaryDirectory() as temp:
            root, parent = Path(temp), Path(temp) / 'parent'
            request = dict(parent=str(parent), original_control=dict(pid=100, started_unix=1),
                           user_request='解除超时门禁')
            atomic_json(root / 'authorization.json', request)
            atomic_json(parent / 'workers/setup/run_status.json', dict(pid=200, status='failed'))
            scheduler = Mock(info=Mock(return_value={'state': 'T'}))
            worker = Mock(pid=200, start_ticks=123, info=Mock(return_value=dict(state='Z', exit_wait_status=256)))
            with patch.object(continuation, 'validate_request', return_value=(request, {})), \
                    patch.object(continuation, 'service_value', side_effect=['300', 'infinity', '100', '27h']), \
                    patch.object(continuation, 'PinnedProcess', side_effect=[scheduler, worker]), \
                    patch.object(continuation.subprocess, 'run'), \
                    patch.object(continuation, 'finalize_manifest') as finalize, \
                    patch.object(continuation, 'UnlimitedController') as controller, \
                    patch.object(continuation.os, 'sched_setaffinity'), \
                    patch.object(continuation.os, 'sched_getaffinity', return_value={30}), \
                    patch.object(continuation.os, 'getpid', return_value=300), \
                    patch.object(continuation.signal, 'signal'), \
                    patch.dict(continuation.os.environ, {'CUDA_VISIBLE_DEVICES': '0',
                        'STAGE2_TIME_WAIVER_UNIT': 'hkbz-stage2-split-v5-20260909-gpu0-half-r7.service'}):
                self.assertEqual(continuation.handoff(root / 'authorization.json'), 1)
                self.assertEqual([c.args[0] for c in scheduler.send.call_args_list],
                                 [signal.SIGSTOP, signal.SIGCONT])
                worker.send.assert_not_called()
                finalize.assert_not_called()
                controller.assert_not_called()


if __name__ == '__main__':
    unittest.main()
