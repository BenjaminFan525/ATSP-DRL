# Frozen-R1 Stage2 BC implementation and execution contract

Material Passport: experiment-agent / run / 2026-09-05 / stage2_bc_injection_v1.
Status: implementation and deterministic recovery validated. The first pilot
failed its historical-reference gate at 2026-09-05 16:00:51 CST, before any
trainer started. Controlled diagnosis is complete: two independent local
strict12 evaluations match exactly, while historical cross-configuration
replay differs. New pilot_r2 started at17:26 with the evidence-bound local
reference amendment. Its new-service preflight passed60/60 at zero tolerance;
B0/B1 trainers started at17:40:46 and are in pre-supervised baseline evaluation
as of17:41. B2 is queued; BC optimization results remain pending.
See `STAGE2_A3_REPLAY_DIAGNOSIS_20260905.md` for the subsequent audit.

## Scope

The next scientific run is the pilot, not the nine-job formal run. B0/B1/B2
use matching + margin supervision and the same frozen R1 head. B0 does not
inject time features; B1 injects DAG only; B2 injects DAG plus R1 predictions.
The shared encoder, plane policy, critics and predictor stay frozen. Only
resource actors and, for B1/B2, the timing projection are optimized. All
teacher actions are executed; PPO is disabled. B0 is a matched frozen-head
control, not an exact reproduction of historical joint-training A3.

R1 source SHA256:
`c0c4825946e469b680e764a4c4b9f3bcbcfdaa66ccfb2fee221633b5d3afb1f1`.
Stage1 source seed3 and H2/F4 teacher600 remain unchanged. Loading transfers
only the ready head, validates source/architecture/routing/scale/teacher
contracts, and starts a fresh resource optimizer with a zero projection.

## New interfaces

- `--device_bc_training_scope policy_frozen_ready`
- `--request_ready_checkpoint PATH --request_ready_checkpoint_sha256 SHA256`
- `--request_ready_loss_coef 0 --device_bc_eval_each_epoch`
- `--train_sampling_seed`: separates data selection/order from training seed.
- `--stage2_bc_deterministic`: strict deterministic CUDA algorithms and a
  deterministic cuBLAS workspace, enabled for all new suite profiles.

Shared evaluation now includes all reliable-head flags in architecture
reconstruction, metadata validation and the result cache key. This includes
hard Blocking routing even when tensor shapes do not change.

## Checkpoints and recovery

Every BC epoch receives a complete checkpoint and independent tune evaluation.
Eligibility requires complete validation with no cycles/timeouts, raw Cmax no
worse than the initial policy, and OOD-stress regression at most 30 seconds.
Missing strata are not silently accepted; the tiny canary may therefore have
no scientifically eligible checkpoint despite passing engineering checks.
Best/Stage2 artifacts contain the actual lowest-Cmax eligible epoch, not the
last epoch renamed to Best. The Last artifact retains the final training state.
Checkpoints retain pre-supervised metrics, optimizer parameter order, optimizer
moments, RNG state, source digests, data/optimizer/injection contract and prior
epoch selection records.

Recovery of the new mode accepts complete epoch boundaries only. A mid-rollout
emergency artifact is not advertised as exact recovery. Use the same manifest
configuration with `--resume_stage2 --checkpoint_dir checkpoint_BCEpoch1.pt`;
the next epoch cursor is restored automatically. Completed earlier epoch
artifacts must accompany a later boundary if needed for best-epoch selection.

## Profiles

| Profile | Arms/seeds | Data | BC epochs | Evaluation | Scientific use |
|---|---|---|---|---|---|
| canary | B2, seed11 | 2 cases, 2 workers | 2 | tune prefix4 | Engineering only |
| pilot | B0/B1/B2, seed11 | fixed 240 balanced cases, 24 workers | 2 | tune60 at epochs0/1/2 | Screen only |
| formal | B0/B1/B2, seeds1/2/3 | 600 unique cases, 960 balanced slots/epoch | 2 | tune60 at epochs0/1/2 | Requires pilot review |

The existing reliability holdout51 is not an independent end-to-end test after
policy training on train600. These commands do not access gate/finalblind.
Formal training is not automatically launched by a successful pilot.

## Resource isolation and monitoring

GPU0 only. The other experiment on GPU1 uses CPU 32-63,96-127; this suite owns
the disjoint CPU 0-31,64-95 half (64/128 logical CPUs, full SMT sibling pairs).
Two training lanes: 0-11,64-75 and 12-23,76-87. Shared evaluation:
24-29,88-93. Controller: 30-31,94-95. A systemd cgroup constrains the complete
process tree; per-process affinity subdivides it. GPU allocator limits are
0.40 per trainer and 0.10 for evaluation. Throughput, not occupied VRAM, is
the optimization criterion.

Heartbeat: 30 seconds. Output stall beyond 300 seconds is advisory. A declared
48-hour hard cap protects the pilot budget; evaluator startup is capped at
600 seconds. No automatic retry; a failed lane prevents pending jobs from
starting. Cleanup signals only process groups created by this suite.

## Commands and outputs

Entry: `bash onpolicy/scripts/train/launch_stage2_bc_injection_gpu0.sh`.
Set `PROFILE=canary|pilot|formal` and a fresh `RUN_TAG`. The default is pilot.
For the recovery check, additionally set `RESUME_CHECKPOINT` to the first
canary's `models/checkpoint_BCEpoch1.pt`; this is accepted only in canary mode.
The preparer rejects existing manifests/runs and records all Python/YAML source
hashes plus the launcher, not just the dirty worktree's Git commit.
Newly prepared suites also retain exactly those source files in a digest-bound
`source_bundle.tar.gz`; unrelated root files, credentials and model outputs
are not included. The existing dirty worktree and Git history are preserved.

Suite: `result/hkbz_train_logs/<RUN_TAG>/`:
`manifest.json`, `suite_status.json`, `records/`, `service_logs/`,
`hardware/runtime_usage.csv`, `analysis/comparison.json`, `analysis/paired_cases.csv`.
Each model run retains `evaluations/bc_epoch_N.json`, full BC epoch checkpoints,
epoch metrics and per-case/per-horizon ready sufficient statistics.

Before any pilot/formal trainer starts, the controller replays the historical
A3 checkpoint on tune60 (seed1, tau0.3). It requires all 60 case hashes and all
case-level Cmax values to match (absolute tolerance 1e-5 seconds), not merely
the aggregate mean 8340.605556 seconds. Evidence is retained in
`reference_a3.json` and `reference_a3_integrity.json`. A mismatch stops the
suite before resource-policy training and is not treated as a new result.

After the initial cross-configuration mismatch, an **explicit** local-reference
amendment was added. Both `REFERENCE_DIAGNOSTIC_DIR` and
`REFERENCE_NUMERIC_PROBE_DIR` are required. Two independent complete strict12
replays must match at zero tolerance, the historical-setting control must
complete, and fixed-input numerical evidence must demonstrate batch/arithmetic
sensitivity. Historical results and discrepancies are retained, not overwritten.
The amended manifest pins proof files, data contents and the numerical runtime;
the new suite still replays A3 before starting any trainer. Changing numerical
or environment source invalidates the proof. This does not relax the BC
eligibility thresholds or authorize a formal-nine-job launch.

The analyzer checks completed budgets, frozen tensor identity (including
critics), finite model tensors, case-hash pairing and complete evaluations.
Bootstrap uncertainty uses cases, conditional on observed training seeds;
request labels are never treated as independent scheduling experiments.

## Validation record

CPU regression: 100 tests passed, covering frozen-head transfer/scope,
zero-projection equivalence, finite gates, optimizer/RNG contracts, routing
cache keys, case pairing, strict historical replay, sampling and existing
Stage2/two-stage orchestration, resource research and lookahead dispatch.
Shell syntax and targeted diff checks passed. The complete command is:

```bash
PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
taskset -c 30-31,94-95 /home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11 -m unittest \
  onpolicy.envs.HKBZ.test.test_stage2_bc_injection \
  onpolicy.envs.HKBZ.test.test_stage2_supervised_pipeline \
  onpolicy.envs.HKBZ.test.test_stage2_transition \
  onpolicy.envs.HKBZ.test.test_train_sampling \
  onpolicy.envs.HKBZ.test.test_two_stage_orchestration \
  onpolicy.envs.HKBZ.test.test_stage2_iga_distill_ppo \
  onpolicy.envs.HKBZ.test.test_stage2_resource_research \
  onpolicy.envs.HKBZ.test.test_device_lookahead_dispatch -q
```

Static formal manifest check: 9 jobs, seeds1/2/3; each seed has 600 unique
cases and 960 slots (IID480 / stress432 / scale48). This was preparation only;
the formal run has not been launched.

Canary r1 (engineering only) was retained as a failed run. Frozen predictor
loading and initial evaluation passed, but a labeled state with no active
matching loss attempted backward on a constant. The optimizer now skips
constant/disabled losses, rejects non-finite gradients and verifies that each
epoch performs optimizer steps. Non-finite auxiliary metrics caused by absent
small-evaluation strata are serialized as null without relaxing the scientific
gate.

Canary r2 completed both training epochs and all three evaluations, but was
retained as failed because Best promotion exposed a NumPy-RNG serialization
incompatibility with weights-only checkpoint loading. New RNG snapshots use
builtins/tensors; a serialization round-trip test covers this. Explicit local
recovery supports the trusted legacy full canary state, converts copied epoch
artifacts to the portable representation, and preserves prior evaluation and
per-case evidence. Fresh recovery is validating finalization and equivalence.

During r2, only recovery/evidence bookkeeping and teacher-execution accounting
were patched; no training objective, model forward or data order was changed.
The old teacher-rate denominator counted finished padding environments as
student execution. The corrected metric counts live environments only; the
resource actions themselves are unchanged. Each suite retains its own code
fingerprint, and the forthcoming pilot is prepared only after these repairs.

Live canary and boundary-recovery results will be recorded below. Pilot launch
is conditional on passing these engineering checks and the historical replay.

The first recovery completed and passed frozen-state/budget/selection audits,
but did not pass bitwise replay: trainable weights differed by at most
1.192093e-7 and one of four evaluation cases differed by 160 seconds. Labels,
optimizer step counts and all previously persisted RNG streams matched.
This is retained as a numerical-reproducibility warning, not described as
exact replay. New trials enable strict deterministic computation in both the
trainer and evaluator, and restore optimizer state via CPU so Adam's CPU step
counters are not inadvertently moved to CUDA. They are being revalidated.

### Final deterministic validation (2026-09-05)

`stage2_bc_injection_20260905_gpu0_half_deterministic_r1` completed both epochs
and all three evaluations, including actual Best selection and frozen-state
integrity analysis. Each training epoch had 211 optimizer steps, 748 resource
labels and 100% teacher execution among live environments. Training took
about 68 seconds per epoch on the two-case engineering fixture.

`stage2_bc_injection_20260905_gpu0_half_deterministic_recovery_r1` restored
epoch1 and completed epoch2. Comparison against the uninterrupted run passed:

- All 508 model tensors were bitwise identical.
- Complete supervised Adam state was bitwise identical.
- Python, NumPy, Torch, CUDA and dedicated DAgger RNG streams were identical.
- All four case-level Cmax values were identical (maximum difference 0 seconds).
- Both runs passed the complete budget/frozen-scope/Best artifact audit.

This fixture is engineering-only; its Cmax is not a Stage2 research result.
Pilot tag: `stage2_bc_injection_20260905_gpu0_half_pilot_r1`. The pipeline first
executes the historical A3 tune60 replay; no BC trainer starts unless that
gate passes. It does not launch the nine-job formal profile automatically.

### Live pilot handoff

Started at 2026-09-05 15:46 CST under user service
`hkbz-stage2-bc-injection-20260905-gpu0-half-pilot-r1.service`.
Manifest and current status:

- `result/hkbz_train_logs/stage2_bc_injection_20260905_gpu0_half_pilot_r1/manifest.json`
- `result/hkbz_train_logs/stage2_bc_injection_20260905_gpu0_half_pilot_r1/suite_status.json`

Startup verification: service active/running; controller PID2358338 bound to
30-31,94-95; evaluator PID2358340 bound to 24-29,88-93 and visible on physical
GPU0 only. The systemd cgroup's allowed CPU set is 0-31,64-95. GPU1's unrelated
experiment was not stopped or reconfigured. During reference validation the
training lanes are intentionally idle. No scientific success is claimed until
the reference gate and subsequent pilot training/evaluation have completed.

### Pilot r2: user-authorized early B2 launch, 19:24 CST

The active suite is now `stage2_bc_injection_20260905_gpu0_half_pilot_r2`.
On the user's explicit request, B2 was expedited in a lifecycle-bound companion
service without restarting B0/B1. The original manifest remains immutable;
CPU affinities are amended to 16/16/16 training + 12 evaluation + 4 controller
logical CPUs, still wholly inside `0-31,64-95` on physical GPU0 only.
Rollout/evaluation widths and the scientific budget remain unchanged.

The original queue adopts the externally claimed B2 result instead of launching
a duplicate. Until that adoption, its in-memory pending list can still contain
B2; use `external_jobs/B2_R1_seed11.json` and B2's `run1/run_status.json` for
the actual state. The 19:26 audit found 90 processes / 182 threads with zero
affinity violations. See [the early-start record](STAGE2_B2_EARLY_START_20260905.md)
for identities, source provenance, exact CPU sets and the 53-test regression check.
