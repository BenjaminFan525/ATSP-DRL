# Stage2 策略改进首轮：实现与启动记录

Material Passport: academic-research-suite / experiment-agent / code-execution / 2026-09-06 / stage2_transfer_v1.

研究计划：[Stage2→Stage3 计划](STAGE2_TO_STAGE3_RESEARCH_PLAN_20260906.md)。
当前状态（2026-09-06 01:16 CST）：代码与 CPU 测试完成；canary_r2 四组全部完成且统一审计通过；pilot_r1 已启动，先进行梯度前完整 tune60 复验。尚无新的科学收益结论。

## 已实现

- 显式 `stage2_policy_warmstart_*` 接口：来源文件/逐例评测 SHA256、S1/R1 lineage、规划和模型契约校验。全量加载最佳模型权重，不恢复旧优化器、RNG 或训练游标。
- 正式筛选进程在任何梯度前，对自己的历史 Best 逐案例零容差复验；不以均值接近替代逐例一致。
- 四组预算匹配的继续 BC / DAgger 分叉：C_B0、D_B0、D_B2、C_B2；DAgger 在实际访问状态查询 IGA 染色体教师，按完整环境资源联合动作混合。
- `device_bc_skip_ready_targets`：只允许冻结 Ready 头的 IGA 策略训练。显式禁用事实教师轨迹时间标签查询、监督和误差统计；Ready 头训练仍只能沿教师轨迹。四组控制统一设置。
- Stage3 静态交接区分“本轮训练预测头”与“使用已经训练并验证的冻结预测头”：核对实际 R1 文件、头训练证据、教师 index SHA 和头逐张量一致性。投影改变不算预测头训练。
- 新分析器保留全部 epoch 和原模型回退选项，核对初始权重/新优化器/游标、教师与学生实际执行次数、标签和优化预算、分布/尾部、配对案例区间及静态 Stage3 兼容性。
- 每个实验独立目录；固定源代码归档/清单，最多三训练进程、一个共享评测器，无自动重试、正式训练或 Stage3 晋级。

关键代码：

- `onpolicy/utils/stage2_policy_transfer.py`
- `onpolicy/runner/shared/hkbz_runner.py`
- `onpolicy/utils/training_stage.py`
- `onpolicy/envs/HKBZ/environment.py`
- `onpolicy/scripts/train/prepare_stage2_policy_transfer.py`
- `onpolicy/scripts/train/analyze_stage2_policy_transfer.py`
- `onpolicy/scripts/train/launch_stage2_policy_transfer_gpu0.sh`
- `onpolicy/envs/HKBZ/test/test_stage2_policy_transfer.py`

## 检查与失败记录

- 修订后 126 项 CPU 回归测试全部通过（2026-09-06 00:50 CST）；包括新策略分叉、冻结头、Stage2 监督/迁移/资源研究、采样、两阶段编排、设备 lookahead 与 Stage3 joint-finetune 测试。
- `git diff --check` 和启动脚本 `bash -n` 通过。
- 对真实 B0/B2 Best 检查点验证冻结 R1 来源和静态交接，均通过；不等于动态 Stage3 训练验证。
- pilot 临时清单预检通过：240 个固定训练案例/顺序、60 个 tune 案例、12 个评测 workers、四个权重分叉；不访问 gate/finalblind。
- canary_r1：DAgger 两组在配置检查阶段被旧“必须纯教师轨迹”规则拒绝，未发生梯度更新。停止该自建服务并完整保留日志；没有绕过 Ready 标签正确性约束，也没有将此失败计为研究效果。
- canary_r2：修订标签收集模式后的新 run。启动时核验 13 个所属进程全部位于 CPU `0-31,64-95` 内，无越界；GPU1 的既有任务未改动。
- canary_r2 最终四组均正常退出，8/8 个训练 epoch、12/12 个评测请求完成；四组初始模型逐张量一致、冻结范围及实际动作执行计数审计通过。C_B0/D_B0 选择新 epoch1，D_B2/C_B2 保留原起点；这是工程结果，不用于判断方法收益或调整 pilot 参数。
- 真实新 C_B0 Best 的本轮 Ready 标签为 0，但已验证 R1 来源中的 3,454,473 条 Ready 训练标签与实际头权重；Stage3 静态交接通过。动态 Stage3 迁移尚未验证。
- 219 个归档源码文件在 canary 期间无变化。工程服务正常退出、GPU0 释放后，才启动 pilot_r1。

## 资源与后续门槛

GPU0；CPU 合计 64 个逻辑 CPU / 32 个物理核。训练 lane 分别为
`0-7,64-71`、`8-15,72-79`、`16-23,80-87`；共享评测
`24-29,88-93`；控制器 `30-31,94-95`。

四组 canary 全流程/分析通过后已启动 pilot_r1。每个 pilot 进程还要单独
通过历史起点零容差复验。首轮只筛选方法，不声称多种子或独立确认成功。
目标为相对强 BC 改善 1%、争取 2%，不是结果承诺。

后续资源 RL 概率/解码审计、独立多种子确认、Stage3 零更新和短程迁移探针
按研究计划分阶段推进；尚未实现或启动这些条件阶段的完整训练。

## 运行证据

- 失败工程记录：`result/hkbz_train_logs/stage2_policy_transfer_20260906_gpu0_half_canary_r1/`
- 通过的工程记录：`result/hkbz_train_logs/stage2_policy_transfer_20260906_gpu0_half_canary_r2/`
- 已启动的筛选目录：`result/hkbz_train_logs/stage2_policy_transfer_20260906_gpu0_half_pilot_r1/`

工程证据哈希：canary manifest `6a6702140c8d4133c2c48d8d1eab3a9501e58ce442783cc0324e0ddf95336e16`；
canary analysis `2d0f7304ffe374837c885d19ad9ffbe8124a6164b68c4e85bb45257858c6c541`。
pilot 服务：`hkbz-stage2-policy-transfer-20260906-gpu0-half-pilot-r1.service`。
01:17:35 CST 实测服务 active，89 个所属进程均在指定 CPU 半区；4 个 GPU 计算
进程全部属于 GPU0。C_B0/D_B0/D_B2 已启动训练前复验流程，C_B2 排队；此时尚未进行 pilot 梯度更新。

分析格式：`effective_epoch` / `effective_checkpoint` 和 `all_epoch_cases.csv` 的
`effective_selection` 表示包括原起点回退在内的实际选择。旧审计器输出的
`selected_epoch` / `paired_cases.csv` 仅表示合格训练 epoch，不应混作回退后的策略。

后续状态以各目录 `suite_status.json`、`manifest.json`、`analysis/comparison.json`
和各训练 run 的 `run_status.json` 为准。
