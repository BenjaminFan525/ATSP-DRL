## Material Passport

- Origin Skill: academic-research-suite/experiment-agent
- Origin Mode: run
- Origin Date: 2026-09-11
- Verification Status: UNVERIFIED (implementation checked; full scientific experiment running)
- Version Label: stage2_v6_train240_launch_v1

# train240/tune60 implementation and launch record

User explicitly requested the full-data launch. The preserved pilot completed
but both arms failed the development screen: S1/S2 mean Cmax regression against
B0 was1.8280%/3.1151%. This was disclosed before launch and is recorded in the new
manifest as a manually requested exploratory extension, not an automatic or
passed-screen promotion. No scientific success is asserted.

## Changes and checks

Added separate full-data contract, prepare/run/launch entries, CPU regression
entry and orchestration tests. Original pilot implementation fingerprints remain
unchanged. The new runner retains the original V6 learner and mathematical
contracts, evaluates tune60 in five12-case groups, records40 updates per epoch,
and saves both arms' checkpoints before development evaluations.

68 selected regression tests passed with zero failures/errors. Full scheduling
was exercised with simulated learners:400 updates per arm, fixed0/1/5/10
evaluations and exact48-reused/192-new teacher case accounting. These tests are
not scientific training. The unchanged learner retains its hash-matched passed
GPU engineering proof and completed pilot evidence; no new GPU microbenchmark
is claimed. Full manifest/input validation also passed before service launch.

Regression proof:
`result/hkbz_train_logs/stage2_v6_full_engineering_20260911_gpu0_r1/regression.json`.

## Launched service

- Suite: `result/hkbz_train_logs/stage2_semantic_pair_v6_20260911_gpu0_half_train240_r1`.
- Unit: `hkbz-stage2-v6-full-20260911-gpu0-half-r1.service`.
- Main PID observed:451367; service start:2026-09-11 08:06:53 Asia/Shanghai.
- Observed active/running, correct GPU0 UUID, AllowedCPUs/CPUAffinity0-31,64-95,
  Restart=no and RuntimeMaxSec=infinity. GPU1 jobs were untouched.
- First scientific phase:IGA180 production replay. At08:08, progress showed
 148 completed event steps, no error and no suspected stall.

Both arms restart from the same B0 and receive ten full train240 epochs,400
updates each. Only immutable teacher48 caches are reused, not pilot-trained
weights. Total new complete physical-case budget748; plus separately identified
48 reused cases. All pilot artifacts remain in their original directory.

Follow `run_status.json`, `resource_ledger.json`, `controller.log`, `teacher_data/`,
`S1/`, `S2/`, `evaluations/` and eventual `full_report.json` in the new suite.
After final evaluation, stop for manual review. PPO and Stage3 are not started.
