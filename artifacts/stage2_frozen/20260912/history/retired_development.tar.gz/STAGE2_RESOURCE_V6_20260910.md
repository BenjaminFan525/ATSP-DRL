# Stage2 V6: semantic repair and lightweight resource actor pilot

Material Passport: Origin Skill = academic-research-suite/experiment-agent;
Origin Mode = run; Origin Date = 2026-09-10; Verification Status = UNVERIFIED;
Version Label = stage2_v6_pilot_v1. Engineering checks are not scientific success.

## Approved scope and immutable goal

Fully exceed IGA180 (no per-case regression, strictly lower mean), reach or
exceed IGA1800 mean/groups/tail, and provide a sound Stage3 initialization.
This first executable block implements A + B of the approved V6 plan. It stops
after S1/S2 pilot review: no automatic train240, PPO, S3, search, cost branches,
DAgger extension, extra seeds, retry, or Stage3. Those later planned experiments
require the pilot decision and separately recorded execution manifests.

## Semantics and structure

H2/F4, soft reservation, frozen plane input/GNN/head, Ready-none, physical rules
and Cmax remain unchanged. V6 observations are opt-in graph metadata; legacy
node/edge tensors and default checkpoint loading remain untouched.
Last-dispatch history stores pre-execution raw request features and stable
(plane, job, site) identity, keyed by device and episode. No-op retains the last
dispatch; reset clears history. Disappeared requests never alias a current slot.
No learned embeddings are cached across updates.

S1: legacy frozen GNN + ordinary/transporter GRU/pointer heads with a new
48-to-64 semantic history adapter. S2: independent 2x128 pair-scoring MLPs for
ordinary/transporter, no resource GRU; request46/device21/global138/pair211.
The resource view includes observable operation/site relations, normalized
times/coordinates, categorical type bits and masked real-node summaries.
Independent V6 critic is provisioned but frozen/untrained in this BC-only pilot.

## Shared data and optimization

Preserve the parent train240/tune60 case lists/hashes. Pilot uses first48 of the
outcome-independent parent training order. Development12 comprises two intact
six-case numerical groups chosen by distribution counts and hash only. No
gate120/finalblind access or independent-generalization claim.

First replay saved IGA180/1800 genes on the four existing diagnostic cases,
production and AR-projected decoding. No new search; historical search budgets
remain uncertified. Projection mean regression >0.5% stops before BC.
Collect exactly one current teacher-forced trajectory for each pilot training
case from the pinned IGA1800 teacher; validate identity and conditional masks.
Both arms reuse these same 48 episodes for 10 offline BC epochs, six cases per
logical batch: 80 Adam steps per arm, LR3e-5, gradient clip1, tau0.3.
Loss: equal cases, equal represented roles within case, uniform free decisions
within role. Forced choices receive no CE but S1 still advances their histories.
S1 replays complete prefixes under current weights, TBPTT16, no optimizer step
inside a case. S2 differentiates stateless records without recurrent replay.
S2 raw pair features/masks are packed once; microbatches256 accumulate into the
same one six-case update. This never caches a trainable network activation.
Frozen GNN outputs may be cached with original case membership. FP32 probability
guards remain logp1e-6 and joint ratio1e-5; do not weaken to pass a failed audit.

## Budget, assessment, and handoff

172 complete-case episodes total: archived diagnostic16 + B0dev12 + shared
teacher48 + candidate initial24 + candidate epoch1/5/10 development72. Offline
case presentations, optimizer steps, teacher queries and physical episodes are
reported separately. Primary endpoint epoch10; epochs1/5 only monitoring.
Pilot investment screen: mean regression vs current B0dev <=0.5%, each group and
tail regression <=1%, zero failures and all80 actor steps. Passing this permissive
screen also requires lower mean training CE at epoch10 than epoch1 (diagnostic,
not a held-out accuracy claim). Passing the
pilot screen is NOT success against IGA and does not automatically start PPO.

GPU0 UUID GPU-744c1334-98c8-5318-e799-7ad15eea1fbf only; CPU0-31,64-95.
One process alternates S1/S2 over shared batches initially (max2 future trainers).
Train CPU0-23,64-87; evaluation24-29,88-93; monitoring30-31,94-95.
GPU1 and the other CPU half are untouched. Heartbeat30s; no restored hard wall
clock gate. Nonfinite/illegal/incomplete data stops the finite experiment and
preserves artifacts; no crash retry. Every checkpoint keeps schema, role,
optimizer/RNG state, source hash and explicit untrained critic/scientific status.

Entry: prepare_stage2_resource_v6.py --suite-dir NEW_DIRECTORY
--engineering-proof PASSED_GPU_REPORT, then
launch_stage2_resource_v6_gpu0.sh NEW_DIRECTORY/manifest.json. Launch only after
CPU regression tests and a GPU0 engineering smoke test have passed.
Engineering smoke checks use six case prefixes, at most64 events each, with
discarded updates. Their attempted prefixes are accounted separately, never
misreported as any of the172 complete scientific episodes.
