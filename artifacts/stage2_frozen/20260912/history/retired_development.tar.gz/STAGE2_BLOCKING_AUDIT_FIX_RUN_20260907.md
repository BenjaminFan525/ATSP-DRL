## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: user-authorized repair, verification and continuation
- Origin Date: 2026-09-07 (Asia/Shanghai)
- Verification Status: CPU, isolated analyzer regression and fresh GPU canary VERIFIED; 240-case BC pilot RUNNING; scientific efficacy UNVERIFIED
- Version Label: blocking_coverage_fixed_regressions_live_teacher_witness_r3

## 故障与诊断

用户授权“修复并继续 stage2 实验”。本轮保留所有旧产物，使用 GPU0 和原 CPU 半区 `0-31,64-95`，不改动 GPU1 上的其他实验。

r2 的 N0/N1 两轮 canary 训练和评估均正常退出（代码 0），但套件于 11:25:36 在后处理验收失败，根流程于 11:25:41 退出。错误为 `N1_BC_dagger_seed11 canary never exercised the Blocking repair`。

实际数据：

| 方法 | 第 1 轮检查 / 修复次数 | 第 2 轮检查 / 修复次数 | 匹配合法性审计 |
|---|---:|---:|---|
| N0 全教师 | 1029 / 1 | 1029 / 1 | 两轮通过 |
| N1 DAgger | 979 / 0 | 931 / 0 | 两轮通过 |

N1 并没有跳过教师投影。旧验收要求所有方法、所有轮次均触发一次实际修复，将“修复次数为零”误当成“未执行投影检查”。但 DAgger 根据已访问的真实状态查询教师，轨迹可以不再经过全教师路径上的反例；不能为了触发计数而改变 DAgger 的执行比例或强制走教师路径。

## 修复

新增验收契约 `fixed_regressions_and_live_teacher_witness_v1`，只显式用于新加速流程；不追溯改写旧清单。

1. 独立运行固定 Blocking 和串行 last-chance 反例：原动作必须被拒绝；投影必须精确得到预定合法动作；不能修改原输入；重复投影必须幂等。
2. 同套件全教师对照（N0 或 N2）仍须每轮至少触发一次真实修复，并逐条校验原始事件记录、教师文件 SHA256、规则契约和回归案例来源。
3. DAgger（N1 或 N3）每轮仍须有真实投影检查并通过部署匹配审计。修复次数允许为零，但不补造事件；若有事件，仍须与原始事件账本一致。缺少调用、缺少轮次、错误规则、非法计数或损坏来源均拒绝。
4. 阶段证明重新计算以上证据，不只信任一个 `passed=true` 字段；旧 canary 的未完成证明不能放行新 pilot。
5. 成功报告延后到全部分析通过才发布。低层检查不会再提前写出 `complete=true`，掩盖后续的验收失败。
6. 完整产物分析测试发现的额外问题已修复：返回内存中的不可用综合/历史最优指标可能为 `inf`，最终严格 JSON 需沿用现有 `json_safe` 将其记录为 `null`。实际 Cmax、案例完成性和模型张量有限性仍先独立严格检查，未放宽。

实现文件：`onpolicy/utils/stage2_blocking_audit.py`；清单准备、阶段证明和三级分析器相应接入。训练、环境规则、教师生成、网络、损失、优化器、DAgger 比例、样本预算、IGA 目标和成本门槛未改。

## 验证

- 103 项 CPU 测试最终全部通过，含固定反例、缺失/伪造证据拒绝、BC/成本两类 canary、旧验收契约隔离、成功报告发布顺序及启动器资源约束。
- 在临时目录构造分析器测试输入，使用 r2 完整权重与日志进行只读回放；修复后的全套分析通过。此临时输出已随测试清理，不作为生产证明，也未改写 r2 的失败状态。前后校验历史清单、报告和训练产物内容一致。
- 该完整测试首次暴露严格 JSON 写入 `inf` 的问题，修复后重跑 103 项测试通过；这是启动前代码测试，不是一次新的生产训练失败。
- 9 个修改/新增 Python 文件 AST 检查、启动脚本 `bash -n`、`git diff --check` 通过。
- 真实服务预检 `hkbz-stage2-cost-accelerated-preflight-20260907-r3.service`：退出码 0，6.789 秒。根流程和 BC canary 准备、源码/权重/输入校验、64 个逻辑 CPU 分配及固定反例均通过。
- 与 r2 比较：训练命令仅运行路径和配置摘要变化；训练、评估、资源、成本、诊断、匹配、调度和固定权重契约不变。分析契约仅新增上述覆盖定义。

## r3 继续方式

```bash
env RUN_TAG=stage2_cost_accelerated_20260907_gpu0_half_r3 \
  PYTHON=/home/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11 \
  bash onpolicy/scripts/train/launch_stage2_cost_accelerated_gpu0.sh
```

由于验收代码指纹变化，r3 从原定 B0 起点重新执行小规模 canary，再进入 240 案例 pilot；不把两案例 canary 权重当成 pilot 新起点，不将旧 r2 失败报告改成通过。

新服务：`hkbz-stage2-cost-accelerated-20260907-gpu0-half-r3.service`。
新根目录：`result/hkbz_train_logs/stage2_cost_accelerated_20260907_gpu0_half_r3/`。
固定源码/配置文件共 250 个。`Restart=no`，总硬上限 48 小时，继续原有阶段顺序和 N2/N3 条件门槛，不启动 RL 或 Stage3。

GPU/CPU：物理 GPU0；全半区 `0-31,64-95`；训练通道 `0-11,64-75` 与 `12-23,76-87`；评估 `24-29,88-93`；套件控制器 `30-31,94-95`。

## 旧产物内容基线

对文件按相对路径排序，记录 `(相对路径, 字节数, 文件 SHA256)`，紧凑 JSON 后计算内容树摘要。以下目录均原地保留，不改旧报告或删除权重：

| 目录 | 文件数 | 字节数 | 内容树 SHA256 |
|---|---:|---:|---|
| r2 根套件 | 13 | 2634829 | `04999c63fbdea2976e3b72731d220bf40ee1ccc7b375068641a04f9b17d52e73` |
| r2 BC canary 套件 | 21 | 3308272 | `3b07255fe249d84c889738f37afa1a5893f424e7bc7601ecf9bf5612db61d938` |
| r2 N0 run1 | 21 | 44449354 | `f589d7a909059a638e858be315a39d668426fc2c67bf374230bef97d52302586` |
| r2 N1 run1 | 18 | 31471434 | `eb457f5141d28c5b6267ff8b6d3f87ddc328a2917009058a362fc2217021fc0d` |

## 运行进度

后续实际启动、canary 验收和 pilot 状态见本节追加记录，以及新目录的 `pipeline_state.json` 与各阶段的 `suite_status.json`。修复通过不等同于训练已完成或研究目标达成。

- 11:44:27：r3 服务启动，控制器 PID 3081136；`Restart=no`，CPU 半区设置核实。
- 11:46：根流程处于 `bc_canary`，N0/N1 PID 为 3081501 / 3081502，正在训练前评估；250 个固定文件逐项校验一致。
- 根清单 SHA256：`519feb88fda4a5a00360f9395794e26330f7bd67e914536b742a1b9d046da04b`。
- 源码归档 SHA256：`4b27083e7db15fbd4a93f30addf6ee1b27c9ace4ff0f0fbeb482e059bec66339`。
- 执行配置 SHA256：`726a1b332d59c26feef03f942cbc4494c48d8f037b0df4e7b678409ba1b9e72e`。
- 新源码命名空间：`f0203106beccab03eadd52181447ad5862c1148c3635669b8a40df9dd34f8362`。
- 11:58:37：新 canary 完成，两组训练退出码均为 0；`canary_contract_passed=true`、`cost_integrity_passed=true`、`blocking_repair_coverage.passed=true`。N1 真实事件数仍为 0/0，没有补造计数。
- 新 canary 证明 SHA256：`1df1cd482c41217a2f59f42863ffae3617dd5cbb49628902f8ff3df7e9029053`；canary 清单 SHA256：`d3ab91e79976c86cbb1de0b53f55fa9ef0030d850882a2a4758c4764d2f74c23`。
- 额外 CUDA 运行结果复核：r3 的 N0/N1 在第 1、2 轮保存的各 508 个模型张量，以及每轮四案例 Cmax，均与 r2 逐项完全一致；两组训练前四案例结果也一致。这支持本次为验收层修复，不是训练方法或结果变化。
- 11:59:29：控制器自动通过新证明并进入 `bc_pilot`。pilot 套件控制器 PID 3090226，共享评估器 PID 3090233，N0/N1 PID 3090281 / 3090282。
- 12:01：pilot 服务保持运行，无重启或报错。两组已完成固定源权重加载，正在训练前 60 案例严格复验；通过后才开始 pilot 的梯度更新。每组 240 个训练案例、24 环境、每轮 10 次采样、共 2 轮；评估为 12 环境 / tune60。
- 已检查 pilot 全部 65 个进程均位于原 CPU 半区，训练/评估子分区符合契约，GPU0 的三个计算进程均属于 r3。未动用 GPU1。
- r3 启动后再次复核旧 r2 根目录、canary 套件及两个训练目录的内容树，均与修复前完全一致。所有旧权重和原始失败记录保留。
- 当前 N2/N3 尚未启动；仍需后续完整加速复验、成本诊断、可学习性、canary 和容量检查，不自动放宽门槛。
