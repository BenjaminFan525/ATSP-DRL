# Stage2 exact cost execution and baseline-first scheduling

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: user-authorized implementation and deterministic verification
- Origin Date: 2026-09-07
- Verification Status: implementation under verification; no scientific efficacy claim
- Version Label: exact_full_batch_fanout_shared_environment_prefix_v1

## Scope

The N0–N3 learning target, initial B0 weights, frozen S1/shared/R1, 240 cases,
two epochs, teacher schedules, selected state ordinals, four-candidate limit,
full student continuation, full heterogeneous GPU batch, both GRUs and losses
are unchanged. GPU0 only; CPU 0-31,64-95 only. GPU1 is out of scope.

New opt-in entry points leave the old running source files and artifacts
unchanged. No running service is stopped by code preparation. Activation uses
a new immutable manifest/output directory; no mid-epoch resume is implied.

## Exact execution

The environment workers process a bounded fanout of independent candidate
continuations. Identical full-batch first actions can serve several target
cases; each case's result is recorded at its own original terminal step.
Within each worker, only identical object history plus exact action bytes
share a transition. Divergent actions clone private state, including RNG,
before any mutation. Equal actions after divergent histories do not merge.

Each neural forward still receives the original batch width/order and both
GRUs. Candidate batches are not concatenated, reduced, or replaced with CPU
or teacher policies. Up to four private frozen-model CUDA streams (default
two) can run independent full-batch forwards concurrently. Each stream has
its own model/GRU buffers and waits for model-copy initialization. CPU threads
and environment workers remain inside the same reserved physical CPU half.
The optimization also batches RPCs and avoids duplicate companion simulation
and serialization. No acceleration factor is promised before a matched GPU
benchmark; both fanout width and stream count are bound to its proof.

Completed outcomes have an immutable, content-checked cache keyed by source,
actual numerical runtime (including GPU UUID, driver and library versions), frozen policy, all companion snapshots, both
post-forward GRUs, history, full first action, target index and step budget.
Incomplete outcomes are never cached. Cross-version/policy/state evidence is
not reused. Concurrent cache misses may compute twice; conflicting writes
fail closed. The old teacher/CPU label cache is never imported.

Logical query count, actual unique jobs, cache hits, shared environment steps,
RPC time, actor time and actual non-overlapping wall time are separate ledgers.
Per-job compute timeouts exclude another job's GPU inference; shared RPC time
is conservatively charged to every active job. The global 48-hour hard limit
remains. Incompletes still abstain and cannot pass the cost integrity gate.

## Scheduling and gates

1. N0/N1 two-case, two-epoch engineering canary; no cost proof required.
2. N0/N1 pilot (up to two concurrent trainers), each with the original strict
   tune60 pre-gradient replay. Cost failures cannot block these completed arms.
3. Matched serial/fanout completed continuations at batch widths 2 and 24;
   exact action/dual-GRU traces, costs, terminal steps and cache replay;
   measured speedup required. A truncated prefix is only a smoke test.
4. The original fixed 24-case cost diagnosis, complete no-intervention replay,
   teacher reference and discarded-copy recurrent microfit. Correctness and
   learnability remain mandatory. Actual cost-work estimates are advisory,
   not a scientific gate or an N0–N3 completion ETA.
5. N2/N3 canary, then N2/N3 pilot, with source-matched proofs and unchanged
   per-job replay/learning/integrity checks. A separate engineering capacity
   check holds only the cost pilot if even the optimistic single-arm cost-work
   projection exceeds the remaining global budget. This neither marks the
   scientific checks failed nor blocks/invalidates completed N0/N1. Passing
   that check is not a claim that full parallel training will fit the budget.
6. Combine only complete source/case-matched BC and cost pilot reports for the
   four planned comparisons. Partial results remain explicitly partial.

BC and diagnostic paths are dependency-decoupled, not run concurrently by this
controller. This keeps the existing physical CPU lane partition and GPU
ownership checks intact. N0/N1 can be prepared/launched independently even if
the cost accelerator or diagnostic gate fails. No automatic retry, extra
epochs, RL, Stage3, gate-set or finalblind access is added.

## Entry points

`launch_stage2_cost_accelerated_gpu0.sh` prepares and starts a new pipeline.
`DRY_RUN=1` prepares only. Explicitly run the new launcher after verification;
the original slow controller is not silently redirected to a new code version.

## September 7 evening: measured frozen-inference continuation

The user authorized N2/N3 acceleration. The original r3 diagnostic was stopped
with every artifact retained; completed N0/N1 are not retrained. A continuation
manifest binds their reports, checkpoints, evaluations and archived source.
Only an explicit cost/orchestration-file allowlist may differ: the model,
learner, losses, environment, teacher, numerical configuration and evaluator
must retain their original source hashes. The original September 9 11:44 CST
deadline is carried into both the controller and service runtime limit.
Historical BC results are identified as reused controls, never relabeled as
results generated by the new source. All cost gates use the new source.

The selected opt-in `host_matching` inference batches CPU transfers and unique
GPU output writes around the unchanged float64 Hungarian solver. It is applied
only to private, frozen cost actors. The original serial actor, learner and
evaluation entry points remain unchanged. No candidate, case, terminal horizon,
neural batch dimension, tensor precision, GRU or learning objective changes.
The candidate execution window is 16, with four private-model CUDA threads.

Two archived real 24-case states were used for performance screening (five
repeats, eight requests each). Old two-thread median: 1.390 seconds; selected
four-thread host-matching median: 1.047 seconds, about 1.33x actor throughput.
This is not a training ETA. Multiprocess CUDA inference was slower and is not
selected. A generated index-only forward was also screened, then removed from
the deployment implementation because it gave no stable additional gain.
Screen source bundles/results are retained, including non-launched preparation
artifacts. No microbenchmark serves as a scientific/production approval.

The full acceleration gate now checks three paths: unchanged serial, previous
8-branch/2-thread execution, and proposed 16-branch/4-thread host matching.
Both fixed batch-2 and heterogeneous batch-24 fixtures must finish, match every
action, both-GRU trace, terminal step and Cmax exactly, pass cold/warm cache
integrity, and beat both previous paths in observed wall time. Only then run
the full original diagnostic, cost canary and capacity-gated N2/N3 pilot.
Old incomplete evidence and completed cache files remain in the old directory;
they are not imported into a differently source-bound cost cache.

## Timeout accounting amendment: amortized shared wall v2

Real-load r4 diagnosis exposed a defect not covered by the four-query neural
fixtures: the first 29 candidates contained 18 wall timeouts. Those same
snapshots, post-forward GRUs, history, policy and full first actions are byte-
identical to the completed r3 batch. A shared environment RPC was charged in
full to every job; overlapping private-actor host latencies were then treated
as private computation. These are not non-overlapping per-job compute times.

Opt-in `amortized_shared_wall_and_progress_deadline_v2` keeps the numeric
600-second job budget, but allocates each measured RPC interval once across
its active jobs and each actor-pool wall interval once, weighted by reported
actor latency. This is explicitly an amortized engineering work budget, NOT
isolated CPU/GPU time. Raw actor latency, shared RPC wall, allocated work,
per-job elapsed wall and legacy hypothetical charge remain separate ledgers.
The old timing path remains available only as an explicit reference mode.

A separate main-process SIGALRM watchdog exits 124 after 600 seconds without
a completed environment RPC or actor-pool operation. It fails immediately
without attempting potentially blocked Python cleanup; the controller does
not retry, and the existing systemd control-group ownership reaps its children.
The original episode-step limit and September 9 11:44 CST global deadline
remain. Any incomplete v2 evidence aborts before further collection/training,
after persisting the evidence; incomplete labels are never accepted or cached.

Before cost diagnosis, v2 requires the actual fixed regression batch: 29
logical queries, 20 distinct full-batch jobs, 16 simultaneously live branches,
4 actor lanes, all 24 companion cases and full terminal horizons. Every Cmax
and terminal step must exactly match the archived complete r3 reference.
The existing small 2/24-case complete action/dual-GRU proofs also run on the
new source. New high-load trace hashes are archived; unavailable historical
high-load hashes are not invented. Short-prefix checks cannot approve v2.

The regression produces fresh current-source completed cache entries. If the
following diagnosis regenerates exactly the same binding, it may reuse those
entries instead of redoing the first batch. Its workload estimate adds the
regression's measured cold wall time back exactly once, only for a complete
matching cache hit, so cached diagnostics cannot make cold training look free.
No historical r3/r4 cache is imported, no sample/candidate count is reduced,
and no new global time or resource budget is granted.
