"""Opt-in, snapshot-safe asynchronous validation for Stage-1 baseline lanes.

The training thread owns all model/optimizer state.  Background threads only
send immutable CPU snapshots to the one existing shared evaluator.  Validation
results are consumed in submission order on the training thread.  Best model
writes always use the submitted full checkpoint, never the live policy.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import math
import os
from pathlib import Path
import shutil
import time

import torch


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    os.replace(temporary, path)


class _QueueClient:
    def __init__(self, owner, client, job):
        self.owner, self.client, self.job = owner, client, job

    def request(self, payload):
        # The synchronous helper deletes its request packet on return.  Keep
        # an independent immutable copy for the background RPC.
        packet = self.owner._async_directory / (payload["request_id"] + ".pt")
        shutil.copyfile(payload["checkpoint_path"], packet)
        request = {**payload, "checkpoint_path": str(packet.resolve())}
        self.job.update({
            "request_id": request["request_id"],
            "model_sha256": request["model_sha256"],
            "packet_path": str(packet),
            "submitted_unix_time": time.time(),
            "request": request,
        })
        atomic_json(packet.with_suffix(".request.json"), request)
        self.job["future"] = self.owner._async_executor.submit(
            self._execute, request, packet
        )
        self.owner._async_jobs.append(self.job)
        self.owner._write_async_status()
        return {"evaluation": {"_stage1_async_queued": True}}

    def _execute(self, request, packet):
        # No runner, CUDA, RNG, or mutable model state is touched here.
        response = self.client.request(request)
        if response.get("request_id") != request["request_id"]:
            raise RuntimeError("Asynchronous evaluator returned the wrong request ID.")
        atomic_json(packet.with_suffix(".response.json"), response)
        return response


class Stage1AsyncEvalMixin:
    """Used only by train_stage1_aligned_baseline.py; other runs are unchanged."""

    # This opt-in applies only to the separate P5-aligned entry point.  The
    # standard cold-PPO baseline runner retains its no-BC guard, while every
    # environment/teacher/stage validation below that guard still runs here.
    baseline_initialization_protocol = "new_semantics_budget_matched"

    def __init__(self, config):
        self._async_jobs = []
        self._async_completed = []
        self._async_submitting = False
        self._async_consuming = False
        self._async_snapshot = None
        self._async_executor = None
        super().__init__(config)
        if self.training_stage != "plane_pretrain":
            raise ValueError("Asynchronous baseline runner is Stage-1-only.")
        if getattr(self.policy.ac, "stage1_baseline", "proposed") == "proposed":
            raise ValueError("This runner must not retrain the proposed main experiment.")
        if self.shared_eval_client is None:
            raise ValueError("An isolated shared evaluator is required.")
        if self.early_stop_patience or self.canary_eval_interval_shards:
            raise ValueError("Async evaluation cannot drive training stop decisions.")
        if getattr(self, "selection_checkpoint_dir", None):
            raise ValueError("Cross-run selection checkpoint seeding is forbidden.")
        self._async_directory = Path(self.run_dir) / "async_evaluation"
        self._async_directory.mkdir(parents=True, exist_ok=True)
        self._async_executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="stage1-validation-client"
        )

    def _write_async_status(self):
        def public(job):
            return {key: value for key, value in job.items()
                    if key not in {"future", "request"}}
        atomic_json(self._async_directory / "status.json", {
            "protocol": "immutable-checkpoint-ordered-async-v1",
            "updated_unix_time": time.time(),
            "pending": [public(job) for job in self._async_jobs],
            "completed": list(self._async_completed),
        })

    @torch.no_grad()
    def eval(self, render=False, evaluation_label=None):
        if render:
            raise ValueError("Asynchronous baseline validation cannot render.")
        label = str(evaluation_label or "")
        if label == "pre_ppo":
            episode = -1
        elif label.startswith("epoch_"):
            episode = int(label.removeprefix("epoch_")) - 1
        else:
            raise ValueError(f"Unsupported asynchronous evaluation label: {label}")
        self._drain_async(wait=False)
        snapshot_name = f"checkpoint_Async_{label}.pt"
        super().save(episode, filename=snapshot_name, extra={
            "stage": "asynchronous_evaluation_snapshot",
            "evaluation_label": label,
            "evaluation_tau": float(self.evaluation_tau),
        })
        job = {
            "label": label, "episode": episode,
            "training_step": int(self.total_num_steps),
            "snapshot_path": str(Path(self.save_dir) / snapshot_name),
        }
        client = self.shared_eval_client
        self._async_submitting = True
        self.shared_eval_client = _QueueClient(self, client, job)
        try:
            super().eval(render=False, evaluation_label=label)
        finally:
            self.shared_eval_client = client
            self._async_submitting = False
        print(f"[AsyncEval] queued {label}; training continues", flush=True)
        return float("nan")

    def _consume_raw_evaluation(self, payload, evaluation_label=None):
        if payload.get("_stage1_async_queued") is True:
            return float("nan")
        return super()._consume_raw_evaluation(payload, evaluation_label)

    def _update_best_checkpoints(self, episode, stage):
        if not self._async_consuming:
            return False
        return super()._update_best_checkpoints(episode, stage)

    def save(self, episode=0, filename=None, extra=None):
        if self._async_snapshot is not None:
            checkpoint = {**self._async_snapshot, **(extra or {})}
            checkpoint.update({
                "best_eval_makespan": float(self.best_eval_makespan),
                "best_eval_iid_makespan": float(self.best_eval_iid_makespan),
                "best_eval_composite_makespan": float(self.best_eval_composite_makespan),
                "evaluation_snapshot_verified": True,
            })
            target = filename or f"checkpoint_Epoch{episode + 1}.pt"
            self._atomic_torch_save(checkpoint, str(Path(self.save_dir) / target))
            return
        # The inherited synchronous loop receives a NaN placeholder.  Do not
        # label its live checkpoint with a previous epoch's evaluation result.
        if extra and extra.get("stage") == "epoch_eval":
            extra = {"stage": "epoch_evaluation_pending"}
        return super().save(episode, filename=filename, extra=extra)

    def _report_progress(self, event, **extra):
        if self._async_submitting and event == "shared_eval_completed":
            return
        if not self._async_consuming and event == "evaluation_completed":
            return super()._report_progress(
                "evaluation_submitted", async_pending=len(self._async_jobs)
            )
        if event == "epoch_completed" and self._async_executor is not None:
            self._drain_async(wait=False)
        return super()._report_progress(event, **extra)

    def log_train(self, train_infos, total_num_steps):
        if (
            not self._async_consuming
            and "eval_makespan" in train_infos
            and not math.isfinite(float(train_infos["eval_makespan"]))
        ):
            return
        return super().log_train(train_infos, total_num_steps)

    def _drain_async(self, *, wait):
        while self._async_jobs:
            job = self._async_jobs[0]
            if not wait and not job["future"].done():
                break
            if wait:
                super()._report_progress(
                    "waiting_for_async_evaluation",
                    evaluation_label=job["label"],
                    async_pending=len(self._async_jobs),
                )
            response = job["future"].result()
            snapshot = torch.load(job["snapshot_path"], map_location="cpu", weights_only=False)
            from onpolicy.utils.training_stage import protected_parameter_summary
            digest = protected_parameter_summary(snapshot["model"], prefixes=("",))["sha256"]
            if digest != job["model_sha256"]:
                raise RuntimeError("The submitted full checkpoint changed during evaluation.")
            previous_steps = self.total_num_steps
            self._async_consuming = True
            self._async_snapshot = snapshot
            self.total_num_steps = job["training_step"]
            try:
                score = float(super()._consume_raw_evaluation(
                    response["evaluation"], evaluation_label=job["label"]
                ))
                info = self._evaluation_log_info(score)
                self.log_train(info, self.total_num_steps)
                improved = self._update_best_checkpoints(job["episode"], "best_eval")
                extra = {
                    "stage": "epoch_eval" if job["episode"] >= 0 else "pre_ppo_baseline",
                    "eval_makespan": score, "selection_score": score,
                    "eval_raw_makespan": float(self.last_eval_raw_makespan),
                    "eval_iid_makespan": float(self.last_eval_iid_makespan),
                    "eval_composite_makespan": float(self.last_eval_composite_makespan),
                    "eval_tail_makespan": float(self.last_eval_tail_makespan),
                    "evaluation_tau": float(self.evaluation_tau),
                    "evaluation_request_id": job["request_id"],
                    "evaluation_model_sha256": digest,
                }
                if job["episode"] < 0:
                    for name in ("checkpoint_PrePPO.pt", "checkpoint_PrePPO_tau03.pt"):
                        self.save(-1, filename=name, extra=extra)
                else:
                    self.save(job["episode"], extra=extra)
                record = {key: value for key, value in job.items()
                          if key not in {"future", "request"}}
                record.update({
                    "score": score if math.isfinite(score) else None,
                    "valid": math.isfinite(score), "improved": improved,
                    "completed_unix_time": time.time(),
                })
                self._async_completed.append(record)
                super()._report_progress(
                    "async_evaluation_completed", evaluation_label=job["label"],
                    evaluation_model_sha256=digest, **info,
                )
                print(f"[AsyncEval] consumed {job['label']} score={score:.4f} best={improved}", flush=True)
            finally:
                self.total_num_steps = previous_steps
                self._async_snapshot = None
                self._async_consuming = False
            self._async_jobs.pop(0)
            self._write_async_status()

    def _plane_bc_update(self, *args, **kwargs):
        actor = self.policy.ac.actor
        if self.policy.ac.stage1_baseline != "l2d":
            return super()._plane_bc_update(*args, **kwargs)
        previous = bool(getattr(actor, "operation_teacher_replay", False))
        actor.operation_teacher_replay = True
        try:
            result = super()._plane_bc_update(*args, **kwargs)
            if result is not None:
                result["l2d_teacher_site_overrides_cumulative"] = int(getattr(
                    actor, "teacher_site_override_count", 0
                ))
            return result
        finally:
            actor.operation_teacher_replay = previous

    def run(self):
        try:
            result = super().run()
            self._drain_async(wait=True)
            self._write_async_status()
            return result
        finally:
            if self._async_executor is not None:
                self._async_executor.shutdown(wait=True, cancel_futures=True)
