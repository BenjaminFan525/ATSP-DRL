"""Execution-only four-rank sharding of the original two-rank tau batches."""
from pathlib import Path

VERSION = 'stage3-tau-two-arms-4x6-v1'
RESIZE_VERSION = 'stage3-tau-two-arms-4x12-v1'
NO_KL_REPLAY_VERSION = 'stage3-tau-no-kl-replay-v1'
PLACEMENT = {'T1_ANNEAL10': [0, 1, 2, 3], 'T3_ANNEAL10_RISK': [4, 5, 6, 7]}
STOPPED = ('T0_FIXED03', 'T2_ANNEAL30')
FIELDS = ('case_id', 'group_id', 'replica', 'seed', 'makespan', 'completed',
          'behavior_deterministic', 'forced_replay', 'policy_updates', 'population_weight')


def split_shards(shards, physical_microbatch=6):
    logical_microbatch = 2 * physical_microbatch
    if (physical_microbatch not in (6, 12) or len(shards) != 2
            or len(shards[0]) != len(shards[1]) or len(shards[0]) % logical_microbatch):
        raise ValueError('Expected two equal logical shards with whole optimizer minibatches')
    return [[row for first in range(0, len(shards[rank % 2]), logical_microbatch)
             for row in shards[rank % 2][first+(rank//2)*physical_microbatch:
                                        first+(rank//2+1)*physical_microbatch]]
            for rank in range(4)]


def resource_sizes(m):
    version = m['resource_restart']['version']
    if version == VERSION:
        return 30, 6
    if version == RESIZE_VERSION:
        return 60, 12
    raise ValueError('Unknown resource continuation version')


def verify_resource_contract(m):
    r = m['resource_restart']
    width, micro = resource_sizes(m)
    if (r['placement'] != PLACEMENT
            or r['stopped_arms'] != list(STOPPED) or r['until_epochs'] != 4
            or r['logical_world_size'] != 2 or r['physical_world_size'] != 4
            or r['global_rollout_trajectories'] != 4*width
            or r['global_optimizer_trajectories'] != 4*micro
            or r['automatic_e8_continuation'] is not False
            or r['bitwise_equivalence_claimed'] is not False
            or m['throughput']['rollout_envs_per_rank'] != width
            or m['throughput']['backward_trajectories_per_rank'] != micro
            or set(r['resume_commits']) != set(PLACEMENT)):
        raise ValueError('Two-arm continuation contract changed')
    if r['version'] == RESIZE_VERSION:
        resize = r['batch_resize']
        switch = resize['switch_episodes']
        if (resize['factor'] != 2 or resize['from_version'] != VERSION
                or resize['optimization_equivalence_claimed'] is not False
                or type(switch) is not int or switch <= 0 or switch >= m['training']['first_stage_episodes']
                or switch % m['training']['episodes_per_data_epoch']
                or ('kl_replay_restart' not in m and
                    any(ref['training_episodes'] != switch for ref in r['resume_commits'].values()))):
            raise ValueError('Batch doubling requires a common complete data-epoch checkpoint')
    if 'kl_replay_restart' in m:
        from onpolicy.utils.stage3_tau import training_plan
        from onpolicy.utils.stage3_research import digest_json
        change = m['kl_replay_restart']
        plan = training_plan(m, 2)
        boundaries = {b['training_episodes'] for b in plan
                      if b['training_episodes'] < m['training']['first_stage_episodes']}
        if (r['version'] != RESIZE_VERSION or change.get('version') != NO_KL_REPLAY_VERSION
                or change.get('minibatch_replay') is not False
                or change.get('whole_batch_replay') is not False
                or change.get('pre_step_soft_kl') is not True
                or change.get('technical_rollback') is not True
                or change.get('optimization_equivalence_claimed') is not False
                or change.get('parent_schedule_sha256') != digest_json(plan)
                or change.get('switch_episodes') != {
                    arm: ref['training_episodes'] for arm, ref in r['resume_commits'].items()}
                or any(ref['training_episodes'] not in boundaries or ref['training_episodes'] < switch
                       for ref in r['resume_commits'].values())):
            raise ValueError('Invalid explicit KL replay restart contract')


def configure_kl_replay(runner, m):
    """Only this explicitly versioned continuation disables both replay guards."""
    if 'kl_replay_restart' in m:
        verify_resource_contract(m)
        from onpolicy.utils.stage3_ppo_transaction import PPOStepTransaction
        runner.ppo_step_controller = PPOStepTransaction(replay_enabled=False)


def global_targets(rows, arm, source_costs, distributed):
    from onpolicy.utils.stage3_rl_bridge import actor_targets
    from onpolicy.utils.stage3_tau import ARMS
    if arm not in PLACEMENT or distributed is None or distributed.world_size != 4:
        raise ValueError('Exactly four synchronized ranks of an approved tau arm required')
    gathered = distributed.gather([{k: r[k] for k in FIELDS} for r in rows])
    if len(gathered) != 4 or len({len(part) for part in gathered}) != 1:
        raise ValueError('Unequal physical shards change optimizer boundaries')
    complete = [row for part in gathered for row in part]
    advantages, weights, audit = actor_targets(complete, arm, source_costs, arm_spec=ARMS[arm])
    start = sum(len(part) for part in gathered[:distributed.rank])
    return advantages[start:start+len(rows)], weights[start:start+len(rows)], audit


def validated_commit(m, arm, path):
    """Hash and metadata audit of every rank before loading any resume state."""
    import torch
    from onpolicy.utils.stage3_distributed import state_digest
    from onpolicy.utils.stage3_research import read_json, digest_file, digest_json
    from onpolicy.utils.stage3_tau import training_plan, validate_temperature_state
    commit = read_json(path)
    world = 4 if 'resource_restart' in m else 2
    plan = training_plan(m, 2)
    episodes = commit['training_episodes']
    cursor = sum(b['training_episodes'] <= episodes for b in plan)
    if (not cursor or plan[cursor-1]['training_episodes'] != episodes
            or commit['manifest_sha256'] != m['manifest_sha256'] or commit['arm'] != arm
            or commit['phase'] != 'full' or commit['world_size'] != world
            or commit['schedule_sha256'] != digest_json(plan)
            or validate_temperature_state(commit['temperature_state'], arm) != episodes
            or len(commit['ranks']) != world
            or [r['rank'] for r in commit['ranks']] != list(range(world))):
        raise ValueError('Incomplete, foreign or inconsistent resume commit')
    states = []
    for entry in commit['ranks']:
        if digest_file(entry['checkpoint']) != entry['sha256']:
            raise ValueError('Committed checkpoint digest mismatch')
        payload = torch.load(entry['checkpoint'], map_location='cpu', weights_only=False)
        if (payload.get('diagnostic_only') is not False or payload['rank'] != entry['rank']
                or payload['world_size'] != world or payload['bridge_arm'] != arm
                or payload['protocol_sha256'] != m['manifest_sha256'] or payload['phase'] != 'full'
                or payload['schedule_sha256'] != commit['schedule_sha256']
                or payload['training_episodes'] != episodes or payload['next_group'] != cursor
                or payload['temperature_state'] != commit['temperature_state']
                or payload['policy_updates'] != commit['policy_updates']):
            raise ValueError('Resume payload does not match its full-rank commit')
        state = state_digest({k: payload[k] for k in ('model', 'actor_optim', 'critic_optim',
                               'role_value_normalizers', 'policy_updates')})
        # Commit hashes use TrajectoryParallel.assert_replicas' key names;
        # training_state uses checkpoint key names. Both include all states,
        # but their dictionary-key-sensitive digests are deliberately distinct.
        replica_state = state_digest(dict(model=payload['model'], actor=payload['actor_optim'],
            critic=payload['critic_optim'], norms=payload['role_value_normalizers'],
            policy_updates=payload['policy_updates']))
        if replica_state != entry['state_sha256']:
            raise ValueError('Saved training state does not match its commit')
        states.append(state)
    if len(set(states)) != 1:
        raise ValueError('Committed rank model/optimizer/normalizer states diverge')
    return commit, cursor, states[0]


def resource_engine_class(physical_microbatch=6):
    """Lazy import keeps manifest/safety validation independent of torch/CUDA."""
    import numpy as np
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.runner.shared.stage3_tau_engine import TauEngine
    from onpolicy.utils.stage3_tau import temperature_state
    if physical_microbatch not in (6, 12):
        raise ValueError('Only the explicitly approved PPO batch sizes are supported')

    class ResourceTauEngine(TauEngine):
        def update(self, trajectories, mode='source', source_cost=None, *, distributed=None, **kwargs):
            if (mode != 'source' or kwargs.get('microbatch_size') != physical_microbatch
                    or kwargs.get('optimizer_step_per_microbatch') is not True):
                raise ValueError('PPO batch size disagrees with the resource contract')
            state = temperature_state(self.bridge_arm, self.committed_episodes)
            if self.exploration['taus'] != [state['sampling_tau']]*3:
                raise ValueError('Temperature changed inside the rollout/update batch')
            advantages, weights, audit = global_targets(trajectories, self.bridge_arm, source_cost, distributed)
            targets = {id(row): (a, w) for row, a, w in zip(trajectories, advantages, weights)}
            def objective(rows):
                if any(id(row) not in targets for row in rows):
                    raise ValueError('Objective escaped its immutable on-policy batch')
                return ([targets[id(row)][0] for row in rows], [targets[id(row)][1] for row in rows])
            self.stage3_actor_objective = objective
            try:
                result = B0Engine.update(self, trajectories, mode, source_cost, distributed=distributed, **kwargs)
            finally:
                del self.stage3_actor_objective
            result.update(temperature_state=state, bridge_objective=audit,
                trajectory_advantages=advantages.tolist(), population_weights=weights.tolist(),
                baseline_mode=audit['advantage_mode'], positive_advantage_fraction=float(np.mean(advantages > 0)),
                resource_execution=dict(version=VERSION if physical_microbatch == 6 else RESIZE_VERSION,
                    physical_world_size=4, logical_world_size=2,
                    global_optimizer_trajectories=4*physical_microbatch))
            return result
    return ResourceTauEngine
