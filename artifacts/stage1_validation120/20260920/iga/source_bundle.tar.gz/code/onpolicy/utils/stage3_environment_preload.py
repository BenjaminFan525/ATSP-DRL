"""CPU-only forkserver preload, never executed in a CUDA learner process.

Share read-mostly Python/library pages across real simultaneous environments.
No environment instance, training model, CUDA context or RNG seed is created.
"""
import gc
import torch

torch.set_num_threads(1)
from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv  # noqa: E402,F401
from onpolicy.envs.HKBZ.experiment.eval_common import completion_details  # noqa: E402,F401
from onpolicy.runner.shared.stage3_research_engine import _environment_worker  # noqa: E402,F401

if torch.cuda.is_initialized():
    raise RuntimeError('The environment forkserver must never initialize CUDA')
gc.collect()
gc.freeze()
