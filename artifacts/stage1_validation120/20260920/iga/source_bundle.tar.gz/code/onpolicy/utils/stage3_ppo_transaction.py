"""Explicit, bounded PPO step transactions; old experiments do not opt in."""
import copy
import math
import random

import numpy as np
import torch


def cpu_copy(value):
    if torch.is_tensor(value):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: cpu_copy(v) for k, v in value.items()}
    if isinstance(value, list):
        return [cpu_copy(v) for v in value]
    if isinstance(value, tuple):
        return tuple(cpu_copy(v) for v in value)
    return copy.deepcopy(value)


def snapshot(runner):
    return cpu_copy({
        "model": runner.policy.ac.state_dict(),
        "actor": runner.policy.actor_optimizer.state_dict(),
        "critic": runner.policy.critic_optimizer.state_dict(),
        "norms": {k: v.state_dict() for k, v in runner.norms.items()},
        "updates": runner.policy_updates, "lr": runner.policy.lr,
        "torch": torch.get_rng_state(), "numpy": np.random.get_state(),
        "python": random.getstate(),
        "cuda": torch.cuda.get_rng_state(runner.device) if runner.device.type == "cuda" else None,
    })


def restore(runner, state):
    runner.policy.ac.load_state_dict(state["model"], strict=True)
    runner.policy.actor_optimizer.load_state_dict(state["actor"])
    runner.policy.critic_optimizer.load_state_dict(state["critic"])
    for k, v in runner.norms.items():
        v.load_state_dict(state["norms"][k])
    runner.policy_updates = state["updates"]
    runner.policy.lr = state["lr"]
    torch.set_rng_state(state["torch"])
    np.random.set_state(state["numpy"])
    random.setstate(state["python"])
    if state["cuda"] is not None:
        torch.cuda.set_rng_state(state["cuda"], runner.device)


def max_role_kl(metrics):
    values = [float(metrics["kl"])]
    values += [float(v["kl"]) for v in metrics["roles"].values() if v["decisions"]]
    if any(not math.isfinite(v) for v in values):
        raise FloatingPointError("Nonfinite PPO KL is not a recoverable trust-region event")
    return max(values)


class PPOStepTransaction:
    def __init__(self, soft_kl=.02, hard_role_kl=.04, max_retries=2, lr_floor=1e-7, *,
                 replay_enabled=True):
        if not (0 < soft_kl < hard_role_kl and max_retries in (0, 1, 2) and lr_floor > 0):
            raise ValueError("Invalid bounded PPO trust-region recipe")
        if type(replay_enabled) is not bool:
            raise ValueError("KL replay requires an explicit boolean")
        self.soft_kl, self.hard_role_kl = soft_kl, hard_role_kl
        self.max_retries, self.lr_floor = max_retries, lr_floor
        self.replay_enabled = replay_enabled

    def step(self, runner, trajectories, stats, heartbeat=None, distributed=None):
        replay = lambda: runner.replay_metrics(trajectories, heartbeat, distributed=distributed)
        if not math.isfinite(float(stats["kl"])):
            raise FloatingPointError("Nonfinite training-forward KL")
        if stats["kl"] > self.soft_kl:
            return {"actor_step_applied": False, "stop_reason": "soft_kl_before_step",
                    "attempts": [], "post_update": replay() if self.replay_enabled else {},
                    "kl_replay_enabled": self.replay_enabled}
        # Clip exactly once: retries reuse the SAME actor/critic gradients.
        torch.nn.utils.clip_grad_norm_(runner.policy.ac.critic_param.parameters(), 1.,
                                       error_if_nonfinite=True)
        before = snapshot(runner)
        attempts = []
        sink = getattr(runner, "update_metrics_sink", None)
        for attempt in range(self.max_retries + 1 if self.replay_enabled else 1):
            if attempt:
                restore(runner, before)
            lr = max(self.lr_floor, before["lr"] * (.5 ** attempt))
            runner.set_actor_lr(lr)
            try:
                runner.policy.actor_optimizer.step()
                runner.policy_updates += 1
                runner.policy.critic_optimizer.step()
                if self.replay_enabled:
                    post = replay()
                    maximum = max_role_kl(post)
                else:
                    # No extra trajectory forward. Keep a cheap finite-parameter
                    # check and the technical transaction, not a fabricated KL=0.
                    finite = [torch.isfinite(p.detach()).all() for p in runner.policy.ac.parameters()]
                    if finite and not bool(torch.stack(finite).all()):
                        raise FloatingPointError("Nonfinite model after PPO optimizer step")
                    post, maximum = {}, None
            except BaseException:
                # Technical errors are NOT retried, but never leave a partially
                # applied Adam/model update behind for a later save.
                restore(runner, before)
                raise
            accepted = not self.replay_enabled or maximum <= self.hard_role_kl
            row = {"attempt": attempt, "actor_lr": lr, "accepted": accepted,
                   "max_role_mean_kl": maximum, "post_update": post,
                   "kl_replay_enabled": self.replay_enabled,
                   "gradient_norm_by_group": stats["gradient_norm_by_group"],
                   "actor_gradient_norm": stats["actor_gradient_norm"],
                   "policy_updates_before": before["updates"]}
            attempts.append(row)
            # Persist evidence BEFORE deciding to rollback or abort. No failed
            # KL event may disappear merely because result.json was not written.
            if sink is not None:
                sink(row)
            if accepted:
                return {"actor_step_applied": True, "attempts": attempts,
                        "post_update": post, "stop_reason": None,
                        "kl_replay_enabled": self.replay_enabled,
                        "accepted_actor_lr": lr, "rolled_back_attempts": attempt}
        restore(runner, before)
        runner.set_actor_lr(max(self.lr_floor, before["lr"] * (.5 ** (self.max_retries + 1))))
        return {"actor_step_applied": False, "attempts": attempts,
                "post_update": replay(), "stop_reason": "bounded_hard_kl_retries_exhausted",
                "rolled_back_attempts": len(attempts)}
