"""Stdlib-only safety monitor, outside the experiment's memory-limited slice."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

GIB = 2**30
SAFETY = dict(version='host-reserve-and-progress-v2', sample_seconds=10,
    host_reserve_gib=8, high_reserve_gib=16, available_stop_gib=8,
    available_emergency_gib=4, pressure_hold_seconds=20, memory_full_avg10_stop=10.,
    progress_warning_seconds=900, progress_stop_seconds=1800,
    worker_start_seconds=900, heartbeat_stop_seconds=120,
    scratch_minimum_free_gib=16, stop_timeout_seconds=20)
REPLAY_STORAGE = dict(directory='/tmp', cache_mib=64, minimum_free_gib=16)


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with temporary.open('w') as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def read_json(path):
    return json.loads(Path(path).read_text())


def pressure(path):
    return {row.split()[0]: {k: float(v) for k, v in
        (part.split('=') for part in row.split()[1:])} for row in Path(path).read_text().splitlines()}


def host_snapshot(cgroup=None):
    memory = {k: int(v.split()[0])*1024 for k, v in
              (line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())}
    vm = dict(line.split() for line in Path('/proc/vmstat').read_text().splitlines())
    row = dict(unix=time.time(), memory={k: memory[k] for k in
        ('MemTotal', 'MemAvailable', 'MemFree', 'Cached', 'AnonPages', 'SwapTotal', 'SwapFree')},
        pressure={k: pressure('/proc/pressure/'+k) for k in ('memory', 'cpu', 'io')},
        vmstat={k: int(v) for k, v in vm.items() if k.startswith(('pgscan', 'pgsteal', 'pswp', 'pgmajfault'))},
        scratch_free_bytes=shutil.disk_usage(REPLAY_STORAGE['directory']).free)
    if cgroup and Path(cgroup).is_dir():
        row['cgroup'] = {}
        for name in ('memory.current', 'memory.peak', 'memory.events', 'memory.stat', 'memory.swap.current'):
            file = Path(cgroup)/name
            if file.exists():
                row['cgroup'][name] = file.read_text().strip()
    return row


class PressureGuard:
    def __init__(self, policy=SAFETY):
        self.policy, self.pressure_since = policy, None

    def check(self, sample, now):
        p = self.policy
        available = sample['memory']['MemAvailable'] / GIB
        if available < p['available_emergency_gib']:
            return f'Host MemAvailable below emergency reserve: {available:.2f} GiB'
        if sample['scratch_free_bytes'] < p['scratch_minimum_free_gib']*GIB:
            return 'Replay SSD free space below safety reserve'
        full = sample['pressure']['memory']['full']['avg10']
        severe = available < p['available_stop_gib'] or full >= p['memory_full_avg10_stop']
        if severe:
            if self.pressure_since is None:
                self.pressure_since = now
            if now-self.pressure_since >= p['pressure_hold_seconds']:
                return f'Sustained host memory pressure: available={available:.2f} GiB, full PSI={full:.2f}%'
        else:
            self.pressure_since = None
        return None


def progress_issue(heartbeat, started, now, policy=SAFETY):
    if heartbeat is None:
        return 'Worker did not initialize' if now-started > policy['worker_start_seconds'] else None
    if heartbeat.get('status') == 'failed':
        return f"Worker failed: {heartbeat.get('error')}"
    if heartbeat.get('status') == 'completed':
        return None
    if now-heartbeat.get('heartbeat_unix', started) > policy['heartbeat_stop_seconds']:
        return 'Worker heartbeat expired'
    if heartbeat.get('event') == 'validator_idle':
        return None
    # Heartbeat thread ticks do not count as computational progress.
    if now-heartbeat.get('last_progress_unix', started) > policy['progress_stop_seconds']:
        return 'Worker made no computational progress before hard stall deadline'
    return None


def live_worker_rows(root, now):
    rows = []
    for pattern in ('canary/*/rank*/process_*.json', 'full/*/rank*/process_*.json',
                    'validator/workers/*/process_*.json'):
        for path in root.glob(pattern):
            process = read_json(path)
            proc = Path('/proc')/str(process['pid'])
            try:
                # PID reuse must not cause a stale record to describe another job.
                cmd = (proc/'cmdline').read_bytes()
                if str(root).encode() not in cmd:
                    continue
            except FileNotFoundError:
                continue
            heartbeat_file = path.parent/'heartbeat.json'
            heartbeat = read_json(heartbeat_file) if heartbeat_file.exists() else None
            issue = progress_issue(heartbeat, process['started_unix'], now)
            progress_age = now-(heartbeat or {}).get('last_progress_unix', process['started_unix'])
            rows.append(dict(path=str(path.parent), pid=process['pid'],
                event=(heartbeat or {}).get('event'), progress_age_seconds=progress_age,
                warning=progress_age > SAFETY['progress_warning_seconds'], issue=issue))
    return rows


def stop_workload(root, unit, reason, sample):
    receipt = dict(unix=time.time(), reason=reason, sample=sample,
        action='stop only this run training and validator units', automatic_retry=False)
    atomic_json(root/'guard_failure.json', receipt)
    status_path = root/'status.json'
    prior = read_json(status_path) if status_path.exists() else {}
    atomic_json(status_path, {**prior, 'status': 'failed', 'error': reason,
        'safety_stop': True, 'automatic_retry': False, 'unix': time.time()})
    # systemd TimeoutStopSec bounds cleanup; KillMode=control-group includes envs.
    subprocess.run(['systemctl', '--user', 'stop', '--no-block',
        unit+'-training.service', unit+'-validator.service'], check=True, timeout=15)


def run(manifest, unit):
    m = read_json(manifest)
    if m.get('runtime_safety', {}).get('policy') != SAFETY:
        raise ValueError('Missing or changed frozen runtime safety policy')
    root = Path(m['root'])
    expected = 'hkbz-'+root.name.replace('_', '-')
    if unit != expected or not root.name.startswith('stage3_tau_'):
        raise ValueError('Safety monitor cannot target foreign services')
    os.sched_setaffinity(0, m['resources']['plan']['controller'])
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    group = subprocess.check_output(['systemctl', '--user', 'show', unit+'.slice',
        '--property=ControlGroup', '--value'], text=True, timeout=10).strip()
    cgroup = '/sys/fs/cgroup'+group if group else None
    guard, begin = PressureGuard(), time.time()
    atomic_json(root/'guard_ready.json', dict(pid=os.getpid(), boot_id=boot,
        unix=begin, policy=SAFETY, cgroup=cgroup, manifest_sha256=m['manifest_sha256']))
    sample = None
    try:
        while True:
            sample = host_snapshot(cgroup)
            sample['workers'] = live_worker_rows(root, sample['unix'])
            with (root/'resource_samples.jsonl').open('a') as output:
                output.write(json.dumps(sample, sort_keys=True)+'\n')
            atomic_json(root/'guard_status.json', dict(unix=sample['unix'], boot_id=boot,
                pid=os.getpid(), available_gib=sample['memory']['MemAvailable']/GIB,
                memory_full_avg10=sample['pressure']['memory']['full']['avg10'],
                workers=sample['workers']))
            status = read_json(root/'status.json') if (root/'status.json').exists() else {}
            if status.get('status') == 'completed':
                return
            reason = guard.check(sample, sample['unix'])
            issues = [w for w in sample['workers'] if w['issue']]
            if issues:
                reason = f"{issues[0]['path']}: {issues[0]['issue']}"
            if status.get('status') == 'failed':
                reason = 'Controller failed: '+status.get('error', 'unknown')
            # Detect dead controllers as well as stale JSON. Startup has 120s grace.
            if sample['unix']-begin > 120:
                for suffix in ('training', 'validator'):
                    active = subprocess.run(['systemctl', '--user', 'is-active', '--quiet',
                        unit+'-'+suffix+'.service'], timeout=10).returncode == 0
                    if not active:
                        reason = f'{suffix} service is no longer active'
            if reason:
                stop_workload(root, unit, reason, sample)
                raise RuntimeError(reason)
            time.sleep(SAFETY['sample_seconds'])
    except BaseException as error:
        if not (root/'guard_failure.json').exists():
            stop_workload(root, unit, f'Safety monitor failed closed: {error}', sample)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--unit', required=True)
    args = parser.parse_args()
    run(args.manifest, args.unit)
