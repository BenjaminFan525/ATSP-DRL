"""Predeclared grouped temperature study. No IGA solver or supervised loss."""
import math
from pathlib import Path

from onpolicy.utils.stage3_rl_bridge import BridgeQueue, identity, distribution_weights, schedule
from onpolicy.utils.stage3_research import digest_file, digest_json, read_json, verify_cases
from onpolicy.utils.stage3_b0_protocol import B0_SHA, EVALUATION, HISTORY
from onpolicy.utils.stage2_frozen import PLANNING

SCHEMA = 'stage3-tau-full600-v1'
ARMS = {
    'T0_FIXED03': dict(native=False, advantage='leave_one_out', risk_lambda=0., risk_tolerance=.02,
                       tau_start=.03, tau_end=.03, gpus=[0, 1]),
    'T1_ANNEAL10': dict(native=False, advantage='leave_one_out', risk_lambda=0., risk_tolerance=.02,
                        tau_start=.10, tau_end=.03, gpus=[2, 3]),
    'T2_ANNEAL30': dict(native=False, advantage='leave_one_out', risk_lambda=0., risk_tolerance=.02,
                        tau_start=.30, tau_end=.03, gpus=[4, 5]),
    'T3_ANNEAL10_RISK': dict(native=False, advantage='leave_one_out', risk_lambda=1., risk_tolerance=.02,
                             tau_start=.10, tau_end=.03, gpus=[6, 7]),
}
TEMPERATURE = dict(version='committed-trajectories-cosine-v1', hold_episodes=960,
    anneal_end_episodes=4800, reference_episodes=9600, final_episodes=19200,
    diagnostic_taus=[.03, .1], batch_constant=True, no_reheat=True)
GATES = dict(minimum_gain=.005, main_gain=.01, breakthrough_gain=.02,
    control_validation_margin=.001, control_tune_margin=0., completion_rate=1.,
    resource_profile_regression=.005, severe_fraction=.05, tail_regression=.01)


def data_budget(case_count):
    """Keep K4, E4 selection and optional E8; only the case count changes."""
    if case_count not in (240, 600):
        raise ValueError('Only full600 or the exact approved subset240 is supported')
    per_epoch = case_count * 4
    return dict(training_split='train_subset240' if case_count == 240 else 'train_full600',
        unique_training_cases=case_count, episodes_per_data_epoch=per_epoch,
        first_stage_episodes=4*per_epoch, max_training_episodes=8*per_epoch,
        first_stage_total_budget=16*per_epoch, maximum_total_budget=24*per_epoch)


def subset_contract(full):
    # Reuse ONLY the immutable case selection, never the old IID1/OOD4 schedule.
    from onpolicy.utils.stage3_b0_subset240 import select_cases, SELECTION_PATH, SELECTION_SHA256, COUNTS
    chosen = select_cases(full)
    return dict(version='tau-exact-subset240-k4-v1',
        authorization='user-confirmed-exact-240-cases-keep-K4-other-settings-20260916',
        selection_file=SELECTION_PATH, selection_file_sha256=SELECTION_SHA256,
        case_count=240, distribution_counts=COUNTS, cases_sha256=digest_json(chosen),
        replicas_per_case=4, episodes_per_data_epoch=960,
        population_weights=distribution_weights(chosen),
        reference_split='train_full600', training_split='train_subset240',
        temperature_cursor='absolute committed trajectories; thresholds unchanged',
        diagnostics_and_capacity_split_unchanged=True)


def training_cases(m):
    return m['splits'][m['training'].get('training_split', 'train_full600')]


def verify_data(m):
    full = m['splits']['train_full600']
    if (len(full) != 600 or distribution_weights(full) != dict(iid=.625, ood_stress=2.5, ood_scale=2.5)):
        raise ValueError('Full600 reference corpus changed')
    split = m['training'].get('training_split')
    if split == 'train_subset240':
        from onpolicy.utils.stage3_b0_subset240 import select_cases
        if (m['splits'].get(split) != select_cases(full)
                or m.get('subset_training') != subset_contract(full)):
            raise ValueError('Exact subset240 selection or K4 contract changed')
    elif split != 'train_full600' or 'subset_training' in m or 'train_subset240' in m['splits']:
        raise ValueError('Unsupported or ambiguous active training split')
    expected = data_budget(len(training_cases(m)))
    if any(m['training'].get(key) != value for key, value in expected.items()):
        raise ValueError('Training budget does not match the active K4 case selection')


def temperature(arm, committed):
    if arm not in ARMS or type(committed) is not int or committed < 0 or committed > 19200:
        raise ValueError('Invalid arm or committed trajectory cursor')
    start, end = ARMS[arm]['tau_start'], ARMS[arm]['tau_end']
    if committed <= 960:
        return start
    if committed >= 4800:
        return end
    return end + (start-end)*.5*(1+math.cos(math.pi*(committed-960)/(4800-960)))


def temperature_state(arm, committed):
    return dict(version=TEMPERATURE['version'], arm=arm, committed_episodes=committed,
                sampling_tau=temperature(arm, committed), schedule_sha256=digest_json(TEMPERATURE))


def validate_temperature_state(state, arm):
    if state != temperature_state(arm, state.get('committed_episodes')):
        raise ValueError('Checkpoint temperature schedule/cursor changed')
    return state['committed_episodes']


def training_plan(m, world):
    if m.get('resource_restart', {}).get('version') == 'stage3-tau-two-arms-4x12-v1':
        if world != 2:
            raise ValueError('Resized resource plans use two logical / four physical shards')
        switch = m['resource_restart']['batch_resize']['switch_episodes']
        if switch % (len(training_cases(m))*4):
            raise ValueError('Batch doubling must start at a complete data-epoch boundary')
        old = schedule(training_cases(m), seed=m['training']['seed'], epochs=8,
                       world_size=2, width=60, phase='full')
        enlarged = schedule(training_cases(m), seed=m['training']['seed'], epochs=8,
                            world_size=2, width=120, phase='full')
        # Preserve the committed prefix exactly; do not reinterpret its cursor
        # against a new schedule or skip/repeat cases at the transition.
        joined = [b for b in old if b['training_episodes'] <= switch]
        joined += [b for b in enlarged if b['training_episodes'] > switch]
        return [{**batch, 'index': index} for index, batch in enumerate(joined)]
    return schedule(training_cases(m), seed=m['training']['seed'], epochs=8,
                    world_size=world, width=60, phase='full')


def resume_cursor(m, arm, commit, world):
    """Only one predeclared topology transition, at the complete E4 boundary."""
    old_world = commit['world_size']
    if (commit['manifest_sha256'] != m['manifest_sha256'] or commit['arm'] != arm
            or commit['phase'] != 'full' or old_world not in (2, 4) or world not in (2, 4)
            or commit['schedule_sha256'] != digest_json(training_plan(m, old_world))
            or validate_temperature_state(commit['temperature_state'], arm) != commit['training_episodes']):
        raise ValueError('Resume contract, schedule or temperature mismatch')
    episodes = commit['training_episodes']
    comparison_end = data_budget(len(training_cases(m)))['first_stage_episodes']
    if old_world != world and (old_world, world, episodes) != (2, 4, comparison_end):
        raise ValueError('Topology may change only from 2 to 4 ranks at E4')
    old = training_plan(m, old_world)
    if episodes not in {b['training_episodes'] for b in old}:
        raise ValueError('Resume is not a committed batch boundary')
    if len(commit['ranks']) != old_world or [r['rank'] for r in commit['ranks']] != list(range(old_world)):
        raise ValueError('Incomplete or reordered rank commit')
    if len({r['state_sha256'] for r in commit['ranks']}) != 1:
        raise ValueError('Committed optimizer/model replicas diverge')
    return sum(b['training_episodes'] <= episodes for b in training_plan(m, world))


def risk_pass(s):
    return (s.get('completion_rate') == 1. and s.get('regression_over_5pct_fraction', 1.) <= .05
        and s.get('tail_makespan', math.inf) <= s.get('source_tail_makespan', 0.)*1.01
        and all(s.get('profiles', {}).get(p, {}).get('regression_fraction', math.inf) <= .005
                for p in ('resource_ood', 'resource_sparse')))


def select_candidate(evaluations):
    """Fixed E4 endpoint; subset E4 may precede the unchanged anneal endpoint."""
    control = evaluations['T0_FIXED03']
    passing = [a for a, row in evaluations.items() if a != 'T0_FIXED03'
        and all(risk_pass(row[s]) and row[s]['gain_fraction'] >= .005 for s in ('validation', 'tune'))
        and row['validation']['gain_fraction'] >= control['validation']['gain_fraction']+.001
        and row['tune']['gain_fraction'] >= control['tune']['gain_fraction']]
    return min(passing, key=lambda a: (evaluations[a]['validation']['makespan'], a)) if passing else None


class TauQueue(BridgeQueue):
    @staticmethod
    def identity(request):
        return digest_json(dict(bridge=BridgeQueue.identity(request),
            sampling_eval_tau=request.get('sampling_eval_tau'), decoder=request.get('decoder'),
            manifest=request['manifest_sha256']))


def verify(m, *, source_root=None, inputs=True):
    if (m['schema'] != SCHEMA or identity(m) != m['manifest_sha256'] or m['arms'] != ARMS
            or m['temperature'] != TEMPERATURE or m['gates'] != GATES
            or m['contract'] != PLANNING or m['evaluation'] != EVALUATION or m['history'] != HISTORY
            or m['source']['sha256'] != B0_SHA or m['iga']['allow_solve'] is not False
            or m['iga']['mode'] != 'frozen_artifacts_only' or m['automatic_confirmation'] is not False
            or m['automatic_active_search'] is not False):
        raise ValueError('Temperature experiment immutable contract changed')
    verify_data(m)
    if 'resource_restart' in m:
        from onpolicy.utils.stage3_tau_resources import verify_resource_contract
        verify_resource_contract(m)
    if 'resource_restart' in m:
        from onpolicy.utils.stage3_tau_resources import resource_sizes
        expected_rollout, expected_backward = resource_sizes(m)
    else:
        expected_rollout, expected_backward = 60, 12
    if (m['training']['data_epochs'] != 8 or m['training']['comparison_epoch'] != 4
            or m['training']['replicas_per_case'] != 4 or m['training']['ppo_epochs'] != 2
            or m['training']['tbptt_steps'] != 8 or m['training']['actor_lr'] != 1e-5
            or m['training']['supervised_actor_losses'] or m['training']['teacher_fit_gate']
            or m['throughput']['rollout_envs_per_rank'] != expected_rollout
            or m['throughput']['backward_trajectories_per_rank'] != expected_backward
            or ('runtime_safety' not in m and m['resources']['memory_max_gib'] is not None)):
        raise ValueError('Data, budget or throughput contract changed')
    if 'runtime_safety' in m:
        from onpolicy.utils.stage3_host_guard import SAFETY, REPLAY_STORAGE, GIB
        safety = m['runtime_safety']
        if (safety['policy'] != SAFETY or m['replay_storage'] != REPLAY_STORAGE
                or safety['memory_max_bytes'] != safety['host_mem_total_bytes']-SAFETY['host_reserve_gib']*GIB
                or safety['memory_high_bytes'] != safety['host_mem_total_bytes']-SAFETY['high_reserve_gib']*GIB
                or m['resources']['memory_max_gib'] != safety['memory_max_bytes']/GIB
                or safety['capacity_waves'] != [['T2_ANNEAL30'], ['T0_FIXED03', 'T1_ANNEAL10', 'T3_ANNEAL10_RISK']]):
            raise ValueError('Frozen replay storage or host safety contract changed')
    root = Path(m['execution']['code_root'])
    if source_root is not None and Path(source_root).resolve() != root.resolve():
        raise ValueError('Execute this run source snapshot only')
    if digest_file(m['source']['path']) != B0_SHA or digest_file(m['source']['manifest']) != m['source']['manifest_file_sha256']:
        raise ValueError('Frozen B0 changed')
    if digest_json(read_json(Path(m['root'])/'baselines.json')) != m['baselines_sha256']:
        raise ValueError('Local B0 baseline table changed')
    if inputs:
        for rel, sha in m['code']['files'].items():
            if digest_file(root/rel) != sha:
                raise ValueError(f'Frozen source changed: {rel}')
        for path, sha in m['input_files'].items():
            if digest_file(path) != sha:
                raise ValueError(f'Frozen input changed: {path}')
        for name in ('train_full600', 'validation', 'tune'):
            verify_cases(m['splits'][name], training=name.startswith('train'))
        # Exact subset records were already checked against the verified full corpus.
        import importlib.metadata
        if any(importlib.metadata.version(k) != v for k, v in m['execution']['packages'].items()):
            raise ValueError('Installed package versions differ from frozen execution')
