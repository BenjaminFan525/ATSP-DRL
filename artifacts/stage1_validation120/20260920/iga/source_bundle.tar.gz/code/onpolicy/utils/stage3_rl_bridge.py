"""Contracts for the opt-in Stage3 RL bridge; IGA artifacts are READ ONLY.

No solver is imported here. Groups are kept whole on one rank so leave-one-out
advantages are computed from four independent, same-version complete rollouts.
"""
from collections import Counter, defaultdict
from pathlib import Path
import math

import numpy as np

from onpolicy.utils.stage3_research import (
    EvaluationQueue, digest_json, digest_file, read_json, verify_cases,
)
from onpolicy.utils.stage3_b0_protocol import B0_SHA, EVALUATION, HISTORY
from onpolicy.utils.stage2_frozen import PLANNING
from onpolicy.utils.stage3_representation import RepresentationQueue

SCHEMA = "stage3-rl-bridge-frozen-iga-v1"
ARMS = {
    "P0_SOURCE": {"native": False, "advantage": "source", "risk_lambda": 0., "gpus": [0, 1]},
    "P1_GROUP": {"native": False, "advantage": "leave_one_out", "risk_lambda": 0., "gpus": [2, 3]},
    "P2_NATIVE": {"native": True, "advantage": "leave_one_out", "risk_lambda": 0., "gpus": [4, 5]},
    "P3_NATIVE_RISK": {"native": True, "advantage": "leave_one_out", "risk_lambda": 1., "gpus": [6, 7]},
}
TARGET_WEIGHTS = {"iid": .50, "ood_stress": .45, "ood_scale": .05}
LATENT = {"version": "native-gaussian-window-v1", "dimension_per_role": 8,
          "window_events": 8, "sigma": .1, "mean_bound": 2.,
          "feature_map": "frozen-pointer-node-pair-v1", "zero_residual_exact": True,
          "request_feature_scales": [3600., 1000., 1000., 32., 32.]}


def identity(manifest):
    return digest_json({k: v for k, v in manifest.items() if k != "manifest_sha256"})


def distribution_weights(cases):
    counts = Counter(c["distribution"] for c in cases)
    if set(counts) != set(TARGET_WEIGHTS):
        raise ValueError("Every training phase must cover all three distributions")
    return {key: len(cases) * weight / counts[key] for key, weight in TARGET_WEIGHTS.items()}


def schedule(cases, *, seed, epochs, world_size, width=60, replicas=4, phase="screen"):
    if replicas != 4 or width % replicas or world_size not in (2, 4):
        raise ValueError("Whole four-replica groups and two/four-rank arms are required")
    if len(cases) % world_size or len({c["path"] for c in cases}) != len(cases):
        raise ValueError("Unique cases must partition evenly across ranks")
    weights, result, episodes = distribution_weights(cases), [], 0
    per_batch = world_size * width // replicas
    for epoch in range(epochs):
        ordered = sorted(cases, key=lambda c: digest_json([seed, phase, epoch, c["content_sha256"]]))
        for first in range(0, len(ordered), per_batch):
            block = ordered[first:first + per_batch]
            if len(block) % world_size:
                raise ValueError("Ragged case tail would give different optimizer minibatches per rank")
            shards = []
            for rank in range(world_size):
                rows = []
                for case in block[rank::world_size]:
                    gid = digest_json([phase, epoch, case["content_sha256"]])
                    for replica in range(replicas):
                        rows.append({"case": case, "replica": replica, "group_id": gid,
                            "weight": weights[case["distribution"]], "seed": int(digest_json(
                                [seed, phase, epoch, case["content_sha256"], replica])[:15], 16) % (2**31-1)})
                shards.append(rows)
            episodes += len(block) * replicas
            result.append({"index": len(result), "epoch": epoch+1, "shards": shards,
                "training_episodes": episodes, "epoch_tail": first+len(block) == len(cases),
                "batch_size": len(block)*replicas})
    return result


def actor_targets(rows, arm, source_costs, replicas=4, *, arm_spec=None):
    """Return immutable per-trajectory advantages and fixed population weights."""
    spec = ARMS.get(arm) if arm_spec is None else arm_spec
    if spec is None or not rows:
        raise ValueError("Unknown arm or empty rollout")
    groups = defaultdict(list)
    for i, row in enumerate(rows):
        if (not row.get("completed") or row.get("behavior_deterministic") or row.get("forced_replay")
                or not math.isfinite(row["makespan"]) or row["makespan"] <= 0):
            raise ValueError("Only unforced, complete stochastic rollouts are PPO data")
        groups[row["group_id"]].append(i)
    advantages = np.zeros(len(rows), dtype=np.float64)
    transformed = np.zeros(len(rows), dtype=np.float64)
    evidence = []
    for gid, indices in groups.items():
        items = [rows[i] for i in indices]
        if (len(items) != replicas or {r["replica"] for r in items} != set(range(replicas))
                or len({r["seed"] for r in items}) != replicas
                or len({r["case_id"] for r in items}) != 1
                or len({r["policy_updates"] for r in items}) != 1):
            raise ValueError("Incomplete, duplicated, mixed-case or mixed-version replica group")
        base = float(source_costs[items[0]["case_id"]])
        if not math.isfinite(base) or base <= 0:
            raise ValueError("Missing finite positive frozen B0 cost")
        costs = np.array([r["makespan"] for r in items], dtype=np.float64)
        objective = costs + spec["risk_lambda"] * np.maximum(0., costs - (1+spec.get("risk_tolerance", .05))*base)
        baseline = (np.full(replicas, base) if spec["advantage"] == "source"
                    else (objective.sum()-objective)/(replicas-1))
        advantages[indices] = .01*(baseline-objective)
        transformed[indices] = objective
        evidence.append({"group_id": gid, "case_id": items[0]["case_id"], "source_cost": base,
            "costs": costs.tolist(), "objective_costs": objective.tolist(),
            "advantages": advantages[indices].tolist(), "policy_updates": items[0]["policy_updates"],
            "best_gain": 1-float(costs.min())/base, "mean_gain": 1-float(costs.mean())/base})
    weights = np.array([r["population_weight"] for r in rows], dtype=np.float64)
    if not np.isfinite(weights).all() or (weights <= 0).any():
        raise ValueError("Invalid fixed distribution weights")
    return advantages, weights, {"arm": arm, "groups": evidence,
        "advantage_mode": spec["advantage"], "risk_lambda": spec["risk_lambda"],
        "objective_costs": transformed.tolist(), "both_advantage_signs_retained": True}


def risk_pass(summary):
    from onpolicy.utils.stage3_representation import risk_pass as original
    return (original(summary) and
            summary.get("profiles", {}).get("resource_ood", {}).get("regression_fraction", float('inf')) <= .005)


def select_candidate(evaluations, *, minimum_gain=.0025):
    """Exploratory selection; risk-qualified validation Best, Tune is a veto."""
    control = evaluations["P0_SOURCE"]
    passing = []
    for arm, splits in evaluations.items():
        if arm == "P0_SOURCE":
            continue
        val, tune = splits["validation"], splits["tune"]
        if (risk_pass(val) and risk_pass(tune) and val["gain_fraction"] >= minimum_gain
                and tune["gain_fraction"] >= 0
                and val["makespan"] < control["validation"]["makespan"]
                and tune["makespan"] <= control["tune"]["makespan"]):
            passing.append(arm)
    return min(passing, key=lambda a: (evaluations[a]["validation"]["makespan"], a)) if passing else None


def diagnostic_summary(evaluations, source_costs):
    """Keep greedy, sampling mean and best-of4 as different estimands."""
    from onpolicy.utils.stage3_research import paired_summary
    grouped = defaultdict(list)
    for result in evaluations:
        if result['kind'] != 'role_mix':
            grouped[(result['arm'], result['kind'])].extend(result['cases'])
    report = {}
    best_costs = {}
    for (arm, kind), rows in grouped.items():
        entry = report.setdefault(arm, {})
        if kind == 'greedy':
            entry['greedy'] = paired_summary(rows, source_costs)
            continue
        by_case = defaultdict(list)
        for row in rows:
            by_case[row['case_id']].append(row)
        if any(len(items) != 4 or len({r['seed'] for r in items}) != 4
               or not all(r['completed'] for r in items) for items in by_case.values()):
            raise ValueError('Sampling diagnostics require four complete independent draws per case')
        means = [{**items[0], 'makespan': float(np.mean([r['makespan'] for r in items]))}
                 for items in by_case.values()]
        best = [min(items, key=lambda r: r['makespan']) for items in by_case.values()]
        entry['sampling_mean'] = paired_summary(means, source_costs)
        entry['best_of4'] = paired_summary(best, source_costs)
        best_costs[arm] = best
    if 'B0' in best_costs:
        baseline = {r['case_id']: r['makespan'] for r in best_costs['B0']}
        for arm, rows in best_costs.items():
            if arm != 'B0':
                report[arm]['best_of4_vs_B0_best_of4'] = paired_summary(rows, baseline)
    return {'arms': report, 'scope': 'train-only diagnostic; best-of4 is NOT single-greedy RL improvement'}


class BridgeQueue(RepresentationQueue):
    @staticmethod
    def identity(request):
        return digest_json({"base": EvaluationQueue.identity(request),
            "arm": request["arm"], "kind": request["kind"],
            "latent": request.get("latent"), "role_mix": request.get("role_mix"),
            "sample_seeds": request.get("sample_seeds")})


def queue(m):
    if m.get('schema') == 'stage3-tau-full600-v1':
        from onpolicy.utils.stage3_tau import TauQueue
        return TauQueue(Path(m['root'])/'validator')
    return BridgeQueue(Path(m["root"])/"validator")


def verify(m, *, source_root=None, inputs=True):
    if m.get('schema') == 'stage3-tau-full600-v1':
        from onpolicy.utils.stage3_tau import verify as verify_tau
        return verify_tau(m, source_root=source_root, inputs=inputs)
    if (m["schema"] != SCHEMA or identity(m) != m["manifest_sha256"] or m["arms"] != ARMS
            or m["contract"] != PLANNING or m["evaluation"] != EVALUATION
            or m["history"] != HISTORY or m["source"]["sha256"] != B0_SHA
            or m["iga"]["allow_solve"] is not False or m["iga"]["mode"] != "frozen_artifacts_only"
            or m["latent"] != LATENT or m["automatic_confirmation"] is not False):
        raise ValueError("RL bridge immutable experiment contract changed")
    if digest_file(m["source"]["path"]) != B0_SHA:
        raise ValueError("Frozen Stage2 B0 changed")
    if digest_json(read_json(Path(m['root'])/'baselines.json')) != m['baselines_sha256']:
        raise ValueError('Frozen local B0 baseline table changed')
    if source_root is not None and Path(source_root).resolve() != Path(m["execution"]["code_root"]).resolve():
        raise ValueError("Execute only this run's source snapshot")
    if inputs:
        root = Path(m["execution"]["code_root"])
        for rel, expected in m["code"]["files"].items():
            if digest_file(root/rel) != expected:
                raise ValueError(f"Frozen source changed: {rel}")
        for path, expected in m["input_files"].items():
            if digest_file(path) != expected:
                raise ValueError(f"Frozen input changed: {path}")
        for name in ("train_full600", "train_screen96", "validation", "tune"):
            verify_cases(m["splits"][name], training=name.startswith("train"))


def baseline_costs(m):
    row = read_json(Path(m["root"])/"baselines.json")
    if (row["source_sha256"] != B0_SHA or row["evaluation"] != EVALUATION
            or digest_json(row["costs"]) != row["costs_sha256"]):
        raise ValueError("Unmatched B0 baseline")
    return row["costs"]
