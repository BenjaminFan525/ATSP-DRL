"""Portable scientific contract and a single shared B0 evaluation queue."""
import math
from pathlib import Path

from onpolicy.utils.stage2_frozen import PLANNING
from onpolicy.utils.stage3_full_data import schedule, COUNTS, QUOTAS
from onpolicy.utils.stage3_representation import RepresentationQueue
from onpolicy.utils.stage3_research import (
    atomic_json, read_json, digest_file, digest_json, code_changes, verify_cases,
)

SCHEMA = "stage3-private-b0-full-data-v2"
HISTORY = "b0_native_environment_authoritative_v1"
B0_SHA = "b7740b2b688c83dc7fa65bed6381243cdf2f6675f4b96808ff05a41d4e44e7e8"
EVALUATION = {"decoder": "b0_native_hungarian", "history": HISTORY, "tau": .3, "seed": 1,
              "inference_batching": "per_case_v1"}
TRAINING = {
    "seed": 2026091201, "data_epochs": 8, "episodes_per_data_epoch": 960,
    "max_training_episodes": 7680, "global_batch": 32, "ppo_epochs": 2,
    "tbptt_steps": 8, "actor_lr": 1e-5, "critic_lr": 1e-4,
    "encoder_lr_scales": [1., 1., 1.], "head_lr_scales": [.25, 1., .5],
    "soft_kl": .02, "post_update_hard_kl": .04, "max_kl_retries": 2,
    "actor_lr_floor": 1e-7, "zero_update_pause_batches": 3,
    "ppo_clip": .2, "clip_norm": 1., "gamma": 1.,
    "advantage": ".01*(frozen_B0_native_case_cost - trajectory_cost)",
    "objective": "global visit mean; time and role sum; keep both advantage signs",
    "temperature_candidates": [.03, .1], "automatic_multi_seed": False,
    "supervised_actor_losses": False, "teacher_fit_gate": False,
}
MECHANISM = {"data_epochs": [0, 1, 2, 4, 8], "cases": 8,
             "fresh_replicas": 4, "fixed_b0_replicas": 2,
             "selection": "train-only content-hash stratified iid4/stress3/scale1"}
LOCAL_BASELINE = {
    "version": "b0-machine-local-recalibration-v1",
    "reference": "fresh frozen B0, fixed per_case_v1 inference on this host",
    "historical_release": "preserved unchanged; comparison report only, not an admission gate",
    "native_cases": 780, "strict_pair_cases": 212,
    "paired_splits": ["TrainDiag32", "Validation120", "Tune60"],
    "pairing": {"cost_atol": 1e-6, "action_sha256": "exact", "steps": "exact"},
    "reuse_historical_trajectories": False,
}


class B0Queue(RepresentationQueue):
    @staticmethod
    def identity(request):
        fields = {"representation_key": RepresentationQueue.identity(request),
            "source_sha256": request["source_sha256"], "comparison_sha256": request["comparison_sha256"],
            "kind": request["kind"], "diagnostic": request.get("diagnostic")}
        # Keep historical identities unchanged; raw initialization is a distinct result type.
        if request.get("raw_initialization"):
            fields["raw_initialization"] = True
        return digest_json(fields)


def identity(manifest):
    return digest_json({k: v for k, v in manifest.items() if k != "manifest_sha256"})


def comparison_contract(splits, baseline_reference=None, *, training=None):
    result = {"source_sha256": B0_SHA, "planning": PLANNING, "history": HISTORY,
            "evaluation": EVALUATION, "training": TRAINING if training is None else training, "mechanism": MECHANISM,
            "splits": {s: [{k: c[k] for k in ("name", "content_sha256", "profile", "distribution")}
                            for c in cases] for s, cases in splits.items()}}
    if baseline_reference is not None:
        if baseline_reference != LOCAL_BASELINE:
            raise ValueError("Unknown B0 baseline reference")
        result["baseline_reference"] = baseline_reference
    return result


def verify(manifest, *, inputs=True):
    from onpolicy.utils.stage3_research import ROOT
    from onpolicy.utils.stage3_numerics import RUNTIME
    expected_training = TRAINING
    if manifest.get("throughput"):
        from onpolicy.utils.stage3_b0_throughput import parent_manifest, training_contract
        expected_training = training_contract(manifest["throughput"]["global_batch"])
        if manifest.get("subset_training"):
            from onpolicy.utils.stage3_b0_subset240 import training_contract as subset_training_contract
            expected_training = subset_training_contract()
        parent_manifest(manifest, evidence=inputs)
    if (manifest.get("schema") != SCHEMA or identity(manifest) != manifest["manifest_sha256"]
            or manifest["training"] != expected_training or manifest["contract"] != PLANNING
            or manifest["history"] != HISTORY or manifest["evaluation"] != EVALUATION
            or manifest["numerics"] != RUNTIME or manifest["source"]["sha256"] != B0_SHA
            or manifest["arms"] != {"C_PRIVATE": {"encoder": "F_PRIVATE", "gpus": list(range(8))}}):
        raise ValueError("B0 study scientific identity changed")
    if (digest_file(manifest["source"]["path"]) != B0_SHA
            or digest_file(manifest["source"]["manifest"]) != manifest["source"]["manifest_file_sha256"]
            or digest_json(comparison_contract(manifest["splits"], manifest.get("baseline_reference"), training=expected_training))
                != manifest["comparison_sha256"]):
        raise ValueError("Frozen source/comparison contract changed")
    if manifest.get("baseline_reference") is not None:
        if (manifest["baseline_reference"] != LOCAL_BASELINE
                or manifest.get("recalibration_authorization") != "user-approved-local-B0-20260912"
                or "reuse_receipt" in manifest.get("acceleration", {})):
            raise ValueError("Local recalibration requires explicit authorization and fresh evidence")
    if Path(manifest["execution"]["code_root"]).resolve() != ROOT.resolve():
        raise ValueError("Execute the source-matched snapshot, not the mutable workspace")
    if inputs:
        if code_changes(manifest["code"]["files"], ROOT):
            raise ValueError("Frozen execution source changed")
        for split, cases in manifest["splits"].items():
            verify_cases(cases, training=split in ("train_full600", "train_subset240"))
        for path, checksum in manifest["input_files"].items():
            if digest_file(path) != checksum:
                raise ValueError(f"Immutable input changed: {path}")
        import importlib.metadata
        if any(importlib.metadata.version(k) != v for k, v in manifest["execution"]["packages"].items()):
            raise ValueError("Execution dependencies changed")
    return code_changes(manifest["code"]["files"], manifest["execution"]["workspace_root"]) if inputs else {}


def queue(manifest):
    return B0Queue(manifest["resources"]["validator_queue"])


def baseline_costs(manifest, *, confirmation=False):
    if manifest.get("throughput"):
        from onpolicy.utils.stage3_b0_throughput import inherited_costs
        return inherited_costs(manifest, confirmation=confirmation)
    name = "confirmation_baseline.json" if confirmation else "baselines.json"
    record = read_json(Path(manifest["root"]) / name)
    if (record["source_sha256"] != B0_SHA
            or record["protocol_sha256"] != manifest["manifest_sha256"]
            or record["evaluation"] != EVALUATION
            or digest_json(record["costs"]) != record["costs_sha256"]):
        raise ValueError("Baseline belongs to another source/environment/decoder")
    expected = {c["path"] for s in (("confirmation",) if confirmation else
                ("train_full600", "validation", "tune")) for c in manifest["splits"][s]}
    if set(record["costs"]) != expected or any(not math.isfinite(v) or v <= 0 for v in record["costs"].values()):
        raise ValueError("Incomplete/invalid B0 case baseline")
    if manifest.get("baseline_reference") and not confirmation:
        from onpolicy.utils.stage3_b0_recalibration import verify_local_baseline
        verify_local_baseline(manifest, record)
    return record["costs"]


def submit(manifest, checkpoint, arm, episodes, representation, *, split, start=0, count=15,
           native=False, tag="", training_exploration=None, kind="native_cost", diagnostic=None,
           cases_override=None, owner_protocol=None, raw_initialization=False):
    cases = manifest["splits"][split][start:start + count] if cases_override is None else cases_override
    if not cases:
        raise ValueError("Empty evaluation request")
    request_id = f"{arm}_{split}_e{episodes:06d}_s{start:04d}{tag}"
    request = {
        "request_id": request_id, "checkpoint": str(Path(checkpoint).resolve()),
        "checkpoint_sha256": digest_file(checkpoint), "training_episodes": episodes,
        "arm": arm, "representation": representation, "native": native,
        "split": split, "case_start": start, "cases": cases, "cases_sha256": digest_json(cases),
        "code_sha256": manifest["code"]["sha256"], "contract_sha256": digest_json(PLANNING),
        "protocol_sha256": owner_protocol or manifest["manifest_sha256"], "comparison_sha256": manifest["comparison_sha256"],
        "evaluation_protocol": EVALUATION, "tau": .3, "seed": 1,
        "training_exploration": training_exploration, "source_sha256": B0_SHA,
        "kind": kind, "diagnostic": diagnostic,
    }
    if raw_initialization:
        request["raw_initialization"] = True
    validate_request(manifest, request)
    return queue(manifest).submit(request)


def submit_split(manifest, checkpoint, arm, episodes, representation, *, split, chunk_size=15, **kwargs):
    if chunk_size <= 0:
        raise ValueError("Evaluation chunk size must be positive")
    return [submit(manifest, checkpoint, arm, episodes, representation, split=split, start=i,
                   count=chunk_size, **kwargs)
            for i in range(0, len(manifest["splits"][split]), chunk_size)]


def validate_request(manifest, request):
    if (request["comparison_sha256"] != manifest["comparison_sha256"]
            or request["code_sha256"] != manifest["code"]["sha256"]
            or request["contract_sha256"] != digest_json(PLANNING)
            or request["evaluation_protocol"] != EVALUATION or request["tau"] != .3 or request["seed"] != 1
            or request["source_sha256"] != B0_SHA
            or digest_file(request["checkpoint"]) != request["checkpoint_sha256"]
            or digest_json(request["cases"]) != request["cases_sha256"]):
        raise ValueError("Shared validation request contract differs")
    if request.get("cache_key", B0Queue.identity(request)) != B0Queue.identity(request):
        raise ValueError("Validation request identity corrupted")
    if request["protocol_sha256"] != manifest["manifest_sha256"]:
        peer_path = Path(manifest["resources"]["validator_queue"]) / "peers" / (request["protocol_sha256"] + ".json")
        peer = read_json(peer_path)
        if (peer["comparison_sha256"] != manifest["comparison_sha256"] or peer["arm"] != request["arm"]
                or request["representation"] != "F_SHARED" or request["native"]):
            raise ValueError("Unregistered peer training route")
    elif (request["arm"], request["representation"]) not in (("B0", "NATIVE"), ("C_PRIVATE", "F_PRIVATE")):
        raise ValueError("Own protocol cannot impersonate another training route")
    if request["representation"] not in ("NATIVE", "F_SHARED", "F_PRIVATE"):
        raise ValueError("Unknown validation architecture")
    if request["native"] != (request["representation"] == "NATIVE"):
        raise ValueError("Native B0 must not be relabeled as a trained policy")
    if request["native"] and (request["checkpoint_sha256"] != B0_SHA or request["training_episodes"] != 0):
        raise ValueError("Invalid native baseline")
    available = {c["content_sha256"]: c for c in manifest["splits"][request["split"]]}
    if any(available.get(c["content_sha256"]) != c for c in request["cases"]):
        raise ValueError("Evaluation cases do not belong to the declared split")
    if request["kind"] not in ("native_cost", "mechanism"):
        raise ValueError("Unknown validation request kind")
    if request.get("raw_initialization") and not (
            manifest.get("acceleration") and request["kind"] == "native_cost"
            and request["arm"] == "C_PRIVATE" and request["representation"] == "F_PRIVATE"
            and request["protocol_sha256"] == manifest["manifest_sha256"]
            and not request["native"] and request["training_episodes"] == 0
            and (request["split"] in ("validation", "tune") or (
                manifest.get("baseline_reference") == LOCAL_BASELINE and request["split"] == "train_full600"
                and all(c in manifest["diagnostic"]["cases32"] for c in request["cases"])))):
        raise ValueError("Raw results are restricted to private zero-update preflight evaluation")
    if request["kind"] == "mechanism":
        from onpolicy.utils.stage3_b0_throughput import completed_epoch
        allowed = {c["content_sha256"] for c in manifest["diagnostic"]["mechanism_cases"]}
        admission = read_json(Path(manifest["root"]) / "sampling_admission.json")
        expected = {"recipe": MECHANISM, "sampling_sha256": digest_file(Path(manifest["root"]) / "sampling_admission.json"),
                    "selected_tau": admission["selected_tau"]}
        if (request["diagnostic"] != expected or request["split"] != "train_full600" or request["native"]
                or any(c["content_sha256"] not in allowed for c in request["cases"])
                or completed_epoch(manifest, request["training_episodes"]) not in MECHANISM["data_epochs"]):
            raise ValueError("Mechanism diagnostics must use the fixed train-only contract")
    elif request["diagnostic"] is not None:
        raise ValueError("Main native cost evaluation cannot carry diagnostic overrides")
    if request["split"] == "confirmation":
        approval = read_json(Path(manifest["root"]) / "confirmation_open.json")
        if (approval["comparison_sha256"] != manifest["comparison_sha256"]
                or set(approval["locks"]) != {"C_PRIVATE", "B_SHARED"}):
            raise ValueError("Confirmation requires BOTH route selections locked")
        for entry in approval["locks"].values():
            if digest_file(entry["path"]) != entry["sha256"]:
                raise ValueError("A route selection changed after confirmation opened")
        if not request["native"]:
            selection = read_json(approval["locks"][request["arm"]]["path"])
            if (selection["checkpoint_sha256"] != request["checkpoint_sha256"]
                    or selection["protocol_sha256"] != request["protocol_sha256"]):
                raise ValueError("Confirmation checkpoint is not the locked selection")


def submit_mechanism(manifest, checkpoint, episodes):
    path = Path(manifest["root"]) / "sampling_admission.json"
    diagnostic = {"recipe": MECHANISM, "sampling_sha256": digest_file(path),
                  "selected_tau": read_json(path)["selected_tau"]}
    cases = manifest["diagnostic"]["mechanism_cases"]
    return [submit(manifest, checkpoint, "C_PRIVATE", episodes, "F_PRIVATE", split="train_full600",
        start=i, tag="_mechanism", kind="mechanism", diagnostic=diagnostic, cases_override=cases[i:i+2])
        for i in range(0, len(cases), 2)]


def register_peer(manifest, peer, arm="B_SHARED"):
    if (peer.get("comparison_sha256") != manifest["comparison_sha256"]
            or peer.get("code", {}).get("sha256") != manifest["code"]["sha256"]
            or identity(peer) != peer.get("manifest_sha256") or arm != "B_SHARED"):
        raise ValueError("Peer must use the identical released B0 comparison/code contract")
    target = Path(manifest["resources"]["validator_queue"]) / "peers" / (peer["manifest_sha256"] + ".json")
    atomic_json(target, {"arm": arm, "comparison_sha256": manifest["comparison_sha256"],
                        "peer_manifest": peer}, overwrite=False)
    return target
