"""Execution-only acceleration: explicit evidence reuse and exclusive preflight leases.

No relaxed scientific gates, optimizer changes, or automatic reuse of trained weights.
"""
import ast
import math
from pathlib import Path
import re

from onpolicy.utils.stage3_b0_protocol import (
    B0_SHA, EVALUATION, PLANNING, B0Queue, baseline_costs, identity,
)
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json, code_changes


def pool_placements(plan, mode, gpus=()):
    if mode == "steady":
        if gpus:
            raise ValueError("Steady pool uses the two reserved CPU leases")
        return {f"steady_g{p['gpu']}": dict(p) for p in plan["validators"]}
    if mode != "boost" or not gpus or len(set(gpus)) != len(gpus) or not set(gpus) <= set(range(8)):
        raise ValueError("Boost pool requires distinct available GPUs")
    return {f"boost_g{g}": dict(plan["trainers"][str(g)]) for g in sorted(gpus)}


def assert_pool_request(m, request):
    expected = pool_placements(m["resources"]["plan"], request["mode"], request["gpus"])
    if (request["protocol_sha256"] != m["manifest_sha256"] or request["generation"] < 0
            or request["placements"] != expected):
        raise ValueError("Invalid elastic validator lease request")
    return expected


def complete_rows(rows, cases):
    expected = {c["path"]: c for c in cases}
    if len(rows) != len(expected) or {r["case_id"] for r in rows} != set(expected):
        raise ValueError("Evidence has incomplete or duplicate case coverage")
    for r in rows:
        c = expected[r["case_id"]]
        if (not r["completed"] or r["cycle_terminated"] or r["source_sha256"] != B0_SHA
                or r["history"] != EVALUATION["history"] or r["decoder"] != EVALUATION["decoder"]
                or r.get("inference_batching") != EVALUATION["inference_batching"]
                or r["seed"] != 1 or r["policy_updates"] != 0 or not r["behavior_deterministic"]
                or r["profile"] != c["profile"] or r["distribution"] != c["distribution"]
                or not re.fullmatch(r"[0-9a-f]{64}", r["action_sha256"])
                or not math.isfinite(r["makespan"]) or r["makespan"] <= 0):
            raise ValueError("Not complete, zero-update native B0 evidence")
    return rows


def source_equivalence(parent, child):
    """Fail closed on runtime changes; scheduling changes have an explicit allowlist."""
    if (identity(parent) != parent["manifest_sha256"]
            or digest_json(parent["code"]["files"]) != parent["code"]["sha256"]
            or code_changes(parent["code"]["files"], parent["execution"]["code_root"])):
        raise ValueError("Parent source or manifest changed")
    for field in ("comparison_sha256", "contract", "history", "evaluation", "training", "numerics", "splits", "diagnostic"):
        if parent[field] != child[field]:
            raise ValueError(f"Cannot reuse evidence after changing {field}")
    if (parent["execution"]["packages"] != child["execution"]["packages"]
            or parent["source"]["sha256"] != B0_SHA or child["source"]["sha256"] != B0_SHA
            or digest_file(parent["source"]["path"]) != B0_SHA
            or parent["source"]["manifest_file_sha256"] != child["source"]["manifest_file_sha256"]
            or parent["resources"]["validator_width"] != child["resources"]["validator_width"]):
        raise ValueError("B0, numerical runtime or evaluation batch width changed")
    allowed = {"onpolicy/scripts/train/run_stage3_b0.py", "onpolicy/scripts/train/stage3_b0_worker.py",
               "onpolicy/utils/stage3_b0_protocol.py", "STAGE3_PRIVATE_B0_20260912.md"}
    changed = sorted(p for p, h in parent["code"]["files"].items() if child["code"]["files"].get(p) != h)
    if set(changed) - allowed:
        raise ValueError(f"Non-scheduling runtime changed: {set(changed) - allowed}")
    protected = {
        "onpolicy/scripts/train/stage3_b0_worker.py":
            ("metadata", "engine", "evaluate", "collect", "initialization", "sampling", "diagnostic_batch", "train"),
        "onpolicy/utils/stage3_b0_protocol.py": ("identity", "comparison_contract", "verify", "baseline_costs"),
    }
    checked = []
    for file, names in protected.items():
        trees = []
        for m in (parent, child):
            tree = ast.parse((Path(m["execution"]["code_root"]) / file).read_text())
            trees.append({n.name: ast.dump(n, include_attributes=False) for n in tree.body
                          if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))})
        for name in names:
            if trees[0][name] != trees[1][name]:
                raise ValueError(f"Protected computation changed: {file}:{name}")
            checked.append(f"{file}:{name}")
    return {"changed_execution_files": changed, "identical_computation_functions": checked,
            "all_other_parent_source_files_identical": True}


def baseline_evidence(parent, path):
    result = read_json(path)
    match = re.fullmatch(r"B0_(train_full600|validation|tune)_e000000_s(\d{4})", result["request_id"])
    if not match:
        raise ValueError("Reuse accepts native B0 pretraining results only")
    split, start = match[1], int(match[2])
    cases = parent["splits"][split][start:start + 15]
    request = {"checkpoint_sha256": B0_SHA, "cases_sha256": digest_json(cases),
        "contract_sha256": digest_json(PLANNING), "code_sha256": parent["code"]["sha256"],
        "tau": .3, "seed": 1, "evaluation_protocol": EVALUATION, "training_exploration": None,
        "representation": "NATIVE", "protocol_sha256": parent["manifest_sha256"],
        "source_sha256": B0_SHA, "comparison_sha256": parent["comparison_sha256"],
        "kind": "native_cost", "diagnostic": None}
    if (not result["ok"] or result["error"] is not None or result["training_episodes"] != 0
            or any(result[k] != request[k] for k in ("checkpoint_sha256", "cases_sha256", "contract_sha256", "code_sha256"))
            or result["cache_key"] != B0Queue.identity(request)
            or result["evaluation"]["evaluation_protocol"] != EVALUATION
            or result["evaluation"]["source_sha256"] != B0_SHA):
        raise ValueError("Native baseline result provenance differs")
    return complete_rows(result["evaluation"]["cases"], cases)


def prepare_reuse(parent_path, child):
    parent = read_json(parent_path)
    root = Path(parent["root"])
    if (not (root / "validator/STOP").exists()
            or list((root / "validator/running").glob("*.json"))
            or list((root / "validator/pending").glob("*.json"))
            or list((root / "validator/failed").glob("*.json"))
            or read_json(root / "status.json").get("formal_training_started")):
        raise ValueError("Quiesce the parent's preflight services and drain running requests before reuse")
    proof = source_equivalence(parent, child)
    inputs = {str(Path(parent_path).resolve()): digest_file(parent_path)}
    native, baseline = [], []
    for rank in range(8):
        path = root / f"initialization/b0/rank{rank}/result.json"
        result = read_json(path)
        cases = parent["diagnostic"]["cases32"][rank::8]
        if not result["passed"] or not result["zero_rl_updates"] or result["source_sha256"] != B0_SHA:
            raise ValueError("Unpassed initialization evidence")
        a = complete_rows(result["cases"]["NATIVE"], cases)
        b = complete_rows(result["cases"]["F_PRIVATE"], cases)
        by_case = {r["case_id"]: r for r in b}
        if any(r["action_sha256"] != by_case[r["case_id"]]["action_sha256"]
               or abs(r["makespan"] - by_case[r["case_id"]]["makespan"]) > 1e-6 for r in a):
            raise ValueError("Private initialization changed B0 trajectories")
        native.extend(a)
        inputs[str(path)] = digest_file(path)
    for path in sorted((root / "validator/results").glob("*.json")):
        baseline.extend(baseline_evidence(parent, path))
        inputs[str(path)] = digest_file(path)
    if len({r["case_id"] for r in baseline}) != len(baseline):
        raise ValueError("Duplicate baseline evidence")
    init_path = root / "initialization/b0/rank0/initialization.json"
    init = read_json(init_path)
    if digest_file(init["checkpoint"]) != init["checkpoint_sha256"]:
        raise ValueError("Parent initialization checkpoint changed")
    inputs[str(init_path)] = digest_file(init_path)
    inputs[init["checkpoint"]] = init["checkpoint_sha256"]
    receipt = {"parent_manifest": str(Path(parent_path).resolve()), "parent_protocol_sha256": parent["manifest_sha256"],
        "parent_code_sha256": parent["code"]["sha256"], "source_sha256": B0_SHA,
        "comparison_sha256": child["comparison_sha256"], "evaluation": EVALUATION,
        "source_equivalence": proof, "input_files": inputs, "native_initialization_cases": native,
        "baseline_cases": baseline, "reused_baseline_cases": len(baseline),
        "parent_initialization_checkpoint": init["checkpoint"],
        "scope": "historical complete evidence, NOT fresh executions; no trained checkpoint reuse"}
    path = Path(child["root"]) / "reuse_evidence.json"
    atomic_json(path, receipt, overwrite=False)
    child["input_files"].update(inputs)
    child["input_files"][str(path)] = digest_file(path)
    return {"path": str(path), "sha256": digest_file(path)}


def reuse_receipt(m):
    entry = m["acceleration"]["reuse_receipt"]
    if digest_file(entry["path"]) != entry["sha256"]:
        raise ValueError("Reuse receipt changed")
    result = read_json(entry["path"])
    if (result["source_sha256"] != B0_SHA or result["comparison_sha256"] != m["comparison_sha256"]
            or result["evaluation"] != EVALUATION):
        raise ValueError("Reuse evidence belongs to another scientific contract")
    return result


def canary_costs(m, cases):
    if (Path(m["root"]) / "baselines.json").exists() or not m.get("acceleration"):
        costs = baseline_costs(m)
    elif m.get("baseline_reference"):
        from onpolicy.utils.stage3_b0_recalibration import diagnostic_costs
        costs = diagnostic_costs(m)
    else:
        receipt = reuse_receipt(m)
        rows = complete_rows(receipt["native_initialization_cases"], m["diagnostic"]["cases32"])
        costs = {r["case_id"]: r["makespan"] for r in rows}
    required = {c["path"] for c in cases}
    if not required <= costs.keys():
        raise ValueError("The technical canary's exact B0 case costs are not ready")
    # This function is used ONLY by diagnostic canaries, never train().
    return {p: costs[p] for p in required}


def fresh_private_initialization(m):
    import torch
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.scripts.train.stage3_b0_worker import metadata
    receipt = reuse_receipt(m)
    old = torch.load(receipt["parent_initialization_checkpoint"], map_location="cpu", weights_only=False)
    if (old.get("protocol_sha256") != receipt["parent_protocol_sha256"] or old.get("policy_updates") != 0
            or old.get("source_sha256") != B0_SHA or not old.get("initialization_only")
            or old.get("diagnostic_only") or old.get("training_episodes") != 0):
        raise ValueError("Only a genuine zero-update B0 initialization can supply reuse evidence")
    runner = B0Engine(m["source"]["manifest"], "F_PRIVATE", device="cpu", create_environments=False)
    try:
        model = runner.policy.ac.state_dict()
        if set(model) != set(old["model"]) or any(not torch.equal(v, old["model"][k]) for k, v in model.items()):
            raise ValueError("Fresh initialization is not tensor-identical to the trajectory-verified private model")
        if runner.policy.actor_optimizer.state or runner.policy.critic_optimizer.state or runner.policy_updates:
            raise ValueError("Fresh initialization contains optimizer history")
        path = Path(m["root"]) / "initialization/b0/rank0/private_init.pt"
        runner.save(path, **metadata(m, diagnostic_only=False, initialization_only=True,
                                    initialization_evidence_sha256=m["acceleration"]["reuse_receipt"]["sha256"]))
        atomic_json(path.parent / "initialization.json", {"checkpoint": str(path), "checkpoint_sha256": digest_file(path),
            "fresh_from_frozen_b0": True, "all_model_tensors_exact_to_parent": True, "zero_rl_updates": True,
            "trajectory_evidence_reused": m["acceleration"]["reuse_receipt"],
            "no_new_trajectory_checks_claimed": True}, overwrite=False)
        return path
    finally:
        runner.close()
