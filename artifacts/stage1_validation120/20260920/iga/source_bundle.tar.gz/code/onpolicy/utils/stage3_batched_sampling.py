"""Opt-in batched categorical sampling with independent trajectory RNG streams.

Only the random draw implementation changes, never logits, masks or returned
likelihoods. Seeds do not depend on rank, batch membership or completion order.
This is distribution-equivalent, not bitwise identical to legacy torch draws.
Native greedy and PPO forced-action replay bypass the new selector.
"""
from contextlib import contextmanager
import hashlib

import numpy as np
import torch

SAMPLING_VERSION = 'trajectory_pcg64_inverse_cdf_v1'
BATCHING_VERSION = 'live_batch_independent_rng_v1'


class TrajectorySamplingStreams:
    def __init__(self, seeds, agents):
        if not seeds or agents <= 0:
            raise ValueError('Nonempty trajectory seeds and positive agent count required')
        self.agents = int(agents)
        self.generators = [np.random.Generator(np.random.PCG64(int.from_bytes(
            hashlib.sha256(f'{SAMPLING_VERSION}:{int(seed)}'.encode()).digest()[:16], 'little')))
            for seed in seeds]

    def draw(self, indices):
        if not indices or len(set(indices)) != len(indices):
            raise ValueError('Distinct live trajectory indices required')
        # Inactive agents also get a draw; masks cannot shift another stream.
        return np.stack([self.generators[i].random(self.agents) for i in indices])


def categorical_from_uniform(logits, uniforms):
    if logits.ndim != 2 or uniforms.shape != logits.shape[:1]:
        raise ValueError('One uniform draw per categorical row required')
    uniforms = uniforms.to(device=logits.device, dtype=torch.float64)
    if not torch.isfinite(uniforms).all() or not ((uniforms >= 0) & (uniforms < 1)).all():
        raise ValueError('Categorical uniforms must lie in [0,1)')
    # Keep softmax in the original dtype, then sum the CDF in double precision.
    probs = torch.softmax(logits, dim=-1).to(torch.float64)
    cdf = probs.cumsum(-1)
    if not torch.isfinite(cdf).all() or not (cdf[:, -1] > 0).all():
        raise ValueError('Invalid categorical probability mass')
    limit = cdf[:, -1:]
    target = torch.minimum(uniforms[:, None]*limit, torch.nextafter(limit, torch.zeros_like(limit)))
    return torch.searchsorted(cdf.contiguous(), target.contiguous(), right=True).squeeze(-1)


@contextmanager
def sampling_uniforms(ac, uniforms, device):
    if getattr(ac, 'stage3_sampling_uniforms', None) is not None:
        raise ValueError('Nested batched sampling is forbidden')
    if torch.is_grad_enabled():
        raise ValueError('Batched sampling must run without autograd')
    ac.stage3_sampling_uniforms = torch.as_tensor(uniforms, dtype=torch.float64, device=device)
    try:
        yield
    finally:
        del ac.stage3_sampling_uniforms
