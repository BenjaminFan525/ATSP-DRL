"""Lossless, batch-local CPU graph offload. No policy, RNG or action changes.

Only graphs go to an anonymous SSD file. Small PPO fields remain in RAM so
behavior hashing, advantages and masks never deserialize graphs. The file is
not a checkpoint: closing the batch (or process) releases it automatically.
"""
from collections import OrderedDict
from collections.abc import Mapping
import os
import pickle
import shutil
import tempfile
import time
import zlib

import torch

from onpolicy.utils.stage3_performance import tensor_bytes


class ReplayState(Mapping):
    def __init__(self, fields, store, index):
        self.fields, self.store, self.index = fields, store, index

    def __getitem__(self, key):
        return self.store.load(self.index) if key == 'graph' else self.fields[key]

    def __iter__(self):
        yield 'graph'
        yield from self.fields

    def __len__(self):
        return 1 + len(self.fields)


class GraphReplayStore:
    def __init__(self, *, directory='/tmp', cache_mib=64, minimum_free_gib=16):
        if cache_mib < 0 or minimum_free_gib < 0:
            raise ValueError('Replay storage budgets must be nonnegative')
        self.minimum_free = int(minimum_free_gib * 2**30)
        self.directory = directory
        self._check_space()
        self.file = tempfile.TemporaryFile(mode='w+b', buffering=0,
                                          prefix='stage3-tau-replay-', dir=directory)
        self.limit = int(cache_mib * 2**20)
        self.entries, self.cache = [], OrderedDict()
        self.cache_bytes = self.peak_cache_bytes = self.written = self.raw_bytes = 0
        self.reads = self.hits = 0
        self.write_seconds = self.read_seconds = 0.
        self.closed = False

    def _check_space(self):
        if shutil.disk_usage(self.directory).free < self.minimum_free:
            raise RuntimeError('Insufficient SSD space for bounded Stage3 replay')

    def pack(self, state):
        if self.closed:
            raise RuntimeError('Replay batch has been released')
        if len(self.entries) % 256 == 0:
            self._check_space()
        start = time.perf_counter()
        graph = state['graph']
        # Retained observations must never serialize CUDA tensors / autograd.
        def check(value):
            if isinstance(value, torch.Tensor):
                if value.device.type != 'cpu' or value.requires_grad:
                    raise ValueError('Replay offload accepts detached CPU observations only')
            elif isinstance(value, dict):
                for item in value.values():
                    check(item)
            elif isinstance(value, (tuple, list)):
                for item in value:
                    check(item)
        check(graph.to_dict() if hasattr(graph, 'to_dict') else graph)
        raw = pickle.dumps(graph, protocol=5)
        payload = zlib.compress(raw, level=1)
        offset = self.written
        if os.pwrite(self.file.fileno(), payload, offset) != len(payload):
            raise OSError('Incomplete replay graph write')
        self.entries.append((offset, len(payload)))
        self.written += len(payload)
        self.raw_bytes += len(raw)
        self.write_seconds += time.perf_counter() - start
        return ReplayState({k: v for k, v in state.items() if k != 'graph'},
                           self, len(self.entries) - 1)

    def load(self, index):
        if self.closed:
            raise RuntimeError('Replay batch has been released')
        if index in self.cache:
            self.hits += 1
            graph, size = self.cache.pop(index)
            self.cache[index] = (graph, size)
            return graph
        start = time.perf_counter()
        offset, length = self.entries[index]
        payload = os.pread(self.file.fileno(), length, offset)
        if len(payload) != length:
            raise OSError('Truncated replay graph')
        # Only this process's own anonymous file is unpickled, never user input.
        graph = pickle.loads(zlib.decompress(payload))
        self.reads += 1
        size = 4096 + tensor_bytes(graph.to_dict() if hasattr(graph, 'to_dict') else graph)
        while self.cache and self.cache_bytes + size > self.limit:
            _, (_, removed) = self.cache.popitem(last=False)
            self.cache_bytes -= removed
        if size <= self.limit:
            self.cache[index] = (graph, size)
            self.cache_bytes += size
            self.peak_cache_bytes = max(self.peak_cache_bytes, self.cache_bytes)
        self.read_seconds += time.perf_counter() - start
        return graph

    def report(self):
        return dict(storage='lossless-zlib1-ssd-graphs-v1', graphs=len(self.entries),
            compressed_bytes=self.written, serialized_bytes=self.raw_bytes,
            graph_cache_budget_bytes=self.limit, graph_cache_peak_bytes=self.peak_cache_bytes,
            graph_reads=self.reads, graph_cache_hits=self.hits,
            write_seconds=self.write_seconds, read_seconds=self.read_seconds,
            ephemeral=True, directory=self.directory)

    def close(self):
        if not self.closed:
            self.cache.clear()
            self.cache_bytes = 0
            self.file.close()
            self.closed = True
