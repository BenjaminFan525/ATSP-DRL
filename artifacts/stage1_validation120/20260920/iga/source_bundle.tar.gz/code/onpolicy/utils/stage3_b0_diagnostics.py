"""Train-only mechanism measurements; no trajectory here can enter PPO."""
from pathlib import Path

import numpy as np

from onpolicy.utils.stage3_b0_protocol import MECHANISM, baseline_costs
from onpolicy.utils.stage3_research import digest_file, digest_json, read_json
from onpolicy.scripts.train.run_stage3_sampling_audit import trajectory_record


def likelihood_record(trajectory):
    if not trajectory["states"] and "likelihood" in trajectory:
        return trajectory["likelihood"]
    roles = {}
    action_rows = {str(r): [] for r in range(3)}
    for role in range(3):
        total, count = 0., 0
        for state in trajectory["states"]:
            selected = (state["roles"] == role) & state["mask"].astype(bool)
            total += float(np.asarray(state["old_logp"], dtype=np.float64)[selected].sum())
            count += int(selected.sum())
            action_rows[str(role)].append(state["action"][state["roles"] == role].tolist())
        roles[str(role)] = {"logp_sum": total, "decisions": count}
    return {"roles": roles, "role_action_sha256": {r: digest_json(v) for r, v in action_rows.items()}}


def fixed_references(manifest, case, tau):
    if manifest.get('throughput'):
        from onpolicy.utils.stage3_b0_throughput import reference_manifest
        manifest = reference_manifest(manifest)
    root = Path(manifest["root"])
    index = next(i for i, c in enumerate(manifest["diagnostic"]["cases32"]) if c == case)
    rank, local_index = index % 8, index // 8
    for replica in range(MECHANISM["fixed_b0_replicas"]):
        path = root / f"sampling/temperatures/rank{rank}/tau{tau}_r{replica}.json"
        sealed = read_json(root / "sampling_admission.json")["archives"]
        if digest_file(path) != sealed[str(path)]:
            raise ValueError("Fixed B0 likelihood archive changed")
        record = read_json(path)
        if (digest_file(record["trace"]["path"]) != record["trace"]["sha256"]
                or record["trace"]["sha256"] != sealed[record["trace"]["path"]]):
            raise ValueError("Fixed B0 action archive changed")
        reference = record["trajectories"][local_index]
        if reference["case_id"] != case["path"] or reference["exploration"]["taus"] != [tau] * 3:
            raise ValueError("Fixed B0 archive does not match the selected sampling recipe")
        with np.load(record["trace"]["path"], allow_pickle=False) as archive:
            actions = archive[f"trajectory_{local_index}_seed_{reference['seed']}"].copy()
        yield reference, actions


def measure(runner, manifest, request, heartbeat):
    tau = request["diagnostic"]["selected_tau"]
    runner.configure_exploration({"roles": [0, 1, 2], "taus": [tau] * 3})
    source = baseline_costs(manifest)
    rows = []
    for case in request["cases"]:
        measured = {"case_id": case["path"], "source_makespan": source[case["path"]],
                    "profile": case["profile"], "distribution": case["distribution"]}
        for decoder in ("native_hungarian", "autoregressive_greedy"):
            old_matching = runner.policy.ac.device_global_matching
            try:
                runner.policy.ac.device_global_matching = decoder == "native_hungarian"
                t = runner.rollout([case], [1], deterministic=True, likelihood_audit=True, heartbeat=heartbeat)[0]
                measured[decoder] = {**trajectory_record(t), **likelihood_record(t)}
                del t
            finally:
                runner.policy.ac.device_global_matching = old_matching
        sampled, decision_stats = [], []
        for replica in range(MECHANISM["fresh_replicas"]):
            seed = int(digest_json([2026091201, "mechanism-fresh", request["training_episodes"],
                                   case["content_sha256"], replica])[:15], 16) % (2**31 - 1)
            t = runner.rollout([case], [seed], heartbeat=heartbeat)[0]
            sampled.append(trajectory_record(t))
            decision_stats.append(runner.last_decision_stats)
        measured["sampling"] = {"replicas": len(sampled), "mean_cost": float(np.mean([t["makespan"] for t in sampled])),
            "best_of_4_cost": min(t["makespan"] for t in sampled), "trajectories": sampled, "decision_stats": decision_stats}
        fixed = []
        for reference, actions in fixed_references(manifest, case, tau):
            t = runner.rollout([case], [reference["seed"]], forced=[actions], likelihood_audit=True, heartbeat=heartbeat)[0]
            current = likelihood_record(t)
            if (trajectory_record(t)["action_sha256"] != reference["action_sha256"]
                    or abs(t["makespan"] - reference["makespan"]) > 1e-6):
                raise ValueError("Forced B0 reference changed environment trajectory")
            advantage = .01 * (source[case["path"]] - reference["makespan"])
            role_changes = {}
            for role, before in reference["likelihood"]["roles"].items():
                after = current["roles"][role]
                if before["decisions"] != after["decisions"]:
                    raise ValueError("Forced reference decision mask changed")
                delta = after["logp_sum"] - before["logp_sum"]
                role_changes[role] = {"delta_logp_sum": delta, "decisions": before["decisions"],
                    "delta_logp_per_decision": delta / max(1, before["decisions"])}
            fixed.append({"seed": reference["seed"], "makespan": reference["makespan"], "advantage": advantage,
                "advantage_sign": "positive" if advantage > 0 else "negative" if advantage < 0 else "zero",
                "roles": role_changes})
            del t
        measured["fixed_b0_likelihood"] = fixed
        rows.append(measured)
        heartbeat.update(event="mechanism_case_complete", completed_cases=len(rows), total_cases=len(request["cases"]))
    return {"kind": "mechanism", "cases": rows, "recipe": MECHANISM, "diagnostic_only": True,
            "used_for_gradient": False, "selected_tau": tau, "training_episodes": request["training_episodes"],
            "decoders": "deployment Hungarian versus AR greedy at tau.3; fresh sampling/forced likelihood at selected training tau"}


def summarize(results, initial_rows):
    rows = [r for value in results for r in value["cases"]]
    initial = {r["case_id"]: r for r in initial_rows}
    if len(rows) != MECHANISM["cases"] or set(initial) != {r["case_id"] for r in rows}:
        raise ValueError("Incomplete mechanism cohort")
    output = {"case_count": len(rows), "training_only": True,
        "source_cost": float(np.mean([r["source_makespan"] for r in rows])),
        "fresh_sampling_mean": float(np.mean([r["sampling"]["mean_cost"] for r in rows])),
        "fresh_best_of_4_mean": float(np.mean([r["sampling"]["best_of_4_cost"] for r in rows]))}
    for decoder in ("native_hungarian", "autoregressive_greedy"):
        output[decoder] = {"mean_cost": float(np.mean([r[decoder]["makespan"] for r in rows])),
            "changed_trajectory_fraction_by_role": {str(role): float(np.mean([
                r[decoder]["role_action_sha256"][str(role)] != initial[r["case_id"]][decoder]["role_action_sha256"][str(role)]
                for r in rows])) for role in range(3)}}
    output["action_change_scope"] = "whole role-action trajectory identity; not a same-state causal matching-flip rate"
    output["fixed_b0_likelihood"] = {}
    for sign in ("positive", "negative", "zero"):
        selected = [t for r in rows for t in r["fixed_b0_likelihood"] if t["advantage_sign"] == sign]
        output["fixed_b0_likelihood"][sign] = {"trajectories": len(selected), "roles": {}}
        for role in map(str, range(3)):
            count = sum(t["roles"][role]["decisions"] for t in selected)
            output["fixed_b0_likelihood"][sign]["roles"][role] = {
                "decisions": count, "delta_logp_per_decision": (
                    sum(t["roles"][role]["delta_logp_sum"] for t in selected) / count if count else None)}
    return output
