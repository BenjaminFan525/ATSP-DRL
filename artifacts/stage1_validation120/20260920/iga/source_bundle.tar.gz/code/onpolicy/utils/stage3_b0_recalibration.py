"""Explicit local B0 calibration. Historical release evidence is never rewritten."""
from pathlib import Path

from onpolicy.utils.stage3_b0_protocol import B0_SHA, EVALUATION, LOCAL_BASELINE, PLANNING, B0Queue
from onpolicy.utils.stage3_b0_acceleration import complete_rows
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json


def paired_cases(m):
    return m["diagnostic"]["cases32"] + m["splits"]["validation"] + m["splits"]["tune"]


def strict_pairs(native, private, cases):
    if not cases or len({c["path"] for c in cases}) != len(cases):
        raise ValueError("Strict pairing requires nonempty unique cases")
    complete_rows(native, cases)
    complete_rows(private, cases)
    if any(type(r.get("steps")) is not int or r["steps"] <= 0 for r in native + private):
        raise ValueError("Strict pairing requires complete positive integer step counts")
    reference = {r["case_id"]: r for r in native}
    differences = {}
    for row in private:
        other = reference[row["case_id"]]
        if (row["action_sha256"] != other["action_sha256"] or row["steps"] != other["steps"]
                or abs(row["makespan"] - other["makespan"]) > 1e-6):
            differences[row["case_id"]] = {
                "cost_delta": row["makespan"] - other["makespan"],
                "actions_exact": row["action_sha256"] == other["action_sha256"],
                "native_steps": other["steps"], "private_steps": row["steps"]}
    return {"passed": not differences, "paired_cases": len(cases),
            "criteria": LOCAL_BASELINE["pairing"], "differences": differences}


def evidence_identity(m, cases, checkpoint_sha, private):
    request = {"checkpoint_sha256": checkpoint_sha, "cases_sha256": digest_json(cases),
        "contract_sha256": digest_json(PLANNING), "code_sha256": m["code"]["sha256"],
        "tau": .3, "seed": 1, "evaluation_protocol": EVALUATION, "training_exploration": None,
        "representation": "F_PRIVATE" if private else "NATIVE", "protocol_sha256": m["manifest_sha256"],
        "source_sha256": B0_SHA, "comparison_sha256": m["comparison_sha256"],
        "kind": "native_cost", "diagnostic": None}
    if private:
        request["raw_initialization"] = True
    return {**{k: request[k] for k in ("checkpoint_sha256", "cases_sha256", "contract_sha256", "code_sha256")},
            "cache_key": B0Queue.identity(request)}


def audit_result(m, result, cases, expected):
    if (not result["ok"] or result["error"] is not None or result["training_episodes"] != 0
            or any(result[k] != v for k, v in expected.items())
            or result["evaluation"]["evaluation_protocol"] != EVALUATION
            or result["evaluation"]["source_sha256"] != B0_SHA):
        raise ValueError("Local baseline result provenance differs")
    return complete_rows(result["evaluation"]["cases"], cases)


def fresh_initialization(m):
    import torch
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.scripts.train.stage3_b0_worker import metadata
    native = B0Engine(m["source"]["manifest"], "NATIVE", device="cpu", create_environments=False)
    private = None
    try:
        private = B0Engine(m["source"]["manifest"], "F_PRIVATE", device="cpu", create_environments=False)
        expected = {}
        for key, value in native.policy.ac.state_dict().items():
            keys = ([f"encoder.encoders.{r}." + key[len("encoder."):] for r in range(3)]
                    if key.startswith("encoder.") else [key])
            expected.update({k: value for k in keys})
        actual = private.policy.ac.state_dict()
        if set(expected) != set(actual) or any(not torch.equal(v, actual[k]) for k, v in expected.items()):
            raise ValueError("Private model is not an exact expansion of released B0")
        if private.policy_updates or private.policy.actor_optimizer.state or private.policy.critic_optimizer.state:
            raise ValueError("Initialization contains optimizer history")
        path = Path(m["root"]) / "initialization/b0/rank0/private_init.pt"
        private.save(path, **metadata(m, diagnostic_only=False, initialization_only=True))
        atomic_json(path.parent / "initialization.json", {"checkpoint": str(path),
            "checkpoint_sha256": digest_file(path), "source_sha256": B0_SHA,
            "protocol_sha256": m["manifest_sha256"], "all_model_tensors_exact": True,
            "compared_tensors": len(expected), "zero_rl_updates": True,
            "fresh_from_frozen_b0": True, "trajectory_admission": "pending"}, overwrite=False)
        return path
    finally:
        native.close()
        if private is not None:
            private.close()


def seal_pairing(m, native, private, cases, name, evidence, **extra):
    report = strict_pairs(native, private, cases)
    report.update(source_sha256=B0_SHA, protocol_sha256=m["manifest_sha256"],
        comparison_sha256=m["comparison_sha256"], baseline_reference=LOCAL_BASELINE,
        evaluation=EVALUATION, native_cases=native, private_cases=private,
        evidence=evidence, initialization_sha256=digest_file(
            Path(m["root"]) / "initialization/b0/rank0/initialization.json"))
    report.update(extra)
    path = Path(m["root"]) / name
    atomic_json(path, report, overwrite=False)
    if not report["passed"]:
        raise RuntimeError(f"Strict local B0/private pairing failed: {report['differences']}")
    return path


def verify_pairing(m, path, cases):
    report = read_json(path)
    init_path = Path(m["root"]) / "initialization/b0/rank0/initialization.json"
    init = read_json(init_path)
    if (m.get("baseline_reference") != LOCAL_BASELINE or not report["passed"]
            or report["protocol_sha256"] != m["manifest_sha256"]
            or report["comparison_sha256"] != m["comparison_sha256"]
            or report["source_sha256"] != B0_SHA or report["evaluation"] != EVALUATION
            or report["baseline_reference"] != LOCAL_BASELINE
            or report["criteria"] != LOCAL_BASELINE["pairing"] or report["paired_cases"] != len(cases)
            or digest_file(init_path) != report["initialization_sha256"]
            or init["protocol_sha256"] != m["manifest_sha256"] or init["source_sha256"] != B0_SHA
            or not all(init[k] for k in ("all_model_tensors_exact", "zero_rl_updates", "fresh_from_frozen_b0"))
            or digest_file(init["checkpoint"]) != init["checkpoint_sha256"]
            or not report["evidence"]
            or any(digest_file(p) != h for p, h in report["evidence"].items())):
        raise ValueError("Local pairing provenance changed or is incomplete")
    if not strict_pairs(report["native_cases"], report["private_cases"], cases)["passed"]:
        raise ValueError("Local pairing no longer exact")
    return report


def diagnostic_costs(m):
    report = verify_pairing(m, Path(m["root"]) / "local_diagnostic_pairing.json", m["diagnostic"]["cases32"])
    return {r["case_id"]: r["makespan"] for r in report["native_cases"]}


def verify_local_baseline(m, record):
    path = Path(m["root"]) / "local_pairing_admission.json"
    if (record.get("baseline_reference") != LOCAL_BASELINE
            or record.get("local_pairing_sha256") != digest_file(path)):
        raise ValueError("Local baseline is missing its strict pairing admission")
    report = verify_pairing(m, path, paired_cases(m))
    cases = [c for s in ("train_full600", "validation", "tune") for c in m["splits"][s]]
    complete_rows(record["cases"], cases)
    if ({r["case_id"]: r["makespan"] for r in record["cases"]} != record["costs"]
            or report["baseline_cases_sha256"] != digest_json(record["cases"])
            or report["baseline_costs_sha256"] != record["costs_sha256"]):
        raise ValueError("Local paired baseline rows/costs changed")
    by_case = {r["case_id"]: r for r in record["cases"]}
    if any(by_case[r["case_id"]] != r for r in report["native_cases"]):
        raise ValueError("Local baseline differs from its paired native evidence")
    return report


def historical_report(m, costs):
    expected = m["diagnostic"]["initial_native_tune_costs"]
    rows = [{"case_id": c["path"], "case_sha256": c["case_sha256"],
        "historical_cost": expected[c["case_sha256"]], "local_cost": costs[c["path"]],
        "delta": costs[c["path"]] - expected[c["case_sha256"]]} for c in m["splits"]["tune"]]
    differences = [r for r in rows if abs(r["delta"]) > 1e-6]
    source = Path(m["source"]["manifest"]).parent / "results/b0_source_evaluation.json"
    return {"historical_costs_exact": not differences, "required_for_training_admission": False,
        "source_results_modified": False, "source_sha256": B0_SHA, "evaluation": EVALUATION,
        "baseline_reference": LOCAL_BASELINE, "historical_result": str(source),
        "historical_result_sha256": digest_file(source), "case_count": len(rows),
        "mismatch_count": len(differences), "historical_mean": sum(r["historical_cost"] for r in rows) / len(rows),
        "local_mean": sum(r["local_cost"] for r in rows) / len(rows), "cases": rows}
