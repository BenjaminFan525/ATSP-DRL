"""Bounded on-policy rollout batches with independent optimizer minibatches.

An active batch lease permits within-batch PPO reuse, never stale data from a
previous call and never policy-version or old-logp relabeling. Each minibatch
keeps the original PPO transaction; a full-batch epoch guard adds coverage.
"""
import numpy as np
import torch

from onpolicy.utils.stage3_distributed import state_digest
from onpolicy.utils.stage3_ppo_transaction import snapshot, restore, max_role_kl


def behavior_digest(rows):
    return state_digest([(t['policy_updates'], t['exploration'],
        [(s['old_logp'], s['action'], s['mask']) for s in t['states']]) for t in rows])


class RolloutBatchLease:
    def __init__(self, runner, rows, max_updates):
        if getattr(runner, '_active_rollout_batch', None) is not None:
            raise ValueError('Nested PPO rollout batches are forbidden')
        self.runner, self.rows = runner, rows
        self.version, self.max_updates = runner.policy_updates, max_updates
        self.ids = frozenset(map(id, rows))
        if (not rows or len(self.ids) != len(rows) or runner.exploration is None
                or any(t.get('policy_updates') != self.version
                    or t.get('exploration') != runner.exploration
                    or t.get('behavior_deterministic') or t.get('forced_replay')
                    or not t.get('completed') or not t.get('states') for t in rows)):
            raise ValueError('A fresh complete on-policy rollout batch is required; no stale relabeling')
        self.digest = behavior_digest(rows)
        self.active = False
        self.consumed = False

    def __enter__(self):
        if self.active or self.consumed:
            raise ValueError('Rollout lease already active or expired')
        self.active = True
        self.consumed = True
        self.runner._active_rollout_batch = self
        return self

    def version_for(self, runner, rows):
        if (not self.active or runner is not self.runner
                or getattr(runner, '_active_rollout_batch', None) is not self
                or not rows or not set(map(id, rows)) <= self.ids
                or not self.version <= runner.policy_updates <= self.version+self.max_updates
                or behavior_digest(self.rows) != self.digest):
            raise ValueError('Invalid/expired PPO rollout lease or modified behavior data')
        return self.version

    def __exit__(self, *_):
        self.active = False
        del self.runner._active_rollout_batch


def update_minibatches(runner, trajectories, mode, source_cost, *, epochs, chunk,
        microbatch_size, heartbeat, distributed, allow_multi_case, visit_balanced,
        imitation_weight, clip_mode, gradient_callback, diagnostic_role):
    if (mode != 'source' or imitation_weight or clip_mode != 'global'
            or gradient_callback is not None or diagnostic_role is not None
            or not visit_balanced or not allow_multi_case
            or type(microbatch_size) is not int or microbatch_size <= 0
            or type(epochs) is not int or epochs <= 0):
        raise ValueError('Optimizer minibatches require explicit pure visit-balanced source PPO')
    from onpolicy.runner.shared.stage3_research_engine import ResearchEngine
    controller = getattr(runner, 'ppo_step_controller', None)
    if controller is None:
        raise ValueError('Optimizer minibatches require PPO/KL transactions')
    groups = [trajectories[i:i+microbatch_size] for i in range(0, len(trajectories), microbatch_size)]
    lease = RolloutBatchLease(runner, trajectories, epochs*len(groups))
    metrics, epoch_reports, subreports = [], [], []
    stop = False
    sink = getattr(runner, 'update_metrics_sink', None)
    def emit(row):
        if sink is not None:
            sink(row)
    with lease:
        for epoch in range(epochs):
            before = snapshot(runner)
            first_metric = len(metrics)
            try:
                for index, group in enumerate(groups):
                    lease.version_for(runner, group)
                    if heartbeat:
                        heartbeat.update(event='optimizer_minibatch_start', ppo_epoch=epoch,
                            optimizer_minibatch=index+1, optimizer_minibatches=len(groups),
                            rollout_policy_updates=lease.version, actual_actor_updates=runner.policy_updates)
                    prior = runner.policy_updates
                    # Call the computation core, not B0Engine.update: its cache,
                    # zero-update counter and result accounting wrap this batch ONCE.
                    result = ResearchEngine.update(runner, group, mode, source_cost, epochs=1,
                        chunk=chunk, heartbeat=heartbeat, distributed=distributed,
                        allow_multi_case=True, visit_balanced=True, microbatch_size=microbatch_size)
                    if len(result['epochs']) != 1:
                        raise RuntimeError('One optimizer minibatch must contain exactly one PPO pass')
                    row = result['epochs'][0]
                    row.update(ppo_epoch=epoch, optimizer_minibatch=index+1,
                        optimizer_minibatches=len(groups), rollout_policy_updates=lease.version,
                        minibatch_trajectories=len(group))
                    if runner.policy_updates-prior != int(row['actor_step_applied']):
                        raise RuntimeError('Optimizer minibatch changed the actor update count incorrectly')
                    metrics.append(row)
                    subreports.append({'ppo_epoch': epoch, 'minibatch': index+1,
                        'case_ids': result['case_ids'], 'weights': result['case_trajectory_weights']})
                    emit({'event': 'optimizer_minibatch_completed', **{k: row[k] for k in
                        ('ppo_epoch', 'optimizer_minibatch', 'actor_step_applied', 'rollout_policy_updates')},
                        'actual_actor_updates': runner.policy_updates})
                    if not row['actor_step_applied'] or row.get('post_update', {}).get('kl', 0.) > controller.soft_kl:
                        stop = True
                        break
                replay_enabled = getattr(controller, 'replay_enabled', True)
                full = (runner.replay_metrics(trajectories, heartbeat, distributed=distributed)
                        if replay_enabled else {})
                maximum = max_role_kl(full) if replay_enabled else None
                rejected = replay_enabled and maximum > controller.hard_role_kl
                report = {'ppo_epoch': epoch, 'full_batch_post_update': full,
                    'kl_replay_enabled': replay_enabled,
                    'max_role_mean_kl': maximum, 'epoch_rolled_back': rejected,
                    'actor_updates_before': before['updates'], 'actor_updates_after': runner.policy_updates}
                if rejected:
                    restore(runner, before)
                    for row in metrics[first_metric:]:
                        row.update(actor_step_applied=False, epoch_rolled_back=True,
                                   stop_reason='whole_rollout_batch_hard_kl')
                    report['actor_updates_after'] = runner.policy_updates
                    stop = True
                epoch_reports.append(report)
                emit({'event': 'whole_rollout_batch_kl' if replay_enabled else 'whole_rollout_batch_kl_skipped',
                      **report})
                lease.version_for(runner, trajectories)
                if replay_enabled and full['kl'] > controller.soft_kl:
                    stop = True
            except BaseException as error:
                restore(runner, before)
                emit({'event': 'ppo_epoch_technical_rollback', 'ppo_epoch': epoch,
                      'restored_actor_updates': before['updates'], 'error': str(error)})
                raise
            if stop:
                break
    costs = np.asarray([t['makespan'] for t in trajectories])
    baselines = np.asarray([source_cost[t['case_id']] for t in trajectories]) if isinstance(source_cost, dict) else np.full(len(costs), source_cost)
    advantages = .01*(baselines-costs)
    from onpolicy.utils.stage3_local_exploration import training_mask
    return {'epochs': metrics, 'ppo_epoch_reports': epoch_reports, 'ppo_epochs_requested': epochs,
        'minibatch_objectives': subreports, 'costs': costs.tolist(), 'baseline_mode': mode,
        'case_ids': [t['case_id'] for t in trajectories], 'source_cost': source_cost,
        'trajectory_advantages': advantages.tolist(), 'positive_advantage_fraction': float(np.mean(advantages > 0)),
        'decisions': sum(float(training_mask(s['mask'], s['roles'], runner.exploration).sum())
                         for t in trajectories for s in t['states']),
        'rollout_policy_updates': lease.version, 'rollout_trajectories': len(trajectories),
        'backward_microbatch_size': microbatch_size, 'backward_microbatches': len(groups),
        'optimizer_step_per_microbatch': True, 'optimizer_step_after_microbatches': False,
        'behavior_data_unchanged': behavior_digest(trajectories) == lease.digest,
        'kl_replay_enabled': getattr(controller, 'replay_enabled', True),
        'stopped_early': stop,
        'peak_reserved_gib': torch.cuda.max_memory_reserved(runner.device)/2**30 if runner.device.type == 'cuda' else 0.}
