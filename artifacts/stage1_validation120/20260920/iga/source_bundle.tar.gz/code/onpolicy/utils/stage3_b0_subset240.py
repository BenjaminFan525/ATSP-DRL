"""Explicit 600 -> 240 data-only continuation at the first formal epoch.

The full corpus remains an immutable reference for B0 costs and diagnostics.
Only the selected cases may supply gradient-bearing trajectories after 960.
"""
from collections import Counter
from pathlib import Path

from onpolicy.utils.stage3_research import read_json, digest_file, digest_json

VERSION = 'b0-exact-subset240-remaining-seven-epochs-v1'
AUTHORIZATION = 'user-requested-exact-240-case-subset-checkpoint-restart-20260913'
SELECTION_PATH = 'onpolicy/config/stage3_b0_subset240_20260913.json'
SELECTION_SHA256 = '0cfb6d238c749a84e969ad64f4498c4f96908c135f787553de08eed4f2a9bbab'
COUNTS = {'iid': 192, 'ood_stress': 43, 'ood_scale': 5}
REPETITIONS = {'iid': 1, 'ood_stress': 4, 'ood_scale': 4}
START = 960
PER_EPOCH = 384
ENDPOINTS = [START + PER_EPOCH * n for n in range(8)]
FINAL = ENDPOINTS[-1]

# Only routing/schedule modules are overlaid. All numerical/model/environment
# implementation files must remain byte-identical to the admitted ENV60 parent.
OVERLAYS = (
    SELECTION_PATH, 'onpolicy/utils/stage3_b0_subset240.py',
    'onpolicy/utils/stage3_b0_protocol.py', 'onpolicy/utils/stage3_b0_throughput.py',
    'onpolicy/scripts/train/run_stage3_b0.py',
    'onpolicy/scripts/train/stage3_b0_large_batch.py',
    'onpolicy/scripts/train/stage3_b0_large_batch_worker.py',
    'onpolicy/scripts/train/stage3_b0_subset240.py',
    'onpolicy/scripts/train/queue_stage3_b0_subset240.py',
    'onpolicy/envs/HKBZ/test/test_stage3_b0_subset240.py',
    'STAGE3_B0_SUBSET240_20260913.md',
)
LINEAGE_KEYS = {'parent_manifest', 'parent_manifest_sha256', 'resume_commit',
    'resume_commit_sha256', 'start_episodes', 'start_actor_updates', 'parent_evidence',
    'schedule_sha256', 'snapshot_overlay_files', 'inherited_epoch_evidence'}


def selection():
    path = Path(__file__).resolve().parents[2] / SELECTION_PATH
    if digest_file(path) != SELECTION_SHA256:
        raise ValueError('The exact user selection file changed')
    return read_json(path)


def select_cases(full, chosen=None):
    chosen = selection() if chosen is None else chosen
    ids = chosen['case_ids']
    if (chosen['authorization'] != AUTHORIZATION or len(ids) != 240 or len(set(ids)) != 240
            or chosen['distribution_counts'] != COUNTS or chosen['visits_per_case'] != REPETITIONS
            or chosen['visits_per_epoch'] != PER_EPOCH or chosen['case_count'] != 240
            or chosen['source_dataset'] != 'fjsp_v3_t600_v120_test60/train'):
        raise ValueError('Invalid exact 240-case selection contract')
    by_name = {c['name']: c for c in full}
    if len(full) != len(by_name) or len(full) != 600 or not set(ids) <= by_name.keys():
        raise ValueError('Selected cases must all exist uniquely in the original 600-case corpus')
    cases = [by_name[name] for name in ids]
    if (Counter(c['distribution'] for c in cases) != COUNTS
            or len({c['path'] for c in cases}) != 240
            or len({c['content_sha256'] for c in cases}) != 240):
        raise ValueError('Selected case hashes/distribution counts differ')
    return cases


def data_contract(full):
    cases = select_cases(full)
    return {'version': VERSION, 'authorization': AUTHORIZATION,
        'selection_file_sha256': SELECTION_SHA256,
        'training_split': 'train_subset240', 'reference_split': 'train_full600',
        'case_count': 240, 'distribution_counts': COUNTS, 'visits_per_case': REPETITIONS,
        'cases_sha256': digest_json(cases), 'episodes_per_data_epoch': PER_EPOCH,
        'parent_completed_epochs': 1, 'start_episodes': START, 'remaining_epochs': 7,
        'total_data_epochs': 8, 'remaining_trajectories': 2688,
        'cumulative_epoch_endpoints': ENDPOINTS, 'final_training_episodes': FINAL,
        'order_and_seed_rule': 'filter unchanged original epoch2..8 schedule; retain visit IDs and seeds',
        'cross_epoch_batches': False, 'padding_or_extra_sampling': False,
        'actual_trajectories_per_rank': 48, 'actual_optimizer_minibatches_per_ppo_epoch': 4,
        'original_corpus_and_diagnostics_preserved': True}


def training_contract():
    from onpolicy.utils.stage3_b0_throughput import training_contract as original
    return {**original(480), 'episodes_per_data_epoch': PER_EPOCH,
        'max_training_episodes': FINAL, 'training_split': 'train_subset240',
        'unique_training_cases': 240}


def continuation_plan(m):
    from onpolicy.utils.stage3_full_data import schedule
    cases = select_cases(m['splits']['train_full600'])
    if (m['subset_training'] != data_contract(m['splits']['train_full600'])
            or m['splits'].get('train_subset240') != cases or m['training'] != training_contract()
            or m['throughput']['start_episodes'] != START):
        raise ValueError('Subset schedule/epoch budget differs from the approved selection')
    selected = {c['path'] for c in cases}
    rows = {epoch: [] for epoch in range(2, 9)}
    for batch in schedule(m['splits']['train_full600'], m['training']['seed']):
        if batch['data_epoch'] == 1:
            continue
        for case, seed, visit in zip(batch['cases'], batch['seeds'], batch['visit_ids']):
            if case['path'] in selected:
                rows[batch['data_epoch']].append((case, seed, visit))
    result = []
    for epoch, visits in rows.items():
        counts = Counter(row[0]['path'] for row in visits)
        if len(visits) != PER_EPOCH or any(counts[c['path']] != REPETITIONS[c['distribution']] for c in cases):
            raise ValueError('An epoch lost/duplicated selected visits')
        result.append({'cases': [row[0] for row in visits], 'seeds': [row[1] for row in visits],
            'visit_ids': [row[2] for row in visits], 'data_epoch': epoch, 'visit': epoch-1,
            'group': len(result)+1, 'training_episodes': ENDPOINTS[epoch-1],
            'batch_size': PER_EPOCH, 'epoch_tail': True})
    return result


def parent_manifest(m, *, evidence=True):
    from onpolicy.utils.stage3_b0_protocol import identity
    from onpolicy.utils.stage3_b0_throughput import (ENV60_BATCH_VERSION,
        parent_manifest as original_parent, continuation_plan as original_plan)
    t = m['throughput']
    path = Path(t['parent_manifest'])
    if digest_file(path) != t['parent_manifest_sha256']:
        raise ValueError('Subset parent manifest changed')
    parent = read_json(path)
    if (parent.get('subset_training') or parent.get('throughput', {}).get('version') != ENV60_BATCH_VERSION
            or identity(parent) != parent['manifest_sha256'] or parent['training']['global_batch'] != 480):
        raise ValueError('Subset requires the original admitted ENV60 parent')
    original_parent(parent, evidence=evidence)
    if m['training'] != training_contract() or m['subset_training'] != data_contract(parent['splits']['train_full600']):
        raise ValueError('Subset training contract changed')
    if ({k:v for k,v in t.items() if k not in LINEAGE_KEYS}
            != {k:v for k,v in parent['throughput'].items() if k not in LINEAGE_KEYS}):
        raise ValueError('Subset must preserve all ENV60 execution and optimizer settings')
    expected_splits = {**parent['splits'], 'train_subset240': select_cases(parent['splits']['train_full600'])}
    if m['splits'] != expected_splits:
        raise ValueError('Subset changed the reference corpus or evaluation splits')
    for key in ('contract', 'contract_sha256', 'history', 'evaluation', 'numerics',
                'baseline_reference', 'diagnostic', 'arms'):
        if parent.get(key) != m.get(key):
            raise ValueError(f'Subset changed {key}')
    if (m['source']['sha256'] != parent['source']['sha256']
            or {k:v for k,v in m['resources'].items() if k != 'validator_queue'}
                != {k:v for k,v in parent['resources'].items() if k != 'validator_queue'}):
        raise ValueError('Subset changed B0 or resource settings')
    if t['snapshot_overlay_files'] != list(OVERLAYS):
        raise ValueError('Unregistered subset source overlay')
    for name, checksum in parent['code']['files'].items():
        if name not in OVERLAYS and m['code']['files'].get(name) != checksum:
            raise ValueError(f'Subset changed numerical/capacity implementation: {name}')
    if set(m['code']['files']) != set(parent['code']['files']) | set(OVERLAYS):
        raise ValueError('Unexpected source added/removed by subset continuation')
    if digest_file(t['resume_commit']) != t['resume_commit_sha256']:
        raise ValueError('Subset resume commit changed')
    commit = read_json(t['resume_commit'])
    if (commit.get('diagnostic_only') or commit['world_size'] != 8 or len(commit['ranks']) != 8
            or commit['protocol_sha256'] != parent['manifest_sha256']
            or commit['training_episodes'] != START or t['start_episodes'] != START
            or commit['actual_actor_updates'] != t['start_actor_updates']
            or commit['schedule_sha256'] != digest_json(original_plan(parent))
            or commit['recipe_sha256'] != t['parent_evidence'][str(path.parent/'training_admission.json')]):
        raise ValueError('Subset requires the exact admitted formal 960 checkpoint')
    if digest_json(continuation_plan(m)) != t['schedule_sha256']:
        raise ValueError('Selected visits/seeds changed')
    if evidence:
        for name, checksum in {**t['parent_evidence'], **t['probe_reports'],
                               **t['inherited_epoch_evidence']}.items():
            if digest_file(name) != checksum:
                raise ValueError(f'Subset evidence changed: {name}')
        for rank, row in enumerate(commit['ranks']):
            expected = path.parent/f'train/full/rank{rank}/models/episodes_{START:06d}.pt'
            if (row['rank'] != rank or Path(row['checkpoint']).resolve() != expected.resolve()
                    or digest_file(expected) != row['sha256']):
                raise ValueError('Subset parent rank checkpoint changed')
        if not read_json(path.parent/'training_admission.json')['passed']:
            raise ValueError('ENV60 capacity admission failed')
    return parent


def capacity_reuse(m):
    """Reuse a passed full 60/rank diagnostic, NOT its diagnostic weights."""
    parent = parent_manifest(m)
    path = Path(parent['root'])/'training_admission.json'
    report = read_json(path)
    evidence = {str(path): digest_file(path), **report['evidence']}
    if (not report['passed'] or report['protocol_sha256'] != parent['manifest_sha256']
            or report['world_size'] != 8 or report['global_batch'] != 480
            or report['rollout_envs_per_rank'] != 60 or report['backward_microbatch'] != 12
            or report['optimizer_minibatches'] != 5 or not report['optimizer_step_per_microbatch']
            or not report['full_trajectories_and_two_epoch_ppo']
            or not report['diagnostic_weights_discarded'] or not report['batched_sampling_verified']
            or len(report['evidence']) != 8
            or any(digest_file(p) != h for p,h in evidence.items())):
        raise ValueError('Full eight-GPU ENV60 capacity evidence cannot be reused')
    for name in report['evidence']:
        row = read_json(name)
        if (not row['passed'] or row['update']['accepted_actor_steps'] != 10
                or row['update']['backward_microbatch_size'] != 12
                or row['update']['rollout_trajectories'] != 60
                or any(e['epoch_rolled_back'] for e in row['update']['ppo_epoch_reports'])):
            raise ValueError('Parent all-rank PPO/KL capacity check did not pass')
    return {'passed': True, 'protocol_sha256': m['manifest_sha256'], 'world_size': 8,
        'global_batch': 480, 'parent_commit_sha256': m['throughput']['resume_commit_sha256'],
        'sampling_sha256': digest_file(Path(m['root'])/'sampling_admission.json'),
        'evidence': evidence, 'admission_kind': 'inherited_full_env60_capacity_data_only_change',
        'new_gpu_capacity_test_performed': False, 'measured_parent_trajectories_per_rank': 60,
        'formal_subset_trajectories_per_rank': 48, 'backward_microbatch': 12,
        'numerical_implementation_unchanged': True, 'diagnostic_weights_discarded': True,
        'model_optimizer_normalizer_rng_resume_source': m['throughput']['resume_commit'],
        'full_trajectories_and_two_epoch_ppo': True}
