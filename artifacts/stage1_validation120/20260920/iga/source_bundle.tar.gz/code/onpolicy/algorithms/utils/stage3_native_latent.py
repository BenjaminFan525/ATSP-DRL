"""Explicit latent-action policy and instance-local native score intervention.

The executor and feature map are frozen. Only q_theta(z|s) is learned. PPO uses
the sampled Gaussian latent density, never a Hungarian pseudo-likelihood.
"""
import ast
from copy import deepcopy
import inspect
import textwrap
import types

import torch
from torch import nn
from torch_geometric.data import Batch

from onpolicy.algorithms.gnn_mappo.algorithm.gnn_actor_critic import _ModuleGroup
from onpolicy.utils.stage3_rl_bridge import LATENT


def gaussian_log_prob(value, mean, sigma):
    return torch.distributions.Normal(mean, sigma).log_prob(value).sum(-1)


def gaussian_kl(old_mean, mean, sigma):
    return ((old_mean-mean).square()/(2*sigma*sigma)).sum(-1)


class NativeLatentActor(nn.Module):
    def __init__(self, executor, config=None):
        super().__init__()
        self.config = dict(LATENT if config is None else config)
        self.encoder = deepcopy(executor.encoder)
        self.encoder.requires_grad_(True)
        reference = next(executor.parameters())
        dim = 64
        self.recurrent = nn.ModuleList([nn.GRUCell(dim, dim) for _ in range(3)])
        self.mean_heads = nn.ModuleList([nn.Linear(dim, self.config['dimension_per_role']) for _ in range(3)])
        self.critics = nn.ModuleList([nn.Sequential(nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, 1)) for _ in range(3)])
        self.to(reference.device, reference.dtype)
        for head in self.mean_heads:
            nn.init.zeros_(head.weight)
            nn.init.zeros_(head.bias)
        self.executor = executor
        self.executor.requires_grad_(False)
        self.critic_param = _ModuleGroup([self.critics])
        self.tau = .3

    def forward(self, graphs, hidden):
        graph = Batch.from_data_list(graphs).to(next(self.parameters()).device)
        encoded = self.encoder(graph)['role_encodings']
        states = torch.stack([self.recurrent[r](encoded[str(r)]['global_emb'], hidden[:, r]) for r in range(3)], 1)
        means = torch.stack([self.config['mean_bound'] * torch.tanh(self.mean_heads[r](states[:, r]))
                             for r in range(3)], 1)
        values = torch.stack([self.critics[r](states[:, r].detach()).squeeze(-1) for r in range(3)], 1)
        return means, values, states


def _fixed_dimensions(values, dim=8):
    values = torch.nan_to_num(values, nan=0., posinf=10., neginf=-10.)
    if values.shape[-1] >= dim:
        return torch.tanh(torch.nan_to_num(values[..., :dim], nan=0., posinf=10., neginf=-10.))
    return torch.nn.functional.pad(torch.tanh(values), (0, dim-values.shape[-1]))


class NativeScoreIntervention:
    """Patch only this executor instance, with explicit graph/agent identities."""
    def __init__(self, ac):
        self.ac, self.coefficients, self.request_physical = ac, None, None
        self.original_forward = ac.forward
        original = ac.forward
        tree = ast.parse(textwrap.dedent(inspect.getsource(original)))
        counts = {'resource': 0, 'plane': 0}

        class Hook(ast.NodeTransformer):
            def visit_Call(self, node):
                self.generic_visit(node)
                resource = isinstance(node.func, ast.Name) and node.func.id == 'actor_head'
                plane = (isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
                         and node.func.value.id == 'self' and node.func.attr == 'actor')
                if resource or plane:
                    key = 'resource' if resource else 'plane'
                    counts[key] += 1
                    expression = ('role_batch_indices' if resource else
                                  'torch.nonzero(active_mask_i, as_tuple=False).flatten()')
                    node.keywords.extend([
                        ast.keyword(arg='stage3_batch_indices', value=ast.parse(expression, mode='eval').body),
                        ast.keyword(arg='stage3_agent_index', value=ast.Name(id='agent_idx', ctx=ast.Load()))])
                return node
        tree = Hook().visit(tree)
        if counts != {'resource': 2, 'plane': 2}:
            raise ValueError(f'Native identity hook call sites changed: {counts}')
        ast.fix_missing_locations(tree)
        namespace = dict(original.__func__.__globals__)
        exec(compile(tree, '<stage3_native_latent_identity>', 'exec'), namespace)
        ac.forward = types.MethodType(namespace[original.__name__], ac)
        self.original_heads = []
        for role, head in enumerate((ac.actor, ac.device_actor, ac.transporter_actor)):
            before = head.forward
            self.original_heads.append((head, before))
            def routed(this, *args, _before=before, _role=role, **kwargs):
                indices = kwargs.pop('stage3_batch_indices')
                agent = kwargs.pop('stage3_agent_index')
                output = _before(*args, **kwargs)
                if self.coefficients is None:
                    raise RuntimeError('Native coefficient context missing')
                z = self.coefficients[indices, _role]
                # Exact B0 preservation, including its original normalization and ties.
                if not bool(torch.count_nonzero(z)):
                    return output
                if not kwargs.get('deterministic') or any(kwargs.get(k) is not None for k in
                        ('chosen_request', 'chosen_op', 'chosen_site', 'sampling_uniform')):
                    raise ValueError('Native latent execution requires deterministic unforced native decoding')
                if _role == 0:
                    op, site, _, logp = output
                    b, choices = logp.shape
                    phi = logp.new_zeros((b, choices, LATENT['dimension_per_role']))
                    sparse = kwargs.get('pair_feature_values')
                    if sparse is not None:
                        phi[kwargs['pair_feature_batch_indices'].long(), kwargs['pair_feature_flat_ids'].long()] = _fixed_dimensions(sparse)
                    elif kwargs.get('pair_features') is not None:
                        phi = _fixed_dimensions(kwargs['pair_features'].reshape(b, choices, -1))
                    else:
                        raise ValueError('Native plane intervention requires observable pair features')
                    valid = kwargs['op_valid_mask'].unsqueeze(-1) & kwargs['site_valid_mask']
                    valid = valid.reshape_as(logp)
                    adjusted = (logp + (phi*z[:, None]).sum(-1)).masked_fill(~valid, -torch.inf)
                    adjusted = torch.log_softmax(adjusted, -1)
                    chosen = adjusted.argmax(-1)
                    nsites = kwargs['site_nodes'].shape[1]
                    return chosen//nsites, chosen%nsites, adjusted.gather(1, chosen[:, None]).squeeze(1), adjusted
                _, _, logp = output
                physical = self.request_physical[indices]
                phi = logp.new_zeros((*logp.shape, LATENT['dimension_per_role']))
                scales = physical.new_tensor(LATENT['request_feature_scales'])
                phi[..., :5] = _fixed_dimensions(physical[..., 1:6] / scales, 5)
                # Frozen query/request compatibility permits device-specific preferences.
                nodes = kwargs['request_nodes']
                query = kwargs['query'].squeeze(1)
                phi[..., 5:7] = torch.tanh(nodes[..., :2] * torch.tanh(query[:, None, :2]))
                phi[:, 0, :] = 0
                phi[:, 0, 7] = 1  # Explicit WAIT marginal, not a fabricated candidate.
                adjusted = (logp+(phi*z[:, None]).sum(-1)).masked_fill(~kwargs['request_valid_mask'], -torch.inf)
                adjusted = torch.log_softmax(adjusted, -1)
                chosen = adjusted.argmax(-1)
                return chosen, adjusted.gather(1, chosen[:, None]).squeeze(1), adjusted
            head.forward = types.MethodType(routed, head)
        self.report = counts

    def set_context(self, coefficients, graphs):
        self.coefficients = coefficients
        self.request_physical = torch.stack([g['request'].x for g in graphs]).to(coefficients.device)

    def close(self):
        self.ac.forward = self.original_forward
        for head, forward in self.original_heads:
            head.forward = forward
        self.coefficients = self.request_physical = None
