#!/usr/bin/env python3
"""User-invoked preflight stop: archive unclaimed requests and drain claimed work.

Never signals a GPU worker, deletes results, or touches another experiment.
Run again with --status to observe the request-boundary drain.
"""
import argparse
import fcntl
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file


def status(root, unit):
    counts = {name: len(list((root / "validator" / name).glob("*.json")))
              for name in ("pending", "running", "results", "failed", "paused_pending")}
    services = subprocess.check_output(["systemctl", "--user", "show", unit + "-training.service",
        unit + "-validator.service", "-p", "Id", "-p", "ActiveState", "-p", "SubState", "-p", "MainPID"], text=True)
    print({"run": str(root), "queue": counts, "services": services}, flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run", required=True)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--status", action="store_true")
    args = p.parse_args()
    if not re.fullmatch(r"stage3_private_b0_[a-zA-Z0-9_]+", args.run):
        raise ValueError("Only an exact Stage3 B0 run identifier is accepted")
    root = ROOT / "result/hkbz_train_logs" / args.run
    if root.resolve() != root or read_json(root / "manifest.json")["root"] != str(root):
        raise ValueError("Run root identity mismatch")
    unit = "hkbz-" + args.run.replace("_", "-")
    if args.status:
        status(root, unit)
        return
    state = read_json(root / "status.json")
    if state.get("formal_training_started") or state["phase"] != "native_b0_baselines":
        raise ValueError("This explicit migration only accepts the initial native baseline phase")
    for suffix in ("training", "validator"):
        command = subprocess.check_output(["systemctl", "--user", "show", f"{unit}-{suffix}.service",
                                          "-p", "ExecStart", "--value"], text=True)
        if str(root / "source/onpolicy/scripts/train/run_stage3_b0.py") not in command:
            raise ValueError("Service command does not belong to this run")
    # This controller owns only already-finished initialization workers in this phase.
    subprocess.run(["systemctl", "--user", "stop", unit + "-training.service"], check=True)
    if subprocess.check_output(["systemctl", "--user", "show", unit + "-training.service",
                                "-p", "MainPID", "--value"], text=True).strip() != "0":
        raise RuntimeError("Training controller did not stop")
    q = root / "validator"
    archive = q / "paused_pending"
    if archive.exists() or (q / "STOP").exists():
        raise FileExistsError("A stop was already recorded; use --status, do not overwrite it")
    archived = []
    with (q / "claim.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        archive.mkdir()
        for path in sorted((q / "pending").glob("*.json")):
            checksum = digest_file(path)
            target = archive / path.name
            if target.exists():
                raise FileExistsError(target)
            os.rename(path, target)
            archived.append({"path": str(target), "sha256": checksum})
        atomic_json(q / "STOP", {"reason": "user-authorized execution-only acceleration restart",
                    "created_unix": time.time(), "drain_claimed_requests": True}, overwrite=False)
        atomic_json(root / "quiesce_receipt.json", {"pending_requests_archived": archived,
            "claimed_requests": [str(p) for p in sorted((q / "running").glob("*.json"))],
            "old_results_preserved": True, "no_worker_signals_sent": True,
            "created_unix": time.time()}, overwrite=False)
    status(root, unit)


if __name__ == "__main__":
    main()
