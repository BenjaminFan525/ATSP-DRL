#!/usr/bin/env python3
"""Isolated hardware probes; prefix fixtures are never training/admission data."""
import argparse
import json
import os
from pathlib import Path
import resource
import sys
import time

ROOT = Path(os.environ.get('HKBZ_STAGE3_PROBE_CODE_ROOT', Path(__file__).resolve().parents[3]))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch

from onpolicy.runner.shared.stage3_b0_engine import B0Engine
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat, trajectory_record
from onpolicy.scripts.train.stage3_b0_worker import attach_journal
from onpolicy.scripts.train.stage3_local_worker import frozen_state, assert_frozen
from onpolicy.utils.stage3_distributed import state_digest
from onpolicy.utils.stage3_numerics import training_state
from onpolicy.utils.stage3_research import atomic_json, digest_file, digest_json, read_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--commit', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--width', type=int, choices=(4, 8, 12), required=True)
    p.add_argument('--steps', type=int, default=64)
    args = p.parse_args()
    if args.output.exists() or args.steps < 16 or args.steps % 8:
        raise ValueError('Use a new probe output and whole TBPTT chunks')
    m, commit = read_json(args.parent), read_json(args.commit)
    if commit['protocol_sha256'] != m['manifest_sha256'] or commit['world_size'] != 8:
        raise ValueError('Probe requires the exact eight-rank source commit')
    entry = commit['ranks'][0]
    if digest_file(entry['checkpoint']) != entry['sha256']:
        raise ValueError('Source checkpoint changed')
    baseline = read_json(Path(m['root']) / 'baselines.json')
    by_path = {c['path']: c for c in m['splits']['train_full600']}
    dense = max((r for r in baseline['cases'] if r['case_id'] in by_path),
                key=lambda r: r['max_graph_tensor_bytes'])['case_id']
    cases = [by_path[dense]] * args.width
    seeds = [int(digest_json(['b0-batch-probe', dense, i])[:15], 16) % (2**31-1)
             for i in range(args.width)]
    args.output.mkdir(parents=True)
    with ProgressHeartbeat(args.output / 'status.json', phase='isolated_prefix_capacity') as hb:
        runner = B0Engine(m['source']['manifest'], width=args.width,
                          tau=read_json(Path(m['root']) / 'sampling_admission.json')['selected_tau'])
        try:
            original_call = runner.pool.call
            def fixture(commands):
                rows = original_call(commands)
                for i, command, _ in commands:
                    if command == 'summary':
                        rows[i] = {**rows[i], 'completed': True, 'synthetic_prefix_fixture': True}
                return rows
            runner.pool.call = fixture
            payload = runner.resume(entry['checkpoint'], protocol_sha256=m['manifest_sha256'],
                                    exploration=runner.exploration)
            resumed = state_digest(training_state(runner))
            frozen = frozen_state(runner)
            attach_journal(runner, args.output / 'ppo_attempts.jsonl')
            torch.cuda.reset_peak_memory_stats()
            begin = time.time()
            group = runner.rollout(cases, seeds, max_steps=args.steps, retain=True, heartbeat=hb)
            rollout_seconds = time.time() - begin
            if not all(t.get('synthetic_prefix_fixture') for t in group):
                raise RuntimeError('Probe fixture must remain explicitly synthetic')
            replay = runner.replay_metrics(group, heartbeat=hb)
            if replay['max_logp_error'] > .002:
                raise RuntimeError('Large-batch likelihood replay mismatch')
            begin = time.time()
            update = runner.update(group, 'source', baseline['costs'], heartbeat=hb, epochs=2, chunk=8)
            update_seconds = time.time() - begin
            assert_frozen(runner, frozen)
            result = {
                'passed': True, 'diagnostic_only': True, 'synthetic_prefix_fixture': True,
                'full_trajectory_admission': False, 'forbidden_as_rl_initialization': True,
                'source_commit': str(args.commit.resolve()), 'source_commit_sha256': digest_file(args.commit),
                'source_checkpoint_sha256': entry['sha256'], 'resumed_state_sha256': resumed,
                'probe_script_sha256': digest_file(__file__), 'parent_code_sha256': m['code']['sha256'],
                'source_actor_updates': payload['policy_updates'], 'width': args.width,
                'backward_trajectories': args.width, 'tbptt_steps': 8, 'prefix_steps': args.steps,
                'dense_case': dense, 'rollout_seconds': rollout_seconds, 'update_seconds': update_seconds,
                'batch_seconds': rollout_seconds + update_seconds,
                'trajectory_steps_per_second': args.width * args.steps / (rollout_seconds + update_seconds),
                'peak_reserved_gib': torch.cuda.max_memory_reserved() / 2**30,
                'peak_allocated_gib': torch.cuda.max_memory_allocated() / 2**30,
                'self_max_rss_gib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20,
                'replay': replay, 'update': update,
                'records': [trajectory_record(t) for t in group], 'finished_unix': time.time(),
            }
            atomic_json(args.output / 'result.json', result, overwrite=False)
            print(json.dumps({k: v for k, v in result.items() if not isinstance(v, (dict, list))}), flush=True)
        except BaseException:
            import traceback
            atomic_json(args.output / 'failure.json', {'error': traceback.format_exc(),
                'diagnostic_only': True, 'no_automatic_retry': True}, overwrite=False)
            raise
        finally:
            runner.close()


if __name__ == '__main__':
    main()
