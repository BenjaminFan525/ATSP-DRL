#!/usr/bin/env python3
"""Hand completed DeviceBC lanes to the corrected 30x50 Stage2 PPO run.

The original selected-three suite was launched with 20 rollout environments
but a recurrent PPO mini-batch width of 30.  DeviceBC itself is valid, because
it does not use the recurrent replay generator.  This controller waits for
each atomically written DeviceBC checkpoint, validates the Stage2 boundary,
stops only that old lane, and starts a PPO-only continuation with 30 rollout
environments and the proven 1500-graph forward geometry.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import torch


ROOT = Path(__file__).resolve().parents[3]
DEFAULT_PYTHON = (ROOT.parent / "conda/envs/maia-hkbz-cu124-20260903/bin/python3.11").resolve()
TRIAL_RUNNER = ROOT / "onpolicy/scripts/train/run_stage2_resource_manifest_trial.py"
RESULT_ROOT = ROOT / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo"

METHODS = (
    "F1_hard_reservation",
    "F2_iga_flow_bc",
    "F3_wait_constraint",
)
TRAIN_CPUS = (
    "0-9,72-81",
    "10-19,82-91",
    "20-29,92-101",
)
PPO_ROLLOUT_THREADS = 30
PPO_MINI_BATCH_SIZE = 30
PPO_DATA_CHUNK_LENGTH = 50
PPO_MAX_GRAPHS = 1500
PPO_CRITIC_ACCUMULATION_STEPS = 3
PPO_ACTOR_ACCUMULATION_STEPS = 2
PPO_CRITIC_ACCUMULATION_TARGET_GRAPHS = 5000
PPO_ACTOR_ACCUMULATION_TARGET_GRAPHS = 2000


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def command_option(command: list[str], option: str) -> str | None:
    if option not in command:
        return None
    return command[command.index(option) + 1]


def command_switch(command: list[str], option: str) -> bool:
    return option in command


def lookahead_contract_from_command(command: list[str]) -> dict:
    """Decode the exact resource-planning contract used by train_hkbz."""

    def value(option: str, default: str) -> str:
        configured = command_option(command, option)
        return default if configured is None else configured

    return {
        "device_lookahead_dispatch": command_switch(
            command, "--device_lookahead_dispatch"
        ),
        "device_lookahead_safety_margin": float(value(
            "--device_lookahead_safety_margin", "60.0"
        )),
        "device_deadline_aware_dispatch": command_switch(
            command, "--device_deadline_aware_dispatch"
        ),
        "device_future_intent_horizon": int(value(
            "--device_future_intent_horizon", "0"
        )),
        "device_future_intent_mode": value(
            "--device_future_intent_mode", "legacy_one"
        ),
        "device_frontier_max_requests": int(value(
            "--device_frontier_max_requests", "2"
        )),
        "resource_release_aware_eta": command_switch(
            command, "--resource_release_aware_eta"
        ),
        "device_lookahead_reservation_mode": value(
            "--device_lookahead_reservation_mode", "none"
        ),
        "device_reservation_grace_seconds": float(value(
            "--device_reservation_grace_seconds", "300.0"
        )),
        "device_departure_lookahead": command_switch(
            command, "--device_departure_lookahead"
        ),
    }


def systemctl_state(unit: str) -> str:
    result = subprocess.run(
        ["systemctl", "--user", "is-active", f"{unit}.service"],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )
    return result.stdout.strip() or "inactive"


def run_status(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def validate_checkpoint(
    checkpoint: Path,
    *,
    expected_teacher: str,
    expected_source_sha256: str,
    expected_lookahead_contract: dict | None = None,
) -> dict:
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    failures = []
    if payload.get("training_stage") != "resource_joint":
        failures.append("training_stage is not resource_joint")
    if payload.get("stage") != "resource_bc_warmup":
        failures.append("stage is not resource_bc_warmup")
    if payload.get("phase") != "resource_bc_warmup_completed":
        failures.append("resource BC phase is incomplete")
    if not bool(payload.get("resource_bc_optimizer_reset")):
        failures.append("PPO optimizers were not reset at the BC boundary")
    if int(payload.get("resource_bc_total_labels", 0)) <= 0:
        failures.append("resource_bc_total_labels is not positive")
    if not payload.get("resource_actor_summary_after_bc"):
        failures.append("resource actor post-BC summary is missing")
    if not payload.get("protected_parameter_summary_after_bc"):
        failures.append("protected Stage1 summary is missing")
    if str(payload.get("device_bc_teacher")) != expected_teacher:
        failures.append(
            "DeviceBC teacher mismatch: "
            f"{payload.get('device_bc_teacher')!r} != {expected_teacher!r}"
        )
    if str(payload.get("source_m2_sha256")) != expected_source_sha256:
        failures.append("Stage1 M2 source digest mismatch")
    if (
        expected_lookahead_contract is not None
        and payload.get("resource_lookahead_contract")
        != expected_lookahead_contract
    ):
        failures.append(
            "resource lookahead contract mismatch: "
            f"checkpoint={payload.get('resource_lookahead_contract')!r} "
            f"configured={expected_lookahead_contract!r}"
        )
    if failures:
        raise RuntimeError(
            f"Invalid DeviceBC checkpoint {checkpoint}: " + "; ".join(failures)
        )
    evidence = {
        "path": str(checkpoint.resolve()),
        "sha256": sha256_file(checkpoint),
        "size_bytes": checkpoint.stat().st_size,
        "resource_bc_total_labels": int(payload["resource_bc_total_labels"]),
        "teacher": str(payload["device_bc_teacher"]),
        "phase": str(payload["phase"]),
        "resource_lookahead_contract": payload.get(
            "resource_lookahead_contract"
        ),
        "validated_at": utc_now(),
    }
    del payload
    return evidence


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run-tag", default="stage2_full_formal_three_20260823_r2"
    )
    parser.add_argument("--suite-dir", type=Path)
    parser.add_argument(
        "--unit-prefix", default="hkbz-s2-full3-20260823-r2"
    )
    parser.add_argument("--python", type=Path, default=DEFAULT_PYTHON)
    parser.add_argument("--poll-seconds", type=float, default=5.0)
    parser.add_argument("--monitor-seconds", type=float, default=30.0)
    parser.add_argument("--wait-timeout-seconds", type=float, default=604800.0)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def lane_paths(args: argparse.Namespace, lane: int, method: str) -> dict:
    suite_dir = args.suite_dir
    original_name = (
        f"{args.run_tag}_planning_formal_full_selected_three_{method}_seed1"
    )
    continuation_name = f"{original_name}_ppo30"
    return {
        "original_name": original_name,
        "continuation_name": continuation_name,
        "checkpoint": (
            RESULT_ROOT
            / original_name
            / "run1/models/checkpoint_DeviceBC.pt"
        ),
        "continuation_status": (
            RESULT_ROOT / continuation_name / "run1/run_status.json"
        ),
        "old_unit": f"{args.unit_prefix}-g0l{lane}",
        "new_unit": f"{args.unit_prefix}-g0l{lane}-ppo30",
        "log": (
            suite_dir
            / "service_logs"
            / f"{args.unit_prefix}-g0l{lane}-ppo30.log"
        ),
        "record": (
            suite_dir
            / "records"
            / f"full_formal_three_g0l{lane}_ppo30.json"
        ),
    }


def continuation_command(
    args: argparse.Namespace,
    lane: int,
    method: str,
    paths: dict,
) -> list[str]:
    evaluator_socket = f"/tmp/{args.unit_prefix}-g0eval.sock"
    evaluator_cpus = "30-34,102-106"
    command = [
        str(args.python.resolve()),
        "-u",
        str(TRIAL_RUNNER.resolve()),
        "--manifest",
        str((args.suite_dir / "commands/full_formal_three.json").resolve()),
        "--command-key",
        method,
        "--gpu",
        "0",
        "--cpu-set",
        TRAIN_CPUS[lane],
        "--shared-eval-socket",
        evaluator_socket,
        "--shared-eval-cpu-set",
        evaluator_cpus,
        "--eval-workers",
        "10",
        "--start-delay-seconds",
        str(lane * 15),
        "--record",
        str(paths["record"].resolve()),
        "--experiment-name",
        paths["continuation_name"],
        "--resource-bc-checkpoint",
        str(paths["checkpoint"].resolve()),
        "--n-rollout-threads",
        str(PPO_ROLLOUT_THREADS),
        "--mini-batch-size",
        str(PPO_MINI_BATCH_SIZE),
        "--data-chunk-length",
        str(PPO_DATA_CHUNK_LENGTH),
        "--max-graphs-per-forward",
        str(PPO_MAX_GRAPHS),
        "--grad-accumulation-steps",
        str(PPO_CRITIC_ACCUMULATION_STEPS),
        "--actor-grad-accumulation-steps",
        str(PPO_ACTOR_ACCUMULATION_STEPS),
        "--grad-accumulation-target-graphs",
        str(PPO_CRITIC_ACCUMULATION_TARGET_GRAPHS),
        "--actor-grad-accumulation-target-graphs",
        str(PPO_ACTOR_ACCUMULATION_TARGET_GRAPHS),
    ]
    return command


def launch_continuation(
    args: argparse.Namespace,
    lane: int,
    method: str,
    paths: dict,
) -> list[str]:
    command = continuation_command(args, lane, method, paths)
    paths["log"].parent.mkdir(parents=True, exist_ok=True)
    paths["record"].parent.mkdir(parents=True, exist_ok=True)
    systemd_command = [
        "systemd-run",
        "--user",
        f"--unit={paths['new_unit']}",
        "--same-dir",
        "--setenv=CUDA_VISIBLE_DEVICES=0",
        "--setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID",
        "--setenv=PYTHONHASHSEED=0",
        "--setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True",
        "--setenv=OMP_NUM_THREADS=1",
        "--setenv=MKL_NUM_THREADS=1",
        "--setenv=OPENBLAS_NUM_THREADS=1",
        "--setenv=NUMEXPR_NUM_THREADS=1",
        "--setenv=MPLCONFIGDIR=/tmp/hkbz-mpl",
        "--property=Type=exec",
        "--property=Restart=no",
        "--property=KillMode=control-group",
        "--property=TimeoutStopSec=180",
        "--property=LimitNOFILE=65536",
        f"--property=AllowedCPUs={TRAIN_CPUS[lane]}",
        f"--property=CPUAffinity={TRAIN_CPUS[lane]}",
        "--property=NUMAPolicy=bind",
        "--property=NUMAMask=0",
        "--property=CPUWeight=100",
        "--property=Nice=0",
        f"--property=StandardOutput=append:{paths['log'].resolve()}",
        f"--property=StandardError=append:{paths['log'].resolve()}",
        *command,
    ]
    if args.dry_run:
        return systemd_command
    subprocess.run(
        systemd_command,
        check=True,
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
    )
    return systemd_command


def stop_unit(unit: str, *, dry_run: bool) -> None:
    if dry_run:
        return
    subprocess.run(
        ["systemctl", "--user", "stop", f"{unit}.service"],
        check=True,
        stdout=subprocess.DEVNULL,
    )


def append_hardware_sample(path: Path, active: int) -> None:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            "unix_time,gpu0_memory_used_mib,gpu0_util_percent,"
            "mem_available_mib,swap_used_mib,active_ppo30_trainers\n",
            encoding="utf-8",
        )
    gpu = subprocess.run(
        [
            "nvidia-smi",
            "--id=0",
            "--query-gpu=memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        check=True,
        text=True,
        stdout=subprocess.PIPE,
    ).stdout.strip()
    gpu_memory, gpu_util = [value.strip() for value in gpu.split(",")]
    memory = {}
    for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
        key, value = line.split(":", 1)
        memory[key] = int(value.strip().split()[0])
    mem_available = memory["MemAvailable"] // 1024
    swap_used = (memory["SwapTotal"] - memory["SwapFree"]) // 1024
    with path.open("a", encoding="utf-8") as output:
        output.write(
            f"{int(time.time())},{gpu_memory},{gpu_util},"
            f"{mem_available},{swap_used},{active}\n"
        )


def main() -> int:
    args = parse_args()
    args.python = args.python.expanduser().resolve()
    args.suite_dir = (
        args.suite_dir.expanduser().resolve()
        if args.suite_dir is not None
        else (ROOT / "result/hkbz_train_logs" / args.run_tag).resolve()
    )
    manifest_path = args.suite_dir / "commands/full_formal_three.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    source_sha256 = str(manifest.get("source", {}).get("sha256", ""))
    if not source_sha256:
        raise RuntimeError("Stage2 manifest has no source checkpoint digest.")
    if PPO_MINI_BATCH_SIZE > PPO_ROLLOUT_THREADS:
        raise RuntimeError("Internal PPO30 geometry is invalid.")
    if PPO_MINI_BATCH_SIZE * PPO_DATA_CHUNK_LENGTH != PPO_MAX_GRAPHS:
        raise RuntimeError("Internal PPO30 graph geometry is invalid.")

    evaluator_unit = f"{args.unit_prefix}-g0eval"
    evaluator_socket = Path(f"/tmp/{evaluator_unit}.sock")
    status_path = args.suite_dir / "handoff/ppo30_status.json"
    hardware_path = args.suite_dir / "hardware/runtime_usage_ppo30.csv"
    started = time.monotonic()
    state = {
        "schema_version": 1,
        "status": "waiting_for_device_bc",
        "started_at": utc_now(),
        "run_tag": args.run_tag,
        "geometry": {
            "n_rollout_threads": PPO_ROLLOUT_THREADS,
            "mini_batch_size": PPO_MINI_BATCH_SIZE,
            "data_chunk_length": PPO_DATA_CHUNK_LENGTH,
            "graphs_per_forward": PPO_MAX_GRAPHS,
        },
        "lanes": {},
    }
    lane_runtime = []
    for lane, method in enumerate(METHODS):
        paths = lane_paths(args, lane, method)
        entry = manifest.get("commands", {}).get(method, {})
        command = list(entry.get("argv", []))
        if not command:
            raise RuntimeError(f"Manifest command is missing for {method}.")
        expected_teacher = str(command_option(command, "--device_bc_teacher"))
        runtime = {
            "lane": lane,
            "method": method,
            "paths": paths,
            "expected_teacher": expected_teacher,
            "expected_lookahead_contract": (
                lookahead_contract_from_command(command)
            ),
            "launched": False,
        }
        lane_runtime.append(runtime)
        state["lanes"][method] = {
            "lane": lane,
            "old_unit": paths["old_unit"],
            "new_unit": paths["new_unit"],
            "checkpoint": str(paths["checkpoint"]),
            "continuation_name": paths["continuation_name"],
            "status": "waiting_for_device_bc",
        }
    atomic_json(status_path, state)

    if args.dry_run:
        state["status"] = "dry_run"
        for runtime in lane_runtime:
            paths = runtime["paths"]
            state["lanes"][runtime["method"]]["launch_command"] = (
                launch_continuation(
                    args,
                    runtime["lane"],
                    runtime["method"],
                    paths,
                )
            )
        atomic_json(status_path, state)
        return 0

    if systemctl_state(evaluator_unit) != "active" or not evaluator_socket.exists():
        raise RuntimeError(
            f"Shared evaluator is not ready: {evaluator_unit}.service "
            f"socket={evaluator_socket}"
        )

    while not all(runtime["launched"] for runtime in lane_runtime):
        if time.monotonic() - started > args.wait_timeout_seconds:
            state["status"] = "failed"
            state["error"] = "Timed out waiting for DeviceBC checkpoints."
            state["updated_at"] = utc_now()
            atomic_json(status_path, state)
            return 1
        for runtime in lane_runtime:
            if runtime["launched"]:
                paths = runtime["paths"]
                lane_state = state["lanes"][runtime["method"]]
                unit_state = systemctl_state(paths["new_unit"])
                payload = run_status(paths["continuation_status"])
                lane_state["new_unit_state"] = unit_state
                lane_state["run_status"] = payload.get("status")
                lane_state["run_event"] = payload.get("event")
                if unit_state not in {"active", "activating"}:
                    lane_state["status"] = "failed"
                    state["status"] = "failed"
                    state["error"] = (
                        f"PPO30 continuation exited before every DeviceBC "
                        f"lane was ready: {runtime['method']} "
                        f"unit_state={unit_state}."
                    )
                    state["updated_at"] = utc_now()
                    atomic_json(status_path, state)
                    return 1
                continue
            lane = runtime["lane"]
            method = runtime["method"]
            paths = runtime["paths"]
            lane_state = state["lanes"][method]
            lane_state["old_unit_state"] = systemctl_state(paths["old_unit"])
            if not paths["checkpoint"].is_file():
                continue
            evidence = validate_checkpoint(
                paths["checkpoint"],
                expected_teacher=runtime["expected_teacher"],
                expected_source_sha256=source_sha256,
                expected_lookahead_contract=runtime[
                    "expected_lookahead_contract"
                ],
            )
            lane_state["checkpoint_evidence"] = evidence
            lane_state["status"] = "stopping_old_lane"
            lane_state["updated_at"] = utc_now()
            atomic_json(status_path, state)
            if systemctl_state(paths["old_unit"]) in {"active", "activating"}:
                stop_unit(paths["old_unit"], dry_run=False)
            if systemctl_state(evaluator_unit) != "active":
                raise RuntimeError(
                    "Shared evaluator stopped during the BC/PPO handoff."
                )
            if paths["record"].exists():
                raise FileExistsError(
                    f"Refusing ambiguous continuation record: {paths['record']}"
                )
            continuation_dir = RESULT_ROOT / paths["continuation_name"]
            if continuation_dir.exists():
                raise FileExistsError(
                    f"Refusing ambiguous continuation directory: {continuation_dir}"
                )
            launch_continuation(args, lane, method, paths)
            runtime["launched"] = True
            lane_state["status"] = "ppo30_launched"
            lane_state["launched_at"] = utc_now()
            lane_state["new_unit_state"] = systemctl_state(paths["new_unit"])
            atomic_json(status_path, state)
        if systemctl_state(evaluator_unit) != "active":
            state["status"] = "failed"
            state["error"] = "Shared evaluator stopped during PPO30 handoff."
            state["updated_at"] = utc_now()
            atomic_json(status_path, state)
            return 1
        active_new = sum(
            systemctl_state(runtime["paths"]["new_unit"])
            in {"active", "activating"}
            for runtime in lane_runtime
            if runtime["launched"]
        )
        append_hardware_sample(hardware_path, active_new)
        time.sleep(args.poll_seconds)

    state["status"] = "ppo30_running"
    state["all_lanes_launched_at"] = utc_now()
    atomic_json(status_path, state)

    while True:
        active = 0
        terminal = 0
        failures = []
        for runtime in lane_runtime:
            method = runtime["method"]
            paths = runtime["paths"]
            unit_state = systemctl_state(paths["new_unit"])
            payload = run_status(paths["continuation_status"])
            lane_state = state["lanes"][method]
            lane_state["new_unit_state"] = unit_state
            lane_state["run_status"] = payload.get("status")
            lane_state["run_event"] = payload.get("event")
            if unit_state in {"active", "activating"}:
                active += 1
                lane_state["status"] = "ppo30_running"
            elif payload.get("status") == "completed":
                terminal += 1
                lane_state["status"] = "completed"
            else:
                terminal += 1
                lane_state["status"] = "failed"
                failures.append(method)
        state["updated_at"] = utc_now()
        atomic_json(status_path, state)
        append_hardware_sample(hardware_path, active)
        if terminal == len(lane_runtime):
            state["status"] = "failed" if failures else "completed"
            state["failed_methods"] = failures
            state["completed_at"] = utc_now()
            atomic_json(status_path, state)
            stop_unit(evaluator_unit, dry_run=False)
            return 1 if failures else 0
        time.sleep(args.monitor_seconds)


if __name__ == "__main__":
    raise SystemExit(main())
