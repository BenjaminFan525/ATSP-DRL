#!/usr/bin/env python3
"""One-shot formal-checkpoint data migration, with a single validator handoff.

No failed experiment is retried. The old pool can finish epoch1 while new
training starts; a second pool is never started until the first exited cleanly.
"""
import argparse
import fcntl
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.queue_stage3_b0_env60 import run_unit, service, boundary_action, verify_commit
from onpolicy.utils.stage3_b0_protocol import identity, queue
from onpolicy.utils.stage3_b0_throughput import ENV60_BATCH_VERSION
from onpolicy.utils.stage3_b0_subset240 import (AUTHORIZATION, VERSION, START, OVERLAYS, select_cases)
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json, WORKSPACE_ROOT

SCHEMA = 'stage3-subset240-formal-checkpoint-transition-v1'
TEST_FILES = ('b0_subset240', 'b0_throughput', 'b0_env60', 'b0_batched_sampling',
    'b0_minibatches', 'b0_microbatch', 'b0', 'b0_recalibration', 'b0_reproduction',
    'full_data', 'full_policy', 'numerics', 'representation')
TEST_FILTER = 'not gpu and not native_complete and not real_workers'


def stage(current, output, staging):
    current, output, staging = [Path(p).resolve() for p in (current, output, staging)]
    for root in (current, output, staging):
        run_unit(root)
    if staging.exists() or output.exists():
        raise FileExistsError('Retain old attempts; use fresh transition/output directories')
    m = read_json(current/'manifest.json')
    if (m['root'] != str(current) or identity(m) != m['manifest_sha256']
            or m.get('subset_training') or m['throughput']['version'] != ENV60_BATCH_VERSION
            or (current/'PAUSE_AFTER_COMMIT').exists()
            or (current/f'train/commits/episodes_{START:06d}.json').exists()):
        raise ValueError('Expected the active, unpaused ENV60 run before its formal 960 checkpoint')
    select_cases(m['splits']['train_full600'])
    boundary_action(m, START, {})
    files = {}
    for relative in sorted(set(m['code']['files']) | set(OVERLAYS)):
        src = ROOT/relative if relative in OVERLAYS else current/'source'/relative
        checksum = digest_file(src)
        if relative not in OVERLAYS and checksum != m['code']['files'][relative]:
            raise ValueError('Parent numerical implementation changed')
        dst = staging/'source'/relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        if digest_file(dst) != checksum:
            raise ValueError('Source changed during the explicit subset overlay')
        files[relative] = checksum
    plan = {'schema': SCHEMA, 'authorization': AUTHORIZATION, 'version': VERSION,
        'created_unix': time.time(), 'current_root': str(current), 'output_root': str(output),
        'staging_root': str(staging), 'target_episodes': START, 'target_kind': 'formal_epoch1_checkpoint',
        'remaining_data_epochs': 7, 'remaining_trajectories': 2688, 'final_training_episodes': 3648,
        'parent_manifest_sha256': digest_file(current/'manifest.json'), 'files': files,
        'python': sys.executable, 'timeout_seconds': 172800, 'poll_seconds': 10,
        'all_old_artifacts_preserved': True, 'no_diagnostic_checkpoint_resume': True,
        'validator_handoff': 'overlap new training with old queue drain; no overlapping pools'}
    plan['plan_sha256'] = digest_json(plan)
    atomic_json(staging/'transition.json', plan, overwrite=False)
    print(staging/'transition.json', flush=True)


def verify_source(plan):
    if (plan['schema'] != SCHEMA or plan['authorization'] != AUTHORIZATION or plan['version'] != VERSION
            or plan['target_episodes'] != START or plan['remaining_data_epochs'] != 7
            or plan['remaining_trajectories'] != 2688 or plan['final_training_episodes'] != 3648
            or digest_json({k:v for k,v in plan.items() if k != 'plan_sha256'}) != plan['plan_sha256']):
        raise ValueError('Subset transition identity/budget changed')
    for root in (plan['current_root'], plan['output_root'], plan['staging_root']):
        run_unit(root)
    for name, checksum in plan['files'].items():
        if digest_file(Path(plan['staging_root'])/'source'/name) != checksum:
            raise ValueError(f'Tested staged source changed: {name}')


def verify_staged(plan):
    verify_source(plan)
    receipt = read_json(Path(plan['staging_root'])/'verification/receipt.json')
    if (not receipt['passed'] or receipt['source_files_sha256'] != digest_json(plan['files'])
            or any(digest_file(p) != h for p,h in receipt['reports'].items())):
        raise ValueError('Passing, source-bound subset tests required before checkpoint pause')


def verify(plan_path):
    plan = read_json(plan_path)
    verify_source(plan)
    if ROOT != Path(plan['staging_root'])/'source':
        raise ValueError('Run tests from the frozen staged source')
    output = Path(plan['staging_root'])/'verification'
    if output.exists():
        raise FileExistsError('Preserve all prior verification attempts')
    output.mkdir()
    import pytest
    os.chdir(WORKSPACE_ROOT)
    rc = pytest.main(['-q', '--import-mode=importlib',
        *[str(ROOT/f'onpolicy/envs/HKBZ/test/test_stage3_{name}.py') for name in TEST_FILES],
        '-k', TEST_FILTER, '--disable-warnings', '--junitxml='+str(output/'cpu.xml')])
    modules = {name: str(Path(module.__file__).resolve()) for name,module in sys.modules.items()
        if name.startswith('onpolicy.') and getattr(module, '__file__', None)}
    outside = {name:path for name,path in modules.items() if not Path(path).is_relative_to(ROOT)}
    atomic_json(output/'imports.json', {'passed': not outside, 'modules': modules,
        'outside': outside, 'source_root': str(ROOT), 'pytest_exit_code': rc}, overwrite=False)
    if rc or outside:
        raise RuntimeError('Subset regression/import audit failed; no checkpoint pause armed')
    import xml.etree.ElementTree as ET
    tests = list(ET.parse(output/'cpu.xml').getroot().iter('testcase'))
    names = {t.attrib['name'].split('[', 1)[0] for t in tests
             if t.find('skipped') is None and t.find('failure') is None and t.find('error') is None}
    required = {'test_subset240_exact_user_selection_is_immutable',
        'test_subset240_schedule_preserves_selected_original_seeds_and_seven_epochs',
        'test_subset240_only_data_budget_changes_and_epoch1_keeps_its_owner',
        'test_subset240_worker_finishes3648_and_submits_all_seven_epoch_checks',
        'test_subset240_real_eight_rank_eight_steps',
        'test_subset240_capacity_reuse_requires_passed_full_parent_not_diagnostic_weights',
        'test_subset240_transition_starts_training_before_serial_pool_handoff',
        'test_subset240_launcher_rejects_overlapping_validator_pools',
        'test_b0_private_exact_initialization_and_ready_frozen',
        'test_transaction_rejection_restores_every_state', 'test_real_eight_rank_b0_visit_mean'}
    if not required <= names:
        raise ValueError(f'Missing required subset regressions: {required-names}')
    verify_source(plan)
    atomic_json(output/'receipt.json', {'passed': True, 'source_files_sha256': digest_json(plan['files']),
        'reports': {str(p): digest_file(p) for p in (output/'cpu.xml', output/'imports.json')},
        'no_gpu_used': True, 'numerical_implementation_inherited_unchanged': True,
        'test_filter': TEST_FILTER,
        'environment_pool_capacity_probes': 'reuse source-bound parent ENV60 evidence; environment code unchanged',
        'full_parent_capacity_pass_required_at_migration': True,
        'new_gpu_capacity_test_performed': False}, overwrite=False)
    print(output/'receipt.json', flush=True)


def guard_gpu_owners(allowed_units):
    """Allow only this transition's known training/validation services; no preemption."""
    text = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
    for value in text.splitlines():
        pid = int(value.strip())
        try:
            lines = Path(f'/proc/{pid}/cgroup').read_text().splitlines()
        except FileNotFoundError:  # Process exited between NVML and /proc checks.
            continue
        groups = [line.split(':', 2)[-1].rstrip('/').split('/') for line in lines]
        if not any(unit in parts for parts in groups for unit in allowed_units):
            raise RuntimeError(f'Unexpected GPU process {pid}; leave it untouched and retain the prepared run')


def launch(plan, role):
    if role not in ('training', 'validator'):
        raise ValueError('Unknown subset service role')
    current, output = Path(plan['current_root']), Path(plan['output_root'])
    old, new = run_unit(current), run_unit(output)
    if service(old+'-training.service').get('MainPID') != '0':
        raise RuntimeError('Old training must exit before starting any new service')
    if role == 'validator' and (service(old+'-validator.service').get('MainPID') != '0'
            or service(old+'-validator.service').get('ExecMainStatus') != '0'):
        raise RuntimeError('Never overlap old and new validator pools')
    status = output/('status.json' if role == 'training' else 'validator/pool_service.json')
    if status.exists() or service(new+'-'+role+'.service').get('MainPID', '0') != '0':
        raise FileExistsError('No automatic retry or duplicate subset service')
    guard_gpu_owners([old+'-validator.service'] if role == 'training' else [new+'-training.service'])
    resources = read_json(output/'manifest.json')['resources']
    slice_name = old+'.slice'
    limits = subprocess.check_output(['systemctl', '--user', 'show', slice_name,
        '-p', 'MemoryHigh', '-p', 'MemoryMax', '-p', 'MemorySwapMax'], text=True)
    if (dict(line.split('=', 1) for line in limits.splitlines()) != {
            'MemoryHigh': 'infinity', 'MemoryMax': 'infinity', 'MemorySwapMax': '0'}
            or resources['memory_max_gib'] is not None or resources['tasks_max'] != 1024):
        raise ValueError('Original uncapped-memory execution contract changed')
    env = {'HKBZ_STAGE3_WORKSPACE_ROOT': str(WORKSPACE_ROOT), 'PYTHONPATH': str(output/'source'),
        'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0', 'CUDA_DEVICE_ORDER': 'PCI_BUS_ID',
        'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
        'NUMEXPR_NUM_THREADS': '1', 'MALLOC_ARENA_MAX': '2',
        'PYTORCH_CUDA_ALLOC_CONF': 'expandable_segments:True', 'CUBLAS_WORKSPACE_CONFIG': ':4096:8'}
    logfile = output/('controller.log' if role == 'training' else 'validator_service.log')
    command = ['systemd-run', '--user', '--slice='+slice_name, '--unit='+new+'-'+role,
        '--property=WorkingDirectory='+str(output/'source'),
        *['--setenv='+k+'='+v for k,v in env.items()],
        '--property=Type=exec', '--property=Restart=no', '--property=KillMode=control-group',
        '--property=TimeoutStopSec=60', '--property=RuntimeMaxSec=1209600',
        '--property=LimitNOFILE=65536', '--property=TasksMax=1024', '--property=OOMPolicy=stop',
        '--property=CPUAffinity=0-127', '--property=StandardOutput=append:'+str(logfile),
        '--property=StandardError=append:'+str(logfile), plan['python'], '-B', '-u',
        str(output/'source/onpolicy/scripts/train/run_stage3_b0.py'),
        'run' if role == 'training' else 'pool', '--manifest', str(output/'manifest.json')]
    subprocess.run(command, check=True, timeout=60)


def handoff_state(m, phase, **values):
    atomic_json(Path(m['root'])/'validator_handoff.json', {
        'protocol_sha256': m['manifest_sha256'],
        'parent_protocol_sha256': m['validator_handoff']['parent_protocol_sha256'],
        'transition_sha256': m['validator_handoff']['transition_sha256'],
        'phase': phase, 'pid': os.getpid(), 'heartbeat_unix': time.time(), **values})


def run(plan_path):
    plan = read_json(plan_path)
    verify_staged(plan)
    if ROOT != Path(plan['staging_root'])/'source':
        raise ValueError('Run the tested staged coordinator, not the workspace copy')
    current, output, staging = [Path(plan[k]) for k in ('current_root', 'output_root', 'staging_root')]
    if (staging/'completed.json').exists() or (staging/'failure.json').exists():
        raise FileExistsError('This one-shot transition already finished/failed; no automatic retry')
    old, new = run_unit(current), run_unit(output)
    parent = read_json(current/'manifest.json')
    if digest_file(current/'manifest.json') != plan['parent_manifest_sha256']:
        raise ValueError('Waiting parent manifest changed')
    commit_path = current/f'train/commits/episodes_{START:06d}.json'
    started, armed = time.time(), False
    def note(phase, **values):
        atomic_json(staging/'status.json', {'status': 'running', 'phase': phase, 'pid': os.getpid(),
            'heartbeat_unix': time.time(), 'started_unix': started, 'pause_armed': armed,
            'target_episodes': START, 'remaining_data_epochs': 7, **values})
    def tick():
        if time.time()-started > plan['timeout_seconds']:
            raise TimeoutError('Migration wait expired; no experiment was killed/retried')
        time.sleep(plan['poll_seconds'])
    with (staging/'transition.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            while True:
                state = read_json(current/'status.json')
                path = current/'train/full/rank0/status.json'
                rank = read_json(path) if path.exists() else {}
                if not armed and boundary_action(parent, START, rank) == 'arm':
                    atomic_json(current/'PAUSE_AFTER_COMMIT', {'authorization': AUTHORIZATION,
                        'transition': str(plan_path), 'plan_sha256': plan['plan_sha256'],
                        'target_episodes': START, 'reason': 'save all eight formal checkpoints, then select exact240'}, overwrite=False)
                    armed = True
                if armed and state.get('phase') == 'paused_at_commit':
                    commit = verify_commit(parent, commit_path, START)
                    for i in range(8):
                        result = read_json(current/f'train/full/rank{i}/result.json')
                        if not result.get('paused') or result['training_episodes'] != START:
                            raise ValueError('All ranks must pause at the exact formal 960 checkpoint')
                    break
                if (state.get('status') == 'failed'
                        or service(old+'-training.service').get('ActiveState') not in ('active', 'activating')):
                    raise RuntimeError('Parent stopped before checkpoint; no retry or diagnostic resume')
                note('waiting_formal_960_checkpoint', parent_phase=state.get('phase'),
                    formal_training_started=state.get('formal_training_started', False))
                tick()
            while service(old+'-training.service').get('MainPID') != '0':
                note('waiting_old_training_exit')
                tick()
            if service(old+'-training.service').get('ExecMainStatus') != '0':
                raise RuntimeError('Parent controller did not exit cleanly')
            verify_staged(plan)
            note('preparing_selected240_from_formal960')
            subprocess.run([plan['python'], '-B', str(ROOT/'onpolicy/scripts/train/stage3_b0_subset240.py'),
                '--prepare-plan', str(plan_path)], check=True, cwd=ROOT, timeout=600)
            m = read_json(output/'manifest.json')
            if m['code']['files'] != plan['files']:
                raise ValueError('Candidate differs from tested source')
            # New formal training need not idle until the old epoch1 diagnostics
            # finish. Both generations have one shared pool, with a serial handoff.
            handoff_state(m, 'draining_parent_pool')
            launch(plan, 'training')
            while queue(parent).pending_count():
                if (service(old+'-validator.service').get('ActiveState') != 'active'
                        or list((current/'validator/failed').glob('*.json'))
                        or service(new+'-training.service').get('ActiveState') != 'active'):
                    raise RuntimeError('Training/old pool failed during drain; no automatic retry')
                pending = queue(parent).pending_count()
                handoff_state(m, 'draining_parent_pool', pending_parent_requests=pending)
                note('training_subset240_while_parent_pool_drains', pending_parent_requests=pending)
                tick()
            old_results = {}
            for kind in ('epochs', 'mechanism'):
                record = read_json(current/kind/'e000960.json')
                for request in record['requests']:
                    if queue(parent).poll(request) is None:
                        raise ValueError('Parent epoch1 result missing despite an empty queue')
                    path = current/'validator/results'/f'{request}.json'
                    old_results[str(path)] = digest_file(path)
            atomic_json(output/'inherited_validation_receipt.json', {
                'passed': True, 'parent_protocol_sha256': parent['manifest_sha256'],
                'results': old_results, 'no_result_relabeling': True}, overwrite=False)
            switching = time.time()
            handoff_state(m, 'switching_pool', switch_started_unix=switching)
            atomic_json(current/'validator/STOP', {'authorization': AUTHORIZATION,
                'reason': 'old requests drained; hand off the single shared pool', 'transition': str(plan_path)}, overwrite=False)
            while service(old+'-validator.service').get('MainPID') != '0':
                if time.time()-switching > 120:
                    raise TimeoutError('Old pool did not exit; do not start a second pool')
                handoff_state(m, 'switching_pool', switch_started_unix=switching)
                note('waiting_old_pool_exit')
                tick()
            launch(plan, 'validator')
            while not (output/'validator/pool_status.json').exists():
                if (service(new+'-validator.service').get('ActiveState') != 'active'
                        or time.time()-switching > 170):
                    raise RuntimeError('Replacement pool failed to start; no automatic retry')
                handoff_state(m, 'switching_pool', switch_started_unix=switching)
                note('waiting_single_replacement_pool')
                tick()
            handoff_state(m, 'new_pool_active', old_pool_clean_exit=True)
            atomic_json(staging/'completed.json', {'passed': True, 'new_experiment_launched': True,
                'target_episodes': START, 'old_commit_sha256': digest_file(commit_path),
                'new_manifest': str(output/'manifest.json'), 'new_manifest_sha256': digest_file(output/'manifest.json'),
                'single_pool_handoff_complete': True, 'all_old_artifacts_retained': True,
                'completed_unix': time.time(), 'final_training_episodes': 3648}, overwrite=False)
            note('subset240_running_single_pool_handoff_complete')
        except BaseException:
            import traceback
            failure = {'status': 'failed', 'error': traceback.format_exc(), 'created_unix': time.time(),
                'pause_armed': armed, 'no_retry': True, 'all_artifacts_retained': True}
            atomic_json(staging/'failure.json', failure, overwrite=False)
            if (output/'manifest.json').exists():
                handoff_state(read_json(output/'manifest.json'), 'failed', error=failure['error'])
            raise


def main():
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest='mode', required=True)
    prep = modes.add_parser('stage')
    for name in ('current', 'output', 'staging'):
        prep.add_argument('--'+name, type=Path, required=True)
    for name in ('verify', 'run'):
        modes.add_parser(name).add_argument('--plan', type=Path, required=True)
    args = parser.parse_args()
    if args.mode == 'stage':
        stage(args.current, args.output, args.staging)
    elif args.mode == 'verify':
        verify(args.plan.resolve())
    else:
        run(args.plan.resolve())


if __name__ == '__main__':
    main()
