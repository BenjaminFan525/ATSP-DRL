#!/usr/bin/env python3
"""Isolated entry point for P5-aligned baseline BC/PPO and async validation."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main(argv=None):
    from onpolicy.runner.shared import hkbz_runner
    from onpolicy.utils.stage1_async_eval import Stage1AsyncEvalMixin
    from onpolicy.scripts.train import train_hkbz

    class AlignedBaselineRunner(Stage1AsyncEvalMixin, hkbz_runner.HKBZ_Runner):
        pass

    # This affects only this explicitly selected training process.  Existing
    # Stage-2/3 services and standard training entry points remain unchanged.
    hkbz_runner.HKBZ_Runner = AlignedBaselineRunner
    train_hkbz.main(sys.argv[1:] if argv is None else argv)


if __name__ == "__main__":
    main()
