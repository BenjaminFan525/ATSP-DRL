#!/usr/bin/env python3
"""Finish the four active Stage-1 seed-1 runs, then stop their lanes.

The existing lane controllers were launched with seeds 1/2/3 already loaded
in memory.  To honour a later wave-1-only decision without interrupting the
active trainers, this monitor freezes only each controller process.  The
seed-1 training child remains runnable.  Once that child has written a
terminal run status and exited, the monitor retires the frozen controller and
records that the lane intentionally stopped after wave 1.
"""

from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import sys
import time
from typing import Any


ROOT = Path(__file__).resolve().parents[3]
RESULT_ROOT = ROOT / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo"
METHODS = ("l2d", "multi_ppo", "fjsp_drl", "daniel")
TERMINAL_RUN_STATES = {"completed", "failed", "interrupted"}


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def process_snapshot(pid: int) -> dict[str, Any] | None:
    stat_path = Path(f"/proc/{pid}/stat")
    try:
        raw = stat_path.read_text(encoding="utf-8")
        _, separator, suffix = raw.rpartition(")")
        if not separator:
            raise ValueError(f"Malformed {stat_path}.")
        fields = suffix.split()
        cmdline = Path(f"/proc/{pid}/cmdline").read_bytes().replace(
            b"\0", b" "
        ).decode("utf-8", errors="replace").strip()
        return {
            "pid": int(pid),
            "state": fields[0],
            "ppid": int(fields[1]),
            # /proc/<pid>/stat field 22; fields begins at field 3.
            "start_ticks": int(fields[19]),
            "cmdline": cmdline,
        }
    except FileNotFoundError:
        return None


def require_process(
    pid: int,
    *,
    expected_text: tuple[str, ...],
    expected_start_ticks: int | None = None,
) -> dict[str, Any]:
    snapshot = process_snapshot(pid)
    if snapshot is None:
        raise RuntimeError(f"Expected PID {pid} is not running.")
    if expected_start_ticks is not None and (
        snapshot["start_ticks"] != expected_start_ticks
    ):
        raise RuntimeError(f"PID {pid} was recycled; refusing to signal it.")
    missing = [text for text in expected_text if text not in snapshot["cmdline"]]
    if missing:
        raise RuntimeError(
            f"PID {pid} command does not contain {missing}: "
            f"{snapshot['cmdline']!r}."
        )
    return snapshot


def latest_run_status(experiment: str) -> tuple[Path, dict[str, Any]]:
    parent = RESULT_ROOT / experiment
    candidates: list[tuple[int, Path]] = []
    if parent.is_dir():
        for run_dir in parent.glob("run*"):
            suffix = run_dir.name.removeprefix("run")
            if suffix.isdigit():
                candidates.append((int(suffix), run_dir))
    if not candidates:
        raise FileNotFoundError(f"No run directory below {parent}.")
    run_dir = max(candidates)[1]
    status_path = run_dir / "run_status.json"
    if not status_path.is_file():
        raise FileNotFoundError(status_path)
    return status_path, read_json(status_path)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", type=Path, required=True)
    parser.add_argument("--poll-seconds", type=float, default=10.0)
    parser.add_argument("--check-only", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 2.0 <= args.poll_seconds <= 300.0:
        raise ValueError("--poll-seconds must be in [2, 300].")
    suite_dir = args.suite_dir.expanduser().resolve()
    manifest_path = suite_dir / "commands/experiment_manifest.json"
    manifest = read_json(manifest_path)
    if manifest.get("scope") != "stage1_learning_baselines":
        raise ValueError("Unexpected experiment-manifest scope.")
    if tuple(manifest.get("methods", ())) != METHODS:
        raise ValueError(f"Unexpected methods: {manifest.get('methods')!r}.")
    run_tag = str(manifest.get("run_tag", "")).strip()
    if not run_tag:
        raise ValueError("Experiment manifest has no run_tag.")

    records_dir = suite_dir / "records"
    monitor_path = records_dir / "wave1_stop_monitor.json"
    lock_path = records_dir / "wave1_stop_monitor.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock_stream = lock_path.open("a+", encoding="utf-8")
    try:
        fcntl.flock(lock_stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as error:
        raise RuntimeError("Another wave-1 stop monitor holds the lock.") from error

    lanes: dict[str, dict[str, Any]] = {}
    for method in METHODS:
        lane_path = records_dir / f"{method}_lane.json"
        lane = read_json(lane_path)
        if lane.get("method") != method:
            raise ValueError(f"Method mismatch in {lane_path}.")
        if lane.get("status") != "formal_running":
            raise ValueError(f"{method} lane is not formal_running.")
        if lane.get("current_run") != "seed1":
            raise ValueError(
                f"{method} current_run={lane.get('current_run')!r}; "
                "refusing a late wave-1 stop guard."
            )
        later_runs = [name for name in lane.get("runs", {}) if name != "canary_seed1"]
        if later_runs:
            raise ValueError(f"{method} already recorded formal runs: {later_runs}.")
        controller_pid = int(lane["controller_pid"])
        child_pid = int(lane["child_pid"])
        controller = require_process(
            controller_pid,
            expected_text=("run_stage1_learning_baseline_lane.py", "--method", method),
        )
        experiment = f"{run_tag}_{method}_seed1"
        child = require_process(
            child_pid,
            # train_hkbz intentionally replaces argv with a concise process
            # title after startup, so validate that title plus parentage.
            expected_text=(f"gnn_mappo-HKBZ-{experiment}",),
        )
        if child["ppid"] != controller_pid:
            raise RuntimeError(
                f"{method} trainer parent={child['ppid']}; expected "
                f"controller {controller_pid}."
            )
        run_status_path, run_status = latest_run_status(experiment)
        if str(run_status.get("status", "")) != "running":
            raise ValueError(
                f"{method} seed1 is already {run_status.get('status')!r}."
            )
        lanes[method] = {
            "lane_path": lane_path,
            "experiment": experiment,
            "run_status_path": run_status_path,
            "controller_pid": controller_pid,
            "controller_start_ticks": controller["start_ticks"],
            "child_pid": child_pid,
            "child_start_ticks": child["start_ticks"],
            "state": "validated",
            "last_run_event": run_status.get("event"),
            "last_run_heartbeat": run_status.get("heartbeat_timestamp"),
        }

    if args.check_only:
        print(json.dumps({
            "status": "check_ok",
            "suite_dir": str(suite_dir),
            "run_tag": run_tag,
            "policy": "complete seed1 only; never start seed2/seed3",
            "lanes": {
                method: {
                    key: str(value) if isinstance(value, Path) else value
                    for key, value in lane.items()
                }
                for method, lane in lanes.items()
            },
        }, ensure_ascii=False, indent=2))
        return 0

    if monitor_path.exists():
        raise FileExistsError(f"Refusing existing monitor state: {monitor_path}")

    state: dict[str, Any] = {
        "schema_version": 1,
        "status": "initializing",
        "policy": "complete seed1 only; never start seed2/seed3",
        "suite_dir": str(suite_dir),
        "run_tag": run_tag,
        "monitor_pid": os.getpid(),
        "created_unix_time": time.time(),
        "poll_seconds": args.poll_seconds,
        "lanes": {},
    }

    stopping = False

    def handle_signal(signum, _frame):
        nonlocal stopping
        stopping = True
        state.update({
            "status": "monitor_interrupted_controllers_remain_frozen",
            "signal": int(signum),
            "finished_unix_time": time.time(),
        })
        atomic_json(monitor_path, state)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    # Freeze only the lightweight parent controllers.  Their trainer children
    # stay runnable and continue the already-started seed-1 experiments.
    for method, lane in lanes.items():
        require_process(
            lane["controller_pid"],
            expected_text=("run_stage1_learning_baseline_lane.py", method),
            expected_start_ticks=lane["controller_start_ticks"],
        )
        os.kill(lane["controller_pid"], signal.SIGSTOP)
    time.sleep(0.25)
    for method, lane in lanes.items():
        controller = require_process(
            lane["controller_pid"],
            expected_text=("run_stage1_learning_baseline_lane.py", method),
            expected_start_ticks=lane["controller_start_ticks"],
        )
        if controller["state"] not in {"T", "t"}:
            raise RuntimeError(
                f"{method} controller did not stop: {controller['state']}."
            )
        lane["state"] = "seed1_running_controller_frozen"
        state["lanes"][method] = {
            key: str(value) if isinstance(value, Path) else value
            for key, value in lane.items()
        }
        print(
            f"[Frozen] {method} controller={lane['controller_pid']} "
            f"trainer={lane['child_pid']}",
            flush=True,
        )
    state["status"] = "monitoring_seed1"
    state["controllers_frozen_unix_time"] = time.time()
    atomic_json(monitor_path, state)

    unfinished = set(METHODS)
    terminal_seen: dict[str, float] = {}
    all_completed = True
    while unfinished and not stopping:
        now = time.time()
        for method in tuple(unfinished):
            lane = lanes[method]
            controller = require_process(
                lane["controller_pid"],
                expected_text=("run_stage1_learning_baseline_lane.py", method),
                expected_start_ticks=lane["controller_start_ticks"],
            )
            if controller["state"] not in {"T", "t"}:
                os.kill(lane["controller_pid"], signal.SIGSTOP)
                lane["controller_refrozen_unix_time"] = now

            run_status = read_json(lane["run_status_path"])
            run_state = str(run_status.get("status", "unknown"))
            lane["last_run_status"] = run_state
            lane["last_run_event"] = run_status.get("event")
            lane["last_run_heartbeat"] = run_status.get("heartbeat_timestamp")
            state["lanes"][method] = {
                key: str(value) if isinstance(value, Path) else value
                for key, value in lane.items()
            }
            if run_state not in TERMINAL_RUN_STATES:
                continue
            terminal_seen.setdefault(method, now)
            child = process_snapshot(lane["child_pid"])
            if child is not None and child["start_ticks"] != lane["child_start_ticks"]:
                raise RuntimeError(
                    f"{method} child PID was recycled; refusing finalization."
                )
            if child is not None and child["state"] != "Z":
                lane["state"] = "terminal_status_waiting_for_trainer_exit"
                lane["terminal_seen_unix_time"] = terminal_seen[method]
                continue

            # The trainer has closed its outputs.  SIGKILL only the frozen
            # controller so it cannot wake and launch the next seed.
            os.kill(lane["controller_pid"], signal.SIGKILL)
            deadline = time.monotonic() + 10.0
            while time.monotonic() < deadline:
                snapshot = process_snapshot(lane["controller_pid"])
                if snapshot is None or snapshot["state"] == "Z":
                    break
                time.sleep(0.1)

            lane_record = read_json(lane["lane_path"])
            successful = run_state == "completed"
            lane_record["runs"]["seed1"] = {
                "status": "completed" if successful else run_state,
                "run_status": run_state,
                "run_dir": str(lane["run_status_path"].parent),
                "total_num_steps": run_status.get("total_num_steps"),
                "eval_makespan": run_status.get("eval_makespan"),
                "best_eval_makespan": run_status.get("best_eval_makespan"),
                "actor_step_completion_rate": run_status.get(
                    "actor_step_completion_rate"
                ),
                "finished_unix_time": now,
            }
            lane_record.update({
                "status": (
                    "wave1_completed_stopped" if successful
                    else "wave1_terminal_stopped"
                ),
                "current_run": None,
                "child_pid": None,
                "wave1_only": True,
                "stop_reason": "user_requested_stop_after_seed1",
                "finished_unix_time": now,
            })
            atomic_json(lane["lane_path"], lane_record)
            lane["state"] = lane_record["status"]
            lane["finished_unix_time"] = now
            state["lanes"][method] = {
                key: str(value) if isinstance(value, Path) else value
                for key, value in lane.items()
            }
            all_completed = all_completed and successful
            unfinished.remove(method)
            print(
                f"[Finalized] {method} seed1={run_state}; controller retired.",
                flush=True,
            )

        state["heartbeat_unix_time"] = now
        state["unfinished_methods"] = sorted(unfinished)
        state["status"] = "monitoring_seed1" if unfinished else (
            "completed" if all_completed else "completed_with_terminal_failure"
        )
        atomic_json(monitor_path, state)
        if unfinished and not stopping:
            time.sleep(args.poll_seconds)

    if stopping:
        return 130
    state["completed_unix_time"] = time.time()
    atomic_json(monitor_path, state)
    return 0 if all_completed else 1


if __name__ == "__main__":
    raise SystemExit(main())
