#!/usr/bin/env python3
"""Single-GPU prefix sampling/replay probe; never a formal update/admission."""
import argparse
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
from onpolicy.scripts.train.stage3_b0_worker import engine, diagnostic_batch
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat, trajectory_record
from onpolicy.utils.stage3_b0_throughput import restore_parent, reference_manifest
from onpolicy.utils.stage3_batched_sampling import BATCHING_VERSION
from onpolicy.utils.stage3_full_policy import shard
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file


def memory():
    torch.cuda.synchronize()
    return {'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,
            'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30,
            'current_allocated_gib':torch.cuda.memory_allocated()/2**30}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--mode', choices=('serial','batched'), required=True)
    parser.add_argument('--steps', type=int, default=8)
    args = parser.parse_args()
    if args.output.exists() or not 2 <= args.steps <= 32:
        raise ValueError('Use a new diagnostic directory and 2..32 prefix steps')
    m = read_json(args.manifest)
    reference = reference_manifest(m)
    train = {c['path'] for c in m['splits']['train_full600']}
    dense = max((r for r in read_json(Path(reference['root'])/'baselines.json')['cases'] if r['case_id'] in train),
                key=lambda r:r['max_graph_tensor_bytes'])['case_id']
    batch = shard(diagnostic_batch(m, 288, dense), 0, 8)
    args.output.mkdir(parents=True)
    with ProgressHeartbeat(args.output/'status.json', phase='batched_sampling_prefix') as hb:
        runner = engine(m, 'F_PRIVATE', 36)
        runner.stochastic_batching = BATCHING_VERSION if args.mode=='batched' else 'per_case_v1'
        original = runner.pool.call
        def prefix(commands):
            result = original(commands)
            for i, command, _ in commands:
                if command == 'summary':
                    result[i] = {**result[i], 'actual_completed':result[i]['completed'],
                        'completed':True, 'synthetic_prefix_fixture':True}
            return result
        runner.pool.call = prefix
        try:
            payload = restore_parent(runner, m, 0)
            torch.cuda.reset_peak_memory_stats()
            start = time.perf_counter()
            rows = runner.rollout(batch['cases'], batch['seeds'], retain=True,max_steps=args.steps,heartbeat=hb)
            for row in rows:
                row['completed'] = row['actual_completed']
            rollout_memory = memory()
            seconds = time.perf_counter()-start
            inference = dict(runner.last_rollout_inference)
            assert inference['max_forward_batch'] == (36 if args.mode=='batched' else 1)
            assert inference['forward_calls'] == (args.steps if args.mode=='batched' else 36*args.steps)
            # No prefix data is given to any optimizer. Replay only checks the
            # unchanged forced-action distribution and history on these states.
            torch.cuda.reset_peak_memory_stats()
            replay = runner.replay_metrics(rows, heartbeat=hb)
            replay_memory = memory()
            assert replay['max_logp_error'] <= .002
            assert runner.policy_updates == payload['policy_updates']
            assert max(rollout_memory['peak_reserved_gib'], replay_memory['peak_reserved_gib']) < 22
            atomic_json(args.output/'result.json', {'passed':True, 'diagnostic_only':True,
                'full_capacity_admission':False, 'formal_actor_updates':0,
                'source_actor_updates':payload['policy_updates'], 'mode':args.mode, 'width':36,
                'prefix_steps':args.steps, 'rollout_seconds':seconds,
                'trajectory_steps_per_second':36*args.steps/seconds,
                'inference':inference, 'rollout_memory':rollout_memory, 'replay_memory':replay_memory,
                'replay':replay, 'records':[trajectory_record(r) for r in rows],
                'manifest_sha256':m['manifest_sha256'], 'code_sha256':m['code']['sha256'],
                'script_sha256':digest_file(__file__),
                'stochastic_traces_not_expected_to_match_legacy':True}, overwrite=False)
            print(args.output/'result.json', flush=True)
        except BaseException:
            import traceback
            atomic_json(args.output/'failure.json', {'passed':False, 'diagnostic_only':True,
                'no_automatic_retry':True, 'error':traceback.format_exc()}, overwrite=False)
            raise
        finally:
            runner.close()


if __name__ == '__main__':
    main()
