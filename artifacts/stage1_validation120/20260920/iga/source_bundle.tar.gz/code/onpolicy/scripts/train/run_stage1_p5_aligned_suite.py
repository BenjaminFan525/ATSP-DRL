#!/usr/bin/env python3
"""Launch or run isolated P5-aligned baseline lanes; never retry failed runs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.prepare_stage1_p5_aligned_baselines import (
    METHODS, check_cpu_isolation, option, read_json, sha256, write_json,
)
from onpolicy.utils.shared_eval import parse_cpu_set


def load_manifest(path, *, require_authorized=True):
    path = Path(path).resolve()
    manifest = read_json(path)
    if manifest.get("scope") != "stage1_p5_aligned_baselines":
        raise ValueError("Unexpected experiment scope")
    if require_authorized and (
        manifest.get("launch_authorized") is not True
        or manifest.get("initialization_choice") != "new_semantics_budget_matched"
    ):
        raise RuntimeError("Launch blocked: historical initialization semantics require explicit user approval.")
    if tuple(lane["method"] for lane in manifest["lanes"]) != METHODS:
        raise ValueError("Expected exactly four baseline lanes, never proposed")
    check_cpu_isolation([lane["cpu_set"] for lane in manifest["lanes"]] + [manifest["evaluator"]["cpu_set"]])
    for record in manifest["reference_main_checkpoints"].values():
        if sha256(record["path"]) != record["sha256"]:
            raise ValueError("A frozen main-experiment checkpoint changed")
    if sha256(manifest["potential_path"]) != manifest["potential_sha256"]:
        raise ValueError("P5 potential changed after protocol freeze")
    if sha256(path.parent / "env_frozen.yaml") != manifest["env_config_sha256"]:
        raise ValueError("Environment configuration changed after protocol freeze")
    for relative, digest in manifest["code_sha256"].items():
        if sha256(Path(manifest["code_root"]) / relative) != digest:
            raise ValueError(f"Frozen source changed: {relative}")
    for lane in manifest["lanes"]:
        for phase in lane["phases"]:
            if sha256(phase["command_json"]) != phase["command_sha256"]:
                raise ValueError("A frozen phase command changed")
            command = read_json(phase["command_json"])["command"]
            if option(command, "--stage1_baseline") != lane["method"]:
                raise ValueError("Command architecture differs from lane")
            if option(command, "--shared_eval_socket") != manifest["evaluator"]["socket_path"]:
                raise ValueError("A lane is not using the one shared validator")
    return manifest


def run_lane(path, method):
    manifest = load_manifest(path)
    suite = Path(path).resolve().parent
    lane = next(lane for lane in manifest["lanes"] if lane["method"] == method)
    expected_cpus = parse_cpu_set(lane["cpu_set"])
    if os.sched_getaffinity(0) != set(expected_cpus):
        raise RuntimeError("Lane did not inherit its exact CPU isolation")
    if os.environ.get("CUDA_VISIBLE_DEVICES") != str(lane["gpu"]):
        raise RuntimeError("Lane GPU mapping mismatch")
    status_path = Path(lane["status_path"])
    if status_path.exists():
        raise FileExistsError("Refusing an implicit restart/retry of this lane")
    state = {"status": "running", "method": method, "pid": os.getpid(),
        "gpu": lane["gpu"], "cpu_set": lane["cpu_set"], "completed_phases": [],
        "started_unix_time": time.time()}
    process = None
    try:
        for phase in lane["phases"]:
            command = read_json(phase["command_json"])["command"]
            run_dir = Path(phase["run_dir"])
            if run_dir.parent.exists():
                raise FileExistsError(f"Refusing to overwrite an existing run: {run_dir.parent}")
            if phase["dependency"] and not Path(phase["dependency"]).is_file():
                raise FileNotFoundError(phase["dependency"])
            phase_key = f"{phase['phase']}_seed{phase['seed']}"
            log_path = suite / "service_logs" / f"{method}_{phase_key}.log"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            started = time.monotonic()
            state.update({"phase": phase_key, "command_json": phase["command_json"],
                "training_log": str(log_path), "run_dir": str(run_dir),
                "phase_started_unix_time": time.time()})
            print(f"[Lane] starting {method} {phase_key}", flush=True)
            with log_path.open("x") as output:
                process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT,
                    cwd=manifest["code_root"], start_new_session=True)
                state["training_pid"] = process.pid
                write_json(status_path, state)
                while process.poll() is None:
                    elapsed = time.monotonic() - started
                    state.update({"phase_elapsed_seconds": elapsed, "heartbeat_unix_time": time.time()})
                    write_json(status_path, state)
                    if elapsed > phase["timeout_seconds"]:
                        print(f"[HardTimeout] {method} {phase_key}; terminating only owned process group {process.pid}", flush=True)
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=120)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                        raise TimeoutError(f"Phase exceeded {phase['timeout_seconds']} seconds")
                    time.sleep(30)
                if process.returncode != 0:
                    raise RuntimeError(f"{phase_key} exited {process.returncode}; no automatic retry")
            runtime = read_json(run_dir / "run_status.json")
            if runtime.get("status") != "completed":
                raise RuntimeError(f"Training status is not completed: {runtime.get('status')}")
            evaluation = read_json(run_dir / "async_evaluation/status.json")
            if evaluation["pending"] or len(evaluation["completed"]) != phase["required_evaluations"]:
                raise RuntimeError("Phase ended without draining every prescribed evaluation")
            if phase["phase"] == "canary" and not all(item["valid"] for item in evaluation["completed"]):
                raise RuntimeError("Canary has incomplete/non-finite validation; inspect before training")
            artifact = run_dir / "models" / ("checkpoint_PlaneBC.pt" if phase["phase"].endswith("bc") else "checkpoint_Best.pt")
            if not artifact.is_file():
                raise FileNotFoundError(artifact)
            state["completed_phases"].append({"phase": phase_key,
                "elapsed_seconds": time.monotonic() - started,
                "artifact": str(artifact), "artifact_sha256": sha256(artifact)})
            write_json(status_path, state)
            process = None
        state.update({"status": "completed", "completed_unix_time": time.time()})
        write_json(status_path, state)
    except BaseException as error:
        state.update({"status": "failed", "error": f"{type(error).__name__}: {error}",
                      "failed_unix_time": time.time()})
        write_json(status_path, state)
        raise


def run_evaluator(path):
    manifest = load_manifest(path)
    spec = manifest["evaluator"]
    if os.sched_getaffinity(0) != set(parse_cpu_set(spec["cpu_set"])):
        raise RuntimeError("Validator CPU isolation mismatch")
    if Path(spec["socket_path"]).exists():
        raise FileExistsError("Refusing to replace an existing validation socket")
    from onpolicy.scripts.train import shared_hkbz_evaluator as shared
    cli = argparse.Namespace(
        source_command_json=Path(spec["source_command_json"]),
        socket_path=Path(spec["socket_path"]), cpu_pool=spec["cpu_set"],
        run_dir=Path(spec["run_dir"]), eval_dataset_dir=None,
        eval_case_offset=None, max_eval_cases=spec["cases"],
        cuda_memory_fraction=spec["cuda_memory_fraction"],
        eval_partition_seed=None, eval_partition_stratify_by=None,
    )
    def stop(_signal, _frame):
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    def watch_lanes():
        while True:
            time.sleep(30)
            states = []
            for lane in manifest["lanes"]:
                try:
                    states.append(read_json(lane["status_path"])["status"])
                except (FileNotFoundError, json.JSONDecodeError, KeyError):
                    break
            if len(states) == len(METHODS) and all(value in {"completed", "failed"} for value in states):
                print("[SharedEval] all owned lanes ended; closing the validation pool", flush=True)
                os.kill(os.getpid(), signal.SIGTERM)
                return
    threading.Thread(target=watch_lanes, daemon=True, name="suite-lifecycle").start()
    return shared.serve(cli)


def launch(path):
    path = Path(path).resolve()
    manifest = load_manifest(path)
    suite = path.parent
    if (suite / "launch_record.json").exists():
        raise FileExistsError("Refusing duplicate suite launch")
    if Path(manifest["evaluator"]["socket_path"]).exists():
        raise FileExistsError("Shared validation socket already exists")
    gpu_table = subprocess.check_output([
        "nvidia-smi", "--query-gpu=index,uuid", "--format=csv,noheader,nounits"
    ], text=True)
    gpu_uuids = {int(row[0].strip()): row[1].strip() for row in csv.reader(io.StringIO(gpu_table))}
    occupied = subprocess.check_output([
        "nvidia-smi", "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader,nounits"
    ], text=True)
    busy = {row[0].strip() for row in csv.reader(io.StringIO(occupied)) if row}
    for lane in manifest["lanes"]:
        if gpu_uuids[lane["gpu"]] in busy:
            raise RuntimeError(f"GPU {lane['gpu']} is no longer idle")
    suffix = hashlib.sha256(manifest["run_tag"].encode()).hexdigest()[:10]
    unit_prefix = "hkbz-p5b-" + suffix
    units = [unit_prefix + "-eval"] + [unit_prefix + "-" + method for method in METHODS]
    for unit in units:
        result = subprocess.run(["systemctl", "--user", "show", unit + ".service", "--property=LoadState", "--value"], capture_output=True, text=True)
        if result.stdout.strip() not in {"", "not-found"}:
            raise RuntimeError(f"Unit already exists: {unit}")
    script = Path(manifest["code_root"]) / "onpolicy/scripts/train/run_stage1_p5_aligned_suite.py"
    logs = suite / "service_logs"
    logs.mkdir(parents=True, exist_ok=True)
    launch_record = {"status": "launching", "manifest_sha256": sha256(path),
        "started_unix_time": time.time(), "units": [], "gpu_uuids": gpu_uuids}
    write_json(suite / "launch_record.json", launch_record)

    def start(unit, role, gpu, cpus, method=None):
        command = ["systemd-run", "--user", "--unit=" + unit, "--collect",
            "--property=Type=exec", "--property=Restart=no", "--property=KillMode=control-group",
            "--property=TimeoutStopSec=180", "--property=LimitNOFILE=65536",
            "--property=WorkingDirectory=" + manifest["code_root"],
            "--property=AllowedCPUs=" + cpus, "--property=CPUAffinity=" + cpus,
            "--property=StandardOutput=append:" + str(logs / (unit + ".log")),
            "--property=StandardError=append:" + str(logs / (unit + ".log")),
            "--setenv=CUDA_VISIBLE_DEVICES=" + str(gpu), "--setenv=CUDA_DEVICE_ORDER=PCI_BUS_ID",
            "--setenv=OMP_NUM_THREADS=1", "--setenv=MKL_NUM_THREADS=1",
            "--setenv=OPENBLAS_NUM_THREADS=1", "--setenv=NUMEXPR_NUM_THREADS=1",
            "--setenv=PYTHONHASHSEED=0", "--setenv=PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True",
            "--setenv=MPLCONFIGDIR=/tmp/hkbz-p5b-mpl",
            "/usr/bin/taskset", "--cpu-list", cpus, manifest["python"], "-u", str(script),
            "--manifest", str(path), "--role", role]
        if method:
            command.extend(("--method", method))
        subprocess.run(command, check=True)
        launch_record["units"].append({"unit": unit + ".service", "role": role,
            "method": method, "gpu": gpu, "cpu_set": cpus, "command": command})
        write_json(suite / "launch_record.json", launch_record)

    spec = manifest["evaluator"]
    try:
        start(units[0], "evaluator", spec["gpu"], spec["cpu_set"])
        deadline = time.monotonic() + 600
        while time.monotonic() < deadline:
            status = Path(spec["run_dir"]) / "service_status.json"
            if status.is_file() and read_json(status).get("status") == "ready":
                break
            active = subprocess.run(["systemctl", "--user", "is-active", units[0] + ".service"], capture_output=True, text=True)
            if active.stdout.strip() not in {"active", "activating"}:
                raise RuntimeError("Shared validator exited before readiness; no trainers were started")
            time.sleep(2)
        else:
            raise TimeoutError("Shared validator did not become ready in 600 seconds")
        for unit, lane in zip(units[1:], manifest["lanes"]):
            start(unit, "lane", lane["gpu"], lane["cpu_set"], lane["method"])
        launch_record.update({"status": "launched", "launched_unix_time": time.time()})
        write_json(suite / "launch_record.json", launch_record)
    except BaseException as error:
        launch_record.update({"status": "launch_failed", "error": f"{type(error).__name__}: {error}"})
        write_json(suite / "launch_record.json", launch_record)
        raise
    print(json.dumps(launch_record, indent=2, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--role", choices=("launch", "lane", "evaluator", "check"), required=True)
    parser.add_argument("--method", choices=METHODS)
    args = parser.parse_args()
    if args.role == "launch":
        launch(args.manifest)
    elif args.role == "lane":
        if not args.method:
            parser.error("lane requires --method")
        run_lane(args.manifest, args.method)
    elif args.role == "evaluator":
        run_evaluator(args.manifest)
    else:
        manifest = load_manifest(args.manifest, require_authorized=False)
        print(json.dumps({"status": "checked", "launch_authorized": manifest["launch_authorized"]}))


if __name__ == "__main__":
    main()
