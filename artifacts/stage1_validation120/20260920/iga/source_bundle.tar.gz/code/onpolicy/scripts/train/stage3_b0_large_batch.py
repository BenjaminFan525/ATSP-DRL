#!/usr/bin/env python3
"""Prepare, capacity-admit and run the explicitly changed B0 batch recipe."""
import argparse
import copy
import json
import os
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_stage3_b0 import B0Suite
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
from onpolicy.utils.stage3_b0_protocol import (identity, comparison_contract, baseline_costs,
    submit, MECHANISM, queue)
from onpolicy.utils.stage3_b0_throughput import (VERSION, AUTHORIZATION, training_contract,
    continuation_plan, parent_manifest, reference_manifest, select_profile, regroup,
    MICRO_VERSION, MICRO_AUTHORIZATION, MINIBATCH_VERSION, MINIBATCH_AUTHORIZATION,
    ENV24_VERSION, ENV24_AUTHORIZATION, ENV48_VERSION, ENV48_AUTHORIZATION,
    ENV36_BATCH_VERSION, ENV36_BATCH_AUTHORIZATION, ENV60_BATCH_VERSION, ENV60_BATCH_AUTHORIZATION,
    capacity_memory_pass, epoch_owner)
from onpolicy.utils.stage3_full_data import schedule
from onpolicy.utils.stage3_research import read_json, atomic_json, digest_json, digest_file, paired_summary
from onpolicy.utils.stage3_representation import risk_pass

OVERLAYS = (
    'onpolicy/utils/stage3_b0_protocol.py', 'onpolicy/utils/stage3_b0_throughput.py',
    'onpolicy/scripts/train/stage3_b0_worker.py', 'onpolicy/scripts/train/run_stage3_b0.py',
    'onpolicy/scripts/train/stage3_b0_large_batch.py',
    'onpolicy/scripts/train/stage3_b0_large_batch_worker.py',
    'onpolicy/scripts/train/probe_stage3_b0_batch.py',
    'onpolicy/envs/HKBZ/test/test_stage3_b0_throughput.py',
    'STAGE3_B0_LARGE_BATCH_20260913.md',
)
MICRO_OVERLAYS = OVERLAYS + (
    'onpolicy/runner/shared/stage3_research_engine.py',
    'onpolicy/utils/stage3_batched_sampling.py',
    'onpolicy/envs/HKBZ/test/test_stage3_b0_microbatch.py',
    'STAGE3_B0_MICROBATCH_20260913.md',
)
MINIBATCH_OVERLAYS = MICRO_OVERLAYS + (
    'onpolicy/utils/stage3_ppo_minibatches.py',
    'onpolicy/utils/stage3_b0_diagnostics.py',
    'onpolicy/envs/HKBZ/test/test_stage3_b0_minibatches.py',
    'STAGE3_B0_MINIBATCH36_20260913.md',
)
ENV24_OVERLAYS = MINIBATCH_OVERLAYS + (
    'onpolicy/utils/stage3_environment_preload.py',
    'onpolicy/scripts/train/probe_stage3_b0_env_pool.py',
    'onpolicy/envs/HKBZ/test/test_stage3_b0_env24.py',
    'STAGE3_B0_ENV24_20260913.md',
)
ENV48_OVERLAYS = ENV24_OVERLAYS + (
    'onpolicy/envs/HKBZ/test/test_stage3_b0_env48.py',
    'STAGE3_B0_ENV48_20260913.md',
)
ENV36_BATCH_OVERLAYS = ENV48_OVERLAYS + (
    'onpolicy/runner/shared/stage3_b0_engine.py',
    'onpolicy/algorithms/utils/ptr_actor.py',
    'onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py',
    'onpolicy/envs/HKBZ/test/test_stage3_b0_batched_sampling.py',
    'onpolicy/scripts/train/probe_stage3_b0_batched_sampling.py',
    'STAGE3_B0_ENV36_BATCHED_20260913.md',
)
ENV60_BATCH_OVERLAYS = ENV36_BATCH_OVERLAYS + (
    'onpolicy/envs/HKBZ/test/test_stage3_b0_env60.py',
    'onpolicy/scripts/train/queue_stage3_b0_env60.py',
    'onpolicy/scripts/train/launch_stage3_b0_env60.sh',
    'onpolicy/scripts/train/verify_stage3_b0_env60.py',
    'STAGE3_B0_ENV60_20260913.md',
)


def env24_probe_evidence(directory, source_files, *, width=24):
    directory = Path(directory).resolve()
    reports = {method: read_json(directory/f'{method}.json') for method in ('spawn', 'forkserver')}
    if any(not r['passed'] or r['live_environments'] != width or r['actor_updates'] != 0
           or not r['diagnostic_only'] or r['full_capacity_admission'] for r in reports.values()):
        raise ValueError(f'Both real {width}-process diagnostic probes must pass')
    if reports['spawn']['records'] != reports['forkserver']['records']:
        raise ValueError('CPU process start method changed seeded rollout behavior')
    if width in (36, 60):
        from onpolicy.utils.stage3_batched_sampling import BATCHING_VERSION
        if any(r.get('inference', {}).get('max_forward_batch') != width
               or r['inference']['stochastic_batching'] != BATCHING_VERSION for r in reports.values()):
            raise ValueError(f'{width}-env probes must exercise actual batched inference')
    if max(r['total_pss_gib'] for r in reports['forkserver']['memory']) >= max(r['total_pss_gib'] for r in reports['spawn']['memory']):
        raise ValueError('CPU forkserver has not demonstrated a memory reduction')
    for report in reports.values():
        if any(source_files.get(p) != h for p, h in report['probe_code_files'].items()):
            raise ValueError('Environment pool probes did not test the frozen implementation')
    return {str(directory/f'{method}.json'): digest_file(directory/f'{method}.json') for method in reports}


def prepare(parent_path, commit_path, probes, output, *, microbatch=False, rollout_envs=12,
            optimizer_minibatches=False, env24=False, env48=False, env36_batch=False,
            env60_batch=False, env_pool_probes=None):
    parent_path, commit_path, output = [Path(p).resolve() for p in (parent_path, commit_path, output)]
    if output.exists():
        raise FileExistsError('Use a new immutable continuation directory')
    parent, commit = read_json(parent_path), read_json(commit_path)
    if env60_batch:
        if not 0 < commit['training_episodes'] < 7680 or commit['training_episodes'] % 32:
            raise ValueError('ENV60 requires a completed formal checkpoint before the final epoch')
    elif not 0 < commit['training_episodes'] < 960:
        raise ValueError('This continuation preserves all eight epoch endpoints and starts before epoch1')
    reports = {}
    if sum((microbatch, optimizer_minibatches, env24, env48, env36_batch, env60_batch)) > 1:
        raise ValueError('Select gradient accumulation OR independent optimizer minibatches')
    concurrent = env24 or env48 or env36_batch or env60_batch
    concurrent_width = 60 if env60_batch else 36 if env36_batch else 48 if env48 else 24
    split_backward = microbatch or optimizer_minibatches or concurrent
    if split_backward:
        allowed_parent = (VERSION, ENV36_BATCH_VERSION) if env60_batch else (VERSION,)
        parent_version = parent.get('throughput', {}).get('version')
        if (parent_version not in allowed_parent
                or parent['training']['global_batch'] != {VERSION:96, ENV36_BATCH_VERSION:288}[parent_version]):
            raise ValueError('Microbatch continuation starts from admitted batch96')
        if rollout_envs not in ((60,) if env60_batch else (36,) if env36_batch else (48,) if env48 else (12, 24)):
            raise ValueError('Resident environments must match the selected continuation mode')
        batch, overlays = 192, MICRO_OVERLAYS
        if optimizer_minibatches:
            if rollout_envs != 12:
                raise ValueError('36/12 continuation uses 12 resident environments in three waves')
            batch, overlays = 288, MINIBATCH_OVERLAYS
        if concurrent:
            if rollout_envs != concurrent_width or env_pool_probes is None:
                raise ValueError(f'{concurrent_width}-env continuation requires simultaneous workers and matched memory probes')
            batch, overlays = concurrent_width*8, (ENV60_BATCH_OVERLAYS if env60_batch else ENV36_BATCH_OVERLAYS if env36_batch else
                                                  ENV48_OVERLAYS if env48 else ENV24_OVERLAYS)
    else:
        probes = Path(probes).resolve()
        reports = {w: read_json(probes / f'w{w}/result.json') for w in (4, 8, 12)}
        batch, overlays = select_profile(reports, 0.), OVERLAYS
        rollout_envs = batch//8
        if any(r['source_commit_sha256'] != digest_file(commit_path) for r in reports.values()):
            raise ValueError('Probe used a different checkpoint')
    original = parent_path.parent / 'source'
    files = {}
    # Inherit the exact old implementation, never unrelated mutable workspace edits.
    for relative, expected in parent['code']['files'].items():
        src = original / relative
        if digest_file(src) != expected:
            raise ValueError(f'Original source snapshot changed: {relative}')
        dst = output / 'source' / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        files[relative] = expected
    for relative in overlays:
        src, dst = ROOT / relative, output / 'source' / relative
        checksum = digest_file(src)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        if digest_file(dst) != checksum:
            raise ValueError('Workspace changed while making the explicit overlay')
        files[relative] = checksum
    m = copy.deepcopy(parent)
    m.pop('manifest_sha256')
    m.pop('acceleration', None)
    m.update(root=str(output), created_unix=time.time(), training=training_contract(batch),
             code={'files': files, 'sha256': digest_json(files)})
    from onpolicy.utils.stage3_research import WORKSPACE_ROOT
    m['execution'].update(code_root=str(output/'source'), workspace_root=str(WORKSPACE_ROOT))
    for key in ('path', 'manifest'):
        m['source'][key] = str(output / 'source' / Path(parent['source'][key]).relative_to(original))
    m['resources'].update(validator_queue=str(output/'validator'), validator_workers=2,
        validator_lifecycle='one independent pool shared by all eight training ranks',
        capacity_worlds=[8], capacity_comparison='resumed checkpoint; full dense batch on all8 GPUs',
        validator_width=3)
    for name in ('validator_max_workers', 'boost_inference_width'):
        m['resources'].pop(name, None)
    if env60_batch:
        m['resources'].update(memory_high_gib=None, memory_max_gib=None, memory_swap_max_gib=0,
            tasks_max=1024, memory_limit_authorization=ENV60_BATCH_AUTHORIZATION)
    evidence_names = ['baselines.json', 'training_admission.json', 'sampling_admission.json']
    evidence_names += ['verification.json'] if split_backward else ['local_pairing_admission.json']
    evidence = {str(parent_path.parent / f): digest_file(parent_path.parent / f) for f in evidence_names}
    production_peaks = []
    for rank in range(8):
        paths = sorted((parent_path.parent/f'train/full/rank{rank}/updates').glob('group_*.json'))
        production_peaks.extend(read_json(p)['peak_reserved_gib'] for p in paths[-3:])
    t = {'version': ENV60_BATCH_VERSION if env60_batch else ENV36_BATCH_VERSION if env36_batch else ENV48_VERSION if env48 else ENV24_VERSION if env24 else MINIBATCH_VERSION if optimizer_minibatches else MICRO_VERSION if microbatch else VERSION,
         'authorization': ENV60_BATCH_AUTHORIZATION if env60_batch else ENV36_BATCH_AUTHORIZATION if env36_batch else ENV48_AUTHORIZATION if env48 else ENV24_AUTHORIZATION if env24 else MINIBATCH_AUTHORIZATION if optimizer_minibatches else MICRO_AUTHORIZATION if microbatch else AUTHORIZATION,
         'parent_manifest': str(parent_path), 'parent_manifest_sha256': digest_file(parent_path),
         'resume_commit': str(commit_path), 'resume_commit_sha256': digest_file(commit_path),
         'start_episodes': commit['training_episodes'], 'start_actor_updates': commit['actual_actor_updates'],
         'global_batch': batch, 'rollout_envs_per_rank': rollout_envs,
         'backward_trajectories_per_rank': 12 if split_backward else batch//8, 'tbptt_steps': 8,
         'optimizer_update_cadence_changed': not (optimizer_minibatches or concurrent), 'remote_batch_matched': False,
         'parent_evidence': evidence,
         'probe_reports': {str(probes/f'w{w}/result.json'): digest_file(probes/f'w{w}/result.json') for w in reports},
         'prefix_probe_is_not_full_admission': True,
         'parent_production_peak_reserved_gib': max(production_peaks),
         'minimum_full_capacity_peak_reserved_gib': (parent['throughput']['minimum_full_capacity_peak_reserved_gib']
             if split_backward else 2*max(production_peaks)),
         'snapshot_overlay_files': list(overlays)}
    if microbatch:
        t.update(rollout_trajectories_per_rank=24, gradient_accumulation_microbatches=2,
                 optimizer_step_after_microbatches=True,
                 rollout_waves_per_rank=24//rollout_envs,
                 no_optimizer_or_kl_step_between_microbatches=True)
    if optimizer_minibatches or concurrent:
        t.update(rollout_trajectories_per_rank=concurrent_width if concurrent else 36,
            rollout_waves_per_rank=1 if concurrent else 3,
            gradient_accumulation_microbatches=1,
            optimizer_minibatches=concurrent_width//12 if concurrent else 3, optimizer_global_batch=96,
            optimizer_step_after_microbatches=False, optimizer_step_per_microbatch=True,
            no_optimizer_or_kl_step_between_microbatches=False, fresh_rollout_cadence_changed=True,
            whole_rollout_epoch_kl_guard=True, release_environments_after_rollout=True)
    if concurrent:
        t.update(environment_start_method='forkserver', true_concurrent_environments_per_rank=concurrent_width)
        t['probe_reports'] = env24_probe_evidence(env_pool_probes, files, width=concurrent_width)
    if env36_batch or env60_batch:
        from onpolicy.utils.stage3_batched_sampling import BATCHING_VERSION, SAMPLING_VERSION
        t.update(stochastic_batching=BATCHING_VERSION, sampling_rng=SAMPLING_VERSION,
                 sampling_forward_batch=concurrent_width, greedy_inference_unchanged=True,
                 bitwise_legacy_sampling_equivalence=False)
    if env60_batch:
        t.update(host_memory_limit_removed=True, capacity_memory_limit_gib=None,
                 completed_epoch_results_keep_original_protocol=True)
    m['throughput'] = t
    t['schedule_sha256'] = digest_json(continuation_plan(m))
    comparison = comparison_contract(m['splits'], m['baseline_reference'], training=m['training'])
    m['comparison_sha256'] = digest_json(comparison)
    m['input_files'].update({str(parent_path): digest_file(parent_path), str(commit_path): digest_file(commit_path),
                            **evidence, **t['probe_reports']})
    if env60_batch:
        # Previous epochs remain part of the curve/selection, never silently disappear.
        inherited = {}
        for episodes in range(960, commit['training_episodes']+1, 960):
            for kind in ('epochs', 'mechanism'):
                if kind == 'mechanism' and episodes//960 not in MECHANISM['data_epochs']:
                    continue
                owner, path = epoch_owner(parent, episodes, kind=kind)
                record = read_json(path)
                inherited[str(path)] = digest_file(path)
                for request_id in record['requests']:
                    result = queue(owner).poll(request_id)
                    if result is None:
                        raise ValueError('Drain inherited epoch validation before migration')
                    result_path = Path(owner['resources']['validator_queue'])/'results'/f'{request_id}.json'
                    inherited[str(result_path)] = digest_file(result_path)
        t['inherited_epoch_evidence'] = inherited
        m['input_files'].update(inherited)
    m['material_passport'].update(origin_date='2026-09-13', verification_status='capacity admission pending',
                                  version_label=t['version'])
    m['manifest_sha256'] = identity(m)
    parent_manifest(m)
    atomic_json(output/'manifest.json', m, overwrite=False)
    atomic_json(output/'comparison_contract.json', comparison, overwrite=False)
    atomic_json(output/'schedule.json', {'groups': continuation_plan(m)}, overwrite=False)
    atomic_json(output/'baselines.json', {'inherited': True, 'path': str(parent_path.parent/'baselines.json'),
        'sha256': evidence[str(parent_path.parent/'baselines.json')],
        'note': 'No baseline values or historical scores rewritten; read and verify original 780/212 evidence.'}, overwrite=False)
    sampling = read_json(parent_path.parent/'sampling_admission.json')
    atomic_json(output/'sampling_admission.json', {'selected_tau': sampling['selected_tau'],
        'protocol_sha256': m['manifest_sha256'], 'inherited': True,
        'parent_evidence': {'path': str(parent_path.parent/'sampling_admission.json'),
                            'sha256': evidence[str(parent_path.parent/'sampling_admission.json')]}}, overwrite=False)
    atomic_json(output/'migration_receipt.json', {'parent': str(parent_path), 'commit': str(commit_path),
        'committed_episodes_preserved': t['start_episodes'], 'actor_updates_preserved': t['start_actor_updates'],
        'all_optimizer_normalizer_rng_states_required': True, 'no_diagnostic_initialization': True,
        'old_global_batch': parent['training']['global_batch'], 'new_global_batch': batch,
        'rollout_envs_per_rank': rollout_envs, 'rollout_trajectories_per_rank': batch//8,
        'backward_microbatch': t['backward_trajectories_per_rank'],
        'gradient_accumulation_microbatches': t.get('gradient_accumulation_microbatches', 1),
        'optimizer_minibatches': t.get('optimizer_minibatches', 1),
        'optimizer_step_per_microbatch': t.get('optimizer_step_per_microbatch', False),
        'optimizer_update_cadence_changed': t['optimizer_update_cadence_changed'],
        'fresh_rollout_cadence_changed': t.get('fresh_rollout_cadence_changed', True),
        'new_remaining_batches': len(continuation_plan(m)),
        'remaining_visits': 7680-t['start_episodes'], 'visits_seeds_and_epoch_endpoints_preserved': True,
        'tbptt_and_kl_unchanged': True, 'remote_architecture_comparison_is_no_longer_batch_matched': True}, overwrite=False)
    print(output/'manifest.json', flush=True)


def validation_copy(m):
    """Rebind only routing metadata, explicitly preserving original tensor/RNG bytes."""
    import torch
    commit = read_json(m['throughput']['resume_commit'])
    payload = torch.load(commit['ranks'][0]['checkpoint'], map_location='cpu', weights_only=False)
    from onpolicy.utils.stage3_distributed import state_digest
    keys = ('model', 'actor_optim', 'critic_optim', 'role_value_normalizers', 'rng_torch', 'rng_cuda',
            'rng_numpy', 'rng_python', 'policy_updates', 'actor_base_lr')
    before = state_digest({k: payload[k] for k in keys})
    payload.update(parent_protocol_sha256=payload['protocol_sha256'], protocol_sha256=m['manifest_sha256'],
        comparison_sha256=m['comparison_sha256'], execution_code_sha256=m['code']['sha256'],
        validation_only=True, throughput=m['throughput'])
    target = Path(m['root'])/'migration/validation_only.pt'
    if target.exists():
        raise FileExistsError(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix('.tmp.pt')
    torch.save(payload, temporary)
    os.link(temporary, target)
    temporary.unlink()
    actual = torch.load(target, map_location='cpu', weights_only=False)
    if state_digest({k: actual[k] for k in keys}) != before:
        raise ValueError('Validation metadata migration changed training state')
    atomic_json(target.parent/'validation_copy.json', {'checkpoint': str(target),
        'checkpoint_sha256': digest_file(target), 'all_training_state_exact': True,
        'validation_only': True, 'parent_checkpoint_sha256': commit['ranks'][0]['sha256']}, overwrite=False)
    return target


class LargeBatchB0Suite(B0Suite):
    def check_available_native_tune(self):
        # Preserved, strictly paired machine-local evidence is verified by inherited_costs.
        return

    def run_private(self):
        with ProgressHeartbeat(self.root/'status.json', phase='large_batch_full_capacity') as hb:
            try:
                hb.update(formal_training_started=False, parent_episodes=self.m['throughput']['start_episodes'],
                          global_batch_size=self.m['training']['global_batch'])
                parent = reference_manifest(self.m)
                baseline_costs(self.m)
                checkpoint = validation_copy(self.m)
                source_rows = read_json(Path(parent['root'])/'baselines.json')['cases']
                train = {c['path'] for c in self.m['splits']['train_full600']}
                dense = max((r for r in source_rows if r['case_id'] in train),
                            key=lambda r: r['max_graph_tensor_bytes'])['case_id']
                co_load = [submit(self.m, checkpoint, 'C_PRIVATE', self.m['throughput']['start_episodes'],
                    'F_PRIVATE', split='train_full600', start=start, count=6, tag='_large_batch_capacity')
                    for start in (0, 15)]
                self.phase_sampled_peak, self.phase_gpu_peak_gib, self.phase_validator_busy_samples = 0, 0., 0
                capacity = self.group('capacity', 'large_batch_dense', hb, world=8,
                                      batch=self.m['training']['global_batch'], dense=dense)
                self.wait_requests(co_load, hb)
                peak = max(r['peak_reserved_gib'] for r in capacity)
                minimum = self.m['throughput']['minimum_full_capacity_peak_reserved_gib']
                passed = (all(r['passed'] for r in capacity) and minimum <= peak < 22
                          and capacity_memory_pass(self.m, self.phase_sampled_peak/2**30)
                          and self.phase_gpu_peak_gib < 23
                          and self.phase_validator_busy_samples > 0)
                micro = self.m['throughput']['version'] == MICRO_VERSION
                mini = self.m['throughput']['version'] in (MINIBATCH_VERSION, ENV24_VERSION, ENV48_VERSION, ENV36_BATCH_VERSION, ENV60_BATCH_VERSION)
                if micro:
                    passed = passed and all(r['update']['backward_microbatch_size'] == 12
                        and r['update']['backward_microbatches'] == 2
                        and r['update']['rollout_trajectories'] == 24
                        and r['update']['accepted_actor_steps'] == 2 for r in capacity)
                if mini:
                    parts = self.m['throughput']['optimizer_minibatches']
                    passed = passed and all(r['update']['backward_microbatch_size'] == 12
                        and r['update']['backward_microbatches'] == parts
                        and r['update']['rollout_trajectories'] == 12*parts
                        and r['update']['accepted_actor_steps'] == 2*parts
                        and r['update']['optimizer_step_per_microbatch']
                        and r['update']['behavior_data_unchanged']
                        and len(r['update']['ppo_epoch_reports']) == 2
                        and not any(e['epoch_rolled_back'] for e in r['update']['ppo_epoch_reports'])
                        for r in capacity)
                evidence = {str(self.root/f'capacity/large_batch_dense/rank{i}/result.json'):
                            digest_file(self.root/f'capacity/large_batch_dense/rank{i}/result.json') for i in range(8)}
                admission = {'passed': passed, 'protocol_sha256': self.m['manifest_sha256'],
                    'world_size': 8, 'global_batch': self.m['training']['global_batch'],
                    'parent_commit_sha256': self.m['throughput']['resume_commit_sha256'],
                    'sampling_sha256': digest_file(self.root/'sampling_admission.json'),
                    'evidence': evidence, 'peak_reserved_gib': peak,
                    'minimum_peak_reserved_gib': minimum, 'combined_memory_peak_gib': self.phase_sampled_peak/2**30,
                    'whole_gpu_sampled_peak_gib': self.phase_gpu_peak_gib,
                    'validator_busy_samples': self.phase_validator_busy_samples,
                    'full_trajectories_and_two_epoch_ppo': True, 'diagnostic_weights_discarded': True}
                if self.m['throughput']['version'] == ENV60_BATCH_VERSION:
                    admission.update(capacity_memory_limit_gib=None, host_memory_limit_removed=True,
                                     memory_limit_authorization=ENV60_BATCH_AUTHORIZATION)
                if micro:
                    admission.update(rollout_trajectories_per_rank=24,
                        rollout_envs_per_rank=self.m['throughput']['rollout_envs_per_rank'],
                        backward_microbatch=12, gradient_accumulation_microbatches=2,
                        optimizer_step_after_microbatches=True)
                if mini:
                    admission.update(rollout_trajectories_per_rank=12*parts,
                        rollout_envs_per_rank=self.m['throughput']['rollout_envs_per_rank'],
                        backward_microbatch=12, gradient_accumulation_microbatches=1,
                        optimizer_minibatches=parts, optimizer_global_batch=96,
                        optimizer_step_per_microbatch=True, optimizer_step_after_microbatches=False,
                        whole_rollout_epoch_kl_guard=True, release_environments_after_rollout=True)
                    if self.m['throughput']['version'] in (ENV24_VERSION, ENV48_VERSION, ENV36_BATCH_VERSION, ENV60_BATCH_VERSION):
                        width = self.m['throughput']['rollout_envs_per_rank']
                        passed = passed and all(r['rollout_envs_per_rank'] == width
                            and r['live_environment_workers_at_start'] == width
                            and r['environment_start_method'] == 'forkserver'
                            and r['rollout_waves'] == 1 for r in capacity)
                        admission.update(passed=passed, live_environment_workers_per_rank=width,
                            environment_start_method='forkserver', rollout_waves=1)
                    if self.m['throughput']['version'] in (ENV36_BATCH_VERSION, ENV60_BATCH_VERSION):
                        passed = passed and all(r['rollout_inference']['max_forward_batch'] == width
                            and r['rollout_inference']['stochastic_batching'] == self.m['throughput']['stochastic_batching']
                            for r in capacity)
                        admission.update(passed=passed, batched_sampling_verified=True,
                            stochastic_batching=self.m['throughput']['stochastic_batching'])
                atomic_json(self.root/'training_admission.json', admission, overwrite=False)
                if not passed:
                    raise RuntimeError('Large-batch full-capacity requirements not met; no formal continuation')
                hb.update(phase='full_data_training', formal_training_started=True)
                results = self.group('train', 'full', hb, world=8, batch=self.m['training']['global_batch'])
                if any(r.get('paused') for r in results):
                    hb.update(phase='paused_at_commit')
                    return
                hb.update(phase='checkpoint_selection')
                self.finish_training(hb)
                hb.update(phase='training_complete_confirmation_sealed')
            finally:
                self.stop_owned()

    def finish_training(self, hb):
        from onpolicy.utils.stage3_b0_diagnostics import summarize
        from onpolicy.utils.stage3_b0_throughput import epoch_endpoint
        costs, curves, candidates = baseline_costs(self.m), [], []
        for epoch in range(1, 9):
            owner, path = epoch_owner(self.m, epoch_endpoint(self.m, epoch))
            record = read_json(path)
            if owner['manifest_sha256'] == self.m['manifest_sha256']:
                self.wait_requests(record['requests'], hb)
            elif any(queue(owner).poll(r) is None for r in record['requests']):
                raise ValueError('Inherited epoch results must already be drained and immutable')
            values = {}
            for split in ('validation', 'tune'):
                results = [queue(owner).poll(r)['evaluation'] for r in record['requests'] if f'_{split}_' in r]
                values[split] = paired_summary([row for result in results for row in result['cases']], costs)
            row = {'data_epoch': epoch, **record, **values,
                   'checkpoint_owner_protocol_sha256': owner['manifest_sha256'],
                   'epoch_record': str(path), 'training_global_batch': owner['training']['global_batch']}
            curves.append(row)
            if risk_pass(values['validation']) and risk_pass(values['tune']):
                candidates.append(row)
        best = min(candidates, key=lambda r: (r['validation']['makespan'], r['training_episodes'])) if candidates else curves[-1]
        lock = {'protocol_sha256': self.m['manifest_sha256'], 'comparison_sha256': self.m['comparison_sha256'],
            'arm': 'C_PRIVATE', 'checkpoint': best['checkpoint'], 'checkpoint_sha256': best['checkpoint_sha256'],
            'training_episodes': best['training_episodes'], 'risk_qualified': bool(candidates),
            'checkpoint_owner_protocol_sha256': best['checkpoint_owner_protocol_sha256'],
            'rule': 'lowest validation mean among risk-qualified epochs; else Last, unqualified',
            'locked_before_confirmation': True, 'remote_batch_matched': False}
        atomic_json(self.root/'learning_curves.json', curves, overwrite=False)
        atomic_json(self.root/'selection_locked.json', lock, overwrite=False)
        atomic_json(self.root/'model_index.json', {'Best': lock,
            'Last': {k: curves[-1][k] for k in ('checkpoint', 'checkpoint_sha256', 'training_episodes', 'actual_actor_updates')}}, overwrite=False)
        parent = reference_manifest(self.m)
        initial = read_json(Path(parent['root'])/'mechanism/e000000.json')
        initial_results = [queue(parent).poll(r)['evaluation'] for r in initial['requests']]
        initial_rows = [row for result in initial_results for row in result['cases']]
        mechanism = {'0': summarize(initial_results, initial_rows)}
        for epoch in MECHANISM['data_epochs'][1:]:
            owner, path = epoch_owner(self.m, epoch_endpoint(self.m, epoch), kind='mechanism')
            record = read_json(path)
            results = (self.wait_requests(record['requests'], hb) if owner['manifest_sha256'] == self.m['manifest_sha256']
                       else [queue(owner).poll(r)['evaluation'] for r in record['requests']])
            mechanism[str(epoch)] = summarize(results, initial_rows)
        atomic_json(self.root/'mechanism/summary.json', {'epochs': mechanism,
            'epoch0_inherited_from': str(Path(parent['root'])/'mechanism/e000000.json')}, overwrite=False)
        atomic_json(self.root/'result.json', {'training_completed': True,
            'training_episodes': self.m['training']['max_training_episodes'],
            'selected': lock, 'validation_target_met': bool(candidates) and best['validation']['gain_fraction'] >= .02
                and all(r['validation']['gain_fraction'] > 0 for r in curves[-2:]),
            'scientific_target_confirmed': False, 'confirmation_status': 'sealed; new batch-matched comparison requires agreement',
            'optimizer_update_cadence_changed': self.m['throughput']['optimizer_update_cadence_changed'],
            'fresh_rollout_cadence_changed': self.m['throughput'].get('fresh_rollout_cadence_changed', True)}, overwrite=False)


def required_tests_present(required, names):
    """Parameterized passing cases satisfy their base test without inflating counts."""
    return required <= {name.split('[',1)[0] for name in names}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--parent', type=Path)
    p.add_argument('--commit', type=Path)
    p.add_argument('--probes', type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--seal-manifest', type=Path)
    p.add_argument('--test-report', type=Path)
    grouping = p.add_mutually_exclusive_group()
    grouping.add_argument('--microbatch-24-12', action='store_true')
    grouping.add_argument('--minibatch-36-12', action='store_true')
    grouping.add_argument('--env24-minibatch12', action='store_true')
    grouping.add_argument('--env48-minibatch12', action='store_true')
    grouping.add_argument('--env36-batched-minibatch12', action='store_true')
    grouping.add_argument('--env60-batched-minibatch12-uncapped', action='store_true')
    p.add_argument('--env-pool-probes', type=Path)
    p.add_argument('--rollout-envs', type=int, choices=(12, 24, 36, 48, 60), default=12)
    args = p.parse_args()
    if args.seal_manifest:
        import xml.etree.ElementTree as ET
        from onpolicy.utils.stage3_b0_protocol import verify
        m = read_json(args.seal_manifest)
        verify(m)
        tests = list(ET.parse(args.test_report).getroot().iter('testcase'))
        if not tests or any(t.find('failure') is not None or t.find('error') is not None for t in tests):
            raise ValueError('Nonempty passing test evidence required')
        names = {t.attrib['name'] for t in tests if t.find('skipped') is None}
        required = {'test_large_batch_eight_rank_visit_mean',
            'test_large_batch_changes_only_global_batch_and_comparison_identity',
            'test_large_batch_parent_evidence_and_checkpoint_are_immutable',
            'test_large_batch_selection_requires_memory_gain_and_same_checkpoint',
            'test_transaction_rejection_restores_every_state',
            'test_b0_private_exact_initialization_and_ready_frozen',
            'test_real_eight_rank_b0_visit_mean'}
        if m['throughput']['version'] == MICRO_VERSION:
            required |= {'test_microbatch_eight_rank_global192_visit_mean',
                'test_microbatch_two_epoch_optimizer_cadence_and_full_kl',
                'test_microbatch_parent96_checkpoint_lineage_and_no_stale_relabel',
                'test_microbatch_collects24_in_two12_environment_waves',
                'test_microbatch_real_b0_cpu_graph_gradients_match_full24'}
        if m['throughput']['version'] == MINIBATCH_VERSION:
            required |= {'test_minibatches_six_independent_steps_keep_behavior_data',
                'test_minibatches_full_epoch_kl_rejection_restores_every_state',
                'test_minibatches_eight_rank_three_optimizer_batches',
                'test_minibatches_parent96_lineage_and_schedule288',
                'test_minibatches_collect36_releases_and_recreates_environment_pool',
                'test_minibatches_mechanism_reads_original_fixed_b0_archives',
                'test_minibatches_real_b0_cpu_private_six_steps'}
        if m['throughput']['version'] == ENV24_VERSION:
            required |= {'test_env24_collects_in_one_call_and_recreates24',
                'test_env24_two_independent_optimizer_minibatches',
                'test_env24_parent96_lineage_and_schedule192',
                'test_env24_real_workers_spawn_forkserver_prefix_parity',
                'test_env24_real_eight_rank_four_steps',
                'test_minibatches_full_epoch_kl_rejection_restores_every_state',
                'test_minibatches_real_b0_cpu_private_six_steps'}
        if m['throughput']['version'] == ENV48_VERSION:
            required |= {'test_env48_collects_in_one_call_and_recreates48',
                'test_env48_four_independent_optimizer_minibatches',
                'test_env48_parent96_lineage_and_schedule384',
                'test_env48_real_workers_spawn_forkserver_prefix_parity',
                'test_env48_real_eight_rank_eight_steps',
                'test_minibatches_full_epoch_kl_rejection_restores_every_state',
                'test_minibatches_real_b0_cpu_private_six_steps'}
        if m['throughput']['version'] == ENV36_BATCH_VERSION:
            required |= {'test_batch36_rng_independent_of_membership_and_completion',
                'test_batch36_categorical_distribution_and_legal_padding',
                'test_batch36_parent_lineage_schedule_and_contract',
                'test_batch36_real_workers_and_batched_replay',
                'test_batch36_real_policy_heads_and_greedy_unchanged',
                'test_minibatches_eight_rank_three_optimizer_batches',
                'test_minibatches_full_epoch_kl_rejection_restores_every_state'}
        if m['throughput']['version'] == ENV60_BATCH_VERSION:
            required |= {'test_env60_ten_independent_optimizer_steps',
                'test_env60_real_eight_rank_ten_steps', 'test_env60_batched_ragged_rollout',
                'test_env60_parent36_lineage_epoch_schedule_and_memory_contract',
                'test_env60_real_workers_and_batched_replay',
                'test_env60_boundary_arming_never_uses_diagnostic_or_previous_group',
                'test_env60_transition_drains_then_launches_without_discarding_checkpoint',
                'test_env60_old_epoch_owner_and_unlimited_ram_are_explicit',
                'test_batch36_real_policy_heads_and_greedy_unchanged',
                'test_minibatches_full_epoch_kl_rejection_restores_every_state'}
        if not required_tests_present(required, names):
            raise ValueError(f'Missing regression evidence: {required-{name.split("[",1)[0] for name in names}}')
        atomic_json(Path(m['root'])/'verification.json', {'passed': True, 'passed_tests': len(names),
            'code_sha256': m['code']['sha256'], 'manifest_sha256': m['manifest_sha256'],
            'reports': {str(args.test_report.resolve()): digest_file(args.test_report),
                        **m['throughput']['probe_reports']},
            'scope': ('frozen full/microbatch gradient, optimizer, distributed and lineage regressions; full all8-GPU capacity still required'
                if m['throughput']['version'] in (MICRO_VERSION, MINIBATCH_VERSION, ENV24_VERSION, ENV48_VERSION, ENV36_BATCH_VERSION, ENV60_BATCH_VERSION) else
                'frozen regression suite and parent-code GPU prefix probes; full all8-GPU capacity still required')}, overwrite=False)
        print(Path(m['root'])/'verification.json', flush=True)
        return
    if any(value is None for value in (args.parent, args.commit, args.output)) or (args.probes is None and not (args.microbatch_24_12 or args.minibatch_36_12 or args.env24_minibatch12 or args.env48_minibatch12 or args.env36_batched_minibatch12 or args.env60_batched_minibatch12_uncapped)):
        p.error('provide parent/commit/output and probes or an explicit minibatch mode; or seal-manifest/test-report')
    prepare(args.parent, args.commit, args.probes, args.output,
            microbatch=args.microbatch_24_12, rollout_envs=args.rollout_envs,
            optimizer_minibatches=args.minibatch_36_12, env24=args.env24_minibatch12,
            env48=args.env48_minibatch12,
            env36_batch=args.env36_batched_minibatch12,
            env60_batch=args.env60_batched_minibatch12_uncapped,
            env_pool_probes=args.env_pool_probes)


if __name__ == '__main__':
    main()
