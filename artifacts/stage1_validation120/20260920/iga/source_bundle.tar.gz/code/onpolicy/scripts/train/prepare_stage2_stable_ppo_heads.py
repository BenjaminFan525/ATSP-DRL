#!/usr/bin/env python3
"""Prepare the Stage2 stable-PPO x device-head causal screen.

The round has two orthogonal blocks.  M0-M3 start from one immutable T4
post-DeviceBC checkpoint and form a 2x2 factorial over a decaying BC-policy KL
anchor and an IGA-fitted resource potential.  S0-S2 return to the same frozen
Stage1 plane checkpoint and compare shared, zero-initialized type-adapter, and
fully independent ordinary-device heads under an otherwise identical T4 BC
contract.  A rotating 600-slot pool supplies 240 cases per epoch in every arm.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.config.config import get_config  # noqa: E402
from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv  # noqa: E402
from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    atomic_json,
    sha256_file,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.scripts.train.train_hkbz import (  # noqa: E402
    parse_args as parse_training_args,
    select_train_case_dirs,
)


RUN_TAG = 'stage2_stable_ppo_heads_20260828_r1'
METHODS = {
    'M0_stable_control': {
        'bc_kl': False,
        'potential_v2': False,
        'hypothesis': 'stable role-event PPO control',
    },
    'M1_bc_kl': {
        'bc_kl': True,
        'potential_v2': False,
        'hypothesis': 'post-DeviceBC KL anchor prevents early policy drift',
    },
    'M2_potential_v2': {
        'bc_kl': False,
        'potential_v2': True,
        'hypothesis': 'IGA-fitted resource potential improves credit density',
    },
    'M3_bc_kl_potential_v2': {
        'bc_kl': True,
        'potential_v2': True,
        'hypothesis': 'KL stability and dense credit are complementary',
    },
}
STRUCTURES = {
    'S0_shared': {
        'head_mode': 'shared',
        'hypothesis': 'T4 BC control with the rotating data pool',
    },
    'S1_type_adapter': {
        'head_mode': 'type_adapter',
        'hypothesis': 'small type residual resolves ordinary-device aliasing',
    },
    'S2_per_type': {
        'head_mode': 'per_type',
        'hypothesis': 'fully independent ordinary-device recurrent heads',
    },
}


def load_json(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError(f'Expected a JSON object: {path}')
    return payload


def option_value(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def code_contract() -> dict:
    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
    ).strip()
    status = subprocess.check_output(
        ['git', 'status', '--short'], cwd=ROOT, text=True
    ).splitlines()
    paths = (
        'onpolicy/config/config.py',
        'onpolicy/envs/HKBZ/environment.py',
        'onpolicy/envs/HKBZ/experiment/fit_stage2_resource_potential_v2.py',
        'onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py',
        'onpolicy/algorithms/gnn_mappo/algorithm/MAPPOPolicy.py',
        'onpolicy/algorithms/gnn_mappo/gnn_mappo.py',
        'onpolicy/runner/shared/hkbz_runner.py',
        'onpolicy/scripts/train/shared_hkbz_evaluator.py',
        'onpolicy/utils/shared_eval.py',
        'onpolicy/scripts/train/prepare_stage2_stable_ppo_heads.py',
        'onpolicy/scripts/train/launch_stage2_stable_ppo_heads_dual_gpu.sh',
    )
    return {
        'git_revision': revision,
        'working_tree_dirty': bool(status),
        'working_tree_status': status,
        'files_sha256': {
            path: sha256_file(ROOT / path)
            for path in paths if (ROOT / path).is_file()
        },
    }


def coverage_contract(dataset_dir: Path) -> dict:
    cases = sorted(str(path) for path in dataset_dir.glob('case_*'))
    selected, audit = select_train_case_dirs(
        cases,
        mode='distribution_balanced',
        weights_spec='iid=0.50,ood_stress=0.45,ood_scale=0.05',
        seed=1,
        max_cases=0,
        sample_size=600,
    )
    if len(selected) != 600:
        raise RuntimeError('Rotating Stage2 pool must contain 600 slots.')
    return {
        **audit,
        'pool_size': 600,
        'cases_per_epoch': 240,
        'shards_per_epoch': 8,
        'epochs': 4,
        'pool_order_sha256': hashlib.sha256(
            '\n'.join(Path(path).name for path in selected).encode('utf-8')
        ).hexdigest(),
    }


def apply_common(command: list[str], *, python: Path, experiment: str) -> None:
    command[0] = str(python)
    set_option(command, '--experiment_name', experiment)
    set_option(command, '--seed', 1)
    set_option(command, '--cuda_memory_fraction', 0.30)
    set_option(command, '--num_episodes', 4)
    set_option(command, '--gnn_freeze_epochs', 4)
    set_option(command, '--plane_freeze_epochs', 4)
    set_option(command, '--n_rollout_threads', 30)
    set_option(command, '--n_eval_rollout_threads', 12)
    set_option(command, '--max_train_cases', 0)
    set_option(command, '--train_sampling_size', 240)
    set_option(command, '--train_sampling_pool_size', 600)
    set_option(command, '--max_eval_cases', 60)
    set_option(command, '--ppo_epoch', 1)
    set_option(command, '--mini_batch_size', 30)
    set_option(command, '--data_chunk_length', 50)
    set_option(command, '--max_graphs_per_forward', 1500)
    set_option(command, '--grad_accumulation_steps', 3)
    set_option(command, '--actor_grad_accumulation_steps', 2)
    set_option(command, '--grad_accumulation_target_graphs', 5000)
    set_option(command, '--actor_grad_accumulation_target_graphs', 2000)
    set_option(command, '--actor_warmup_shards', 0)
    set_option(command, '--adaptive_actor_lr_max_scale', 1.0)
    set_option(command, '--target_kl', 0.003)
    set_option(command, '--plane_target_kl', 0.003)
    set_option(command, '--device_target_kl', 0.003)
    set_option(command, '--transporter_target_kl', 0.003)
    set_option(command, '--plane_loss_coef', 0.0)
    set_option(command, '--device_loss_coef', 0.5)
    set_option(command, '--transporter_loss_coef', 0.5)
    set_option(command, '--ordinary_device_type_count', 10)
    set_option(command, '--hindsight_cmax_coef', 0.0)
    set_option(command, '--hindsight_shaping_coef', 0.0)
    set_option(command, '--hindsight_terminal_cmax_coef', 1.0)
    set_option(command, '--iga_potential_gamma', 1.0)
    set_option(command, '--resource_lateness_coef', 0.0)
    set_option(command, '--resource_critical_lateness_coef', 0.0)
    set_option(command, '--resource_earliness_coef', 0.0)
    set_option(command, '--resource_wait_constraint_target', 0.0)
    set_option(command, '--resource_wait_dual_lr', 0.0)
    set_option(command, '--early_stop_patience', 0)
    set_option(command, '--recovery_checkpoint_interval_shards', 1)
    set_switch(command, '--use_eval', True)
    set_switch(command, '--rollout_until_done', True)
    set_switch(command, '--safe_graph_batch_pipeline', True)
    set_switch(command, '--safe_dagger_teacher_overlap', True)
    set_switch(command, '--clear_cuda_cache_after_update', False)


def method_command(
    base: list[str], method_id: str, method: dict, *, args
) -> list[str]:
    command = list(base)
    apply_common(
        command,
        python=args.python,
        experiment=f'{args.run_tag}_wave1_{method_id}_seed1',
    )
    set_option(command, '--device_policy_head_mode', 'shared')
    set_option(command, '--device_bc_pretrain_epochs', 0)
    set_switch(command, '--device_bc_only', False)
    set_switch(command, '--joint_team_ppo', True)
    set_option(command, '--joint_team_ppo_scope', 'all')
    set_switch(command, '--role_atomic_ppo', True)
    set_switch(command, '--role_event_returns', True)
    set_switch(command, '--role_valuenorm', True)
    set_switch(command, '--counterfactual_q_baseline', False)
    set_switch(command, '--role_sequential_ppo', False)
    set_option(command, '--role_loss_weighting', 'fixed')

    if method['bc_kl']:
        set_option(command, '--bc_reference_kl_coef', 0.4)
        set_option(
            command, '--bc_reference_kl_coef_schedule', '0.40,0.25,0.10,0.05'
        )
        set_option(command, '--bc_reference_target_kl', 0.02)
        set_switch(command, '--bc_reference_hard_gate', True)
    else:
        set_option(command, '--bc_reference_kl_coef', 0.0)
        set_option(command, '--bc_reference_kl_coef_schedule', '0.0')
        set_option(command, '--bc_reference_target_kl', 0.0)
        set_switch(command, '--bc_reference_hard_gate', False)

    if method['potential_v2']:
        set_option(
            command, '--hindsight_reward_mode',
            'team_time_resource_fitted_potential',
        )
        set_option(command, '--iga_potential_weights_path', args.potential)
        set_option(command, '--iga_potential_beta', 0.10)
        set_option(command, '--iga_potential_beta_schedule', '0.10')
    else:
        set_option(command, '--hindsight_reward_mode', 'team_time')
        set_option(command, '--iga_potential_beta', 0.0)
        set_option(command, '--iga_potential_beta_schedule', '0.0')
        remove_option(command, '--iga_potential_weights_path')
    return command


def structure_command(
    base: list[str], structure_id: str, structure: dict, *, args
) -> list[str]:
    command = list(base)
    apply_common(
        command,
        python=args.python,
        experiment=f'{args.run_tag}_wave1_{structure_id}_seed1',
    )
    set_option(command, '--device_policy_head_mode', structure['head_mode'])
    set_option(command, '--device_bc_pretrain_epochs', 4)
    set_option(command, '--device_bc_min_labels_per_epoch', 64)
    set_option(command, '--device_bc_min_rollouts_per_epoch', 8)
    set_option(command, '--device_bc_max_rollouts_per_epoch', 8)
    set_option(command, '--device_bc_dagger_schedule', '1.0,0.7,0.4,0.1')
    set_option(command, '--device_bc_teacher', 'iga')
    set_option(command, '--device_bc_min_teacher_score_margin', -1.0)
    set_switch(command, '--device_bc_role_balanced', True)
    set_switch(command, '--device_bc_timing_balanced', True)
    set_switch(command, '--device_bc_only', True)
    set_switch(command, '--joint_team_ppo', False)
    set_switch(command, '--role_atomic_ppo', False)
    set_switch(command, '--role_event_returns', False)
    set_switch(command, '--role_valuenorm', False)
    set_switch(command, '--counterfactual_q_baseline', False)
    set_switch(command, '--role_sequential_ppo', False)
    set_option(command, '--hindsight_reward_mode', 'team_time')
    set_option(command, '--iga_potential_beta', 0.0)
    set_option(command, '--iga_potential_beta_schedule', '0.0')
    set_option(command, '--bc_reference_kl_coef', 0.0)
    set_option(command, '--bc_reference_kl_coef_schedule', '0.0')
    set_option(command, '--bc_reference_target_kl', 0.0)
    set_switch(command, '--bc_reference_hard_gate', False)
    remove_option(command, '--iga_potential_weights_path')
    remove_option(command, '--resource_bc_checkpoint')
    return command


def canary_command(command: list[str], key: str) -> list[str]:
    result = list(command)
    experiment = option_value(result, '--experiment_name')
    set_option(result, '--experiment_name', f'{experiment}_canary')
    set_option(result, '--num_episodes', 1)
    set_option(result, '--gnn_freeze_epochs', 1)
    set_option(result, '--plane_freeze_epochs', 1)
    set_option(result, '--max_train_cases', 30)
    set_option(result, '--train_sampling_size', 30)
    remove_option(result, '--train_sampling_pool_size')
    set_option(result, '--max_eval_cases', 12)
    set_option(result, '--device_bc_pretrain_epochs', 1 if key.startswith('S') else 0)
    set_option(result, '--device_bc_min_rollouts_per_epoch', 1)
    set_option(result, '--device_bc_max_rollouts_per_epoch', 1)
    set_option(result, '--device_bc_dagger_schedule', '1.0')
    set_option(result, '--recovery_checkpoint_interval_shards', 1)
    if key.startswith('M'):
        set_switch(result, '--skip_pre_ppo_eval', True)
        set_switch(result, '--skip_epoch_eval', True)
    return result


def validate_command(command: list[str], *, key: str, canary: bool) -> None:
    parsed = parse_training_args(command[2:], get_config())
    expected_cases = 30 if canary else 240
    if int(parsed.train_sampling_size) != expected_cases:
        raise RuntimeError(f'{key}: wrong epoch case budget.')
    if int(parsed.max_graphs_per_forward) != 1500:
        raise RuntimeError(f'{key}: graph cap drifted.')
    if not canary and int(parsed.train_sampling_pool_size) != 600:
        raise RuntimeError(f'{key}: rotating pool is not active.')
    if parsed.training_stage != 'resource_joint':
        raise RuntimeError(f'{key}: wrong training stage.')
    if int(parsed.ordinary_device_type_count) != 10:
        raise RuntimeError(f'{key}: wrong device vocabulary size.')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', default=RUN_TAG)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--old-ppo-manifest', type=Path, required=True)
    parser.add_argument('--old-bc-manifest', type=Path, required=True)
    parser.add_argument('--selection', type=Path, required=True)
    parser.add_argument('--potential', type=Path, required=True)
    parser.add_argument('--dataset-dir', type=Path, required=True)
    parser.add_argument('--python', type=Path, required=True)
    parser.add_argument('--wave-output', type=Path, required=True)
    parser.add_argument('--canary-output', type=Path, required=True)
    args = parser.parse_args()
    args.suite_dir = args.suite_dir.resolve()
    args.python = args.python.resolve()
    args.potential = args.potential.resolve()
    for path in (
        args.old_ppo_manifest, args.old_bc_manifest, args.selection,
        args.potential, args.dataset_dir, args.python,
    ):
        if not path.resolve().exists():
            raise FileNotFoundError(path.resolve())

    selection = load_json(args.selection.resolve())
    selected_checkpoint = Path(selection['selected_checkpoint']).resolve()
    if (
        not selected_checkpoint.is_file()
        or sha256_file(selected_checkpoint)
        != selection['selected_checkpoint_sha256']
    ):
        raise RuntimeError('Selected T4 DeviceBC checkpoint digest changed.')
    potential = load_json(args.potential)
    if potential.get('status') != 'calibrated':
        raise RuntimeError('Resource Potential V2 is not calibrated.')
    if (
        potential.get('potential_schema_version')
        != AircraftScheduleEnv.RESOURCE_POTENTIAL_SCHEMA_VERSION
        or potential.get('environment_semantics_version')
        != AircraftScheduleEnv.SEMANTICS_VERSION
        or potential.get('feature_names')
        != list(AircraftScheduleEnv.RESOURCE_POTENTIAL_FEATURES)
    ):
        raise RuntimeError('Resource Potential V2 contract mismatch.')
    heldout_r2 = float(
        potential['calibration']['heldout_metrics']['r2']
    )
    if heldout_r2 < 0.75:
        raise RuntimeError(f'Resource Potential V2 heldout R2={heldout_r2}.')

    old_ppo = load_json(args.old_ppo_manifest.resolve())
    old_bc = load_json(args.old_bc_manifest.resolve())
    ppo_base = list(old_ppo['commands']['P0_legacy']['argv'])
    bc_base = list(old_bc['commands']['T4_iga_role_timing']['argv'])
    commands: dict[str, dict] = {}
    for key, method in METHODS.items():
        command = method_command(ppo_base, key, method, args=args)
        validate_command(command, key=key, canary=False)
        commands[key] = {
            **method, 'family': 'training_method', 'argv': command,
            'shell': shlex.join(command),
        }
    for key, structure in STRUCTURES.items():
        command = structure_command(bc_base, key, structure, args=args)
        validate_command(command, key=key, canary=False)
        commands[key] = {
            **structure, 'family': 'device_head', 'argv': command,
            'shell': shlex.join(command),
        }

    shared = {
        'schema_version': 1,
        'research_stage': 'stage2_resource_joint',
        'profile': 'stable_ppo_x_device_heads',
        'run_tag': args.run_tag,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'code_contract': code_contract(),
        'data_contract': coverage_contract(args.dataset_dir.resolve()),
        'source_selection': {
            'path': str(args.selection.resolve()),
            'sha256': sha256_file(args.selection.resolve()),
            'selected_method': selection['selected_method'],
            'checkpoint': str(selected_checkpoint),
            'checkpoint_sha256': sha256_file(selected_checkpoint),
        },
        'resource_potential_v2': {
            'path': str(args.potential),
            'sha256': sha256_file(args.potential),
            'heldout_r2': heldout_r2,
        },
        'hardware_contract': {
            'gpus': [0, 1],
            'simultaneous_trainers_per_gpu': 3,
            'shared_evaluators_per_gpu': 1,
            'physical_core_isolation': True,
            'max_graphs_per_forward': 1500,
        },
    }
    wave = {
        **shared,
        'phase': 'wave1',
        'methods': {**METHODS, **STRUCTURES},
        'evaluator_command': commands['M0_stable_control']['argv'],
        'evaluator_source_method': 'M0_stable_control',
        'commands': commands,
    }
    canary_keys = (
        'M3_bc_kl_potential_v2', 'S1_type_adapter', 'S2_per_type'
    )
    canary_entries = {}
    for source_key in canary_keys:
        key = f'C_{source_key}'
        command = canary_command(commands[source_key]['argv'], source_key)
        validate_command(command, key=key, canary=True)
        canary_entries[key] = {
            'source_method': source_key,
            'argv': command,
            'shell': shlex.join(command),
        }
    canary = {
        **shared,
        'phase': 'memory_functional_canary',
        'methods': canary_entries,
        'evaluator_command': canary_entries[
            'C_M3_bc_kl_potential_v2'
        ]['argv'],
        'evaluator_source_method': 'C_M3_bc_kl_potential_v2',
        'commands': canary_entries,
    }
    atomic_json(args.wave_output.resolve(), wave)
    atomic_json(args.canary_output.resolve(), canary)
    print(json.dumps({
        'status': 'prepared',
        'wave_manifest': str(args.wave_output.resolve()),
        'canary_manifest': str(args.canary_output.resolve()),
        'wave_methods': list(commands),
        'potential_heldout_r2': heldout_r2,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
