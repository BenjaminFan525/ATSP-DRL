#!/usr/bin/env python3
"""Continue the Stage2 event-credit study after the Wave-A screen.

The controller is deliberately independent from the Wave-A launcher.  It can
be attached to a running suite without restarting any trainer.  Once Wave A
finishes it applies the preregistered health/performance gates, runs a fresh
four-epoch confirmation for the best two methods on gate[0:60], and then runs
the winning method for seeds 1/2/3 for eight epochs on gate[60:120].  The
sealed finalblind60 split is evaluated only when the multi-seed Formal gate
passes.

No method is promoted merely because it ranks first: a phase with no eligible
candidate stops cleanly and records the reasons in ``autopilot/state.json``.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import numpy as np
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from typing import Any, Mapping, Sequence


ROOT = Path(
    os.environ.get("HKBZ_ROOT", Path(__file__).resolve().parents[3])
).resolve()
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.utils.shared_eval import SharedEvalClient  # noqa: E402


ACTIVE_STATES = {"active", "activating", "reloading", "deactivating"}
DEFAULT_RESULTS_ROOT = ROOT / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo"
DEFAULT_MATCHED_IGA = (
    ROOT
    / "result/hkbz_train_logs/stage2_matched_iga_tune60_20260827_r1"
    / "analysis/matched_iga_comparison.json"
)
DEFAULT_EVAL_ROOT = (
    ROOT
    / "onpolicy/envs/HKBZ/dataset"
    / "fjsp_v3_resource_joint_eval_s20260811/joint"
)


@dataclass(frozen=True)
class Trial:
    key: str
    gpu: int
    cpu_set: str
    delay_seconds: float = 0.0


WAVE_B_LAYOUT = (
    (0, "0-9,72-81"),
    (0, "10-19,82-91"),
    (0, "20-29,92-101"),
    (1, "36-45,108-117"),
    (1, "46-55,118-127"),
    (1, "56-65,128-137"),
)
FORMAL_LAYOUT = (
    (0, "0-14,72-86"),
    (1, "36-65,108-137"),
    (0, "15-29,87-101"),
)
TRAIN_EVAL_CPUS = {
    0: "30-35,102-107",
    1: "66-71,138-143",
}
BLIND_EVAL_CPUS = {
    0: "0-35,72-107",
    1: "36-71,108-143",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    try:
        temporary.write_text(value, encoding="utf-8")
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    _atomic_text(
        path,
        json.dumps(
            dict(payload), ensure_ascii=False, indent=2, sort_keys=True,
            allow_nan=False,
        ) + "\n",
    )


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return payload


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _finite(mapping: Mapping[str, Any], key: str) -> float:
    try:
        value = float(mapping[key])
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError(f"Missing numeric field {key!r}.") from error
    if not math.isfinite(value):
        raise ValueError(f"Non-finite field {key}={value!r}.")
    return value


def _flag_value(command: Sequence[str], flag: str) -> str:
    positions = [index for index, value in enumerate(command) if value == flag]
    if len(positions) != 1 or positions[0] + 1 >= len(command):
        raise ValueError(f"Expected exactly one valued option {flag}.")
    value = str(command[positions[0] + 1])
    if value.startswith("--"):
        raise ValueError(f"Missing value for {flag}.")
    return value


def _case_signature(payload: Mapping[str, Any]) -> tuple[tuple[str, str], ...]:
    cases = payload.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("Evaluation contains no per-case records.")
    signature = []
    for record in cases:
        if not isinstance(record, Mapping):
            raise ValueError("Invalid evaluation case record.")
        key = str(record.get("case_key", ""))
        digest = str(record.get("case_sha256", ""))
        if not key or not digest:
            raise ValueError("Evaluation case lacks key/content digest.")
        signature.append((key, digest))
    if len(signature) != len(set(signature)):
        raise ValueError("Evaluation contains duplicate cases.")
    return tuple(sorted(signature))


def _evaluation(path: Path, expected_cases: int = 60) -> dict[str, Any]:
    payload = _load_json(path)
    summary = payload.get("summary")
    if not isinstance(summary, Mapping):
        raise ValueError(f"Evaluation summary missing: {path}")
    count = int(_finite(summary, "eval_case_count"))
    if count != expected_cases:
        raise ValueError(
            f"Expected Valid{expected_cases}, observed {count}: {path}"
        )
    cases = payload.get("cases", [])
    paired_deltas = []
    late_dispatch_rates = []
    for record in cases:
        if not isinstance(record, Mapping):
            continue
        try:
            delta = float(record["delta_vs_pre_ppo"])
        except (KeyError, TypeError, ValueError):
            pass
        else:
            if math.isfinite(delta):
                paired_deltas.append(delta)
        try:
            late_rate = float(record["resource_late_dispatch_rate"])
        except (KeyError, TypeError, ValueError):
            pass
        else:
            if math.isfinite(late_rate):
                late_dispatch_rates.append(late_rate)
    paired_ci_low = None
    paired_ci_high = None
    paired_mean = None
    catastrophic_count = None
    if len(paired_deltas) == count:
        values = np.asarray(paired_deltas, dtype=np.float64)
        paired_mean = float(values.mean())
        catastrophic_count = int(np.count_nonzero(values > 500.0))
        rng = np.random.default_rng(20260829)
        bootstrap = np.empty(5000, dtype=np.float64)
        for start in range(0, bootstrap.size, 500):
            stop = min(start + 500, bootstrap.size)
            indices = rng.integers(0, count, size=(stop - start, count))
            bootstrap[start:stop] = values[indices].mean(axis=1)
        paired_ci_low, paired_ci_high = (
            float(value) for value in np.quantile(bootstrap, (0.025, 0.975))
        )
    return {
        "path": str(path.resolve()),
        "selection_score": _finite(summary, "eval_selection_score"),
        "raw_makespan": _finite(summary, "eval_raw_makespan"),
        "iid_makespan": _finite(summary, "eval_iid_makespan"),
        "ood_stress_makespan": _finite(
            summary, "eval_distribution_ood_stress_makespan"
        ),
        "ood_scale_makespan": _finite(
            summary, "eval_distribution_ood_scale_makespan"
        ),
        "tail_makespan": _finite(summary, "eval_tail_makespan"),
        "completion_rate": _finite(summary, "eval_completion_rate"),
        "cycle_count": int(_finite(summary, "eval_cycle_count")),
        "timeout_count": int(_finite(summary, "eval_timeout_count")),
        "paired_delta_mean": paired_mean,
        "paired_delta_ci95_low": paired_ci_low,
        "paired_delta_ci95_high": paired_ci_high,
        "catastrophic_regression_count_500": catastrophic_count,
        "late_dispatch_rate_mean": (
            float(np.mean(late_dispatch_rates))
            if len(late_dispatch_rates) == count else None
        ),
        "case_signature": _case_signature(payload),
    }


def _run_dir(results_root: Path, command: Sequence[str]) -> Path:
    experiment = _flag_value(command, "--experiment_name")
    experiment_dir = results_root / experiment
    runs = sorted(
        (path for path in experiment_dir.glob("run*") if path.is_dir()),
        key=lambda path: int(path.name[3:]) if path.name[3:].isdigit() else -1,
    )
    if len(runs) != 1:
        raise ValueError(
            f"Expected one unambiguous run for {experiment}, found {runs}."
        )
    return runs[0]


def _health_reasons(status: Mapping[str, Any], gate: Mapping[str, Any]) -> list[str]:
    reasons: list[str] = []
    if status.get("status") != "completed":
        reasons.append("status_not_completed")
    if status.get("training_stage") != "resource_joint":
        reasons.append("wrong_training_stage")
    if status.get("phase") != "resource_joint_completed":
        reasons.append("phase_not_completed")
    if status.get("canary_rejected") is not False:
        reasons.append("canary_rejected")
    health = status.get("actor_update_health")
    if not isinstance(health, Mapping):
        health = {}
    completion = float(health.get(
        "step_completion_rate", status.get("actor_step_completion_rate", 0.0)
    ))
    if completion < float(gate["actor_step_completion_min"]):
        reasons.append("actor_step_completion_below_gate")
    if int(health.get("zero_update_shards", -1)) != 0:
        reasons.append("zero_update_shards")
    return reasons


def _method_record(
    method: str,
    command: Sequence[str],
    results_root: Path,
    gate: Mapping[str, Any],
    *,
    iga1800_raw: float | None,
) -> dict[str, Any]:
    expected_epochs = int(_flag_value(command, "--num_episodes"))
    run_dir = _run_dir(results_root, command)
    reasons: list[str] = []
    try:
        status = _load_json(run_dir / "run_status.json")
        reasons.extend(_health_reasons(status, gate))
    except (FileNotFoundError, ValueError, json.JSONDecodeError) as error:
        status = {}
        reasons.append(f"invalid_run_status:{type(error).__name__}")

    pre: dict[str, Any] | None = None
    try:
        pre = _evaluation(run_dir / "evaluations/pre_ppo.json")
    except (FileNotFoundError, ValueError, json.JSONDecodeError) as error:
        reasons.append(f"invalid_pre_ppo:{type(error).__name__}")
    epochs: list[dict[str, Any]] = []
    for epoch in range(1, expected_epochs + 1):
        try:
            record = _evaluation(run_dir / f"evaluations/epoch_{epoch}.json")
        except (FileNotFoundError, ValueError, json.JSONDecodeError) as error:
            reasons.append(f"invalid_epoch_{epoch}:{type(error).__name__}")
        else:
            record["epoch"] = epoch
            epochs.append(record)

    signatures = set()
    if pre is not None:
        signatures.add(pre["case_signature"])
    signatures.update(record["case_signature"] for record in epochs)
    if len(signatures) != 1:
        reasons.append("within_method_validation_case_mismatch")

    best = min(
        epochs,
        key=lambda record: (
            record["selection_score"], record["raw_makespan"], record["epoch"]
        ),
        default=None,
    )
    raw_improvement = None
    iga_gap = None
    ood_regression = None
    tail_regression = None
    if pre is not None and best is not None:
        raw_improvement = pre["raw_makespan"] - best["raw_makespan"]
        ood_regression = (
            best["ood_stress_makespan"] - pre["ood_stress_makespan"]
        )
        tail_regression = best["tail_makespan"] - pre["tail_makespan"]
        if raw_improvement < float(gate["raw_cmax_improvement_seconds"]):
            reasons.append("raw_cmax_improvement_below_gate")
        if ood_regression > float(gate["ood_stress_regression_seconds_max"]):
            reasons.append("ood_stress_regression_above_gate")
        if (
            "tail_regression_seconds_max" in gate
            and tail_regression > float(gate["tail_regression_seconds_max"])
        ):
            reasons.append("tail_regression_above_gate")
        if "paired_ci95_upper_seconds_max" in gate:
            ci_high = best.get("paired_delta_ci95_high")
            if ci_high is None:
                reasons.append("paired_bootstrap_unavailable")
            elif ci_high > float(gate["paired_ci95_upper_seconds_max"]):
                reasons.append("paired_bootstrap_not_improving")
        if "catastrophic_regression_count_500_max" in gate:
            count_500 = best.get("catastrophic_regression_count_500")
            if count_500 is None:
                reasons.append("catastrophic_count_unavailable")
            elif count_500 > int(gate[
                "catastrophic_regression_count_500_max"
            ]):
                reasons.append("catastrophic_regression_count_above_gate")
        if iga1800_raw is not None:
            iga_gap = best["raw_makespan"] - float(iga1800_raw)
            if iga_gap > float(gate["matched_iga1800_gap_seconds_max"]):
                reasons.append("matched_iga1800_gap_above_gate")
        if best["completion_rate"] < float(gate["completion_rate_min"]):
            reasons.append("incomplete_validation")
        if best["cycle_count"] > int(gate["cycle_count_max"]):
            reasons.append("validation_cycle")
        if best["timeout_count"] != 0:
            reasons.append("validation_timeout")

    checkpoint = run_dir / "models/checkpoint_Best.pt"
    if not checkpoint.is_file():
        reasons.append("missing_best_checkpoint")
    health = status.get("actor_update_health", {})
    if not isinstance(health, Mapping):
        health = {}
    return {
        "method": method,
        "experiment_name": _flag_value(command, "--experiment_name"),
        "run_dir": str(run_dir.resolve()),
        "eligible": not reasons,
        "gate_reasons": reasons,
        "pre_ppo": _without_signature(pre),
        "epochs": [_without_signature(record) for record in epochs],
        "best_epoch": best["epoch"] if best is not None else None,
        "best_selection_score": (
            best["selection_score"] if best is not None else None
        ),
        "best_raw_makespan": best["raw_makespan"] if best is not None else None,
        "mean_selection_score": (
            sum(record["selection_score"] for record in epochs) / len(epochs)
            if epochs else None
        ),
        "raw_cmax_improvement_seconds": raw_improvement,
        "matched_iga1800_gap_seconds": iga_gap,
        "ood_stress_regression_seconds": ood_regression,
        "tail_regression_seconds": tail_regression,
        "paired_delta_ci95_high": (
            best.get("paired_delta_ci95_high") if best is not None else None
        ),
        "catastrophic_regression_count_500": (
            best.get("catastrophic_regression_count_500")
            if best is not None else None
        ),
        "late_dispatch_rate_mean": (
            best.get("late_dispatch_rate_mean") if best is not None else None
        ),
        "actor_step_completion_rate": float(health.get(
            "step_completion_rate", status.get("actor_step_completion_rate", 0.0)
        )),
        "zero_update_shards": int(health.get("zero_update_shards", -1)),
        "checkpoint": str(checkpoint.resolve()),
        "checkpoint_sha256": _sha256(checkpoint) if checkpoint.is_file() else None,
        "case_signature": next(iter(signatures)) if len(signatures) == 1 else None,
    }


def _without_signature(record: Mapping[str, Any] | None) -> dict[str, Any]:
    if record is None:
        return {}
    return {key: value for key, value in record.items() if key != "case_signature"}


def _ranking_key(record: Mapping[str, Any]) -> tuple[Any, ...]:
    return (
        float(record["best_selection_score"]),
        float(record["mean_selection_score"]),
        float(record["best_raw_makespan"]),
        str(record["method"]),
    )


def analyze_phase(
    manifest_path: Path,
    results_root: Path,
    output: Path,
    *,
    iga1800_raw: float | None,
) -> dict[str, Any]:
    manifest = _load_json(manifest_path)
    commands = manifest.get("commands")
    gate = manifest.get("screen_gate")
    if not isinstance(commands, Mapping) or not commands:
        raise ValueError(f"Manifest has no commands: {manifest_path}")
    if not isinstance(gate, Mapping):
        raise ValueError(f"Manifest has no screen gate: {manifest_path}")
    records = [
        _method_record(
            str(key), list(value["argv"]), results_root, gate,
            iga1800_raw=iga1800_raw,
        )
        for key, value in commands.items()
    ]
    signatures = {
        record["case_signature"] for record in records
        if record["case_signature"] is not None
    }
    if len(signatures) > 1:
        raise ValueError("Methods were not evaluated on identical cases.")
    ranking = sorted(
        (record for record in records if record["eligible"]),
        key=_ranking_key,
    )
    payload = {
        "schema_version": 1,
        "created_at": _now(),
        "phase": str(manifest.get("phase", "")),
        "manifest": str(manifest_path.resolve()),
        "matched_iga1800_raw_makespan": iga1800_raw,
        "screen_gate": dict(gate),
        "methods": [
            {key: value for key, value in record.items() if key != "case_signature"}
            for record in records
        ],
        "ranking": [record["method"] for record in ranking],
        "eligible_methods": [record["method"] for record in ranking],
        "selected_method": ranking[0]["method"] if ranking else None,
        "valid60_case_signature_sha256": (
            hashlib.sha256(json.dumps(
                list(next(iter(signatures))), separators=(",", ":")
            ).encode("utf-8")).hexdigest()
            if len(signatures) == 1 else None
        ),
    }
    _atomic_json(output, payload)
    _atomic_text(output.with_suffix(".md"), _phase_markdown(payload))
    return payload


def _phase_markdown(payload: Mapping[str, Any]) -> str:
    lines = [
        f"# Stage2 {payload['phase']} 自动晋级报告",
        "",
        "| 排名 | 方法 | 晋级 | 最佳 Epoch | Selection | Raw Cmax | Raw 改善 | IGA-1800 差距 | OOD-stress 退化 | Tail 退化 | 配对 CI 上界 | >500s | 更新完成率 | 原因 |",
        "|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    ranks = {method: index + 1 for index, method in enumerate(payload["ranking"])}
    for record in payload["methods"]:
        def number(key: str) -> str:
            value = record.get(key)
            return "—" if value is None else f"{float(value):.3f}"
        lines.append(
            f"| {ranks.get(record['method'], '—')} | {record['method']} | "
            f"{'是' if record['eligible'] else '否'} | "
            f"{record.get('best_epoch') or '—'} | "
            f"{number('best_selection_score')} | {number('best_raw_makespan')} | "
            f"{number('raw_cmax_improvement_seconds')} | "
            f"{number('matched_iga1800_gap_seconds')} | "
            f"{number('ood_stress_regression_seconds')} | "
            f"{number('tail_regression_seconds')} | "
            f"{number('paired_delta_ci95_high')} | "
            f"{record.get('catastrophic_regression_count_500', '—')} | "
            f"{record['actor_step_completion_rate']:.1%} | "
            f"{', '.join(record['gate_reasons']) or '—'} |"
        )
    lines.extend(("", f"选择结果：**{payload['selected_method'] or '无候选'}**。", ""))
    return "\n".join(lines)


def _clone_command(
    source: Sequence[str], *, experiment: str, epochs: int, seed: int,
    eval_offset: int,
) -> list[str]:
    command = list(source)
    set_option(command, "--experiment_name", experiment)
    set_option(command, "--num_episodes", epochs)
    set_option(command, "--gnn_freeze_epochs", epochs)
    set_option(command, "--plane_freeze_epochs", epochs)
    set_option(command, "--seed", seed)
    set_option(command, "--eval_case_offset", eval_offset)
    set_option(command, "--eval_partition_seed", 20260811)
    set_option(command, "--eval_partition_stratify_by", "distribution")
    set_option(command, "--max_eval_cases", 60)
    set_option(command, "--early_stop_patience", 0)
    remove_option(command, "--resume_stage2", takes_value=False)
    remove_option(command, "--reset_optimizers_on_resume", takes_value=False)
    remove_option(command, "--reset_value_normalizer_on_resume", takes_value=False)
    set_switch(command, "--use_eval", True)
    set_switch(command, "--skip_pre_ppo_eval", False)
    set_switch(command, "--skip_epoch_eval", False)
    return command


def build_followup_manifest(
    source_manifest_path: Path,
    selected_methods: Sequence[str],
    output: Path,
    *,
    phase: str,
    run_tag: str,
    epochs: int,
    seeds: Sequence[int],
    eval_offset: int,
) -> dict[str, Any]:
    source = _load_json(source_manifest_path)
    source_commands = source.get("commands")
    if not isinstance(source_commands, Mapping):
        raise ValueError("Source manifest has no commands.")
    entries: dict[str, Any] = {}
    for method in selected_methods:
        if method not in source_commands:
            raise KeyError(f"Unknown source method {method}.")
        source_entry = source_commands[method]
        for seed in seeds:
            key = method if len(seeds) == 1 else f"{method}_seed{seed}"
            experiment = f"{run_tag}_{phase}_{method}_seed{seed}"
            command = _clone_command(
                source_entry["argv"], experiment=experiment, epochs=epochs,
                seed=seed, eval_offset=eval_offset,
            )
            entries[key] = {
                **{k: v for k, v in source_entry.items() if k not in {"argv", "shell"}},
                "source_method": method,
                "seed": seed,
                "argv": command,
                "shell": subprocess.list2cmdline(command),
            }
    if not entries:
        raise ValueError("Refusing to build an empty follow-up manifest.")
    first = next(iter(entries.values()))
    manifest = {
        "schema_version": 1,
        "created_at": _now(),
        "research_stage": "stage2_resource_joint",
        "profile": "event_credit_autopilot",
        "phase": phase,
        "run_tag": run_tag,
        "epochs": epochs,
        "seeds": list(seeds),
        "eval_case_offset": eval_offset,
        "source_manifest": {
            "path": str(source_manifest_path.resolve()),
            "sha256": _sha256(source_manifest_path),
            "methods": list(selected_methods),
        },
        "screen_gate": dict(source["screen_gate"]),
        "evaluator_source_method": next(iter(entries)),
        "evaluator_command": first["argv"],
        "commands": entries,
    }
    _atomic_json(output, manifest)
    return manifest


def build_representation_manifest(
    source_manifest_path: Path,
    selected_methods: Sequence[str],
    output: Path,
    *,
    run_tag: str,
    epochs: int = 4,
    eval_offset: int = 0,
) -> dict[str, Any]:
    """Cross the two best learning signals with three device-head families."""
    source = _load_json(source_manifest_path)
    source_commands = source.get("commands")
    if not isinstance(source_commands, Mapping):
        raise ValueError("Source manifest has no commands.")
    entries: dict[str, Any] = {}
    for method in selected_methods:
        if method not in source_commands:
            raise KeyError(f"Unknown source method {method}.")
        source_entry = source_commands[method]
        for head_mode in ("shared", "type_adapter", "per_type"):
            key = f"{method}__{head_mode}"
            command = _clone_command(
                source_entry["argv"],
                experiment=f"{run_tag}_waveB_{key}_seed1",
                epochs=epochs,
                seed=1,
                eval_offset=eval_offset,
            )
            set_option(command, "--device_policy_head_mode", head_mode)
            entries[key] = {
                **{
                    k: v for k, v in source_entry.items()
                    if k not in {"argv", "shell"}
                },
                "source_method": method,
                "device_policy_head_mode": head_mode,
                "seed": 1,
                "argv": command,
                "shell": subprocess.list2cmdline(command),
            }
    if not entries:
        raise ValueError("Refusing to build an empty representation manifest.")
    first = next(iter(entries.values()))
    manifest = {
        "schema_version": 1,
        "created_at": _now(),
        "research_stage": "stage2_resource_joint",
        "profile": "mc_cf_timing_tail_representation_wave",
        "phase": "wave_b_representation",
        "run_tag": run_tag,
        "epochs": epochs,
        "seeds": [1],
        "eval_case_offset": eval_offset,
        "source_manifest": {
            "path": str(source_manifest_path.resolve()),
            "sha256": _sha256(source_manifest_path),
            "methods": list(selected_methods),
        },
        "screen_gate": dict(source["screen_gate"]),
        "evaluator_source_method": next(iter(entries)),
        "evaluator_command": first["argv"],
        "commands": entries,
    }
    _atomic_json(output, manifest)
    return manifest


def _service_state(unit: str) -> str:
    result = subprocess.run(
        ["systemctl", "--user", "is-active", f"{unit}.service"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        check=False,
    )
    return result.stdout.strip() or "unknown"


def _write_state(path: Path, phase: str, **details: Any) -> None:
    _atomic_json(path, {
        "schema_version": 1,
        "updated_at": _now(),
        "phase": phase,
        **details,
    })


def wait_for_predecessor(
    unit: str, pipeline_status: Path, state_path: Path,
    *, poll_seconds: float, timeout_seconds: float,
) -> None:
    deadline = time.monotonic() + timeout_seconds
    while _service_state(unit) in ACTIVE_STATES:
        if time.monotonic() >= deadline:
            raise TimeoutError(f"Timed out waiting for {unit}.service")
        _write_state(
            state_path, "waiting_for_wave_a", predecessor_unit=unit,
            predecessor_state=_service_state(unit),
        )
        time.sleep(poll_seconds)
    payload = _load_json(pipeline_status)
    if payload.get("status") != "completed" or payload.get("phase") != "wave_a":
        raise RuntimeError(f"Wave A did not complete successfully: {payload}")


def _wait_gpu_idle(gpus: Sequence[int], timeout_seconds: float = 900.0) -> None:
    deadline = time.monotonic() + timeout_seconds
    while True:
        busy = {}
        for gpu in sorted(set(gpus)):
            result = subprocess.run(
                [
                    "nvidia-smi", f"--id={gpu}",
                    "--query-compute-apps=pid", "--format=csv,noheader,nounits",
                ],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                check=False,
            )
            if result.returncode != 0 or result.stdout.strip():
                busy[gpu] = result.stdout.strip() or result.stderr.strip()
        if not busy:
            return
        if time.monotonic() >= deadline:
            raise TimeoutError(f"GPUs remained busy: {busy}")
        time.sleep(2.0)


def _terminate(process: subprocess.Popen[Any]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=60)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=30)


def run_training_phase(
    args: argparse.Namespace,
    manifest_path: Path,
    trials: Sequence[Trial],
    *,
    phase: str,
    eval_dataset: Path,
    eval_offset: int,
) -> None:
    used_gpus = sorted({trial.gpu for trial in trials})
    _wait_gpu_idle(used_gpus)
    evaluators: dict[int, subprocess.Popen[Any]] = {}
    evaluator_logs = []
    trainer_logs = []
    trainers: dict[str, subprocess.Popen[Any]] = {}
    sockets: dict[int, Path] = {}
    try:
        for gpu in used_gpus:
            socket = Path(f"/tmp/{args.autopilot_unit}-{phase}-g{gpu}.sock")
            try:
                socket.unlink()
            except FileNotFoundError:
                pass
            sockets[gpu] = socket
            log_path = args.suite_dir / f"service_logs/{phase}_g{gpu}_eval.log"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log = log_path.open("ab", buffering=0)
            evaluator_logs.append(log)
            env = os.environ.copy()
            env.update({"CUDA_VISIBLE_DEVICES": str(gpu), "CUDA_DEVICE_ORDER": "PCI_BUS_ID"})
            command = [
                "/usr/bin/taskset", "--cpu-list", TRAIN_EVAL_CPUS[gpu],
                str(args.python), "-u", str(args.evaluator),
                "--source-command-json", str(manifest_path),
                "--socket-path", str(socket),
                "--cpu-pool", TRAIN_EVAL_CPUS[gpu],
                "--run-dir", str(args.suite_dir / f"shared_evaluator/{phase}_g{gpu}"),
                "--eval-dataset-dir", str(eval_dataset),
                "--eval-case-offset", str(eval_offset),
                "--max-eval-cases", "60",
                "--cuda-memory-fraction", "0.08",
                "--eval-partition-seed", "20260811",
                "--eval-partition-stratify-by", "distribution",
            ]
            evaluators[gpu] = subprocess.Popen(
                command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        deadline = time.monotonic() + 1200.0
        pending = set(used_gpus)
        while pending:
            for gpu in tuple(pending):
                process = evaluators[gpu]
                if process.poll() is not None:
                    raise RuntimeError(
                        f"{phase} GPU{gpu} evaluator exited with {process.returncode}."
                    )
                if sockets[gpu].exists():
                    try:
                        reply = SharedEvalClient(
                            str(sockets[gpu]), timeout_seconds=5.0
                        ).ping()
                    except Exception:
                        continue
                    if int(reply.get("worker_count", -1)) == 12:
                        pending.remove(gpu)
            if pending and time.monotonic() >= deadline:
                raise TimeoutError(f"Evaluator readiness timeout: {sorted(pending)}")
            if pending:
                time.sleep(1.0)

        for trial in trials:
            log_path = args.suite_dir / f"service_logs/{phase}_{trial.key}.log"
            log = log_path.open("ab", buffering=0)
            trainer_logs.append(log)
            env = os.environ.copy()
            env.update({
                "CUDA_VISIBLE_DEVICES": str(trial.gpu),
                "CUDA_DEVICE_ORDER": "PCI_BUS_ID",
            })
            command = [
                "/usr/bin/taskset", "--cpu-list", trial.cpu_set,
                str(args.python), "-u", str(args.trial_runner),
                "--manifest", str(manifest_path),
                "--command-key", trial.key,
                "--gpu", str(trial.gpu),
                "--cpu-set", trial.cpu_set,
                "--shared-eval-socket", str(sockets[trial.gpu]),
                "--shared-eval-cpu-set", TRAIN_EVAL_CPUS[trial.gpu],
                "--eval-workers", "12",
                "--start-delay-seconds", str(trial.delay_seconds),
                "--record", str(args.suite_dir / f"records/{phase}_{trial.key}.json"),
            ]
            trainers[trial.key] = subprocess.Popen(
                command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True,
            )

        while True:
            states = {key: process.poll() for key, process in trainers.items()}
            _write_state(
                args.state_path, f"{phase}_running",
                trainer_states={key: ("active" if value is None else value) for key, value in states.items()},
            )
            if all(value is not None for value in states.values()):
                break
            for gpu, process in evaluators.items():
                if process.poll() is not None:
                    raise RuntimeError(
                        f"{phase} GPU{gpu} evaluator exited with {process.returncode}."
                    )
            time.sleep(args.poll_seconds)
        failures = {key: code for key, code in states.items() if code != 0}
        if failures:
            raise RuntimeError(f"{phase} trainers failed: {failures}")
    finally:
        for process in trainers.values():
            _terminate(process)
        for process in evaluators.values():
            _terminate(process)
        for log in trainer_logs + evaluator_logs:
            log.close()
        for socket in sockets.values():
            try:
                socket.unlink()
            except FileNotFoundError:
                pass


def _matched_iga_raw(path: Path) -> float:
    payload = _load_json(path)
    summaries = payload.get("method_summaries")
    if not isinstance(summaries, Mapping):
        raise ValueError("Matched-IGA comparison has no method_summaries.")
    hard = summaries.get("matched_iga1800_hard_F1")
    if not isinstance(hard, Mapping):
        raise ValueError("Matched hard IGA-1800 summary is missing.")
    return _finite(hard, "mean")


def _formal_summary(selection: Mapping[str, Any], output: Path) -> dict[str, Any]:
    records = list(selection.get("methods", []))
    if len(records) != 3:
        raise ValueError(f"Formal requires three seed records, got {len(records)}.")
    hard_failures = [record for record in records if record.get("gate_reasons")]
    improvements = [float(record["raw_cmax_improvement_seconds"]) for record in records]
    ood = [float(record["ood_stress_regression_seconds"]) for record in records]
    payload = {
        "schema_version": 1,
        "created_at": _now(),
        "method": str(records[0]["method"]).rsplit("_seed", 1)[0],
        "seed_count": 3,
        "mean_best_raw_makespan": sum(float(record["best_raw_makespan"]) for record in records) / 3.0,
        "mean_raw_improvement_seconds": sum(improvements) / 3.0,
        "improved_seed_count": sum(value > 0.0 for value in improvements),
        "mean_ood_stress_regression_seconds": sum(ood) / 3.0,
        "all_health_gates_passed": not hard_failures,
        "finalblind_authorized": bool(
            not hard_failures
            and sum(improvements) / 3.0 >= 75.0
            and sum(value > 0.0 for value in improvements) >= 2
            and sum(ood) / 3.0 <= 25.0
        ),
        "records": records,
    }
    _atomic_json(output, payload)
    return payload


def _blind_manifest(formal_manifest: Path, output: Path) -> dict[str, Any]:
    manifest = _load_json(formal_manifest)
    command = list(manifest["evaluator_command"])
    set_option(command, "--n_eval_rollout_threads", 60)
    set_option(command, "--max_eval_cases", 60)
    set_option(command, "--eval_case_offset", 0)
    payload = {
        **manifest,
        "created_at": _now(),
        "phase": "finalblind",
        "eval_case_offset": 0,
        "evaluator_command": command,
    }
    _atomic_json(output, payload)
    return payload


def run_finalblind(
    args: argparse.Namespace,
    formal_selection: Mapping[str, Any],
    formal_manifest: Path,
) -> dict[str, Any]:
    blind_manifest = args.suite_dir / "commands/finalblind.json"
    _blind_manifest(formal_manifest, blind_manifest)
    records = list(formal_selection["methods"])
    assignments = {0: [records[0], records[2]], 1: [records[1]]}
    _wait_gpu_idle((0, 1))
    evaluators: dict[int, subprocess.Popen[Any]] = {}
    logs = []
    sockets: dict[int, Path] = {}
    try:
        for gpu in (0, 1):
            socket = Path(f"/tmp/{args.autopilot_unit}-finalblind-g{gpu}.sock")
            try:
                socket.unlink()
            except FileNotFoundError:
                pass
            sockets[gpu] = socket
            log = (args.suite_dir / f"service_logs/finalblind_g{gpu}_eval.log").open("ab", buffering=0)
            logs.append(log)
            env = os.environ.copy()
            env.update({"CUDA_VISIBLE_DEVICES": str(gpu), "CUDA_DEVICE_ORDER": "PCI_BUS_ID"})
            command = [
                "/usr/bin/taskset", "--cpu-list", BLIND_EVAL_CPUS[gpu],
                str(args.python), "-u", str(args.evaluator),
                "--source-command-json", str(blind_manifest),
                "--socket-path", str(socket),
                "--cpu-pool", BLIND_EVAL_CPUS[gpu],
                "--run-dir", str(args.suite_dir / f"shared_evaluator/finalblind_g{gpu}"),
                "--eval-dataset-dir", str(args.finalblind_dir),
                "--eval-case-offset", "0", "--max-eval-cases", "60",
                "--cuda-memory-fraction", "0.08",
                "--eval-partition-seed", "20260811",
                "--eval-partition-stratify-by", "distribution",
            ]
            evaluators[gpu] = subprocess.Popen(
                command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        deadline = time.monotonic() + 1200.0
        pending = {0, 1}
        while pending:
            for gpu in tuple(pending):
                if evaluators[gpu].poll() is not None:
                    raise RuntimeError(f"Finalblind evaluator GPU{gpu} exited.")
                if sockets[gpu].exists():
                    try:
                        reply = SharedEvalClient(str(sockets[gpu]), 5.0).ping()
                    except Exception:
                        continue
                    if int(reply.get("worker_count", -1)) == 60:
                        pending.remove(gpu)
            if pending and time.monotonic() >= deadline:
                raise TimeoutError(f"Finalblind evaluator timeout: {pending}")
            if pending:
                time.sleep(1.0)

        workers = []
        worker_logs = []
        for gpu, gpu_records in assignments.items():
            log = (args.suite_dir / f"service_logs/finalblind_g{gpu}_client.log").open("ab", buffering=0)
            worker_logs.append(log)
            script = [
                str(args.python), "-u", str(args.offline_evaluator),
                "--socket-path", str(sockets[gpu]),
                "--cpu-set", BLIND_EVAL_CPUS[gpu],
                "--n-eval-rollout-threads", "60",
            ]
            # One process per GPU evaluates its assigned seeds serially so the
            # shared service cannot receive interleaved requests from this phase.
            commands = []
            for record in gpu_records:
                seed = int(str(record["method"]).rsplit("_seed", 1)[-1])
                output = args.suite_dir / f"finalblind/{record['method']}.json"
                commands.append(script + [
                    "--checkpoint", record["checkpoint"],
                    "--seed", str(seed), "--output", str(output),
                    "--label", f"finalblind_{record['method']}",
                    "--evaluation-tau", "0.3",
                ])
            code = "import subprocess,sys; cmds=" + repr(commands) + "; " \
                + "[subprocess.run(c,check=True) for c in cmds]"
            workers.append(subprocess.Popen(
                [str(args.python), "-c", code], cwd=ROOT,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
            ))
        failures = []
        for process in workers:
            code = process.wait()
            if code != 0:
                failures.append(code)
        for log in worker_logs:
            log.close()
        if failures:
            raise RuntimeError(f"Finalblind clients failed: {failures}")
    finally:
        for process in evaluators.values():
            _terminate(process)
        for log in logs:
            log.close()
        for socket in sockets.values():
            try:
                socket.unlink()
            except FileNotFoundError:
                pass

    outputs = sorted((args.suite_dir / "finalblind").glob("*.json"))
    rows = []
    for output in outputs:
        payload = _load_json(output)
        summary = payload["evaluation"]["summary"]
        rows.append({
            "path": str(output.resolve()),
            "seed": int(payload["seed"]),
            "raw_makespan": _finite(summary, "eval_raw_makespan"),
            "selection_score": _finite(summary, "eval_selection_score"),
            "completion_rate": _finite(summary, "eval_completion_rate"),
            "cycle_count": int(_finite(summary, "eval_cycle_count")),
            "timeout_count": int(_finite(summary, "eval_timeout_count")),
        })
    if len(rows) != 3:
        raise ValueError(f"Expected three finalblind outputs, got {len(rows)}.")
    report = {
        "schema_version": 1,
        "created_at": _now(),
        "seed_count": 3,
        "mean_raw_makespan": sum(row["raw_makespan"] for row in rows) / 3.0,
        "mean_selection_score": sum(row["selection_score"] for row in rows) / 3.0,
        "all_completed": all(
            row["completion_rate"] == 1.0
            and row["cycle_count"] == 0
            and row["timeout_count"] == 0
            for row in rows
        ),
        "rows": rows,
    }
    _atomic_json(args.suite_dir / "analysis/finalblind_summary.json", report)
    return report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", type=Path, required=True)
    parser.add_argument("--wave-unit", required=True)
    parser.add_argument("--autopilot-unit", required=True)
    parser.add_argument("--run-tag", required=True)
    parser.add_argument("--matched-iga", type=Path, default=DEFAULT_MATCHED_IGA)
    parser.add_argument("--gate-dir", type=Path, default=DEFAULT_EVAL_ROOT / "gate")
    parser.add_argument("--finalblind-dir", type=Path, default=DEFAULT_EVAL_ROOT / "finalblind")
    parser.add_argument("--results-root", type=Path, default=DEFAULT_RESULTS_ROOT)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument(
        "--trial-runner", type=Path,
        default=ROOT / "onpolicy/scripts/train/run_stage2_resource_manifest_trial.py",
    )
    parser.add_argument(
        "--evaluator", type=Path,
        default=ROOT / "onpolicy/scripts/train/shared_hkbz_evaluator.py",
    )
    parser.add_argument(
        "--offline-evaluator", type=Path,
        default=ROOT / "onpolicy/scripts/train/evaluate_stage1_shared_checkpoint.py",
    )
    parser.add_argument("--poll-seconds", type=float, default=30.0)
    parser.add_argument("--timeout-seconds", type=float, default=604800.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.suite_dir = args.suite_dir.resolve()
    args.state_path = args.suite_dir / "autopilot/state.json"
    wave_manifest = args.suite_dir / "commands/wave_a.json"
    pipeline_status = args.suite_dir / "pipeline_status.json"
    dynamic_deadline = time.monotonic() + min(
        args.timeout_seconds, 1800.0
    )
    while not wave_manifest.exists() or not pipeline_status.exists():
        if time.monotonic() >= dynamic_deadline:
            raise TimeoutError(
                "Timed out waiting for the Wave-A manifest/controller state."
            )
        _write_state(
            args.state_path,
            "waiting_for_wave_a_artifacts",
            wave_manifest_exists=wave_manifest.exists(),
            pipeline_status_exists=pipeline_status.exists(),
        )
        time.sleep(min(args.poll_seconds, 5.0))
    for path in (
        args.python, args.trial_runner, args.evaluator, args.offline_evaluator,
        args.matched_iga, args.gate_dir, args.finalblind_dir, wave_manifest,
        pipeline_status,
    ):
        if not path.resolve().exists():
            raise FileNotFoundError(path.resolve())
    if args.poll_seconds <= 0 or args.timeout_seconds <= 0:
        raise ValueError("Polling and timeout values must be positive.")
    try:
        wait_for_predecessor(
            args.wave_unit, pipeline_status, args.state_path,
            poll_seconds=args.poll_seconds, timeout_seconds=args.timeout_seconds,
        )
        iga_raw = _matched_iga_raw(args.matched_iga)
        _write_state(args.state_path, "analyzing_wave_a", matched_iga1800_raw=iga_raw)
        wave_a = analyze_phase(
            wave_manifest, args.results_root,
            args.suite_dir / "analysis/wave_a_selection.json",
            iga1800_raw=iga_raw,
        )
        promoted = list(wave_a["eligible_methods"][:2])
        if not promoted:
            _write_state(
                args.state_path, "stopped_no_wave_b_candidate",
                selection=str(args.suite_dir / "analysis/wave_a_selection.json"),
            )
            return 0

        wave_b_manifest = args.suite_dir / "commands/wave_b.json"
        wave_b = build_representation_manifest(
            wave_manifest, promoted, wave_b_manifest,
            run_tag=args.run_tag, epochs=4, eval_offset=0,
        )
        wave_b_trials = [
            Trial(key, *WAVE_B_LAYOUT[index], delay_seconds=15.0 * index)
            for index, key in enumerate(wave_b["commands"])
        ]
        _write_state(args.state_path, "launching_wave_b", promoted_methods=promoted)
        run_training_phase(
            args, wave_b_manifest, wave_b_trials, phase="wave_b",
            eval_dataset=args.gate_dir, eval_offset=0,
        )
        _write_state(args.state_path, "analyzing_wave_b")
        wave_b_selection = analyze_phase(
            wave_b_manifest, args.results_root,
            args.suite_dir / "analysis/wave_b_selection.json",
            iga1800_raw=None,
        )
        winner = wave_b_selection["selected_method"]
        if winner is None:
            _write_state(
                args.state_path, "stopped_no_formal_candidate",
                selection=str(args.suite_dir / "analysis/wave_b_selection.json"),
            )
            return 0

        formal_manifest = args.suite_dir / "commands/formal.json"
        formal = build_followup_manifest(
            wave_b_manifest, (winner,), formal_manifest,
            phase="formal", run_tag=args.run_tag, epochs=8, seeds=(1, 2, 3),
            eval_offset=60,
        )
        formal_trials = [
            Trial(key, *FORMAL_LAYOUT[index], delay_seconds=15.0 * index)
            for index, key in enumerate(formal["commands"])
        ]
        _write_state(args.state_path, "launching_formal", selected_method=winner)
        run_training_phase(
            args, formal_manifest, formal_trials, phase="formal",
            eval_dataset=args.gate_dir, eval_offset=60,
        )
        _write_state(args.state_path, "analyzing_formal", selected_method=winner)
        formal_selection = analyze_phase(
            formal_manifest, args.results_root,
            args.suite_dir / "analysis/formal_selection.json",
            iga1800_raw=None,
        )
        formal_summary = _formal_summary(
            formal_selection, args.suite_dir / "analysis/formal_summary.json"
        )
        if not formal_summary["finalblind_authorized"]:
            _write_state(
                args.state_path, "completed_before_finalblind",
                selected_method=winner,
                finalblind_authorized=False,
                formal_summary=str(args.suite_dir / "analysis/formal_summary.json"),
            )
            return 0
        _write_state(args.state_path, "running_finalblind", selected_method=winner)
        blind = run_finalblind(args, formal_selection, formal_manifest)
        _write_state(
            args.state_path, "completed", selected_method=winner,
            finalblind_authorized=True,
            finalblind_summary=str(args.suite_dir / "analysis/finalblind_summary.json"),
            finalblind_mean_raw_makespan=blind["mean_raw_makespan"],
        )
        return 0
    except Exception as error:
        _write_state(
            args.state_path, "failed", error_type=type(error).__name__,
            error=str(error),
        )
        raise


if __name__ == "__main__":
    raise SystemExit(main())
