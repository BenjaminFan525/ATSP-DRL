#!/usr/bin/env python3
"""Prepare and analyze the Stage2 adaptive-trust/critic-calibration screen."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.config.config import get_config  # noqa: E402
from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    sha256_file,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.scripts.train.stage2_event_credit_autopilot import (  # noqa: E402
    _matched_iga_raw,
    analyze_phase,
)
from onpolicy.scripts.train.train_hkbz import (  # noqa: E402
    parse_args as parse_training_args,
)


RUN_TAG = 'stage2_adaptive_trust_20260830_r1'
METHODS = {
    'T0_backtrack_no_bc': {
        'bc_mode': 'none', 'critic_mode': 'inherited', 'paired_scope': 'none',
        'hypothesis': 'KL backtracking alone prevents shard-wide Actor freeze',
    },
    'T1_backtrack_fixed_soft_bc': {
        'bc_mode': 'fixed', 'critic_mode': 'inherited', 'paired_scope': 'none',
        'hypothesis': 'fixed soft BC anchor limits drift without rejecting updates',
    },
    'T2_backtrack_adaptive_soft_bc': {
        'bc_mode': 'adaptive', 'critic_mode': 'inherited', 'paired_scope': 'none',
        'hypothesis': 'adaptive soft BC pressure tracks a useful trust distance',
    },
    'T3_adaptive_raw_critic_calibration': {
        'bc_mode': 'adaptive', 'critic_mode': 'raw_warmup', 'paired_scope': 'none',
        'hypothesis': 'fresh ValueNorm plus one critic-only pass calibrates raw returns',
    },
    'T4_adaptive_paired_residual_critic': {
        'bc_mode': 'adaptive', 'critic_mode': 'paired_warmup', 'paired_scope': 'returns',
        'hypothesis': 'a paired residual Critic reduces case-difficulty variance',
    },
    'T5_adaptive_actor_only_paired': {
        'bc_mode': 'adaptive', 'critic_mode': 'raw_warmup', 'paired_scope': 'actor',
        'hypothesis': 'paired control variate helps Actor without shifting Critic targets',
    },
}


def load_json(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError(f'Expected JSON object: {path}')
    return payload


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + '\n',
        encoding='utf-8',
    )
    temporary.replace(path)


def option_value(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def code_contract() -> dict:
    paths = (
        'onpolicy/config/config.py',
        'onpolicy/algorithms/gnn_mappo/gnn_mappo.py',
        'onpolicy/utils/shared_buffer.py',
        'onpolicy/runner/shared/hkbz_runner.py',
        'onpolicy/scripts/train/prepare_stage2_adaptive_trust.py',
        'onpolicy/scripts/train/launch_stage2_adaptive_trust_dual_gpu.sh',
    )
    return {
        'git_revision': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
        ).strip(),
        'working_tree_dirty': bool(subprocess.check_output(
            ['git', 'status', '--short'], cwd=ROOT, text=True
        ).strip()),
        'files_sha256': {
            path: sha256_file(ROOT / path)
            for path in paths if (ROOT / path).is_file()
        },
    }


def configure(command: list[str], key: str, method: dict, args) -> list[str]:
    command = list(command)
    command[0] = str(args.python)
    set_option(command, '--experiment_name', f'{args.run_tag}_wave1_{key}_seed1')
    set_option(command, '--resource_bc_checkpoint', str(args.bc_checkpoint))
    set_option(command, '--device_bc_pretrain_epochs', 0)
    set_switch(command, '--device_bc_only', False)
    set_option(command, '--seed', 1)
    set_option(command, '--num_episodes', 3)
    set_option(command, '--gnn_freeze_epochs', 3)
    set_option(command, '--plane_freeze_epochs', 3)
    set_option(command, '--ppo_epoch', 3)
    set_option(command, '--lr', 7.5e-6)
    set_option(command, '--critic_lr', 1.0e-4)
    set_option(command, '--target_kl', 0.003)
    set_option(command, '--device_target_kl', 0.003)
    set_option(command, '--transporter_target_kl', 0.003)
    set_option(command, '--plane_loss_coef', 0.0)
    set_option(command, '--device_loss_coef', 0.5)
    set_option(command, '--transporter_loss_coef', 0.5)
    set_switch(command, '--adaptive_actor_kl', False)
    set_switch(command, '--actor_kl_backtrack', True)
    set_option(command, '--actor_kl_backtrack_scales', '0.5,0.25,0.125')
    set_switch(command, '--joint_team_ppo', True)
    set_option(command, '--joint_team_ppo_scope', 'all')
    set_switch(command, '--role_atomic_ppo', True)
    set_switch(command, '--role_sequential_ppo', False)
    set_switch(command, '--role_event_returns', True)
    set_switch(command, '--role_valuenorm', True)
    set_switch(command, '--counterfactual_q_baseline', True)
    set_option(command, '--role_event_credit_mode', 'elapsed')
    set_option(command, '--role_event_credit_uniform_mix', 0.15)
    set_option(command, '--hindsight_reward_mode', 'team_time')
    set_option(command, '--iga_potential_beta', 0.0)
    set_option(command, '--iga_potential_beta_schedule', '0.0')
    remove_option(command, '--iga_potential_weights_path')
    set_option(command, '--cvar_policy_fraction', 1.0)
    set_option(command, '--cvar_policy_weight', 1.0)
    set_option(command, '--cvar_case_metric', 'cmax')
    set_option(command, '--tail_policy_start_fraction', 1.0)
    set_option(command, '--tail_policy_weight', 1.0)
    set_switch(command, '--bc_reference_hard_gate', False)

    bc_mode = method['bc_mode']
    if bc_mode == 'none':
        set_option(command, '--bc_reference_kl_coef', 0.0)
        set_option(command, '--bc_reference_target_kl', 0.0)
        set_switch(command, '--adaptive_bc_reference_kl', False)
    elif bc_mode == 'fixed':
        set_option(command, '--bc_reference_kl_coef', 0.10)
        set_option(command, '--bc_reference_target_kl', 0.03)
        set_switch(command, '--adaptive_bc_reference_kl', False)
    else:
        set_option(command, '--bc_reference_kl_coef', 0.10)
        set_option(command, '--bc_reference_target_kl', 0.03)
        set_switch(command, '--adaptive_bc_reference_kl', True)
        set_option(command, '--adaptive_bc_reference_target_kl', 0.03)
        set_option(command, '--adaptive_bc_reference_coef_min', 0.02)
        set_option(command, '--adaptive_bc_reference_coef_max', 1.0)
        set_option(command, '--adaptive_bc_reference_coef_up', 1.5)
        set_option(command, '--adaptive_bc_reference_coef_down', 0.8)
    set_option(command, '--bc_reference_kl_coef_schedule', '')

    calibrated = method['critic_mode'] != 'inherited'
    set_option(command, '--actor_warmup_shards', 8 if calibrated else 0)
    set_switch(command, '--reset_value_normalizer_before_ppo', calibrated)
    scope = method['paired_scope']
    if scope == 'none':
        remove_option(command, '--paired_case_baseline_dir')
        set_option(command, '--paired_case_baseline_coef', 0.0)
        set_option(command, '--paired_case_baseline_scope', 'returns')
    else:
        set_option(command, '--paired_case_baseline_dir', str(args.paired_baseline))
        set_option(command, '--paired_case_baseline_coef', 1.0)
        set_option(command, '--paired_case_baseline_scope', scope)

    # Preserve the measured full-data throughput point from the previous
    # round: 30 rollout workers and 1000 graphs/forward, three trainers/GPU.
    set_option(command, '--cuda_memory_fraction', 0.30)
    set_option(command, '--n_rollout_threads', 30)
    set_option(command, '--n_eval_rollout_threads', 12)
    set_option(command, '--max_train_cases', 0)
    set_option(command, '--train_sampling_size', 240)
    set_option(command, '--train_sampling_pool_size', 600)
    set_option(command, '--max_eval_cases', 60)
    set_option(command, '--max_graphs_per_forward', 1000)
    set_option(command, '--mini_batch_size', 20)
    set_option(command, '--data_chunk_length', 50)
    set_option(command, '--grad_accumulation_steps', 3)
    set_option(command, '--actor_grad_accumulation_steps', 2)
    set_option(command, '--grad_accumulation_target_graphs', 4000)
    set_option(command, '--actor_grad_accumulation_target_graphs', 1800)
    set_option(command, '--early_stop_patience', 0)
    set_option(command, '--recovery_checkpoint_interval_shards', 1)
    set_option(command, '--eval_partition_seed', 20260811)
    set_option(command, '--eval_partition_stratify_by', 'distribution')
    set_switch(command, '--use_eval', True)
    set_switch(command, '--skip_pre_ppo_eval', False)
    set_switch(command, '--skip_epoch_eval', False)
    set_switch(command, '--rollout_until_done', True)
    set_switch(command, '--safe_graph_batch_pipeline', True)
    set_switch(command, '--clear_cuda_cache_after_update', False)
    return command


def validate(command: list[str]) -> None:
    parsed = parse_training_args(command[2:], get_config())
    if parsed.training_stage != 'resource_joint':
        raise ValueError('Adaptive-trust screen requires resource_joint.')
    if not parsed.actor_kl_backtrack or parsed.bc_reference_hard_gate:
        raise ValueError('Wave1 requires backtracking and forbids hard BC gates.')
    if parsed.role_sequential_ppo:
        raise ValueError('Backtracking screen must use atomic joint PPO.')
    if parsed.max_graphs_per_forward != 1000:
        raise ValueError('Wave1 graph cap must remain 1000.')
    if parsed.mini_batch_size * parsed.data_chunk_length > 1000:
        raise ValueError('Wave1 PPO microbatch exceeds its graph cap.')
    if parsed.max_train_cases != 0 or parsed.train_sampling_pool_size != 600:
        raise ValueError('Wave1 must retain the full 600-case sampling pool.')


def canary_command(command: list[str], key: str) -> list[str]:
    command = list(command)
    set_option(command, '--experiment_name', f'{option_value(command, "--experiment_name")}_canary')
    set_option(command, '--num_episodes', 1)
    set_option(command, '--gnn_freeze_epochs', 1)
    set_option(command, '--plane_freeze_epochs', 1)
    set_option(command, '--ppo_epoch', 1)
    set_option(command, '--max_train_cases', 30)
    set_option(command, '--train_sampling_size', 30)
    remove_option(command, '--train_sampling_pool_size')
    set_option(command, '--max_eval_cases', 12)
    # Exercise Actor retry in every canary lane; critic warmup itself is a
    # deterministic flag and is covered by the full command validation.
    set_option(command, '--actor_warmup_shards', 0)
    return command


def prepare(args) -> dict:
    source = load_json(args.source_manifest)
    base = list(source['commands']['P1_mc_counterfactual']['argv'])
    selection = load_json(args.bc_selection)
    if selection.get('selected_method') != 'B0_categorical_control':
        raise ValueError('Expected the verified B0 DeviceBC boundary.')
    recorded_checkpoint = Path(selection['selected_checkpoint']).resolve()
    recorded_sha = selection['selected_checkpoint_sha256']
    if recorded_checkpoint != args.bc_checkpoint:
        raise ValueError('Explicit BC checkpoint does not match its selection record.')
    if sha256_file(args.bc_checkpoint) != recorded_sha:
        raise ValueError('B0 DeviceBC checkpoint SHA256 mismatch.')
    if not args.paired_baseline.is_file():
        raise FileNotFoundError(args.paired_baseline)

    commands = {}
    for key, method in METHODS.items():
        command = configure(base, key, method, args)
        validate(command)
        commands[key] = {
            **method,
            'family': 'adaptive_trust_critic_calibration',
            'argv': command,
            'shell': shlex.join(command),
        }
    shared = {
        'schema_version': 1,
        'research_stage': 'stage2_resource_joint',
        'profile': 'adaptive_trust_critic_calibration',
        'phase': 'wave1_adaptive_trust',
        'run_tag': args.run_tag,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'code_contract': code_contract(),
        'source_manifest': {
            'path': str(args.source_manifest),
            'sha256': sha256_file(args.source_manifest),
            'method': 'P1_mc_counterfactual',
        },
        'source_bc_checkpoint': {
            'path': str(args.bc_checkpoint),
            'sha256': recorded_sha,
            'selection': str(args.bc_selection),
            'selection_sha256': sha256_file(args.bc_selection),
        },
        'paired_baseline': {
            'path': str(args.paired_baseline),
            'sha256': sha256_file(args.paired_baseline),
        },
        'hardware_contract': {
            'gpus': [0, 1], 'trainers_per_gpu': 3,
            'shared_evaluators_per_gpu': 1,
            'physical_core_isolation': True,
            'max_graphs_per_forward': 1000,
        },
        'screen_gate': {
            'raw_cmax_improvement_seconds': 0.0,
            'matched_iga1800_gap_seconds_max': 250.0,
            'ood_stress_regression_seconds_max': 25.0,
            'tail_regression_seconds_max': 25.0,
            'completion_rate_min': 1.0,
            'actor_step_completion_min': 0.90,
            'cycle_count_max': 0,
            'backtrack_failed_group_fraction_max': 0.05,
            'zero_update_shards_max': 0,
            'critic_calibration_ratio_max': 0.25,
        },
        'methods': METHODS,
        'evaluator_source_method': next(iter(commands)),
        'evaluator_command': next(iter(commands.values()))['argv'],
        'commands': commands,
    }
    atomic_json(args.wave_output, shared)

    canary_keys = (
        'T0_backtrack_no_bc',
        'T2_backtrack_adaptive_soft_bc',
        'T5_adaptive_actor_only_paired',
    )
    canary_commands = {}
    for key in canary_keys:
        canary_key = f'C_{key}'
        command = canary_command(commands[key]['argv'], key)
        parsed = parse_training_args(command[2:], get_config())
        if parsed.max_train_cases != 30 or parsed.train_sampling_size != 30:
            raise ValueError('Canary must run exactly one 30-case shard.')
        canary_commands[canary_key] = {
            'source_method': key,
            'argv': command,
            'shell': shlex.join(command),
        }
    canary = {
        **{key: value for key, value in shared.items()
           if key not in {'phase', 'methods', 'commands',
                          'evaluator_source_method', 'evaluator_command'}},
        'phase': 'production_layout_canary',
        'methods': canary_commands,
        'evaluator_source_method': next(iter(canary_commands)),
        'evaluator_command': next(iter(canary_commands.values()))['argv'],
        'commands': canary_commands,
    }
    atomic_json(args.canary_output, canary)
    return {'canary': str(args.canary_output), 'wave1': str(args.wave_output)}


def analyze(args) -> dict:
    payload = analyze_phase(
        args.wave_output,
        args.results_root,
        args.analysis_output,
        iga1800_raw=_matched_iga_raw(args.matched_iga),
    )
    manifest = load_json(args.wave_output)
    for record in payload['methods']:
        command = manifest['commands'][record['method']]['argv']
        run_dir = Path(record['run_dir'])
        status = load_json(run_dir / 'run_status.json')
        health = status.get('actor_update_health', {})
        failed_fraction = float(health.get(
            'backtrack_failed_group_fraction', 1.0
        ))
        record['backtrack_failed_group_fraction'] = failed_fraction
        record['backtrack_retry_attempts'] = float(health.get(
            'backtrack_retry_attempts', 0.0
        ))
        record['critic_calibration_ratio_final'] = float(status.get(
            'critic_calibration_ratio', 0.0
        ))
        reasons = list(record['gate_reasons'])
        if failed_fraction > 0.05:
            reasons.append('backtrack_failed_group_fraction_above_gate')
        if int(record.get('zero_update_shards', -1)) != 0:
            reasons.append('zero_update_shards')
        critic_mode = manifest['methods'][record['method']]['critic_mode']
        if (
            critic_mode != 'inherited'
            and record['critic_calibration_ratio_final'] > 0.25
        ):
            reasons.append('critic_calibration_ratio_above_gate')
        best_epoch = record.get('best_epoch')
        exact_checkpoint = (
            run_dir / f'models/checkpoint_Epoch{int(best_epoch)}.pt'
            if best_epoch is not None else None
        )
        if exact_checkpoint is None or not exact_checkpoint.is_file():
            reasons.append('missing_exact_epoch_checkpoint')
            record['checkpoint'] = None
            record['checkpoint_sha256'] = None
        else:
            record['checkpoint'] = str(exact_checkpoint.resolve())
            record['checkpoint_sha256'] = sha256_file(exact_checkpoint)
        record['gate_reasons'] = sorted(set(reasons))
        record['eligible'] = not record['gate_reasons']

    eligible = sorted(
        (record for record in payload['methods'] if record['eligible']),
        key=lambda record: (
            float(record['best_selection_score']),
            float(record['mean_selection_score']),
            float(record['best_raw_makespan']),
            record['method'],
        ),
    )
    payload['ranking'] = [record['method'] for record in eligible]
    payload['eligible_methods'] = list(payload['ranking'])
    payload['selected_method'] = payload['ranking'][0] if eligible else None
    payload['selected_checkpoint'] = (
        eligible[0]['checkpoint'] if eligible else None
    )
    payload['selected_checkpoint_sha256'] = (
        eligible[0]['checkpoint_sha256'] if eligible else None
    )
    payload['checkpoint_binding'] = 'exact_best_epoch_checkpoint'
    atomic_json(args.analysis_output, payload)
    return {
        'selected_method': payload['selected_method'],
        'selected_checkpoint': payload['selected_checkpoint'],
        'eligible_methods': payload['eligible_methods'],
    }


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['prepare', 'analyze'], required=True)
    parser.add_argument('--run-tag', default=RUN_TAG)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--bc-selection', type=Path, required=True)
    parser.add_argument('--bc-checkpoint', type=Path, required=True)
    parser.add_argument('--paired-baseline', type=Path, required=True)
    parser.add_argument('--python', type=Path, required=True)
    parser.add_argument('--canary-output', type=Path, required=True)
    parser.add_argument('--wave-output', type=Path, required=True)
    parser.add_argument('--analysis-output', type=Path, required=True)
    parser.add_argument('--matched-iga', type=Path, required=True)
    parser.add_argument(
        '--results-root', type=Path,
        default=ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo',
    )
    args = parser.parse_args()
    for name, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, name, value.expanduser().resolve())
    for name in (
        'source_manifest', 'bc_selection', 'bc_checkpoint',
        'paired_baseline', 'python', 'matched_iga', 'results_root',
    ):
        if not getattr(args, name).exists():
            raise FileNotFoundError(getattr(args, name))
    return args


def main() -> int:
    args = parse_args()
    result = prepare(args) if args.mode == 'prepare' else analyze(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
