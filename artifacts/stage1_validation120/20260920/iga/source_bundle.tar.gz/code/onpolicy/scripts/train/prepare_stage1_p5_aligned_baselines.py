#!/usr/bin/env python3
"""Freeze a four-GPU baseline suite aligned to the completed P5 experiment.

Preparation never launches processes.  The historical-warmup semantic change
requires an explicit choice; without it the produced manifest is launch-blocked.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

import yaml

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.utils.shared_eval import parse_cpu_set

METHODS = ("l2d", "multi_ppo", "fjsp_drl", "daniel")
CPU_SETS = ("32-37,96-101", "38-43,102-107", "44-49,108-113", "50-55,114-119")
EVAL_CPUS = "56-63,120-127"
SOURCE_PATHS = {
    "n2": "result/hkbz_train_logs/stage1_tail_robustness_v2_20260803_r1/commands/screen_N2_safe_tail_dagger_seed1.json",
    "m2": "result/hkbz_train_logs/stage1_next_round_20260808_r1/commands/formal_M2_bc_kl_anneal_seed1.json",
    "b0": "result/hkbz_train_logs/stage1_departure_research_20260812_r1/commands/bc_screen_seed1.json",
    "p5": "result/hkbz_train_logs/stage1_departure_reward_formal_dual_20260816_r1/commands/formal_P5.json",
}
TEACHER = ROOT / "result/hkbz_train_logs/iga_teachers/fjspv3_t600_train_s1_progressive_departure_r014_20260812_v2_p20_g20_t1800_a5_s1"
POTENTIAL = ROOT / "result/hkbz_train_logs/stage1_departure_research_20260812_r1/iga_potential_v2.json"
TRAIN_DATA = ROOT / "onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train"
VALIDATION = ROOT / "onpolicy/envs/HKBZ/dataset/fjsp_v3_stage1_v2_eval_s20260803/validation"
RESULTS = ROOT / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo"


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    os.replace(temporary, path)


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def remove(command, flag, takes_value=True):
    while flag in command:
        index = command.index(flag)
        del command[index:index + (2 if takes_value else 1)]


def option(command, flag, default=None):
    if command.count(flag) > 1:
        raise ValueError(f"Duplicate option {flag}")
    return command[command.index(flag) + 1] if flag in command else default


def set_option(command, flag, value):
    remove(command, flag)
    command.extend((flag, str(value)))


def switch(command, flag, enabled):
    remove(command, flag, takes_value=False)
    if enabled:
        command.append(flag)


def migrate(value):
    marker = "/HKBZ-environment/"
    if marker in value:
        return str(ROOT / value.split(marker, 1)[1])
    return value


def source_commands():
    source = {key: read_json(ROOT / path) for key, path in SOURCE_PATHS.items()}
    return {
        "n2": list(source["n2"]["command"]),
        "m2": list(source["m2"]["command"]),
        "b0": list(source["b0"]["commands"]["B0_legacy_dagger_warm"]["argv"]),
        "p5": list(source["p5"]["commands"]["P5_team_time_potential_fixed_seed1"]["argv"]),
    }


def check_cpu_isolation(groups=(*CPU_SETS, EVAL_CPUS)):
    parsed = [parse_cpu_set(value) for value in groups]
    for i, cpus in enumerate(parsed):
        if not cpus <= set(range(32, 64)) | set(range(96, 128)):
            raise ValueError("Baseline CPU affinity escapes reserved NUMA-1 cores.")
        for cpu in cpus:
            sibling = cpu + 64 if cpu < 64 else cpu - 64
            if sibling not in cpus:
                raise ValueError("SMT siblings must remain in the same process group.")
        if any(cpus & other for other in parsed[i + 1:]):
            raise ValueError("CPU process groups overlap.")
    return True


def snapshot_sources(destination):
    destination.mkdir(parents=True)
    records = {}
    excluded = {"dataset", "results", "__pycache__", ".git"}
    for source_dir in (ROOT / "onpolicy", ROOT / "utils"):
        for current, directories, files in os.walk(source_dir):
            directories[:] = [name for name in directories if name not in excluded]
            for name in files:
                source = Path(current) / name
                if source.suffix not in {".py", ".yaml", ".yml", ".json"}:
                    continue
                relative = source.relative_to(ROOT)
                target = destination / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                records[str(relative)] = sha256(target)
    for source in ROOT.glob("*.py"):
        shutil.copy2(source, destination / source.name)
        records[source.name] = sha256(destination / source.name)
    # Keep normal, unique experiment output locations while importing only
    # the frozen source tree in subsequent lane phases.
    (destination / "onpolicy/scripts/results").symlink_to(ROOT / "onpolicy/scripts/results", target_is_directory=True)
    return records


def teacher_audit():
    from onpolicy.envs.HKBZ.data_generator import _sha256 as canonical_sha256

    records = []
    for case in sorted(TRAIN_DATA.glob("case_*")):
        if not case.is_dir():
            continue
        teacher_path = TEACHER / (case.name + ".json")
        teacher = read_json(teacher_path)
        metadata = read_json(case / "metadata.json")
        fingerprints = metadata.get("fingerprints", {})
        case_digest = metadata.get("case_sha256") or fingerprints.get("case_sha256")
        file_values = {name: read_json(case / name) for name in (
            "job.json", "fixed_resources.json", "mobile_resources.json", "sites.json", "flights.json"
        )}
        for filename, digest in fingerprints.get("files", {}).items():
            if canonical_sha256(file_values[filename]) != digest:
                raise ValueError(f"Training data fingerprint mismatch: {case / filename}")
        if canonical_sha256(file_values) != case_digest:
            raise ValueError(f"Training case fingerprint mismatch: {case}")
        if (
            teacher.get("environment_semantics_version") != "progressive-departure-r014-pipeline-v2"
            or teacher.get("teacher_scope") != "stage1_plane_policy"
            or teacher.get("resource_policy") != "heuristic"
            or teacher.get("completion_verified") is not True
            or not case_digest
            or teacher.get("case_sha256") != case_digest
        ):
            raise ValueError(f"Invalid teacher contract: {teacher_path}")
        records.append({"case": case.name, "case_sha256": case_digest, "teacher_sha256": sha256(teacher_path)})
    if len(records) != 600:
        raise ValueError(f"Expected 600 verified teachers, found {len(records)}")
    return records


def runtime_command(source, *, method, experiment, seed, code_root, suite, socket_path):
    command = [migrate(value) for value in source]
    command[:2] = [sys.executable, str(code_root / "onpolicy/scripts/train/train_stage1_aligned_baseline.py")]
    for flag in ("--checkpoint_dir", "--selection_checkpoint_dir", "--shared_eval_socket", "--shared_eval_cpu_set", "--shared_eval_timeout_seconds", "--bc_reference_checkpoint", "--shared_gpu_phase_lock"):
        remove(command, flag)
    for flag in ("--resume_stage1", "--reset_optimizers_on_resume", "--reset_value_normalizer_on_resume"):
        switch(command, flag, False)
    for flag, value in {
        "--experiment_name": experiment, "--stage1_baseline": method,
        "--seed": seed, "--training_stage": "plane_pretrain",
        "--resource_policy": "heuristic", "--plane_order_mode": "fixed",
        "--plane_pair_decoder": "joint_pair", "--n_training_threads": 1,
        "--n_rollout_threads": 60, "--n_eval_rollout_threads": 12,
        "--ac_config": code_root / "onpolicy/config/ac.yaml",
        "--env_config": suite / "env_frozen.yaml",
        "--eval_dataset_dir": VALIDATION, "--max_eval_cases": 60,
        "--eval_case_offset": 0, "--eval_partition_seed": 20260803,
        "--eval_partition_stratify_by": "profile",
        "--plane_bc_teacher_dir": TEACHER,
        "--iga_potential_weights_path": POTENTIAL,
        "--shared_eval_socket": socket_path, "--shared_eval_cpu_set": EVAL_CPUS,
        "--shared_eval_timeout_seconds": 43200,
        "--cuda_memory_fraction": 0.55 if method == "l2d" else 0.9,
        "--ipc_timeout_seconds": 900, "--status_heartbeat_seconds": 30,
        "--safe_async_graph_clone_workers": 2, "--canary_eval_interval_shards": 0,
        "--early_stop_patience": 0,
    }.items():
        set_option(command, flag, value)
    for flag in ("--safe_graph_batch_pipeline", "--safe_dagger_teacher_overlap", "--shared_encoder_activation_checkpoint", "--clear_cuda_cache_after_update", "--use_eval"):
        switch(command, flag, True)
    return command


def prepare(suite, *, accept_new_semantics_warmup=False, snapshot=True):
    suite = Path(suite).resolve()
    if suite.exists():
        raise FileExistsError(f"Refusing to overwrite suite {suite}")
    if suite.parent != ROOT / "result/hkbz_train_logs":
        raise ValueError("Suite must be a direct child of result/hkbz_train_logs.")
    check_cpu_isolation()
    teachers = teacher_audit()
    sources = source_commands()
    suite.mkdir(parents=True)
    run_tag = suite.name
    code_root = suite / "code"
    source_hashes = snapshot_sources(code_root) if snapshot else {}
    if not snapshot:
        code_root = ROOT
    socket_path = f"/tmp/hkbz-p5b-{hashlib.sha256(run_tag.encode()).hexdigest()[:12]}.sock"
    env = yaml.safe_load((ROOT / "onpolicy/config/env_plane_pretrain.yaml").read_text())
    env.update({"resource_policy": "heuristic", "dataset_dir": str(TRAIN_DATA),
                "eval_dataset_dir": str(VALIDATION), "validation_dataset_dir": str(VALIDATION)})
    for key in ("jobs_path", "fixed_res_path", "mobile_res_path", "sites_path", "flights_path"):
        source = Path(migrate(env[key])).resolve()
        # Dataset workers replace all five paths with each selected case.
        # Historical YAMLs retain unused fallback paths which may not exist.
        if not source.is_file():
            continue
        frozen = code_root / source.relative_to(ROOT)
        if not frozen.is_file():
            raise FileNotFoundError(f"Missing frozen environment asset: {frozen}")
        env[key] = str(frozen)
    (suite / "env_frozen.yaml").write_text(yaml.safe_dump(env, sort_keys=False))
    lanes = []
    for method, gpu, cpus in zip(METHODS, range(4, 8), CPU_SETS):
        phases = []
        definitions = [("canary", "p5", 1), ("initial_bc", "n2", 1), ("warm_ppo", "m2", 1), ("departure_bc", "b0", 1)]
        definitions += [("formal", "p5", seed) for seed in (1, 2, 3)]
        outputs = {}
        for phase, source_key, seed in definitions:
            experiment = f"{run_tag}_{phase}_{method}_seed{seed}"
            if (RESULTS / experiment).exists():
                raise FileExistsError(RESULTS / experiment)
            command = runtime_command(sources[source_key], method=method,
                experiment=experiment, seed=seed, code_root=code_root, suite=suite,
                socket_path=socket_path)
            dependency = None
            if phase in {"initial_bc", "departure_bc"}:
                switch(command, "--plane_bc_only", True)
                set_option(command, "--plane_bc_pretrain_epochs", 4)
                set_option(command, "--hindsight_reward_mode", "team_time")
                set_option(command, "--hindsight_terminal_cmax_coef", 1.0)
                set_option(command, "--iga_potential_beta", 0.0)
                set_option(command, "--gamma", 1.0)
                remove(command, "--iga_potential_beta_schedule")
            if phase == "warm_ppo":
                dependency = outputs["initial_bc"] / "checkpoint_PlaneBC.pt"
            elif phase == "departure_bc":
                dependency = outputs["warm_ppo"] / "checkpoint_Best.pt"
            elif phase == "formal":
                dependency = outputs["departure_bc"] / "checkpoint_PlaneBC.pt"
            if dependency:
                set_option(command, "--checkpoint_dir", dependency)
                switch(command, "--resume_stage1", True)
                switch(command, "--reset_optimizers_on_resume", True)
                if phase == "formal":
                    switch(command, "--reset_value_normalizer_on_resume", True)
            if phase == "canary":
                for flag, value in {"--plane_bc_pretrain_epochs": 1, "--plane_bc_rollouts_per_epoch": 1,
                    "--num_episodes": 1, "--train_sampling_size": 60,
                    "--actor_warmup_shards": 0}.items():
                    set_option(command, flag, value)
            models = RESULTS / experiment / "run1/models"
            outputs[phase] = models
            path = suite / "commands" / (experiment + ".json")
            write_json(path, {"phase": phase, "method": method, "seed": seed,
                "source": source_key, "command": command,
                "initialization_mode": "new_semantics_budget_matched",
                "historical_semantics_difference": phase in {"initial_bc", "warm_ppo"}})
            phases.append({"phase": phase, "seed": seed, "experiment": experiment,
                "command_json": str(path), "command_sha256": sha256(path),
                "dependency": str(dependency) if dependency else None,
                "run_dir": str(models.parent), "timeout_seconds": 72 * 3600,
                "required_evaluations": 1 if phase.endswith("bc") else (2 if phase == "canary" else 9)})
        lanes.append({"method": method, "gpu": gpu, "cpu_set": cpus, "phases": phases,
                      "status_path": str(suite / "lanes" / f"{method}.json")})
    reference = {}
    for seed in (1, 2, 3):
        checkpoint = RESULTS / f"stage1_departure_reward_formal_dual_20260816_r1_formal_P5_team_time_potential_fixed_seed{seed}/run1/models/checkpoint_Best.pt"
        reference[str(seed)] = {"path": str(checkpoint), "sha256": sha256(checkpoint)}
    manifest = {
        "schema_version": 1, "scope": "stage1_p5_aligned_baselines", "run_tag": run_tag,
        "launch_authorized": bool(accept_new_semantics_warmup),
        "initialization_choice": "new_semantics_budget_matched" if accept_new_semantics_warmup else "pending_user_choice",
        "historical_initialization_difference": "N2/M2 warmup uses current verified departure teachers/potential, not the legacy environment. Stage budgets match; complete historical semantic equivalence is NOT claimed.",
        "code_root": str(code_root), "code_sha256": source_hashes,
        "python": sys.executable, "source_commands": {key: {"path": str(ROOT / path), "sha256": sha256(ROOT / path)} for key, path in SOURCE_PATHS.items()},
        "reference_main_checkpoints": reference,
        "teacher_dir": str(TEACHER), "teacher_count": len(teachers),
        "potential_path": str(POTENTIAL), "potential_sha256": sha256(POTENTIAL),
        "env_config_sha256": sha256(suite / "env_frozen.yaml"),
        "budget": {"formal_ppo_runs": 12, "formal_ppo_epochs": 8,
            "formal_case_attempts_per_run": 7680, "initial_bc_epochs": 4,
            "warm_ppo_epochs": 8, "departure_bc_epochs": 4,
            "independent_bc_initializations_per_method": 1,
            "case_budget_not_equal_effective_steps": True},
        "evaluator": {"gpu": 4, "cpu_set": EVAL_CPUS, "workers": 12,
            "cases": 60, "socket_path": socket_path, "cuda_memory_fraction": 0.35,
            "source_command_json": lanes[0]["phases"][0]["command_json"],
            "run_dir": str(suite / "shared_evaluator")},
        "lanes": lanes,
    }
    write_json(suite / "teacher_audit.json", teachers)
    write_json(suite / "manifest.json", manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-tag", required=True)
    parser.add_argument("--accept-new-semantics-warmup", action="store_true")
    args = parser.parse_args()
    if Path(args.run_tag).name != args.run_tag:
        raise ValueError("run-tag must be a single safe directory name")
    suite = ROOT / "result/hkbz_train_logs" / args.run_tag
    manifest = prepare(suite, accept_new_semantics_warmup=args.accept_new_semantics_warmup)
    print(json.dumps({"manifest": str(suite / "manifest.json"), "launch_authorized": manifest["launch_authorized"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
