#!/usr/bin/env python3
"""Select Stage2 H/F with matched IGA, then label the 600 train cases.

The controller is deliberately resumable.  Every arm is written to its own
directory and the underlying generator verifies/reuses completed cases.  Two
GPUs advance independent H/F arms concurrently.  Each arm is split into
multiple independent case shards on its GPU (the proven Stage-2 labelling
layout), while the two arms retain disjoint NUMA CPU pools.  Final train600
labelling uses both GPUs and a single global shard index space.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path
from typing import Mapping, Sequence


ROOT = Path(__file__).resolve().parents[3]
GENERATOR = (
    ROOT
    / "onpolicy/envs/HKBZ/experiment/generate_stage2_resource_iga_labels.py"
)
DEFAULT_PYTHON = Path(
    "/mnt/eb20f54b-f016-4501-a5b2-5dd6afff9d90/"
    "fanyixuan_files/conda/envs/maia-hkbz-cu124-20260903/bin/python3.11"
)
DEFAULT_OUTPUT = (
    ROOT
    / "result/hkbz_train_logs/"
    "stage2_supervised_hf_labels_20260901_r1"
)
TUNE_DATASET = (
    ROOT
    / "onpolicy/envs/HKBZ/dataset/"
    "fjsp_v3_resource_joint_eval_s20260811/joint/tune"
)
GATE_DATASET = (
    ROOT
    / "onpolicy/envs/HKBZ/dataset/"
    "fjsp_v3_resource_joint_eval_s20260811/joint/gate"
)
TRAIN_DATASET = (
    ROOT
    / "onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train"
)
CHECKPOINT = (
    ROOT
    / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo/"
    "stage1_departure_reward_formal_dual_20260816_r1_formal_"
    "P5_team_time_potential_fixed_seed3/run1/models/checkpoint_Best.pt"
)
SOURCE_COMMAND = (
    ROOT
    / "result/hkbz_train_logs/stage1_departure_reward_formal_dual_"
    "20260816_r1/commands/formal_P5.json"
)
HANDOFF = ROOT / "onpolicy/config/stage1_m2_handoff.json"


def _atomic_json(path: Path, payload: Mapping) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _arm_name(horizon: int, frontier: int) -> str:
    return f"H{int(horizon)}_F{int(frontier)}"


def _planning_contract(horizon: int, frontier: int) -> dict:
    return {
        "device_lookahead_dispatch": True,
        "device_lookahead_safety_margin": 60.0,
        "device_deadline_aware_dispatch": True,
        "device_future_intent_horizon": int(horizon),
        "device_future_intent_mode": "bounded_frontier",
        "device_frontier_max_requests": int(frontier),
        "resource_release_aware_eta": True,
        "device_lookahead_reservation_mode": "soft",
        "device_reservation_grace_seconds": 300.0,
        "device_departure_lookahead": True,
    }


def _base_command(args, dataset: Path, output: Path, gpu: int, h: int, f: int):
    return [
        str(args.python),
        "-u",
        str(GENERATOR),
        "--dataset-dir",
        str(dataset),
        "--output-dir",
        str(output),
        "--checkpoint",
        str(CHECKPOINT),
        "--source-command",
        str(SOURCE_COMMAND),
        "--source-command-key",
        "P5_team_time_potential_fixed_seed3",
        "--handoff",
        str(HANDOFF),
        "--device",
        f"cuda:{int(gpu)}",
        "--evaluation-tau",
        "0.3",
        "--device-lookahead-safety-margin",
        "60",
        "--device-deadline-aware-dispatch",
        "--device-future-intent-horizon",
        str(int(h)),
        "--device-future-intent-mode",
        "bounded_frontier",
        "--device-frontier-max-requests",
        str(int(f)),
        "--resource-release-aware-eta",
        "--device-lookahead-reservation-mode",
        "soft",
        "--device-reservation-grace-seconds",
        "300",
        "--device-departure-lookahead",
        "--population",
        str(int(args.population)),
        "--case-batch-size",
        str(int(args.case_batch_size)),
        "--max-generations",
        "100000",
        "--max-steps",
        "4000",
        "--seed",
        str(int(args.seed)),
    ]


def _run_logged(
    command: Sequence[str],
    *,
    log_path: Path,
    cpu_set: str,
    phase: str,
) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment.update({
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MPLCONFIGDIR": "/tmp/hkbz-stage2-hf-mpl",
        "PYTHONUNBUFFERED": "1",
    })
    full_command = ["taskset", "--cpu-list", cpu_set, *command]
    with log_path.open("a", encoding="utf-8") as log:
        log.write(
            f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] {phase}\n"
            + " ".join(full_command)
            + "\n"
        )
        log.flush()
        completed = subprocess.run(
            full_command,
            cwd=ROOT,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if completed.returncode:
        raise RuntimeError(
            f"{phase} exited {completed.returncode}; see {log_path}"
        )


def _run_iga(
    args,
    *,
    dataset: Path,
    output: Path,
    gpu: int,
    cpu_set: str,
    h: int,
    f: int,
    additional_budget: float,
    cumulative_budget: float,
    warm_start: Path | None = None,
    warm_budget: float = 0.0,
    shard_index: int = 0,
    shard_count: int = 1,
    summarize: bool = True,
    phase: str,
) -> None:
    command = _base_command(args, dataset, output, gpu, h, f)
    command.extend([
        "--time-budget-seconds",
        str(float(additional_budget)),
        "--cumulative-budget-seconds",
        str(float(cumulative_budget)),
        "--shard-index",
        str(int(shard_index)),
        "--shard-count",
        str(int(shard_count)),
    ])
    if warm_start is not None:
        command.extend([
            "--warm-start-dir",
            str(warm_start),
            "--warm-start-budget-seconds",
            str(float(warm_budget)),
        ])
    log_path = args.output_dir / "logs" / f"{phase}.log"
    _run_logged(command, log_path=log_path, cpu_set=cpu_set, phase=phase)
    if summarize:
        summary_command = [*command, "--summarize-only"]
        _run_logged(
            summary_command,
            log_path=log_path,
            cpu_set=cpu_set,
            phase=f"{phase}:summarize",
        )


def _summarize_iga(
    args,
    *,
    dataset: Path,
    output: Path,
    gpu: int,
    cpu_set: str,
    h: int,
    f: int,
    additional_budget: float,
    cumulative_budget: float,
    warm_start: Path | None = None,
    warm_budget: float = 0.0,
    phase: str,
) -> None:
    command = _base_command(args, dataset, output, gpu, h, f)
    command.extend([
        "--time-budget-seconds",
        str(float(additional_budget)),
        "--cumulative-budget-seconds",
        str(float(cumulative_budget)),
    ])
    if warm_start is not None:
        command.extend([
            "--warm-start-dir",
            str(warm_start),
            "--warm-start-budget-seconds",
            str(float(warm_budget)),
        ])
    command.append("--summarize-only")
    _run_logged(
        command,
        log_path=args.output_dir / "logs" / f"{phase}.log",
        cpu_set=cpu_set,
        phase=phase,
    )


def _case_metrics(output: Path) -> dict:
    records = []
    for path in sorted((output / "cases").glob("case_*.json")):
        record = json.loads(path.read_text(encoding="utf-8"))
        records.append({
            "case": path.stem,
            "makespan": float(record["makespan"]),
            "distribution": record.get("distribution"),
            "profile": record.get("profile"),
        })
    if not records:
        raise RuntimeError(f"No completed case records in {output}")
    values = [item["makespan"] for item in records]
    tail_count = max(1, math.ceil(0.10 * len(values)))
    by_distribution = {}
    for distribution in sorted({item["distribution"] for item in records}):
        subset = [
            item["makespan"]
            for item in records
            if item["distribution"] == distribution
        ]
        by_distribution[str(distribution)] = {
            "count": len(subset),
            "mean_makespan": statistics.mean(subset),
        }
    return {
        "case_count": len(records),
        "mean_makespan": statistics.mean(values),
        "std_makespan": statistics.pstdev(values),
        "median_makespan": statistics.median(values),
        "worst10_mean_makespan": statistics.mean(
            sorted(values, reverse=True)[:tail_count]
        ),
        "by_distribution": by_distribution,
        "cases": {item["case"]: item["makespan"] for item in records},
    }


def _rank(outputs: Mapping[str, Path]) -> list[dict]:
    rows = []
    for arm, output in outputs.items():
        metrics = _case_metrics(output)
        h_text, f_text = arm.split("_")
        rows.append({
            "arm": arm,
            "H": int(h_text[1:]),
            "F": int(f_text[1:]),
            **metrics,
        })
    rows.sort(key=lambda item: (
        item["mean_makespan"],
        item["worst10_mean_makespan"],
        item["H"],
        item["F"],
    ))
    return rows


def _run_arm_batch(args, tasks: Sequence[dict]) -> None:
    cpu_sets = args.cpu_sets
    gpus = args.gpus

    def execute(slot: int, task: Mapping) -> None:
        phase = str(task["phase"])
        shard_count = int(args.search_shards_per_gpu)

        def execute_shard(shard_index: int) -> None:
            shard_task = dict(task)
            shard_task.update({
                "shard_index": shard_index,
                "shard_count": shard_count,
                "summarize": False,
                "phase": f"{phase}_shard{shard_index:02d}",
            })
            _run_iga(
                args,
                gpu=gpus[slot],
                cpu_set=cpu_sets[slot],
                **shard_task,
            )

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=shard_count
        ) as shard_pool:
            shard_futures = [
                shard_pool.submit(execute_shard, shard_index)
                for shard_index in range(shard_count)
            ]
            for future in shard_futures:
                future.result()

        _summarize_iga(
            args,
            dataset=task["dataset"],
            output=task["output"],
            gpu=gpus[slot],
            cpu_set=cpu_sets[slot],
            h=task["h"],
            f=task["f"],
            additional_budget=task["additional_budget"],
            cumulative_budget=task["cumulative_budget"],
            warm_start=task.get("warm_start"),
            warm_budget=task.get("warm_budget", 0.0),
            phase=f"{phase}_summary",
        )

    # Preserve deterministic GPU assignment while keeping both slots busy.
    for offset in range(0, len(tasks), len(gpus)):
        wave = list(tasks[offset:offset + len(gpus)])
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=len(wave)
        ) as pool:
            futures = [
                pool.submit(execute, slot, task)
                for slot, task in enumerate(wave)
            ]
            for future in futures:
                future.result()


def _run_distributed_iga(
    args,
    *,
    dataset: Path,
    output: Path,
    h: int,
    f: int,
    additional_budget: float,
    cumulative_budget: float,
    warm_start: Path | None = None,
    warm_budget: float = 0.0,
    phase: str,
) -> None:
    """Run one teacher set across all GPUs with globally unique shards."""

    shards_per_gpu = int(args.label_shards_per_gpu)
    shard_count = shards_per_gpu * len(args.gpus)

    def execute_shard(gpu_slot: int, shard_index: int) -> None:
        _run_iga(
            args,
            dataset=dataset,
            output=output,
            gpu=args.gpus[gpu_slot],
            cpu_set=args.cpu_sets[gpu_slot],
            h=h,
            f=f,
            additional_budget=additional_budget,
            cumulative_budget=cumulative_budget,
            warm_start=warm_start,
            warm_budget=warm_budget,
            shard_index=shard_index,
            shard_count=shard_count,
            summarize=False,
            phase=f"{phase}_shard{shard_index:02d}",
        )

    worker_specs = [
        (gpu_slot, gpu_slot * shards_per_gpu + local_shard)
        for gpu_slot in range(len(args.gpus))
        for local_shard in range(shards_per_gpu)
    ]
    with concurrent.futures.ThreadPoolExecutor(
        max_workers=shard_count
    ) as pool:
        futures = [
            pool.submit(execute_shard, gpu_slot, shard_index)
            for gpu_slot, shard_index in worker_specs
        ]
        for future in futures:
            future.result()

    _summarize_iga(
        args,
        dataset=dataset,
        output=output,
        gpu=args.gpus[0],
        cpu_set=args.cpu_sets[0],
        h=h,
        f=f,
        additional_budget=additional_budget,
        cumulative_budget=cumulative_budget,
        warm_start=warm_start,
        warm_budget=warm_budget,
        phase=f"{phase}_summary",
    )


def _build_teacher_index(args, winner: Mapping, teacher_root: Path) -> Path:
    teacher_dir = teacher_root / "teachers"
    entries = {}
    makespans = []
    observed = 0
    labeled = 0
    for case_dir in sorted(path for path in TRAIN_DATASET.iterdir() if path.is_dir()):
        case = case_dir.name
        teacher_path = teacher_dir / f"{case}.json"
        if not teacher_path.is_file():
            raise RuntimeError(f"Missing final Stage2 teacher: {teacher_path}")
        teacher = json.loads(teacher_path.read_text(encoding="utf-8"))
        metadata = json.loads(
            (case_dir / "metadata.json").read_text(encoding="utf-8")
        )
        case_sha = (
            metadata.get("case_sha256")
            or metadata.get("fingerprints", {}).get("case_sha256")
        )
        coverage = teacher.get("intrinsic_ready_time_label_coverage", {})
        blocking = coverage.get("by_request_kind", {}).get(
            "blocking_wait", {}
        )
        if (
            teacher.get("schema_version") != 2
            or not teacher.get("completion_verified")
            or not teacher.get("completed")
            or teacher.get("case_sha256") != case_sha
            or teacher.get("resource_lookahead_contract")
            != _planning_contract(winner["H"], winner["F"])
            or int(coverage.get("labeled_request_count", 0)) <= 0
            or int(blocking.get("labeled", 0))
            != int(blocking.get("observed", 0))
        ):
            raise RuntimeError(f"Invalid final Stage2 label teacher: {teacher_path}")
        makespan = float(teacher["makespan"])
        makespans.append(makespan)
        observed += int(coverage["observed_request_count"])
        labeled += int(coverage["labeled_request_count"])
        entries[case] = {
            "case_sha256": case_sha,
            "teacher_sha256": _sha256(teacher_path),
            "makespan": makespan,
            "profile": metadata.get("profile"),
            "distribution": metadata.get("distribution"),
            "intrinsic_ready_time_label_coverage": float(
                coverage.get("coverage", 0.0)
            ),
        }
    index = {
        "schema_version": 2,
        "teacher_scope": "stage2_resource_policy",
        "teacher_method": "resource_iga_all",
        "environment_semantics_version": (
            "progressive-departure-r014-pipeline-v2"
        ),
        "intrinsic_ready_time_label_schema_version": 1,
        "intrinsic_ready_time_semantics": (
            "earliest_physical_ready_time_excluding_mobile_resource_delay"
        ),
        "teacher_dir": str(teacher_dir.resolve()),
        "source_teacher_dir": str(teacher_dir.resolve()),
        "dataset_dir": str(TRAIN_DATASET.resolve()),
        "frozen_plane_checkpoint_sha256": _sha256(CHECKPOINT),
        "frozen_plane_source_command_sha256": _sha256(SOURCE_COMMAND),
        "search_contract_version": 4,
        "resource_lookahead_contract": _planning_contract(
            winner["H"], winner["F"]
        ),
        "selected_H": int(winner["H"]),
        "selected_F": int(winner["F"]),
        "selection_report": str(
            (args.output_dir / "hf_search_report.json").resolve()
        ),
        "case_count": len(entries),
        "mean_teacher_cmax": statistics.mean(makespans),
        "intrinsic_ready_time_observed_request_count": observed,
        "intrinsic_ready_time_labeled_request_count": labeled,
        "intrinsic_ready_time_label_coverage": labeled / observed,
        "entries": entries,
        "generated_unix_time": time.time(),
    }
    path = teacher_root / "stage2_bc_teacher_index.json"
    _atomic_json(path, index)
    return path


def run(args) -> dict:
    args.output_dir.mkdir(parents=True, exist_ok=True)
    state_path = args.output_dir / "pipeline_state.json"
    _atomic_json(state_path, {
        "status": "running",
        "phase": "hf_screen_iga180",
        "started_unix_time": time.time(),
        "grid": {"H": [1, 2, 3], "F": [1, 2, 3, 4]},
        "gpus": args.gpus,
        "cpu_sets": args.cpu_sets,
        "search_shards_per_gpu": args.search_shards_per_gpu,
        "label_shards_per_gpu": args.label_shards_per_gpu,
        "case_batch_size": args.case_batch_size,
    })

    screen_outputs = {}
    screen_tasks = []
    for h in (1, 2, 3):
        for f in (1, 2, 3, 4):
            arm = _arm_name(h, f)
            output = args.output_dir / "hf_search" / "screen" / arm / "iga180"
            screen_outputs[arm] = output
            screen_tasks.append({
                "dataset": TUNE_DATASET,
                "output": output,
                "h": h,
                "f": f,
                "additional_budget": args.screen_budget,
                "cumulative_budget": args.screen_budget,
                "phase": f"screen_{arm}_iga180",
            })
    _run_arm_batch(args, screen_tasks)
    screen_ranking = _rank(screen_outputs)
    promoted = screen_ranking[: args.refine_count]

    _atomic_json(state_path, {
        "status": "running",
        "phase": "hf_refine_tune_iga1800",
        "screen_ranking": screen_ranking,
        "promoted": [item["arm"] for item in promoted],
    })
    refine_outputs = {}
    refine_tasks = []
    for row in promoted:
        arm = row["arm"]
        output = args.output_dir / "hf_search" / "refine" / arm / "iga1800"
        refine_outputs[arm] = output
        refine_tasks.append({
            "dataset": TUNE_DATASET,
            "output": output,
            "h": row["H"],
            "f": row["F"],
            "additional_budget": args.refine_budget - args.screen_budget,
            "cumulative_budget": args.refine_budget,
            "warm_start": screen_outputs[arm],
            "warm_budget": args.screen_budget,
            "phase": f"refine_{arm}_iga1800",
        })
    _run_arm_batch(args, refine_tasks)
    refine_ranking = _rank(refine_outputs)
    finalists = refine_ranking[: args.gate_count]

    _atomic_json(state_path, {
        "status": "running",
        "phase": "hf_gate_iga1800",
        "screen_ranking": screen_ranking,
        "refine_ranking": refine_ranking,
        "finalists": [item["arm"] for item in finalists],
    })
    gate_outputs = {}
    gate180_tasks = []
    for row in finalists:
        arm = row["arm"]
        output = args.output_dir / "hf_search" / "gate" / arm / "iga180"
        gate_outputs[arm] = {
            "iga180": output,
            "iga1800": args.output_dir / "hf_search" / "gate" / arm / "iga1800",
        }
        gate180_tasks.append({
            "dataset": GATE_DATASET,
            "output": output,
            "h": row["H"],
            "f": row["F"],
            "additional_budget": args.screen_budget,
            "cumulative_budget": args.screen_budget,
            "phase": f"gate_{arm}_iga180",
        })
    _run_arm_batch(args, gate180_tasks)
    gate1800_tasks = []
    for row in finalists:
        arm = row["arm"]
        gate1800_tasks.append({
            "dataset": GATE_DATASET,
            "output": gate_outputs[arm]["iga1800"],
            "h": row["H"],
            "f": row["F"],
            "additional_budget": args.refine_budget - args.screen_budget,
            "cumulative_budget": args.refine_budget,
            "warm_start": gate_outputs[arm]["iga180"],
            "warm_budget": args.screen_budget,
            "phase": f"gate_{arm}_iga1800",
        })
    _run_arm_batch(args, gate1800_tasks)
    gate_ranking = _rank({
        arm: outputs["iga1800"] for arm, outputs in gate_outputs.items()
    })
    winner = gate_ranking[0]
    report = {
        "status": "completed",
        "selection_rule": (
            "minimum matched-IGA mean Cmax on independent gate120; "
            "worst-10 mean, H, then F are deterministic tie-breakers"
        ),
        "screen_dataset": str(TUNE_DATASET),
        "gate_dataset": str(GATE_DATASET),
        "screen_budget_seconds": args.screen_budget,
        "refine_budget_seconds": args.refine_budget,
        "screen_ranking": screen_ranking,
        "refine_ranking": refine_ranking,
        "gate_ranking": gate_ranking,
        "winner": winner,
        "planning_contract": _planning_contract(winner["H"], winner["F"]),
        "completed_unix_time": time.time(),
    }
    _atomic_json(args.output_dir / "hf_search_report.json", report)

    label180 = args.output_dir / "stage2_bc_labels" / "iga180"
    label1800 = args.output_dir / "stage2_bc_labels" / "iga1800"
    _atomic_json(state_path, {
        "status": "running",
        "phase": "train600_labels_iga180",
        "winner": winner,
    })
    _run_distributed_iga(
        args,
        dataset=TRAIN_DATASET,
        output=label180,
        h=winner["H"],
        f=winner["F"],
        additional_budget=args.screen_budget,
        cumulative_budget=args.screen_budget,
        phase="labels_iga180",
    )

    _atomic_json(state_path, {
        "status": "running",
        "phase": "train600_labels_iga1800",
        "winner": winner,
    })
    _run_distributed_iga(
        args,
        dataset=TRAIN_DATASET,
        output=label1800,
        h=winner["H"],
        f=winner["F"],
        additional_budget=args.refine_budget - args.screen_budget,
        cumulative_budget=args.refine_budget,
        warm_start=label180,
        warm_budget=args.screen_budget,
        phase="labels_iga1800",
    )
    index_path = _build_teacher_index(args, winner, label1800)
    final = {
        "status": "completed",
        "phase": "completed",
        "winner": winner,
        "hf_search_report": str(
            (args.output_dir / "hf_search_report.json").resolve()
        ),
        "stage2_bc_teacher_dir": str((label1800 / "teachers").resolve()),
        "stage2_bc_teacher_index": str(index_path.resolve()),
        "completed_unix_time": time.time(),
    }
    _atomic_json(state_path, final)
    return final


def parse_args(argv: Sequence[str] | None = None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--python", type=Path, default=DEFAULT_PYTHON)
    parser.add_argument("--gpus", default="0,1")
    parser.add_argument(
        "--cpu-sets",
        default="0-35,72-107;36-71,108-143",
    )
    parser.add_argument("--population", type=int, default=20)
    parser.add_argument("--case-batch-size", type=int, default=16)
    parser.add_argument("--search-shards-per-gpu", type=int, default=4)
    parser.add_argument("--label-shards-per-gpu", type=int, default=8)
    parser.add_argument("--screen-budget", type=float, default=180.0)
    parser.add_argument("--refine-budget", type=float, default=1800.0)
    parser.add_argument("--refine-count", type=int, default=4)
    parser.add_argument("--gate-count", type=int, default=2)
    parser.add_argument("--seed", type=int, default=20260901)
    args = parser.parse_args(argv)
    args.output_dir = args.output_dir.expanduser().resolve()
    args.python = args.python.expanduser().resolve()
    args.gpus = [int(value) for value in args.gpus.split(",") if value]
    args.cpu_sets = [
        value.strip() for value in args.cpu_sets.split(";") if value.strip()
    ]
    if not args.gpus or len(args.gpus) != len(args.cpu_sets):
        parser.error("--gpus and --cpu-sets must have the same nonzero length")
    if (
        args.population < 2
        or args.case_batch_size < 1
        or args.search_shards_per_gpu < 1
        or args.label_shards_per_gpu < 1
    ):
        parser.error(
            "population must be >=2; batch size and shard counts must be positive"
        )
    if not 1 <= args.gate_count <= args.refine_count <= 12:
        parser.error("require 1 <= gate-count <= refine-count <= 12")
    if not 0.0 < args.screen_budget < args.refine_budget:
        parser.error("require 0 < screen-budget < refine-budget")
    return args


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    result = run(args)
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
