#!/usr/bin/env python3
"""Prepare and execute the approved data-only seven-epoch continuation."""
import argparse
import copy
import os
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.stage3_b0_large_batch import LargeBatchB0Suite
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
from onpolicy.utils.stage3_b0_protocol import (identity, comparison_contract, baseline_costs, queue)
from onpolicy.utils.stage3_b0_subset240 import (VERSION, AUTHORIZATION, START, FINAL, OVERLAYS,
    select_cases, data_contract, training_contract, capacity_reuse)
from onpolicy.utils.stage3_b0_throughput import continuation_plan, parent_manifest
from onpolicy.utils.stage3_research import (atomic_json, read_json, digest_file, digest_json, WORKSPACE_ROOT)


def prepare(plan_path):
    from onpolicy.scripts.train.queue_stage3_b0_subset240 import verify_staged
    from onpolicy.scripts.train.queue_stage3_b0_env60 import verify_commit
    plan = read_json(plan_path)
    verify_staged(plan)
    parent_root, output = Path(plan['current_root']), Path(plan['output_root'])
    source = Path(plan['staging_root'])/'source'
    if ROOT != source or output.exists():
        raise ValueError('Prepare once, from the tested staged source into a new directory')
    parent_path, commit_path = parent_root/'manifest.json', parent_root/f'train/commits/episodes_{START:06d}.json'
    if digest_file(parent_path) != plan['parent_manifest_sha256']:
        raise ValueError('Parent manifest changed while waiting')
    parent = read_json(parent_path)
    commit = verify_commit(parent, commit_path, START)
    for relative, checksum in plan['files'].items():
        dst = output/'source'/relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source/relative, dst)
        if digest_file(dst) != checksum:
            raise ValueError('Source changed during subset snapshot')
    m = copy.deepcopy(parent)
    m.pop('manifest_sha256')
    m.update(root=str(output), created_unix=time.time(), training=training_contract(),
             subset_training=data_contract(parent['splits']['train_full600']),
             code={'files': plan['files'], 'sha256': digest_json(plan['files'])})
    m['splits']['train_subset240'] = select_cases(parent['splits']['train_full600'])
    m['execution'].update(code_root=str(output/'source'), workspace_root=str(WORKSPACE_ROOT))
    for key in ('path', 'manifest'):
        m['source'][key] = str(output/'source'/Path(parent['source'][key]).relative_to(parent_root/'source'))
    m['resources']['validator_queue'] = str(output/'validator')
    evidence = {str(parent_root/name): digest_file(parent_root/name) for name in
        ('training_admission.json', 'sampling_admission.json', 'baselines.json', 'verification.json')}
    # These record immutable request IDs/checkpoint identity. Pending results stay
    # in their old queue, with their old source and protocol, until fully drained.
    inherited = {str(parent_root/kind/'e000960.json'): digest_file(parent_root/kind/'e000960.json')
        for kind in ('epochs', 'mechanism')}
    m['throughput'].update(parent_manifest=str(parent_path), parent_manifest_sha256=digest_file(parent_path),
        resume_commit=str(commit_path), resume_commit_sha256=digest_file(commit_path),
        start_episodes=START, start_actor_updates=commit['actual_actor_updates'], parent_evidence=evidence,
        snapshot_overlay_files=list(OVERLAYS), inherited_epoch_evidence=inherited)
    m['throughput']['schedule_sha256'] = digest_json(continuation_plan(m))
    m['validator_handoff'] = {'parent_root': str(parent_root),
        'parent_protocol_sha256': parent['manifest_sha256'], 'transition': str(plan_path.resolve()),
        'transition_sha256': digest_file(plan_path),
        'policy': 'train immediately; old pool drains under old protocol; then one replacement pool'}
    comparison = comparison_contract(m['splits'], m['baseline_reference'], training=m['training'])
    m['comparison_sha256'] = digest_json(comparison)
    m['input_files'].update({str(parent_path): digest_file(parent_path), str(commit_path): digest_file(commit_path),
        str(plan_path.resolve()): digest_file(plan_path), **evidence, **inherited})
    m['material_passport'].update(origin_date='2026-09-13',
        verification_status='source-bound CPU verification; inherited full ENV60 capacity', version_label=VERSION)
    m['manifest_sha256'] = identity(m)
    parent_manifest(m)
    atomic_json(output/'manifest.json', m, overwrite=False)
    atomic_json(output/'comparison_contract.json', comparison, overwrite=False)
    atomic_json(output/'schedule.json', {'groups': continuation_plan(m)}, overwrite=False)
    atomic_json(output/'baselines.json', {'inherited': True, 'path': str(parent_root/'baselines.json'),
        'sha256': evidence[str(parent_root/'baselines.json')],
        'note': 'Full780 reference/paired evidence retained; active gradient-bearing split is train_subset240'}, overwrite=False)
    sampling = read_json(parent_root/'sampling_admission.json')
    atomic_json(output/'sampling_admission.json', {'selected_tau': sampling['selected_tau'],
        'protocol_sha256': m['manifest_sha256'], 'inherited': True,
        'parent_evidence': {'path': str(parent_root/'sampling_admission.json'),
                            'sha256': evidence[str(parent_root/'sampling_admission.json')]}}, overwrite=False)
    admission = capacity_reuse(m)
    atomic_json(output/'training_admission.json', admission, overwrite=False)
    receipt_path = Path(plan['staging_root'])/'verification/receipt.json'
    receipt = read_json(receipt_path)
    atomic_json(output/'verification.json', {'passed': True, 'code_sha256': m['code']['sha256'],
        'manifest_sha256': m['manifest_sha256'], 'reports': {str(receipt_path): digest_file(receipt_path), **receipt['reports']},
        'scope': 'source-bound subset/resume/queue regressions; unchanged numerical files reuse passed full ENV60 capacity'}, overwrite=False)
    atomic_json(output/'migration_receipt.json', {'authorization': AUTHORIZATION,
        'parent': str(parent_path), 'commit': str(commit_path), 'commit_sha256': digest_file(commit_path),
        'committed_episodes_preserved': START, 'actor_updates_preserved': commit['actual_actor_updates'],
        'remaining_epochs': 7, 'remaining_trajectories': 2688, 'final_training_episodes': FINAL,
        'data_selection': m['subset_training'], 'unchanged_execution': m['throughput']['version'],
        'configured_envs_per_rank': 60, 'actual_trajectories_per_rank': 48,
        'backward_batch_per_rank': 12, 'actual_optimizer_steps_per_group': 8,
        'all_optimizer_normalizer_rng_states_required': True, 'no_diagnostic_initialization': True,
        'old_artifacts_preserved': True, 'shared_validator_handoff': m['validator_handoff'],
        'capacity_admission': admission['admission_kind']}, overwrite=False)
    print(output/'manifest.json', flush=True)


def handoff_location(m, state, *, now=None):
    """A short, explicit service handoff is not an unbounded validator bypass."""
    now = time.time() if now is None else now
    if (state.get('protocol_sha256') != m['manifest_sha256']
            or state.get('parent_protocol_sha256') != m['validator_handoff']['parent_protocol_sha256']
            or state.get('transition_sha256') != m['validator_handoff']['transition_sha256']):
        raise ValueError('Validator handoff identity changed')
    phase = state.get('phase')
    if phase == 'new_pool_active':
        return Path(m['root'])
    if (phase not in ('draining_parent_pool', 'switching_pool')
            or not 0 <= now-state.get('heartbeat_unix', 0) < 180):
        raise RuntimeError('Validator handoff failed/stalled; retain checkpoints without retry')
    if phase == 'switching_pool':
        if not 0 <= now-state.get('switch_started_unix', 0) < 180:
            raise RuntimeError('Single-validator-pool handoff exceeded its bounded startup window')
        return None
    return Path(m['validator_handoff']['parent_root'])


class Subset240B0Suite(LargeBatchB0Suite):
    def check_validator_pool(self, root=None):
        state = read_json(self.root/'validator_handoff.json')
        location = handoff_location(self.m, state)
        if state['phase'] != 'new_pool_active':
            os.kill(state['pid'], 0)
        if location is not None:
            super().check_validator_pool(location)

    def run_private(self):
        if (self.root/'status.json').exists():
            raise FileExistsError('No implicit subset controller restart')
        os.sched_setaffinity(0, self.plan['controller'])
        with ProgressHeartbeat(self.root/'status.json', phase='subset_resume_verification',
                               formal_training_started=False) as hb:
            try:
                baseline_costs(self.m)
                actual = capacity_reuse(self.m)
                if read_json(self.root/'training_admission.json') != actual:
                    raise ValueError('Inherited admission changed')
                self.check_validator_pool()
                hb.update(phase='subset240_training', formal_training_started=True,
                    active_unique_training_cases=240, episodes_per_data_epoch=384,
                    completed_parent_epochs=1, remaining_data_epochs=7, final_training_episodes=FINAL,
                    parent_episodes=START, configured_envs_per_rank=60,
                    actual_trajectories_per_rank=48, backward_batch_per_rank=12)
                results = self.group('train', 'full', hb, world=8, batch=480)
                if any(r.get('paused') for r in results):
                    hb.update(phase='paused_at_commit')
                    return
                # Parent epoch1 is a valid candidate, owned by the old manifest.
                # Wait for it if training finished before the handoff completed.
                parent = parent_manifest(self.m)
                for kind in ('epochs', 'mechanism'):
                    record = read_json(Path(parent['root'])/kind/'e000960.json')
                    while any(queue(parent).poll(r) is None for r in record['requests']):
                        self.check(hb)
                        hb.update(phase='awaiting_original_epoch1_validation')
                        time.sleep(5)
                hb.update(phase='checkpoint_selection')
                self.finish_training(hb)
                hb.update(phase='training_complete_confirmation_sealed')
            finally:
                self.stop_owned()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-plan', type=Path, required=True)
    args = parser.parse_args()
    prepare(args.prepare_plan)


if __name__ == '__main__':
    main()
