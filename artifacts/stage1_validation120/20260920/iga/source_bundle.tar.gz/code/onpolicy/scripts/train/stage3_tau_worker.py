"""Training loop for the full600 tau study; shared bridge workers do evaluation."""
import gc
from pathlib import Path
import time

import torch

from onpolicy.scripts.train.stage3_rl_bridge_worker import (
    make_engine, collect, save_rollouts, metadata, submit_evaluation, attach_journal,
)
from onpolicy.utils.stage3_tau import training_plan, resume_cursor, temperature_state
from onpolicy.utils.stage3_rl_bridge import baseline_costs
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json


def train(args, m, sync, hb):
    root, output = Path(m['root']), args.output
    if not read_json(root/'training_admission.json')['passed'] or args.phase != 'full':
        raise ValueError('Full600 training requires the completed technical admission')
    plan = training_plan(m, args.world_size)
    plan_sha = digest_json(plan)
    costs = baseline_costs(m)
    runner = make_engine(m, args.arm, 60)
    cursor = 0
    try:
        if args.resume_commit:
            commit = read_json(args.resume_commit)
            cursor = resume_cursor(m, args.arm, commit, args.world_size)
            entry = commit['ranks'][args.rank % commit['world_size']]
            if digest_file(entry['checkpoint']) != entry['sha256']:
                raise ValueError('Committed checkpoint checksum changed')
            payload = runner.resume(entry['checkpoint'], protocol_sha256=m['manifest_sha256'])
            if (payload['diagnostic_only'] or payload['rank'] != entry['rank']
                    or payload['world_size'] != commit['world_size'] or payload['phase'] != 'full'
                    or payload['schedule_sha256'] != commit['schedule_sha256']
                    or payload['training_episodes'] != commit['training_episodes']
                    or payload['temperature_state'] != commit['temperature_state']
                    or payload['next_group'] != sum(b['training_episodes'] <= commit['training_episodes']
                                                   for b in training_plan(m, commit['world_size']))):
                raise ValueError('Diagnostic, incomplete or mismatched training checkpoint')
            atomic_json(output/f'resume_e{args.until_epochs}.json', dict(parent_commit=str(args.resume_commit),
                old_world=commit['world_size'], new_world=args.world_size, source_rank=entry['rank'],
                next_group=cursor, temperature_state=payload['temperature_state'],
                global_optimizer_trajectories=12*args.world_size,
                bitwise_equivalence_across_topologies_claimed=False), overwrite=False)
        sync.assert_replicas(runner)
        for batch in plan[cursor:]:
            if batch['epoch'] > args.until_epochs:
                break
            if any(sync.gather((root/'PAUSE_AFTER_COMMIT').exists())):
                atomic_json(output/f'paused_{args.until_epochs}.json', dict(paused=True,
                    training_episodes=runner.committed_episodes, next_group=batch['index']), overwrite=False)
                return
            while sum(1 for _ in (root/'validator/pending').glob('*.json')) > 640:
                hb.update(event='shared_validator_backpressure', next_group=batch['index'])
                time.sleep(5)
            before = batch['training_episodes']-batch['batch_size']
            if runner.committed_episodes != before:
                raise ValueError('Rollout cursor is not the last committed temperature boundary')
            state = runner.set_progress(before)
            if any(s != state for s in sync.gather(state)):
                raise ValueError('Cross-rank temperature mismatch')
            torch.cuda.reset_peak_memory_stats()
            begin = time.time()
            hb.update(event='batch_start', phase='full', arm=args.arm, epoch=batch['epoch'],
                batch_index=batch['index'], training_episodes=before, sampling_tau=state['sampling_tau'],
                actual_actor_updates=runner.policy_updates, trajectories_per_rank=60)
            rows = collect(runner, batch['shards'][args.rank], hb)
            rollout_seconds = time.time()-begin
            rollout_memory = dict(allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                                  reserved_gib=torch.cuda.max_memory_reserved()/2**30)
            stem = f'e{batch["training_episodes"]:06d}'
            save_rollouts(output/f'rollouts/{stem}.json', rows,
                metadata(m, args.arm, diagnostic_only=False, phase='full', rank=args.rank,
                         temperature_state=state, decision_stats=runner.last_decision_stats))
            attach_journal(runner, output/f'updates/{stem}_attempts.jsonl')
            torch.cuda.reset_peak_memory_stats()
            begin = time.time()
            result = runner.update(rows, 'source', costs, epochs=2, chunk=8, heartbeat=hb,
                distributed=sync, microbatch_size=12, optimizer_step_per_microbatch=True)
            result.update(rollout_seconds=rollout_seconds, update_seconds=time.time()-begin,
                rollout_memory=rollout_memory,
                replay_storage=runner.replay_storage_report(),
                update_memory=dict(allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                                   reserved_gib=torch.cuda.max_memory_reserved()/2**30))
            atomic_json(output/f'updates/{stem}.json', result, overwrite=False)
            if result['accepted_actor_steps'] == 0:
                raise RuntimeError('No accepted PPO step: schedule not advanced; last commit retained')
            model_sha = sync.assert_replicas(runner)
            episodes = batch['training_episodes']
            # Rollout/replay lease has ended. Save the NEXT batch's temperature.
            next_state = runner.set_progress(episodes)
            checkpoint = output/f'models/{stem}.pt'
            checksum = runner.save(checkpoint, **metadata(m, args.arm, diagnostic_only=False,
                phase='full', rank=args.rank, world_size=args.world_size, training_episodes=episodes,
                next_group=batch['index']+1, schedule_sha256=plan_sha))
            entries = sync.gather(dict(rank=args.rank, checkpoint=str(checkpoint), sha256=checksum,
                                       state_sha256=model_sha))
            if args.rank == 0:
                commit = root/'full'/args.arm/f'commits/{stem}.json'
                atomic_json(commit, dict(manifest_sha256=m['manifest_sha256'], arm=args.arm, phase='full',
                    world_size=args.world_size, ranks=entries, schedule_sha256=plan_sha,
                    training_episodes=episodes, policy_updates=runner.policy_updates,
                    temperature_state=next_state), overwrite=False)
                if batch['epoch_tail']:
                    requests = {split: submit_evaluation(m, checkpoint, args.arm, episodes, 'full', split=split)
                                for split in ('validation', 'tune')}
                    atomic_json(root/'full'/args.arm/f'epochs/e{batch["epoch"]:02d}.json', dict(
                        checkpoint=str(checkpoint), checkpoint_sha256=checksum, requests=requests,
                        training_episodes=episodes, policy_updates=runner.policy_updates,
                        temperature_state=next_state, commit=str(commit)), overwrite=False)
            sync.barrier()
            hb.update(event='batch_committed', phase='full', arm=args.arm, training_episodes=episodes,
                sampling_tau=next_state['sampling_tau'], actual_actor_updates=runner.policy_updates,
                rollout_seconds=rollout_seconds, update_seconds=result['update_seconds'])
            del rows
            runner.release_replay()
            gc.collect()
        atomic_json(output/f'result_epoch{args.until_epochs}.json', dict(completed=True,
            training_episodes=runner.committed_episodes, policy_updates=runner.policy_updates,
            temperature_state=temperature_state(args.arm, runner.committed_episodes)), overwrite=False)
    finally:
        runner.close()
