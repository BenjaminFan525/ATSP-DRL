#!/usr/bin/env python3
"""One CPU diagnostic: real environment pools, memory and reset/trace parity."""
import argparse
import gc
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import psutil
from onpolicy.runner.shared.stage3_b0_engine import B0Engine
from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool
from onpolicy.scripts.train.run_stage3_sampling_audit import trajectory_record
from onpolicy.utils.stage3_distributed import state_digest
from onpolicy.utils.stage3_research import WORKSPACE_ROOT, case_record, atomic_json, digest_file


def memory():
    rows = []
    for process in [psutil.Process(), *psutil.Process().children(recursive=True)]:
        try:
            info = process.memory_full_info()
            rows.append({'pid': process.pid, 'pss': info.pss, 'uss': info.uss, 'rss': info.rss})
        except psutil.NoSuchProcess:
            pass
    return {'processes': rows, 'total_pss_gib': sum(r['pss'] for r in rows)/2**30,
            'total_uss_gib': sum(r['uss'] for r in rows)/2**30}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--start-method', choices=['spawn', 'forkserver'], required=True)
    parser.add_argument('--width', type=int, choices=(24, 36, 48, 60), default=24)
    parser.add_argument('--batched-inference', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Keep each diagnostic attempt separate')
    runner = B0Engine(ROOT/'artifacts/stage2_frozen/20260912/manifest.json', width=args.width,
                      device='cpu', create_environments=False)
    if args.batched_inference:
        from onpolicy.utils.stage3_batched_sampling import BATCHING_VERSION
        runner.stochastic_batching = BATCHING_VERSION
    start = time.time()
    runner.pool = EnvironmentPool(args.width, start_method=args.start_method)
    original_call = runner.pool.call
    def prefix_fixture(commands):
        result = original_call(commands)
        for i, command, _ in commands:
            if command == 'summary':
                result[i] = {**result[i], 'actual_completed': result[i]['completed'],
                             'completed': True, 'synthetic_prefix_fixture': True}
        return result
    runner.pool.call = prefix_fixture
    try:
        case = case_record(WORKSPACE_ROOT/'onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train/case_0341')
        records, samples = [], []
        for batch in range(2):
            rows = runner.rollout([case]*args.width,
                list(range(2026091301, 2026091301+args.width)), retain=True, max_steps=2)
            for row in rows:
                row['completed'] = row['actual_completed']
            records.append({'traces': [trajectory_record(r) for r in rows],
                'behavior_sha256': state_digest([(r['policy_updates'], r['exploration'],
                    [(s['old_logp'], s['action'], s['mask'], s['hidden']) for s in r['states']]) for r in rows])})
            replay = runner.replay_metrics(rows) if args.batched_inference else None
            if replay is not None:
                assert replay['max_logp_error'] <= .002
            samples.append(memory())
            assert all(p.is_alive() for p in runner.pool.processes)
            del rows
            gc.collect()
        assert records[0] == records[1], 'Same seeds/reset must reproduce the same prefix'
        atomic_json(args.output, {'passed': True, 'diagnostic_only': True, 'prefix_steps': 2,
            'full_capacity_admission': False, 'actor_updates': runner.policy_updates,
            'start_method': args.start_method, 'live_environments': len(runner.pool.processes),
            'seconds': time.time()-start, 'records': records, 'memory': samples,
            'inference': runner.last_rollout_inference,
            'replay': replay,
            'probe_code_files': {p: digest_file(ROOT/p) for p in (
                'onpolicy/runner/shared/stage3_research_engine.py',
                'onpolicy/runner/shared/stage3_b0_engine.py',
                'onpolicy/utils/stage3_environment_preload.py',
                'onpolicy/envs/HKBZ/environment.py',
                'onpolicy/utils/stage3_batched_sampling.py',
                'onpolicy/algorithms/utils/ptr_actor.py',
                'onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py')},
            'pid': os.getpid()}, overwrite=False)
        print(args.output, flush=True)
    except BaseException:
        import traceback
        atomic_json(args.output.with_suffix('.failure.json'), {
            'passed': False, 'diagnostic_only': True, 'error': traceback.format_exc()}, overwrite=False)
        raise
    finally:
        runner.close()


if __name__ == '__main__':
    main()
