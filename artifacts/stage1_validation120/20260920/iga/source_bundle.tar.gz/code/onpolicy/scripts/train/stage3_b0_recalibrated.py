"""Fresh machine-local B0 evidence and strict pairs, with ONE elastic validator pool."""
import os
from pathlib import Path

from onpolicy.scripts.train.stage3_b0_accelerated import AcceleratedB0Suite
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
from onpolicy.utils.stage3_b0_protocol import (
    B0_SHA, EVALUATION, LOCAL_BASELINE, TRAINING, verify, submit, submit_mechanism, baseline_costs,
)
from onpolicy.utils.stage3_b0_acceleration import complete_rows
from onpolicy.utils.stage3_b0_recalibration import (
    fresh_initialization, evidence_identity, audit_result, strict_pairs, paired_cases,
    seal_pairing, diagnostic_costs, historical_report,
)
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json


class RecalibratedB0Suite(AcceleratedB0Suite):
    def __init__(self, manifest, manifest_path):
        super().__init__(manifest, manifest_path)
        self.calibration_requests = {}
        self.calibration_results = {}
        self.paired_audited = set()
        self.calibration_rows = {False: {}, True: {}}
        self.calibration_evidence = {}

    def enqueue(self, checkpoint, cases, split, start, *, private, tag):
        expected = evidence_identity(self.m, cases, digest_file(checkpoint), private)
        request = submit(self.m, checkpoint, "C_PRIVATE" if private else "B0", 0,
            "F_PRIVATE" if private else "NATIVE", split=split, start=start, cases_override=cases,
            native=not private, raw_initialization=private, tag=tag)
        self.calibration_requests[request] = (cases, expected, private)
        return request

    def check_available_native_tune(self):
        """Opt-in replacement: early exact LOCAL pairs; historical costs are report-only."""
        for request, (cases, expected, private) in self.calibration_requests.items():
            if request in self.calibration_results:
                continue
            result = self.queue.poll(request)
            if result is None:
                continue
            rows = audit_result(self.m, result, cases, expected)
            self.calibration_results[request] = rows
            path = self.queue.root / "results" / (request + ".json")
            self.calibration_evidence[str(path)] = digest_file(path)
            for row in rows:
                if row["case_id"] in self.calibration_rows[private]:
                    raise ValueError("Duplicate local calibration evidence")
                self.calibration_rows[private][row["case_id"]] = row
        common = (self.calibration_rows[False].keys() & self.calibration_rows[True].keys()) - self.paired_audited
        if common:
            cases = [c for c in paired_cases(self.m) if c["path"] in common]
            report = strict_pairs([self.calibration_rows[False][c["path"]] for c in cases],
                                  [self.calibration_rows[True][c["path"]] for c in cases], cases)
            if not report["passed"]:
                atomic_json(self.root / "local_pairing_early_failure.json", {
                    **report, "partial_audit_only": True, "formal_training_admitted": False}, overwrite=False)
                raise RuntimeError(f"Strict local B0 pairing failed: {report['differences']}; no RL admitted")
            self.paired_audited.update(common)

    def collected(self, requests):
        self.check_available_native_tune()
        return [row for request in requests for row in self.calibration_results[request]]

    def run_private(self):
        if (self.root / "status.json").exists():
            raise FileExistsError("Use a fresh calibration run; preserve all previous results")
        os.sched_setaffinity(0, self.plan["controller"])
        with ProgressHeartbeat(self.root / "status.json", phase="local_b0_initialization",
                               formal_training_started=False) as hb:
            try:
                hb.update(workspace_advisory=verify(self.m), baseline_reference=LOCAL_BASELINE)
                init = fresh_initialization(self.m)
                self.request_pool(hb, "boost", list(range(8)))
                native, private = [], []
                count = self.m["acceleration"]["preflight_chunk_size"]
                diag = self.m["diagnostic"]["cases32"]
                hb.update(phase="local_TrainDiag32_strict_pairing")
                for start in range(0, len(diag), count):
                    block = diag[start:start + count]
                    native.append(self.enqueue(self.m["source"]["path"], block, "train_full600", start,
                                               private=False, tag="_local_diag"))
                    private.append(self.enqueue(init, block, "train_full600", start,
                                                private=True, tag="_local_diag"))
                self.wait_requests(native + private, hb)
                seal_pairing(self.m, self.collected(native), self.collected(private), diag,
                             "local_diagnostic_pairing.json", dict(self.calibration_evidence))
                costs32 = diagnostic_costs(self.m)
                gpus = self.m["acceleration"]["temperature_gpus"]
                self.request_pool(hb, "boost", [g for g in range(8) if g not in gpus])
                diag_paths = {c["path"] for c in diag}
                for split in ("tune", "validation", "train_full600"):
                    cases = self.m["splits"][split]
                    for start in range(0, len(cases), count):
                        block = cases[start:start + count]
                        missing = [c for c in block if c["path"] not in diag_paths]
                        if missing:
                            native.append(self.enqueue(self.m["source"]["path"], missing, split, start,
                                                       private=False, tag="_local_calibration"))
                        if split != "train_full600":
                            private.append(self.enqueue(init, block, split, start,
                                                        private=True, tag="_local_pair"))
                atomic_json(self.root / "preflight_plan.json", {"native_requests": native,
                    "private_initialization_requests": private, "fresh_baseline_cases": 780,
                    "fresh_strict_pair_cases": 212, "reused_trajectory_count": 0,
                    "temperature_trajectories": 256, "temperature_physical_gpus": gpus,
                    "capacity_worlds": [8], "historical_release": "preserved; report only"}, overwrite=False)
                hb.update(phase="fresh_temperature_and_local_baseline_parallel", strict_pairs_passed=32)
                samples = self.temperature_tasks(hb)
                temperatures = {}
                for tau in TRAINING["temperature_candidates"]:
                    rows = [r for sample in samples for r in sample["temperatures"][str(tau)]["cases"]]
                    if len(rows) != 128:
                        raise ValueError("Incomplete fresh temperature diagnostic")
                    temperatures[str(tau)] = {"trajectories": len(rows),
                        "mean_cost": sum(r["makespan"] for r in rows) / len(rows),
                        "positive_fraction": sum(r["makespan"] < costs32[r["case_id"]] for r in rows) / len(rows)}
                tau = min(TRAINING["temperature_candidates"], key=lambda t: (temperatures[str(t)]["mean_cost"], t))
                archives = {str(p): digest_file(p) for p in (self.root / "sampling/temperatures").glob("rank*/tau*")
                            if p.suffix in (".json", ".npz")}
                atomic_json(self.root / "sampling_admission.json", {"selected_tau": tau, "temperatures": temperatures,
                    "protocol_sha256": self.m["manifest_sha256"], "comparison_sha256": self.m["comparison_sha256"],
                    "archives": archives, "rule": "lower mean sampling cost on fixed TrainDiag32, ties lower tau",
                    "used_validation": False, "reward_gain_gate": False, "total_diagnostic_trajectories": 256,
                    "local_diagnostic_pairing_sha256": digest_file(self.root / "local_diagnostic_pairing.json")}, overwrite=False)
                self.request_pool(hb, "boost", list(range(1, 8)))
                hb.update(phase="fresh_single_gpu_reference_and_local_baseline_parallel")
                reference = self.group("reference", "single", hb, world=1)[0]
                self.request_pool(hb, "boost", list(range(8)))
                hb.update(phase="complete_local_780_baselines_and_212_strict_pairs")
                self.wait_requests(native + private, hb)
                rows, private_rows = self.collected(native), self.collected(private)
                cases = [c for s in ("train_full600", "validation", "tune") for c in self.m["splits"][s]]
                complete_rows(rows, cases)
                costs = {r["case_id"]: r["makespan"] for r in rows}
                atomic_json(self.root / "historical_release_comparison.json", historical_report(self.m, costs), overwrite=False)
                pair_paths = {c["path"] for c in paired_cases(self.m)}
                proof = seal_pairing(self.m, [r for r in rows if r["case_id"] in pair_paths], private_rows,
                    paired_cases(self.m), "local_pairing_admission.json", dict(self.calibration_evidence),
                    baseline_cases_sha256=digest_json(rows), baseline_costs_sha256=digest_json(costs))
                atomic_json(self.root / "baselines.json", {"costs": costs, "costs_sha256": digest_json(costs),
                    "cases": rows, "source_sha256": B0_SHA, "protocol_sha256": self.m["manifest_sha256"],
                    "evaluation": EVALUATION, "baseline_reference": LOCAL_BASELINE,
                    "local_pairing_sha256": digest_file(proof)}, overwrite=False)
                baseline_costs(self.m)
                self.request_pool(hb, "steady")
                diagnostic = submit_mechanism(self.m, init, 0)
                atomic_json(self.root / "mechanism/e000000.json", {"requests": diagnostic,
                    "checkpoint_sha256": digest_file(init), "training_episodes": 0}, overwrite=False)
                self.complete_admission(hb, rows, init, reference=reference)
            finally:
                self.stop_owned()
