#!/usr/bin/env python3
"""Prepare/seal/run the private B0 route; supervise ONE independent validator pool."""
import argparse
import fcntl
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.utils.stage3_b0_protocol import (
    SCHEMA, HISTORY, B0_SHA, TRAINING, EVALUATION, PLANNING, identity, comparison_contract,
    verify, queue, submit, submit_split, submit_mechanism, baseline_costs, register_peer, MECHANISM, LOCAL_BASELINE,
)
from onpolicy.utils.stage3_research import (
    TRAIN_ROOT, EVAL_ROOT, case_record, read_json, atomic_json, digest_file, digest_json, paired_summary,
)
from onpolicy.utils.stage3_full_data import schedule
from onpolicy.utils.stage3_full_policy import resource_plan
from onpolicy.utils.stage3_representation import discover_topology, risk_pass
from onpolicy.utils.stage3_numerics import RUNTIME
from onpolicy.scripts.train.run_stage3_full_policy import FullSuite, compare_checkpoints
from onpolicy.scripts.train.run_stage3_representation import Suite
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat


def prepare(args):
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError("Use a NEW B0 run directory; do not overwrite old experiments")
    local = getattr(args, "recalibrate_local_b0", False)
    if local and getattr(args, "accelerated_from", None):
        raise ValueError("Local recalibration requires fresh evidence, not --accelerated-from")
    prior = read_json(args.prior)
    bundle_path = ROOT / "artifacts/stage2_frozen/20260912/manifest.json"
    bundle = read_json(bundle_path)
    if bundle["files"]["b0"]["sha256"] != B0_SHA:
        raise ValueError("Unexpected Stage2 B0 release")
    splits = {
        "train_full600": [case_record(p) for p in sorted(TRAIN_ROOT.glob("case_*"))],
        "validation": [case_record(p) for p in sorted((ROOT / "onpolicy/envs/HKBZ/dataset/fjsp_v3_stage1_v2_eval_s20260803/validation").glob("case_*"))],
        "tune": [case_record(p) for p in sorted((EVAL_ROOT / "tune").glob("case_*"))],
        "confirmation": [case_record(c["path"]) for c in prior["splits"]["confirmation"]],
    }
    if {k: len(v) for k, v in splits.items()} != {"train_full600": 600, "validation": 120, "tune": 60, "confirmation": 120}:
        raise ValueError("Expected 600/120/60/120 case splits")
    from onpolicy.scripts.train.run_stage3_full_data import physical_identity
    physical = {k: {physical_identity(c) for c in v} for k, v in splits.items()}
    if any(len(physical[k]) != len(splits[k]) for k in splits):
        raise ValueError("Duplicate physical cases")
    for a, b in (("train_full600", "validation"), ("train_full600", "tune"),
                 ("train_full600", "confirmation"), ("validation", "confirmation"), ("tune", "confirmation")):
        if physical[a] & physical[b]:
            raise ValueError(f"Case leakage: {a}/{b}")
    origins = {Path(prior["root"]), Path(splits["confirmation"][0]["path"]).parents[1]}
    if prior.get("recovery", {}).get("parent_manifest"):
        origins.add(Path(prior["recovery"]["parent_manifest"]).parent)
    for origin in origins:
        if ((origin / "confirmation_baseline.json").exists()
                or list((origin / "validator/results").glob("*confirmation*.json"))):
            raise ValueError("Confirmation previously exposed; do not silently call it blind")
    source_rows = read_json(bundle_path.parent / "results/b0_source_evaluation.json")["cases"]
    source_by_hash = {r["case_sha256"]: r["makespan"] for r in source_rows}
    if set(source_by_hash) != {c["case_sha256"] for c in splits["tune"]}:
        raise ValueError("Local Tune60 does not match the released B0 cases")
    teacher = read_json(bundle_path.parent / "provenance/teacher_index.json")
    if teacher["case_count"] != 600:
        raise ValueError("Unexpected Stage2 teacher provenance")
    # Snapshot current integrated runtime, not a pre-merge historical source.
    listed = subprocess.check_output(["rg", "--files", "onpolicy", "scripts"], cwd=ROOT, text=True).splitlines()
    selected = {p for p in listed if "/dataset/" not in p and "/results/" not in p and (
        p.endswith(".py") or (p.startswith("onpolicy/config/") and Path(p).suffix in (".json", ".yaml", ".yml"))
        or "/test/fixtures/" in p)}
    selected.update(("STAGE2_FROZEN.md", "STAGE3_PRIVATE_B0_20260912.md", "requirements.txt",
                     "onpolicy/scripts/train/launch_stage3_b0_all.sh"))
    selected.add(str(bundle_path.relative_to(ROOT)))
    if local:
        selected.add("STAGE3_B0_LOCAL_RECALIBRATION_20260912.md")
    selected.update(str((bundle_path.parent / entry["path"]).relative_to(ROOT)) for entry in bundle["files"].values())
    files = {}
    for relative in sorted(selected):
        source, target = ROOT / relative, output / "source" / relative
        checksum = digest_file(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        if digest_file(target) != checksum:
            raise ValueError("Source changed during snapshot")
        files[relative] = checksum
    frozen_manifest = output / "source" / bundle_path.relative_to(ROOT)
    gpus = []
    for line in subprocess.check_output(["nvidia-smi", "--query-gpu=index,uuid,memory.total", "--format=csv,noheader,nounits"], text=True).splitlines():
        index, uuid, memory = [p.strip() for p in line.split(",")]
        gpus.append({"index": int(index), "uuid": uuid, "memory_mib": int(memory)})
    if [g["index"] for g in gpus] != list(range(8)):
        raise ValueError("This launch requires all eight GPUs")
    cores = discover_topology()
    placement = resource_plan(cores)
    for validator in placement["validators"]:
        validator["cuda_memory_fraction"] = 1.0
    cases32 = []
    for distribution, count in (("iid", 16), ("ood_stress", 14), ("ood_scale", 2)):
        cases32.extend(sorted([c for c in splits["train_full600"] if c["distribution"] == distribution],
                             key=lambda c: c["content_sha256"])[:count])
    canaries = [min((c for c in splits["train_full600"] if c["profile"] == profile),
                   key=lambda c: c["content_sha256"]) for profile in
                ("balanced", "low_load_ood", "resource_ood", "stress_joint")]
    mechanism_cases = [c for distribution, count in (("iid", 4), ("ood_stress", 3), ("ood_scale", 1))
                       for c in [c for c in cases32 if c["distribution"] == distribution][:count]]
    if local and any(c not in cases32 for c in canaries):
        raise ValueError("Parallel reference requires its four canaries in the paired TrainDiag32")
    comparison = comparison_contract(splits, LOCAL_BASELINE if local else None)
    m = {"schema": SCHEMA, "root": str(output), "created_unix": time.time(),
        "material_passport": {"origin_skill": "academic-research-suite/experiment-agent", "origin_mode": "run",
            "origin_date": "2026-09-12", "verification_status": "prepared; admissions pending", "version_label": SCHEMA},
        "source": {"path": str(frozen_manifest.parent / "checkpoints/b0.pt"), "sha256": B0_SHA,
            "manifest": str(frozen_manifest), "manifest_file_sha256": digest_file(frozen_manifest)},
        "contract": PLANNING, "contract_sha256": digest_json(PLANNING), "history": HISTORY,
        "evaluation": EVALUATION, "training": TRAINING, "splits": splits, "numerics": RUNTIME,
        "comparison_sha256": digest_json(comparison), "code": {"files": files, "sha256": digest_json(files)},
        "arms": {"C_PRIVATE": {"encoder": "F_PRIVATE", "gpus": list(range(8))}},
        "execution": {"code_root": str(output / "source"), "workspace_root": str(ROOT),
            "python": sys.executable, "worker": "onpolicy/scripts/train/stage3_b0_worker.py",
            "packages": {p: importlib.metadata.version(p) for p in ("torch", "torch-geometric", "numpy", "scipy", "PyYAML")},
            "workspace_protection": "advisory only; immutable run snapshot remains strict"},
        "resources": {"gpus": gpus, "core_groups": cores, "plan": placement,
            "validator_workers": 2, "validator_width": 3, "validator_queue": str(output / "validator"),
            "validator_lifecycle": "independent service, shared by all registered training routes",
            "memory_high_gib": 96, "memory_max_gib": 108, "formal_world_size": 8,
            "capacity_comparison": "4 vs 8 GPUs at identical global batch32; latest user request selects all8 for formal run"},
        "diagnostic": {"cases32": cases32, "canary_cases": canaries, "temperature_trajectories": 256,
            "mechanism_cases": mechanism_cases, "mechanism": MECHANISM,
            "initial_native_tune_costs": source_by_hash, "model_atol": 2e-6, "logp_atol": .002,
            "no_reward_improvement_gate": True},
        "input_files": {str(args.prior.resolve()): digest_file(args.prior)},
        "exposure": {"confirmation_costs_unopened": True, "prior_roots_checked": [str(p) for p in sorted(origins)],
            "validation_and_tune_previously_exposed": True, "stage2_teacher_scope": teacher["teacher_scope"],
            "train_unique_cases": 600, "physical_train_eval_overlap": 0},
        "scientific_target": {"gain": .02, "private_incremental_gain": .005, "single_seed_only": True},
        "timeouts_seconds": {"initialization": 43200, "sampling": 43200, "reference": 43200,
            "contract": 43200, "capacity": 43200, "train": 1209600, "validator": 1209600,
            "validator_request": 21600, "progress_warning": 900},
    }
    if getattr(args, "accelerated_from", None):
        from onpolicy.utils.stage3_b0_acceleration import prepare_reuse
        m["resources"].update(validator_max_workers=8, capacity_worlds=[8],
            capacity_comparison="four-GPU performance comparison deferred; full eight-GPU normal/dense gates retained")
        m["acceleration"] = {"version": 1, "preflight_chunk_size": 3,
            "temperature_logical_world_size": 8, "temperature_gpus": [1, 2, 5, 6],
            "validator_pool": "elastic boost on available GPUs; two reserved-CPU workers for formal training",
            "reuse_receipt": prepare_reuse(args.accelerated_from, m)}
    if local:
        m.update(baseline_reference=LOCAL_BASELINE,
                 recalibration_authorization="user-approved-local-B0-20260912")
        m["resources"].update(validator_max_workers=8, capacity_worlds=[8],
            capacity_comparison="four-GPU performance comparison deferred; full eight-GPU normal/dense gates retained")
        m["acceleration"] = {"version": 2, "preflight_chunk_size": 3,
            "temperature_logical_world_size": 8, "temperature_gpus": [1, 2, 5, 6],
            "validator_pool": "one elastic pool; fresh local evidence only"}
        import torch
        m["execution"]["local_inference_runtime"] = {
            "cuda": torch.version.cuda, "cudnn": torch.backends.cudnn.version(),
            "gpu_driver_fingerprint": subprocess.check_output(["nvidia-smi",
                "--query-gpu=index,uuid,name,driver_version", "--format=csv,noheader"], text=True).strip(),
            "numerics": RUNTIME, "neural_inference_batch": 1}
    m["manifest_sha256"] = identity(m)
    atomic_json(output / "manifest.json", m, overwrite=False)
    atomic_json(output / "comparison_contract.json", comparison, overwrite=False)
    atomic_json(output / "schedule.json", {"groups": schedule(splits["train_full600"], TRAINING["seed"])}, overwrite=False)
    print(output / "manifest.json", flush=True)


class B0Suite(FullSuite):
    def __init__(self, manifest, manifest_path):
        super().__init__(manifest, manifest_path)
        self.queue = queue(manifest)
        self.phase_gpu_peak_gib = 0.
        self.phase_validator_busy_samples = 0
        self._audited_native_tune_results = set()

    def check_available_native_tune(self):
        """Reject observed replay failures before spending hours on PPO preflight.

        This is an EARLY failure check, not a replacement for the complete
        60-case release gate or the 780-case sealed training baseline.
        """
        from onpolicy.utils.stage3_b0_acceleration import complete_rows
        expected = self.m["diagnostic"]["initial_native_tune_costs"]
        cases = {c["path"]: c for c in self.m["splits"]["tune"]}
        for path in sorted((self.queue.root / "results").glob("B0_tune_e000000_*.json")):
            if path.name in self._audited_native_tune_results:
                continue
            result = read_json(path)
            if (not result["ok"] or result["checkpoint_sha256"] != B0_SHA
                    or result["code_sha256"] != self.m["code"]["sha256"]
                    or result["evaluation"]["evaluation_protocol"] != EVALUATION):
                raise ValueError("Invalid native Tune replay evidence")
            rows = result["evaluation"]["cases"]
            complete_rows(rows, [cases[r["case_id"]] for r in rows])
            differences = {cases[r["case_id"]]["name"]:
                r["makespan"] - expected[cases[r["case_id"]]["case_sha256"]]
                for r in rows if abs(r["makespan"] - expected[cases[r["case_id"]]["case_sha256"]]) > 1e-6}
            if differences:
                atomic_json(self.root / "native_replay_early_failure.json", {
                    "passed": False, "partial_audit_only": True, "cost_atol": 1e-6,
                    "evaluation": EVALUATION, "result": str(path), "result_sha256": digest_file(path),
                    "differences": differences, "formal_training_admitted": False}, overwrite=False)
                raise RuntimeError(f"Native B0 release reproduction failed (early check): {differences}; no RL admitted")
            self._audited_native_tune_results.add(path.name)

    @staticmethod
    def task_key(phase, name):
        if phase not in ("initialization", "sampling", "reference", "contract", "capacity", "train", "validator") or not re.fullmatch(r"[A-Za-z0-9_/-]+", name) or ".." in name or name.startswith("/"):
            raise ValueError("Unsafe B0 worker identity")
        return f"{phase}/{name}"

    def check(self, hb):
        Suite.check(self, hb)
        if not getattr(self, "pool_only", False):
            self.check_available_native_tune()
        if time.time() - self.last_resource_sample < 10:
            return
        relative = next(l[3:] for l in Path("/proc/self/cgroup").read_text().splitlines() if l.startswith("0::"))
        group = Path("/sys/fs/cgroup") / relative.lstrip("/")
        # Both independent services live in a dedicated common slice.
        scope = group.parent if group.name.endswith(".service") else group
        usage = {"unix": time.time(), "scope": str(scope),
                 "cgroup_memory_bytes": int((scope / "memory.current").read_text()),
                 "memory_events": (scope / "memory.events").read_text()}
        gpu_rows = subprocess.check_output(["nvidia-smi", "--query-gpu=index,memory.used,utilization.gpu",
                                             "--format=csv,noheader,nounits"], text=True).splitlines()
        usage["gpus"] = [{"index": int(parts[0]), "memory_mib": float(parts[1]), "utilization_percent": float(parts[2])}
                         for parts in (line.split(",") for line in gpu_rows)]
        self.phase_gpu_peak_gib = max(self.phase_gpu_peak_gib, max(g["memory_mib"] / 1024 for g in usage["gpus"]))
        usage["busy_validators"] = sum(bool(read_json(path).get("request_id")) for path in
            (self.root / "validator/workers").glob("*/status.json"))
        self.phase_validator_busy_samples += bool(usage["busy_validators"])
        self.phase_sampled_peak = max(self.phase_sampled_peak, usage["cgroup_memory_bytes"])
        self.sampled_peak = max(self.sampled_peak, usage["cgroup_memory_bytes"])
        with (self.root / ("pool_resource_samples.jsonl" if getattr(self, "pool_only", False) else "resource_samples.jsonl")).open("a") as f:
            f.write(json.dumps(usage) + "\n")
        hb.update(sampled_combined_memory_peak_gib=self.sampled_peak / 2**30)
        self.last_resource_sample = time.time()
        if not getattr(self, "pool_only", False):
            self.check_validator_pool()

    def check_validator_pool(self, root=None):
        root = self.root if root is None else Path(root)
        state = read_json(root / "validator/pool_status.json")
        if state.get("status") == "failed":
            raise RuntimeError("Independent shared validator pool failed; retain all checkpoints")
        pid = read_json(root / "validator/pool_service.json")["pid"]
        os.kill(pid, 0)

    def group(self, phase, label, hb, *, world=8, batch=8, dense=None):
        keys = []
        rendezvous = self.root / "rendezvous" / f"{phase}_{label}"
        rendezvous.parent.mkdir(parents=True, exist_ok=True)
        for rank in range(world):
            # Four-card diagnostics span both NUMA nodes; formal training uses all8.
            gpu = ([0, 1, 4, 5][rank] if world == 4 else rank)
            options = dict(rank=rank, world_size=world, batch_size=batch, init_file=rendezvous,
                           until=self.m['training']['max_training_episodes'])
            if dense:
                options["dense_case"] = dense
            keys.append(self.start(f"{label}/rank{rank}", phase, self.plan["trainers"][str(gpu)], **options))
        while any(self.jobs[k]["process"].poll() is None for k in keys):
            self.check(hb)
            time.sleep(5)
        self.check(hb)
        return [read_json(self.jobs[k]["output"] / "result.json") for k in keys]

    def wait_requests(self, requests, hb):
        while any(self.queue.poll(r) is None for r in requests):
            self.check(hb)
            hb.update(event="await_shared_validation", pending_requests=sum(self.queue.poll(r) is None for r in requests))
            time.sleep(5)
        return [self.queue.poll(r)["evaluation"] for r in requests]

    def finish_training(self, hb):
        costs, curves, candidates = baseline_costs(self.m), [], []
        for epoch in range(1, 9):
            record = read_json(self.root / f"epochs/e{epoch*960:06d}.json")
            self.wait_requests(record["requests"], hb)
            values = {}
            for split in ("validation", "tune"):
                results = [self.queue.poll(r)["evaluation"] for r in record["requests"] if f"_{split}_" in r]
                rows = [r for result in results for r in result["cases"]]
                values[split] = paired_summary(rows, costs)
            row = {"data_epoch": epoch, **record, **values}
            curves.append(row)
            if risk_pass(values["validation"]) and risk_pass(values["tune"]):
                candidates.append(row)
        best = min(candidates, key=lambda r: (r["validation"]["makespan"], r["training_episodes"])) if candidates else curves[-1]
        lock = {"protocol_sha256": self.m["manifest_sha256"], "comparison_sha256": self.m["comparison_sha256"],
            "arm": "C_PRIVATE", "checkpoint": best["checkpoint"], "checkpoint_sha256": best["checkpoint_sha256"],
            "training_episodes": best["training_episodes"], "risk_qualified": bool(candidates),
            "rule": "lowest validation120 mean among risk-qualified epochs; else Last, unqualified",
            "locked_before_confirmation": True}
        atomic_json(self.root / "learning_curves.json", curves, overwrite=False)
        atomic_json(self.root / "selection_locked.json", lock, overwrite=False)
        atomic_json(self.root / "model_index.json", {"Best": lock,
            "Last": {k: curves[-1][k] for k in ("checkpoint", "checkpoint_sha256", "training_episodes", "actual_actor_updates")}}, overwrite=False)
        from onpolicy.utils.stage3_b0_diagnostics import summarize
        mechanism, initial_rows = {}, None
        for epoch in MECHANISM["data_epochs"]:
            record = read_json(self.root / f"mechanism/e{epoch*960:06d}.json")
            evaluations = self.wait_requests(record["requests"], hb)
            if initial_rows is None:
                initial_rows = [r for value in evaluations for r in value["cases"]]
            mechanism[str(epoch)] = summarize(evaluations, initial_rows)
        atomic_json(self.root / "mechanism/summary.json", mechanism, overwrite=False)
        atomic_json(self.root / "result.json", {"training_completed": True, "training_episodes": 7680,
            "selected": lock, "validation_target_met": bool(candidates) and best["validation"]["gain_fraction"] >= .02
                and all(r["validation"]["gain_fraction"] > 0 for r in curves[-2:]),
            "scientific_target_confirmed": False,
            "confirmation_status": "sealed; await shared-route selection lock before common confirmation",
            "validator_pool": "continues independently for all registered training routes"}, overwrite=False)

    def run_private(self):
        if (self.root / "status.json").exists():
            raise FileExistsError("No implicit controller restart; preserve the previous attempt")
        os.sched_setaffinity(0, self.plan["controller"])
        with ProgressHeartbeat(self.root / "status.json", phase="initialization", formal_training_started=False) as hb:
            try:
                hb.update(workspace_advisory=verify(self.m))
                requests = [r for split in ("train_full600", "validation", "tune") for r in submit_split(
                    self.m, self.m["source"]["path"], "B0", 0, "NATIVE", split=split, native=True)]
                initial = self.group("initialization", "b0", hb)
                if not all(r["passed"] for r in initial):
                    raise RuntimeError("B0 private initialization failed")
                hb.update(phase="native_b0_baselines")
                evaluations = self.wait_requests(requests, hb)
                rows = [r for value in evaluations for r in value["cases"]]
                costs = {r["case_id"]: r["makespan"] for r in rows}
                atomic_json(self.root / "baselines.json", {"costs": costs, "costs_sha256": digest_json(costs),
                    "cases": rows, "source_sha256": B0_SHA, "protocol_sha256": self.m["manifest_sha256"],
                    "evaluation": EVALUATION}, overwrite=False)
                baseline_costs(self.m)
                expected = self.m["diagnostic"]["initial_native_tune_costs"]
                differences = {c["name"]: costs[c["path"]] - expected[c["case_sha256"]]
                               for c in self.m["splits"]["tune"] if abs(costs[c["path"]] - expected[c["case_sha256"]]) > 1e-6}
                atomic_json(self.root / "native_replay.json", {"passed": not differences, "differences": differences}, overwrite=False)
                if differences:
                    raise RuntimeError("Native B0 failed to reproduce its released Tune60; no RL admitted")
                init = read_json(self.root / "initialization/b0/rank0/initialization.json")["checkpoint"]
                init_requests = [r for split in ("validation", "tune") for r in submit_split(
                    self.m, init, "C_PRIVATE", 0, "F_PRIVATE", split=split)]
                for result in self.wait_requests(init_requests, hb):
                    if any(abs(r["makespan"] - costs[r["case_id"]]) > 1e-6 for r in result["cases"]):
                        raise RuntimeError("Private zero-update validation differs from B0")
                hb.update(phase="training_only_temperature_diagnostic")
                samples = self.group("sampling", "temperatures", hb)
                temperatures = {}
                for tau in TRAINING["temperature_candidates"]:
                    sampled = [r for result in samples for r in result["temperatures"][str(tau)]["cases"]]
                    temperatures[str(tau)] = {"trajectories": len(sampled),
                        "mean_cost": sum(r["makespan"] for r in sampled) / len(sampled),
                        "positive_fraction": sum(r["makespan"] < costs[r["case_id"]] for r in sampled) / len(sampled)}
                selected_tau = min(TRAINING["temperature_candidates"], key=lambda t: (temperatures[str(t)]["mean_cost"], t))
                archives = {str(p): digest_file(p) for p in (self.root / "sampling/temperatures").glob("rank*/tau*")
                            if p.suffix in (".json", ".npz")}
                atomic_json(self.root / "sampling_admission.json", {"selected_tau": selected_tau,
                    "protocol_sha256": self.m["manifest_sha256"], "comparison_sha256": self.m["comparison_sha256"],
                    "temperatures": temperatures, "archives": archives,
                    "rule": "lower mean sampling cost on fixed TrainDiag32, ties lower tau",
                    "used_validation": False, "reward_gain_gate": False, "total_diagnostic_trajectories": 256}, overwrite=False)
                diagnostic = submit_mechanism(self.m, init, 0)
                atomic_json(self.root / "mechanism/e000000.json", {"requests": diagnostic,
                    "checkpoint_sha256": digest_file(init), "training_episodes": 0}, overwrite=False)
                self.complete_admission(hb, rows, init)
            finally:
                # The independent pool is NOT a child job and is not stopped.
                self.stop_owned()

    def complete_admission(self, hb, rows, init, reference=None):
        if self.m.get("baseline_reference"):
            baseline_costs(self.m)
        if reference is None:
            hb.update(phase="single_gpu_reference")
            reference = self.group("reference", "single", hb, world=1)[0]
        hb.update(phase="eight_gpu_parity")
        distributed = self.group("contract", "eight", hb)
        parity = compare_checkpoints(reference["after_update_checkpoint"], distributed[0]["after_update_checkpoint"], 2e-6)
        parity["trace_exact"] = all(r["trace_identity"] == reference["trace_identity"] for r in distributed)
        atomic_json(self.root / "contract/parity.json", parity, overwrite=False)
        if not parity["passed"] or not parity["trace_exact"]:
            raise RuntimeError("Single/eight-GPU update parity failed")
        train_paths = {c["path"] for c in self.m["splits"]["train_full600"]}
        dense = max((r for r in rows if r["case_id"] in train_paths), key=lambda r: r["max_graph_tensor_bytes"])["case_id"]
        capacity = {}
        self.phase_sampled_peak = 0
        self.phase_gpu_peak_gib = 0.
        self.phase_validator_busy_samples = 0
        for world in self.m['resources'].get('capacity_worlds', [4, 8]):
            for label, case in (("normal", None), ("dense", dense)):
                hb.update(phase=f"capacity_w{world}_{label}")
                co_load = [submit(self.m, init, "C_PRIVATE", 0, "F_PRIVATE", split="train_full600",
                    start=start, count=6, tag=f"_capacity_w{world}_{label}") for start in (0, 15)]
                capacity[f"w{world}_{label}"] = self.group("capacity", f"w{world}_{label}", hb,
                                                         world=world, batch=32, dense=case)
                self.wait_requests(co_load, hb)
        rows_capacity = [r for group in capacity.values() for r in group]
        passed = all(r["passed"] for r in rows_capacity) and self.phase_sampled_peak / 2**30 < 96
        maximum_vram = max(r["peak_reserved_gib"] for r in rows_capacity)
        # Whole-card safety includes the independently running pool,
        # not an obsolete per-process allocator fraction.
        passed = (passed and maximum_vram < 22 and self.phase_gpu_peak_gib < 23
                  and self.phase_validator_busy_samples > 0)
        admission = {"passed": passed, "world_size": 8, "global_batch": 32,
            "protocol_sha256": self.m["manifest_sha256"], "baseline_sha256": digest_file(self.root / "baselines.json"),
            "sampling_sha256": digest_file(self.root / "sampling_admission.json"), "capacity": capacity,
            "combined_memory_peak_gib": self.phase_sampled_peak / 2**30, "peak_reserved_gib": maximum_vram,
            "whole_gpu_sampled_peak_gib": self.phase_gpu_peak_gib,
            "validator_busy_samples": self.phase_validator_busy_samples,
            "source_sha256": B0_SHA, "formal_initialization": "fresh B0, never diagnostic weights",
            "shared_validator_pool_active": True, "teacher_fit_gate": False}
        if self.m.get("baseline_reference"):
            baseline_costs(self.m)
            admission["local_pairing_sha256"] = digest_file(self.root / "local_pairing_admission.json")
        atomic_json(self.root / "training_admission.json", admission, overwrite=False)
        if not passed:
            raise RuntimeError("Full resource capacity not admitted")
        hb.update(phase="full_data_training", formal_training_started=True)
        self.group("train", "full", hb, world=8, batch=32)
        hb.update(phase="checkpoint_selection")
        self.finish_training(hb)
        hb.update(phase="training_complete_confirmation_sealed")

    def run_pool(self):
        self.pool_only = True
        os.sched_setaffinity(0, self.plan["controller"])
        atomic_json(self.root / "validator/pool_service.json", {"pid": os.getpid(), "created_unix": time.time(),
            "scope": "one pool shared by every local rank and registered peer", "workers": 2}, overwrite=False)
        with ProgressHeartbeat(self.root / "validator/pool_status.json", phase="shared_validator_pool") as hb:
            try:
                for i, placement in enumerate(self.plan["validators"]):
                    self.start(f"pool{i}", "validator", placement)
                while not (self.queue.root / "STOP").exists() or self.queue.pending_count():
                    self.check(hb)
                    time.sleep(5)
            finally:
                self.stop_owned()

    def finalize(self, peer_selection):
        """Explicit late entry point; never opened by local training completion."""
        import torch
        paths = {"C_PRIVATE": self.root / "selection_locked.json", "B_SHARED": peer_selection.resolve()}
        locks = {arm: read_json(path) for arm, path in paths.items()}
        for arm, lock in locks.items():
            if (lock["arm"] != arm or lock["comparison_sha256"] != self.m["comparison_sha256"]
                    or not lock["locked_before_confirmation"]
                    or digest_file(lock["checkpoint"]) != lock["checkpoint_sha256"]):
                raise ValueError("Both immutable selections must match the comparison contract")
            if arm == "B_SHARED":
                peer = read_json(self.queue.root / "peers" / (lock["protocol_sha256"] + ".json"))
                if peer["comparison_sha256"] != self.m["comparison_sha256"]:
                    raise ValueError("Unregistered peer selection")
            elif lock["protocol_sha256"] != self.m["manifest_sha256"]:
                raise ValueError("Wrong private selection protocol")
            payload = torch.load(lock["checkpoint"], map_location="cpu", weights_only=False)
            tau = read_json(self.root / "sampling_admission.json")["selected_tau"]
            if (payload.get("protocol_sha256") != lock["protocol_sha256"] or payload.get("diagnostic_only")
                    or payload.get("training_episodes") != lock["training_episodes"]
                    or payload.get("source_sha256") != B0_SHA
                    or payload.get("exploration") != {"roles": [0, 1, 2], "taus": [tau] * 3}):
                raise ValueError("Selected checkpoint recipe/lineage differs")
            del payload
        atomic_json(self.root / "confirmation_open.json", {"comparison_sha256": self.m["comparison_sha256"],
            "locks": {arm: {"path": str(path), "sha256": digest_file(path)} for arm, path in paths.items()},
            "opened_unix": time.time()}, overwrite=False)
        with ProgressHeartbeat(self.root / "confirmation_status.json", phase="confirmation") as hb:
            requests = submit_split(self.m, self.m["source"]["path"], "B0", 0, "NATIVE", split="confirmation", native=True)
            baseline = [r for value in self.wait_requests(requests, hb) for r in value["cases"]]
            costs = {r["case_id"]: r["makespan"] for r in baseline}
            atomic_json(self.root / "confirmation_baseline.json", {"costs": costs, "costs_sha256": digest_json(costs),
                "cases": baseline, "source_sha256": B0_SHA, "protocol_sha256": self.m["manifest_sha256"],
                "evaluation": EVALUATION}, overwrite=False)
            evaluations = {}
            for arm, lock in locks.items():
                requests = submit_split(self.m, lock["checkpoint"], arm, lock["training_episodes"],
                    "F_PRIVATE" if arm == "C_PRIVATE" else "F_SHARED", split="confirmation",
                    owner_protocol=lock["protocol_sha256"])
                evaluations[arm] = [r for value in self.wait_requests(requests, hb) for r in value["cases"]]
            summaries = {arm: paired_summary(rows, costs) for arm, rows in evaluations.items()}
            increment = paired_summary(evaluations["C_PRIVATE"], {r["case_id"]: r["makespan"] for r in evaluations["B_SHARED"]})
            private = summaries["C_PRIVATE"]
            validation_met = read_json(self.root / "result.json")["validation_target_met"]
            atomic_json(self.root / "confirmation_result.json", {"summaries": summaries,
                "private_vs_shared": increment,
                "scientific_target_confirmed": validation_met and risk_pass(private)
                    and private["gain_fraction"] >= .02 and private["paired_case_bootstrap_gain_ci95"][0] > 0,
                "private_route_screen_positive": increment["gain_fraction"] >= .005
                    and increment["paired_case_bootstrap_gain_ci95"][0] > 0,
                "scope": "one seed; case-bootstrap uncertainty; two-host hardware-confounded route screening"}, overwrite=False)


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--prior", type=Path, required=True)
    prep.add_argument("--output", type=Path, required=True)
    prep.add_argument("--accelerated-from", type=Path,
                      help="Quiesced B0 preflight manifest; reuse verified evidence and enable elastic scheduling")
    prep.add_argument("--recalibrate-local-b0", action="store_true",
                      help="Explicitly authorized fresh local B0 reference; retain historical release as report-only")
    for command in ("run", "pool", "seal-tests", "register-peer", "submit-peer", "finalize"):
        q = sub.add_parser(command)
        q.add_argument("--manifest", type=Path, required=True)
        if command == "seal-tests":
            q.add_argument("--reports", type=Path, nargs="+", required=True)
        if command == "register-peer":
            q.add_argument("--peer-manifest", type=Path, required=True)
        if command == "submit-peer":
            q.add_argument("--peer-protocol", required=True)
            q.add_argument("--checkpoint", type=Path, required=True)
            q.add_argument("--episodes", type=int, required=True)
            q.add_argument("--split", choices=("validation", "tune"), required=True)
        if command == "finalize":
            q.add_argument("--peer-selection", type=Path, required=True)
    args = p.parse_args()
    if args.command == "prepare":
        prepare(args)
        return
    m = read_json(args.manifest)
    verify(m)
    if args.command == "register-peer":
        print(register_peer(m, read_json(args.peer_manifest)))
        return
    if args.command == "submit-peer":
        print(json.dumps(submit_split(m, args.checkpoint, "B_SHARED", args.episodes, "F_SHARED",
            split=args.split, owner_protocol=args.peer_protocol)))
        return
    if args.command == "seal-tests":
        tests = [t for path in args.reports for t in ET.parse(path).getroot().iter("testcase")]
        if not tests or any(t.find("failure") is not None or t.find("error") is not None for t in tests):
            raise ValueError("Cannot seal empty/failed tests")
        names = {t.attrib["name"] for t in tests if t.find("skipped") is None}
        required = {"test_b0_private_exact_initialization_and_ready_frozen", "test_transaction_rejection_restores_every_state",
                    "test_b0_gpu_prefix_cache_resume_and_gradient_isolation", "test_real_eight_rank_b0_visit_mean",
                    "test_b0_gpu_native_complete_release_replay", "test_confirmation_requires_two_immutable_locks",
                    "test_per_case_greedy_preserves_parallel_environments_and_legacy_default",
                    "test_batching_identity_invalidates_legacy_queue_cache_and_evidence",
                    "test_early_replay_failure_keeps_strict_threshold_and_never_admits_training"}
        if m.get("acceleration"):
            required.update({"test_elastic_pool_cpu_gpu_leases", "test_pool_drain_ack_precedes_replacement_leases",
                             "test_only_diagnostic_canary_can_use_partial_costs",
                             "test_raw_initialization_is_not_a_formal_validation_bypass",
                             "test_temperature_shards_keep_logical_eight_world_and_archive_layout"})
        if m.get("baseline_reference"):
            required.update({"test_local_pairing_rejects_equal_cost_different_actions",
                "test_local_baseline_requires_complete_bound_pairing",
                "test_historical_difference_is_reported_not_passed_or_used_as_gate",
                "test_local_raw_diag_is_not_a_training_bypass"})
        if not required <= names:
            raise ValueError(f"Missing required evidence: {required - names}")
        atomic_json(Path(m["root"]) / "verification.json", {"passed": True, "passed_tests": len(names),
            "code_sha256": m["code"]["sha256"], "manifest_sha256": m["manifest_sha256"],
            "reports": {str(path.resolve()): digest_file(path) for path in args.reports},
            "scope": "unit and bounded real CPU/GPU tests only; full-trajectory admissions remain pending"}, overwrite=False)
        return
    receipt = read_json(Path(m["root"]) / "verification.json")
    if (not receipt["passed"] or receipt["code_sha256"] != m["code"]["sha256"]
            or receipt["manifest_sha256"] != m["manifest_sha256"]
            or any(digest_file(path) != checksum for path, checksum in receipt["reports"].items())):
        raise ValueError("Source-matched verification receipt required")
    lock_path = Path(m["root"]) / ("pool.lock" if args.command == "pool" else "controller.lock")
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        signal.signal(signal.SIGTERM, lambda s, f: (_ for _ in ()).throw(KeyboardInterrupt("SIGTERM")))
        if m.get("subset_training"):
            from onpolicy.scripts.train.stage3_b0_subset240 import Subset240B0Suite
            suite = Subset240B0Suite(m, args.manifest)
        elif m.get("throughput"):
            from onpolicy.scripts.train.stage3_b0_large_batch import LargeBatchB0Suite
            suite = LargeBatchB0Suite(m, args.manifest)
        elif m.get("baseline_reference"):
            from onpolicy.scripts.train.stage3_b0_recalibrated import RecalibratedB0Suite
            suite = RecalibratedB0Suite(m, args.manifest)
        elif m.get("acceleration"):
            from onpolicy.scripts.train.stage3_b0_accelerated import AcceleratedB0Suite
            suite = AcceleratedB0Suite(m, args.manifest)
        else:
            suite = B0Suite(m, args.manifest)
        if args.command == "pool":
            suite.run_pool()
        elif args.command == "finalize":
            suite.finalize(args.peer_selection)
        else:
            suite.run_private()


if __name__ == "__main__":
    main()
