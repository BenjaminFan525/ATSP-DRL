#!/usr/bin/env python3
"""Scoped resource expansion for the two unfinished AR screening arms.

Never edits the original manifest/source. Uses an independently frozen execution
patch, preserves optimizer sample membership, and exports explicit two-logical-rank
compatibility checkpoints for the unchanged controller and shared validator.
"""
import argparse
from datetime import timedelta
import copy
import gc
import importlib.util
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json
from onpolicy.utils.stage3_rl_bridge import verify, schedule
from onpolicy.scripts.train.stage3_bridge_resource_core import VERSION, PLACEMENT, split_logical_shards

NEW_FILES = ('onpolicy/scripts/train/stage3_bridge_resource_core.py',
             'onpolicy/scripts/train/stage3_bridge_resource_control.py',
             'onpolicy/envs/HKBZ/test/test_stage3_bridge_resources.py')


def load_parent(path):
    manifest = read_json(path)
    verify(manifest)
    return manifest


def process_record(pid):
    proc = Path('/proc')/str(pid)
    stat = (proc/'stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': pid, 'state': stat[0], 'start_ticks': int(stat[19]), 'parent': int(stat[1]),
            'command': (proc/'cmdline').read_bytes().replace(b'\0', b' ').decode()}


def assert_process(record):
    current = process_record(record['pid'])
    if current['start_ticks'] != record['start_ticks'] or current['command'] != record['command']:
        raise RuntimeError('Process identity changed; do not signal a reused PID')


def unit_property(unit, prop):
    return subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', prop, '--value'], text=True).strip()


def live_workers(m):
    output = {}
    for arm in PLACEMENT:
        for rank in range(2):
            directory = Path(m['root'])/'screen'/arm/f'rank{rank}'
            candidates = []
            for path in directory.glob('process_*.json'):
                item = read_json(path)
                try:
                    record = process_record(item['pid'])
                except FileNotFoundError:
                    continue
                if str(directory) in record['command'] and '--task train' in record['command']:
                    candidates.append(record)
            if len(candidates) != 1:
                raise RuntimeError(f'Expected exactly one live original worker: {arm}/{rank}')
            output[f'{arm}:{rank}'] = candidates[0]
    return output


def cpu_expand(args):
    m = load_parent(args.manifest)
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError('CPU allocation receipt is immutable')
    for arm in ('P2_NATIVE', 'P3_NATIVE_RISK'):
        if not all(read_json(Path(m['root'])/'screen'/arm/f'rank{r}/result_epoch2.json')['completed'] for r in range(2)):
            raise RuntimeError('Native training still owns its CPU budget')
    workers = live_workers(m)
    records = {}
    for proc in Path('/proc').iterdir():
        if proc.name.isdigit():
            try:
                record = process_record(int(proc.name))
                records[record['pid']] = record
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
    changed = []
    for key, record in workers.items():
        arm, rank = key.split(':'); rank = int(rank)
        gpus = PLACEMENT[arm]
        cpus = sorted(set(m['resources']['plan']['trainers'][str(gpus[rank])]['cpus'] +
                          m['resources']['plan']['trainers'][str(gpus[rank+2])]['cpus']))
        owned = {record['pid']}
        while True:
            expanded = owned | {pid for pid, row in records.items() if row['parent'] in owned}
            if expanded == owned:
                break
            owned = expanded
        for pid in sorted(owned):
            try:
                assert_process(records[pid])
                for task in (Path('/proc')/str(pid)/'task').iterdir():
                    tid = int(task.name)
                    before = sorted(os.sched_getaffinity(tid))
                    os.sched_setaffinity(tid, cpus)
                    if sorted(os.sched_getaffinity(tid)) != cpus:
                        raise RuntimeError('CPU affinity readback failed')
                    changed.append({'arm': arm, 'logical_rank': rank, 'pid': pid, 'tid': tid,
                                    'before': before, 'after': cpus})
            except (FileNotFoundError, ProcessLookupError):
                if pid == record['pid']:
                    raise
    atomic_json(output, {'manifest_sha256': m['manifest_sha256'], 'applied_unix': time.time(),
        'scope': 'P0/P1 worker threads and owned environment descendants only',
        'physical_cores_per_logical_rank': 14, 'workers': workers, 'changes': changed}, overwrite=False)
    print({'cpu_allocation': str(output), 'threads_updated': len(changed), 'physical_cores_total': 56})


def prepare(args):
    m = load_parent(args.manifest)
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(output)
    parent_root = Path(m['root'])
    if read_json(parent_root/'status.json')['phase'] != 'train_screen_2':
        raise ValueError('This patch is restricted to the current two-epoch screening phase')
    recovery = None
    if args.recover_from is not None:
        previous, original = verify_patch(args.recover_from)
        if original['manifest_sha256'] != m['manifest_sha256']:
            raise ValueError('Recovery belongs to a different scientific experiment')
        evidence = validate_paused_recovery(previous, m, args.recover_from.resolve())
        workers, target = previous['workers'], previous['pause_next_group']
        recovery = {'manifest': str(args.recover_from.resolve()), 'sha256': previous['sha256'],
            'manifest_file_sha256': digest_file(args.recover_from),
            'pause_flag_sha256': digest_file(parent_root/'PAUSE_AFTER_COMMIT'),
            'evidence': evidence, 'authorization': 'explicit user requested handoff repair and checkpoint recovery'}
    else:
        workers = live_workers(m)
        target = {}
        for arm in PLACEMENT:
            heartbeats = [read_json(parent_root/'screen'/arm/f'rank{r}/heartbeat.json') for r in range(2)]
            if len({h['batch_index'] for h in heartbeats}) != 1:
                raise RuntimeError('Logical ranks disagree about the current batch')
            target[arm] = heartbeats[0]['batch_index']+1
    files = dict(m['code']['files'])
    for relative, checksum in files.items():
        source, dest = Path(m['execution']['code_root'])/relative, output/'source'/relative
        if digest_file(source) != checksum:
            raise ValueError('Original frozen source changed')
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
    for relative in NEW_FILES:
        dest = output/'source'/relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT/relative, dest)
        files[relative] = digest_file(dest)
    unit = 'hkbz-stage3-rl-bridge-20260915-r1-training.service'
    pid = int(unit_property(unit, 'MainPID'))
    controller = process_record(pid)
    if str(args.manifest.resolve()) not in controller['command']:
        raise ValueError('Old controller belongs to a different experiment')
    patch = {'version': VERSION, 'root': str(output), 'source_root': str(output/'source'),
        'parent_manifest': str(args.manifest.resolve()), 'parent_manifest_sha256': m['manifest_sha256'],
        'parent_manifest_file_sha256': digest_file(args.manifest), 'parent_code_sha256': m['code']['sha256'],
        'code_files': files, 'code_sha256': digest_json(files), 'placement': PLACEMENT,
        'controller_unit': unit, 'controller': controller, 'workers': workers,
        'pause_next_group': target, 'until_epochs': 2, 'physical_world_size': 4,
        'logical_world_size': 2, 'physical_rollout_envs': 30, 'physical_microbatch': 6,
        'global_rollout_trajectories': 120, 'global_optimizer_trajectories': 24,
        'science_unchanged': ['case order', 'seeds', 'four-replica advantages', 'global minibatch membership',
            'PPO epochs', 'learning rates', 'KL thresholds', 'TBPTT', 'evaluation', 'IGA frozen'],
        'bitwise_equivalence_claimed': False, 'automatic_retry': False, 'created_unix': time.time()}
    if recovery is not None:
        patch['recovery_from'] = recovery
    patch['sha256'] = digest_json(patch)
    atomic_json(output/'manifest.json', patch, overwrite=False)
    print({'resource_manifest': str(output/'manifest.json'), 'pause_next_group': target, 'placement': PLACEMENT})


def verify_patch(path):
    p = read_json(path)
    if (p['version'] != VERSION or p['placement'] != PLACEMENT
            or digest_json({k: v for k, v in p.items() if k != 'sha256'}) != p['sha256']
            or digest_file(p['parent_manifest']) != p['parent_manifest_file_sha256']):
        raise ValueError('Resource execution contract changed')
    m = load_parent(p['parent_manifest'])
    if m['manifest_sha256'] != p['parent_manifest_sha256']:
        raise ValueError('Scientific protocol changed')
    for relative, checksum in p['code_files'].items():
        if digest_file(Path(p['source_root'])/relative) != checksum:
            raise ValueError(f'Frozen resource execution file changed: {relative}')
    return p, m


def logical_plan(m):
    return schedule(m['splits']['train_screen96'], seed=m['training']['seed'],
                    epochs=4, world_size=2, width=60, phase='screen')


def boundary_commit(p, m, arm):
    """Accept only the announced, complete, original two-rank boundary."""
    import torch
    from onpolicy.utils.stage3_distributed import state_digest
    plan = logical_plan(m)
    cursor = p['pause_next_group'][arm]
    episodes = plan[cursor-1]['training_episodes']
    path = Path(m['root'])/'screen'/arm/f'commits/e{episodes:06d}.json'
    commit = read_json(path)
    if (commit['manifest_sha256'] != m['manifest_sha256'] or commit['arm'] != arm
            or commit['world_size'] != 2 or commit['phase'] != 'screen'
            or commit['schedule_sha256'] != digest_json(plan) or len(commit['ranks']) != 2):
        raise ValueError('Original commit protocol/topology differs')
    checksums = []
    for rank, entry in enumerate(commit['ranks']):
        if entry['rank'] != rank or digest_file(entry['checkpoint']) != entry['sha256']:
            raise ValueError('Original committed checkpoint changed')
        payload = torch.load(entry['checkpoint'], map_location='cpu', weights_only=False)
        if (payload['diagnostic_only'] or payload['rank'] != rank or payload['next_group'] != cursor
                or payload['world_size'] != 2 or payload['bridge_arm'] != arm
                or payload['protocol_sha256'] != m['manifest_sha256']
                or payload['schedule_sha256'] != digest_json(plan)
                or payload['training_episodes'] != episodes
                or payload['policy_updates'] != commit['policy_updates']):
            raise ValueError('Original resume metadata does not match its commit')
        checksums.append(state_digest({k: payload[k] for k in ('model', 'actor_optim', 'critic_optim',
            'role_value_normalizers', 'policy_updates')}))
    if len(set(checksums)) != 1:
        raise ValueError('Original committed model/optimizer/normalizer replicas diverged')
    return path, commit, checksums[0]


def seal_tests(args):
    p, _ = verify_patch(args.manifest)
    cases = list(ET.parse(args.junit).getroot().iter('testcase'))
    required = ('test_resource_schedule', 'test_resource_targets', 'test_resource_gloo',
                'test_resource_rejects', 'test_resource_controller')
    if not cases or any(c.find(x) is not None for c in cases for x in ('failure', 'error', 'skipped')):
        raise ValueError('Every resource execution test must pass, without skips')
    if any(not any(c.attrib['name'].startswith(prefix) for c in cases) for prefix in required):
        raise ValueError('Required resource tests absent')
    gpu = read_json(args.gpu_report)
    if not gpu['passed'] or gpu['resource_sha256'] != p['sha256'] or not gpu['no_optimizer_steps']:
        raise ValueError('Source-bound, non-stepping CUDA gradient diagnostic required')
    atomic_json(Path(p['root'])/'verification.json', {'passed': True, 'test_cases': len(cases),
        'junit': str(args.junit.resolve()), 'junit_sha256': digest_file(args.junit),
        'gpu_report': str(args.gpu_report.resolve()), 'gpu_report_sha256': digest_file(args.gpu_report),
        'resource_sha256': p['sha256'], 'code_sha256': p['code_sha256'],
        'scope': 'execution equivalence; not scientific performance or new full-trajectory admission'}, overwrite=False)


def make_resource_engine(p, m, arm):
    from onpolicy.scripts.train.stage3_bridge_resource_core import ResourceGroupEngine
    from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool
    runner = ResourceGroupEngine(m['source']['manifest'], 'F_PRIVATE', arm=arm,
        width=p['physical_rollout_envs'], device='cuda:0', tau=m['training']['sampling_tau'],
        actor_lr=m['training']['actor_lr'], cache_mib=1024, create_environments=False)
    runner.environment_start_method = m['throughput']['environment_start_method']
    runner.stochastic_batching = m['throughput']['stochastic_batching']
    runner.pool = EnvironmentPool(runner.width, start_method=runner.environment_start_method)
    return runner


def worker(args):
    import torch
    import torch.distributed as dist
    from onpolicy.runner.shared.stage3_research_engine import seed_all
    from onpolicy.utils.stage3_distributed import TrajectoryParallel
    from onpolicy.utils.stage3_distributed import state_digest
    from onpolicy.utils.stage3_numerics import training_state
    from onpolicy.utils.stage3_rl_bridge import baseline_costs
    from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
    from onpolicy.scripts.train.stage3_b0_worker import attach_journal
    from onpolicy.scripts.train.stage3_rl_bridge_worker import collect, metadata, save_rollouts, submit_evaluation
    p, m = verify_patch(args.manifest)
    if Path(p['source_root']).resolve() != ROOT:
        raise ValueError('Workers must execute the independently frozen resource source')
    if args.gpu != PLACEMENT[args.arm][args.rank]:
        raise ValueError('Physical GPU mapping differs')
    if not read_json(Path(m['root'])/'training_admission.json')['passed']:
        raise ValueError('Original scientific admission missing')
    os.sched_setaffinity(0, m['resources']['plan']['trainers'][str(args.gpu)]['cpus'])
    seed_all(m['training']['seed'])
    dist.init_process_group('gloo', init_method=f'file://{args.rendezvous.resolve()}',
        world_size=4, rank=args.rank, timeout=timedelta(hours=12))
    sync, runner = TrajectoryParallel(device_packed=True), None
    root, output = Path(m['root']), args.output
    plan = logical_plan(m)
    try:
        with ProgressHeartbeat(output/'heartbeat.json', task='resource_train', arm=args.arm,
                rank=args.rank, global_gpu=args.gpu, physical_world_size=4) as hb:
            runner = make_resource_engine(p, m, args.arm)
            _, commit, expected_state = boundary_commit(p, m, args.arm)
            original = commit['ranks'][args.rank % 2]
            payload = runner.resume(original['checkpoint'], protocol_sha256=m['manifest_sha256'],
                                    exploration=runner.exploration)
            if state_digest(training_state(runner)) != expected_state:
                raise ValueError('Full training state changed during resource resume')
            sync.assert_replicas(runner)
            atomic_json(output/'resume.json', {'physical_rank': args.rank, 'original_logical_rank': args.rank % 2,
                'checkpoint': original, 'next_group': payload['next_group'], 'original_state_sha256': expected_state,
                'resource_sha256': p['sha256'], 'policy_updates': runner.policy_updates}, overwrite=False)
            costs = baseline_costs(m)
            for batch in plan[payload['next_group']:]:
                if batch['epoch'] > p['until_epochs']:
                    break
                if sync.gather((root/'PAUSE_AFTER_COMMIT').exists())[0]:
                    atomic_json(output/'paused.json', {'next_group': batch['index'], 'paused': True}, overwrite=False)
                    return
                while len(list((root/'validator/pending').glob('*.json'))) > 320:
                    hb.update(event='shared_validator_backpressure', next_group=batch['index'])
                    time.sleep(5)
                items = split_logical_shards(batch['shards'])[args.rank]
                hb.update(event='batch_start', epoch=batch['epoch'], batch_index=batch['index'],
                    actual_actor_updates=runner.policy_updates, trajectories_per_rank=len(items))
                torch.cuda.reset_peak_memory_stats()
                begin = time.time()
                rows = collect(runner, items, hb)
                rollout_seconds = time.time()-begin
                rollout_memory = {'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                                  'reserved_gib': torch.cuda.max_memory_reserved()/2**30}
                extra = dict(diagnostic_only=False, phase='screen', rank=args.rank, world_size=4,
                    resource_sha256=p['sha256'], resource_code_sha256=p['code_sha256'],
                    execution_code_sha256=p['code_sha256'], parent_execution_code_sha256=m['code']['sha256'])
                save_rollouts(output/f'rollouts/g{batch["index"]:04d}.json', rows, metadata(m, args.arm, **extra))
                attach_journal(runner, output/f'updates/g{batch["index"]:04d}_attempts.jsonl')
                torch.cuda.reset_peak_memory_stats()
                begin = time.time()
                result = runner.update(rows, 'source', costs, epochs=2, chunk=8, heartbeat=hb,
                    distributed=sync, microbatch_size=6, optimizer_step_per_microbatch=True)
                result.update(rollout_seconds=rollout_seconds, update_seconds=time.time()-begin,
                    rollout_memory=rollout_memory, update_memory={
                        'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                        'reserved_gib': torch.cuda.max_memory_reserved()/2**30})
                atomic_json(output/f'updates/g{batch["index"]:04d}.json', result, overwrite=False)
                state = sync.assert_replicas(runner)
                episodes = batch['training_episodes']
                checkpoint = output/f'models/e{episodes:06d}.pt'
                saved_meta = metadata(m, args.arm, **extra, training_episodes=episodes,
                    next_group=batch['index']+1, schedule_sha256=digest_json(plan))
                checksum = runner.save(checkpoint, **saved_meta)
                entry = {'rank': args.rank, 'checkpoint': str(checkpoint), 'sha256': checksum}
                # Logical metadata is explicit, not a claim of two physical ranks.
                # The unchanged future controller can consume these full-state checkpoints.
                if args.rank < 2:
                    compat = root/'screen'/args.arm/f'rank{args.rank}/models/e{episodes:06d}.pt'
                    logical_meta = {**saved_meta, 'world_size': 2, 'resource_execution': {
                        'physical_world_size': 4, 'physical_rank': args.rank, 'physical_microbatch': 6,
                        'logical_world_size': 2, 'logical_microbatch': 12, 'global_optimizer_trajectories': 24,
                        'source_checkpoint': entry.copy(), 'manifest': str(args.manifest),
                        'resource_sha256': p['sha256'], 'bitwise_old_topology_equivalence': False}}
                    entry['logical_checkpoint'] = {'rank': args.rank, 'checkpoint': str(compat),
                        'sha256': runner.save(compat, **logical_meta)}
                entries = sync.gather(entry)
                if args.rank == 0:
                    physical_commit = Path(p['root'])/'train'/args.arm/f'commits/e{episodes:06d}.json'
                    common = {'manifest_sha256': m['manifest_sha256'], 'arm': args.arm, 'phase': 'screen',
                        'schedule_sha256': digest_json(plan), 'training_episodes': episodes,
                        'policy_updates': runner.policy_updates, 'resource_sha256': p['sha256'],
                        'replica_state_sha256': state}
                    atomic_json(physical_commit, {**common, 'world_size': 4, 'ranks': entries}, overwrite=False)
                    logical_commit = root/'screen'/args.arm/f'commits/e{episodes:06d}.json'
                    logical = [entries[r]['logical_checkpoint'] for r in range(2)]
                    atomic_json(logical_commit, {**common, 'world_size': 2, 'ranks': logical,
                        'physical_commit': str(physical_commit)}, overwrite=False)
                    if batch['epoch_tail']:
                        selected = logical[0]
                        requests = {split: submit_evaluation(m, selected['checkpoint'], args.arm,
                            episodes, 'screen', split=split) for split in ('validation', 'tune')}
                        atomic_json(root/'screen'/args.arm/f'epochs/e{batch["epoch"]:02d}.json', {
                            'checkpoint': selected['checkpoint'], 'checkpoint_sha256': selected['sha256'],
                            'requests': requests, 'training_episodes': episodes,
                            'policy_updates': runner.policy_updates, 'commit': str(logical_commit),
                            'resource_sha256': p['sha256']}, overwrite=False)
                sync.barrier()
                hb.update(event='batch_committed', training_episodes=episodes,
                    actual_actor_updates=runner.policy_updates, rollout_seconds=rollout_seconds,
                    update_seconds=result['update_seconds'])
                del rows
                gc.collect()
                if runner.zero_update_batches >= 3:
                    raise RuntimeError('Three consecutive zero-update batches; all commits retained')
            report = {'completed': True, 'training_episodes': p['until_epochs']*len(m['splits']['train_screen96'])*4,
                'policy_updates': runner.policy_updates, 'resource_sha256': p['sha256']}
            atomic_json(output/'result_epoch2.json', report, overwrite=False)
            if args.rank < 2:
                atomic_json(root/'screen'/args.arm/f'rank{args.rank}/result_epoch2.json', report, overwrite=False)
    except BaseException as exc:
        atomic_json(output/'error.json', {'error': str(exc), 'traceback': traceback.format_exc(), 'unix': time.time()})
        raise
    finally:
        if runner is not None:
            runner.close()
        dist.destroy_process_group()


def original_controller(m):
    path = Path(m['execution']['code_root'])/'onpolicy/scripts/train/run_stage3_rl_bridge.py'
    spec = importlib.util.spec_from_file_location('resource_parent_controller', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def resume_original_controller(m, parent_manifest):
    """Skip only completed admission/screen work; all selection gates stay native."""
    from onpolicy.utils.stage3_rl_bridge import ARMS
    module = original_controller(m)
    suite = module.BridgeSuite(m, Path(parent_manifest))
    def admission(hb):
        receipt = read_json(Path(m['root'])/'training_admission.json')
        if not receipt['passed'] or receipt['manifest_sha256'] != m['manifest_sha256']:
            raise ValueError('Cannot reuse missing/foreign original admission')
    original_execute = suite.execute
    first = True
    def execute(task, phase, arms, until_epochs, hb, *, resume=False):
        nonlocal first
        if first:
            if (task, phase, until_epochs, resume) != ('train', 'screen', 2, False):
                raise ValueError('Unexpected original controller continuation entry')
            first = False
            for arm in ARMS:
                for rank in range(2):
                    result = read_json(Path(m['root'])/'screen'/arm/f'rank{rank}/result_epoch2.json')
                    if not result['completed'] or result['training_episodes'] != 768:
                        raise ValueError('Cannot skip incomplete screening')
                for epoch in (1, 2):
                    index = read_json(Path(m['root'])/'screen'/arm/f'epochs/e{epoch:02d}.json')
                    if digest_file(index['checkpoint']) != index['checkpoint_sha256']:
                        raise ValueError('Completed screening checkpoint changed')
            atomic_json(Path(m['root'])/'train_screen_2_completed.json', {
                'completed': True, 'resource_version': VERSION, 'unix': time.time()}, overwrite=False)
            suite.pool_mode('evaluation_only', hb)
            return
        return original_execute(task, phase, arms, until_epochs, hb, resume=resume)
    suite.admission, suite.execute = admission, execute
    try:
        suite.run()
    finally:
        suite.lock.close()


def process_active(record):
    """Exit state is not command identity: zombies legitimately have no cmdline.

    Always validate start_ticks, including for zombies. Re-read once if the
    process exits between reading stat and cmdline; a live exec/PID substitution
    still raises and is never treated as an authorized signal target.
    """
    try:
        for _ in range(2):
            current = process_record(record['pid'])
            if current['start_ticks'] != record['start_ticks']:
                raise RuntimeError('Process identity changed; do not signal a reused PID')
            if current['state'] in ('Z', 'X'):
                return False
            if current['command'] == record['command']:
                return True
        raise RuntimeError('Live process command changed; ownership cannot be established')
    except (FileNotFoundError, ProcessLookupError):
        return False


def validate_paused_recovery(previous, m, previous_manifest):
    """Recovery is limited to an audited pre-launch, fully committed handoff."""
    root, old_root = Path(m['root']), Path(previous['root'])
    if (old_root/'activated.json').exists() or (old_root/'handoff.json').exists():
        raise ValueError('Recovery entry requires an unlaunched original checkpoint handoff')
    error = read_json(old_root/'error.json')
    if not error.get('controller_paused'):
        raise ValueError('Old controller is not recorded as safely paused')
    flag = read_json(root/'PAUSE_AFTER_COMMIT')
    if (flag.get('owner') != VERSION or flag.get('resource_manifest') != str(previous_manifest)
            or flag.get('next_groups') != previous['pause_next_group']):
        raise ValueError('Another request owns the existing pause flag')
    assert_process(previous['controller'])
    controller = process_record(previous['controller']['pid'])
    if (controller['state'] not in ('T', 't') or
            int(unit_property(previous['controller_unit'], 'MainPID')) != controller['pid']):
        raise ValueError('Original controller is no longer stopped in its recorded unit')
    boundaries = {}
    for arm in PLACEMENT:
        _, commit, state = boundary_commit(previous, m, arm)
        for rank in range(2):
            marker = read_json(root/'screen'/arm/f'rank{rank}/paused_2.json')
            if (marker.get('paused') is not True or marker['next_group'] != previous['pause_next_group'][arm]
                    or marker['policy_updates'] != commit['policy_updates']):
                raise ValueError('Full checkpoint and pause cursor do not match')
            if process_active(previous['workers'][f'{arm}:{rank}']):
                raise ValueError('A prior training worker is still active')
        boundaries[arm] = {'training_episodes': commit['training_episodes'],
            'policy_updates': commit['policy_updates'], 'state_sha256': state}
    return boundaries


def check_only_shared_validators(m, parent_manifest):
    """Never preempt a job which acquired an idle GPU while awaiting the boundary."""
    xml = ET.fromstring(subprocess.check_output(['nvidia-smi', '-q', '-x'], text=True, timeout=30))
    gpus = xml.findall('gpu')
    if len(gpus) != 8:
        raise ValueError('Eight healthy GPUs required for the announced placement')
    seen = []
    for index, gpu in enumerate(gpus):
        for process in gpu.findall('processes/process_info'):
            record = process_record(int(process.findtext('pid')))
            if (index not in (0, 4) or str(parent_manifest) not in record['command']
                    or '--task validator' not in record['command']):
                raise RuntimeError(f'GPU {index} acquired another job; do not preempt PID {record["pid"]}')
            seen.append(index)
    if sorted(seen) != [0, 4]:
        raise ValueError('Original shared validator pool placement changed')
    pool = read_json(Path(m['root'])/'validator/pool_status.json')
    if pool['mode'] != 'training' or time.time()-pool['unix'] > 120:
        raise ValueError('Original shared validator pool is not healthy')


def run(args):
    from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
    p, m = verify_patch(args.manifest)
    receipt = read_json(Path(p['root'])/'verification.json')
    if (not receipt['passed'] or receipt['resource_sha256'] != p['sha256']
            or receipt['code_sha256'] != p['code_sha256']
            or digest_file(receipt['junit']) != receipt['junit_sha256']
            or digest_file(receipt['gpu_report']) != receipt['gpu_report_sha256']):
        raise ValueError('Resource execution verification missing or changed')
    if ROOT != Path(p['source_root']).resolve():
        raise ValueError('Supervisor must execute frozen resource source')
    root, patch_root = Path(m['root']), Path(p['root'])
    flag, processes, controller_paused = root/'PAUSE_AFTER_COMMIT', [], False
    recovery = p.get('recovery_from')
    flag_owner = str(args.manifest)
    if recovery:
        previous, _ = verify_patch(recovery['manifest'])
        if (previous['sha256'] != recovery['sha256'] or
                digest_file(recovery['manifest']) != recovery['manifest_file_sha256'] or
                digest_file(flag) != recovery['pause_flag_sha256']):
            raise ValueError('Recovery source or owned pause request changed')
        if validate_paused_recovery(previous, m, Path(recovery['manifest'])) != recovery['evidence']:
            raise ValueError('Committed recovery state changed after preparation')
        flag_owner = recovery['manifest']
    else:
        if flag.exists():
            raise FileExistsError('Another pause request already owns the checkpoint boundary')
        for record in [p['controller'], *p['workers'].values()]:
            assert_process(record)
    if int(unit_property(p['controller_unit'], 'MainPID')) != p['controller']['pid']:
        raise ValueError('Controller unit identity differs')
    for arm in PLACEMENT:
        for rank in range(2):
            hb = read_json(root/'screen'/arm/f'rank{rank}/heartbeat.json')
            if hb['batch_index']+1 != p['pause_next_group'][arm]:
                raise ValueError('Prepared boundary passed; prepare a new execution patch')
    try:
        with ProgressHeartbeat(patch_root/'heartbeat.json', pid=os.getpid(), version=VERSION) as hb:
            os.kill(p['controller']['pid'], signal.SIGSTOP)
            controller_paused = True
            if recovery is None:
                atomic_json(flag, {'owner': VERSION, 'resource_manifest': str(args.manifest),
                    'next_groups': p['pause_next_group'], 'unix': time.time()}, overwrite=False)
            atomic_json(patch_root/'armed.json', {'controller_paused_only': p['controller'],
                'workers_continue_to_full_commit': p['workers'], 'next_groups': p['pause_next_group'],
                'recovery_from': recovery, 'unix': time.time()}, overwrite=False)
            status = read_json(root/'status.json')
            atomic_json(root/'status.json', {**status, 'resource_switch': 'waiting_complete_checkpoint',
                'resource_manifest': str(args.manifest), 'resource_heartbeat': str(patch_root/'heartbeat.json'),
                'original_controller_intentionally_paused': True, 'unix': time.time()})
            start = time.time()
            while True:
                paused = []
                for arm in PLACEMENT:
                    for rank in range(2):
                        directory = root/'screen'/arm/f'rank{rank}'
                        if (directory/'error.json').exists():
                            raise RuntimeError(f'Original worker failed: {directory}')
                        marker = directory/'paused_2.json'
                        if marker.exists():
                            item = read_json(marker)
                            if not item['paused'] or item['next_group'] != p['pause_next_group'][arm]:
                                raise ValueError('Worker paused at a different boundary')
                            paused.append(f'{arm}:{rank}')
                        elif not process_active(p['workers'][f'{arm}:{rank}']):
                            raise RuntimeError('Worker exited without its full-commit pause receipt')
                live = [key for key, record in p['workers'].items() if process_active(record)]
                hb.update(event='waiting_original_full_commit', paused=paused, live_workers=live,
                    target_next_groups=p['pause_next_group'], placement=PLACEMENT)
                if len(paused) == 4 and not live:
                    break
                if time.time()-start > 6*3600:
                    raise TimeoutError('Checkpoint handoff exceeded six-hour safety timeout')
                time.sleep(10)
            boundaries = {}
            for arm in PLACEMENT:
                path, commit, state = boundary_commit(p, m, arm)
                boundaries[arm] = {'commit': str(path), 'sha256': digest_file(path),
                    'training_episodes': commit['training_episodes'], 'state_sha256': state}
            check_only_shared_validators(m, p['parent_manifest'])
            atomic_json(patch_root/'handoff.json', {'boundaries': boundaries,
                'all_original_workers_exited': True, 'unix': time.time()}, overwrite=False)
            assert_process(p['controller'])
            # Only the old controller is left; its children have durably committed.
            # Queue SIGTERM before SIGCONT, so it cannot interpret paused exits as completion.
            os.kill(p['controller']['pid'], signal.SIGTERM)
            os.kill(p['controller']['pid'], signal.SIGCONT)
            controller_paused = False
            subprocess.run(['systemctl', '--user', 'stop', p['controller_unit']], check=True, timeout=90)
            if process_active(p['controller']):
                raise RuntimeError('Old controller still owns the phase lock')
            if read_json(flag)['resource_manifest'] != flag_owner:
                raise ValueError('Pause flag ownership changed')
            flag.rename(patch_root/'pause_request_consumed.json')
            module = original_controller(m)
            for arm, gpus in PLACEMENT.items():
                rendezvous = patch_root/'rendezvous'/arm
                rendezvous.parent.mkdir(parents=True, exist_ok=True)
                if rendezvous.exists():
                    raise FileExistsError('No automatic reuse of a distributed rendezvous')
                for rank, gpu in enumerate(gpus):
                    output = patch_root/'train'/arm/f'rank{rank}'
                    output.mkdir(parents=True, exist_ok=True)
                    env = module.child_environment(m, gpu)
                    env.update(PYTHONPATH=p['source_root'], GLOO_SOCKET_IFNAME='lo')
                    cmd = [m['execution']['python'], '-B', '-u', str(ROOT/NEW_FILES[1]), 'worker',
                        '--manifest', str(args.manifest), '--arm', arm, '--rank', str(rank),
                        '--gpu', str(gpu), '--output', str(output), '--rendezvous', str(rendezvous)]
                    with (output/'worker.log').open('ab') as log:
                        child = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
                    processes.append((arm, rank, child))
                    atomic_json(output/f'process_{child.pid}.json', {'pid': child.pid, 'command': cmd,
                        'gpu': gpu, 'started_unix': time.time()}, overwrite=False)
            atomic_json(patch_root/'activated.json', {'placement': PLACEMENT, 'unix': time.time(),
                'global_optimizer_trajectories': 24, 'global_rollout_trajectories': 120}, overwrite=False)
            atomic_json(root/'status.json', {'status': 'running', 'phase': 'resource_parallel_screen_2',
                'arms': PLACEMENT, 'resource_manifest': str(args.manifest),
                'iga': 'frozen; no solving', 'unix': time.time()})
            while True:
                codes = [(a, r, child.poll()) for a, r, child in processes]
                if any(code not in (0, None) for _, _, code in codes):
                    raise RuntimeError(f'Resource worker failure; no automatic retry: {codes}')
                if (root/'validator/pool_error.json').exists():
                    raise RuntimeError('Shared validator failed')
                hb.update(event='resource_workers_running', workers=codes)
                if all(code == 0 for _, _, code in codes):
                    break
                time.sleep(10)
            atomic_json(patch_root/'training_completed.json', {'exits': codes, 'unix': time.time()}, overwrite=False)
        resume_original_controller(m, p['parent_manifest'])
    except BaseException as exc:
        atomic_json(patch_root/'error.json', {'error': str(exc), 'traceback': traceback.format_exc(),
            'controller_paused': controller_paused, 'automatic_retry': False, 'all_artifacts_retained': True,
            'unix': time.time()})
        atomic_json(root/'status.json', {'status': 'failed', 'phase': 'resource_controller_failed',
            'resource_manifest': str(args.manifest), 'error': str(exc),
            'original_controller_intentionally_paused': controller_paused, 'unix': time.time()})
        # Do not resume a half-migrated controller or discard any saved state.
        # The unit's KillMode=control-group stops only new workers owned by this patch.
        raise


def proposed_adam_updates(runner, captured):
    """Simulate a clipped Adam proposal on detached CPU copies, never live weights."""
    import torch
    names = {id(parameter): name for name, parameter in runner.policy.ac.named_parameters()}
    result = {}
    for key, source in (('actor', runner.policy.actor_optimizer), ('critic', runner.policy.critic_optimizer)):
        groups, parameters, gradient_before = [], {}, []
        for group in source.param_groups:
            cloned = []
            for original in group['params']:
                name = names[id(original)]
                parameter = torch.nn.Parameter(original.detach().cpu().clone())
                if name in captured:
                    parameter.grad = captured[name].clone()
                    gradient_before.append(parameter.grad.reshape(-1).to(torch.float64))
                cloned.append(parameter)
                parameters[name] = parameter
            groups.append({**{k: v for k, v in group.items() if k != 'params'}, 'params': cloned})
        optimizer = torch.optim.Adam(groups)
        optimizer.load_state_dict(copy.deepcopy(source.state_dict()))
        torch.nn.utils.clip_grad_norm_(list(parameters.values()), 1., error_if_nonfinite=True)
        optimizer.step()
        result[key] = {'parameters': {name: p.detach().clone() for name, p in parameters.items()},
            'gradient': torch.cat(gradient_before)}
    return result


def compare_gradient_proposals(runner, before, after):
    """Cancellation-sensitive element errors are audited, not silently ignored.

    Require both a tight whole-objective direction bound and a float32-scale
    bound on the actual clipped/Adam proposal, using the saved optimizer moments.
    Scientific likelihood/KL guards remain exactly as in the parent experiment.
    """
    import torch
    if before.keys() != after.keys():
        raise ValueError('Gradient ownership differs')
    proposals = [proposed_adam_updates(runner, gradients) for gradients in (before, after)]
    report, passed = {}, True
    for role in ('actor', 'critic'):
        left, right = (proposal[role] for proposal in proposals)
        g, h = left['gradient'], right['gradient']
        finite = bool(torch.isfinite(g).all() and torch.isfinite(h).all())
        relative_l2 = float(torch.linalg.vector_norm(g-h)/max(float(torch.linalg.vector_norm(g)), 1e-12))
        cosine = float(torch.nn.functional.cosine_similarity(g, h, dim=0, eps=1e-12))
        maximum = max(float((value-right['parameters'][name]).abs().max())
                      for name, value in left['parameters'].items())
        close = finite and relative_l2 <= 1e-4 and cosine >= 1-1e-8 and maximum <= 1e-7
        report[role] = {'passed': close, 'relative_l2_error': relative_l2, 'cosine': cosine,
            'proposed_parameter_max_absolute_error': maximum,
            'reference_gradient_l2': float(torch.linalg.vector_norm(g)),
            'gradient_max_absolute_error': float((g-h).abs().max())}
        passed = passed and close
    return passed, report


def probe(args):
    """Real CUDA graph prefix, fixed-data 12 vs 2x6 gradients; never optimizer steps."""
    import torch
    from onpolicy.runner.shared.stage3_research_engine import ResearchEngine, seed_all
    from onpolicy.scripts.train.stage3_rl_bridge_worker import make_engine
    from onpolicy.utils.stage3_rl_bridge import actor_targets, baseline_costs
    from onpolicy.utils.stage3_numerics import training_state
    from onpolicy.utils.stage3_distributed import state_digest
    p, m = verify_patch(args.manifest)
    if ROOT != Path(p['source_root']).resolve() or args.gpu not in (5, 6, 7):
        raise ValueError('Diagnostic requires frozen execution and an idle non-validator GPU')
    os.sched_setaffinity(0, m['resources']['plan']['trainers'][str(args.gpu)]['cpus'])
    seed_all(m['training']['seed'])
    args.output.mkdir(parents=True, exist_ok=True)
    runner = make_engine(m, 'P0_SOURCE', 12)
    checkpoint = Path(m['root'])/'screen/P0_SOURCE/rank0/models/e000120.pt'
    payload = runner.resume(checkpoint, protocol_sha256=m['manifest_sha256'], exploration=runner.exploration)
    original_call = runner.pool.call
    def prefix(commands):
        result = original_call(commands)
        for index, kind, _ in commands:
            if kind == 'summary':
                result[index] = {**result[index], 'completed': True, 'synthetic_prefix_fixture': True}
        return result
    runner.pool.call = prefix
    captured, max_errors = [], []
    class Captured(Exception):
        pass
    try:
        items = logical_plan(m)[payload['next_group']]['shards'][0][:12]
        rows = runner.rollout([i['case'] for i in items], [i['seed'] for i in items], retain=True, max_steps=32)
        for row, item in zip(rows, items):
            row.update(group_id=item['group_id'], replica=item['replica'], population_weight=item['weight'])
        replay = [runner.replay_metrics(part) for part in (rows, rows[:6], rows[6:])]
        if any(r['max_logp_error'] > .002 for r in replay):
            raise ValueError('Likelihood replay changed beyond the original .002 tolerance')
        costs = baseline_costs(m)
        for micro in (12, 6):
            runner.resume(checkpoint, protocol_sha256=m['manifest_sha256'], exploration=runner.exploration)
            before = state_digest(training_state(runner))
            a, w, _ = actor_targets(rows, 'P0_SOURCE', costs)
            fixed = {id(row): (av, wt) for row, av, wt in zip(rows, a, w)}
            runner.stage3_actor_objective = lambda rs: ([fixed[id(r)][0] for r in rs], [fixed[id(r)][1] for r in rs])
            def capture(epoch, ac, stats):
                captured.append({name: param.grad.detach().cpu().clone() for name, param in ac.named_parameters()
                                 if param.grad is not None})
                raise Captured()
            torch.cuda.reset_peak_memory_stats()
            try:
                ResearchEngine.update(runner, rows, 'source', costs, epochs=1, chunk=8,
                    allow_multi_case=True, visit_balanced=True, microbatch_size=micro, gradient_callback=capture)
            except Captured:
                pass
            else:
                raise ValueError('Diagnostic unexpectedly reached optimizer stepping')
            if state_digest(training_state(runner)) != before:
                raise ValueError('Gradient diagnostic changed model/optimizer/normalizer state')
            max_errors.append({'microbatch': micro, 'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                'reserved_gib': torch.cuda.max_memory_reserved()/2**30})
        differences = []
        for name, before in captured[0].items():
            after = captured[1][name]
            mismatches = int(((before-after).abs() > 3e-5+3e-4*after.abs()).sum())
            differences.append({'parameter': name, 'max_absolute_error': float((before-after).abs().max()),
                                'strict_elementwise_mismatches': mismatches})
        untouched = state_digest(training_state(runner))
        passed, comparison = compare_gradient_proposals(runner, captured[0], captured[1])
        if state_digest(training_state(runner)) != untouched:
            raise ValueError('CPU proposal simulation changed live training state')
        atomic_json(args.output/'result.json', {'passed': passed, 'resource_sha256': p['sha256'],
            'prefix_steps': 32, 'trajectories': 12, 'no_optimizer_steps': True,
            'optimizer_proposals_on_detached_cpu_copies_only': True,
            'diagnostic_only': True, 'not_full_trajectory_admission': True,
            'checkpoint_sha256': digest_file(checkpoint), 'gradient_tensors': len(differences),
            'likelihood_replay': replay,
            'max_absolute_error': max(x['max_absolute_error'] for x in differences),
            'strict_elementwise_mismatches': sum(x['strict_elementwise_mismatches'] for x in differences),
            'worst_tensors': sorted(differences, key=lambda x: -x['max_absolute_error'])[:20],
            'comparison': comparison, 'relative_l2_limit': 1e-4, 'cosine_minimum': 1-1e-8,
            'parameter_update_absolute_limit': 1e-7, 'memory': max_errors, 'unix': time.time()}, overwrite=False)
        if not passed:
            raise ValueError(f'CUDA gradient or optimizer proposal differs: {comparison}')
    finally:
        if hasattr(runner, 'stage3_actor_objective'):
            del runner.stage3_actor_objective
        runner.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('cpu', 'prepare', 'seal-tests', 'run', 'worker', 'probe'))
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--arm', choices=tuple(PLACEMENT))
    parser.add_argument('--rank', type=int)
    parser.add_argument('--gpu', type=int)
    parser.add_argument('--rendezvous', type=Path)
    parser.add_argument('--junit', type=Path)
    parser.add_argument('--gpu-report', type=Path)
    parser.add_argument('--recover-from', type=Path)
    args = parser.parse_args()
    if args.command == 'cpu':
        return cpu_expand(args)
    if args.command == 'prepare':
        return prepare(args)
    return {'run': run, 'worker': worker, 'probe': probe, 'seal-tests': seal_tests}[args.command](args)


if __name__ == '__main__':
    main()
