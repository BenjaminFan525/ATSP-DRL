#!/usr/bin/env python3
"""Inspect an explicitly captured same-state numerical reproduction fixture."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from onpolicy.runner.shared.stage3_b0_engine import B0Engine
from onpolicy.utils.stage3_research import read_json, atomic_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--fixture", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    m = read_json(args.manifest)
    fixture = torch.load(args.fixture, map_location="cpu", weights_only=False)
    runner = B0Engine(m["source"]["manifest"], "NATIVE", create_environments=False)
    runner.configure_exploration(None)
    matching = runner.policy.ac._apply_device_global_matching
    captured = []
    def capture(scores, lookahead, active, choices, logp, validated):
        matching(scores, lookahead, active, choices, logp, validated)
        captured.append({"scores": scores.detach().cpu(), "lookahead": lookahead.detach().cpu(),
                         "choices": choices.detach().cpu().clone(), "active": active.detach().cpu()})
    runner.policy.ac._apply_device_global_matching = capture
    results, states = {}, {}
    def run(mode, indices, api, roles=True):
        captured.clear()
        with torch.no_grad():
            call = getattr(runner.policy, api)
            kwargs = {"deterministic": True}
            if roles:
                kwargs["agent_types"] = fixture["roles"][indices]
            if api == "get_actions":
                kwargs["return_decision_mask"] = True
            value = call([fixture["graphs"][i].clone() for i in indices], fixture["hidden"][indices],
                fixture["active"][indices], fixture["op"][indices], fixture["site"][indices], **kwargs)
        action = value[1] if api == "get_actions" else value[0]
        states[mode] = {"action": action.cpu(), "matching": captured[0]}
        results[mode] = {"action": action.cpu().tolist(), "cuda_matmul_tf32": torch.backends.cuda.matmul.allow_tf32,
                         "cudnn_tf32": torch.backends.cudnn.allow_tf32}
    try:
        run("batch", list(range(len(fixture["graphs"]))), "get_actions")
        run("single", [0], "get_actions")
        run("act_batch", list(range(len(fixture["graphs"]))), "act", False)
        run("act_single", [0], "act", False)
        run("repeat_single", [0], "get_actions")
        torch.backends.cudnn.allow_tf32 = True
        run("cudnn_tf32_single", [0], "act", False)
        torch.backends.cuda.matmul.allow_tf32 = True
        run("tf32_single", [0], "act", False)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        from onpolicy.utils.stage2_resource_rl import configure_trainability
        configure_trainability(runner.policy)
        runner.policy.ac.eval()
        run("historical_grad_single", [0], "act", False)
        run("historical_grad_batch", list(range(len(fixture["graphs"]))), "act", False)
        comparisons = {}
        base = states["single"]
        for mode, state in states.items():
            a, b = base["matching"]["scores"][0], state["matching"]["scores"][0]
            finite = torch.isfinite(a) & torch.isfinite(b)
            rows = torch.nonzero((base["action"][0] != state["action"][0]).any(-1)).flatten().tolist()
            comparisons[mode] = {"different_agent_rows": rows,
                "max_finite_score_error": float((a[finite]-b[finite]).abs().max()) if finite.any() else 0.,
                "finite_mask_exact": bool(torch.equal(torch.isfinite(a), torch.isfinite(b))),
                "scores_for_different_agents": {str(r): {"single": [[i, float(v)] for i, v in enumerate(a[r]) if torch.isfinite(v)],
                    "other": [[i, float(v)] for i, v in enumerate(b[r]) if torch.isfinite(v)]} for r in rows}}
        atomic_json(args.output, {"comparisons": comparisons, "calls": results}, overwrite=False)
    finally:
        runner.close()


if __name__ == "__main__":
    main()
