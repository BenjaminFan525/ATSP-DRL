#!/usr/bin/env python3
"""Give the existing B0 validation queue all CPUs after formal trainers exit.

This execution-only sidecar never edits the sealed source/manifest, stops the
original pool, republishes requests, or changes inference/thread settings. Six
unchanged frozen workers join the two original workers in the SAME locked queue.
The training *controller* deliberately remains alive to select checkpoints;
waiting for its service to exit would deadlock the requested handoff.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time
import traceback


AUTHORIZATION = "user-requested-all-cpus-to-validator-after-training-20260914"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value, *, exclusive=False):
    """Atomic runtime receipt, not an edit to experimental inputs."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False) as stream:
        temp = Path(stream.name)
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    try:
        if exclusive:
            os.link(temp, path)
        else:
            os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def placements(manifest):
    groups = manifest["resources"]["core_groups"]
    gpus = sorted(g["index"] for g in manifest["resources"]["gpus"])
    flattened = [cpu for group in groups for cpu in group]
    if (len(groups) != 64 or any(len(group) != 2 for group in groups)
            or sorted(flattened) != list(range(128)) or gpus != list(range(8))):
        raise ValueError("This handoff requires the recorded 64-core/128-thread, eight-GPU host")
    # Consecutive complete cores preserve this host's two NUMA-node partition.
    return {str(gpu): {"gpu": gpu, "cpus": sorted(sum(groups[gpu*8:(gpu+1)*8], []))}
            for gpu in gpus}


def process_identity(pid, proc=Path("/proc")):
    base = proc / str(pid)
    try:
        fields = (base / "stat").read_text().rsplit(")", 1)[1].split()
        if fields[0] == "Z":
            return None
        return {"pid": pid, "start_ticks": int(fields[19]),
                "cgroup": (base / "cgroup").read_text().strip()}
    except FileNotFoundError:
        return None


def assert_worker(identity, manifest, unit):
    pid = identity["pid"]
    if process_identity(pid) != identity:
        raise RuntimeError("Original validator PID exited or was reused")
    if not any(unit in line.split(":", 2)[-1].split("/")
               for line in identity["cgroup"].splitlines()):
        raise ValueError("Validator belongs to a different service")
    args = (Path("/proc") / str(pid) / "cmdline").read_bytes().decode().split("\0")
    root = Path(manifest["root"])
    worker = str(Path(manifest["execution"]["code_root"]) / manifest["execution"]["worker"])
    if (worker not in args or str(root/"manifest.json") not in args
            or "--phase" not in args or args[args.index("--phase")+1] != "validator"):
        raise ValueError("PID is not an unchanged frozen validator for this run")


def training_ready(manifest, *, alive=process_identity):
    """A durable final commit alone is insufficient: wait for all eight exits."""
    root, final = Path(manifest["root"]), manifest["training"]["max_training_episodes"]
    state = read(root/"status.json")
    if state.get("status") == "failed" or state.get("phase") == "paused_at_commit":
        raise RuntimeError("Training failed/paused; do not take its resources")
    path = root/f"train/commits/episodes_{final:06d}.json"
    if not path.exists():
        return False, "waiting_final_formal_checkpoint"
    commit = read(path)
    if (commit.get("training_episodes") != final or commit.get("world_size") != 8
            or commit.get("protocol_sha256") != manifest["manifest_sha256"]
            or [r["rank"] for r in commit["ranks"]] != list(range(8))):
        raise ValueError("Final checkpoint identity mismatch")
    for rank in range(8):
        output = root/f"train/full/rank{rank}"
        result = output/"result.json"
        if not result.exists():
            return False, "waiting_trainer_completion_receipts"
        record = read(result)
        if (not record.get("completed") or record.get("training_episodes") != final
                or record.get("actual_actor_updates") != commit["actual_actor_updates"]):
            raise ValueError("Final trainer receipt mismatch")
        if alive(read(output/"status.json")["pid"]) is not None:
            return False, "waiting_training_worker_exit"
        code = state.get("worker_exit_codes", {}).get(f"train/full/rank{rank}")
        if code not in (None, 0):
            raise RuntimeError("A training worker exited unsuccessfully")
        if code is None:
            return False, "waiting_controller_exit_acknowledgement"
    for kind in ("epochs", "mechanism"):
        record = root/kind/f"e{final:06d}.json"
        if not record.exists():
            return False, "waiting_final_validation_publication"
        row = read(record)
        if (row.get("training_episodes") != final or not row.get("requests")
                or row.get("checkpoint_sha256") != commit["ranks"][0]["sha256"]):
            raise ValueError("Final evaluation publication mismatch")
    return True, "all_eight_trainers_exited_after_final_commit"


def verify_files(manifest, manifest_hash):
    root = Path(manifest["root"])
    if sha(root/"manifest.json") != manifest_hash:
        raise ValueError("Frozen manifest changed after scheduling")
    source = Path(manifest["execution"]["code_root"])
    for relative, checksum in manifest["code"]["files"].items():
        path = (source/relative).resolve()
        if not path.is_relative_to(source) or sha(path) != checksum:
            raise ValueError(f"Frozen source changed: {relative}")


def verify_checkpoints(manifest):
    root, final = Path(manifest["root"]), manifest["training"]["max_training_episodes"]
    commit = read(root/f"train/commits/episodes_{final:06d}.json")
    for entry in commit["ranks"]:
        expected = root/f"train/full/rank{entry['rank']}/models/episodes_{final:06d}.pt"
        if Path(entry["checkpoint"]).resolve() != expected or sha(expected) != entry["sha256"]:
            raise ValueError("Final checkpoint is missing, altered, or outside this run")


def affinity_tree(identity, cpus, *, proc=Path("/proc")):
    if process_identity(identity["pid"], proc) != identity:
        raise RuntimeError("Affinity target PID changed")
    pending, seen, tids = [identity["pid"]], set(), set()
    while pending:
        pid = pending.pop()
        if pid in seen:
            continue
        seen.add(pid)
        current = process_identity(pid, proc)
        if current is None:
            continue
        if current["cgroup"] != identity["cgroup"]:
            raise RuntimeError("Refuse to modify an unrelated descendant")
        for task in (proc/str(pid)/"task").glob("*"):
            try:
                pending.extend(map(int, (task/"children").read_text().split()))
                os.sched_setaffinity(int(task.name), cpus)
                tids.add(int(task.name))
            except (FileNotFoundError, ProcessLookupError):
                continue
    if set(os.sched_getaffinity(identity["pid"])) != set(cpus):
        raise RuntimeError("Validator CPU allocation did not take effect")
    return {"pid": identity["pid"], "cpus": cpus, "updated_tasks": len(tids)}


def worker_launch(manifest, placement, output):
    source = Path(manifest["execution"]["code_root"])
    gpu = next(g for g in manifest["resources"]["gpus"] if g["index"] == placement["gpu"])
    # Match FullSuite.start; all numerical and environment settings stay sealed.
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=gpu["uuid"], CUDA_DEVICE_ORDER="PCI_BUS_ID",
        HKBZ_STAGE3_WORKSPACE_ROOT=manifest["execution"]["workspace_root"], PYTHONPATH=str(source),
        OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0", MALLOC_ARENA_MAX="2",
        CUBLAS_WORKSPACE_CONFIG=manifest["numerics"]["cublas_workspace_config"],
        PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True")
    command = ["/usr/bin/taskset", "--cpu-list", ",".join(map(str, placement["cpus"])),
        manifest["execution"]["python"], "-B", "-u", str(source/manifest["execution"]["worker"]),
        str(Path(manifest["root"])/"manifest.json"), "--phase", "validator", "--output", str(output)]
    return command, env


def queue_counts(root):
    return {name: len(list((root/"validator"/name).glob("*.json")))
            for name in ("pending", "running", "results", "failed")}


def guard_gpu_owners(manifest, validator_unit):
    known = {g["uuid"] for g in manifest["resources"]["gpus"]}
    rows = subprocess.check_output(["nvidia-smi", "--query-compute-apps=gpu_uuid,pid",
                                   "--format=csv,noheader,nounits"], text=True)
    for line in rows.splitlines():
        uuid, raw_pid = map(str.strip, line.split(","))
        if uuid not in known:
            continue
        identity = process_identity(int(raw_pid))
        if identity is not None and not any(validator_unit in row.split(":", 2)[-1].split("/")
                                           for row in identity["cgroup"].splitlines()):
            raise RuntimeError(f"GPU still has a training or unrelated owner PID {raw_pid}; left untouched")


class Boost:
    def __init__(self, manifest):
        self.path = manifest.resolve()
        self.m = read(self.path)
        self.root = Path(self.m["root"])
        if self.path != self.root/"manifest.json" or Path(self.m["resources"]["validator_queue"]) != self.root/"validator":
            raise ValueError("Manifest and the single shared queue must belong to the same exact run")
        self.directory = self.root/"validator/cpu_boost_20260914"
        self.unit = "hkbz-" + self.root.name.replace("_", "-") + "-validator.service"
        self.allocations = placements(self.m)
        self.manifest_hash = sha(self.path)
        self.originals, self.children, self.receipt = [], [], None
        self.stop_requested = False

    def plan(self):
        verify_files(self.m, self.manifest_hash)
        originals = []
        for index, placement in enumerate(self.m["resources"]["plan"]["validators"]):
            output = self.root/f"validator/workers/pool{index}"
            identity = process_identity(read(output/"status.json")["pid"])
            if identity is None:
                raise RuntimeError("Original pool is not running")
            assert_worker(identity, self.m, self.unit)
            originals.append({"identity": identity, "output": str(output), "gpu": placement["gpu"],
                              "old_cpus": sorted(os.sched_getaffinity(identity["pid"]))})
        if len(originals) != 2 or {p["gpu"] for p in originals} != {0, 4}:
            raise ValueError("Expected the existing GPU0/GPU4 two-worker pool")
        self.originals = originals
        return {"authorization": AUTHORIZATION, "created_unix": time.time(), "pid": os.getpid(),
            "manifest": str(self.path), "manifest_file_sha256": self.manifest_hash,
            "protocol_sha256": self.m["manifest_sha256"], "script_sha256": sha(__file__),
            "queue": str(self.root/"validator"), "original_workers": originals,
            "placements": self.allocations, "total_workers_after_handoff": 8,
            "trigger": "final formal checkpoint verified AND all eight training workers exit successfully",
            "inference_contract_unchanged": True, "new_queue_or_manifest": False}

    def status(self, phase, **extra):
        terminal = {"completed", "failed", "cancelled_before_handoff", "cancelled_after_drain"}
        write(self.directory/"status.json", {"phase": phase, "pid": os.getpid(),
            "status": phase if phase in terminal else "running",
            "heartbeat_unix": time.time(), "queue": queue_counts(self.root),
            "authorization": AUTHORIZATION, **extra})

    def activate(self):
        ready, reason = training_ready(self.m)
        if not ready:
            raise RuntimeError(f"Training has not released its resources: {reason}")
        verify_files(self.m, self.manifest_hash)
        verify_checkpoints(self.m)
        guard_gpu_owners(self.m, self.unit)
        if set(os.sched_getaffinity(0)) != set(range(128)):
            raise ValueError("Booster must inherit the full 128-CPU allowance")
        if queue_counts(self.root)["failed"]:
            raise RuntimeError("Existing failed validation requires explicit diagnosis, not expansion")
        for original in self.originals:
            assert_worker(original["identity"], self.m, self.unit)
        changes = []
        for original in self.originals:
            # Repeat once to catch an environment child forked while its parent
            # was receiving the new mask. Future forks inherit that mask.
            affinity_tree(original["identity"], self.allocations[str(original["gpu"])]["cpus"])
            changes.append(affinity_tree(original["identity"], self.allocations[str(original["gpu"])]["cpus"]))
        for key, placement in self.allocations.items():
            if placement["gpu"] in {p["gpu"] for p in self.originals}:
                continue
            output = self.root/f"validator/workers/fullcpu_g{key}"
            log = self.root/f"logs/validator/fullcpu_g{key}.log"
            if output.exists() or log.exists():
                raise FileExistsError("No implicit retry or overwrite of a validator worker")
            command, env = worker_launch(self.m, placement, output)
            write(self.directory/f"command_g{key}.json", {"command": command, "placement": placement}, exclusive=True)
            log.parent.mkdir(parents=True, exist_ok=True)
            with log.open("x") as stream:
                process = subprocess.Popen(command, env=env, cwd=self.m["execution"]["code_root"],
                    stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            self.children.append({"process": process, "output": output, "placement": placement,
                                  "started_unix": time.time()})
        self.receipt = {"activated_unix": time.time(), "total_workers": 8, "physical_cores": 64,
            "logical_cpus": 128, "original_affinity_changes": changes,
            "added_workers": [{"pid": c["process"].pid, "output": str(c["output"]),
                               "placement": c["placement"]} for c in self.children],
            "source_and_manifest_unchanged": True, "shared_queue": str(self.root/"validator")}
        write(self.directory/"activated.json", self.receipt, exclusive=True)

    def drain(self):
        # Normal completion/cancellation does not signal or kill a running case.
        for child in self.children:
            if child["process"].poll() is None:
                write(child["output"]/"DRAIN", {"authorization": AUTHORIZATION,
                      "created_unix": time.time(), "preserve_inflight_request": True})
        while any(c["process"].poll() is None for c in self.children):
            self.status("draining_added_workers_at_request_boundaries")
            time.sleep(5)

    def run(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        with (self.directory/"lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            write(self.directory/"plan.json", self.plan(), exclusive=True)
            deadline = time.time()+8*3600
            try:
                while not self.stop_requested:
                    ready, reason = training_ready(self.m)
                    self.status(reason, activated=False)
                    if ready:
                        break
                    if time.time() > deadline:
                        raise TimeoutError("Training completion not observed within eight hours")
                    time.sleep(15)
                if self.stop_requested:
                    self.status("cancelled_before_handoff", activated=False)
                    return
                self.activate()
                while not self.stop_requested:
                    counts = queue_counts(self.root)
                    if counts["failed"]:
                        raise RuntimeError("A validation request failed; artifacts retained")
                    for original in self.originals:
                        assert_worker(original["identity"], self.m, self.unit)
                    for child in self.children:
                        rc = child["process"].poll()
                        if rc is not None:
                            raise RuntimeError(f"Added validator exited unexpectedly, rc={rc}")
                        state_path = child["output"]/"status.json"
                        if state_path.exists():
                            state = read(state_path)
                            if state.get("status") == "failed":
                                raise RuntimeError("Added validator reported a failure")
                            if time.time()-state.get("heartbeat_unix", 0) > 180:
                                raise TimeoutError("Added validator heartbeat expired")
                            started = state.get("request_started_unix")
                            if started and time.time()-started > self.m["timeouts_seconds"]["validator_request"]:
                                raise TimeoutError("Added validator exceeded the unchanged request time limit")
                        elif time.time()-child["started_unix"] > 180:
                            raise TimeoutError("Added validator did not start")
                    self.status("all_cpus_shared_validation", activated=True, resources=self.receipt)
                    result_path = self.root/"result.json"
                    if (counts["pending"] == counts["running"] == 0 and result_path.exists()
                            and read(result_path).get("training_completed")):
                        break
                    time.sleep(10)
                self.drain()
                self.status("completed" if not self.stop_requested else "cancelled_after_drain",
                            activated=True, resources=self.receipt)
            except BaseException:
                error = traceback.format_exc()
                write(self.directory/"failure.json", {"error": error, "all_artifacts_retained": True})
                self.drain()
                self.status("failed", error=error)
                raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-only", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()
    boost = Boost(args.manifest)
    if args.check_only:
        plan = boost.plan()
        plan["readiness"] = training_ready(boost.m)
        print(json.dumps(plan, indent=2, sort_keys=True))
        return
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda _sig, _frame: setattr(boost, "stop_requested", True))
    boost.run()


if __name__ == "__main__":
    main()
