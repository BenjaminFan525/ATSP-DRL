#!/usr/bin/env python3
"""Bounded, zero-update B0 reproduction diagnostics; never an admission override."""
import argparse
import copy
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from onpolicy.runner.shared.stage3_b0_engine import B0Engine
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat, save_group, trajectory_record


@torch.no_grad()
def fixed_slot_rollout(runner, cases, heartbeat):
    """Diagnostic reproduction of Stage2's keep-all-slots collector, no updates."""
    from onpolicy.utils.stage2_resource_rl import forward
    runner.configure_exploration(None)
    runner.policy.ac.eval()
    count = len(cases)
    initial = runner.pool.call([(i, "reset", {**runner.make_environment(c["path"], 1),
        "_stage3_diagnostics": True}) for i, c in enumerate(cases)])
    obs = [initial[i][0] for i in range(count)]
    infos = [initial[i][2] for i in range(count)]
    hidden = np.zeros((count, 104, 1, 64), np.float32)
    previous = np.full((count, 104, 3), -1, np.int64)
    live = np.ones(count, bool)
    rows = [dict(case_id=c["path"], profile=c["profile"], distribution=c["distribution"],
        seed=1, actions=[], states=[], behavior_deterministic=True, forced_replay=False,
        policy_updates=0, exploration=None) for c in cases]
    for step in range(4000):
        graph, h, active, op, site, roles = runner._inputs(obs, hidden, infos, previous)
        active[~live] = 0
        out, _ = forward(runner.policy, graph, h, active, np.stack((op, site), -1),
                         roles, deterministic=True, hungarian=True)
        actions = out["actions"].cpu().numpy().astype(np.int64)
        hidden = out["rnn_states"].cpu().numpy()
        for i in np.flatnonzero(live):
            rows[i]["actions"].append(actions[i].tolist())
        results = runner.pool.call([(i, "step", actions[i]) for i in range(count)])
        newly_done = []
        for i in range(count):
            obs[i], _, done, infos[i] = results[i]
            if np.all(done):
                hidden[i] = 0
                if live[i]:
                    newly_done.append(i)
                live[i] = False
        summaries = runner.pool.call([(i, "summary", None) for i in newly_done])
        for i, summary in summaries.items():
            rows[i].update(summary)
        previous = actions
        if step % 50 == 0:
            heartbeat.update(event="rollout", rollout_step=step, live_trajectories=int(live.sum()))
        if not live.any():
            return rows
    raise RuntimeError("Diagnostic fixed-slot replay did not complete")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--split", choices=("tune", "train_full600"), default="tune")
    parser.add_argument("--cases", nargs="+", required=True)
    parser.add_argument("--variant", default="NATIVE", choices=("NATIVE", "F_PRIVATE"))
    parser.add_argument("--compare-singletons", action="store_true")
    parser.add_argument("--singleton-calls", action="store_true")
    parser.add_argument("--historical-grad-flags", action="store_true")
    parser.add_argument("--original-pool", action="store_true")
    parser.add_argument("--fixed-slots", action="store_true")
    parser.add_argument("--release-model-code", action="store_true")
    parser.add_argument("--stage2-numerics", action="store_true")
    parser.add_argument("--rollout-chunk-size", type=int)
    parser.add_argument("--legacy-live-batch", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("Use a fresh diagnostic directory")
    args.output.mkdir(parents=True)
    m = read_json(args.manifest)
    by_name = {c["name"]: c for c in m["splits"][args.split]}
    cases = [by_name[n] for n in args.cases]
    width = args.rollout_chunk_size or len(cases)
    if not 0 < width <= len(cases) or (args.fixed_slots and width != len(cases)):
        raise ValueError("Invalid diagnostic rollout chunk size")
    runner = B0Engine(m["source"]["manifest"], args.variant, width=width,
                      stable_pool=not args.original_pool)
    if args.stage2_numerics:
        # Stage2 configure_bc_determinism preserves this PyTorch default.
        torch.backends.cudnn.allow_tf32 = True
    if args.release_model_code:
        if args.variant != "NATIVE" or not args.original_pool:
            raise ValueError("Released model diagnostic requires NATIVE and original pooling")
        import hashlib
        import subprocess
        proof = read_json(Path(m["source"]["manifest"]).parent / "provenance/hf_manifest.json")
        for relative, obj, class_name in (
            ("onpolicy/algorithms/utils/gnn.py", runner.policy.ac.encoder, "HeteroGraphEncoder"),
            ("onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py", runner.policy.ac, "GNN_Actor_Critic")):
            source = subprocess.check_output(["git", "show", "origin/stage2-frozen-20260912:" + relative], cwd=ROOT)
            if hashlib.sha256(source).hexdigest() != proof["code_fingerprint"][relative]:
                raise ValueError("Diagnostic reference differs from published source fingerprint")
            namespace = {"__name__": "stage3_diagnostic_frozen_model", "__file__": str(ROOT / relative)}
            exec(compile(source, relative, "exec"), namespace)
            obj.__class__ = namespace[class_name]
    if args.historical_grad_flags:
        from onpolicy.utils.stage2_resource_rl import configure_trainability
        runner.configure_exploration(None)
        configure_trainability(runner.policy)
        runner.policy.ac.eval()
        # B0Engine's normal rollout setup restores Stage3 training metadata.
        # Apply the historical flags after that setup, immediately before calls.
        configure = runner.configure_exploration
        def historical_exploration(config):
            configure(config)
            configure_trainability(runner.policy)
            runner.policy.ac.eval()
        runner.configure_exploration = historical_exploration
    original = runner.policy.get_actions
    stats = {"calls": 0, "action_comparisons": 0, "first_action_difference": None,
             "max_hidden_error": 0., "max_logp_error": 0.}
    def compare(graph, hidden, active, op, site, **kwargs):
        batched = original(graph, hidden, active, op, site, **kwargs)
        index = stats["calls"]
        stats["calls"] += 1
        if (not args.singleton_calls and stats["first_action_difference"] is not None) or len(graph) == 1:
            return batched
        singles = [original([g], hidden[i:i+1], active[i:i+1], op[i:i+1], site[i:i+1],
                   **{**kwargs, "agent_types": kwargs["agent_types"][i:i+1]}) for i, g in enumerate(graph)]
        joined = tuple(torch.cat([value[j] for value in singles], dim=0) for j in range(len(batched)))
        stats["action_comparisons"] += len(graph)
        stats["max_hidden_error"] = max(stats["max_hidden_error"], float((batched[3]-joined[3]).abs().max()))
        stats["max_logp_error"] = max(stats["max_logp_error"], float((batched[2]-joined[2]).abs().max()))
        different = torch.nonzero((batched[1] != joined[1]).any(dim=-1), as_tuple=False).cpu().tolist()
        if different and stats["first_action_difference"] is None:
            stats["first_action_difference"] = {"policy_call": index, "different_agents": different,
                "batch_actions": batched[1].cpu().tolist(), "singleton_actions": joined[1].cpu().tolist(),
                "max_hidden_error": stats["max_hidden_error"], "max_logp_error": stats["max_logp_error"]}
            torch.save({"graphs": [g.clone().cpu() for g in graph], "hidden": hidden, "active": active,
                "op": op, "site": site, "roles": kwargs["agent_types"],
                "batch_actions": batched[1].cpu(), "singleton_actions": joined[1].cpu()}, args.output / "first_difference.pt")
            atomic_json(args.output / "first_difference.json", stats, overwrite=False)
        return joined if args.singleton_calls else batched
    if args.compare_singletons or args.singleton_calls:
        runner.policy.get_actions = compare
    begin = time.time()
    with ProgressHeartbeat(args.output / "status.json", phase="b0_reproduction_diagnostic") as hb:
        try:
            if args.fixed_slots:
                trajectories = fixed_slot_rollout(runner, cases, hb)
            else:
                trajectories = []
                for start in range(0, len(cases), width):
                    group = cases[start:start + width]
                    if args.legacy_live_batch:
                        from onpolicy.runner.shared.stage3_research_engine import ResearchEngine
                        from onpolicy.runner.shared.stage3_b0_engine import HISTORY
                        runner.configure_exploration(None)
                        values = ResearchEngine.rollout(runner, group, [1] * len(group),
                            deterministic=True, heartbeat=hb, greedy_batching="live_batch")
                        for row in values:
                            row.update(history=HISTORY, source_sha256=runner.b0_sha256,
                                       decoder="b0_native_hungarian", inference_batching="legacy_live_batch")
                    else:
                        values = runner.rollout(group, [1] * len(group), deterministic=True, heartbeat=hb)
                    trajectories.extend(values)
            rows = [trajectory_record(t) for t in trajectories]
            save_group(args.output / "trajectories.json", trajectories, {"zero_updates": True, "diagnostic_only": True})
            expected = m["diagnostic"]["initial_native_tune_costs"] if args.split == "tune" else {}
            atomic_json(args.output / "result.json", {"variant": args.variant, "cases": rows, "comparisons": stats,
                "elapsed_seconds": time.time()-begin, "source_sha256": runner.b0_sha256,
                "manifest_sha256": digest_file(args.manifest), "singleton_calls": args.singleton_calls,
                "historical_grad_flags": args.historical_grad_flags, "original_pool": args.original_pool,
                "fixed_slots": args.fixed_slots,
                "release_model_code": args.release_model_code,
                "stage2_numerics": args.stage2_numerics,
                "legacy_live_batch": args.legacy_live_batch, "rollout_width": width,
                "runtime_sources": {name: digest_file(ROOT / name) for name in (
                    "onpolicy/scripts/train/diagnose_stage3_b0_reproduction.py",
                    "onpolicy/runner/shared/stage3_b0_engine.py",
                    "onpolicy/runner/shared/stage3_research_engine.py",
                    "onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py",
                    "onpolicy/algorithms/utils/gnn.py")},
                "release_cost_differences": {c["name"]: r["makespan"] - expected[c["case_sha256"]]
                    for c, r in zip(cases, rows) if c["case_sha256"] in expected}, "actor_updates": runner.policy_updates}, overwrite=False)
        finally:
            runner.close()


if __name__ == "__main__":
    main()
