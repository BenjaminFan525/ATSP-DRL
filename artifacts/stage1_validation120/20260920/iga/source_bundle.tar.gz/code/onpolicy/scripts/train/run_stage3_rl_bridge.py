#!/usr/bin/env python3
"""Prepare, verify and supervise the finite four-arm RL study. IGA is frozen."""
import argparse
import copy
import fcntl
import importlib.metadata
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.utils.stage3_rl_bridge import (
    SCHEMA, ARMS, LATENT, identity, verify, queue, baseline_costs, risk_pass, select_candidate, diagnostic_summary,
)
from onpolicy.utils.stage3_b0_protocol import B0_SHA, EVALUATION, HISTORY, PLANNING
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json, stratified_cases, paired_summary
from onpolicy.utils.stage3_numerics import RUNTIME
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat

NEW_FILES = (
    'onpolicy/utils/stage3_rl_bridge.py', 'onpolicy/algorithms/utils/stage3_native_latent.py',
    'onpolicy/runner/shared/stage3_rl_bridge_engine.py', 'onpolicy/runner/shared/stage3_research_engine.py',
    'onpolicy/scripts/train/stage3_rl_bridge_worker.py', 'onpolicy/scripts/train/run_stage3_rl_bridge.py',
    'onpolicy/scripts/train/launch_stage3_rl_bridge.sh',
    'onpolicy/envs/HKBZ/test/test_stage3_rl_bridge.py', 'STAGE3_RL_BRIDGE_20260915.md',
)


def resolve_baseline(path):
    seen = set()
    while True:
        path = Path(path).resolve()
        if str(path) in seen:
            raise ValueError('Cyclic inherited baseline')
        seen.add(str(path))
        row = read_json(path)
        if 'costs' in row:
            return path, row, seen
        path = row['path']


def prepare(args):
    prior = read_json(args.prior)
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError('A new immutable experiment directory is required')
    if (prior['source']['sha256'] != B0_SHA or prior['contract'] != PLANNING
            or prior['evaluation'] != EVALUATION or prior['resources']['memory_max_gib'] is not None):
        raise ValueError('Expected the completed uncapped, H2/F4/soft B0 parent')
    prior_result = read_json(Path(prior['root'])/'result.json')
    if not prior_result['training_completed']:
        raise ValueError('Do not replace an unfinished parent training run')
    gpu_info = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,memory.total',
                                      '--format=csv,noheader,nounits'], text=True)
    gpus = [{'index': int(a.strip()), 'uuid': b.strip(), 'memory_mib': int(c.strip())}
            for a, b, c in (line.split(',') for line in gpu_info.splitlines())]
    if [x['index'] for x in gpus] != list(range(8)):
        raise ValueError('Eight GPUs are required')
    from onpolicy.utils.stage3_representation import discover_topology
    if discover_topology() != prior['resources']['core_groups']:
        raise ValueError('CPU topology differs from the approved prior resource layout')
    splits = {k: prior['splits'][k] for k in ('train_full600', 'validation', 'tune', 'confirmation')}
    splits['train_screen96'] = stratified_cases(splits['train_full600'],
        {'iid': 48, 'ood_stress': 43, 'ood_scale': 5}, 2026091201)
    diagnosis = stratified_cases(splits['train_full600'], {'iid': 16, 'ood_stress': 14, 'ood_scale': 2}, 2026091501)
    required_profiles = {'resource_ood', 'stress_joint', 'coupled', 'resource_sparse'}
    if not required_profiles <= {r['profile'] for r in diagnosis}:
        raise ValueError('Required failure profiles missing from fixed TrainDiag32')
    baseline_path, base, chain = resolve_baseline(Path(prior['root'])/'baselines.json')
    if (base['source_sha256'] != B0_SHA or base['evaluation'] != EVALUATION
            or digest_json(base['costs']) != base['costs_sha256']):
        raise ValueError('Prior local B0 baseline identity differs')
    expected_cases = {c['path'] for s in ('train_full600', 'validation', 'tune') for c in splits[s]}
    if set(base['costs']) != expected_cases:
        raise ValueError('Prior baseline does not cover the exact 780 current cases')
    # Freeze the actual last-run source, then overlay ONLY the new opt-in files.
    # In particular no unrelated dirty Stage1/Stage2 worktree edits enter this run.
    files = {}
    for relative, checksum in prior['code']['files'].items():
        source = Path(prior['execution']['code_root'])/relative
        if Path(relative).is_absolute() or '..' in Path(relative).parts or digest_file(source) != checksum:
            raise ValueError(f'Historical source changed: {relative}')
        target = output/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        files[relative] = checksum
    for relative in NEW_FILES:
        source, target = ROOT/relative, output/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        checksum = digest_file(source)
        shutil.copy2(source, target)
        if digest_file(target) != checksum:
            raise ValueError('Workspace changed during snapshot')
        files[relative] = checksum
    bundle_relative = Path(prior['source']['manifest']).relative_to(prior['execution']['code_root'])
    source = {'manifest': str(output/'source'/bundle_relative), 'sha256': B0_SHA,
              'path': str(output/'source'/bundle_relative.parent/'checkpoints/b0.pt'),
              'manifest_file_sha256': prior['source']['manifest_file_sha256']}
    resources = copy.deepcopy(prior['resources'])
    resources.update(gpus=gpus, validator_queue=str(output/'validator'), validator_workers=2,
        validator_width=3, validator_max_workers=8, formal_world_size=4, screen_world_size=2,
        tasks_max=2048, capacity_worlds=[2], capacity_comparison='fresh B0 full60 rollout / micro12 update on all8 GPUs',
        validator_lifecycle='one elastic async pool shared by ALL arms')
    resources['evaluation_plan'] = {}
    for gpu in range(8):
        cores = [c for i, c in enumerate(resources['core_groups']) if gpu*8 <= i < (gpu+1)*8 and i not in (31, 63)]
        resources['evaluation_plan'][str(gpu)] = {'gpu': gpu, 'cpus': sum(cores, []), 'width': len(cores)}
    training = copy.deepcopy(prior['training'])
    training.update(seed=2026091201, sampling_tau=.03, replicas_per_case=4,
        screen_epochs=2, screen_max_epochs=4, screen_episodes=768, formal_epochs=4,
        formal_episodes=9600, episodes_per_formal_epoch=2400, automatic_multi_seed=False,
        objective='fixed population-weighted visit mean; time and role sum; keep both advantage signs',
        population_objective={'iid': .5, 'ood_stress': .45, 'ood_scale': .05})
    for stale in ('max_training_episodes', 'episodes_per_data_epoch', 'global_batch', 'data_epochs',
                  'training_split', 'unique_training_cases', 'advantage', 'temperature_candidates'):
        training.pop(stale, None)
    previous_last = read_json(Path(prior['root'])/'model_index.json')['Last']
    references = []
    for relative, label, comparable in (
        ('stage3_matched_iga_h3f4_tune60_20260831_r1/full/iga1800/summary.json', 'H3/F4 soft full-joint', False),
        ('stage2_supervised_hf_labels_20260901_r1/hf_search/refine/H2_F4/iga1800/summary.json', 'H2/F4 soft resource-only', False)):
        path = ROOT/'result/hkbz_train_logs'/relative
        if path.exists():
            references.append({'path': str(path), 'sha256': digest_file(path), 'scope': label, 'matched_full_joint': comparable})
    inputs = {str(args.prior.resolve()): digest_file(args.prior),
              **{p: digest_file(p) for p in chain}, previous_last['checkpoint']: previous_last['checkpoint_sha256'],
              **{r['path']: r['sha256'] for r in references}}
    reused_base = {**base, 'reused_from': str(baseline_path),
        'reuse_scope': 'same frozen executor; zero-update full paired validation required before training'}
    m = {'schema': SCHEMA, 'root': str(output), 'created_unix': time.time(),
        'baselines_sha256': digest_json(reused_base),
        'material_passport': {'origin_skill': 'academic-research-suite/experiment-agent', 'origin_mode': 'run',
            'origin_date': '2026-09-15', 'verification_status': 'prepared; scientific outcomes unverified'},
        'source': source, 'contract': PLANNING, 'evaluation': EVALUATION, 'history': HISTORY,
        'numerics': RUNTIME, 'arms': ARMS, 'latent': LATENT, 'training': training, 'splits': splits,
        'resources': resources,
        'throughput': {'rollout_envs_per_rank': 60, 'backward_trajectories_per_rank': 12,
            'optimizer_step_per_microbatch': True, 'environment_start_method': 'forkserver',
            'stochastic_batching': prior['throughput']['stochastic_batching'],
            'host_memory_limit_removed': True},
        'diagnostic': {'cases32': diagnosis, 'role_mix_cases12': stratified_cases(diagnosis,
            {'iid': 6, 'ood_stress': 5, 'ood_scale': 1}, 2026091502), 'previous_last': previous_last},
        'iga': {'mode': 'frozen_artifacts_only', 'allow_solve': False, 'references': references,
                'matched_superiority_claim_allowed': False},
        'automatic_confirmation': False, 'automatic_active_search': False,
        'exposure': {'validation_and_tune': 'previously exposed development sets',
                     'confirmation': 'sealed; both-host lock and separate agreement required'},
        'gates': {'screen_validation_gain': .0025, 'formal_gain': .02,
                  'extension': 'any new arm has nonnegative Tune, positive Val and Val better than control',
                  'formal_mid': 'both Val epochs positive; latest Val >=.005, both splits beat P0; both risks pass'},
        'code': {'files': files, 'sha256': digest_json(files)}, 'input_files': inputs,
        'execution': {**copy.deepcopy(prior['execution']), 'code_root': str(output/'source'),
            'workspace_root': str(ROOT), 'worker': 'onpolicy/scripts/train/stage3_rl_bridge_worker.py',
            'python': sys.executable, 'base_source_sha256': prior['code']['sha256'],
            'workspace_protection': 'advisory; immutable snapshot strict'},
        'timeouts_seconds': copy.deepcopy(prior['timeouts_seconds'])}
    m['comparison_sha256'] = digest_json({'source': B0_SHA, 'environment': PLANNING,
        'evaluation': EVALUATION, 'cases': {s: [c['content_sha256'] for c in splits[s]] for s in ('validation', 'tune')}})
    m['manifest_sha256'] = identity(m)
    atomic_json(output/'manifest.json', m, overwrite=False)
    atomic_json(output/'baselines.json', reused_base, overwrite=False)
    atomic_json(output/'validator/mode.json', {'mode': 'training'})
    print({'manifest': str(output/'manifest.json'), 'arms': list(ARMS), 'iga': 'frozen; no solving'})


def seal_tests(m, junit):
    verify(m, source_root=ROOT)
    xml = ET.parse(junit).getroot()
    cases = list(xml.iter('testcase'))
    if not cases or any(c.find(x) is not None for c in cases for x in ('failure', 'error', 'skipped')):
        raise ValueError('Required CPU tests must all pass without skips')
    for prefix in ('test_group', 'test_native', 'test_queue', 'test_selection', 'test_objective'):
        if not any(prefix in c.attrib.get('name', '') for c in cases):
            raise ValueError(f'Required CPU tests missing: {prefix}')
    atomic_json(Path(m['root'])/'verification.json', {'passed': True, 'test_cases': len(cases),
        'junit': str(junit.resolve()), 'junit_sha256': digest_file(junit),
        'manifest_sha256': m['manifest_sha256'], 'code_sha256': m['code']['sha256'],
        'gpu_admission': 'pending real complete-trajectory capacity/replay/resume tests'}, overwrite=False)


def child_environment(m, gpu):
    env = os.environ.copy()
    env.update(CUDA_VISIBLE_DEVICES=str(gpu), CUDA_DEVICE_ORDER='PCI_BUS_ID',
        HKBZ_STAGE3_WORKSPACE_ROOT=m['execution']['workspace_root'], PYTHONPATH=m['execution']['code_root'],
        PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
        NUMEXPR_NUM_THREADS='1', MALLOC_ARENA_MAX='2', CUBLAS_WORKSPACE_CONFIG=':4096:8')
    return env


def launch_worker(m, manifest, *, gpu, output, extra):
    output.mkdir(parents=True, exist_ok=True)
    command = [m['execution']['python'], '-B', '-u', str(ROOT/m['execution']['worker']),
        '--manifest', str(manifest), '--global-gpu', str(gpu), '--output', str(output), *map(str, extra)]
    log = (output/'worker.log').open('ab')
    process = subprocess.Popen(command, cwd=ROOT, env=child_environment(m, gpu), stdout=log, stderr=subprocess.STDOUT)
    log.close()
    atomic_json(output/f'process_{process.pid}.json', {'pid': process.pid, 'command': command,
        'started_unix': time.time(), 'gpu': gpu}, overwrite=False)
    return process


def run_pool(m, manifest):
    verify(m, source_root=ROOT)
    root = Path(m['root'])/'validator'
    lock = (root/'pool.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    workers, generations = {}, {i: 0 for i in range(8)}
    start = time.time()
    with ProgressHeartbeat(root/'pool_heartbeat.json', pid=os.getpid()) as hb:
        while True:
            mode = read_json(root/'mode.json')['mode']
            desired = set() if mode == 'stop' else (set(range(8)) if mode == 'evaluation_only' else {0, 4})
            for gpu, p in list(workers.items()):
                code = p.poll()
                if code is not None:
                    if code != 0 or gpu in desired:
                        atomic_json(root/'pool_error.json', {'gpu': gpu, 'pid': p.pid, 'exit_code': code,
                            'message': 'Unexpected worker exit; automatic retry disabled'})
                        raise RuntimeError('Shared validator worker failed')
                    del workers[gpu]
            for gpu in sorted(desired-set(workers)):
                generations[gpu] += 1
                output = root/'workers'/f'gpu{gpu}_g{generations[gpu]}'
                workers[gpu] = launch_worker(m, manifest, gpu=gpu, output=output,
                    extra=['--task', 'validator']+(['--boost'] if gpu not in (0, 4) else []))
            atomic_json(root/'pool_status.json', {'mode': mode, 'workers': {str(g): p.pid for g, p in workers.items()},
                'pid': os.getpid(), 'unix': time.time()})
            hb.update(event='pool_supervision', mode=mode, workers=len(workers))
            if mode == 'stop' and not workers:
                break
            if time.time()-start > m['timeouts_seconds']['validator']:
                raise TimeoutError('Shared validator hard timeout')
            time.sleep(3)


class BridgeSuite:
    def __init__(self, m, manifest):
        self.m, self.manifest, self.root = m, manifest, Path(m['root'])
        self.start = time.time()
        self.lock = (self.root/'controller.lock').open('a+')
        fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def check(self):
        if (self.root/'validator/pool_error.json').exists():
            raise RuntimeError('Shared validator failed; training admission/selection blocked')
        status = self.root/'validator/pool_status.json'
        if not status.exists() or time.time()-read_json(status)['unix'] > 120:
            raise RuntimeError('Shared validator pool heartbeat unavailable')
        if time.time()-self.start > self.m['timeouts_seconds']['train']:
            raise TimeoutError('Finite experiment hard timeout')

    def pool_mode(self, mode, hb):
        atomic_json(self.root/'validator/mode.json', {'mode': mode, 'unix': time.time()})
        while True:
            self.check()
            status = read_json(self.root/'validator/pool_status.json')
            target = 2 if mode == 'training' else 8
            if status['mode'] == mode and len(status['workers']) == target:
                return
            hb.update(event='validator_pool_transition', target_mode=mode, live_workers=len(status['workers']))
            time.sleep(3)

    def execute(self, task, phase, arms, until_epochs, hb, *, resume=False, execution_tag=None):
        self.pool_mode('training', hb)
        processes = []
        stage_start = time.time()
        stamp = f'{task}_{phase}_{until_epochs}'
        if execution_tag is not None:
            if not execution_tag.replace('_', '').isalnum():
                raise ValueError('Unsafe execution tag')
            stamp += '_'+execution_tag
        atomic_json(self.root/'status.json', {'status': 'running', 'phase': stamp,
            'arms': arms, 'iga': 'frozen; no solving', 'unix': time.time()})
        for arm, gpus in arms.items():
            rendezvous = self.root/'rendezvous'/f'{stamp}_{arm}'
            rendezvous.parent.mkdir(parents=True, exist_ok=True)
            if rendezvous.exists():
                raise FileExistsError('Rendezvous already used; no implicit restart')
            for rank, gpu in enumerate(gpus):
                output = self.root/('canary' if task=='canary' else phase)/arm/f'rank{rank}'
                extra = ['--task', task, '--arm', arm, '--phase', phase, '--rank', rank,
                    '--world-size', len(gpus), '--rendezvous', rendezvous, '--until-epochs', until_epochs]
                if resume:
                    commits = sorted((self.root/phase/arm/'commits').glob('*.json'))
                    if not commits:
                        raise ValueError('Extension requires a complete multi-rank commit')
                    extra += ['--resume-commit', commits[-1]]
                processes.append((arm, rank, launch_worker(self.m, self.manifest, gpu=gpu, output=output, extra=extra)))
        while True:
            self.check()
            if time.time()-stage_start > self.m['timeouts_seconds']['capacity' if task == 'canary' else 'train']:
                raise TimeoutError(f'{task}/{phase} exceeded the frozen phase deadline')
            codes = [(arm, rank, p.poll()) for arm, rank, p in processes]
            if any(code not in (None, 0) for _, _, code in codes):
                atomic_json(self.root/'worker_failure.json', {'phase': stamp, 'exits': codes,
                    'message': 'No automatic retry; all existing artifacts retained'})
                raise RuntimeError(f'{stamp} worker failed: {codes}')
            if all(code == 0 for _, _, code in codes):
                break
            hb.update(event='workers_running', phase=stamp, live=sum(code is None for _, _, code in codes))
            time.sleep(10)
        atomic_json(self.root/f'{stamp}_completed.json', {'exits': codes, 'unix': time.time()}, overwrite=False)
        self.pool_mode('evaluation_only', hb)

    def wait_requests(self, ids, hb):
        while True:
            self.check()
            results = [queue(self.m).poll(i) for i in ids]
            if all(r is not None for r in results):
                return results
            hb.update(event='waiting_shared_validation', pending=sum(r is None for r in results), total=len(ids))
            time.sleep(5)

    def collect_epoch(self, phase, arm, epoch, hb):
        index = read_json(self.root/phase/arm/f'epochs/e{epoch:02d}.json')
        summaries = {}
        for split, ids in index['requests'].items():
            results = self.wait_requests(ids, hb)
            rows = [row for r in results for row in r['evaluation']['cases']]
            if ({r['case_id'] for r in rows} != {c['path'] for c in self.m['splits'][split]}
                    or len(rows) != len(self.m['splits'][split])):
                raise ValueError('Incomplete/duplicated full-split validation')
            summary = paired_summary(rows, baseline_costs(self.m))
            summaries[split] = summary
            target = self.root/phase/arm/f'evaluations/e{epoch:02d}_{split}.json'
            if not target.exists():
                atomic_json(target, {'cases': rows, 'summary': summary, 'checkpoint': index['checkpoint'],
                    'checkpoint_sha256': index['checkpoint_sha256']}, overwrite=False)
        return summaries

    def admission(self, hb):
        self.execute('canary', 'screen', {a: r['gpus'] for a, r in ARMS.items()}, 2, hb)
        results = [read_json(self.root/'canary'/a/f'rank{r}/result.json') for a in ARMS for r in range(2)]
        if not all(r['passed'] for r in results):
            raise ValueError('Technical canary failed')
        base = {r['case_id']: r for r in read_json(self.root/'baselines.json')['cases']}
        pairs = {}
        for arm in ARMS:
            index = read_json(self.root/'canary'/arm/'rank0/initial_evaluations.json')
            results = self.wait_requests(index['requests'], hb)
            rows = [row for result in results for row in result['evaluation']['cases']]
            if len(rows) != 180 or len({r['case_id'] for r in rows}) != 180:
                raise ValueError('Zero-update requires the full180 paired development cases')
            errors = [r['case_id'] for r in rows if any(r[key] != base[r['case_id']][key]
                for key in ('action_sha256', 'steps')) or abs(r['makespan']-base[r['case_id']]['makespan']) > 1e-6]
            pairs[arm] = {'case_count': len(rows), 'mismatches': errors}
            if errors:
                raise RuntimeError(f'{arm} full180 zero-update mismatch')
        atomic_json(self.root/'training_admission.json', {'passed': True, 'zero_update_pairs': pairs,
            'manifest_sha256': self.m['manifest_sha256'], 'diagnostic_weights_used': False,
            'iga_solve_count': 0, 'cpu_tests': read_json(self.root/'verification.json')}, overwrite=False)

    def diagnostics(self, phase, arms, epoch, hb):
        from onpolicy.scripts.train.stage3_rl_bridge_worker import submit_evaluation
        ids = []
        cases = self.m['diagnostic']['cases32']
        for arm in arms:
            index = read_json(self.root/phase/arm/f'epochs/e{epoch:02d}.json')
            for kind in ('greedy', 'sampling'):
                ids += submit_evaluation(self.m, index['checkpoint'], arm, index['training_episodes'],
                    f'diag_{phase}', split='train_diag32', kind=kind, cases=cases)
        # A fixed B0 sampling reference: never attribute existing best-of4 gains to RL.
        ids += submit_evaluation(self.m, self.m['source']['path'], 'B0', 0, f'diag_{phase}',
            split='train_diag32', kind='sampling', cases=cases)
        if not (self.root/'role_mix_submitted.json').exists():
            previous = self.m['diagnostic']['previous_last']
            for bits in range(8):
                mix = [(bits >> role) & 1 for role in range(3)]
                ids += submit_evaluation(self.m, previous['checkpoint'], 'B0', previous['training_episodes'],
                    f'role_mix_{bits}', split='train_diag12', kind='role_mix',
                    cases=self.m['diagnostic']['role_mix_cases12'], role_mix=mix)
            atomic_json(self.root/'role_mix_submitted.json', {'requests': ids, 'scope': 'previous RL vs B0'}, overwrite=False)
        results = self.wait_requests(ids, hb)
        evaluations = [r['evaluation'] for r in results]
        atomic_json(self.root/f'diagnostics_{phase}.json', {'requests': ids,
            'evaluations': evaluations, 'summary': diagnostic_summary(evaluations, baseline_costs(self.m)),
            'iga_solve_count': 0}, overwrite=False)

    def run(self):
        verify(self.m, source_root=ROOT)
        receipt = read_json(self.root/'verification.json')
        if not receipt['passed'] or receipt['manifest_sha256'] != self.m['manifest_sha256']:
            raise ValueError('Source-matched CPU tests must be sealed before launch')
        with ProgressHeartbeat(self.root/'heartbeat.json', pid=os.getpid(), iga='frozen') as hb:
            self.admission(hb)
            arms = {a: r['gpus'] for a, r in ARMS.items()}
            self.execute('train', 'screen', arms, 2, hb)
            evaluations = {a: self.collect_epoch('screen', a, 2, hb) for a in ARMS}
            for a in ARMS:
                self.collect_epoch('screen', a, 1, hb)
            candidate = select_candidate(evaluations)
            epoch = 2
            extend = candidate is None and any(a != 'P0_SOURCE' and r['validation']['gain_fraction'] > 0
                and r['tune']['gain_fraction'] >= 0
                and r['validation']['makespan'] < evaluations['P0_SOURCE']['validation']['makespan']
                for a, r in evaluations.items())
            atomic_json(self.root/'screen_initial_review.json', {'evaluations': evaluations,
                'candidate': candidate, 'paired_extension': extend}, overwrite=False)
            if extend:
                self.execute('train', 'screen', arms, 4, hb, resume=True)
                evaluations = {a: self.collect_epoch('screen', a, 4, hb) for a in ARMS}
                for a in ARMS:
                    self.collect_epoch('screen', a, 3, hb)
                candidate, epoch = select_candidate(evaluations), 4
            atomic_json(self.root/'screen_admission.json', {'candidate': candidate, 'epochs': epoch,
                'evaluations': evaluations, 'selection_rule': 'risk-qualified Val improvement, Tune veto'}, overwrite=False)
            if candidate is None:
                self.diagnostics('screen', list(ARMS), epoch, hb)
                return self.finish({'training_completed': True, 'formal_training_started': False,
                    'reason': 'no_greedy_candidate_passed_screen', 'screen_epochs': epoch})
            formal_arms = {'P0_SOURCE': [0, 1, 2, 3], candidate: [4, 5, 6, 7]}
            self.execute('train', 'formal', formal_arms, 2, hb)
            curves = {a: [self.collect_epoch('formal', a, e, hb) for e in (1, 2)] for a in formal_arms}
            current, control = curves[candidate][-1], curves['P0_SOURCE'][-1]
            proceed = (all(x['validation']['gain_fraction'] > 0 for x in curves[candidate])
                and current['validation']['gain_fraction'] >= .005
                and all(current[s]['makespan'] < control[s]['makespan'] for s in ('validation', 'tune'))
                and current['tune']['gain_fraction'] >= 0 and all(risk_pass(current[s]) for s in ('validation', 'tune')))
            atomic_json(self.root/'formal_mid_review.json', {'continue_to_9600': proceed,
                'candidate': candidate, 'evaluations': curves}, overwrite=False)
            final_epoch = 2
            if proceed:
                self.execute('train', 'formal', formal_arms, 4, hb, resume=True)
                for a in formal_arms:
                    curves[a] += [self.collect_epoch('formal', a, e, hb) for e in (3, 4)]
                final_epoch = 4
            eligible = [(e+1, row) for e, row in enumerate(curves[candidate])
                        if all(risk_pass(row[s]) for s in ('validation', 'tune'))]
            best_epoch, best = (min(eligible, key=lambda pair: pair[1]['validation']['makespan']) if eligible else
                                (final_epoch, curves[candidate][-1]))
            index = read_json(self.root/'formal'/candidate/f'epochs/e{best_epoch:02d}.json')
            target = bool(eligible) and all(best[s]['gain_fraction'] >= .02 for s in ('validation', 'tune'))
            target = target and all(x['validation']['gain_fraction'] > 0 for x in curves[candidate][-2:])
            atomic_json(self.root/'candidate_lock.json', {'arm': candidate, 'epoch': best_epoch,
                'checkpoint': index['checkpoint'], 'checkpoint_sha256': index['checkpoint_sha256'],
                'risk_qualified': bool(eligible), 'development_target_met': target,
                'last_epoch': final_epoch, 'confirmation_opened': False}, overwrite=False)
            atomic_json(self.root/'learning_curves.json', curves, overwrite=False)
            self.diagnostics('formal', list(formal_arms), final_epoch, hb)
            self.finish({'training_completed': True, 'formal_training_started': True, 'candidate': candidate,
                'formal_epochs': final_epoch, 'development_target_met': target, 'risk_qualified': bool(eligible)})

    def finish(self, result):
        result.update(iga_solve_count=0, iga_status='frozen; heterogeneous historical references only',
                      scientific_target_confirmed=False, confirmation_status='sealed')
        atomic_json(self.root/'result.json', result, overwrite=False)
        atomic_json(self.root/'status.json', {'status': 'completed', **result, 'unix': time.time()})
        atomic_json(self.root/'validator/mode.json', {'mode': 'stop', 'reason': 'all planned evaluations completed'})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('prepare', 'seal-tests', 'pool', 'run'))
    parser.add_argument('--prior', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--junit', type=Path)
    args = parser.parse_args()
    if args.command == 'prepare':
        return prepare(args)
    m = read_json(args.manifest)
    if args.command == 'seal-tests':
        return seal_tests(m, args.junit)
    if args.command == 'pool':
        return run_pool(m, args.manifest)
    try:
        BridgeSuite(m, args.manifest).run()
    except BaseException as exc:
        atomic_json(Path(m['root'])/'status.json', {'status': 'failed', 'error': str(exc),
            'traceback': traceback.format_exc(), 'unix': time.time(), 'automatic_retry': False,
            'iga_solve_count': 0})
        raise


if __name__ == '__main__':
    main()
