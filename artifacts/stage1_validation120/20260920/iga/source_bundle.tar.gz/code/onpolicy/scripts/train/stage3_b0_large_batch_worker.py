"""Large-batch training continuation; no diagnostic checkpoint is consumable."""
import gc
from pathlib import Path
import time
import torch

from onpolicy.scripts.train.stage3_b0_worker import engine, metadata, attach_journal, collect
from onpolicy.scripts.train.run_stage3_sampling_audit import save_group
from onpolicy.scripts.train.stage3_local_worker import frozen_state, assert_frozen
from onpolicy.utils.stage3_b0_protocol import baseline_costs, queue, submit_split, submit_mechanism, MECHANISM
from onpolicy.utils.stage3_b0_throughput import continuation_plan, restore_parent, parent_manifest
from onpolicy.utils.stage3_b0_throughput import completed_epoch
from onpolicy.utils.stage3_distributed import state_digest
from onpolicy.utils.stage3_full_policy import shard
from onpolicy.utils.stage3_numerics import training_state
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json


def train(args, m, sync, hb):
    root = Path(m['root'])
    parent_manifest(m)
    admission = read_json(root / 'training_admission.json')
    if (not admission['passed'] or admission['protocol_sha256'] != m['manifest_sha256']
            or args.world_size != 8 or args.until != m['training']['max_training_episodes']
            or admission['global_batch'] != m['training']['global_batch']
            or admission['parent_commit_sha256'] != m['throughput']['resume_commit_sha256']
            or admission['sampling_sha256'] != digest_file(root / 'sampling_admission.json')
            or any(digest_file(p) != h for p, h in admission['evidence'].items())):
        raise ValueError('Measured large-batch admission required')
    costs = baseline_costs(m)
    plan = continuation_plan(m)
    schedule_sha, recipe_sha = digest_json(plan), digest_file(root / 'training_admission.json')
    width = m['throughput']['rollout_envs_per_rank']
    backward_width = m['throughput']['backward_trajectories_per_rank']
    runner = engine(m, 'F_PRIVATE', width)
    cursor = 0
    try:
        if args.resume_commit:
            commit = read_json(args.resume_commit)
            if (commit['protocol_sha256'] != m['manifest_sha256'] or commit['world_size'] != 8
                    or commit['schedule_sha256'] != schedule_sha or commit['recipe_sha256'] != recipe_sha):
                raise ValueError('Large-batch resume commit differs')
            entry = commit['ranks'][args.rank]
            if entry['rank'] != args.rank or digest_file(entry['checkpoint']) != entry['sha256']:
                raise ValueError('Large-batch committed checkpoint changed')
            payload = runner.resume(entry['checkpoint'], protocol_sha256=m['manifest_sha256'],
                                    exploration=runner.exploration)
            cursor = payload['next_group']
            if (payload.get('diagnostic_only') or payload['rank'] != args.rank or not 0 < cursor <= len(plan)
                    or payload['training_episodes'] != plan[cursor-1]['training_episodes']
                    or commit['training_episodes'] != payload['training_episodes']):
                raise ValueError('Large-batch resume cursor differs')
        else:
            payload = restore_parent(runner, m, args.rank)
        atomic_json(args.output / 'resume_verified.json', {
            'passed': True, 'source_protocol_sha256': payload['protocol_sha256'],
            'source_training_episodes': payload['training_episodes'],
            'source_actor_updates': payload['policy_updates'],
            'full_training_state_sha256': state_digest(training_state(runner)),
            'optimizer_normalizers_rng_restored': True, 'diagnostic_weights_used': False,
            'global_batch': m['training']['global_batch'], 'rollout_envs': width,
            'backward_trajectories': backward_width, 'tbptt_steps': 8,
            'rollout_trajectories': m['training']['global_batch']//8,
            'gradient_accumulation_microbatches': m['throughput'].get('gradient_accumulation_microbatches', 1),
            'optimizer_minibatches': m['throughput'].get('optimizer_minibatches', 1),
            'optimizer_step_per_microbatch': m['throughput'].get('optimizer_step_per_microbatch', False),
            'environment_start_method': runner.environment_start_method,
            'live_environment_workers': sum(p.is_alive() for p in runner.pool.processes),
        }, overwrite=False)
        sync.assert_replicas(runner)
        frozen = frozen_state(runner)
        for index in range(cursor, len(plan)):
            sync.barrier()
            # Every rank observes the same stop decision at the commit boundary.
            stop = sync.gather((root / 'PAUSE_AFTER_COMMIT').exists())[0]
            if stop:
                episodes = m['throughput']['start_episodes'] if index == 0 else plan[index-1]['training_episodes']
                atomic_json(args.output / 'result.json', {'completed': False, 'paused': True,
                    'training_episodes': episodes, 'next_group': index,
                    'actual_actor_updates': runner.policy_updates}, overwrite=False)
                hb.update(event='paused_at_commit', training_episodes=episodes)
                return
            while queue(m).pending_count('C_PRIVATE') >= 24:
                hb.update(event='shared_validator_backpressure', next_group=index)
                time.sleep(5)
            batch = plan[index]
            before_episodes = m['throughput']['start_episodes'] if index == 0 else plan[index-1]['training_episodes']
            hb.update(event='batch_start', training_episodes=before_episodes, global_batch=index+1,
                global_batch_size=batch['batch_size'], rollout_envs=width,
                backward_trajectories=min(backward_width, batch['batch_size']//8),
                rollout_trajectories=batch['batch_size']//8,
                backward_microbatches=(batch['batch_size']//8+backward_width-1)//backward_width,
                data_epoch=batch['data_epoch'],
                actual_actor_updates=runner.policy_updates, epoch_tail=batch['epoch_tail'])
            begin = time.time()
            torch.cuda.reset_peak_memory_stats()
            group = collect(runner, shard(batch, args.rank, args.world_size), hb)
            torch.cuda.synchronize()
            rollout_seconds = time.time() - begin
            rollout_memory = {'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,
                              'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30}
            rollout_inference = dict(runner.last_rollout_inference)
            if any(t.get('synthetic_prefix_fixture') for t in group):
                raise ValueError('Hardware prefix fixtures must never enter formal training')
            save_group(args.output / f'rollouts/group_{index+1:04d}.json', group,
                metadata(m, diagnostic_only=False, rank=args.rank, visit_ids=batch['visit_ids'],
                         global_batch_size=batch['batch_size']))
            attach_journal(runner, args.output / f'updates/group_{index+1:04d}_attempts.jsonl')
            begin = time.time()
            torch.cuda.reset_peak_memory_stats()
            update = runner.update(group, 'source', costs, distributed=sync, heartbeat=hb,
                                   epochs=m['training']['ppo_epochs'], chunk=m['training']['tbptt_steps'],
                                   microbatch_size=backward_width,
                                   optimizer_step_per_microbatch=m['throughput'].get('optimizer_step_per_microbatch', False))
            update_seconds = time.time() - begin
            update.update(global_batch_size=batch['batch_size'], rollout_trajectories=len(group),
                          rollout_memory=rollout_memory, rollout_inference=rollout_inference,
                          update_memory={'peak_allocated_gib':torch.cuda.max_memory_allocated()/2**30,
                                         'peak_reserved_gib':torch.cuda.max_memory_reserved()/2**30},
                          backward_trajectories=min(backward_width, len(group)),
                          rollout_seconds=rollout_seconds, update_seconds=update_seconds,
                          batch_seconds=rollout_seconds+update_seconds)
            atomic_json(args.output / f'updates/group_{index+1:04d}.json', update, overwrite=False)
            assert_frozen(runner, frozen)
            sync.assert_replicas(runner)
            episodes = batch['training_episodes']
            checkpoint = args.output / f'models/episodes_{episodes:06d}.pt'
            checksum = runner.save(checkpoint, **metadata(m, diagnostic_only=False,
                training_episodes=episodes, next_group=index+1, rank=args.rank, world_size=8,
                schedule_sha256=schedule_sha, recipe_sha256=recipe_sha,
                global_batch_size=batch['batch_size'], throughput=m['throughput']))
            entries = sync.gather({'rank': args.rank, 'checkpoint': str(checkpoint), 'sha256': checksum})
            if args.rank == 0:
                atomic_json(root / f'train/commits/episodes_{episodes:06d}.json', {
                    'ranks': entries, 'world_size': 8, 'schedule_sha256': schedule_sha,
                    'recipe_sha256': recipe_sha, 'training_episodes': episodes,
                    'actual_actor_updates': runner.policy_updates, 'protocol_sha256': m['manifest_sha256'],
                    'global_batch_size': batch['batch_size'], 'parent_commit_sha256': m['throughput']['resume_commit_sha256'],
                }, overwrite=False)
                epoch = completed_epoch(m, episodes)
                if epoch not in (None, 0):
                    requests = [r for split in ('validation', 'tune') for r in submit_split(m, checkpoint,
                        'C_PRIVATE', episodes, 'F_PRIVATE', split=split, training_exploration=runner.exploration)]
                    atomic_json(root / f'epochs/e{episodes:06d}.json', {'requests': requests,
                        'checkpoint': str(checkpoint), 'checkpoint_sha256': checksum,
                        'training_episodes': episodes, 'actual_actor_updates': runner.policy_updates}, overwrite=False)
                    if epoch in MECHANISM['data_epochs']:
                        requests = submit_mechanism(m, checkpoint, episodes)
                        atomic_json(root / f'mechanism/e{episodes:06d}.json', {'requests': requests,
                            'checkpoint_sha256': checksum, 'training_episodes': episodes}, overwrite=False)
            hb.update(event='batch_committed', training_episodes=episodes,
                actual_actor_updates=runner.policy_updates, rollout_seconds=rollout_seconds,
                update_seconds=update_seconds, batch_seconds=rollout_seconds+update_seconds)
            del group
            gc.collect()
            if runner.zero_update_batches >= 3:
                raise RuntimeError('Three zero-update batches; committed state retained')
        atomic_json(args.output / 'result.json', {'completed': True,
            'training_episodes': m['training']['max_training_episodes'],
            'actual_actor_updates': runner.policy_updates}, overwrite=False)
    finally:
        runner.close()
