#!/usr/bin/env python3
"""Finite four-arm temperature study, one shared async validator pool."""
import argparse
import copy
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.utils.stage3_tau import (SCHEMA, ARMS, TEMPERATURE, GATES, verify, risk_pass,
    select_candidate, data_budget, subset_contract)
from onpolicy.utils.stage3_rl_bridge import identity, queue, baseline_costs, diagnostic_summary
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_json, digest_file, paired_summary
from onpolicy.scripts.train.run_stage3_rl_bridge import BridgeSuite, run_pool
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
from onpolicy.utils.stage3_host_guard import SAFETY, REPLAY_STORAGE, host_snapshot, GIB

NEW_FILES = (
    'onpolicy/utils/stage3_tau.py', 'onpolicy/utils/stage3_rl_bridge.py',
    'onpolicy/runner/shared/stage3_tau_engine.py', 'onpolicy/runner/shared/stage3_rl_bridge_engine.py',
    'onpolicy/runner/shared/stage3_research_engine.py',
    'onpolicy/scripts/train/stage3_rl_bridge_worker.py', 'onpolicy/scripts/train/stage3_tau_worker.py',
    'onpolicy/scripts/train/run_stage3_tau.py', 'onpolicy/scripts/train/launch_stage3_tau.sh',
    'onpolicy/envs/HKBZ/test/test_stage3_tau.py', 'STAGE3_TAU_FULL600_20260916.md',
    'onpolicy/utils/stage3_replay_store.py', 'onpolicy/utils/stage3_host_guard.py',
    'onpolicy/scripts/train/run_stage3_rl_bridge.py',
    'onpolicy/envs/HKBZ/test/test_stage3_tau_safety.py',
    'STAGE3_TAU_RECOVERY_20260916.md',
    'STAGE3_TAU_SUBSET240_20260916.md',
    'onpolicy/envs/HKBZ/test/test_stage3_tau_subset240.py',
)


def prepare(args):
    from onpolicy.utils.stage3_rl_bridge import verify as verify_parent
    from onpolicy.utils.stage3_representation import discover_topology
    prior = read_json(args.prior)
    verify_parent(prior)
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError('New experiments must use a new immutable output directory')
    if not read_json(Path(prior['root'])/'result.json')['training_completed']:
        raise ValueError('Parent training must have finished')
    if discover_topology() != prior['resources']['core_groups']:
        raise ValueError('Approved physical CPU placement changed')
    gpu_info = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,memory.total',
                                       '--format=csv,noheader,nounits'], text=True)
    gpus = [dict(index=int(a), uuid=b.strip(), memory_mib=int(c))
            for a, b, c in (line.split(',') for line in gpu_info.splitlines())]
    if [g['index'] for g in gpus] != list(range(8)):
        raise ValueError('Eight GPUs required by the approved plan')
    # Snapshot the known parent plus explicit opt-in changes. Do not include
    # unrelated dirty Stage1/2 files, and never demand a clean worktree.
    files = {}
    for relative, expected in prior['code']['files'].items():
        if Path(relative).is_absolute() or '..' in Path(relative).parts:
            raise ValueError('Unsafe source snapshot entry')
        source = Path(prior['execution']['code_root'])/relative
        if digest_file(source) != expected:
            raise ValueError(f'Parent source changed: {relative}')
        target = output/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        files[relative] = expected
    for relative in NEW_FILES:
        source, target = ROOT/relative, output/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        expected = digest_file(source)
        shutil.copy2(source, target)
        if digest_file(target) != expected:
            raise ValueError('Source changed while snapshotting')
        files[relative] = expected
    m = copy.deepcopy(prior)
    m.update(schema=SCHEMA, root=str(output), created_unix=time.time(), arms=ARMS,
        temperature=TEMPERATURE, gates=GATES, code=dict(files=files, sha256=digest_json(files)))
    m.pop('latent', None)
    for key in ('manifest', 'path'):
        relative = Path(prior['source'][key]).relative_to(prior['execution']['code_root'])
        m['source'][key] = str(output/'source'/relative)
    m['material_passport'] = dict(origin_skill='academic-research-suite/experiment-agent', origin_mode='run',
        origin_date='2026-09-16', verification_status='UNVERIFIED', version_label='tau_full600_execution_v2')
    total = host_snapshot()['memory']['MemTotal']
    m['replay_storage'] = copy.deepcopy(REPLAY_STORAGE)
    m['runtime_safety'] = dict(policy=copy.deepcopy(SAFETY), host_mem_total_bytes=total,
        memory_high_bytes=total-SAFETY['high_reserve_gib']*GIB,
        memory_max_bytes=total-SAFETY['host_reserve_gib']*GIB,
        capacity_waves=[['T2_ANNEAL30'], ['T0_FIXED03', 'T1_ANNEAL10', 'T3_ANNEAL10_RISK']],
        authorization='User requested repair of host freeze and experiment restart; stop on resource/stall faults')
    if args.recovery_from:
        previous = read_json(args.recovery_from)
        if (previous['schema'] != SCHEMA or previous['arms'] != ARMS
                or previous['temperature'] != TEMPERATURE
                or any((Path(previous['root'])/'full').glob('*/commits/*.json'))):
            raise ValueError('This recovery is for the zero-formal-update tau run only')
        m['recovery_from'] = dict(manifest=str(args.recovery_from.resolve()),
            manifest_sha256=digest_file(args.recovery_from), old_artifacts_modified=False,
            formal_updates=0, restart='fresh frozen B0; never canary weights')
        m['input_files'][str(args.recovery_from.resolve())] = digest_file(args.recovery_from)
    m['resources'].update(gpus=gpus, validator_queue=str(output/'validator'), screen_world_size=2,
        formal_world_size=4, capacity_comparison='staged full600 K4; 60 env/rank; micro12; lossless graph offload',
        memory_max_gib=m['runtime_safety']['memory_max_bytes']/GIB)
    m['throughput'].update(host_memory_limit_removed=False,
        fixed_108gib_limit_removed=True, dynamic_host_reserve_protection=True)
    m['execution'].update(code_root=str(output/'source'), workspace_root=str(ROOT), python=sys.executable,
        base_source_sha256=prior['code']['sha256'])
    for key in ('screen_epochs', 'screen_max_epochs', 'screen_episodes', 'formal_epochs', 'formal_episodes',
                'episodes_per_formal_epoch', 'sampling_tau'):
        m['training'].pop(key, None)
    m['training'].update(data_epochs=8, comparison_epoch=4, episodes_per_data_epoch=2400,
        first_stage_episodes=9600, max_training_episodes=19200, unique_training_cases=600,
        training_split='train_full600', advantage='same-case K4 leave-one-out of actor objective costs',
        first_stage_total_budget=38400, maximum_total_budget=57600,
        fresh_initialization='Stage2 B0; never a diagnostic or parent-trained checkpoint',
        continuation='E4 qualifying candidate plus T0; both 2->4 GPUs; at most four more epochs')
    if args.training_subset == 'subset240':
        from onpolicy.utils.stage3_b0_subset240 import select_cases
        m['splits']['train_subset240'] = select_cases(m['splits']['train_full600'])
        m['subset_training'] = subset_contract(m['splits']['train_full600'])
        m['training'].update(data_budget(240))
        m['material_passport'].update(version_label='tau_subset240_k4_execution_v1',
            change_scope='Exact training-case subset only; absolute temperature thresholds unchanged')
    m['input_files'][str(args.prior.resolve())] = digest_file(args.prior)
    m['input_files'][str(Path(prior['root'])/'result.json')] = digest_file(Path(prior['root'])/'result.json')
    base = read_json(Path(prior['root'])/'baselines.json')
    m['baselines_sha256'] = digest_json(base)
    m['prior_manifest'] = dict(path=str(args.prior.resolve()), sha256=digest_file(args.prior))
    m['diagnostic'].update(comparison='same fixed tau and K4 across B0/all trained arms',
        decoder_kinds=['greedy', 'greedy_ar', 'sampling'], role_mix_source='current selected E4 arm, not previous Last')
    m['manifest_sha256'] = identity(m)
    atomic_json(output/'baselines.json', base, overwrite=False)
    atomic_json(output/'manifest.json', m, overwrite=False)
    atomic_json(output/'validator/mode.json', dict(mode='training'), overwrite=False)
    verify(m)
    print(dict(manifest=str(output/'manifest.json'), arms=list(ARMS),
        train_cases=m['training']['unique_training_cases'],
        first_stage_trajectories=m['training']['first_stage_total_budget'],
        maximum_trajectories=m['training']['maximum_total_budget'], iga_solve_count=0))


def seal_tests(m, junit):
    verify(m, source_root=ROOT)
    cases = list(ET.parse(junit).getroot().iter('testcase'))
    if not cases or any(c.find(k) is not None for c in cases for k in ('failure', 'error', 'skipped')):
        raise ValueError('All source-matched admission tests must pass without skips')
    for name in ('test_tau_schedule', 'test_tau_resume', 'test_tau_queue', 'test_tau_risk',
                 'test_tau_group', 'test_tau_selection', 'test_tau_engine',
                 'test_replay_store', 'test_host_guard', 'test_progress_guard'):
        if not any(name in c.attrib.get('name', '') for c in cases):
            raise ValueError(f'Required test missing: {name}')
    if m['training']['training_split'] == 'train_subset240':
        for name in ('test_tau_subset_selection', 'test_tau_subset_budget',
                     'test_tau_subset_resume', 'test_tau_subset_temperature', 'test_tau_subset_reject'):
            if not any(name in c.attrib.get('name', '') for c in cases):
                raise ValueError(f'Required subset test missing: {name}')
    atomic_json(Path(m['root'])/'verification.json', dict(passed=True, test_cases=len(cases),
        junit=str(junit.resolve()), junit_sha256=digest_file(junit), manifest_sha256=m['manifest_sha256'],
        code_sha256=m['code']['sha256'], gpu_admission='pending complete trajectory/replay/update/resume'), overwrite=False)


class TauSuite(BridgeSuite):
    def check(self):
        super().check()
        if (self.root/'guard_failure.json').exists():
            raise RuntimeError('Independent host/progress guard stopped this experiment')
        path = self.root/'guard_status.json'
        if not path.exists() or time.time()-read_json(path)['unix'] > 60:
            raise RuntimeError('Independent safety monitor unavailable; failing closed')

    def admission(self, hb):
        for index, wave in enumerate(self.m['runtime_safety']['capacity_waves']):
            self.execute('canary', 'full', {a: ARMS[a]['gpus'] for a in wave}, 4, hb,
                         execution_tag=f'capacity_wave{index}')
        results = [read_json(self.root/'canary'/a/f'rank{r}/result.json') for a in ARMS for r in range(2)]
        if not all(r['passed'] for r in results):
            raise ValueError('Technical capacity/replay/resume canary failed')
        base = {r['case_id']: r for r in read_json(self.root/'baselines.json')['cases']}
        pairs = {}
        for arm in ARMS:
            index = read_json(self.root/'canary'/arm/'rank0/initial_evaluations.json')
            rows = [r for result in self.wait_requests(index['requests'], hb) for r in result['evaluation']['cases']]
            expected = {c['path'] for s in ('validation', 'tune') for c in self.m['splits'][s]}
            if len(rows) != 180 or {r['case_id'] for r in rows} != expected:
                raise ValueError('Zero-update must cover the exact full180 cases once')
            errors = [r['case_id'] for r in rows if r['steps'] != base[r['case_id']]['steps']
                or r['action_sha256'] != base[r['case_id']]['action_sha256']
                or abs(r['makespan']-base[r['case_id']]['makespan']) > 1e-6]
            pairs[arm] = dict(case_count=180, mismatches=errors)
            if errors:
                raise ValueError(f'Full180 B0 zero-update mismatch: {arm}')
        atomic_json(self.root/'training_admission.json', dict(passed=True, zero_update_pairs=pairs,
            manifest_sha256=self.m['manifest_sha256'], diagnostic_weights_used=False, iga_solve_count=0,
            cpu_tests=read_json(self.root/'verification.json')), overwrite=False)

    def diagnostics(self, arms, epoch, hb, *, role_arm=None):
        from onpolicy.scripts.train.stage3_rl_bridge_worker import submit_evaluation
        ids = []
        cases = self.m['diagnostic']['cases32']
        for arm in ['B0', *arms]:
            index = (dict(checkpoint=self.m['source']['path'], training_episodes=0) if arm == 'B0' else
                     read_json(self.root/'full'/arm/f'epochs/e{epoch:02d}.json'))
            for kind in ('greedy', 'greedy_ar'):
                ids += submit_evaluation(self.m, index['checkpoint'], arm, index['training_episodes'],
                    f'diag_e{epoch}', split='train_diag32', kind=kind, cases=cases)
            for tau in TEMPERATURE['diagnostic_taus']:
                ids += submit_evaluation(self.m, index['checkpoint'], arm, index['training_episodes'],
                    f'diag_e{epoch}', split='train_diag32', kind='sampling', cases=cases, sampling_eval_tau=tau)
        if role_arm:
            index = read_json(self.root/'full'/role_arm/f'epochs/e{epoch:02d}.json')
            for bits in range(8):
                ids += submit_evaluation(self.m, index['checkpoint'], role_arm, index['training_episodes'],
                    f'role_e{epoch}_{bits}', split='train_diag12', kind='role_mix',
                    cases=self.m['diagnostic']['role_mix_cases12'], role_mix=[(bits >> r) & 1 for r in range(3)])
        atomic_json(self.root/f'diagnostic_requests_e{epoch}.json', dict(requests=ids, role_arm=role_arm), overwrite=False)
        evaluations = [r['evaluation'] for r in self.wait_requests(ids, hb)]
        reports = {}
        for tau in TEMPERATURE['diagnostic_taus']:
            selected = [r for r in evaluations if r['kind'] == 'greedy' or
                        r['kind'] == 'sampling' and r['sampling_eval_tau'] == tau]
            reports[str(tau)] = diagnostic_summary(selected, baseline_costs(self.m))
        atomic_json(self.root/f'diagnostics_e{epoch}.json', dict(evaluations=evaluations,
            fixed_temperature_summaries=reports, role_mix_source=role_arm,
            estimands_separated=['native_greedy', 'autoregressive_greedy', 'sampling_mean', 'best4'],
            iga_solve_count=0), overwrite=False)

    def run(self):
        verify(self.m, source_root=ROOT)
        receipt = read_json(self.root/'verification.json')
        if not receipt['passed'] or receipt['manifest_sha256'] != self.m['manifest_sha256']:
            raise ValueError('Source-matched tests must be sealed before launch')
        os.sched_setaffinity(0, self.m['resources']['plan']['controller'])
        with ProgressHeartbeat(self.root/'heartbeat.json', pid=os.getpid(), iga='frozen') as hb:
            self.admission(hb)
            self.execute('train', 'full', {a: r['gpus'] for a, r in ARMS.items()}, 4, hb)
            curves = {a: [self.collect_epoch('full', a, e, hb) for e in range(1, 5)] for a in ARMS}
            endpoint = {a: curve[-1] for a, curve in curves.items()}
            candidate = select_candidate(endpoint)
            atomic_json(self.root/'e4_comparison.json', dict(evaluations=endpoint, candidate=candidate,
                fixed_epoch=4, decision_rule=GATES,
                training_episodes_per_arm=self.m['training']['first_stage_episodes'],
                annealing_complete=self.m['training']['first_stage_episodes'] >= TEMPERATURE['anneal_end_episodes']),
                overwrite=False)
            atomic_json(self.root/'learning_curves.json', curves)
            role_arm = candidate or min(ARMS, key=lambda a: endpoint[a]['validation']['makespan'])
            self.diagnostics(list(ARMS), 4, hb, role_arm=role_arm)
            if candidate:
                continuation = {'T0_FIXED03': [0, 1, 2, 3], candidate: [4, 5, 6, 7]}
                self.execute('train', 'full', continuation, 8, hb, resume=True)
                for arm in continuation:
                    curves[arm] += [self.collect_epoch('full', arm, e, hb) for e in range(5, 9)]
                self.diagnostics(list(continuation), 8, hb, role_arm=candidate)
            indexes = {}
            for arm, curve in curves.items():
                qualified = [(e+1, row) for e, row in enumerate(curve)
                             if all(risk_pass(row[s]) and row[s]['gain_fraction'] >= 0 for s in ('validation', 'tune'))]
                best = min(qualified, key=lambda x: (x[1]['validation']['makespan'], x[0])) if qualified else None
                indexes[arm] = dict(Last=read_json(self.root/'full'/arm/f'epochs/e{len(curve):02d}.json'),
                    ValidationBest=(read_json(self.root/'full'/arm/f'epochs/e{best[0]:02d}.json') if best else None),
                    risk_qualified=best is not None, final_epoch=len(curve),
                    final_main_target_met=all(risk_pass(curve[-1][s]) and curve[-1][s]['gain_fraction'] >= .01
                                              for s in ('validation', 'tune')))
            atomic_json(self.root/'model_index.json', indexes, overwrite=False)
            atomic_json(self.root/'learning_curves.json', curves)
            atomic_json(self.root/'iga_comparability.json', dict(allow_solve=False,
                matched_full_joint_H2_reference_available=False, superiority_claim_allowed=False,
                references=self.m['iga']['references'],
                reason='Frozen H3 full-joint and H2 resource-only cannot serve as a matched H2 full-joint endpoint'), overwrite=False)
            self.finish(dict(training_completed=True, candidate=candidate, fixed_comparison_epoch=4,
                epochs_by_arm={a: len(c) for a, c in curves.items()},
                training_trajectories=sum(len(c)*self.m['training']['episodes_per_data_epoch'] for c in curves.values()),
                main_target_arms=[a for a, i in indexes.items() if i['final_main_target_met']]))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=('prepare', 'seal-tests', 'run', 'pool'))
    p.add_argument('--prior', type=Path)
    p.add_argument('--recovery-from', type=Path)
    p.add_argument('--training-subset', choices=('full600', 'subset240'), default='full600')
    p.add_argument('--output', type=Path)
    p.add_argument('--manifest', type=Path)
    p.add_argument('--junit', type=Path)
    args = p.parse_args()
    if args.command == 'prepare':
        return prepare(args)
    m = read_json(args.manifest)
    if args.command == 'seal-tests':
        return seal_tests(m, args.junit)
    if args.command == 'pool':
        return run_pool(m, args.manifest)
    try:
        TauSuite(m, args.manifest).run()
    except BaseException as exc:
        atomic_json(Path(m['root'])/'status.json', dict(status='failed', error=str(exc),
            traceback=traceback.format_exc(), unix=time.time(), automatic_retry=False, iga_solve_count=0))
        raise


if __name__ == '__main__':
    main()
