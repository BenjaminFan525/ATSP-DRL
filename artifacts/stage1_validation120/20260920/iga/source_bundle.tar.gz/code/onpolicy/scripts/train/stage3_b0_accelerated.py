"""Opt-in preflight DAG with one independently supervised elastic validator pool."""
import os
from pathlib import Path
import time

from onpolicy.scripts.train.run_stage3_b0 import B0Suite
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
from onpolicy.utils.stage3_b0_acceleration import (
    pool_placements, assert_pool_request, reuse_receipt, complete_rows, fresh_private_initialization,
)
from onpolicy.utils.stage3_b0_protocol import (
    B0_SHA, EVALUATION, TRAINING, verify, submit, submit_mechanism, baseline_costs,
)
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_json, digest_file


class AcceleratedB0Suite(B0Suite):
    def request_pool(self, hb, mode, gpus=()):
        path = self.queue.root / "desired_pool.json"
        generation = read_json(path)["generation"] + 1 if path.exists() else 1
        desired = {"protocol_sha256": self.m["manifest_sha256"], "generation": generation,
            "mode": mode, "gpus": list(gpus), "placements": pool_placements(self.plan, mode, gpus)}
        atomic_json(path, desired)
        while True:
            self.check(hb)
            status = read_json(self.queue.root / "pool_status.json")
            if (status.get("acknowledged_generation") == generation
                    and status.get("active_placements") == desired["placements"]
                    and not status.get("draining_workers")):
                return
            hb.update(event="await_elastic_pool_lease", desired_pool=desired,
                      draining_workers=status.get("draining_workers", []))
            time.sleep(3)

    def run_pool(self):
        self.pool_only = True
        os.sched_setaffinity(0, self.plan["controller"])
        atomic_json(self.queue.root / "pool_service.json", {"pid": os.getpid(), "created_unix": time.time(),
            "scope": "ONE elastic pool shared by all ranks and registered routes", "maximum_workers": 8,
            "steady_workers": 2}, overwrite=False)
        active, retired, serial = {}, set(), 0
        with ProgressHeartbeat(self.queue.root / "pool_status.json", phase="elastic_shared_validator_pool") as hb:
            try:
                while not (self.queue.root / "STOP").exists() or self.queue.pending_count():
                    request_path = self.queue.root / "desired_pool.json"
                    desired = (read_json(request_path) if request_path.exists() else {
                        "protocol_sha256": self.m["manifest_sha256"], "generation": 0, "mode": "boost",
                        "gpus": list(range(8)), "placements": pool_placements(self.plan, "boost", range(8))})
                    wanted = assert_pool_request(self.m, desired)
                    for lease, key in list(active.items()):
                        job = self.jobs[key]
                        if lease not in wanted and key not in retired:
                            atomic_json(job["output"] / "DRAIN", {"generation": desired["generation"]}, overwrite=False)
                            retired.add(key)
                        rc = job["process"].poll()
                        if rc is not None:
                            if rc != 0 or key not in retired:
                                raise RuntimeError(f"Validator exited unexpectedly: {key} rc={rc}")
                            del active[lease]
                    # Do not start a replacement until the previous lease holder has really exited.
                    for lease, placement in wanted.items():
                        if lease in active:
                            continue
                        live = [self.jobs[key]["placement"] for key in active.values()]
                        if any(p["gpu"] == placement["gpu"] or set(p["cpus"]) & set(placement["cpus"]) for p in live):
                            continue
                        serial += 1
                        active[lease] = self.start(f"{lease}_v{serial}", "validator", placement)
                    self.check(hb)
                    draining = [key for key in active.values() if key in retired]
                    placements = {lease: self.jobs[key]["placement"] for lease, key in active.items()}
                    hb.update(active_workers=active, active_placements=placements, draining_workers=draining,
                        acknowledged_generation=desired["generation"] if placements == wanted and not draining else None,
                        mode=desired["mode"], requested_generation=desired["generation"])
                    time.sleep(3)
            finally:
                self.stop_owned()

    def temperature_tasks(self, hb):
        """Eight unchanged logical shards; four physical GPUs refill as soon as a shard finishes."""
        gpus = self.m["acceleration"]["temperature_gpus"]
        pending, active, results = list(range(8)), {}, {}
        while pending or active:
            for gpu, (rank, key) in list(active.items()):
                if self.jobs[key]["process"].poll() is not None:
                    self.check(hb)
                    result = read_json(self.jobs[key]["output"] / "result.json")
                    if not result["passed"] or result["actor_updates"] != 0:
                        raise RuntimeError("Temperature diagnostic failed")
                    results[rank] = result
                    del active[gpu]
            for gpu in gpus:
                if gpu not in active and pending:
                    rank = pending.pop(0)
                    key = self.start(f"temperatures/rank{rank}", "sampling", self.plan["trainers"][str(gpu)],
                                     rank=rank, world_size=8)
                    active[gpu] = (rank, key)
            self.check(hb)
            hb.update(event="parallel_temperature_and_native_evaluation", completed_temperature_shards=len(results),
                      total_temperature_shards=8, queued_temperature_shards=pending)
            if active:
                time.sleep(5)
        return [results[r] for r in range(8)]

    def preflight_requests(self, init, reused):
        native, private = [], []
        cached = {r["case_id"] for r in reused}
        count = self.m["acceleration"]["preflight_chunk_size"]
        # Released Tune60 and paired private initialization receive early service.
        # Interleave raw private/native chunks; all requests use the SAME durable queue.
        for split in ("tune", "validation", "train_full600"):
            cases = self.m["splits"][split]
            for start in range(0, len(cases), count):
                block = cases[start:start + count]
                missing = [c for c in block if c["path"] not in cached]
                if missing:
                    native.append(submit(self.m, self.m["source"]["path"], "B0", 0, "NATIVE",
                        split=split, start=start, cases_override=missing, native=True, tag="_accelerated"))
                if split != "train_full600":
                    private.append(submit(self.m, init, "C_PRIVATE", 0, "F_PRIVATE", split=split,
                        start=start, count=count, raw_initialization=True, tag="_initialization"))
        return native, private

    def run_private(self):
        if (self.root / "status.json").exists():
            raise FileExistsError("No implicit controller restart; preserve the previous attempt")
        os.sched_setaffinity(0, self.plan["controller"])
        with ProgressHeartbeat(self.root / "status.json", phase="accelerated_preflight", formal_training_started=False) as hb:
            try:
                hb.update(workspace_advisory=verify(self.m))
                receipt = reuse_receipt(self.m)
                init = fresh_private_initialization(self.m)
                temperature_gpus = self.m["acceleration"]["temperature_gpus"]
                self.request_pool(hb, "boost", [g for g in range(8) if g not in temperature_gpus])
                requests, private_requests = self.preflight_requests(init, receipt["baseline_cases"])
                atomic_json(self.root / "preflight_plan.json", {"native_requests": requests,
                    "private_initialization_requests": private_requests, "reused_baseline_cases": len(receipt["baseline_cases"]),
                    "fresh_baseline_cases": 780 - len(receipt["baseline_cases"]), "reused_initialization_pairs": 32,
                    "temperature_logical_world_size": 8, "temperature_physical_gpus": temperature_gpus,
                    "capacity_worlds": [8], "four_gpu_benchmark": "deferred, not passed or required for the selected eight-GPU run"},
                    overwrite=False)
                hb.update(phase="temperature_and_baseline_parallel", reused_baseline_cases=len(receipt["baseline_cases"]))
                samples = self.temperature_tasks(hb)
                diagnostic_costs = {r["case_id"]: r["makespan"] for r in receipt["native_initialization_cases"]}
                temperatures = {}
                for tau in TRAINING["temperature_candidates"]:
                    rows = [r for sample in samples for r in sample["temperatures"][str(tau)]["cases"]]
                    if len(rows) != 128:
                        raise ValueError("Incomplete temperature diagnostic")
                    temperatures[str(tau)] = {"trajectories": len(rows),
                        "mean_cost": sum(r["makespan"] for r in rows) / len(rows),
                        "positive_fraction": sum(r["makespan"] < diagnostic_costs[r["case_id"]] for r in rows) / len(rows)}
                tau = min(TRAINING["temperature_candidates"], key=lambda t: (temperatures[str(t)]["mean_cost"], t))
                archives = {str(p): digest_file(p) for p in (self.root / "sampling/temperatures").glob("rank*/tau*")
                            if p.suffix in (".json", ".npz")}
                atomic_json(self.root / "sampling_admission.json", {"selected_tau": tau, "temperatures": temperatures,
                    "protocol_sha256": self.m["manifest_sha256"], "comparison_sha256": self.m["comparison_sha256"],
                    "archives": archives, "rule": "lower mean sampling cost on fixed TrainDiag32, ties lower tau",
                    "used_validation": False, "reward_gain_gate": False, "total_diagnostic_trajectories": 256,
                    "positive_fraction_baseline_evidence": self.m["acceleration"]["reuse_receipt"]}, overwrite=False)
                self.request_pool(hb, "boost", list(range(1, 8)))
                hb.update(phase="single_gpu_reference_and_baseline_parallel")
                reference = self.group("reference", "single", hb, world=1)[0]
                self.request_pool(hb, "boost", list(range(8)))
                hb.update(phase="finish_complete_native_and_private_baselines")
                rows = receipt["baseline_cases"] + [r for value in self.wait_requests(requests, hb) for r in value["cases"]]
                cases = [c for s in ("train_full600", "validation", "tune") for c in self.m["splits"][s]]
                complete_rows(rows, cases)
                costs = {r["case_id"]: r["makespan"] for r in rows}
                atomic_json(self.root / "baselines.json", {"costs": costs, "costs_sha256": digest_json(costs),
                    "cases": rows, "source_sha256": B0_SHA, "protocol_sha256": self.m["manifest_sha256"],
                    "evaluation": EVALUATION, "reuse_evidence": self.m["acceleration"]["reuse_receipt"]}, overwrite=False)
                baseline_costs(self.m)  # Formal training still requires EXACTLY all 780 cases.
                expected = self.m["diagnostic"]["initial_native_tune_costs"]
                differences = {c["name"]: costs[c["path"]] - expected[c["case_sha256"]]
                    for c in self.m["splits"]["tune"] if abs(costs[c["path"]] - expected[c["case_sha256"]]) > 1e-6}
                diag_differences = {p: costs[p] - v for p, v in diagnostic_costs.items() if abs(costs[p] - v) > 1e-6}
                atomic_json(self.root / "native_replay.json", {"passed": not differences and not diag_differences,
                    "differences": differences, "reused_diagnostic_baseline_differences": diag_differences}, overwrite=False)
                if differences or diag_differences:
                    raise RuntimeError("Native B0 release/reused diagnostic cost reproduction failed")
                private_rows = [r for value in self.wait_requests(private_requests, hb) for r in value["cases"]]
                complete_rows(private_rows, self.m["splits"]["validation"] + self.m["splits"]["tune"])
                delta = {r["case_id"]: r["makespan"] - costs[r["case_id"]] for r in private_rows
                         if abs(r["makespan"] - costs[r["case_id"]]) > 1e-6}
                atomic_json(self.root / "private_initialization_replay.json", {"passed": not delta, "cases": 180,
                    "differences": delta, "paired_only_after_all_native_costs_ready": True}, overwrite=False)
                if delta:
                    raise RuntimeError("Private zero-update validation differs from B0")
                self.request_pool(hb, "steady")
                diagnostic = submit_mechanism(self.m, init, 0)
                atomic_json(self.root / "mechanism/e000000.json", {"requests": diagnostic,
                    "checkpoint_sha256": digest_file(init), "training_episodes": 0}, overwrite=False)
                self.complete_admission(hb, rows, init, reference=reference)
            finally:
                self.stop_owned()  # Independent pool remains available; no external services are killed.
