#!/usr/bin/env python3
"""Build the selected three-arm, full-train600 Stage2 formal manifest.

Wave 4 ranked F1 hard reservation, F3 wait constraint, and F2 IGA-flow BC as
the three useful and complementary methods.  This profile keeps exactly those
methods, lets every method train its own DeviceBC checkpoint, and uses the
previously exercised three-trainer 1500-graph PPO geometry.
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import re
import shlex
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train import prepare_stage2_full_formal as full  # noqa: E402
from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    DEFAULT_DATASET,
    DEFAULT_HANDOFF,
    DEFAULT_PYTHON,
    DEFAULT_SOURCE_TEACHERS,
    atomic_json,
    build_compact_teacher_index,
    natural_evaluator_command,
    sha256_file,
    source_contract,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    build_stage2_command,
    set_option,
)


FORMAL_PROFILE = "planning_formal_full_selected_three"
FORMAL_ROLLOUT_THREADS = 30
FORMAL_BC_ROLLOUTS = 32
FORMAL_GRAPHS_PER_FORWARD = 1500
FORMAL_MINI_BATCH_SIZE = 30
FORMAL_DATA_CHUNK_LENGTH = 50
FORMAL_CRITIC_ACCUMULATION_STEPS = 3
FORMAL_ACTOR_ACCUMULATION_STEPS = 2
FORMAL_CRITIC_ACCUMULATION_TARGET_GRAPHS = 5000
FORMAL_ACTOR_ACCUMULATION_TARGET_GRAPHS = 2000
GPU_MEMORY_SAFETY_LIMIT_MIB = 77824

DEFAULT_SCREEN_DIR = (
    ROOT
    / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo"
)
DEFAULT_1500_CANARY_MANIFEST = (
    ROOT
    / "result/hkbz_train_logs/stage2_resource_sparse1500_canary_20260819_r1/"
    "commands/canary_standard.json"
)
DEFAULT_1500_CANARY_GPU_CSV = (
    ROOT
    / "result/hkbz_train_logs/stage2_resource_sparse1500_canary_20260819_r1/"
    "hardware/canary_standard_gpu_memory.csv"
)
DEFAULT_1500_FULL_LOG_DIR = (
    ROOT
    / "result/hkbz_train_logs/stage2_resource_wave1_20260819_r9/service_logs"
)


def _selected_method(method_id: str) -> dict:
    method = dict(full.FORMAL_METHODS[method_id])
    # F3 shared F0's BC only to save work in the five-arm suite.  Once F0 is
    # removed, F3 is the leader of that identical heuristic-soft BC group.
    method["bc_leader"] = True
    method["reuse_bc_from"] = None
    return method


SELECTED_FORMAL_METHODS = {
    method_id: _selected_method(method_id)
    for method_id in (
        "F1_hard_reservation",
        "F2_iga_flow_bc",
        "F3_wait_constraint",
    )
}

SCREEN_METHODS = {
    "F0_soft_control": "A3_soft_reservation",
    "F1_hard_reservation": "A4_hard_reservation",
    "F2_iga_flow_bc": "B1_iga_flow_bc",
    "F3_wait_constraint": "B2_wait_constraint",
    "F4_iga_constraint": "B3_iga_constraint",
}


def configure_selected_command(
    base: list[str],
    method_id: str,
    method: dict,
    *,
    run_tag: str,
    teacher_dir: Path,
    teacher_index: Path,
) -> list[str]:
    command = full.configure_full_formal_command(
        base,
        method_id,
        method,
        run_tag=run_tag,
        teacher_dir=teacher_dir,
        teacher_index=teacher_index,
    )
    set_option(
        command,
        "--experiment_name",
        f"{run_tag}_{FORMAL_PROFILE}_{method_id}_seed1",
    )
    set_option(command, "--n_rollout_threads", FORMAL_ROLLOUT_THREADS)
    set_option(
        command,
        "--device_bc_min_rollouts_per_epoch",
        FORMAL_BC_ROLLOUTS,
    )
    set_option(
        command,
        "--device_bc_max_rollouts_per_epoch",
        FORMAL_BC_ROLLOUTS,
    )
    set_option(command, "--mini_batch_size", FORMAL_MINI_BATCH_SIZE)
    set_option(command, "--data_chunk_length", FORMAL_DATA_CHUNK_LENGTH)
    set_option(
        command,
        "--max_graphs_per_forward",
        FORMAL_GRAPHS_PER_FORWARD,
    )
    set_option(
        command,
        "--grad_accumulation_steps",
        FORMAL_CRITIC_ACCUMULATION_STEPS,
    )
    set_option(
        command,
        "--actor_grad_accumulation_steps",
        FORMAL_ACTOR_ACCUMULATION_STEPS,
    )
    set_option(
        command,
        "--grad_accumulation_target_graphs",
        FORMAL_CRITIC_ACCUMULATION_TARGET_GRAPHS,
    )
    set_option(
        command,
        "--actor_grad_accumulation_target_graphs",
        FORMAL_ACTOR_ACCUMULATION_TARGET_GRAPHS,
    )
    return command


def selection_contract(screen_root: Path) -> dict:
    results = {}
    for formal_id, wave4_id in SCREEN_METHODS.items():
        evaluation_dir = (
            screen_root
            / (
                "stage2_planning_wave4_20260822_r2_planning_wave_"
                f"{wave4_id}_seed1/run1/evaluations"
            )
        )
        scores = {}
        files = sorted(evaluation_dir.glob("*.json"))
        if not files:
            raise FileNotFoundError(
                f"Missing Wave-4 selection evidence: {evaluation_dir}"
            )
        for path in files:
            payload = json.loads(path.read_text(encoding="utf-8"))
            score = payload.get("summary", {}).get("eval_selection_score")
            if score is not None:
                scores[path.stem] = float(score)
        if "pre_ppo" not in scores or not any(
            label.startswith("epoch_") for label in scores
        ):
            raise ValueError(f"Incomplete Wave-4 scores in {evaluation_dir}")
        best_label, best_score = min(scores.items(), key=lambda item: item[1])
        results[formal_id] = {
            "wave4_method": wave4_id,
            "pre_ppo_score": scores["pre_ppo"],
            "best_label": best_label,
            "best_score": best_score,
            "evaluation_dir": str(evaluation_dir.resolve()),
            "file_sha256": {
                path.name: sha256_file(path) for path in files
            },
        }
    observed = sorted(results, key=lambda key: results[key]["best_score"])
    expected = [
        "F1_hard_reservation",
        "F3_wait_constraint",
        "F2_iga_flow_bc",
    ]
    if observed[:3] != expected:
        raise ValueError(
            f"Wave-4 top-three ranking changed: {observed[:3]} != {expected}"
        )
    return {
        "metric": "eval_selection_score",
        "direction": "lower_is_better",
        "ranking": observed,
        "selected": list(SELECTED_FORMAL_METHODS),
        "rationale": {
            "F1_hard_reservation": (
                "best absolute Wave-4 validation control"
            ),
            "F2_iga_flow_bc": (
                "best retained IGA-supervised arm and teacher contrast"
            ),
            "F3_wait_constraint": (
                "best PPO-improved wait-control arm"
            ),
        },
        "results": results,
    }


_RESERVED_RE = re.compile(r"peak_reserved_gib=([0-9]+(?:\.[0-9]+)?)")


def graph1500_calibration_contract(
    canary_manifest: Path,
    canary_gpu_csv: Path,
    full_log_dir: Path,
) -> dict:
    payload = json.loads(canary_manifest.read_text(encoding="utf-8"))
    profile = payload.get("throughput_profile", {})
    required = {
        "mini_batch_size": FORMAL_MINI_BATCH_SIZE,
        "data_chunk_length": FORMAL_DATA_CHUNK_LENGTH,
        "max_graphs_per_forward": FORMAL_GRAPHS_PER_FORWARD,
        "critic_grad_accumulation_steps": FORMAL_CRITIC_ACCUMULATION_STEPS,
        "actor_grad_accumulation_steps": FORMAL_ACTOR_ACCUMULATION_STEPS,
        "critic_grad_accumulation_target_graphs": (
            FORMAL_CRITIC_ACCUMULATION_TARGET_GRAPHS
        ),
        "actor_grad_accumulation_target_graphs": (
            FORMAL_ACTOR_ACCUMULATION_TARGET_GRAPHS
        ),
    }
    observed = {key: int(profile.get(key, -1)) for key in required}
    if observed != required:
        raise ValueError(
            f"1500-graph canary geometry mismatch: {observed} != {required}"
        )

    with canary_gpu_csv.open(newline="", encoding="utf-8") as source:
        rows = list(csv.DictReader(source))
    canary_peak = max(int(row["memory_used_mib"]) for row in rows)

    logs = sorted(full_log_dir.glob("*resume1500-r1-m[0-2].log"))
    if len(logs) != 3:
        raise ValueError(
            f"Expected three full 1500-graph evidence logs, got {len(logs)}"
        )
    per_trainer_reserved_gib = []
    for path in logs:
        values = [
            float(match.group(1))
            for match in _RESERVED_RE.finditer(
                path.read_text(encoding="utf-8", errors="replace")
            )
        ]
        if not values:
            raise ValueError(f"No CUDA reserved-memory evidence in {path}")
        per_trainer_reserved_gib.append(max(values))
    projected_peak_mib = math.ceil(sum(per_trainer_reserved_gib) * 1024)
    headroom_mib = GPU_MEMORY_SAFETY_LIMIT_MIB - projected_peak_mib
    if headroom_mib <= 0:
        raise ValueError(
            "Three-trainer 1500-graph evidence exceeds GPU safety limit: "
            f"{projected_peak_mib} >= {GPU_MEMORY_SAFETY_LIMIT_MIB} MiB"
        )
    return {
        "canary_manifest": str(canary_manifest.resolve()),
        "canary_manifest_sha256": sha256_file(canary_manifest),
        "canary_gpu_csv": str(canary_gpu_csv.resolve()),
        "canary_observed_peak_mib": canary_peak,
        "full_evidence_logs": [str(path.resolve()) for path in logs],
        "full_evidence_peak_reserved_gib_per_trainer": (
            per_trainer_reserved_gib
        ),
        "conservative_combined_reserved_mib": projected_peak_mib,
        "safety_limit_mib": GPU_MEMORY_SAFETY_LIMIT_MIB,
        "projected_headroom_mib": headroom_mib,
        "trainer_count_per_gpu": 3,
        "graphs_per_forward": FORMAL_GRAPHS_PER_FORWARD,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-tag", required=True)
    parser.add_argument("--suite-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--handoff", type=Path, default=DEFAULT_HANDOFF)
    parser.add_argument("--source-seed", type=int, default=3)
    parser.add_argument(
        "--source-teacher-dir", type=Path, default=DEFAULT_SOURCE_TEACHERS
    )
    parser.add_argument("--dataset-dir", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--python", type=Path, default=DEFAULT_PYTHON)
    parser.add_argument("--screen-root", type=Path, default=DEFAULT_SCREEN_DIR)
    parser.add_argument(
        "--graph1500-canary-manifest",
        type=Path,
        default=DEFAULT_1500_CANARY_MANIFEST,
    )
    parser.add_argument(
        "--graph1500-canary-gpu-csv",
        type=Path,
        default=DEFAULT_1500_CANARY_GPU_CSV,
    )
    parser.add_argument(
        "--graph1500-full-log-dir",
        type=Path,
        default=DEFAULT_1500_FULL_LOG_DIR,
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    suite_dir = args.suite_dir.resolve()
    compact_dir = suite_dir / "artifacts/resource_iga1800_compact"
    teacher_index = suite_dir / "artifacts/resource_iga1800_index.json"
    teacher_contract = build_compact_teacher_index(
        args.source_teacher_dir.resolve(),
        args.dataset_dir.resolve(),
        compact_dir,
        teacher_index,
    )
    source, source_command = source_contract(
        args.handoff.resolve(), args.source_seed
    )
    if source["sha256"] != teacher_contract["frozen_plane_checkpoint_sha256"]:
        raise ValueError(
            "Stage1 source checkpoint differs from the resource IGA teacher."
        )
    coverage = full.full_coverage_audit(
        args.dataset_dir.resolve(),
        seed=1,
        n_rollout_threads=FORMAL_ROLLOUT_THREADS,
    )
    if FORMAL_MINI_BATCH_SIZE > FORMAL_ROLLOUT_THREADS:
        raise ValueError(
            "Formal recurrent PPO mini-batch cannot exceed rollout width: "
            f"{FORMAL_MINI_BATCH_SIZE} > {FORMAL_ROLLOUT_THREADS}."
        )
    if FORMAL_ROLLOUT_THREADS * FORMAL_BC_ROLLOUTS != int(
        coverage["selected_cases"]
    ):
        raise ValueError(
            "Formal DeviceBC geometry must cover exactly one balanced epoch: "
            f"{FORMAL_ROLLOUT_THREADS}*{FORMAL_BC_ROLLOUTS} != "
            f"{coverage['selected_cases']}."
        )

    commands = {}
    for method_id, method in SELECTED_FORMAL_METHODS.items():
        base = build_stage2_command(
            source["path"],
            run_tag=f"{args.run_tag}_{FORMAL_PROFILE}_{method_id}",
            seed=1,
            bc_epochs=full.FORMAL_BC_EPOCHS,
            ppo_epochs=full.FORMAL_PPO_EPOCHS,
            ppo_epoch=2,
            bc_min_labels=64,
            bc_min_rollouts=full.FORMAL_BC_ROLLOUTS,
            bc_max_rollouts=full.FORMAL_BC_ROLLOUTS,
            source_command=source_command,
            python=args.python.resolve(),
        )
        command = configure_selected_command(
            base,
            method_id,
            method,
            run_tag=args.run_tag,
            teacher_dir=compact_dir,
            teacher_index=teacher_index,
        )
        commands[method_id] = {
            "argv": command,
            "shell": shlex.join(command),
            **method,
        }

    evaluator_key = "F1_hard_reservation"
    manifest = {
        "schema_version": 1,
        "research_stage": "stage2_resource_joint",
        "profile": FORMAL_PROFILE,
        "run_tag": args.run_tag,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "code_commit": full.git_revision(),
        "source": source,
        "teacher_index_path": str(teacher_index),
        "teacher_index_sha256": sha256_file(teacher_index),
        "teacher_case_count": int(teacher_contract["case_count"]),
        "selection_contract": selection_contract(args.screen_root.resolve()),
        "data_contract": coverage,
        "training_contract": {
            "seed": 1,
            "bc_epochs": full.FORMAL_BC_EPOCHS,
            "ppo_epochs": full.FORMAL_PPO_EPOCHS,
            "ppo_epoch": 2,
            "bc_rollouts_per_epoch": FORMAL_BC_ROLLOUTS,
            "recovery_interval_shards": (
                full.FORMAL_RECOVERY_INTERVAL_SHARDS
            ),
            "plane_frozen_for_all_ppo_epochs": True,
            "shared_encoder_frozen_for_all_ppo_epochs": True,
            "independent_device_bc_per_method": True,
        },
        "cpu_contract": {
            "host_logical_cpus": 144,
            "maximum_experiment_logical_cpus": 72,
            "trainer_logical_cpus_each": 20,
            "trainer_rollout_processes_each": FORMAL_ROLLOUT_THREADS,
            "intentional_env_process_oversubscription": True,
            "shared_evaluator_logical_cpus": 10,
            "monitor_logical_cpus": 2,
            "physical_core_isolation": True,
            "numa_node": 0,
        },
        "gpu_contract": {
            "gpu": 0,
            "trainer_count": 3,
            "shared_evaluator_count": 1,
            "max_graphs_per_forward": FORMAL_GRAPHS_PER_FORWARD,
            "calibration": graph1500_calibration_contract(
                args.graph1500_canary_manifest.resolve(),
                args.graph1500_canary_gpu_csv.resolve(),
                args.graph1500_full_log_dir.resolve(),
            ),
        },
        "throughput_profile": {
            "n_rollout_threads": FORMAL_ROLLOUT_THREADS,
            "n_eval_rollout_threads": full.PLANNING_EVAL_THREADS,
            "mini_batch_size": FORMAL_MINI_BATCH_SIZE,
            "data_chunk_length": FORMAL_DATA_CHUNK_LENGTH,
            "max_graphs_per_forward": FORMAL_GRAPHS_PER_FORWARD,
            "critic_grad_accumulation_steps": (
                FORMAL_CRITIC_ACCUMULATION_STEPS
            ),
            "actor_grad_accumulation_steps": (
                FORMAL_ACTOR_ACCUMULATION_STEPS
            ),
            "critic_grad_accumulation_target_graphs": (
                FORMAL_CRITIC_ACCUMULATION_TARGET_GRAPHS
            ),
            "actor_grad_accumulation_target_graphs": (
                FORMAL_ACTOR_ACCUMULATION_TARGET_GRAPHS
            ),
        },
        "evaluator_command": natural_evaluator_command(
            commands[evaluator_key]["argv"]
        ),
        "evaluator_source_method": evaluator_key,
        "methods": SELECTED_FORMAL_METHODS,
        "commands": commands,
    }
    atomic_json(args.output.resolve(), manifest)
    print(json.dumps({
        "manifest": str(args.output.resolve()),
        "methods": list(commands),
        "unique_cases": coverage["unique_cases"],
        "case_slots": coverage["selected_cases"],
        "shards_per_epoch": coverage["shards_per_epoch"],
        "graphs_per_forward": FORMAL_GRAPHS_PER_FORWARD,
        "projected_gpu_headroom_mib": (
            manifest["gpu_contract"]["calibration"][
                "projected_headroom_mib"
            ]
        ),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
