#!/usr/bin/env python3
"""Explicit checkpoint-boundary migration; never restarts a failed experiment.

The old source/weights stay immutable. A separate, sealed source snapshot waits
for the requested formal boundary, drains the one validator pool, then launches
one replacement pool and the ENV60 capacity/continuation controller.
"""
import argparse
import fcntl
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json, WORKSPACE_ROOT
from onpolicy.utils.stage3_b0_protocol import identity, queue
from onpolicy.utils.stage3_b0_throughput import ENV36_BATCH_VERSION, ENV60_BATCH_AUTHORIZATION, continuation_plan

SCHEMA = 'stage3-env60-checkpoint-boundary-transition-v1'


def run_unit(root):
    root = Path(root).resolve()
    if (root.parent != WORKSPACE_ROOT/'result/hkbz_train_logs'
            or not re.fullmatch(r'stage3_private_b0_[a-zA-Z0-9_]+', root.name)):
        raise ValueError('Only an exact local Stage3 private B0 run is in scope')
    return 'hkbz-'+root.name.replace('_', '-')


def boundary_action(m, target, state):
    """Arm during the target batch, after rank0 has passed its stop barrier.

Writing PAUSE immediately after the previous commit is racy: it can stop one
batch too early. global_batch is written only after the shared stop decision.
"""
    plan = continuation_plan(m)
    matches = [(i, b) for i, b in enumerate(plan) if b['training_episodes'] == target]
    if len(matches) != 1:
        raise ValueError('Requested boundary is not a future formal commit')
    index, _ = matches[0]
    before = m['throughput']['start_episodes'] if index == 0 else plan[index-1]['training_episodes']
    if state.get('phase') != 'train':
        return 'wait'
    group = state.get('global_batch', 0)
    if group > index+1:
        raise RuntimeError('Requested boundary was passed; do not silently choose a later checkpoint')
    if (group == index+1 and state.get('training_episodes') == before
            and state.get('event') not in ('batch_committed', 'paused_at_commit')):
        return 'arm'
    return 'wait'


def service(unit):
    values = subprocess.check_output(['systemctl', '--user', 'show', unit,
        '-p', 'ActiveState', '-p', 'MainPID', '-p', 'ExecMainStatus', '-p', 'ExecStart'], text=True)
    return dict(line.split('=', 1) for line in values.splitlines() if '=' in line)


def verify_commit(m, path, target):
    commit = read_json(path)
    from onpolicy.utils.stage3_b0_throughput import parent_manifest
    parent_manifest(m)
    if (commit.get('diagnostic_only') or commit['world_size'] != 8
            or commit['training_episodes'] != target or len(commit['ranks']) != 8
            or commit['protocol_sha256'] != m['manifest_sha256']
            or commit['schedule_sha256'] != digest_json(continuation_plan(m))
            or commit['recipe_sha256'] != digest_file(Path(m['root'])/'training_admission.json')):
        raise ValueError('An all-rank, admitted formal commit is required')
    for rank, row in enumerate(commit['ranks']):
        expected = Path(m['root'])/f'train/full/rank{rank}/models/episodes_{target:06d}.pt'
        if row['rank'] != rank or Path(row['checkpoint']).resolve() != expected.resolve():
            raise ValueError('Checkpoint is outside the requested formal boundary')
        if digest_file(expected) != row['sha256']:
            raise ValueError('Incomplete/changed rank checkpoint')
    return commit


def stage(current, output, staging, target):
    from onpolicy.scripts.train.stage3_b0_large_batch import ENV60_BATCH_OVERLAYS
    current, output, staging = [Path(p).resolve() for p in (current, output, staging)]
    run_unit(current)
    run_unit(output)
    run_unit(staging)
    if staging.exists() or output.exists():
        raise FileExistsError('Retain old attempts; choose new transition/output directories')
    m = read_json(current/'manifest.json')
    if (m['root'] != str(current) or identity(m) != m['manifest_sha256']
            or m['throughput']['version'] != ENV36_BATCH_VERSION
            or (current/'PAUSE_AFTER_COMMIT').exists()):
        raise ValueError('Expected the active, unpaused ENV36 recipe')
    boundary_action(m, target, {})
    files = {}
    overlays = set(ENV60_BATCH_OVERLAYS)
    for relative in sorted(set(m['code']['files']) | overlays):
        src = ROOT/relative if relative in overlays else current/'source'/relative
        expected = digest_file(src)
        if relative not in overlays and expected != m['code']['files'][relative]:
            raise ValueError('Parent frozen source changed')
        dst = staging/'source'/relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        if digest_file(dst) != expected:
            raise ValueError('Source changed while staging the explicit overlay')
        files[relative] = expected
    plan = {'schema': SCHEMA, 'authorization': ENV60_BATCH_AUTHORIZATION,
        'created_unix': time.time(), 'current_root': str(current), 'output_root': str(output),
        'staging_root': str(staging), 'target_episodes': target,
        'target_kind': 'completed_data_epoch' if target % 960 == 0 else 'completed_formal_batch',
        'parent_manifest_sha256': digest_file(current/'manifest.json'), 'files': files,
        'python': sys.executable, 'timeout_seconds': 172800, 'poll_seconds': 10,
        'memory_high': 'infinity', 'memory_max': 'infinity', 'memory_swap_max': 0,
        'tasks_max': 1024, 'rollout_envs_per_gpu': 60, 'backward_batch': 12,
        'old_artifacts_preserved': True, 'diagnostic_checkpoint_is_not_resume_source': True}
    plan['plan_sha256'] = digest_json(plan)
    atomic_json(staging/'transition.json', plan, overwrite=False)
    print(staging/'transition.json', flush=True)


def verify_staged(plan):
    if (plan['schema'] != SCHEMA or plan['authorization'] != ENV60_BATCH_AUTHORIZATION
            or digest_json({k:v for k,v in plan.items() if k != 'plan_sha256'}) != plan['plan_sha256']):
        raise ValueError('Transition identity changed')
    stage_root = Path(plan['staging_root'])
    for name, checksum in plan['files'].items():
        if digest_file(stage_root/'source'/name) != checksum:
            raise ValueError(f'Staged source changed: {name}')
    report = read_json(stage_root/'verification/receipt.json')
    if (not report['passed'] or report['source_files_sha256'] != digest_json(plan['files'])
            or any(digest_file(p) != h for p,h in report['reports'].items())):
        raise ValueError('Source-matched passing tests are required before arming a transition')


def run(plan_path):
    plan = read_json(plan_path)
    verify_staged(plan)
    current, output, staging = [Path(plan[k]) for k in ('current_root', 'output_root', 'staging_root')]
    old_unit = run_unit(current)
    run_unit(output)
    m = read_json(current/'manifest.json')
    if digest_file(current/'manifest.json') != plan['parent_manifest_sha256']:
        raise ValueError('The waiting parent manifest changed')
    target = plan['target_episodes']
    commit_path = current/f'train/commits/episodes_{target:06d}.json'
    pause_path = current/'PAUSE_AFTER_COMMIT'
    start, armed = time.time(), False
    def note(phase, **values):
        atomic_json(staging/'status.json', {'schema':SCHEMA, 'status':'running', 'phase':phase,
            'pid':os.getpid(), 'started_unix':start, 'heartbeat_unix':time.time(),
            'target_episodes':target, 'pause_armed':armed, **values})
    def tick():
        if time.time()-start > plan['timeout_seconds']:
            raise TimeoutError('Transition wait expired; no experiment was killed or retried')
        time.sleep(plan['poll_seconds'])
    with (staging/'transition.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            while True:
                state = read_json(current/'status.json')
                rank_path = current/'train/full/rank0/status.json'
                rank_state = read_json(rank_path) if rank_path.exists() else {}
                if not armed and boundary_action(m, target, rank_state) == 'arm':
                    atomic_json(pause_path, {'authorization':ENV60_BATCH_AUTHORIZATION,
                        'transition':str(plan_path), 'plan_sha256':plan['plan_sha256'],
                        'target_episodes':target, 'reason':'finish current batch and save all eight checkpoints'}, overwrite=False)
                    armed = True
                if armed and state.get('phase') == 'paused_at_commit':
                    commit = verify_commit(m, commit_path, target)
                    for rank in range(8):
                        result = read_json(current/f'train/full/rank{rank}/result.json')
                        if not result.get('paused') or result['training_episodes'] != target:
                            raise ValueError('All ranks must stop at the same formal checkpoint')
                    break
                old = service(old_unit+'-training.service')
                if state.get('status') == 'failed' or old.get('ActiveState') not in ('active', 'activating'):
                    raise RuntimeError('Parent stopped before the requested boundary; no automatic retry')
                note('waiting_formal_checkpoint', parent_phase=state.get('phase'),
                     formal_training_started=state.get('formal_training_started', False),
                     training_episodes=rank_state.get('training_episodes', m['throughput']['start_episodes']))
                tick()
            while service(old_unit+'-training.service').get('MainPID') != '0':
                note('waiting_training_controller_exit')
                tick()
            if service(old_unit+'-training.service').get('ExecMainStatus') != '0':
                raise RuntimeError('Parent controller exited unsuccessfully; retain its checkpoint')
            # Finish every old request under its original manifest. Do not re-label results.
            while queue(m).pending_count():
                if (service(old_unit+'-validator.service').get('ActiveState') != 'active'
                        or list((current/'validator/failed').glob('*.json'))):
                    raise RuntimeError('Old validator failed during drain; no automatic retry')
                note('draining_original_shared_validator', pending_validations=queue(m).pending_count())
                tick()
            atomic_json(current/'validator/STOP', {'authorization':ENV60_BATCH_AUTHORIZATION,
                'reason':'all old requests completed; hand off the single shared validator pool',
                'transition':str(plan_path)}, overwrite=False)
            while service(old_unit+'-validator.service').get('MainPID') != '0':
                note('waiting_validator_controller_exit')
                tick()
            if service(old_unit+'-validator.service').get('ExecMainStatus') != '0':
                raise RuntimeError('Old validator did not exit cleanly')
            verify_staged(plan)
            note('preparing_env60_from_committed_checkpoint')
            command = [plan['python'], '-B', str(ROOT/'onpolicy/scripts/train/stage3_b0_large_batch.py'),
                '--parent', str(current/'manifest.json'), '--commit', str(commit_path),
                '--output', str(output), '--rollout-envs', '60', '--env60-batched-minibatch12-uncapped',
                '--env-pool-probes', str(staging/'verification/env_pool')]
            subprocess.run(command, check=True, timeout=600)
            candidate = read_json(output/'manifest.json')
            if candidate['code']['files'] != plan['files']:
                raise ValueError('Prepared code is not the tested staged implementation')
            # Both snapshots are byte-identical; retain and explicitly bind that fact.
            atomic_json(output/'staged_verification.json', {'passed':True,
                'staged_files_sha256':digest_json(plan['files']), 'candidate_code_sha256':candidate['code']['sha256'],
                'staged_receipt':str(staging/'verification/receipt.json'),
                'staged_receipt_sha256':digest_file(staging/'verification/receipt.json')}, overwrite=False)
            subprocess.run([plan['python'], '-B', str(output/'source/onpolicy/scripts/train/stage3_b0_large_batch.py'),
                '--seal-manifest', str(output/'manifest.json'), '--test-report', str(staging/'verification/cpu.xml')],
                check=True, cwd=output/'source', timeout=600,
                env={**os.environ, 'PYTHONPATH':str(output/'source')})
            note('launching_env60_capacity', committed_episodes=target,
                 actual_actor_updates=commit['actual_actor_updates'])
            subprocess.run(['bash', str(output/'source/onpolicy/scripts/train/launch_stage3_b0_env60.sh'),
                output.name], check=True, timeout=180)
            atomic_json(staging/'completed.json', {'passed':True, 'new_experiment_launched':True,
                'capacity_admission_still_required':True, 'target_episodes':target,
                'old_commit_sha256':digest_file(commit_path), 'new_manifest':str(output/'manifest.json'),
                'new_manifest_sha256':digest_file(output/'manifest.json'), 'completed_unix':time.time()}, overwrite=False)
            note('env60_launched_capacity_pending', new_root=str(output))
        except BaseException:
            import traceback
            atomic_json(staging/'failure.json', {'status':'failed', 'error':traceback.format_exc(),
                'created_unix':time.time(), 'pause_armed':armed, 'no_retry':True,
                'all_artifacts_retained':True}, overwrite=False)
            raise


def main():
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest='mode', required=True)
    prep = modes.add_parser('stage')
    for name in ('current', 'output', 'staging'):
        prep.add_argument('--'+name, type=Path, required=True)
    prep.add_argument('--target-episodes', type=int, required=True)
    wait = modes.add_parser('run')
    wait.add_argument('--plan', type=Path, required=True)
    args = parser.parse_args()
    if args.mode == 'stage':
        stage(args.current, args.output, args.staging, args.target_episodes)
    else:
        run(args.plan.resolve())


if __name__ == '__main__':
    main()
