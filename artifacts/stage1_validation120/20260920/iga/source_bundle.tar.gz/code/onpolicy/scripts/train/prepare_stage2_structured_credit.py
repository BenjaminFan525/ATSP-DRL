#!/usr/bin/env python3
"""Prepare/promote the Stage2 structured-BC and residual-PPO round."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.config.config import get_config  # noqa: E402
from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    sha256_file,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.scripts.train.train_hkbz import (  # noqa: E402
    parse_args as parse_training_args,
)
from onpolicy.scripts.train.stage2_event_credit_autopilot import (  # noqa: E402
    _matched_iga_raw,
    analyze_phase,
)


RUN_TAG = 'stage2_structured_credit_20260830_r3'
BC_METHODS = {
    'B0_categorical_control': {
        'ranking': False, 'timing': False, 'matching': False,
        'hard_dagger': False,
        'hypothesis': 'current categorical IGA DeviceBC control',
    },
    'B1_candidate_ranking': {
        'ranking': True, 'timing': False, 'matching': False,
        'hard_dagger': False,
        'hypothesis': 'dense IGA candidate ranking fixes one-hot information loss',
    },
    'B2_ranking_timing': {
        'ranking': True, 'timing': True, 'matching': False,
        'hard_dagger': False,
        'hypothesis': 'factor dispatch timing from request identity',
    },
    'B3_ranking_matching': {
        'ranking': True, 'timing': False, 'matching': True,
        'hard_dagger': False,
        'hypothesis': 'global matching removes fixed device-order contention',
    },
    'B4_full_structure': {
        'ranking': True, 'timing': True, 'matching': True,
        'hard_dagger': False,
        'hypothesis': 'ranking, timing and matching are complementary',
    },
    'B5_full_hard_dagger': {
        'ranking': True, 'timing': True, 'matching': True,
        'hard_dagger': True,
        'hypothesis': 'student-state and OOD-stress recovery closes tail failures',
    },
}

PPO_METHODS = {
    'P0_near_bc_control': {
        'counterfactual': False, 'hard_kl': False, 'paired': False,
        # Keep PPO conservative while still guaranteeing a measurable resource
        # actor update; the runner rejects a completed PPO phase with no
        # bitwise actor change.
        'critical': False, 'tail': False, 'lr': 1.0e-7,
        'hypothesis': 'near-frozen post-BC validation control',
    },
    'P1_mc_counterfactual': {
        'counterfactual': True, 'hard_kl': False, 'paired': False,
        'critical': False, 'tail': False, 'lr': 1.0e-5,
        'hypothesis': 'MC plus legal-action counterfactual control variate',
    },
    'P2_residual_hard_kl': {
        'counterfactual': True, 'hard_kl': True, 'paired': False,
        'critical': False, 'tail': False, 'lr': 7.5e-6,
        'hypothesis': 'small residual PPO with rollback-safe BC trust region',
    },
    'P3_paired_case_baseline': {
        'counterfactual': True, 'hard_kl': True, 'paired': True,
        'critical': False, 'tail': False, 'lr': 7.5e-6,
        'hypothesis': 'matched IGA case baseline removes instance difficulty variance',
    },
    'P4_critical_event_credit': {
        'counterfactual': True, 'hard_kl': True, 'paired': True,
        'critical': True, 'tail': False, 'lr': 7.5e-6,
        'hypothesis': 'conserved critical-event credit targets causal dispatches',
    },
    'P5_paired_delta_tail': {
        'counterfactual': True, 'hard_kl': True, 'paired': True,
        'critical': True, 'tail': True, 'lr': 7.5e-6,
        'hypothesis': 'true episodic delta-Cmax tail removes catastrophic cases',
    },
}


def load_json(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError(f'Expected JSON object: {path}')
    return payload


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + '\n',
        encoding='utf-8',
    )
    temporary.replace(path)


def option_value(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def code_contract() -> dict:
    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
    ).strip()
    paths = (
        'onpolicy/config/config.py',
        'onpolicy/envs/HKBZ/environment.py',
        'onpolicy/envs/HKBZ/resource_teacher.py',
        'onpolicy/algorithms/utils/ptr_actor.py',
        'onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py',
        'onpolicy/algorithms/gnn_mappo/algorithm/MAPPOPolicy.py',
        'onpolicy/algorithms/gnn_mappo/gnn_mappo.py',
        'onpolicy/utils/shared_buffer.py',
        'onpolicy/runner/shared/hkbz_runner.py',
        'onpolicy/scripts/train/shared_hkbz_evaluator.py',
        'onpolicy/scripts/train/prepare_stage2_structured_credit.py',
        'onpolicy/scripts/train/launch_stage2_structured_credit_dual_gpu.sh',
    )
    return {
        'git_revision': revision,
        'working_tree_dirty': bool(subprocess.check_output(
            ['git', 'status', '--short'], cwd=ROOT, text=True
        ).strip()),
        'files_sha256': {
            path: sha256_file(ROOT / path)
            for path in paths if (ROOT / path).is_file()
        },
    }


def compact_baseline(teacher_index: Path, output: Path) -> dict:
    source = load_json(teacher_index)
    entries = source.get('entries')
    if not isinstance(entries, dict) or len(entries) != 600:
        raise ValueError('Paired IGA index must contain all 600 train cases.')
    cases = {
        str(case): float(record['makespan'])
        for case, record in entries.items()
    }
    if not all(np.isfinite(value) and value > 0.0 for value in cases.values()):
        raise ValueError('Paired IGA index contains invalid makespans.')
    payload = {
        'schema_version': 1,
        'source_index': str(teacher_index.resolve()),
        'source_index_sha256': sha256_file(teacher_index),
        'case_count': len(cases),
        'mean_makespan': float(np.mean(list(cases.values()))),
        'cases': cases,
    }
    atomic_json(output, payload)
    return payload


def apply_common(command: list[str], *, python: Path, experiment: str) -> None:
    command[0] = str(python)
    set_option(command, '--experiment_name', experiment)
    set_option(command, '--seed', 1)
    set_option(command, '--cuda_memory_fraction', 0.30)
    set_option(command, '--n_rollout_threads', 30)
    set_option(command, '--n_eval_rollout_threads', 12)
    set_option(command, '--max_train_cases', 0)
    set_option(command, '--train_sampling_size', 240)
    set_option(command, '--train_sampling_pool_size', 600)
    set_option(command, '--max_eval_cases', 60)
    set_option(command, '--eval_partition_seed', 20260811)
    set_option(command, '--eval_partition_stratify_by', 'distribution')
    set_option(command, '--max_graphs_per_forward', 1000)
    # 20 environments x 50 recurrent steps exactly fills the 1000-graph
    # forward cap.  The remaining ten rollout environments form a 500-graph
    # microbatch and are combined by graph-count-based accumulation.
    set_option(command, '--mini_batch_size', 20)
    set_option(command, '--data_chunk_length', 50)
    set_option(command, '--grad_accumulation_steps', 3)
    set_option(command, '--actor_grad_accumulation_steps', 2)
    set_option(command, '--grad_accumulation_target_graphs', 4000)
    set_option(command, '--actor_grad_accumulation_target_graphs', 1800)
    set_option(command, '--early_stop_patience', 0)
    set_option(command, '--recovery_checkpoint_interval_shards', 1)
    set_option(command, '--device_policy_head_mode', 'shared')
    set_option(command, '--ordinary_device_type_count', 10)
    set_switch(command, '--use_eval', True)
    set_switch(command, '--rollout_until_done', True)
    set_switch(command, '--safe_graph_batch_pipeline', True)
    set_switch(command, '--safe_dagger_teacher_overlap', True)
    set_switch(command, '--clear_cuda_cache_after_update', False)


def bc_command(base, key, method, *, run_tag, python):
    command = list(base)
    apply_common(
        command, python=python,
        experiment=f'{run_tag}_waveA_{key}_seed1',
    )
    set_option(command, '--num_episodes', 1)
    set_option(command, '--gnn_freeze_epochs', 1)
    set_option(command, '--plane_freeze_epochs', 1)
    set_option(command, '--device_bc_pretrain_epochs', 4)
    set_option(command, '--device_bc_min_labels_per_epoch', 64)
    set_option(command, '--device_bc_min_rollouts_per_epoch', 8)
    set_option(command, '--device_bc_max_rollouts_per_epoch', 8)
    set_option(command, '--device_bc_teacher', 'iga')
    set_option(command, '--device_bc_min_teacher_score_margin', -1.0)
    set_option(
        command, '--device_bc_ranking_loss_coef',
        0.5 if method['ranking'] else 0.0,
    )
    set_option(command, '--device_bc_ranking_temperature', 0.10)
    set_option(
        command, '--device_bc_timing_loss_coef',
        0.5 if method['timing'] else 0.0,
    )
    set_option(
        command, '--device_bc_dagger_schedule',
        '1.0,0.5,0.2,0.0'
        if method['hard_dagger'] else '1.0,0.7,0.4,0.1',
    )
    set_option(
        command, '--train_sampling_weights',
        'iid=0.35,ood_stress=0.60,ood_scale=0.05'
        if method['hard_dagger']
        else 'iid=0.50,ood_stress=0.45,ood_scale=0.05',
    )
    set_switch(command, '--device_bc_role_balanced', True)
    set_switch(command, '--device_bc_timing_balanced', True)
    set_switch(command, '--device_timing_head', method['timing'])
    set_switch(command, '--device_global_matching', method['matching'])
    set_switch(command, '--device_bc_only', True)
    remove_option(command, '--resource_bc_checkpoint')
    return command


def canary_command(command, key):
    result = list(command)
    set_option(
        result, '--experiment_name',
        f"{option_value(result, '--experiment_name')}_canary",
    )
    set_option(result, '--max_train_cases', 30)
    set_option(result, '--train_sampling_size', 30)
    remove_option(result, '--train_sampling_pool_size')
    set_option(result, '--max_eval_cases', 12)
    set_option(result, '--device_bc_pretrain_epochs', 1)
    set_option(result, '--device_bc_min_rollouts_per_epoch', 1)
    set_option(result, '--device_bc_max_rollouts_per_epoch', 1)
    set_option(result, '--device_bc_dagger_schedule', '1.0')
    return result


def validate(command, *, bc_only):
    args = parse_training_args(command[2:], get_config())
    if args.training_stage != 'resource_joint':
        raise ValueError('Structured round requires resource_joint.')
    if int(args.max_graphs_per_forward) != 1000:
        raise ValueError('Structured round graph cap drifted from 1000.')
    requested_graphs = int(args.mini_batch_size) * int(args.data_chunk_length)
    if requested_graphs > int(args.max_graphs_per_forward):
        raise ValueError(
            'Structured round PPO microbatch exceeds graph cap: '
            f'{args.mini_batch_size}*{args.data_chunk_length}='
            f'{requested_graphs}>{args.max_graphs_per_forward}.'
        )
    if bool(args.device_bc_only) != bool(bc_only):
        raise ValueError('DeviceBC/PPO phase contract mismatch.')
    if args.device_policy_head_mode != 'shared':
        raise ValueError('This round retains the unsplit shared encoder/head.')


def prepare(args):
    source = load_json(args.source_manifest)
    base = list(source['commands']['T4_iga_role_timing']['argv'])
    baseline = compact_baseline(args.teacher_index, args.baseline_output)
    commands = {}
    for key, method in BC_METHODS.items():
        command = bc_command(
            base, key, method, run_tag=args.run_tag, python=args.python
        )
        validate(command, bc_only=True)
        commands[key] = {
            **method, 'family': 'structured_device_bc', 'argv': command,
            'shell': shlex.join(command),
        }
    shared = {
        'schema_version': 1,
        'research_stage': 'stage2_resource_joint',
        'profile': 'structured_bc_residual_ppo',
        'run_tag': args.run_tag,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'code_contract': code_contract(),
        'source_manifest': {
            'path': str(args.source_manifest),
            'sha256': sha256_file(args.source_manifest),
            'method': 'T4_iga_role_timing',
        },
        'paired_iga_baseline': {
            'path': str(args.baseline_output),
            'sha256': sha256_file(args.baseline_output),
            'case_count': baseline['case_count'],
            'mean_makespan': baseline['mean_makespan'],
        },
        'hardware_contract': {
            'gpus': [0, 1], 'trainers_per_gpu': 3,
            'shared_evaluators_per_gpu': 1,
            'physical_core_isolation': True,
            'max_graphs_per_forward': 1000,
        },
    }
    wave = {
        **shared, 'phase': 'wave_a_structured_bc',
        'methods': BC_METHODS,
        'evaluator_source_method': next(iter(commands)),
        'evaluator_command': next(iter(commands.values()))['argv'],
        'commands': commands,
    }
    canary_keys = ('B1_candidate_ranking', 'B4_full_structure', 'B5_full_hard_dagger')
    canary_commands = {}
    for key in canary_keys:
        canary_key = f'C_{key}'
        command = canary_command(commands[key]['argv'], key)
        validate(command, bc_only=True)
        canary_commands[canary_key] = {
            'source_method': key, 'argv': command,
            'shell': shlex.join(command),
        }
    canary = {
        **shared, 'phase': 'production_layout_canary',
        'methods': canary_commands,
        'evaluator_source_method': next(iter(canary_commands)),
        'evaluator_command': next(iter(canary_commands.values()))['argv'],
        'commands': canary_commands,
    }
    atomic_json(args.wave_a_output, wave)
    atomic_json(args.canary_output, canary)
    return {'wave_a': str(args.wave_a_output), 'canary': str(args.canary_output)}


def evaluation_record(results_root: Path, command: list[str]) -> dict:
    experiment = option_value(command, '--experiment_name')
    run_dir = results_root / experiment / 'run1'
    evaluation = load_json(run_dir / 'evaluations/pre_ppo.json')
    summary = evaluation['summary']
    cases = evaluation['cases']
    checkpoint = run_dir / 'models/checkpoint_DeviceBC.pt'
    status = load_json(run_dir / 'run_status.json')
    policy_defer = [
        float(case.get('resource_policy_defer_seconds', 0.0))
        for case in cases
    ]
    return {
        'experiment_name': experiment,
        'run_dir': str(run_dir.resolve()),
        'checkpoint': str(checkpoint.resolve()),
        'checkpoint_sha256': sha256_file(checkpoint),
        'status': status.get('status'),
        'completion_rate': float(summary['eval_completion_rate']),
        'cycle_count': int(summary['eval_cycle_count']),
        'timeout_count': int(summary['eval_timeout_count']),
        'raw_makespan': float(summary['eval_raw_makespan']),
        'selection_score': float(summary['eval_selection_score']),
        'iid_makespan': float(summary['eval_iid_makespan']),
        'ood_stress_makespan': float(
            summary['eval_distribution_ood_stress_makespan']
        ),
        'tail_makespan': float(summary['eval_tail_makespan']),
        'policy_defer_mean': float(np.mean(policy_defer)),
        'case_signature_sha256': hashlib.sha256('\n'.join(
            f"{case['case_key']}:{case['case_sha256']}" for case in cases
        ).encode('utf-8')).hexdigest(),
    }


def ppo_command(source, key, method, *, run_tag, python, checkpoint, baseline):
    command = list(source)
    apply_common(
        command, python=python,
        experiment=f'{run_tag}_waveB_{key}_seed1',
    )
    set_option(command, '--resource_bc_checkpoint', checkpoint)
    set_option(command, '--device_bc_pretrain_epochs', 0)
    set_switch(command, '--device_bc_only', False)
    set_option(command, '--num_episodes', 3)
    set_option(command, '--gnn_freeze_epochs', 3)
    set_option(command, '--plane_freeze_epochs', 3)
    set_option(command, '--ppo_epoch', 1)
    set_option(command, '--lr', method['lr'])
    set_option(command, '--critic_lr', 1.0e-4)
    set_option(command, '--target_kl', 0.003)
    set_option(command, '--device_target_kl', 0.003)
    set_option(command, '--transporter_target_kl', 0.003)
    set_option(command, '--plane_loss_coef', 0.0)
    set_option(command, '--device_loss_coef', 0.5)
    set_option(command, '--transporter_loss_coef', 0.5)
    set_switch(command, '--joint_team_ppo', True)
    set_option(command, '--joint_team_ppo_scope', 'all')
    set_switch(command, '--role_atomic_ppo', True)
    set_switch(command, '--role_event_returns', True)
    set_switch(command, '--role_valuenorm', True)
    set_switch(
        command, '--counterfactual_q_baseline', method['counterfactual']
    )
    set_switch(command, '--role_sequential_ppo', False)
    set_option(command, '--role_event_credit_mode', (
        'critical_path' if method['critical'] else 'elapsed'
    ))
    set_option(command, '--role_event_credit_uniform_mix', 0.15)
    set_option(command, '--hindsight_reward_mode', 'team_time')
    set_option(command, '--iga_potential_beta', 0.0)
    set_option(command, '--iga_potential_beta_schedule', '0.0')
    remove_option(command, '--iga_potential_weights_path')
    if method['hard_kl']:
        set_option(command, '--bc_reference_kl_coef', 0.4)
        set_option(command, '--bc_reference_kl_coef_schedule', '0.40,0.25,0.10')
        set_option(command, '--bc_reference_target_kl', 0.02)
        set_switch(command, '--bc_reference_hard_gate', True)
    else:
        set_option(command, '--bc_reference_kl_coef', 0.0)
        set_option(command, '--bc_reference_kl_coef_schedule', '0.0')
        set_option(command, '--bc_reference_target_kl', 0.0)
        set_switch(command, '--bc_reference_hard_gate', False)
    if method['paired']:
        set_option(command, '--paired_case_baseline_dir', baseline)
        set_option(command, '--paired_case_baseline_coef', 1.0)
    else:
        remove_option(command, '--paired_case_baseline_dir')
        set_option(command, '--paired_case_baseline_coef', 0.0)
    if method['tail']:
        set_option(command, '--cvar_policy_fraction', 0.20)
        set_option(command, '--cvar_policy_weight', 2.0)
        set_option(command, '--cvar_case_metric', 'paired_delta')
    else:
        set_option(command, '--cvar_policy_fraction', 1.0)
        set_option(command, '--cvar_policy_weight', 1.0)
        set_option(command, '--cvar_case_metric', 'cmax')
    return command


def promote(args):
    wave_a = load_json(args.wave_a_output)
    records = []
    signatures = set()
    for key, entry in wave_a['commands'].items():
        record = {'method': key, **evaluation_record(
            args.results_root, entry['argv']
        )}
        record['eligible'] = bool(
            record['status'] == 'completed'
            and record['completion_rate'] == 1.0
            and record['cycle_count'] == 0
            and record['timeout_count'] == 0
        )
        signatures.add(record['case_signature_sha256'])
        records.append(record)
    if len(signatures) != 1:
        raise RuntimeError('Wave-A methods were not validated on identical cases.')
    eligible = [record for record in records if record['eligible']]
    if not eligible:
        raise RuntimeError('No safe structured DeviceBC candidate completed.')
    eligible.sort(key=lambda item: (
        item['selection_score'], item['raw_makespan'],
        item['policy_defer_mean'], item['method'],
    ))
    selected = eligible[0]
    control = next(item for item in records if item['method'].startswith('B0_'))
    for record in records:
        record['raw_delta_vs_control'] = (
            record['raw_makespan'] - control['raw_makespan']
        )
        record['policy_defer_delta_vs_control'] = (
            record['policy_defer_mean'] - control['policy_defer_mean']
        )
    selection = {
        'schema_version': 1,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'selected_method': selected['method'],
        'selected_checkpoint': selected['checkpoint'],
        'selected_checkpoint_sha256': selected['checkpoint_sha256'],
        'ranking': [item['method'] for item in eligible],
        'methods': records,
    }
    atomic_json(args.selection_output, selection)

    source = wave_a['commands'][selected['method']]['argv']
    commands = {}
    for key, method in PPO_METHODS.items():
        command = ppo_command(
            source, key, method, run_tag=args.run_tag, python=args.python,
            checkpoint=selected['checkpoint'], baseline=args.baseline_output,
        )
        validate(command, bc_only=False)
        commands[key] = {
            **method, 'family': 'residual_ppo_credit', 'argv': command,
            'shell': shlex.join(command),
        }
    wave_b = {
        **{key: value for key, value in wave_a.items()
           if key not in {'phase', 'methods', 'commands',
                          'evaluator_source_method', 'evaluator_command'}},
        'phase': 'wave_b_residual_ppo',
        'source_bc_selection': {
            'path': str(args.selection_output),
            'sha256': sha256_file(args.selection_output),
            'method': selected['method'],
            'checkpoint': selected['checkpoint'],
            'checkpoint_sha256': selected['checkpoint_sha256'],
        },
        'screen_gate': {
            'raw_cmax_improvement_seconds': 75.0,
            'matched_iga1800_gap_seconds_max': 100.0,
            'ood_stress_regression_seconds_max': 25.0,
            'tail_regression_seconds_max': 0.0,
            'paired_ci95_upper_seconds_max': 0.0,
            'catastrophic_regression_count_500_max': 0,
            'completion_rate_min': 1.0,
            'actor_step_completion_min': 0.90,
            'cycle_count_max': 0,
        },
        'methods': PPO_METHODS,
        'evaluator_source_method': next(iter(commands)),
        'evaluator_command': next(iter(commands.values()))['argv'],
        'commands': commands,
    }
    atomic_json(args.wave_b_output, wave_b)
    return {
        'selected_method': selected['method'],
        'wave_b': str(args.wave_b_output),
    }


def analyze(args):
    iga_raw = _matched_iga_raw(args.matched_iga)
    result = analyze_phase(
        args.wave_b_output,
        args.results_root,
        args.ppo_selection_output,
        iga1800_raw=iga_raw,
    )
    return {
        'selected_method': result.get('selected_method'),
        'eligible_methods': result.get('eligible_methods', []),
        'selection': str(args.ppo_selection_output),
        'matched_iga1800_raw_makespan': iga_raw,
    }


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        '--mode', choices=['prepare', 'promote', 'analyze'], required=True
    )
    parser.add_argument('--run-tag', default=RUN_TAG)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--teacher-index', type=Path, required=True)
    parser.add_argument('--python', type=Path, required=True)
    parser.add_argument('--canary-output', type=Path, required=True)
    parser.add_argument('--wave-a-output', type=Path, required=True)
    parser.add_argument('--wave-b-output', type=Path, required=True)
    parser.add_argument('--selection-output', type=Path, required=True)
    parser.add_argument('--baseline-output', type=Path, required=True)
    parser.add_argument(
        '--matched-iga', type=Path,
        default=(
            ROOT / 'result/hkbz_train_logs/'
            'stage2_matched_iga_tune60_20260827_r1/'
            'analysis/matched_iga_comparison.json'
        ),
    )
    parser.add_argument('--ppo-selection-output', type=Path, required=True)
    parser.add_argument(
        '--results-root', type=Path,
        default=ROOT / 'onpolicy/scripts/results/HKBZ/simple/gnn_mappo',
    )
    args = parser.parse_args()
    for name in (
        'suite_dir', 'source_manifest', 'teacher_index', 'python',
        'canary_output', 'wave_a_output', 'wave_b_output',
        'selection_output', 'baseline_output', 'matched_iga',
        'ppo_selection_output', 'results_root',
    ):
        setattr(args, name, getattr(args, name).expanduser().resolve())
    for path in (
        args.source_manifest, args.teacher_index, args.python,
        args.matched_iga,
    ):
        if not path.exists():
            raise FileNotFoundError(path)
    return args


def main():
    args = parse_args()
    args.suite_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        'prepare': prepare,
        'promote': promote,
        'analyze': analyze,
    }[args.mode](args)
    print(json.dumps({'status': 'ok', **payload}, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
