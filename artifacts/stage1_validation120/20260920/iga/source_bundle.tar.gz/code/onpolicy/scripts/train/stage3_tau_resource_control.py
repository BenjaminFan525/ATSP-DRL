#!/usr/bin/env python3
"""Finite, audited two-arm continuation; all arms share the native validator."""
import argparse
import copy
from datetime import timedelta
import gc
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json
from onpolicy.utils.stage3_tau import verify, training_plan, temperature_state, risk_pass
from onpolicy.utils.stage3_rl_bridge import identity, baseline_costs
from onpolicy.utils.stage3_tau_resources import (
    VERSION, RESIZE_VERSION, PLACEMENT, STOPPED, split_shards, validated_commit,
    resource_engine_class, resource_sizes, configure_kl_replay, NO_KL_REPLAY_VERSION,
)

NEW_FILES = (
    'onpolicy/utils/stage3_tau.py', 'onpolicy/utils/stage3_tau_resources.py',
    'onpolicy/scripts/train/stage3_tau_resource_control.py',
    'onpolicy/scripts/train/launch_stage3_tau.sh',
    'onpolicy/scripts/train/stage3_bridge_resource_core.py',
    'onpolicy/scripts/train/stage3_bridge_resource_control.py',
    'onpolicy/envs/HKBZ/test/test_stage3_tau_resources.py',
    'STAGE3_TAU_TWO_ARMS_20260917.md',
    'STAGE3_TAU_ENV60_PPO12_20260917.md',
)

NO_KL_FILES = (
    'onpolicy/utils/stage3_ppo_transaction.py',
    'onpolicy/utils/stage3_ppo_minibatches.py',
    'onpolicy/utils/stage3_tau_resources.py',
    'onpolicy/scripts/train/stage3_tau_resource_control.py',
    'onpolicy/envs/HKBZ/test/test_stage3_tau_resources.py',
    'onpolicy/envs/HKBZ/test/test_stage3_no_kl_replay.py',
    'STAGE3_TAU_NO_KL_REPLAY_20260917.md',
)


def prepare(args):
    parent = read_json(args.parent)
    verify(parent)
    parent_root, output = Path(parent['root']), args.output.resolve()
    if output.exists():
        raise FileExistsError('A resource restart needs a new frozen output directory')
    if 'resource_restart' in parent:
        raise ValueError('This operator transition starts from the original four-arm run')
    unit = 'hkbz-'+parent_root.name.replace('_', '-')
    for suffix in ('training', 'validator', 'guard'):
        active = subprocess.check_output(['systemctl', '--user', 'show', unit+'-'+suffix+'.service',
                                         '-p', 'ActiveState', '--value'], text=True).strip()
        if active not in ('inactive', 'failed'):
            raise RuntimeError('Original services must be stopped before reallocation')
    admission_path = parent_root/'training_admission.json'
    admission = read_json(admission_path)
    if not admission['passed'] or admission['manifest_sha256'] != parent['manifest_sha256']:
        raise ValueError('Original native B0/technical admission is missing')
    ranking, resumes = [], {}
    for arm in parent['arms']:
        path = sorted((parent_root/'full'/arm/'commits').glob('e*.json'))[-1]
        commit, cursor, state = validated_commit(parent, arm, path)
        updates = [read_json(p) for p in sorted((parent_root/'full'/arm/'rank0/updates').glob('e*.json'))]
        mean = sum(r['rollout_seconds']+r['update_seconds'] for r in updates)/len(updates)
        ranking.append(dict(arm=arm, committed_episodes=commit['training_episodes'],
                            mean_cycle_seconds=mean, saved_actor_updates=commit['policy_updates']))
        if arm in PLACEMENT:
            resumes[arm] = dict(commit=str(path.resolve()), commit_sha256=digest_file(path),
                next_group=cursor, state_sha256=state, training_episodes=commit['training_episodes'],
                policy_updates=commit['policy_updates'])
    ranking.sort(key=lambda r: (r['committed_episodes'], -r['mean_cycle_seconds']))
    if {r['arm'] for r in ranking[:2]} != set(STOPPED):
        raise ValueError('Measured slowest arms changed; do not silently stop different arms')
    files = dict(parent['code']['files'])
    for relative, checksum in files.items():
        if Path(relative).is_absolute() or '..' in Path(relative).parts:
            raise ValueError('Unsafe source snapshot entry')
        source, target = Path(parent['execution']['code_root'])/relative, output/'source'/relative
        if digest_file(source) != checksum:
            raise ValueError('Parent source changed')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    for relative in NEW_FILES:
        target = output/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT/relative, target)
        files[relative] = digest_file(target)
    m = copy.deepcopy(parent)
    m.update(root=str(output), created_unix=time.time(), code=dict(files=files, sha256=digest_json(files)))
    for key in ('path', 'manifest'):
        relative = Path(parent['source'][key]).relative_to(parent['execution']['code_root'])
        m['source'][key] = str(output/'source'/relative)
    m['execution'].update(code_root=str(output/'source'), base_source_sha256=parent['code']['sha256'])
    m['throughput'].update(rollout_envs_per_rank=30, backward_trajectories_per_rank=6)
    m['resources'].update(validator_queue=str(output/'validator'), screen_world_size=4,
        capacity_comparison='same global rollout120/minibatch24 sharded over four ranks')
    m['resource_restart'] = dict(version=VERSION, placement=PLACEMENT, stopped_arms=list(STOPPED),
        parent_manifest=str(args.parent.resolve()), parent_manifest_sha256=parent['manifest_sha256'],
        parent_manifest_file_sha256=digest_file(args.parent), resume_commits=resumes,
        ranking=ranking, selection_basis='committed progress; mean completed cycle duration breaks ties',
        until_epochs=4, logical_world_size=2, physical_world_size=4,
        global_rollout_trajectories=120, global_optimizer_trajectories=24,
        automatic_e8_continuation=False, bitwise_equivalence_claimed=False,
        remaining_trajectories={a: m['training']['first_stage_episodes']-r['training_episodes']
                                for a, r in resumes.items()},
        inherited_admission=str(admission_path), inherited_admission_sha256=digest_file(admission_path),
        authorization='User requested stop two slowest arms and allocate CPU/GPU to the other two',
        continuation_gate='Original T0-relative E4 gate unavailable; no automatic E8 promotion')
    m['material_passport'].update(version_label=VERSION,
        change_scope='Operator arm pruning and execution-only resource sharding; no reward selection')
    m['input_files'][str(args.parent.resolve())] = digest_file(args.parent)
    m['input_files'][str(admission_path)] = digest_file(admission_path)
    for resume in resumes.values():
        m['input_files'][resume['commit']] = resume['commit_sha256']
        for rank in read_json(resume['commit'])['ranks']:
            m['input_files'][rank['checkpoint']] = rank['sha256']
    m['manifest_sha256'] = identity(m)
    atomic_json(output/'baselines.json', read_json(parent_root/'baselines.json'), overwrite=False)
    atomic_json(output/'manifest.json', m, overwrite=False)
    atomic_json(output/'validator/mode.json', dict(mode='training'), overwrite=False)
    verify(m)
    stop = dict(status='stopped_by_operator', stopped_arms=list(STOPPED),
        retained_arms=list(PLACEMENT), ranking=ranking, restart_root=str(output),
        all_saved_artifacts_retained=True, uncommitted_batches_recollected=True, unix=time.time())
    atomic_json(parent_root/'operator_stop_20260917.json', stop, overwrite=False)
    atomic_json(parent_root/'status.json', {**read_json(parent_root/'status.json'), **stop})
    print(dict(manifest=str(output/'manifest.json'), placement=PLACEMENT, resumes=resumes), flush=True)


def prepare_resize(args):
    """Explicit operator batch-size change, never an execution-equivalence claim."""
    parent = read_json(args.parent)
    verify(parent)
    if parent.get('resource_restart', {}).get('version') != VERSION:
        raise ValueError('Batch doubling starts only from the audited 30-env / PPO6 four-rank run')
    parent_root, output = Path(parent['root']), args.output.resolve()
    if output.exists():
        raise FileExistsError('Batch doubling requires a new immutable output directory')
    unit = 'hkbz-'+parent_root.name.replace('_', '-')
    for suffix in ('training', 'validator', 'guard'):
        active = subprocess.check_output(['systemctl', '--user', 'show', unit+'-'+suffix+'.service',
                                         '-p', 'ActiveState', '--value'], text=True).strip()
        if active not in ('inactive', 'failed'):
            raise RuntimeError('Parent services must stop before batch resizing')
    admission_path = parent_root/'training_admission.json'
    admission = read_json(admission_path)
    if not admission['passed'] or admission['manifest_sha256'] != parent['manifest_sha256']:
        raise ValueError('Parent admission is missing')
    resumes = {}
    for arm in PLACEMENT:
        path = sorted((parent_root/'full'/arm/'commits').glob('e*.json'))[-1]
        commit, cursor, state = validated_commit(parent, arm, path)
        resumes[arm] = dict(commit=str(path.resolve()), commit_sha256=digest_file(path),
            next_group=cursor, state_sha256=state, training_episodes=commit['training_episodes'],
            policy_updates=commit['policy_updates'])
    switches = {ref['training_episodes'] for ref in resumes.values()}
    if len(switches) != 1:
        raise ValueError('Both arms must resize at the same committed data-epoch boundary')
    switch = switches.pop()
    if switch % parent['training']['episodes_per_data_epoch'] or not 0 < switch < parent['training']['first_stage_episodes']:
        raise ValueError('Latest checkpoints must complete a data epoch before the E4 endpoint')
    files = dict(parent['code']['files'])
    for relative, checksum in files.items():
        if Path(relative).is_absolute() or '..' in Path(relative).parts:
            raise ValueError('Unsafe source snapshot entry')
        source, target = Path(parent['execution']['code_root'])/relative, output/'source'/relative
        if digest_file(source) != checksum:
            raise ValueError('Parent source changed')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    for relative in NEW_FILES:
        target = output/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT/relative, target)
        files[relative] = digest_file(target)
    m = copy.deepcopy(parent)
    m.update(root=str(output), created_unix=time.time(), code=dict(files=files, sha256=digest_json(files)))
    for key in ('path', 'manifest'):
        relative = Path(parent['source'][key]).relative_to(parent['execution']['code_root'])
        m['source'][key] = str(output/'source'/relative)
    m['execution'].update(code_root=str(output/'source'), base_source_sha256=parent['code']['sha256'])
    m['throughput'].update(rollout_envs_per_rank=60, backward_trajectories_per_rank=12)
    m['resources'].update(validator_queue=str(output/'validator'),
        capacity_comparison='four ranks each env60/PPO12; global rollout240/optimizer48')
    m['resource_restart'].update(version=RESIZE_VERSION,
        parent_manifest=str(args.parent.resolve()), parent_manifest_sha256=parent['manifest_sha256'],
        parent_manifest_file_sha256=digest_file(args.parent), resume_commits=resumes,
        global_rollout_trajectories=240, global_optimizer_trajectories=48,
        remaining_trajectories={a: m['training']['first_stage_episodes']-switch for a in PLACEMENT},
        inherited_admission=str(admission_path), inherited_admission_sha256=digest_file(admission_path),
        authorization='User requested doubling environments and PPO batch on every GPU',
        batch_resize=dict(factor=2, from_version=VERSION, switch_episodes=switch,
            optimization_equivalence_claimed=False, same_trajectory_budget=True,
            temperature_cursor='absolute committed trajectories; thresholds unchanged',
            prior_epoch_evaluations='requeued in the single shared validator; originals retained'))
    m['material_passport'].update(version_label=RESIZE_VERSION,
        change_scope='User-authorized rollout and optimizer batch doubling; not optimizer-equivalent')
    m['input_files'][str(args.parent.resolve())] = digest_file(args.parent)
    m['input_files'][str(admission_path)] = digest_file(admission_path)
    for resume in resumes.values():
        m['input_files'][resume['commit']] = resume['commit_sha256']
        for entry in read_json(resume['commit'])['ranks']:
            m['input_files'][entry['checkpoint']] = entry['sha256']
    m['manifest_sha256'] = identity(m)
    atomic_json(output/'baselines.json', read_json(parent_root/'baselines.json'), overwrite=False)
    atomic_json(output/'manifest.json', m, overwrite=False)
    atomic_json(output/'validator/mode.json', dict(mode='training'), overwrite=False)
    verify(m)
    stop = dict(status='stopped_by_operator', reason='per-GPU env30/PPO6 to env60/PPO12',
        restart_root=str(output), saved_progress={a: r['training_episodes'] for a, r in resumes.items()},
        all_saved_artifacts_retained=True, uncommitted_batches_recollected=True, unix=time.time())
    atomic_json(parent_root/'operator_resize_20260917.json', stop, overwrite=False)
    atomic_json(parent_root/'status.json', {**read_json(parent_root/'status.json'), **stop})
    print(dict(manifest=str(output/'manifest.json'), placement=PLACEMENT, resumes=resumes), flush=True)


def prepare_no_kl_replay(args):
    """Resume unchanged batches from full-rank commits with no extra KL replay."""
    parent = read_json(args.parent)
    verify(parent)
    if (parent.get('resource_restart', {}).get('version') != RESIZE_VERSION
            or 'kl_replay_restart' in parent):
        raise ValueError('Expected the admitted env60/PPO12 run with KL replay enabled')
    parent_root, output = Path(parent['root']), args.output.resolve()
    if output.exists():
        raise FileExistsError('KL replay transition needs a new frozen output directory')
    unit = 'hkbz-'+parent_root.name.replace('_', '-')
    for suffix in ('training', 'validator', 'guard'):
        active = subprocess.check_output(['systemctl', '--user', 'show', unit+'-'+suffix+'.service',
                                         '-p', 'ActiveState', '--value'], text=True).strip()
        if active not in ('inactive', 'failed'):
            raise RuntimeError('Parent services must stop before the KL replay transition')
    admission_path = parent_root/'training_admission.json'
    admission = read_json(admission_path)
    if not admission['passed'] or admission['manifest_sha256'] != parent['manifest_sha256']:
        raise ValueError('Parent admission is missing')
    resumes = {}
    for arm in PLACEMENT:
        path = sorted((parent_root/'full'/arm/'commits').glob('e*.json'))[-1]
        commit, cursor, state = validated_commit(parent, arm, path)
        if commit['training_episodes'] >= parent['training']['first_stage_episodes']:
            raise ValueError('The authorized E4 budget has already finished')
        resumes[arm] = dict(commit=str(path.resolve()), commit_sha256=digest_file(path),
            next_group=cursor, state_sha256=state, training_episodes=commit['training_episodes'],
            policy_updates=commit['policy_updates'])
    files = dict(parent['code']['files'])
    for relative, checksum in files.items():
        if Path(relative).is_absolute() or '..' in Path(relative).parts:
            raise ValueError('Unsafe source snapshot entry')
        source, target = Path(parent['execution']['code_root'])/relative, output/'source'/relative
        if digest_file(source) != checksum:
            raise ValueError('Parent source changed')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    for relative in NO_KL_FILES:
        target = output/'source'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT/relative, target)
        files[relative] = digest_file(target)
    m = copy.deepcopy(parent)
    m.update(root=str(output), created_unix=time.time(), code=dict(files=files, sha256=digest_json(files)))
    for key in ('path', 'manifest'):
        relative = Path(parent['source'][key]).relative_to(parent['execution']['code_root'])
        m['source'][key] = str(output/'source'/relative)
    m['execution'].update(code_root=str(output/'source'), base_source_sha256=parent['code']['sha256'])
    m['resources']['validator_queue'] = str(output/'validator')
    m['resource_restart'].update(parent_manifest=str(args.parent.resolve()),
        parent_manifest_sha256=parent['manifest_sha256'], parent_manifest_file_sha256=digest_file(args.parent),
        resume_commits=resumes,
        remaining_trajectories={a: m['training']['first_stage_episodes']-r['training_episodes']
                                for a, r in resumes.items()},
        inherited_admission=str(admission_path), inherited_admission_sha256=digest_file(admission_path),
        authorization='User requested disabling KL replay and restarting the current experiments')
    m['kl_replay_restart'] = dict(version=NO_KL_REPLAY_VERSION,
        minibatch_replay=False, whole_batch_replay=False, pre_step_soft_kl=True,
        technical_rollback=True, optimization_equivalence_claimed=False,
        switch_episodes={a: r['training_episodes'] for a, r in resumes.items()},
        parent_schedule_sha256=digest_json(training_plan(parent, 2)))
    if training_plan(m, 2) != training_plan(parent, 2):
        raise ValueError('KL replay transition must not change any scheduled case, seed or batch')
    m['material_passport'].update(version_label=NO_KL_REPLAY_VERSION,
        change_scope='Disable extra post-step and whole-batch KL replay; keep inline soft KL and technical checks')
    for path in (args.parent.resolve(), admission_path):
        m['input_files'][str(path)] = digest_file(path)
    for resume in resumes.values():
        m['input_files'][resume['commit']] = resume['commit_sha256']
        for entry in read_json(resume['commit'])['ranks']:
            m['input_files'][entry['checkpoint']] = entry['sha256']
    m['manifest_sha256'] = identity(m)
    atomic_json(output/'baselines.json', read_json(parent_root/'baselines.json'), overwrite=False)
    atomic_json(output/'manifest.json', m, overwrite=False)
    atomic_json(output/'validator/mode.json', dict(mode='training'), overwrite=False)
    verify(m)
    stop = dict(status='stopped_by_operator', reason='Disable both extra KL replay guards',
        restart_root=str(output), saved_progress={a: r['training_episodes'] for a, r in resumes.items()},
        all_saved_artifacts_retained=True, uncommitted_batches_recollected=True, unix=time.time())
    atomic_json(parent_root/f'operator_no_kl_replay_{output.name}.json', stop, overwrite=False)
    atomic_json(parent_root/'status.json', {**read_json(parent_root/'status.json'), **stop})
    print(dict(manifest=str(output/'manifest.json'), resumes=resumes), flush=True)


def load_manifest(path):
    m = read_json(path)
    verify(m, source_root=ROOT)
    if m.get('resource_restart', {}).get('version') not in (VERSION, RESIZE_VERSION):
        raise ValueError('This controller requires its explicit resource restart contract')
    return m


def make_engine(m, arm, width):
    from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool
    runner = resource_engine_class(resource_sizes(m)[1])(m['source']['manifest'], 'F_PRIVATE', arm=arm, width=width,
        device='cuda:0', actor_lr=m['training']['actor_lr'], cache_mib=1024,
        replay_storage=m['replay_storage'], create_environments=False)
    configure_kl_replay(runner, m)
    runner.environment_start_method = m['throughput']['environment_start_method']
    runner.stochastic_batching = m['throughput']['stochastic_batching']
    runner.pool = EnvironmentPool(width, start_method=runner.environment_start_method)
    return runner


def resume_source(m, arm):
    restart = m['resource_restart']
    if digest_file(restart['parent_manifest']) != restart['parent_manifest_file_sha256']:
        raise ValueError('Parent manifest changed')
    parent = read_json(restart['parent_manifest'])
    ref = restart['resume_commits'][arm]
    if digest_file(ref['commit']) != ref['commit_sha256']:
        raise ValueError('Parent resume commit changed')
    commit, cursor, state = validated_commit(parent, arm, ref['commit'])
    if (cursor != ref['next_group'] or state != ref['state_sha256']
            or commit['training_episodes'] != ref['training_episodes']):
        raise ValueError('Resume state differs from the prepared contract')
    return parent, commit, cursor, state


def worker(args):
    import torch
    import torch.distributed as dist
    from onpolicy.utils.stage3_distributed import TrajectoryParallel, state_digest
    from onpolicy.utils.stage3_numerics import training_state
    from onpolicy.runner.shared.stage3_research_engine import seed_all
    from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
    from onpolicy.scripts.train.stage3_rl_bridge_worker import collect, metadata, save_rollouts, submit_evaluation
    from onpolicy.scripts.train.stage3_b0_worker import attach_journal
    m = load_manifest(args.manifest)
    if args.arm not in PLACEMENT or args.gpu != PLACEMENT[args.arm][args.rank]:
        raise ValueError('Physical rank/GPU ownership mismatch')
    root, output = Path(m['root']), args.output
    if not read_json(root/'training_admission.json')['passed']:
        raise ValueError('Resource admission required')
    os.sched_setaffinity(0, m['resources']['plan']['trainers'][str(args.gpu)]['cpus'])
    seed_all(m['training']['seed'])
    dist.init_process_group('gloo', init_method=f'file://{args.rendezvous.resolve()}',
        world_size=4, rank=args.rank, timeout=timedelta(hours=12))
    sync, runner = TrajectoryParallel(device_packed=True), None
    try:
        with ProgressHeartbeat(output/'heartbeat.json', task='train', arm=args.arm, phase='full',
                rank=args.rank, global_gpu=args.gpu, physical_world_size=4) as hb:
            width, micro = resource_sizes(m)
            runner = make_engine(m, args.arm, width)
            parent, commit, cursor, expected = resume_source(m, args.arm)
            source_rank = args.rank % commit['world_size']
            entry = commit['ranks'][source_rank]
            payload = runner.resume(entry['checkpoint'], protocol_sha256=parent['manifest_sha256'])
            if state_digest(training_state(runner)) != expected:
                raise ValueError('Model/optimizer/value normalizers changed during resume')
            sync.assert_replicas(runner)
            atomic_json(output/'resume.json', dict(parent_checkpoint=entry, source_rank=source_rank,
                physical_rank=args.rank, state_sha256=expected, next_group=cursor,
                training_episodes=runner.committed_episodes, policy_updates=runner.policy_updates,
                temperature_state=payload['temperature_state'], manifest_sha256=m['manifest_sha256']), overwrite=False)
            plan, costs = training_plan(m, 2), baseline_costs(m)
            plan_sha = digest_json(plan)
            for batch in plan[cursor:]:
                if batch['epoch'] > m['resource_restart']['until_epochs']:
                    break
                if any(sync.gather((root/'PAUSE_AFTER_COMMIT').exists())):
                    atomic_json(output/'paused_4.json', dict(paused=True, next_group=batch['index'],
                        training_episodes=runner.committed_episodes), overwrite=False)
                    return
                while sum(1 for _ in (root/'validator/pending').glob('*.json')) > 640:
                    hb.update(event='shared_validator_backpressure', next_group=batch['index'])
                    time.sleep(5)
                before = batch['training_episodes']-batch['batch_size']
                if runner.committed_episodes != before:
                    raise ValueError('Temperature and logical sampling cursor differ')
                state = runner.set_progress(before)
                if any(s != state for s in sync.gather(state)):
                    raise ValueError('Cross-rank temperature mismatch')
                items = split_shards(batch['shards'], micro)[args.rank]
                hb.update(event='batch_start', epoch=batch['epoch'], batch_index=batch['index'],
                    training_episodes=before, actual_actor_updates=runner.policy_updates,
                    sampling_tau=state['sampling_tau'], trajectories_per_rank=len(items))
                torch.cuda.reset_peak_memory_stats()
                begin = time.time()
                rows = collect(runner, items, hb)
                rollout_seconds = time.time()-begin
                rollout_memory = dict(allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                                      reserved_gib=torch.cuda.max_memory_reserved()/2**30)
                stem = f'e{batch["training_episodes"]:06d}'
                extra = dict(diagnostic_only=False, phase='full', rank=args.rank, world_size=4,
                    logical_world_size=2, resource_version=m['resource_restart']['version'],
                    kl_replay_enabled=runner.ppo_step_controller.replay_enabled)
                save_rollouts(output/f'rollouts/{stem}.json', rows,
                    metadata(m, args.arm, **extra, temperature_state=state, decision_stats=runner.last_decision_stats))
                attach_journal(runner, output/f'updates/{stem}_attempts.jsonl')
                torch.cuda.reset_peak_memory_stats()
                begin = time.time()
                result = runner.update(rows, 'source', costs, epochs=2, chunk=8, heartbeat=hb,
                    distributed=sync, microbatch_size=micro, optimizer_step_per_microbatch=True)
                result.update(rollout_seconds=rollout_seconds, update_seconds=time.time()-begin,
                    rollout_memory=rollout_memory, replay_storage=runner.replay_storage_report(),
                    update_memory=dict(allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                                       reserved_gib=torch.cuda.max_memory_reserved()/2**30))
                atomic_json(output/f'updates/{stem}.json', result, overwrite=False)
                if result['accepted_actor_steps'] == 0:
                    raise RuntimeError('No accepted PPO update; do not advance committed progress')
                model_sha = sync.assert_replicas(runner)
                episodes = batch['training_episodes']
                next_state = runner.set_progress(episodes)
                checkpoint = output/f'models/{stem}.pt'
                checksum = runner.save(checkpoint, **metadata(m, args.arm, **extra,
                    training_episodes=episodes, next_group=batch['index']+1, schedule_sha256=plan_sha))
                entries = sync.gather(dict(rank=args.rank, checkpoint=str(checkpoint), sha256=checksum,
                                            state_sha256=model_sha))
                if args.rank == 0:
                    commit_path = root/'full'/args.arm/f'commits/{stem}.json'
                    atomic_json(commit_path, dict(manifest_sha256=m['manifest_sha256'], arm=args.arm,
                        phase='full', world_size=4, logical_world_size=2,
                        resource_version=m['resource_restart']['version'],
                        ranks=entries, schedule_sha256=plan_sha, training_episodes=episodes,
                        policy_updates=runner.policy_updates, temperature_state=next_state), overwrite=False)
                    if batch['epoch_tail']:
                        requests = {s: submit_evaluation(m, checkpoint, args.arm, episodes, 'full', split=s)
                                    for s in ('validation', 'tune')}
                        atomic_json(root/'full'/args.arm/f'epochs/e{batch["epoch"]:02d}.json', dict(
                            checkpoint=str(checkpoint), checkpoint_sha256=checksum, requests=requests,
                            training_episodes=episodes, policy_updates=runner.policy_updates,
                            temperature_state=next_state, commit=str(commit_path)), overwrite=False)
                sync.barrier()
                hb.update(event='batch_committed', training_episodes=episodes,
                    actual_actor_updates=runner.policy_updates, sampling_tau=next_state['sampling_tau'],
                    rollout_seconds=rollout_seconds, update_seconds=result['update_seconds'])
                del rows
                runner.release_replay()
                gc.collect()
            atomic_json(output/'result_epoch4.json', dict(completed=True,
                training_episodes=runner.committed_episodes, policy_updates=runner.policy_updates,
                temperature_state=temperature_state(args.arm, runner.committed_episodes)), overwrite=False)
    except BaseException as exc:
        atomic_json(output/'error.json', dict(error=str(exc), traceback=traceback.format_exc(), unix=time.time()))
        raise
    finally:
        if runner is not None:
            runner.close()
        dist.destroy_process_group()


def run(args):
    from onpolicy.scripts.train.run_stage3_tau import TauSuite
    from onpolicy.scripts.train.run_stage3_rl_bridge import child_environment
    from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
    m = load_manifest(args.manifest)
    root = Path(m['root'])
    receipt = read_json(root/'verification.json')
    if (not receipt['passed'] or receipt['manifest_sha256'] != m['manifest_sha256']
            or receipt['code_sha256'] != m['code']['sha256']
            or digest_file(receipt['junit']) != receipt['junit_sha256']
            or any(digest_file(r['path']) != r['sha256'] for r in receipt['cuda_reports'].values())):
        raise ValueError('Source-bound resource verification missing or changed')
    suite = TauSuite(m, args.manifest)
    os.sched_setaffinity(0, m['resources']['plan']['controller'])
    processes = []
    try:
        with ProgressHeartbeat(root/'heartbeat.json', pid=os.getpid(), version=m['resource_restart']['version']) as hb:
            suite.pool_mode('training', hb)
            atomic_json(root/'status.json', dict(status='running', phase='resource_train_full_4',
                arms=PLACEMENT, stopped_arms=list(STOPPED), iga='frozen; no solving', unix=time.time()))
            if m['resource_restart']['version'] == RESIZE_VERSION:
                from onpolicy.scripts.train.stage3_rl_bridge_worker import submit_evaluation
                parent_root = Path(read_json(m['resource_restart']['parent_manifest'])['root'])
                for arm in PLACEMENT:
                    episodes = m['resource_restart']['resume_commits'][arm]['training_episodes']
                    for epoch in range(1, episodes//m['training']['episodes_per_data_epoch']+1):
                        prior_path = parent_root/'full'/arm/f'epochs/e{epoch:02d}.json'
                        prior = read_json(prior_path)
                        if digest_file(prior['checkpoint']) != prior['checkpoint_sha256']:
                            raise ValueError('Inherited epoch checkpoint changed')
                        requests = {s: submit_evaluation(m, prior['checkpoint'], arm,
                            prior['training_episodes'], 'full', split=s) for s in ('validation', 'tune')}
                        atomic_json(root/'full'/arm/f'epochs/e{epoch:02d}.json',
                            {**prior, 'requests': requests, 'inherited_from': str(prior_path)}, overwrite=False)
            for arm, gpus in PLACEMENT.items():
                rendezvous = root/'rendezvous'/arm
                rendezvous.parent.mkdir(parents=True, exist_ok=True)
                if rendezvous.exists():
                    raise FileExistsError('No automatic rendezvous or run reuse')
                for rank, gpu in enumerate(gpus):
                    output = root/'full'/arm/f'rank{rank}'
                    output.mkdir(parents=True, exist_ok=True)
                    cmd = [m['execution']['python'], '-B', '-u', str(ROOT/NEW_FILES[2]), 'worker',
                        '--manifest', str(args.manifest), '--arm', arm, '--rank', str(rank),
                        '--gpu', str(gpu), '--output', str(output), '--rendezvous', str(rendezvous)]
                    env = child_environment(m, gpu)
                    env['GLOO_SOCKET_IFNAME'] = 'lo'
                    with (output/'worker.log').open('ab') as log:
                        process = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
                    processes.append((arm, rank, process))
                    atomic_json(output/f'process_{process.pid}.json', dict(pid=process.pid, command=cmd,
                        started_unix=time.time(), gpu=gpu), overwrite=False)
            while True:
                suite.check()
                codes = [(a, r, process.poll()) for a, r, process in processes]
                if any(code not in (None, 0) for _, _, code in codes):
                    raise RuntimeError(f'Resource worker failed; no automatic retry: {codes}')
                hb.update(event='workers_running', phase='resource_train_full_4',
                    live=sum(code is None for _, _, code in codes), workers=codes)
                if all(code == 0 for _, _, code in codes):
                    break
                time.sleep(10)
            for arm in PLACEMENT:
                for rank in range(4):
                    result = read_json(root/'full'/arm/f'rank{rank}/result_epoch4.json')
                    if not result['completed'] or result['training_episodes'] != m['training']['first_stage_episodes']:
                        raise ValueError('Worker exited without completing the authorized E4 endpoint')
            atomic_json(root/'train_full_4_completed.json', dict(exits=codes, unix=time.time()), overwrite=False)
            suite.pool_mode('evaluation_only', hb)
            curves = {a: [suite.collect_epoch('full', a, e, hb) for e in range(1, 5)] for a in PLACEMENT}
            atomic_json(root/'learning_curves.json', curves, overwrite=False)
            endpoint = {a: curve[-1] for a, curve in curves.items()}
            role_arm = min(endpoint, key=lambda a: endpoint[a]['validation']['makespan'])
            atomic_json(root/'e4_comparison.json', dict(evaluations=endpoint, candidate=None,
                stopped_arms=list(STOPPED), automatic_e8_continuation=False,
                reason=m['resource_restart']['continuation_gate'], role_mix_diagnostic_arm=role_arm), overwrite=False)
            suite.diagnostics(list(PLACEMENT), 4, hb, role_arm=role_arm)
            indexes = {}
            for arm, curve in curves.items():
                qualified = [(e+1, row) for e, row in enumerate(curve)
                    if all(risk_pass(row[s]) and row[s]['gain_fraction'] >= 0 for s in ('validation', 'tune'))]
                best = min(qualified, key=lambda x: (x[1]['validation']['makespan'], x[0])) if qualified else None
                indexes[arm] = dict(Last=read_json(root/'full'/arm/'epochs/e04.json'),
                    ValidationBest=read_json(root/'full'/arm/f'epochs/e{best[0]:02d}.json') if best else None,
                    risk_qualified=best is not None, final_epoch=4,
                    final_main_target_met=all(risk_pass(curve[-1][s]) and curve[-1][s]['gain_fraction'] >= .01
                                              for s in ('validation', 'tune')))
            atomic_json(root/'model_index.json', indexes, overwrite=False)
            suite.finish(dict(training_completed=True, epochs_by_arm={a: 4 for a in PLACEMENT},
                stopped_arms=list(STOPPED), automatic_e8_continuation=False,
                reason=m['resource_restart']['continuation_gate'],
                main_target_arms=[a for a, row in indexes.items() if row['final_main_target_met']]))
    except BaseException as exc:
        atomic_json(root/'status.json', dict(status='failed', error=str(exc),
            traceback=traceback.format_exc(), automatic_retry=False, unix=time.time()))
        raise
    finally:
        suite.lock.close()


def probe_comparisons(m):
    # A replay-only restart never changes PPO12 into accumulated PPO6. Compare
    # the actual intervention on the SAME batch shape; keep old resize probes
    # and their numerical tolerances unchanged.
    if 'kl_replay_restart' in m:
        return 'same_ppo12_replay_on_vs_off', ((12, True), (12, False))
    return 'ppo12_vs_accumulated6', ((12, True), (6, True))


def probe(args):
    """CUDA prefix checks matched to the transition; all diagnostic state restored."""
    import torch
    from onpolicy.runner.shared.stage3_research_engine import ResearchEngine, seed_all
    from onpolicy.scripts.train.stage3_rl_bridge_worker import make_engine as native_engine, collect
    from onpolicy.scripts.train.stage3_bridge_resource_control import compare_gradient_proposals
    from onpolicy.utils.stage3_rl_bridge import actor_targets
    from onpolicy.utils.stage3_tau import ARMS
    from onpolicy.utils.stage3_distributed import state_digest
    from onpolicy.utils.stage3_numerics import training_state
    m = load_manifest(args.manifest)
    os.sched_setaffinity(0, m['resources']['plan']['trainers'][str(args.gpu)]['cpus'])
    seed_all(m['training']['seed'])
    args.output.mkdir(parents=True, exist_ok=True)
    parent, commit, cursor, expected = resume_source(m, args.arm)
    checkpoint = commit['ranks'][0]['checkpoint']
    resized = m['resource_restart']['version'] == RESIZE_VERSION
    probe_width, prefix_steps = (60, 64) if resized else (12, 32)
    runner = native_engine(m, args.arm, probe_width)
    configure_kl_replay(runner, m)
    original_call = runner.pool.call
    def prefix(commands):
        results = original_call(commands)
        for index, kind, _ in commands:
            if kind == 'summary':
                results[index] = {**results[index], 'completed': True, 'synthetic_prefix_fixture': True}
        return results
    runner.pool.call = prefix
    captured = []
    class Captured(Exception):
        pass
    try:
        runner.resume(checkpoint, protocol_sha256=parent['manifest_sha256'])
        if state_digest(training_state(runner)) != expected:
            raise ValueError('Original checkpoint did not restore exactly')
        batch = training_plan(m, 2)[cursor]
        items = split_shards(batch['shards'], 12)[0] if resized else batch['shards'][0][:12]
        torch.cuda.reset_peak_memory_stats()
        collected = runner.rollout([r['case'] for r in items], [r['seed'] for r in items],
                                   retain=True, max_steps=prefix_steps)
        rollout_memory = dict(allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                              reserved_gib=torch.cuda.max_memory_reserved()/2**30)
        for row, item in zip(collected, items):
            row.update(group_id=item['group_id'], replica=item['replica'], population_weight=item['weight'])
        rows = collected[:12]
        comparison_scope, comparisons = probe_comparisons(m)
        replay_parts = (rows,) if 'kl_replay_restart' in m else (rows, rows[:6], rows[6:])
        replay = [runner.replay_metrics(part) for part in replay_parts]
        if any(r['max_logp_error'] > .002 for r in replay):
            raise ValueError('Likelihood replay failed the original tolerance')
        memory = []
        for micro, replay_enabled in comparisons:
            runner.ppo_step_controller.replay_enabled = replay_enabled
            runner.resume(checkpoint, protocol_sha256=parent['manifest_sha256'])
            before = state_digest(training_state(runner))
            a, w, _ = actor_targets(rows, args.arm, baseline_costs(m), arm_spec=ARMS[args.arm])
            fixed = {id(r): (av, wt) for r, av, wt in zip(rows, a, w)}
            runner.stage3_actor_objective = lambda rs: ([fixed[id(r)][0] for r in rs], [fixed[id(r)][1] for r in rs])
            def capture(epoch, ac, stats):
                captured.append({name: p.grad.detach().cpu().clone() for name, p in ac.named_parameters()
                                 if p.grad is not None})
                raise Captured()
            torch.cuda.reset_peak_memory_stats()
            try:
                ResearchEngine.update(runner, rows, 'source', baseline_costs(m), epochs=1, chunk=8,
                    allow_multi_case=True, visit_balanced=True, microbatch_size=micro, gradient_callback=capture)
            except Captured:
                pass
            else:
                raise RuntimeError('Gradient probe unexpectedly reached optimizer stepping')
            if state_digest(training_state(runner)) != before:
                raise ValueError('Diagnostic changed live training state')
            memory.append(dict(microbatch=micro, kl_replay_enabled=replay_enabled,
                               allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                               reserved_gib=torch.cuda.max_memory_reserved()/2**30))
        before = state_digest(training_state(runner))
        passed, comparison = compare_gradient_proposals(runner, *captured)
        if state_digest(training_state(runner)) != before:
            raise ValueError('Detached CPU Adam proposal changed live model/optimizer state')
        ppo_smoke = None
        if resized:
            # Ephemeral prefix-only PPO/KL smoke. Never save or train from these
            # synthetic diagnostic weights; restore the exact parent afterward.
            runner.resume(checkpoint, protocol_sha256=parent['manifest_sha256'])
            torch.cuda.reset_peak_memory_stats()
            original_replay = runner.replay_metrics
            def forbidden_replay(*unused_args, **unused_kwargs):
                raise AssertionError('Disabled KL replay must never run during PPO')
            if 'kl_replay_restart' in m:
                runner.replay_metrics = forbidden_replay
            try:
                ppo_smoke = runner.update(rows, 'source', baseline_costs(m), epochs=1, chunk=8,
                    microbatch_size=12, optimizer_step_per_microbatch=True)
            finally:
                runner.replay_metrics = original_replay
            memory.append(dict(microbatch=12, phase='prefix_ppo_kl_smoke',
                allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                reserved_gib=torch.cuda.max_memory_reserved()/2**30))
            runner.resume(checkpoint, protocol_sha256=parent['manifest_sha256'])
            if state_digest(training_state(runner)) != expected:
                raise ValueError('Diagnostic PPO state did not restore to the parent exactly')
            if ppo_smoke['accepted_actor_steps'] < 1:
                raise ValueError('PPO12 prefix smoke failed the unchanged PPO/KL transaction')
        capacity_limit = torch.cuda.get_device_properties(0).total_memory/2**30-1.5
        memory_ok = max(r['reserved_gib'] for r in [rollout_memory, *memory]) < capacity_limit
        passed = passed and memory_ok
        atomic_json(args.output/'result.json', dict(passed=passed, arm=args.arm, diagnostic_only=True,
            kl_replay_enabled=runner.ppo_step_controller.replay_enabled,
            manifest_sha256=m['manifest_sha256'], code_sha256=m['code']['sha256'],
            checkpoint_sha256=digest_file(checkpoint), no_optimizer_steps=not resized,
            diagnostic_ppo_smoke=ppo_smoke, restored_parent_state=True,
            prefix_steps=prefix_steps, trajectories=len(collected), gradient_trajectories=12,
            actual_rollout_environments=runner.width, not_full_trajectory_admission=True,
            comparison=comparison, comparison_scope=comparison_scope,
            likelihood_replay=replay, memory=memory, rollout_memory=rollout_memory,
            memory_headroom_passed=memory_ok, memory_limit_gib=capacity_limit, unix=time.time()), overwrite=False)
        if not passed:
            raise ValueError(f'CUDA gradient/Adam proposal comparison failed: {comparison}')
    finally:
        if hasattr(runner, 'stage3_actor_objective'):
            del runner.stage3_actor_objective
        runner.close()


def seal_tests(args):
    m = load_manifest(args.manifest)
    cases = list(ET.parse(args.junit).getroot().iter('testcase'))
    required = ('test_tau_resource_schedule', 'test_tau_resource_targets', 'test_tau_resource_gloo',
                'test_tau_resource_contract', 'test_tau_resource_resume', 'test_tau_engine_resume')
    if m['resource_restart']['version'] == RESIZE_VERSION:
        required += ('test_tau_resource_resize_schedule', 'test_tau_resource_resize_contract',
                     'test_tau_resource_resize_resume')
    if 'kl_replay_restart' in m:
        required += ('test_no_kl_replay',)
    if (not cases or any(c.find(k) is not None for c in cases for k in ('failure', 'error', 'skipped'))
            or any(not any(c.attrib.get('name', '').startswith(prefix) for c in cases) for prefix in required)):
        raise ValueError('All source-bound resource/resume tests must pass without skips')
    reports = {}
    for arm in PLACEMENT:
        path = Path(m['root'])/'probes'/arm/'result.json'
        report = read_json(path)
        if (not report['passed'] or report['arm'] != arm
                or report['manifest_sha256'] != m['manifest_sha256'] or report['code_sha256'] != m['code']['sha256']):
            raise ValueError('Source-bound real CUDA diagnostic required for both arms')
        if m['resource_restart']['version'] == VERSION and not report['no_optimizer_steps']:
            raise ValueError('Original sharding diagnostic cannot make optimizer steps')
        if m['resource_restart']['version'] == RESIZE_VERSION and (
                report.get('actual_rollout_environments') != 60 or report.get('trajectories') != 60
                or report.get('gradient_trajectories') != 12 or report.get('prefix_steps') != 64
                or not report.get('memory_headroom_passed') or not report.get('restored_parent_state')
                or report.get('diagnostic_ppo_smoke', {}).get('accepted_actor_steps', 0) < 1):
            raise ValueError('Batch doubling requires an actual env60/PPO12 CUDA prefix probe')
        if 'kl_replay_restart' in m and (report.get('kl_replay_enabled') is not False
                or report.get('comparison_scope') != 'same_ppo12_replay_on_vs_off'
                or report.get('diagnostic_ppo_smoke', {}).get('kl_replay_enabled') is not False):
            raise ValueError('The real CUDA PPO smoke must execute with both KL replays disabled')
        reports[arm] = dict(path=str(path), sha256=digest_file(path))
    receipt = dict(passed=True, manifest_sha256=m['manifest_sha256'], code_sha256=m['code']['sha256'],
        test_cases=len(cases), junit=str(args.junit.resolve()), junit_sha256=digest_file(args.junit),
        cuda_reports=reports, inherited_admission=m['resource_restart']['inherited_admission'],
        scope='Resource execution/resume verification; original full-trajectory/native B0 admission inherited')
    atomic_json(Path(m['root'])/'verification.json', receipt, overwrite=False)
    atomic_json(Path(m['root'])/'training_admission.json', {**receipt,
        'diagnostic_weights_used': False, 'iga_solve_count': 0}, overwrite=False)
    print(dict(passed=True, test_cases=len(cases), arms=list(reports)), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('prepare', 'prepare-resize', 'prepare-no-kl-replay',
                                          'worker', 'run', 'probe', 'seal-tests'))
    parser.add_argument('--parent', type=Path)
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--arm', choices=tuple(PLACEMENT))
    parser.add_argument('--rank', type=int)
    parser.add_argument('--gpu', type=int)
    parser.add_argument('--rendezvous', type=Path)
    parser.add_argument('--junit', type=Path)
    args = parser.parse_args()
    return dict(prepare=prepare, worker=worker, run=run, probe=probe,
        **{'prepare-resize': prepare_resize, 'prepare-no-kl-replay': prepare_no_kl_replay,
           'seal-tests': seal_tests})[args.command](args)


if __name__ == '__main__':
    main()
