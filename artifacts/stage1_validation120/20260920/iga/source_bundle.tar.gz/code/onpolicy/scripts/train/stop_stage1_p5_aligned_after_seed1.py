#!/usr/bin/env python3
"""Retire already-running P5 lanes after seed1, without restarting trainers.

The frozen controllers have all three seeds in memory. Leave their preparation
stages alone; freeze only the parent controller once formal seed1 starts. Its
trainer and shared validator keep running. Drain validation and check the real
trainer exit before retiring the service. Reservation markers in deferred run
parents also make the old controller's no-overwrite check fail closed if this
guard is unavailable. No frozen training code or command is changed.
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.scripts.train.stop_stage1_learning_baselines_after_wave1 import (
    METHODS, atomic_json, process_snapshot, read_json, require_process,
)

POLICY_NAME = "complete_seed1_only"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_policy(suite):
    manifest = read_json(suite / "manifest.json")
    policy = read_json(suite / "execution_policy.json")
    if manifest.get("scope") != "stage1_p5_aligned_baselines":
        raise ValueError("Unexpected suite scope")
    if tuple(lane["method"] for lane in manifest["lanes"]) != METHODS:
        raise ValueError("Expected exactly the four approved baselines")
    if (policy.get("policy") != POLICY_NAME
            or policy.get("allowed_formal_seeds") != [1]
            or policy.get("deferred_formal_seeds") != [2, 3]
            or policy.get("manifest_sha256") != digest(suite / "manifest.json")):
        raise ValueError("Seed1 execution policy does not match the frozen suite")
    launch = read_json(suite / "launch_record.json")
    units = {item["method"]: item["unit"] for item in launch["units"]
             if item["role"] == "lane"}
    expected_prefix = "hkbz-p5b-" + hashlib.sha256(
        manifest["run_tag"].encode()).hexdigest()[:10]
    for lane in manifest["lanes"]:
        method = lane["method"]
        if units.get(method) != f"{expected_prefix}-{method}.service":
            raise ValueError("Unexpected lane service identity")
        phases = lane["phases"]
        if [(p["phase"], p["seed"]) for p in phases] != [
            ("canary", 1), ("initial_bc", 1), ("warm_ppo", 1),
            ("departure_bc", 1), ("formal", 1), ("formal", 2), ("formal", 3),
        ]:
            raise ValueError("Unexpected phase sequence")
        for phase in phases:
            if phase["seed"] == 1:
                continue
            run_dir = Path(phase["run_dir"])
            marker = read_json(run_dir.parent / "DEFERRED_BY_USER.json")
            if (marker.get("policy") != POLICY_NAME
                    or marker.get("method") != method
                    or marker.get("seed") != phase["seed"]
                    or marker.get("run_tag") != manifest["run_tag"]
                    or run_dir.exists()):
                raise ValueError("Deferred phase is not safely reserved/unstarted")
    return manifest, units


def controller_snapshot(suite, method, lane_state, previous=None):
    return require_process(
        int(lane_state["pid"]),
        expected_text=("run_stage1_p5_aligned_suite.py", str(suite / "manifest.json"),
                       "--role lane", f"--method {method}"),
        expected_start_ticks=(previous or {}).get("controller_start_ticks"),
    )


def freeze_formal(suite, method, spec, lane_state, previous=None):
    """Stop the exact scheduling parent, never the active training child."""
    if lane_state["phase"] != "formal_seed1":
        raise ValueError("Only formal seed1 may be adopted by this guard")
    controller = controller_snapshot(suite, method, lane_state, previous)
    child = process_snapshot(int(lane_state["training_pid"]))
    if child is None or child["ppid"] != controller["pid"]:
        raise RuntimeError("Trainer is not a child of the expected controller")
    expected_child_start = (previous or {}).get("training_start_ticks")
    if expected_child_start is not None and child["start_ticks"] != expected_child_start:
        raise RuntimeError("Trainer PID recycled; controller remains stopped")
    if child["state"] != "Z" and spec["experiment"] not in child["cmdline"]:
        raise RuntimeError("Trainer identity does not match formal seed1")
    if controller["state"] not in {"T", "t"}:
        os.kill(controller["pid"], signal.SIGSTOP)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if controller_snapshot(suite, method, lane_state, previous)["state"] in {"T", "t"}:
                break
            time.sleep(0.05)
        else:
            raise RuntimeError("Controller did not freeze")
    latest = read_json(Path(spec["status_path"]))
    if (latest.get("phase") != "formal_seed1"
            or latest.get("training_pid") != child["pid"]):
        raise RuntimeError("Phase changed while freezing; controller left stopped")
    return {
        "state": "formal_seed1_running_controller_frozen",
        "controller_pid": controller["pid"],
        "controller_start_ticks": controller["start_ticks"],
        "training_pid": child["pid"],
        "training_start_ticks": child["start_ticks"],
        "frozen_unix_time": (previous or {}).get("frozen_unix_time", time.time()),
    }


def trainer_wait_status(pid):
    # /proc stat field 52 is the waitpid-style exit status (suffix starts at 3).
    raw = Path(f"/proc/{pid}/stat").read_text()
    return int(raw.rpartition(")")[2].split()[49])


def formal_outcome(spec, child):
    """None means trainer still owns its outputs (including validation drain)."""
    if child is not None and child["state"] != "Z":
        return None
    if child is None:
        return False, "Trainer disappeared before its exit could be verified"
    wait_status = trainer_wait_status(child["pid"])
    if wait_status != 0:
        return False, f"Trainer wait status {wait_status}; no automatic retry"
    run_dir = Path(spec["run_dir"])
    try:
        runtime = read_json(run_dir / "run_status.json")
        evaluation = read_json(run_dir / "async_evaluation/status.json")
    except (FileNotFoundError, ValueError) as error:
        return False, f"Missing/unreadable final evidence: {error}"
    if runtime.get("status") != "completed":
        return False, f"Trainer final status is {runtime.get('status')}"
    if (evaluation.get("pending") != []
            or len(evaluation.get("completed", [])) != spec["required_evaluations"]):
        return False, "Not all prescribed evaluations were drained"
    if not (run_dir / "models/checkpoint_Best.pt").is_file():
        return False, "Missing Best checkpoint"
    return True, "Seed1 completed and all prescribed evaluations drained"


def stop_owned_service(unit, controller_pid):
    current = subprocess.check_output(
        ["systemctl", "--user", "show", unit, "--property=MainPID", "--value"],
        text=True, timeout=10,
    ).strip()
    if current != str(controller_pid):
        raise RuntimeError(f"Service ownership changed: {unit}, MainPID={current}")
    # This occurs only after trainer exit, or at the original 72h hard timeout.
    # systemd terminates the stopped scheduling parent and its owned cgroup.
    subprocess.run(["systemctl", "--user", "stop", unit], check=True, timeout=210)


def retire_lane(spec, unit, lane_state, adopted, successful, reason, now):
    stop_owned_service(unit, adopted["controller_pid"])
    result = dict(lane_state)
    completed = list(result["completed_phases"])
    if successful:
        artifact = Path(spec["run_dir"]) / "models/checkpoint_Best.pt"
        completed.append({"phase": "formal_seed1",
                          "elapsed_seconds": now - result["phase_started_unix_time"],
                          "artifact": str(artifact), "artifact_sha256": digest(artifact)})
    result.update({
        "status": "completed" if successful else "failed",
        "completed_phases": completed, "seed1_only": True,
        "completed_formal_seeds": [1] if successful else [],
        "deferred_formal_seeds": [2, 3], "stop_reason": reason,
        "training_pid": None, "heartbeat_unix_time": now,
        "completed_unix_time" if successful else "failed_unix_time": now,
    })
    atomic_json(Path(spec["status_path"]), result)
    return {**adopted, "state": result["status"], "reason": reason,
            "finished_unix_time": now}


def run(suite, poll_seconds, check_only=False):
    manifest, units = load_policy(suite)
    policy_hash = digest(suite / "execution_policy.json")
    checked = {}
    for lane in manifest["lanes"]:
        state = read_json(Path(lane["status_path"]))
        if state["status"] in {"completed", "failed"}:
            checked[lane["method"]] = {"phase": state.get("phase"), "status": state["status"]}
            continue
        if state.get("phase") in {"formal_seed2", "formal_seed3"}:
            raise RuntimeError("Later seed reached; inspect instead of adopting")
        process = controller_snapshot(suite, lane["method"], state)
        checked[lane["method"]] = {"phase": state["phase"], "controller_pid": process["pid"],
                                   "controller_start_ticks": process["start_ticks"],
                                   "training_pid": state.get("training_pid")}
    if check_only:
        import json
        print(json.dumps({"status": "check_ok", "policy": POLICY_NAME,
                          "lanes": checked}, indent=2))
        return 0
    records = suite / "records"
    records.mkdir(exist_ok=True)
    lock = (records / "seed1_stop_guard.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state_path = records / "seed1_stop_guard.json"
    guard = read_json(state_path) if state_path.exists() else {
        "policy": POLICY_NAME, "policy_sha256": policy_hash,
        "started_unix_time": time.time(), "lanes": checked,
    }
    if guard["policy_sha256"] != policy_hash:
        raise ValueError("Guard cannot adopt a different execution policy")
    guard.update({"pid": os.getpid(), "status": "monitoring", "poll_seconds": poll_seconds})
    atomic_json(state_path, guard)
    print("[Seed1Only] Armed; preparation stays runnable; later-seed reservations are present.", flush=True)
    try:
        while True:
            unfinished = []
            now = time.time()
            for lane in manifest["lanes"]:
                method = lane["method"]
                state = read_json(Path(lane["status_path"]))
                previous = guard["lanes"].get(method, {})
                if state["status"] in {"completed", "failed"}:
                    guard["lanes"][method] = {**previous, "state": state["status"],
                                               "phase": state.get("phase")}
                    continue
                unfinished.append(method)
                controller_snapshot(suite, method, state, previous)
                if state["phase"] != "formal_seed1":
                    if state["phase"] in {"formal_seed2", "formal_seed3"}:
                        raise RuntimeError("Deferred seed boundary unexpectedly reached")
                    guard["lanes"][method] = {**previous, "state": "preparation_running",
                                               "phase": state["phase"],
                                               "training_pid": state.get("training_pid")}
                    continue
                formal = dict(next(p for p in lane["phases"]
                                   if p["phase"] == "formal" and p["seed"] == 1),
                              status_path=lane["status_path"])
                adopted = freeze_formal(suite, method, formal, state, previous)
                if previous.get("frozen_unix_time") is None:
                    print(f"[Frozen] {method} parent={adopted['controller_pid']}; seed1 trainer remains runnable", flush=True)
                guard["lanes"][method] = adopted
                atomic_json(state_path, guard)
                child = process_snapshot(adopted["training_pid"])
                if child is not None and child["start_ticks"] != adopted["training_start_ticks"]:
                    raise RuntimeError("Trainer PID recycled; refusing to signal")
                outcome = formal_outcome(formal, child)
                if outcome is None and now - state["phase_started_unix_time"] > formal["timeout_seconds"]:
                    outcome = False, "Original 72h phase hard timeout exceeded"
                    print(f"[HardTimeout] {method}: stopping only its owned service", flush=True)
                if outcome is not None:
                    guard["lanes"][method] = retire_lane(
                        formal, units[method], state, adopted, *outcome, now)
                    print(f"[Retired] {method}: {outcome[1]}; seeds2/3 remain deferred", flush=True)
            guard.update({"heartbeat_unix_time": time.time(), "unfinished_methods": unfinished})
            if not unfinished:
                successful = all(x.get("state") == "completed" for x in guard["lanes"].values())
                guard.update({"status": "completed" if successful else "ended_with_failure",
                              "finished_unix_time": time.time()})
                atomic_json(state_path, guard)
                return 0 if successful else 1
            atomic_json(state_path, guard)
            time.sleep(poll_seconds)
    except BaseException as error:
        guard.update({"status": "guard_error_no_training_retry",
                      "error": f"{type(error).__name__}: {error}",
                      "heartbeat_unix_time": time.time()})
        atomic_json(state_path, guard)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", type=Path, required=True)
    parser.add_argument("--poll-seconds", type=float, default=10)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    if not 2 <= args.poll_seconds <= 300:
        raise ValueError("Poll interval must be in [2, 300] seconds")
    return run(args.suite_dir.resolve(), args.poll_seconds, args.check_only)


if __name__ == "__main__":
    raise SystemExit(main())
