#!/usr/bin/env python3
"""Workers for one B0-private learner and its shared asynchronous validation pool."""
import argparse
import copy
import gc
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback
from datetime import timedelta

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import torch.distributed as dist

from onpolicy.runner.shared.stage3_b0_engine import B0Engine, HISTORY
from onpolicy.utils.stage3_b0_protocol import (
    verify, queue, baseline_costs, submit_split, submit_mechanism, validate_request, EVALUATION, B0_SHA, MECHANISM,
)
from onpolicy.utils.stage3_distributed import TrajectoryParallel, state_digest
from onpolicy.utils.stage3_full_data import schedule
from onpolicy.utils.stage3_full_policy import shard, trace_identity
from onpolicy.utils.stage3_numerics import training_state
from onpolicy.utils.stage3_ppo_transaction import cpu_copy
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_json, digest_file, paired_summary
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat, save_group, trajectory_record
from onpolicy.scripts.train.stage3_local_worker import frozen_state, assert_frozen, nested_close


def metadata(m, **extra):
    return {"protocol_sha256": m["manifest_sha256"], "execution_code_sha256": m["code"]["sha256"],
            "comparison_sha256": m["comparison_sha256"], "arm": "C_PRIVATE",
            "next_group": 0, "elite_buffer": {}, "elite_usage": {}, "auxiliary_steps": 0,
            "diagnostic_only": True, "training_episodes": 0, **extra}


def engine(m, variant, width, *, tau=None, cache=True):
    if tau is None:
        admission = Path(m["root"]) / "sampling_admission.json"
        tau = read_json(admission)["selected_tau"] if admission.exists() else .03
    start_method = m.get('throughput', {}).get('environment_start_method', 'spawn') if cache else 'spawn'
    runner = B0Engine(m["source"]["manifest"], variant, width=width, tau=tau,
                     actor_lr=m["training"]["actor_lr"], cache_mib=1024 if cache else 0,
                     create_environments=start_method == 'spawn')
    runner.environment_start_method = start_method
    runner.stochastic_batching = (m.get('throughput', {}).get('stochastic_batching', 'per_case_v1')
                                 if cache else 'per_case_v1')
    if start_method != 'spawn':
        from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool
        runner.pool = EnvironmentPool(width, start_method=start_method)
    runner.release_environments_after_rollout = m.get('throughput', {}).get('release_environments_after_rollout', False)
    return runner


def evaluate(runner, cases, hb, *, retain=False):
    rows = []
    for first in range(0, len(cases), runner.width):
        batch = cases[first:first + runner.width]
        group = runner.rollout(batch, [1] * len(batch), deterministic=True, retain=retain, heartbeat=hb)
        rows.extend(group if retain else [trajectory_record(t) for t in group])
        hb.update(event="native_hungarian_evaluation", completed_cases=len(rows), total_cases=len(cases))
    return rows


def collect(runner, batch, hb):
    if getattr(runner, 'release_environments_after_rollout', False) and runner.pool is None:
        from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool
        method = getattr(runner, 'environment_start_method', 'spawn')
        runner.pool = (EnvironmentPool(runner.width) if method == 'spawn'
                       else EnvironmentPool(runner.width, start_method=method))
    result = []
    for first in range(0, len(batch["cases"]), runner.width):
        if hb:
            hb.update(event='rollout_wave_start', rollout_wave=first//runner.width+1,
                rollout_waves=(len(batch['cases'])+runner.width-1)//runner.width,
                rollout_trajectories_collected=len(result), rollout_trajectories_target=len(batch['cases']))
        result.extend(runner.rollout(batch["cases"][first:first + runner.width],
            batch["seeds"][first:first + runner.width], retain=True, heartbeat=hb))
        if hb:
            hb.update(event='rollout_wave_completed', rollout_trajectories_collected=len(result))
    if getattr(runner, 'release_environments_after_rollout', False):
        runner.pool.close()
        runner.pool = None
        gc.collect()
        if hb:
            hb.update(event='rollout_complete_environment_pool_released', rollout_trajectories_collected=len(result))
    return result


def attach_journal(runner, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    def write(row):
        with path.open("a") as handle:
            handle.write(json.dumps({"unix": time.time(), **row}, allow_nan=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
    runner.update_metrics_sink = write


def initialization(args, m, sync, hb):
    cases = m["diagnostic"]["cases32"][args.rank::args.world_size]
    rows = {}
    for variant in ("NATIVE", "F_PRIVATE"):
        runner = engine(m, variant, min(4, len(cases)))
        try:
            rows[variant] = evaluate(runner, cases, hb)
            if variant == "F_PRIVATE" and args.rank == 0:
                checkpoint = args.output / "private_init.pt"
                runner.save(checkpoint, **metadata(m, diagnostic_only=False, initialization_only=True))
                atomic_json(args.output / "initialization.json", {
                    "checkpoint": str(checkpoint), "checkpoint_sha256": digest_file(checkpoint),
                    "handoff": runner.handoff_report, "representation": runner.representation_report,
                    "optimizer_groups": [{k: g[k] for k in ("name", "lr", "lr_scale")}
                                         for g in runner.policy.actor_optimizer.param_groups]}, overwrite=False)
        finally:
            runner.close()
            del runner
            gc.collect()
            torch.cuda.empty_cache()
    errors = [a["case_id"] for a, b in zip(rows["NATIVE"], rows["F_PRIVATE"])
              if a["action_sha256"] != b["action_sha256"] or abs(a["makespan"] - b["makespan"]) > 1e-6]
    result = {"passed": not errors, "mismatched_cases": errors, "cases": rows,
              "zero_rl_updates": True, "source_sha256": B0_SHA}
    atomic_json(args.output / "result.json", result, overwrite=False)
    if errors:
        raise RuntimeError("Private initialization changed complete B0 trajectories")


def sampling(args, m, sync, hb):
    cases = m["diagnostic"]["cases32"][args.rank::args.world_size]
    results = {}
    for tau in m["training"]["temperature_candidates"]:
        runner = engine(m, "NATIVE", min(4, len(cases)), tau=tau)
        records, statistics = [], []
        try:
            for replica in range(4):
                seeds = [int(digest_json([2026091201, "b0-temperature", c["content_sha256"], replica])[:15], 16)
                         % (2**31 - 1) for c in cases]
                group = runner.rollout(cases, seeds, likelihood_audit=True, heartbeat=hb)
                save_group(args.output / f"tau{tau}_r{replica}.json", group,
                           {"diagnostic_only": True, "temperature": tau, "used_for_gradient": False})
                records.extend(trajectory_record(t) for t in group)
                statistics.append(copy.deepcopy(runner.last_decision_stats))
                del group
            results[str(tau)] = {"cases": records, "decision_stats": statistics}
        finally:
            runner.close()
    atomic_json(args.output / "result.json", {"passed": True, "temperatures": results,
                "training_data_only": True, "actor_updates": 0}, overwrite=False)


def diagnostic_batch(m, count, dense_case=None):
    cases = m["diagnostic"]["canary_cases"]
    if dense_case:
        cases = [next(c for c in m["splits"]["train_full600"] if c["path"] == dense_case)]
    pairs = [(c, r) for c in cases for r in range(count // len(cases))]
    if len(pairs) != count:
        raise ValueError("Unbalanced diagnostic batch")
    return {"cases": [c for c, r in pairs], "seeds": [
        int(digest_json([2026091201, "b0-full-canary", c["content_sha256"], r])[:15], 16) % (2**31 - 1)
        for c, r in pairs]}


def canary(args, m, sync, hb):
    batch = diagnostic_batch(m, args.batch_size, args.dense_case)
    from onpolicy.utils.stage3_b0_acceleration import canary_costs
    costs = canary_costs(m, batch["cases"])
    local = shard(batch, args.rank, args.world_size)
    runner = engine(m, "F_PRIVATE", min(len(local["cases"]), m['throughput']['rollout_envs_per_rank'])
                    if m.get("throughput") else min(8, len(local["cases"])))
    attach_journal(runner, args.output / "ppo_attempts.jsonl")
    live_workers = sum(p.is_alive() for p in runner.pool.processes)
    hb.update(event='environment_pool_created', rollout_envs_per_rank=runner.width,
              live_environment_workers=live_workers,
              environment_start_method=runner.environment_start_method)
    try:
        if m.get("throughput"):
            from onpolicy.utils.stage3_b0_throughput import restore_parent
            restore_parent(runner, m, args.rank)
        sync.assert_replicas(runner)
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        begin = time.time()
        group = collect(runner, local, hb)
        torch.cuda.synchronize()
        rollout_seconds = time.time() - begin
        rollout_memory = {'peak_allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                          'peak_reserved_gib': torch.cuda.max_memory_reserved()/2**30}
        rollout_inference = dict(runner.last_rollout_inference)
        save_group(args.output / "rollout.json", group, metadata(m, rank=args.rank))
        records = [r for rows in sync.gather([trajectory_record(t) for t in group]) for r in rows]
        replay = runner.replay_metrics(group, hb, distributed=sync)
        atomic_json(args.output / "replay.json", replay, overwrite=False)
        if replay["max_logp_error"] > .002:
            raise RuntimeError("B0 autoregressive likelihood replay mismatch")
        start = args.output / "resume_start.pt"
        runner.save(start, **metadata(m))
        before = state_digest(training_state(runner))
        frozen = frozen_state(runner)
        begin = time.time()
        torch.cuda.reset_peak_memory_stats()
        update = runner.update(group, "source", costs, distributed=sync, heartbeat=hb,
            microbatch_size=m.get('throughput', {}).get('backward_trajectories_per_rank'),
            optimizer_step_per_microbatch=m.get('throughput', {}).get('optimizer_step_per_microbatch', False))
        update_seconds = time.time() - begin
        update_memory = {'peak_allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                         'peak_reserved_gib': torch.cuda.max_memory_reserved()/2**30}
        atomic_json(args.output / "update.json", update, overwrite=False)
        assert_frozen(runner, frozen)
        after_digest = sync.assert_replicas(runner)
        after = args.output / "after_update.pt"
        runner.save(after, **metadata(m, training_episodes=args.batch_size))
        accepted = update["accepted_actor_steps"] > 0
        resume = None
        if args.phase == "reference":
            expected = cpu_copy(training_state(runner))
            exploration = copy.deepcopy(runner.exploration)
            runner.resume(start, protocol_sha256=m["manifest_sha256"], exploration=exploration)
            restored = state_digest(training_state(runner)) == before
            fast_cache = runner.execution_cache
            # Leave the cache installed but inactive: the entire original path
            # is used for the repeated update and compared with the fast path.
            runner.execution_cache = None
            runner.update(group, "source", costs, distributed=sync, heartbeat=hb,
                microbatch_size=m.get('throughput', {}).get('backward_trajectories_per_rank'),
                optimizer_step_per_microbatch=m.get('throughput', {}).get('optimizer_step_per_microbatch', False))
            runner.execution_cache = fast_cache
            resume = {"restored_exact": restored, "next_update_close": nested_close(
                      expected, cpu_copy(training_state(runner)))}
            atomic_json(args.output / "resume_comparison.json", resume, overwrite=False)
            accepted = accepted and all(resume.values())
        result = {"passed": accepted, "diagnostic_only": True, "forbidden_as_rl_initialization": True,
            'rollout_envs_per_rank': runner.width, 'live_environment_workers_at_start': live_workers,
            'environment_start_method': runner.environment_start_method,
            'rollout_waves': (len(local['cases'])+runner.width-1)//runner.width,
            'rollout_inference': rollout_inference, 'rollout_memory': rollout_memory,
            'update_memory': update_memory,
            "source_sha256": B0_SHA, "batch_size": args.batch_size, "world_size": args.world_size,
            "trace_identity": trace_identity(records), "records": records,
            "replay": replay, "update": update, "resume": resume,
            "rollout_seconds": rollout_seconds, "update_seconds": update_seconds,
            "batch_seconds": rollout_seconds + update_seconds,
            "peak_reserved_gib": torch.cuda.max_memory_reserved() / 2**30,
            "after_update_checkpoint": str(after), "replica_sha256": after_digest}
        atomic_json(args.output / "result.json", result, overwrite=False)
        if not accepted:
            raise RuntimeError("B0 technical canary failed; full metrics retained")
    finally:
        runner.close()


def validator(args, m, hb):
    jobs = queue(m)
    runner, representation = None, None
    try:
        while True:
            # Retire only at request boundaries, never discard an in-flight evaluation.
            if (args.output / "DRAIN").exists():
                hb.update(event="validator_drained", request_id=None, request_started_unix=None)
                return
            claim = jobs.claim()
            if claim is None:
                hb.update(event="validator_idle", request_id=None, request_started_unix=None)
                if (jobs.root / "STOP").exists():
                    return
                time.sleep(2)
                continue
            path, request = claim
            try:
                validate_request(m, request)
                variant = request["representation"]
                if runner is None or variant != representation:
                    if runner is not None:
                        runner.close()
                        del runner
                        gc.collect()
                        torch.cuda.empty_cache()
                    runner = engine(m, variant, m["resources"]["validator_width"], cache=False)
                    representation = variant
                if not request["native"]:
                    payload = torch.load(request["checkpoint"], map_location="cpu", weights_only=False)
                    if (payload.get("diagnostic_only") or payload.get("protocol_sha256") != request["protocol_sha256"]
                            or payload.get("training_episodes") != request["training_episodes"]
                            or payload.get("arm") != request["arm"]
                            or payload.get("comparison_sha256") != m["comparison_sha256"]
                            or payload.get("execution_code_sha256") != m["code"]["sha256"]):
                        raise ValueError("Diagnostic or mismatched checkpoint cannot enter main validation")
                    if request["training_episodes"]:
                        tau = read_json(Path(m["root"]) / "sampling_admission.json")["selected_tau"]
                        if payload.get("exploration") != {"roles": [0, 1, 2], "taus": [tau] * 3}:
                            raise ValueError("Training routes used different sampling temperatures")
                    elif not payload.get("initialization_only") or payload.get("policy_updates") != 0:
                        raise ValueError("Zero-episode validation requires a zero-update initialization")
                    del payload
                    runner.load(request["checkpoint"])
                hb.update(event="validation", request_id=request["request_id"], request_started_unix=time.time(),
                          completed_cases=0, total_cases=len(request["cases"]))
                if request["kind"] == "mechanism":
                    from onpolicy.utils.stage3_b0_diagnostics import measure
                    jobs.finish(path, measure(runner, m, request, hb))
                else:
                    rows = evaluate(runner, request["cases"], hb)
                    result = {"cases": rows, "evaluation_protocol": EVALUATION, "source_sha256": B0_SHA}
                    if request.get("raw_initialization"):
                        result["paired_summary_pending"] = True
                    else:
                        costs = ({r["case_id"]: r["makespan"] for r in rows} if request["native"] else
                                 baseline_costs(m, confirmation=request["split"] == "confirmation"))
                        result["summary"] = paired_summary(rows, costs)
                    jobs.finish(path, result)
                hb.update(event="validation_complete", request_id=None, request_started_unix=None)
            except BaseException:
                jobs.finish(path, None, traceback.format_exc())
                raise
    finally:
        if runner is not None:
            runner.close()


def train(args, m, sync, hb):
    if m.get("throughput"):
        from onpolicy.scripts.train.stage3_b0_large_batch_worker import train as train_large_batch
        return train_large_batch(args, m, sync, hb)
    root = Path(m["root"])
    admission = read_json(root / "training_admission.json")
    if (not admission["passed"] or admission["protocol_sha256"] != m["manifest_sha256"]
            or admission["world_size"] != args.world_size or args.until != 7680
            or admission["baseline_sha256"] != digest_file(root / "baselines.json")
            or admission["sampling_sha256"] != digest_file(root / "sampling_admission.json")):
        raise ValueError("Source-matched training admission required")
    if m.get("baseline_reference"):
        if admission.get("local_pairing_sha256") != digest_file(root / "local_pairing_admission.json"):
            raise ValueError("Strict local pairing must be bound to training admission")
        baseline_costs(m)  # No model/GPU allocation before the full 780/212 evidence is checked.
    plan = schedule(m["splits"]["train_full600"], m["training"]["seed"])
    schedule_sha, recipe_sha = digest_json(plan), digest_file(root / "training_admission.json")
    runner = engine(m, "F_PRIVATE", 32 // args.world_size)
    cursor = 0
    try:
        if args.resume_commit:
            commit = read_json(args.resume_commit)
            if (commit["world_size"] != args.world_size or commit["schedule_sha256"] != schedule_sha
                    or commit["recipe_sha256"] != recipe_sha):
                raise ValueError("Resume global commit differs")
            entry = commit["ranks"][args.rank]
            if digest_file(entry["checkpoint"]) != entry["sha256"]:
                raise ValueError("Committed rank checkpoint changed")
            payload = runner.resume(entry["checkpoint"], protocol_sha256=m["manifest_sha256"],
                                    exploration=runner.exploration)
            if payload.get("diagnostic_only") or payload["rank"] != args.rank:
                raise ValueError("Cannot resume diagnostic/other-rank weights")
            cursor = payload["next_group"]
            if payload["training_episodes"] != cursor * 32 or commit["training_episodes"] != cursor * 32:
                raise ValueError("Resume cursor differs")
        sync.assert_replicas(runner)
        costs, frozen = baseline_costs(m), frozen_state(runner)
        for index in range(cursor, len(plan)):
            sync.barrier()
            while queue(m).pending_count("C_PRIVATE") >= 24:
                hb.update(event="shared_validator_backpressure", next_group=index)
                time.sleep(5)
            batch = plan[index]
            hb.update(event="batch_start", training_episodes=index * 32, global_batch=index + 1,
                      data_epoch=batch["data_epoch"], actual_actor_updates=runner.policy_updates)
            begin = time.time()
            group = collect(runner, shard(batch, args.rank, args.world_size), hb)
            rollout_seconds = time.time() - begin
            save_group(args.output / f"rollouts/group_{index+1:04d}.json", group,
                metadata(m, diagnostic_only=False, rank=args.rank, visit_ids=batch["visit_ids"]))
            attach_journal(runner, args.output / f"updates/group_{index+1:04d}_attempts.jsonl")
            begin = time.time()
            update = runner.update(group, "source", costs, distributed=sync, heartbeat=hb)
            update_seconds = time.time() - begin
            atomic_json(args.output / f"updates/group_{index+1:04d}.json", update, overwrite=False)
            assert_frozen(runner, frozen)
            sync.assert_replicas(runner)
            episodes = (index + 1) * 32
            checkpoint = args.output / f"models/episodes_{episodes:06d}.pt"
            checksum = runner.save(checkpoint, **metadata(m, diagnostic_only=False,
                training_episodes=episodes, next_group=index+1, rank=args.rank, world_size=args.world_size,
                schedule_sha256=schedule_sha, recipe_sha256=recipe_sha))
            entries = sync.gather({"rank": args.rank, "checkpoint": str(checkpoint), "sha256": checksum})
            if args.rank == 0:
                commit_path = root / f"train/commits/episodes_{episodes:06d}.json"
                atomic_json(commit_path, {"ranks": entries, "world_size": args.world_size,
                    "schedule_sha256": schedule_sha, "recipe_sha256": recipe_sha,
                    "training_episodes": episodes, "actual_actor_updates": runner.policy_updates,
                    "protocol_sha256": m["manifest_sha256"]}, overwrite=False)
                if episodes % 960 == 0:
                    requests = [r for split in ("validation", "tune") for r in submit_split(m, checkpoint,
                        "C_PRIVATE", episodes, "F_PRIVATE", split=split, training_exploration=runner.exploration)]
                    atomic_json(root / f"epochs/e{episodes:06d}.json", {"requests": requests,
                        "checkpoint": str(checkpoint), "checkpoint_sha256": checksum,
                        "training_episodes": episodes, "actual_actor_updates": runner.policy_updates}, overwrite=False)
                    if episodes // 960 in MECHANISM["data_epochs"]:
                        diagnostic = submit_mechanism(m, checkpoint, episodes)
                        atomic_json(root / f"mechanism/e{episodes:06d}.json", {"requests": diagnostic,
                            "checkpoint_sha256": checksum, "training_episodes": episodes}, overwrite=False)
            hb.update(event="batch_committed", training_episodes=episodes,
                actual_actor_updates=runner.policy_updates, rollout_seconds=rollout_seconds,
                update_seconds=update_seconds, batch_seconds=rollout_seconds+update_seconds)
            del group
            gc.collect()
            if runner.zero_update_batches >= 3:
                raise RuntimeError("Three zero-update batches; committed state retained for diagnosis")
        atomic_json(args.output / "result.json", {"completed": True, "training_episodes": 7680,
                    "actual_actor_updates": runner.policy_updates}, overwrite=False)
    finally:
        runner.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--phase", choices=("initialization", "sampling", "reference", "contract", "capacity", "train", "validator"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--arm", default="C_PRIVATE")
    parser.add_argument("--rank", type=int, default=0)
    parser.add_argument("--world-size", type=int, default=1)
    parser.add_argument("--init-file", type=Path)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--until", type=int, default=7680)
    parser.add_argument("--dense-case")
    parser.add_argument("--resume-commit", type=Path)
    args = parser.parse_args()
    m = read_json(args.manifest)
    verify(m, inputs=False)
    args.output.mkdir(parents=True, exist_ok=True)
    signal.signal(signal.SIGTERM, lambda s, f: (_ for _ in ()).throw(KeyboardInterrupt("SIGTERM")))
    with ProgressHeartbeat(args.output / "status.json", phase=args.phase, rank=args.rank) as hb:
        try:
            if args.world_size > 1 and args.phase not in ("initialization", "sampling"):
                dist.init_process_group("gloo", init_method="file://" + str(args.init_file.resolve()),
                    rank=args.rank, world_size=args.world_size, timeout=timedelta(hours=3))
            sync = TrajectoryParallel(device_packed=True)
            if args.phase == "validator":
                validator(args, m, hb)
            elif args.phase == "initialization":
                initialization(args, m, sync, hb)
            elif args.phase == "sampling":
                sampling(args, m, sync, hb)
            elif args.phase == "train":
                train(args, m, sync, hb)
            else:
                canary(args, m, sync, hb)
        except BaseException:
            atomic_json(args.output / "failure.json", {"error": traceback.format_exc(),
                "phase": args.phase, "rank": args.rank, "all_artifacts_retained": True})
            raise
        finally:
            if dist.is_initialized():
                dist.destroy_process_group()


if __name__ == "__main__":
    main()
