#!/usr/bin/env python3
"""CPU-only, source-bound regression receipt for a staged ENV60 transition."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan',type=Path,required=True)
    args = parser.parse_args()
    from onpolicy.utils.stage3_research import read_json, atomic_json, digest_file, digest_json, WORKSPACE_ROOT
    plan = read_json(args.plan)
    output = Path(plan['staging_root'])/'verification'
    if output.exists():
        raise FileExistsError('Keep each verification attempt separate')
    output.mkdir()
    if Path(plan['staging_root'])/'source' != ROOT:
        raise ValueError('Run verification from the staged source')
    for name,checksum in plan['files'].items():
        if digest_file(ROOT/name) != checksum:
            raise ValueError('Staged source changed before verification')
    import pytest
    os.chdir(WORKSPACE_ROOT)
    names = ('b0_env60','b0_batched_sampling','b0_env48','b0_env24','b0_minibatches','b0_microbatch',
        'b0_throughput','b0','b0_recalibration','b0_acceleration','b0_reproduction',
        'full_data','full_policy','numerics','performance','representation')
    result = pytest.main(['-q','--import-mode=importlib',
        *[str(ROOT/f'onpolicy/envs/HKBZ/test/test_stage3_{name}.py') for name in names],
        '-k','not gpu and not native_complete','--disable-warnings',
        '--junitxml='+str(output/'cpu.xml')])
    modules = {name:str(Path(module.__file__).resolve()) for name,module in sys.modules.items()
        if name.startswith('onpolicy.') and getattr(module,'__file__',None)}
    outside = {name:path for name,path in modules.items() if not Path(path).is_relative_to(ROOT)}
    atomic_json(output/'imports.json',{'passed':not outside,'modules':modules,'outside':outside,
        'source_root':str(ROOT),'pytest_exit_code':result},overwrite=False)
    if result or outside:
        raise RuntimeError('Frozen CPU regressions/import audit failed; do not arm transition')
    for method in ('spawn','forkserver'):
        subprocess.run([sys.executable,'-B',str(ROOT/'onpolicy/scripts/train/probe_stage3_b0_env_pool.py'),
            '--width','60','--batched-inference','--start-method',method,
            '--output',str(output/f'env_pool/{method}.json')],check=True,cwd=WORKSPACE_ROOT,
            env={**os.environ,'CUDA_VISIBLE_DEVICES':''},timeout=240)
    from onpolicy.scripts.train.stage3_b0_large_batch import env24_probe_evidence
    env24_probe_evidence(output/'env_pool',plan['files'],width=60)
    reports = {str(p):digest_file(p) for p in (output/'cpu.xml', output/'imports.json',
        output/'env_pool/spawn.json',output/'env_pool/forkserver.json')}
    atomic_json(output/'receipt.json',{'passed':True,'source_files_sha256':digest_json(plan['files']),
        'reports':reports,'diagnostic_only':True,'no_gpu_used':True,
        'full_all_gpu_capacity_admission_still_required':True},overwrite=False)
    print(output/'receipt.json',flush=True)


if __name__ == '__main__':
    main()
