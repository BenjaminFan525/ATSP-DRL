#!/usr/bin/env python3
"""Prepare the Stage2 role-credit Wave-A causal screen.

All six arms start from the same immutable matched-IGA DeviceBC checkpoint and
keep the Stage1 actor, shared encoder, device head, planning semantics, data
order, seed, and optimizer settings fixed.  The screen isolates four training
questions: role TD(lambda), fitted-potential composition, audited critical-path
return redistribution, and the existing action-masked counterfactual critic.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.config.config import get_config  # noqa: E402
from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv  # noqa: E402
from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    atomic_json,
    sha256_file,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.scripts.train.train_hkbz import (  # noqa: E402
    parse_args as parse_training_args,
    select_train_case_dirs,
)


RUN_TAG = 'stage2_event_credit_wave_20260829_r2'
METHODS = {
    'A0_mc_control': {
        'role_td_lambda': False,
        'potential_v2': False,
        'critical_path_credit': False,
        'counterfactual_critic': False,
        'hypothesis': 'role-clock Monte-Carlo control',
    },
    'A1_mc_potential_v2': {
        'role_td_lambda': False,
        'potential_v2': True,
        'critical_path_credit': False,
        'counterfactual_critic': False,
        'hypothesis': 'Potential V2 composes with role clocks after branch fix',
    },
    'A2_role_td_lambda': {
        'role_td_lambda': True,
        'potential_v2': False,
        'critical_path_credit': False,
        'counterfactual_critic': False,
        'hypothesis': 'same-role TD(lambda) lowers long-horizon critic variance',
    },
    'A3_event_redistribution': {
        'role_td_lambda': True,
        'potential_v2': False,
        'critical_path_credit': True,
        'counterfactual_critic': False,
        'hypothesis': 'return-conserving critical-path credit improves action timing',
    },
    'A4_counterfactual_critic': {
        'role_td_lambda': True,
        'potential_v2': False,
        'critical_path_credit': False,
        'counterfactual_critic': True,
        'hypothesis': 'legal-action Q expectation reduces multi-agent baseline noise',
    },
    'A5_event_cf': {
        'role_td_lambda': True,
        'potential_v2': False,
        'critical_path_credit': True,
        'counterfactual_critic': True,
        'hypothesis': 'event credit and counterfactual baselines are complementary',
    },
}


def load_json(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError(f'Expected a JSON object: {path}')
    return payload


def code_contract() -> dict:
    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True
    ).strip()
    status = subprocess.check_output(
        ['git', 'status', '--short'], cwd=ROOT, text=True
    ).splitlines()
    paths = (
        'onpolicy/config/config.py',
        'onpolicy/envs/HKBZ/environment.py',
        'onpolicy/utils/shared_buffer.py',
        'onpolicy/runner/shared/hkbz_runner.py',
        'onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py',
        'onpolicy/algorithms/gnn_mappo/gnn_mappo.py',
        'onpolicy/scripts/train/prepare_stage2_event_credit_wave.py',
        'onpolicy/scripts/train/launch_stage2_event_credit_wave_dual_gpu.sh',
        'onpolicy/scripts/train/stage2_event_credit_autopilot.py',
        'onpolicy/scripts/train/evaluate_stage1_shared_checkpoint.py',
    )
    return {
        'git_revision': revision,
        'working_tree_dirty': bool(status),
        'working_tree_status': status,
        'files_sha256': {
            path: sha256_file(ROOT / path)
            for path in paths if (ROOT / path).is_file()
        },
    }


def data_contract(dataset_dir: Path) -> dict:
    cases = sorted(str(path) for path in dataset_dir.glob('case_*'))
    selected, audit = select_train_case_dirs(
        cases,
        mode='distribution_balanced',
        weights_spec='iid=0.50,ood_stress=0.45,ood_scale=0.05',
        seed=1,
        max_cases=0,
        sample_size=600,
    )
    if len(selected) != 600:
        raise RuntimeError('Wave A requires the immutable rotating 600-slot pool.')
    return {
        **audit,
        'pool_size': 600,
        'cases_per_epoch': 240,
        'screen_epochs': 2,
        'pool_order_sha256': hashlib.sha256(
            '\n'.join(Path(path).name for path in selected).encode('utf-8')
        ).hexdigest(),
    }


def apply_common(command: list[str], *, args, method_id: str) -> None:
    command[0] = str(args.python)
    set_option(
        command, '--experiment_name',
        f'{args.run_tag}_waveA_{method_id}_seed1',
    )
    set_option(command, '--seed', 1)
    set_option(command, '--cuda_memory_fraction', 0.30)
    set_option(command, '--num_episodes', 2)
    set_option(command, '--gnn_freeze_epochs', 2)
    set_option(command, '--plane_freeze_epochs', 2)
    set_option(command, '--n_rollout_threads', 30)
    set_option(command, '--n_eval_rollout_threads', 12)
    set_option(command, '--max_train_cases', 0)
    set_option(command, '--train_sampling_size', 240)
    set_option(command, '--train_sampling_pool_size', 600)
    set_option(command, '--max_eval_cases', 60)
    set_option(command, '--ppo_epoch', 1)
    set_option(command, '--mini_batch_size', 30)
    set_option(command, '--data_chunk_length', 50)
    set_option(command, '--max_graphs_per_forward', 1500)
    set_option(command, '--grad_accumulation_steps', 3)
    set_option(command, '--actor_grad_accumulation_steps', 2)
    set_option(command, '--grad_accumulation_target_graphs', 5000)
    set_option(command, '--actor_grad_accumulation_target_graphs', 2000)
    set_option(command, '--actor_warmup_shards', 0)
    set_option(command, '--adaptive_actor_lr_max_scale', 1.0)
    set_option(command, '--target_kl', 0.003)
    set_option(command, '--plane_target_kl', 0.003)
    set_option(command, '--device_target_kl', 0.003)
    set_option(command, '--transporter_target_kl', 0.003)
    set_option(command, '--plane_loss_coef', 0.0)
    set_option(command, '--device_loss_coef', 0.5)
    set_option(command, '--transporter_loss_coef', 0.5)
    set_option(command, '--device_policy_head_mode', 'shared')
    set_option(command, '--device_bc_pretrain_epochs', 0)
    set_option(command, '--hindsight_cmax_coef', 0.0)
    set_option(command, '--hindsight_shaping_coef', 0.0)
    set_option(command, '--hindsight_terminal_cmax_coef', 1.0)
    set_option(command, '--resource_lateness_coef', 0.0)
    set_option(command, '--resource_critical_lateness_coef', 0.0)
    set_option(command, '--resource_earliness_coef', 0.0)
    set_option(command, '--resource_wait_constraint_target', 0.0)
    set_option(command, '--resource_wait_dual_lr', 0.0)
    set_option(command, '--early_stop_patience', 0)
    set_option(command, '--recovery_checkpoint_interval_shards', 1)
    set_option(command, '--bc_reference_kl_coef', 0.0)
    set_option(command, '--bc_reference_kl_coef_schedule', '0.0')
    set_option(command, '--bc_reference_target_kl', 0.0)
    set_switch(command, '--bc_reference_hard_gate', False)
    set_switch(command, '--device_bc_only', False)
    set_switch(command, '--joint_team_ppo', True)
    set_option(command, '--joint_team_ppo_scope', 'all')
    set_switch(command, '--role_atomic_ppo', True)
    set_switch(command, '--role_event_returns', True)
    set_switch(command, '--role_valuenorm', True)
    set_switch(command, '--role_sequential_ppo', False)
    set_option(command, '--role_loss_weighting', 'fixed')
    set_switch(command, '--use_eval', True)
    set_switch(command, '--rollout_until_done', True)
    set_switch(command, '--safe_graph_batch_pipeline', True)
    set_switch(command, '--safe_dagger_teacher_overlap', True)
    set_switch(command, '--clear_cuda_cache_after_update', False)


def build_command(base: list[str], method_id: str, method: dict, *, args) -> list[str]:
    command = list(base)
    apply_common(command, args=args, method_id=method_id)

    if method['role_td_lambda']:
        set_option(command, '--role_event_gae_lambda', 1.0)
        set_option(command, '--plane_role_gae_lambda', 1.0)
        set_option(command, '--device_role_gae_lambda', 0.90)
        set_option(command, '--transporter_role_gae_lambda', 0.95)
    else:
        set_option(command, '--role_event_gae_lambda', 1.0)
        set_option(command, '--plane_role_gae_lambda', 1.0)
        set_option(command, '--device_role_gae_lambda', 1.0)
        set_option(command, '--transporter_role_gae_lambda', 1.0)

    set_option(
        command,
        '--role_event_credit_mode',
        'critical_path' if method['critical_path_credit'] else 'elapsed',
    )
    set_option(command, '--role_event_credit_uniform_mix', 0.15)
    set_switch(
        command,
        '--counterfactual_q_baseline',
        method['counterfactual_critic'],
    )
    set_option(command, '--counterfactual_q_topk', 8)
    set_option(command, '--counterfactual_q_min_mass', 0.90)

    if method['potential_v2']:
        set_option(
            command, '--hindsight_reward_mode',
            'team_time_resource_fitted_potential',
        )
        set_option(command, '--iga_potential_weights_path', args.potential)
        set_option(command, '--iga_potential_beta', 0.10)
        set_option(command, '--iga_potential_beta_schedule', '0.10')
    else:
        set_option(command, '--hindsight_reward_mode', 'team_time')
        set_option(command, '--iga_potential_beta', 0.0)
        set_option(command, '--iga_potential_beta_schedule', '0.0')
        remove_option(command, '--iga_potential_weights_path')
    return command


def canary_command(command: list[str]) -> list[str]:
    result = list(command)
    name_idx = result.index('--experiment_name') + 1
    result[name_idx] = f'{result[name_idx]}_canary'
    set_option(result, '--num_episodes', 1)
    set_option(result, '--gnn_freeze_epochs', 1)
    set_option(result, '--plane_freeze_epochs', 1)
    set_option(result, '--max_train_cases', 30)
    set_option(result, '--train_sampling_size', 30)
    remove_option(result, '--train_sampling_pool_size')
    set_option(result, '--max_eval_cases', 12)
    set_switch(result, '--skip_pre_ppo_eval', True)
    set_switch(result, '--skip_epoch_eval', True)
    return result


def validate(command: list[str], *, canary: bool) -> None:
    parsed = parse_training_args(command[2:], get_config())
    if parsed.training_stage != 'resource_joint':
        raise RuntimeError('Wave A command is not Stage2 resource_joint.')
    if int(parsed.max_graphs_per_forward) != 1500:
        raise RuntimeError('Wave A graph cap drifted from 1500.')
    if int(parsed.train_sampling_size) != (30 if canary else 240):
        raise RuntimeError('Wave A case budget drifted.')
    if not canary and int(parsed.train_sampling_pool_size) != 600:
        raise RuntimeError('Wave A rotating pool is not active.')
    if not parsed.role_event_returns or not parsed.role_atomic_ppo:
        raise RuntimeError('Wave A requires role-atomic role-event PPO.')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-tag', default=RUN_TAG)
    parser.add_argument('--suite-dir', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--source-method', default='M0_stable_control')
    parser.add_argument('--potential', type=Path, required=True)
    parser.add_argument('--dataset-dir', type=Path, required=True)
    parser.add_argument('--python', type=Path, required=True)
    parser.add_argument('--wave-output', type=Path, required=True)
    parser.add_argument('--canary-output', type=Path, required=True)
    args = parser.parse_args()
    args.python = args.python.resolve()
    args.potential = args.potential.resolve()
    for path in (
        args.source_manifest, args.potential, args.dataset_dir, args.python,
    ):
        if not path.resolve().exists():
            raise FileNotFoundError(path.resolve())

    potential = load_json(args.potential)
    if potential.get('status') != 'calibrated':
        raise RuntimeError('Resource Potential V2 is not calibrated.')
    if (
        potential.get('potential_schema_version')
        != AircraftScheduleEnv.RESOURCE_POTENTIAL_SCHEMA_VERSION
        or potential.get('environment_semantics_version')
        != AircraftScheduleEnv.SEMANTICS_VERSION
    ):
        raise RuntimeError('Resource Potential V2 contract mismatch.')
    heldout_r2 = float(potential['calibration']['heldout_metrics']['r2'])
    if heldout_r2 < 0.75:
        raise RuntimeError(f'Resource Potential V2 heldout R2={heldout_r2}.')

    source = load_json(args.source_manifest.resolve())
    base = list(source['commands'][args.source_method]['argv'])
    commands = {}
    for method_id, method in METHODS.items():
        command = build_command(base, method_id, method, args=args)
        validate(command, canary=False)
        commands[method_id] = {
            **method,
            'family': 'role_credit_wave_a',
            'argv': command,
            'shell': shlex.join(command),
        }

    shared = {
        'schema_version': 1,
        'research_stage': 'stage2_resource_joint',
        'profile': 'role_credit_wave_a',
        'run_tag': args.run_tag,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'code_contract': code_contract(),
        'data_contract': data_contract(args.dataset_dir.resolve()),
        'source_manifest': {
            'path': str(args.source_manifest.resolve()),
            'sha256': sha256_file(args.source_manifest.resolve()),
            'method': args.source_method,
        },
        'resource_potential_v2': {
            'path': str(args.potential),
            'sha256': sha256_file(args.potential),
            'heldout_r2': heldout_r2,
        },
        'screen_gate': {
            'raw_cmax_improvement_seconds': 75.0,
            'matched_iga1800_gap_seconds_max': 100.0,
            'ood_stress_regression_seconds_max': 25.0,
            'completion_rate_min': 1.0,
            'actor_step_completion_min': 0.90,
            'cycle_count_max': 0,
        },
        'hardware_contract': {
            'gpus': [0, 1],
            'simultaneous_trainers_per_gpu': 3,
            'shared_evaluators_per_gpu': 1,
            'physical_core_isolation': True,
            'max_graphs_per_forward': 1500,
        },
        'automatic_followup_contract': {
            'wave_b': {
                'methods': 'top two Wave-A arms passing every gate',
                'epochs': 4,
                'seeds': [1],
                'evaluation_partition': 'gate[0:60]',
            },
            'formal': {
                'methods': 'best Wave-B arm passing every gate',
                'epochs': 8,
                'seeds': [1, 2, 3],
                'evaluation_partition': 'gate[60:120]',
            },
            'finalblind': {
                'evaluation_partition': 'finalblind[0:60]',
                'authorization': (
                    'all three Formal runs pass health/performance gates; '
                    'mean raw improvement >=75 seconds; at least two seeds '
                    'improve; mean OOD-stress regression <=25 seconds'
                ),
            },
        },
    }
    wave = {
        **shared,
        'phase': 'wave_a',
        'methods': METHODS,
        'evaluator_source_method': 'A0_mc_control',
        'evaluator_command': commands['A0_mc_control']['argv'],
        'commands': commands,
    }
    canary_entries = {}
    for source_key in (
        'A1_mc_potential_v2',
        'A3_event_redistribution',
        'A5_event_cf',
    ):
        key = f'C_{source_key}'
        command = canary_command(commands[source_key]['argv'])
        validate(command, canary=True)
        canary_entries[key] = {
            'source_method': source_key,
            'argv': command,
            'shell': shlex.join(command),
        }
    canary = {
        **shared,
        'phase': 'functional_memory_canary',
        'methods': canary_entries,
        'evaluator_source_method': next(iter(canary_entries)),
        'evaluator_command': next(iter(canary_entries.values()))['argv'],
        'commands': canary_entries,
    }
    atomic_json(args.wave_output.resolve(), wave)
    atomic_json(args.canary_output.resolve(), canary)
    print(json.dumps({
        'status': 'prepared',
        'wave_methods': list(commands),
        'canary_methods': list(canary_entries),
        'potential_heldout_r2': heldout_r2,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
