#!/usr/bin/env python3
"""Owned workers for the frozen-IGA bridge. No IGA solver entry point exists."""
import argparse
import copy
import gc
import json
import os
from pathlib import Path
import sys
import time
import traceback
from datetime import timedelta

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import torch.distributed as dist

from onpolicy.runner.shared.stage3_rl_bridge_engine import GroupB0Engine, NativeBridgeEngine
from onpolicy.runner.shared.stage3_b0_engine import B0Engine
from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool, seed_all
from onpolicy.utils.stage3_rl_bridge import (
    ARMS, LATENT, BridgeQueue, verify, queue, schedule, baseline_costs,
)
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json, paired_summary
from onpolicy.utils.stage3_distributed import TrajectoryParallel, state_digest
from onpolicy.utils.stage3_numerics import training_state
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat, save_group, trajectory_record
from onpolicy.scripts.train.stage3_b0_worker import attach_journal


def metadata(m, arm, **extra):
    return {'protocol_sha256': m['manifest_sha256'], 'execution_code_sha256': m['code']['sha256'],
        'arm': arm, 'next_group': 0, 'elite_buffer': {}, 'elite_usage': {}, 'auxiliary_steps': 0,
        'diagnostic_only': True, 'training_episodes': 0, **extra}


def make_engine(m, arm, width, *, create_environments=True):
    if arm == 'B0':
        runner = B0Engine(m['source']['manifest'], 'F_PRIVATE', width=width, device='cuda:0',
                         cache_mib=0, create_environments=False)
    elif m.get('schema') == 'stage3-tau-full600-v1':
        from onpolicy.runner.shared.stage3_tau_engine import TauEngine
        runner = TauEngine(m['source']['manifest'], 'F_PRIVATE', arm=arm, width=width,
            device='cuda:0', actor_lr=m['training']['actor_lr'], cache_mib=1024,
            replay_storage=m.get('replay_storage'), create_environments=False)
    elif ARMS[arm]['native']:
        return NativeBridgeEngine(m['source']['manifest'], arm=arm, width=width, device='cuda:0',
            actor_lr=m['training']['actor_lr'], create_environments=create_environments,
            start_method=m['throughput']['environment_start_method'])
    else:
        runner = GroupB0Engine(m['source']['manifest'], 'F_PRIVATE', arm=arm, width=width,
            device='cuda:0', tau=m['training']['sampling_tau'], actor_lr=m['training']['actor_lr'],
            cache_mib=1024, create_environments=False)
    runner.environment_start_method = m['throughput']['environment_start_method']
    runner.stochastic_batching = m['throughput']['stochastic_batching']
    runner.pool = EnvironmentPool(width, start_method=runner.environment_start_method) if create_environments else None
    return runner


def record(row):
    return trajectory_record({k: v for k, v in row.items() if k != 'latent_samples'})


def save_rollouts(path, rows, meta):
    if any('latent_samples' in r for r in rows):
        target = Path(path).with_suffix('.latent.npz')
        if target.exists():
            raise FileExistsError(target)
        payload = {}
        for i, row in enumerate(rows):
            for field in ('z', 'mean', 'old_logp', 'event', 'time'):
                payload[f'trajectory_{i}_{field}'] = np.asarray([s[field] for s in row.get('latent_samples', [])])
        temporary = target.with_suffix('.tmp.npz')
        target.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(temporary, **payload)
        with temporary.open('rb') as handle:
            os.fsync(handle.fileno())
        os.link(temporary, target)
        temporary.unlink()
        meta = {**meta, 'latent_trace': {'path': str(target), 'sha256': digest_file(target)}}
    save_group(path, [{k: v for k, v in r.items() if k != 'latent_samples'} for r in rows], meta)


def collect(runner, items, hb):
    result = []
    for start in range(0, len(items), runner.width):
        part = items[start:start+runner.width]
        rows = runner.rollout([x['case'] for x in part], [x['seed'] for x in part], retain=True, heartbeat=hb)
        for row, item in zip(rows, part):
            row.update(group_id=item['group_id'], replica=item['replica'], population_weight=item['weight'])
        result.extend(rows)
    return result


def submit_evaluation(m, checkpoint, arm, episodes, phase, *, split, kind='greedy', cases=None,
                      role_mix=None, chunk_size=6, sampling_eval_tau=None):
    cases = m['splits'][split] if cases is None else cases
    ids = []
    for first in range(0, len(cases), chunk_size):
        part = cases[first:first+chunk_size]
        request = {'request_id': f'{phase}_{arm}_{episodes:06d}_{kind}_{split}_{first:03d}',
            'checkpoint': str(checkpoint), 'checkpoint_sha256': digest_file(checkpoint),
            'arm': arm, 'training_episodes': episodes, 'phase': phase, 'kind': kind,
            'cases': part, 'cases_sha256': digest_json(part), 'contract_sha256': m['comparison_sha256'],
            'code_sha256': m['code']['sha256'], 'tau': .3, 'seed': 1,
            'latent': LATENT if arm in ARMS and ARMS[arm]['native'] else None,
            'role_mix': role_mix, 'manifest_sha256': m['manifest_sha256']}
        if kind == 'sampling':
            request['sample_seeds'] = [[int(digest_json([m['training']['seed'], 'diagnostic',
                c['content_sha256'], replica])[:15], 16) % (2**31-1) for c in part] for replica in range(4)]
        if m.get('schema') == 'stage3-tau-full600-v1':
            from onpolicy.utils.stage3_tau import TEMPERATURE
            if (kind == 'sampling') != (sampling_eval_tau in TEMPERATURE['diagnostic_taus']):
                raise ValueError('Sampling diagnostics need an explicit fixed evaluation temperature')
            request.update(sampling_eval_tau=sampling_eval_tau,
                decoder='autoregressive_sampling' if kind == 'sampling' else
                        ('autoregressive_greedy' if kind == 'greedy_ar' else 'b0_native_hungarian'))
            if sampling_eval_tau is not None:
                request['request_id'] += f'_tau{sampling_eval_tau:g}'
        ids.append(queue(m).submit(request))
    return ids


def canary(args, m, sync, hb):
    runner = make_engine(m, args.arm, m['throughput']['rollout_envs_per_rank'])
    output = args.output
    try:
        sync.assert_replicas(runner)
        local_cases = m['diagnostic']['cases32'][args.global_gpu::8]
        zero = runner.rollout(local_cases, [1]*len(local_cases), deterministic=True, heartbeat=hb)
        costs = baseline_costs(m)
        baseline_rows = read_json(Path(m['root'])/'baselines.json')['cases']
        by_case = {r['case_id']: r for r in baseline_rows}
        from onpolicy.scripts.train.run_stage3_sampling_audit import action_digest
        errors = [r['case_id'] for r in zero if abs(r['makespan']-costs[r['case_id']]) > 1e-6
            or action_digest(r['actions']) != by_case[r['case_id']]['action_sha256']
            or r['steps'] != by_case[r['case_id']]['steps']]
        atomic_json(output/'zero_update.json', {'passed': not errors, 'mismatches': errors,
            'cases': [record(r) for r in zero], 'actor_updates': runner.policy_updates}, overwrite=False)
        if errors:
            raise RuntimeError(f'Zero-update B0 trajectory mismatch: {errors}')
        del zero
        capacity_split = 'train_full600' if m.get('schema') == 'stage3-tau-full600-v1' else 'train_screen96'
        plan = schedule(m['splits'][capacity_split], seed=m['training']['seed'], epochs=1,
                        world_size=args.world_size, width=60, phase='capacity')
        items = plan[0]['shards'][args.rank]
        torch.cuda.reset_peak_memory_stats()
        begin = time.time()
        rows = collect(runner, items, hb)
        rollout_seconds = time.time()-begin
        rollout_memory = {'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                          'reserved_gib': torch.cuda.max_memory_reserved()/2**30}
        save_rollouts(output/'capacity_rollouts.json', rows, metadata(m, args.arm))
        # Full60 environment capacity, actual12-trajectory backward peak and exact
        # same-data update/resume parity. No prefix fixtures or diagnostic warm start.
        batch = rows[:12]
        capacity_trajectories = len(rows)
        # Summaries/actions are durable above. Do not retain the other 48 PPO
        # records throughout this 12-trajectory diagnostic update.
        del rows
        gc.collect()
        hb.update(event='capacity_pre_update_replay_start', capacity_phase='pre_update_replay',
            actual_actor_updates=runner.policy_updates, retained_trajectories=len(batch))
        before_replay = runner.replay_metrics(batch, hb, distributed=sync)
        if before_replay['max_logp_error'] > .002:
            raise RuntimeError(f'Initial likelihood replay error: {before_replay}')
        checkpoint = output/'before.pt'
        runner.save(checkpoint, **metadata(m, args.arm))
        attach_journal(runner, output/'update_attempts.jsonl')
        torch.cuda.reset_peak_memory_stats()
        hb.update(event='capacity_update_start', capacity_phase='update_resume_parity',
                  actual_actor_updates=runner.policy_updates)
        result = runner.update(batch, 'source', costs, epochs=1, chunk=8, heartbeat=hb,
            distributed=sync, microbatch_size=12, optimizer_step_per_microbatch=True)
        update_memory = {'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                         'reserved_gib': torch.cuda.max_memory_reserved()/2**30}
        after = state_digest(training_state(runner))
        runner.resume(checkpoint, protocol_sha256=m['manifest_sha256'], exploration=runner.exploration)
        repeated = runner.update(batch, 'source', costs, epochs=1, chunk=8, heartbeat=hb,
            distributed=sync, microbatch_size=12, optimizer_step_per_microbatch=True)
        if after != state_digest(training_state(runner)):
            raise RuntimeError('Exact committed checkpoint/update resume parity failed')
        sync.assert_replicas(runner)
        if result['accepted_actor_steps'] < 1 or repeated['accepted_actor_steps'] < 1:
            raise RuntimeError('Capacity canary executed no accepted PPO update')
        runner.resume(checkpoint, protocol_sha256=m['manifest_sha256'], exploration=runner.exploration)
        if args.rank == 0:
            init = output/'initial.pt'
            runner.save(init, **metadata(m, args.arm, diagnostic_only=False, initialization_only=True))
            requests = [r for split in ('validation', 'tune') for r in submit_evaluation(
                m, init, args.arm, 0, 'zero', split=split)]
            atomic_json(output/'initial_evaluations.json', {'checkpoint': str(init), 'requests': requests}, overwrite=False)
        atomic_json(output/'result.json', {'passed': True, 'zero_update_cases': len(local_cases),
            'replay': before_replay, 'actual_rollout_environments': runner.width,
            'capacity_trajectories': capacity_trajectories, 'backward_trajectories': len(batch),
            'replay_storage': runner.replay_storage_report() if hasattr(runner, 'replay_storage_report') else None,
            'rollout_seconds': rollout_seconds, 'rollout_memory': rollout_memory,
            'update_memory': update_memory, 'resume_exact': True,
            'update': result, 'diagnostic_weights_forbidden': True}, overwrite=False)
    finally:
        runner.close()


def train(args, m, sync, hb):
    root, output = Path(m['root']), args.output
    if not read_json(root/'training_admission.json')['passed']:
        raise ValueError('Technical admission has not passed')
    costs = baseline_costs(m)
    cases = m['splits']['train_screen96' if args.phase == 'screen' else 'train_full600']
    plan = schedule(cases, seed=m['training']['seed'], epochs=4,
                    world_size=args.world_size, width=60, phase=args.phase)
    runner = make_engine(m, args.arm, 60)
    cursor = 0
    try:
        if args.resume_commit:
            commit = read_json(args.resume_commit)
            if (commit['manifest_sha256'] != m['manifest_sha256'] or commit['arm'] != args.arm
                    or commit['phase'] != args.phase or commit['world_size'] != args.world_size
                    or commit['schedule_sha256'] != digest_json(plan)):
                raise ValueError('Committed resume topology/phase/arm differs')
            entry = commit['ranks'][args.rank]
            if entry['rank'] != args.rank or digest_file(entry['checkpoint']) != entry['sha256']:
                raise ValueError('Committed rank checkpoint changed')
            payload = runner.resume(entry['checkpoint'], protocol_sha256=m['manifest_sha256'], exploration=runner.exploration)
            if payload['diagnostic_only'] or payload['rank'] != args.rank:
                raise ValueError('Diagnostic or different-rank checkpoint cannot resume')
            cursor = payload['next_group']
        sync.assert_replicas(runner)
        for batch in plan[cursor:]:
            if batch['epoch'] > args.until_epochs:
                break
            if sync.gather((root/'PAUSE_AFTER_COMMIT').exists())[0]:
                atomic_json(output/f'paused_{args.until_epochs}.json', {'paused': True,
                    'next_group': batch['index'], 'policy_updates': runner.policy_updates}, overwrite=False)
                return
            while sum(1 for p in (root/'validator/pending').glob('*.json')) > 320:
                hb.update(event='shared_validator_backpressure', next_group=batch['index'])
                time.sleep(5)
            torch.cuda.reset_peak_memory_stats()
            begin = time.time()
            hb.update(event='batch_start', phase=args.phase, arm=args.arm, epoch=batch['epoch'],
                batch_index=batch['index'], actual_actor_updates=runner.policy_updates,
                trajectories_per_rank=len(batch['shards'][args.rank]))
            rows = collect(runner, batch['shards'][args.rank], hb)
            rollout_seconds = time.time()-begin
            rollout_memory = {'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                              'reserved_gib': torch.cuda.max_memory_reserved()/2**30}
            save_rollouts(output/f'rollouts/g{batch["index"]:04d}.json', rows,
                metadata(m, args.arm, diagnostic_only=False, phase=args.phase, rank=args.rank))
            attach_journal(runner, output/f'updates/g{batch["index"]:04d}_attempts.jsonl')
            torch.cuda.reset_peak_memory_stats()
            begin = time.time()
            result = runner.update(rows, 'source', costs, epochs=2, chunk=8, heartbeat=hb,
                distributed=sync, microbatch_size=12, optimizer_step_per_microbatch=True)
            result.update(rollout_seconds=rollout_seconds, update_seconds=time.time()-begin,
                rollout_memory=rollout_memory,
                update_memory={'allocated_gib': torch.cuda.max_memory_allocated()/2**30,
                               'reserved_gib': torch.cuda.max_memory_reserved()/2**30})
            atomic_json(output/f'updates/g{batch["index"]:04d}.json', result, overwrite=False)
            sync.assert_replicas(runner)
            episodes = batch['training_episodes']
            checkpoint = output/f'models/e{episodes:06d}.pt'
            checksum = runner.save(checkpoint, **metadata(m, args.arm, diagnostic_only=False,
                phase=args.phase, rank=args.rank, world_size=args.world_size, training_episodes=episodes,
                next_group=batch['index']+1, schedule_sha256=digest_json(plan)))
            entries = sync.gather({'rank': args.rank, 'checkpoint': str(checkpoint), 'sha256': checksum})
            if args.rank == 0:
                commit = root/args.phase/args.arm/f'commits/e{episodes:06d}.json'
                atomic_json(commit, {'manifest_sha256': m['manifest_sha256'], 'arm': args.arm,
                    'phase': args.phase, 'world_size': args.world_size, 'ranks': entries,
                    'schedule_sha256': digest_json(plan), 'training_episodes': episodes,
                    'policy_updates': runner.policy_updates}, overwrite=False)
                if batch['epoch_tail']:
                    requests = {split: submit_evaluation(m, checkpoint, args.arm, episodes, args.phase, split=split)
                                for split in ('validation', 'tune')}
                    atomic_json(root/args.phase/args.arm/f'epochs/e{batch["epoch"]:02d}.json', {
                        'checkpoint': str(checkpoint), 'checkpoint_sha256': checksum, 'requests': requests,
                        'training_episodes': episodes, 'policy_updates': runner.policy_updates,
                        'commit': str(commit)}, overwrite=False)
            hb.update(event='batch_committed', phase=args.phase, arm=args.arm,
                training_episodes=episodes, actual_actor_updates=runner.policy_updates,
                rollout_seconds=rollout_seconds, update_seconds=result['update_seconds'])
            del rows
            gc.collect()
            if runner.zero_update_batches >= 3:
                raise RuntimeError('Three consecutive zero-update batches; committed state retained')
        atomic_json(output/f'result_epoch{args.until_epochs}.json', {'completed': True,
            'training_episodes': args.until_epochs*len(cases)*4, 'policy_updates': runner.policy_updates}, overwrite=False)
    finally:
        runner.close()


def validate_request(m, request):
    tau_study = m.get('schema') == 'stage3-tau-full600-v1'
    kinds = ('greedy', 'sampling', 'role_mix', 'greedy_ar') if tau_study else ('greedy', 'sampling', 'role_mix')
    if (request['manifest_sha256'] != m['manifest_sha256'] or request['kind'] not in kinds
            or request.get('cache_key') != queue(m).identity(request)
            or request['contract_sha256'] != m['comparison_sha256'] or request['code_sha256'] != m['code']['sha256']
            or digest_file(request['checkpoint']) != request['checkpoint_sha256']
            or digest_json(request['cases']) != request['cases_sha256']):
        raise ValueError('Foreign/changed validation request or forbidden task kind')
    allowed = {c['path']: c for s in ('train_full600', 'validation', 'tune') for c in m['splits'][s]}
    if any(c != allowed.get(c['path']) for c in request['cases']):
        raise ValueError('Validation request accessed sealed/unknown cases')
    if request['arm'] != 'B0' and request['arm'] not in m.get('arms', ARMS):
        raise ValueError('Unknown validation arm')
    expected_latent = LATENT if request['arm'] in ARMS and ARMS[request['arm']]['native'] else None
    if request.get('latent') != expected_latent or request['tau'] != .3 or request['seed'] != 1:
        raise ValueError('Evaluation policy or numerical contract changed')
    if request['arm'] == 'B0':
        expected = (m['diagnostic']['previous_last']['checkpoint_sha256'] if request['kind'] == 'role_mix'
                    else m['source']['sha256'])
        if request['checkpoint_sha256'] != expected:
            raise ValueError('B0 or historical role-mix checkpoint was substituted')
    if request['kind'] in ('sampling', 'role_mix', 'greedy_ar') and any(c['path'] not in {
            x['path'] for x in m['diagnostic']['cases32']} for c in request['cases']):
        raise ValueError('Mechanism sampling/role interventions are training-only')
    if tau_study:
        from onpolicy.utils.stage3_tau import TEMPERATURE
        tau = request.get('sampling_eval_tau')
        decoder = ('autoregressive_sampling' if request['kind'] == 'sampling' else
                   ('autoregressive_greedy' if request['kind'] == 'greedy_ar' else 'b0_native_hungarian'))
        if request.get('decoder') != decoder or (request['kind'] == 'sampling' and tau not in TEMPERATURE['diagnostic_taus']) \
                or (request['kind'] != 'sampling' and tau is not None):
            raise ValueError('Evaluation decoder or fixed diagnostic temperature changed')


def apply_role_mix(runner, checkpoint, bits):
    if len(bits) != 3 or any(x not in (0, 1) for x in bits):
        raise ValueError('Role mix requires three binary choices')
    payload = torch.load(checkpoint, map_location='cpu', weights_only=False)
    if payload.get('source_sha256') != runner.b0_sha256 or payload.get('history') != 'b0_native_environment_authoritative_v1':
        raise ValueError('Role mix is restricted to native current B0 lineage')
    ac = runner.policy.ac
    groups = (ac.plane_actor_param, ac.device_actor_param, ac.transporter_actor_param)
    chosen = set()
    for role, bit in enumerate(bits):
        if bit:
            chosen.update(id(p) for p in groups[role].parameters())
            chosen.update(id(p) for p in ac.encoder.encoders[role].parameters())
    with torch.no_grad():
        for name, param in ac.named_parameters():
            if id(param) in chosen:
                param.copy_(payload['model'][name])


def validator(args, m, hb):
    q = queue(m)
    runner = None
    active_key = None
    worker_id = f'gpu{args.global_gpu}'
    try:
        while True:
            mode = read_json(Path(m['root'])/'validator/mode.json')['mode']
            if mode == 'stop' or (args.boost and mode != 'evaluation_only'):
                return
            placement = (m['resources']['evaluation_plan'][str(args.global_gpu)] if mode == 'evaluation_only'
                         else next(x for x in m['resources']['plan']['validators'] if x['gpu'] == args.global_gpu))
            os.sched_setaffinity(0, placement['cpus'])
            claimed = q.claim()
            if claimed is None:
                hb.update(event='validator_idle', worker=worker_id, pool_mode=mode)
                time.sleep(3)
                continue
            path, request = claimed
            try:
                validate_request(m, request)
                width = min(placement.get('width', 3), len(request['cases']))
                key = (request['arm'], request['checkpoint_sha256'], request['kind']=='role_mix',
                       tuple(request.get('role_mix') or ()), width,
                       request.get('sampling_eval_tau'), request.get('decoder'))
                if key != active_key:
                    if runner is not None:
                        runner.close()
                        del runner
                        gc.collect()
                        torch.cuda.empty_cache()
                    runner = make_engine(m, 'B0' if request['kind']=='role_mix' else request['arm'], width)
                    if request['kind']=='role_mix':
                        apply_role_mix(runner, request['checkpoint'], request['role_mix'])
                    elif request['arm'] != 'B0':
                        runner.load(request['checkpoint'])
                    if request.get('sampling_eval_tau') is not None:
                        runner.configure_exploration(dict(roles=[0, 1, 2], taus=[request['sampling_eval_tau']]*3))
                    if request['kind'] == 'greedy_ar':
                        runner.policy.ac.device_global_matching = False
                    active_key = key
                for p in runner.pool.processes:
                    os.sched_setaffinity(p.pid, placement['cpus'])
                rows = []
                seeds = request.get('sample_seeds', [[1]*len(request['cases'])])
                for replica, all_seeds in enumerate(seeds):
                    for first in range(0, len(request['cases']), width):
                        cases = request['cases'][first:first+width]
                        group = runner.rollout(cases, all_seeds[first:first+width],
                            deterministic=request['kind'] != 'sampling', heartbeat=hb)
                        target = Path(m['root'])/'validator/artifacts'/request['request_id']/f'r{replica}_s{first:03d}.json'
                        save_rollouts(target, group, {'diagnostic_only': True, 'request_id': request['request_id']})
                        rows.extend(record(r) for r in group)
                        del group
                result = {'cases': rows, 'kind': request['kind'], 'arm': request['arm'],
                    'phase': request['phase'], 'role_mix': request.get('role_mix'),
                    'checkpoint_sha256': request['checkpoint_sha256']}
                if m.get('schema') == 'stage3-tau-full600-v1':
                    result.update(sampling_eval_tau=request.get('sampling_eval_tau'), decoder=request['decoder'])
                if request['kind'] != 'sampling':
                    result['summary'] = paired_summary(rows, baseline_costs(m))
                q.finish(path, result)
                hb.update(event='validator_completed', request_id=request['request_id'], completed_cases=len(rows))
            except BaseException as exc:
                q.finish(path, None, f'{type(exc).__name__}: {exc}')
                raise
    finally:
        if runner is not None:
            runner.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--task', choices=('canary', 'train', 'validator'), required=True)
    parser.add_argument('--arm', default='P0_SOURCE')
    parser.add_argument('--phase', choices=('screen', 'formal', 'full'), default='screen')
    parser.add_argument('--rank', type=int, default=0)
    parser.add_argument('--world-size', type=int, default=1)
    parser.add_argument('--global-gpu', type=int, required=True)
    parser.add_argument('--rendezvous', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--resume-commit', type=Path)
    parser.add_argument('--until-epochs', type=int, default=2)
    parser.add_argument('--boost', action='store_true')
    args = parser.parse_args()
    m = read_json(args.manifest)
    verify(m, source_root=ROOT)
    if args.task != 'validator' and args.arm not in m['arms']:
        raise ValueError('Unknown training arm')
    args.output.mkdir(parents=True, exist_ok=True)
    seed_all(m['training']['seed'])
    if args.task != 'validator':
        os.sched_setaffinity(0, m['resources']['plan']['trainers'][str(args.global_gpu)]['cpus'])
    if args.world_size > 1:
        dist.init_process_group('gloo', init_method=f'file://{args.rendezvous.resolve()}',
            world_size=args.world_size, rank=args.rank, timeout=timedelta(hours=12))
    sync = TrajectoryParallel(device_packed=True)
    try:
        with ProgressHeartbeat(args.output/'heartbeat.json', task=args.task, arm=args.arm, rank=args.rank,
                               global_gpu=args.global_gpu) as hb:
            train_fn = train
            if m.get('schema') == 'stage3-tau-full600-v1':
                from onpolicy.scripts.train.stage3_tau_worker import train as train_fn
            {'canary': canary, 'train': train_fn}.get(args.task, lambda a, b, c, h: validator(a, b, h))(args, m, sync, hb)
    except BaseException as exc:
        atomic_json(args.output/'error.json', {'type': type(exc).__name__, 'error': str(exc),
            'traceback': traceback.format_exc(), 'unix': time.time()})
        raise
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()


if __name__ == '__main__':
    main()
