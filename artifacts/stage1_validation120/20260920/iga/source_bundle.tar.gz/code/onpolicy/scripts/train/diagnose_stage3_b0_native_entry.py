#!/usr/bin/env python3
"""Read-only model replay through the original Stage2 collector, never RL admission.

Uses frozen args/config/case order, original env construction/seed/cursor, and
fixed twelve-slot collection. All outputs go to a new diagnostic directory.
No Stage2 source, release result or checkpoint is modified.
"""
import argparse
import copy
import hashlib
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml

from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.scripts.train.run_stage2_bc_hf import FrozenEvaluator
from onpolicy.scripts.train.run_stage2_resource_rl import arguments, seed
from onpolicy.scripts.train.run_stage3_sampling_audit import ProgressHeartbeat
from onpolicy.scripts.train.train_hkbz import make_train_env
from onpolicy.utils.stage2_bc_contract import configure_bc_determinism, ready_head_config
from onpolicy.utils.stage2_bc_hf import configure_args, current_cases
from onpolicy.utils.stage2_frozen import FrozenStage2Bundle
from onpolicy.utils.stage2_resource_rl import configure_trainability, summary
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, default=ROOT / "artifacts/stage2_frozen/20260912/manifest.json")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batch", type=int, choices=range(1, 6), required=True)
    cli = parser.parse_args()
    if cli.output.exists():
        raise FileExistsError("Use a fresh diagnostic output; no implicit retries")
    cli.output.mkdir(parents=True)
    configure_bc_determinism(True)
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = True  # Set BEFORE constructing the model, as in the native entry.
    bundle = FrozenStage2Bundle(cli.bundle)
    hf = read_json(bundle.path("hf_manifest"))
    model_arguments = copy.deepcopy(hf["model_arguments"])
    # parse_args reads the environment YAML to resolve 24/80 dimensions, so
    # rebase config paths BEFORE parsing rather than replacing args afterwards.
    for flag, key in (("--ac_config", "ac_config"), ("--env_config", "env_config")):
        index = model_arguments["environment_argv"].index(flag)
        model_arguments["environment_argv"][index + 1] = str(bundle.path(key))
    args = arguments(model_arguments)
    if (args.max_agent_num, args.max_device_num) != (24, 80):
        raise ValueError("Native environment dimensions differ from the released 24/80 contract")
    payload = bundle.checkpoint()
    for key, value in ready_head_config(payload).items():
        setattr(args, key, value)
    seed(100011)
    policy = GNN_MAPPOPolicy(args, yaml.safe_load(Path(args.ac_config).read_text()), torch.device("cuda:0"))
    policy.ac.load_state_dict(payload["model"], strict=True)
    policy.ac.tau = args.evaluation_tau
    policy.ac.device_global_matching = True
    bundle.validate(policy.ac.state_dict())
    configure_trainability(policy)
    policy.ac.eval()
    configure_args(args, "H2_F4", native=False)
    before = summary(policy.ac)
    flags = {n: p.requires_grad for n, p in policy.ac.named_parameters()}
    selected = hf["evaluation"]["cases"][(cli.batch - 1) * 12:cli.batch * 12]
    dataset = ROOT / "onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune"
    env_args = copy.copy(args)
    env_args.seed = 1
    env_args.max_train_cases = env_args.train_sampling_size = env_args.n_rollout_threads = 12
    atomic_json(cli.output / "protocol.json", {
        "diagnostic_only": True, "formal_training_started": False, "actor_updates": 0,
        "source_sha256": digest_file(bundle.path("b0")), "bundle_sha256": digest_file(cli.bundle),
        "batch": cli.batch, "case_order": [c["case_dir"] for c in selected],
        "environment_seeds": [50000 + i * 10000 for i in range(12)],
        "reset": "reset_data_cursor(); reset()", "fixed_terminal_slots": True,
        "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
        "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
        "model_tensor_count": len(payload["model"]), "requires_grad": flags,
        "packages": {"torch": torch.__version__, "cuda": torch.version.cuda,
                     "cudnn": torch.backends.cudnn.version()},
        "code": {name: digest_file(ROOT / name) for name in (
            "onpolicy/scripts/train/diagnose_stage3_b0_native_entry.py",
            "onpolicy/scripts/train/run_stage2_bc_hf.py", "onpolicy/scripts/train/train_hkbz.py",
            "onpolicy/utils/stage2_resource_rl.py", "onpolicy/envs/env_wrappers.py",
            "onpolicy/envs/HKBZ/environment.py",
            "onpolicy/algorithms/gnn_mappo/algorithm/MAPPOPolicy.py",
            "onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py",
            "onpolicy/algorithms/utils/gnn.py")}}, overwrite=False)
    begin = time.time()
    envs = None
    with ProgressHeartbeat(cli.output / "status.json", phase="original_native_entry_diagnostic",
                           formal_training_started=False) as hb:
        def progress(event, **kwargs):
            kwargs.pop("force", None)
            hb.update(event=event, **kwargs)
        learner = FrozenEvaluator(policy, args, progress)
        actions, histories = [], []
        original = learner.collect_forward
        def traced_forward(policy, obs, hidden, active, history, types, **kwargs):
            out, encoded = original(policy, obs, hidden, active, history, types, **kwargs)
            actions.append(out["actions"].cpu().numpy().copy())
            histories.append(np.asarray(history).copy())
            return out, encoded
        learner.collect_forward = traced_forward
        try:
            envs, _ = make_train_env(env_args, case_records=selected, dataset_override=str(dataset), evaluation=True)
            seed(1)
            result = learner.collect(envs, training=False, hungarian=True)
            result.pop("frames")
            result.pop("targets")
            result["cases"] = current_cases(result["cases"], selected)
            release = read_json(bundle.path("b0_evaluation"))
            expected = {r["case_sha256"]: r for r in release["cases"]}
            for i, row in enumerate(result["cases"]):
                row["action_sha256"] = hashlib.sha256(np.stack(actions)[:row["steps"], i].tobytes()).hexdigest()
                row["history_sha256"] = hashlib.sha256(np.stack(histories)[:row["steps"], i].tobytes()).hexdigest()
            differences = {r["case_dir"]: {
                "cost_delta": r["makespan"] - expected[r["case_sha256"]]["makespan"],
                "steps_delta": r["steps"] - expected[r["case_sha256"]].get("steps", expected[r["case_sha256"]].get("finish_steps"))}
                for r in result["cases"]}
            historical_hash = read_json(bundle.path("hf_baseline"))["batches"][cli.batch - 1]["trajectory_action_sha256"]
            unchanged = summary(policy.ac) == before and flags == {n: p.requires_grad for n, p in policy.ac.named_parameters()}
            if not unchanged or any(p.grad is not None for p in policy.ac.parameters()):
                raise RuntimeError("Read-only native replay changed model state")
            result.update(diagnostic_only=True, actor_updates=0, tensors_unchanged=True,
                historical_differences=differences, historical_cohort_action_sha256=historical_hash,
                historical_cohort_actions_exact=result["trajectory_action_sha256"] == historical_hash,
                cost_and_steps_exact=all(abs(r["cost_delta"]) <= 1e-6 and r["steps_delta"] == 0 for r in differences.values()),
                elapsed_seconds=time.time() - begin)
            np.savez_compressed(cli.output / "complete_actions_and_history.npz",
                                actions=np.stack(actions), histories=np.stack(histories))
            atomic_json(cli.output / "result.json", result, overwrite=False)
        finally:
            if envs is not None:
                envs.close()


if __name__ == "__main__":
    main()
