#!/usr/bin/env python3
"""Prepare/select the matched-IGA DeviceBC -> resource-PPO research round.

The causal boundary is deliberately explicit:

* ``bc`` builds six DeviceBC-only commands from the exact train600 IGA-1800
  planning contract.
* ``select`` rejects incomplete/deadlocked validations and selects one
  immutable ``checkpoint_DeviceBC.pt`` by Pre-PPO composite-tail score.
* ``ppo`` builds six PPO commands that all restore that exact BC checkpoint.

No PPO branch is allowed to regenerate BC, and the plane actor plus shared
encoder stay frozen for every Stage2 update.  Method screening deliberately
uses one 240-case distribution-balanced cycle instead of expanding every
epoch to the 960-slot full-coverage formal contract.  The cycle contains all
120 OOD cases and 120 IID cases, so the expensive screen removes repeated OOD
rollouts without dropping any unique tail case.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.envs.HKBZ.experiment.generate_stage2_resource_iga_labels import (  # noqa: E402
    SEARCH_CONTRACT_VERSION,
)
from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    DEFAULT_DATASET,
    DEFAULT_HANDOFF,
    DEFAULT_PYTHON,
    atomic_json,
    build_compact_teacher_index,
    configure_command,
    natural_evaluator_command,
    sha256_file,
    source_contract,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    build_stage2_command,
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.scripts.train.train_hkbz import (  # noqa: E402
    select_train_case_dirs,
)


PROFILE = "matched_iga_distill_resource_ppo"
BC_EPOCHS = 4
PPO_EPOCHS = 8
ROLLOUT_THREADS = 30
TRAIN_CASE_SLOTS = 240
TRAIN_UNIQUE_CASES = 240
TRAIN_DISTRIBUTION_COUNTS = {
    "iid": 120,
    "ood_stress": 108,
    "ood_scale": 12,
}
BC_ROLLOUTS = math.ceil(TRAIN_CASE_SLOTS / ROLLOUT_THREADS)
MINI_BATCH_SIZE = 30
DATA_CHUNK_LENGTH = 50
GRAPHS_PER_FORWARD = 1500
EVAL_THREADS = 12
MATCHED_IGA_BUDGET = 1800.0

MATCHED_HARD_CONTRACT = {
    "device_lookahead_dispatch": True,
    "device_lookahead_safety_margin": 60.0,
    "device_deadline_aware_dispatch": True,
    "device_future_intent_horizon": 1,
    "device_future_intent_mode": "bounded_frontier",
    "device_frontier_max_requests": 2,
    "resource_release_aware_eta": True,
    "device_lookahead_reservation_mode": "hard",
    "device_reservation_grace_seconds": 300.0,
    "device_departure_lookahead": True,
}

BC_METHODS = {
    "T0_heuristic_role": {
        "teacher": "heuristic",
        "role_balanced": True,
        "timing_balanced": False,
        "score_margin": -1.0,
        "hypothesis": "old Hungarian teacher control under matched planning",
    },
    "T1_iga_plain": {
        "teacher": "iga",
        "role_balanced": False,
        "timing_balanced": False,
        "score_margin": -1.0,
        "hypothesis": "exact matched IGA teacher with unweighted NLL",
    },
    "T2_iga_role": {
        "teacher": "iga",
        "role_balanced": True,
        "timing_balanced": False,
        "score_margin": -1.0,
        "hypothesis": "matched IGA plus ordinary/R014 balancing",
    },
    "T3_iga_timing": {
        "teacher": "iga",
        "role_balanced": False,
        "timing_balanced": True,
        "score_margin": -1.0,
        "hypothesis": "matched IGA plus blocking/lookahead/defer balancing",
    },
    "T4_iga_role_timing": {
        "teacher": "iga",
        "role_balanced": True,
        "timing_balanced": True,
        "score_margin": -1.0,
        "hypothesis": "crossed role and timing strata",
    },
    "T5_iga_confident": {
        "teacher": "iga",
        "role_balanced": True,
        "timing_balanced": True,
        "score_margin": 0.05,
        "hypothesis": "crossed strata with ambiguous IGA dispatches removed",
    },
}

PPO_METHODS = {
    "P0_legacy": {
        "hypothesis": "legacy per-agent PPO control",
    },
    "P1_role_atomic": {
        "role_atomic": True,
        "hypothesis": "one atomic joint-event ratio per resource role",
    },
    "P2_role_event": {
        "role_atomic": True,
        "role_event": True,
        "hypothesis": "resource role-event clocks remove mixed-time credit",
    },
    "P3_critic_calibrated": {
        "role_atomic": True,
        "role_event": True,
        "role_valuenorm": True,
        "actor_warmup_shards": 12,
        "hypothesis": "role targets plus critic-only calibration boundary",
    },
    "P4_counterfactual_q": {
        "role_atomic": True,
        "role_event": True,
        "role_valuenorm": True,
        "counterfactual_q": True,
        "actor_warmup_shards": 12,
        "hypothesis": "legal-action Q expectation lowers resource variance",
    },
    "P5_sequential_roles": {
        "role_atomic": True,
        "role_event": True,
        "role_valuenorm": True,
        "counterfactual_q": True,
        "role_sequential": True,
        "actor_warmup_shards": 12,
        "hypothesis": "counterfactual Q plus rotating HAPPO-style roles",
    },
}


def small_batch_coverage_audit(
    dataset_dir: Path,
    *,
    seed: int = 1,
    n_rollout_threads: int = ROLLOUT_THREADS,
) -> dict:
    """Build and verify the tail-complete 240-case screening cycle."""

    n_rollout_threads = int(n_rollout_threads)
    if n_rollout_threads <= 0:
        raise ValueError("n_rollout_threads must be positive.")
    case_dirs = sorted(
        path for path in dataset_dir.glob("case_*") if path.is_dir()
    )
    selected, audit = select_train_case_dirs(
        case_dirs,
        mode="distribution_balanced",
        weights_spec="iid=0.50,ood_stress=0.45,ood_scale=0.05",
        seed=seed,
        max_cases=0,
        sample_size=TRAIN_CASE_SLOTS,
    )
    expected_scalars = {
        "source_cases": 600,
        "selected_cases": TRAIN_CASE_SLOTS,
        "unique_cases": TRAIN_UNIQUE_CASES,
    }
    for key, expected in expected_scalars.items():
        observed = int(audit.get(key, -1))
        if observed != expected:
            raise ValueError(
                f"Small-batch Stage2 contract mismatch for {key}: "
                f"{observed} != {expected}."
            )
    observed_counts = {
        key: int(value)
        for key, value in audit.get(
            "selected_distribution_counts", {}
        ).items()
    }
    if observed_counts != TRAIN_DISTRIBUTION_COUNTS:
        raise ValueError(
            "Small-batch Stage2 distribution mismatch: "
            f"{observed_counts} != {TRAIN_DISTRIBUTION_COUNTS}."
        )
    unique_counts = {
        key: int(value)
        for key, value in audit.get(
            "unique_distribution_counts", {}
        ).items()
    }
    if unique_counts != TRAIN_DISTRIBUTION_COUNTS:
        raise ValueError(
            "Small-batch Stage2 must not duplicate cases within a cycle: "
            f"{unique_counts} != {TRAIN_DISTRIBUTION_COUNTS}."
        )
    order_sha256 = hashlib.sha256(
        "\n".join(Path(path).name for path in selected).encode("utf-8")
    ).hexdigest()
    return {
        **audit,
        "dataset_dir": str(dataset_dir.resolve()),
        "sampling_seed": int(seed),
        "case_order_sha256": order_sha256,
        "n_rollout_threads": n_rollout_threads,
        "shards_per_epoch": math.ceil(
            len(selected) / n_rollout_threads
        ),
        "max_train_cases": 0,
        "train_sampling_size": TRAIN_CASE_SLOTS,
        "all_ood_unique_cases_retained": True,
    }


def option_value(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def code_contract() -> dict:
    revision = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    status = subprocess.check_output(
        ["git", "status", "--short"], cwd=ROOT, text=True
    )
    diff = subprocess.check_output(
        ["git", "diff", "--binary", "--", "onpolicy"], cwd=ROOT
    )
    implementation_files = (
        "onpolicy/config/config.py",
        "onpolicy/envs/HKBZ/environment.py",
        "onpolicy/envs/HKBZ/resource_teacher.py",
        "onpolicy/envs/HKBZ/experiment/generate_stage2_resource_iga_labels.py",
        "onpolicy/runner/shared/hkbz_runner.py",
        "onpolicy/algorithms/gnn_mappo/gnn_mappo.py",
        "onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py",
        "onpolicy/scripts/train/prepare_stage2_iga_distill_ppo.py",
        "onpolicy/scripts/train/launch_stage2_iga_distill_ppo_dual_gpu.sh",
    )
    return {
        "git_revision": revision,
        "working_tree_dirty": bool(status.strip()),
        "working_tree_status": status.splitlines(),
        "onpolicy_diff_sha256": hashlib.sha256(diff).hexdigest(),
        "implementation_files_sha256": {
            relative: sha256_file(ROOT / relative)
            for relative in implementation_files
        },
    }


def common_command(
    source: dict,
    source_command: list[str],
    *,
    run_tag: str,
    method_id: str,
    python: Path,
    teacher_dir: Path,
    teacher_index: Path,
) -> list[str]:
    method = {
        "teacher": "iga",
        "role_balanced": True,
        "reward_mode": "team_time",
        "release_aware": True,
        "future_intent_mode": "bounded_frontier",
        "reservation_mode": "hard",
    }
    base = build_stage2_command(
        source["path"],
        run_tag=f"{run_tag}_{PROFILE}_{method_id}",
        seed=1,
        bc_epochs=BC_EPOCHS,
        ppo_epochs=PPO_EPOCHS,
        ppo_epoch=2,
        bc_min_labels=64,
        bc_min_rollouts=BC_ROLLOUTS,
        bc_max_rollouts=BC_ROLLOUTS,
        source_command=source_command,
        python=python,
    )
    command = configure_command(
        base,
        method_id,
        method,
        run_tag=run_tag,
        profile="planning_wave",
        teacher_dir=teacher_dir,
        teacher_index=teacher_index,
        low_memory=False,
    )
    set_option(
        command,
        "--experiment_name",
        f"{run_tag}_{PROFILE}_{method_id}_seed1",
    )
    set_option(command, "--seed", 1)
    set_option(command, "--num_episodes", PPO_EPOCHS)
    set_option(command, "--gnn_freeze_epochs", PPO_EPOCHS)
    set_option(command, "--plane_freeze_epochs", PPO_EPOCHS)
    set_switch(command, "--stage2_allow_shared_unfreeze", False)
    set_option(command, "--n_rollout_threads", ROLLOUT_THREADS)
    set_option(command, "--n_eval_rollout_threads", EVAL_THREADS)
    set_option(command, "--max_train_cases", 0)
    set_option(command, "--train_sampling_size", TRAIN_CASE_SLOTS)
    set_option(command, "--max_eval_cases", 60)
    set_option(command, "--device_bc_min_rollouts_per_epoch", BC_ROLLOUTS)
    set_option(command, "--device_bc_max_rollouts_per_epoch", BC_ROLLOUTS)
    set_option(command, "--device_bc_dagger_schedule", "1.0,0.7,0.4,0.1")
    set_option(command, "--mini_batch_size", MINI_BATCH_SIZE)
    set_option(command, "--data_chunk_length", DATA_CHUNK_LENGTH)
    set_option(command, "--max_graphs_per_forward", GRAPHS_PER_FORWARD)
    set_option(command, "--grad_accumulation_steps", 3)
    set_option(command, "--actor_grad_accumulation_steps", 2)
    set_option(command, "--grad_accumulation_target_graphs", 5000)
    set_option(command, "--actor_grad_accumulation_target_graphs", 2000)
    set_option(command, "--actor_warmup_shards", 0)
    set_option(command, "--hindsight_reward_mode", "team_time")
    set_option(command, "--hindsight_cmax_coef", 0.0)
    set_option(command, "--hindsight_shaping_coef", 0.0)
    set_option(command, "--hindsight_terminal_cmax_coef", 1.0)
    set_option(command, "--resource_lateness_coef", 0.0)
    set_option(command, "--resource_critical_lateness_coef", 0.0)
    set_option(command, "--resource_earliness_coef", 0.0)
    set_option(command, "--resource_wait_constraint_target", 0.0)
    set_option(command, "--resource_wait_dual_lr", 0.0)
    set_option(command, "--device_lookahead_safety_margin", 60.0)
    set_switch(command, "--device_deadline_aware_dispatch", True)
    set_option(command, "--device_future_intent_horizon", 1)
    set_option(command, "--device_future_intent_mode", "bounded_frontier")
    set_option(command, "--device_frontier_max_requests", 2)
    set_switch(command, "--resource_release_aware_eta", True)
    set_option(command, "--device_lookahead_reservation_mode", "hard")
    set_option(command, "--device_reservation_grace_seconds", 300.0)
    set_switch(command, "--device_departure_lookahead", True)
    set_option(command, "--selection_metric", "composite_tail")
    set_switch(command, "--skip_pre_ppo_eval", False)
    set_switch(command, "--skip_epoch_eval", False)
    set_switch(command, "--use_eval", True)
    set_switch(command, "--rollout_until_done", True)
    set_switch(command, "--safe_graph_batch_pipeline", True)
    set_switch(command, "--safe_dagger_teacher_overlap", True)
    for flag in (
        "--role_atomic_ppo",
        "--role_event_returns",
        "--role_valuenorm",
        "--counterfactual_q_baseline",
        "--role_sequential_ppo",
        "--device_bc_only",
        "--device_bc_timing_balanced",
    ):
        set_switch(command, flag, False)
    set_switch(command, "--joint_team_ppo", False)
    set_option(command, "--joint_team_ppo_scope", "plane")
    set_option(command, "--device_bc_min_teacher_score_margin", -1.0)
    return command


def build_bc_manifest(args: argparse.Namespace) -> dict:
    suite = args.suite_dir.resolve()
    teacher_dir = suite / "artifacts/resource_iga1800_compact"
    teacher_index = suite / "artifacts/resource_iga1800_index.json"
    teacher_contract = build_compact_teacher_index(
        args.source_teacher_dir.resolve(),
        args.dataset_dir.resolve(),
        teacher_dir,
        teacher_index,
        expected_search_contract_version=SEARCH_CONTRACT_VERSION,
        expected_resource_lookahead_contract=MATCHED_HARD_CONTRACT,
        expected_cumulative_budget_seconds=MATCHED_IGA_BUDGET,
    )
    source, source_command = source_contract(
        args.handoff.resolve(), args.source_seed
    )
    if source["sha256"] != teacher_contract["frozen_plane_checkpoint_sha256"]:
        raise ValueError("Matched IGA teachers use a different Stage1 source.")
    coverage = small_batch_coverage_audit(
        args.dataset_dir.resolve(), seed=1, n_rollout_threads=ROLLOUT_THREADS
    )
    commands = {}
    for method_id, method in BC_METHODS.items():
        command = common_command(
            source,
            source_command,
            run_tag=args.run_tag,
            method_id=method_id,
            python=args.python.resolve(),
            teacher_dir=teacher_dir,
            teacher_index=teacher_index,
        )
        set_option(command, "--device_bc_pretrain_epochs", BC_EPOCHS)
        set_option(command, "--device_bc_teacher", method["teacher"])
        set_switch(
            command, "--device_bc_role_balanced", method["role_balanced"]
        )
        set_switch(
            command,
            "--device_bc_timing_balanced",
            method["timing_balanced"],
        )
        set_option(
            command,
            "--device_bc_min_teacher_score_margin",
            method["score_margin"],
        )
        set_switch(command, "--device_bc_only", True)
        if method["teacher"] != "iga":
            remove_option(command, "--resource_iga_teacher_dir")
            remove_option(command, "--resource_iga_teacher_index")
        commands[method_id] = {
            "argv": command,
            "shell": shlex.join(command),
            **method,
        }
    return manifest_payload(
        args,
        phase="bc",
        source=source,
        teacher_contract=teacher_contract,
        teacher_index=teacher_index,
        coverage=coverage,
        commands=commands,
        methods=BC_METHODS,
    )


def select_bc(args: argparse.Namespace) -> dict:
    manifest = json.loads(args.bc_manifest.read_text(encoding="utf-8"))
    rows = []
    for method_id, entry in manifest["commands"].items():
        experiment = option_value(entry["argv"], "--experiment_name")
        run_dir = (
            ROOT / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo"
            / experiment / "run1"
        )
        evaluation_path = run_dir / "evaluations/pre_ppo.json"
        checkpoint = run_dir / "models/checkpoint_DeviceBC.pt"
        if not evaluation_path.is_file() or not checkpoint.is_file():
            raise FileNotFoundError(
                f"Incomplete DeviceBC arm {method_id}: {run_dir}"
            )
        evaluation = json.loads(evaluation_path.read_text(encoding="utf-8"))
        summary = evaluation.get("summary", {})
        completion = float(summary.get("eval_completion_rate", 0.0))
        timeout_count = int(summary.get("eval_timeout_count", -1))
        cycle_count = int(summary.get("eval_cycle_count", -1))
        score = float(summary.get("eval_selection_score", math.inf))
        valid = (
            math.isfinite(score)
            and math.isclose(completion, 1.0, abs_tol=1e-12)
            and timeout_count == 0
            and cycle_count == 0
        )
        rows.append({
            "method": method_id,
            "valid": valid,
            "selection_score": score,
            "raw_makespan": float(
                summary.get("eval_raw_makespan", math.inf)
            ),
            "completion_rate": completion,
            "timeout_count": timeout_count,
            "cycle_count": cycle_count,
            "evaluation_path": str(evaluation_path.resolve()),
            "evaluation_sha256": sha256_file(evaluation_path),
            "checkpoint": str(checkpoint.resolve()),
            "checkpoint_sha256": sha256_file(checkpoint),
        })
    accepted = [row for row in rows if row["valid"]]
    if not accepted:
        raise RuntimeError("Every DeviceBC method failed the validation gate.")
    winner = min(accepted, key=lambda row: row["selection_score"])
    payload = {
        "schema_version": 1,
        "status": "selected",
        "metric": "pre_ppo_eval_selection_score",
        "direction": "lower_is_better",
        "hard_gate": {
            "completion_rate": 1.0,
            "timeout_count": 0,
            "cycle_count": 0,
        },
        "selected_method": winner["method"],
        "selected_checkpoint": winner["checkpoint"],
        "selected_checkpoint_sha256": winner["checkpoint_sha256"],
        "rows": sorted(rows, key=lambda row: row["selection_score"]),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    atomic_json(args.output.resolve(), payload)
    return payload


def build_ppo_manifest(
    args: argparse.Namespace, *, memory_canary: bool = False
) -> dict:
    selection = json.loads(args.selection.read_text(encoding="utf-8"))
    checkpoint = Path(selection["selected_checkpoint"]).resolve()
    if not checkpoint.is_file() or sha256_file(checkpoint) != selection[
        "selected_checkpoint_sha256"
    ]:
        raise ValueError("Selected DeviceBC checkpoint digest changed.")
    bc_manifest = json.loads(args.bc_manifest.read_text(encoding="utf-8"))
    teacher_index = Path(bc_manifest["teacher_index_path"]).resolve()
    teacher_dir = Path(
        bc_manifest["teacher_contract"]["teacher_dir"]
    ).resolve()
    source, source_command = source_contract(
        args.handoff.resolve(), args.source_seed
    )
    coverage = small_batch_coverage_audit(
        args.dataset_dir.resolve(), seed=1, n_rollout_threads=ROLLOUT_THREADS
    )
    commands = {}
    selected_bc_method = BC_METHODS[selection["selected_method"]]
    selected_methods = (
        {
            f"C{method_id[1:]}": method
            for method_id, method in PPO_METHODS.items()
            if method_id in {
                "P3_critic_calibrated",
                "P4_counterfactual_q",
                "P5_sequential_roles",
            }
        }
        if memory_canary else PPO_METHODS
    )
    for method_id, method in selected_methods.items():
        command = common_command(
            source,
            source_command,
            run_tag=args.run_tag,
            method_id=method_id,
            python=args.python.resolve(),
            teacher_dir=teacher_dir,
            teacher_index=teacher_index,
        )
        set_option(command, "--device_bc_pretrain_epochs", 0)
        set_option(command, "--resource_bc_checkpoint", checkpoint)
        set_option(command, "--device_bc_teacher", selected_bc_method["teacher"])
        if selected_bc_method["teacher"] != "iga":
            remove_option(command, "--resource_iga_teacher_dir")
            remove_option(command, "--resource_iga_teacher_index")
        set_switch(
            command,
            "--device_bc_role_balanced",
            selected_bc_method["role_balanced"],
        )
        set_switch(
            command,
            "--device_bc_timing_balanced",
            selected_bc_method["timing_balanced"],
        )
        set_option(
            command,
            "--device_bc_min_teacher_score_margin",
            selected_bc_method["score_margin"],
        )
        set_switch(command, "--device_bc_only", False)
        role_atomic = bool(method.get("role_atomic", False))
        set_switch(command, "--joint_team_ppo", role_atomic)
        set_option(
            command, "--joint_team_ppo_scope", "all" if role_atomic else "plane"
        )
        set_switch(command, "--role_atomic_ppo", role_atomic)
        set_switch(
            command, "--role_event_returns", bool(method.get("role_event", False))
        )
        set_switch(
            command, "--role_valuenorm", bool(method.get("role_valuenorm", False))
        )
        set_switch(
            command,
            "--counterfactual_q_baseline",
            bool(method.get("counterfactual_q", False)),
        )
        set_switch(
            command,
            "--role_sequential_ppo",
            bool(method.get("role_sequential", False)),
        )
        set_option(
            command,
            "--actor_warmup_shards",
            0 if memory_canary else int(method.get("actor_warmup_shards", 0)),
        )
        if memory_canary:
            set_option(command, "--num_episodes", 1)
            set_option(command, "--gnn_freeze_epochs", 1)
            set_option(command, "--plane_freeze_epochs", 1)
            set_option(command, "--ppo_epoch", 1)
            set_option(command, "--max_train_cases", ROLLOUT_THREADS)
            set_option(command, "--train_sampling_size", ROLLOUT_THREADS)
            set_option(command, "--recovery_checkpoint_interval_shards", 1)
            set_switch(command, "--skip_pre_ppo_eval", True)
            set_switch(command, "--skip_epoch_eval", True)
        set_option(command, "--role_loss_weighting", "fixed")
        set_option(command, "--plane_loss_coef", 0.0 if role_atomic else 1.0)
        set_option(command, "--device_loss_coef", 0.5)
        set_option(command, "--transporter_loss_coef", 0.5)
        set_option(command, "--device_target_kl", 0.005)
        set_option(command, "--transporter_target_kl", 0.005)
        commands[method_id] = {
            "argv": command,
            "shell": shlex.join(command),
            **method,
        }
    teacher_contract = bc_manifest["teacher_contract"]
    payload = manifest_payload(
        args,
        phase="ppo_memory_canary" if memory_canary else "ppo",
        source=source,
        teacher_contract=teacher_contract,
        teacher_index=teacher_index,
        coverage=coverage,
        commands=commands,
        methods=selected_methods,
    )
    payload["bc_selection"] = selection
    return payload


def manifest_payload(
    args: argparse.Namespace,
    *,
    phase: str,
    source: dict,
    teacher_contract: dict,
    teacher_index: Path,
    coverage: dict,
    commands: dict,
    methods: dict,
) -> dict:
    evaluator_key = next(iter(commands))
    return {
        "schema_version": 1,
        "research_stage": "stage2_resource_joint",
        "profile": PROFILE,
        "phase": phase,
        "run_tag": args.run_tag,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "code_contract": code_contract(),
        "source": source,
        "teacher_contract": teacher_contract,
        "teacher_index_path": str(teacher_index.resolve()),
        "teacher_index_sha256": sha256_file(teacher_index),
        "data_contract": coverage,
        "planning_contract": MATCHED_HARD_CONTRACT,
        "training_contract": {
            "seed": 1,
            "bc_epochs": BC_EPOCHS if phase == "bc" else 0,
            "ppo_epochs": (
                0 if phase == "bc"
                else 1 if phase == "ppo_memory_canary"
                else PPO_EPOCHS
            ),
            "device_bc_only": phase == "bc",
            "shared_bc_checkpoint_for_all_ppo": phase in {
                "ppo_memory_canary", "ppo"
            },
            "memory_canary": phase == "ppo_memory_canary",
            "plane_frozen": True,
            "shared_encoder_frozen": True,
            "n_rollout_threads": ROLLOUT_THREADS,
            "train_case_slots": TRAIN_CASE_SLOTS,
            "train_unique_cases": TRAIN_UNIQUE_CASES,
            "shards_per_epoch": math.ceil(
                TRAIN_CASE_SLOTS / ROLLOUT_THREADS
            ),
            "max_graphs_per_forward": GRAPHS_PER_FORWARD,
        },
        "hardware_contract": {
            "gpus": [0, 1],
            "trainers_per_gpu": 3,
            "shared_evaluators_per_gpu": 1,
            "physical_core_isolation": True,
            "numa_local": True,
        },
        "evaluator_command": natural_evaluator_command(
            commands[evaluator_key]["argv"]
        ),
        "evaluator_source_method": evaluator_key,
        "methods": methods,
        "commands": commands,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--phase",
        choices=("bc", "select", "ppo_memory_canary", "ppo"),
        required=True,
    )
    parser.add_argument("--run-tag")
    parser.add_argument("--suite-dir", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--handoff", type=Path, default=DEFAULT_HANDOFF)
    parser.add_argument("--source-seed", type=int, default=3)
    parser.add_argument("--source-teacher-dir", type=Path)
    parser.add_argument("--dataset-dir", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--python", type=Path, default=DEFAULT_PYTHON)
    parser.add_argument("--bc-manifest", type=Path)
    parser.add_argument("--selection", type=Path)
    args = parser.parse_args()
    if args.phase in {"bc", "ppo_memory_canary", "ppo"} and (
        not args.run_tag or not args.suite_dir
    ):
        parser.error("--run-tag and --suite-dir are required for bc/ppo")
    if args.phase == "bc" and args.source_teacher_dir is None:
        parser.error("--source-teacher-dir is required for bc")
    if args.phase == "select" and args.bc_manifest is None:
        parser.error("--bc-manifest is required for select")
    if args.phase in {"ppo_memory_canary", "ppo"} and (
        args.bc_manifest is None or args.selection is None
    ):
        parser.error("--bc-manifest and --selection are required for ppo")
    return args


def main() -> int:
    args = parse_args()
    if args.phase == "bc":
        payload = build_bc_manifest(args)
        atomic_json(args.output.resolve(), payload)
    elif args.phase == "select":
        payload = select_bc(args)
    else:
        payload = build_ppo_manifest(
            args, memory_canary=args.phase == "ppo_memory_canary"
        )
        atomic_json(args.output.resolve(), payload)
    print(json.dumps({
        "phase": args.phase,
        "output": str(args.output.resolve()),
        "commands": list(payload.get("commands", {})),
        "selected_method": payload.get("selected_method"),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
