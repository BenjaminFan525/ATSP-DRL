#!/usr/bin/env python3
"""Prepare the Stage2 MC+counterfactual+timing+tail causal screen.

The previous role-credit wave ruled out TD(lambda) and critical-path return
redistribution.  This round keeps the exact matched-IGA T4 DeviceBC boundary,
uses unbiased role-clock Monte-Carlo returns in every arm, and isolates the
missing counterfactual, fitted-potential, persistent timing-anchor, and CVaR
effects.  Plane modules and the unsplit shared encoder remain frozen.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys


ROOT = Path(
    os.environ.get("HKBZ_ROOT", Path(__file__).resolve().parents[3])
).resolve()
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from onpolicy.config.config import get_config  # noqa: E402
from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv  # noqa: E402
from onpolicy.scripts.train.prepare_stage2_event_credit_wave import (  # noqa: E402
    data_contract,
    load_json,
)
from onpolicy.scripts.train.prepare_stage2_resource_research import (  # noqa: E402
    atomic_json,
    sha256_file,
)
from onpolicy.scripts.train.run_hkbz_two_stage_pipeline import (  # noqa: E402
    remove_option,
    set_option,
    set_switch,
)
from onpolicy.scripts.train.train_hkbz import parse_args as parse_training_args  # noqa: E402


RUN_TAG = "stage2_mc_cf_timing_tail_20260829_r2"
METHODS = {
    "A0_mc_control": {
        "counterfactual": False,
        "potential": False,
        "timing_anchor": False,
        "cvar": False,
        "hypothesis": "role-clock Monte-Carlo control",
    },
    "A1_mc_cf": {
        "counterfactual": True,
        "potential": False,
        "timing_anchor": False,
        "cvar": False,
        "hypothesis": "MC plus legal-action counterfactual baseline",
    },
    "A2_mc_cf_potential": {
        "counterfactual": True,
        "potential": True,
        "timing_anchor": False,
        "cvar": False,
        "hypothesis": "Potential V2 adds direction to stable MC+CF",
    },
    "A3_mc_cf_timing_anchor": {
        "counterfactual": True,
        "potential": False,
        "timing_anchor": True,
        "cvar": False,
        "hypothesis": "persistent matched-IGA timing anchor prevents PPO drift",
    },
    "A4_mc_cf_timing_potential": {
        "counterfactual": True,
        "potential": True,
        "timing_anchor": True,
        "cvar": False,
        "hypothesis": "timing anchor and Potential V2 are complementary",
    },
    "A5_mc_cf_timing_potential_cvar": {
        "counterfactual": True,
        "potential": True,
        "timing_anchor": True,
        "cvar": True,
        "hypothesis": "bounded CVaR suppresses coupled-case catastrophes",
    },
}


def code_contract() -> dict:
    paths = (
        "onpolicy/config/config.py",
        "onpolicy/envs/HKBZ/environment.py",
        "onpolicy/utils/shared_buffer.py",
        "onpolicy/runner/shared/hkbz_runner.py",
        "onpolicy/algorithms/gnn_mappo/algorithm/gnn_actor_critic.py",
        "onpolicy/algorithms/gnn_mappo/gnn_mappo.py",
        "onpolicy/scripts/train/prepare_stage2_mc_cf_timing_tail.py",
        "onpolicy/scripts/train/launch_stage2_mc_cf_timing_tail_dual_gpu.sh",
        "onpolicy/scripts/train/stage2_event_credit_autopilot.py",
    )
    revision = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    status = subprocess.check_output(
        ["git", "status", "--short"], cwd=ROOT, text=True
    ).splitlines()
    return {
        "git_revision": revision,
        "working_tree_dirty": bool(status),
        "working_tree_status": status,
        "files_sha256": {
            path: sha256_file(ROOT / path)
            for path in paths if (ROOT / path).is_file()
        },
    }


def apply_common(command: list[str], *, args, method_id: str) -> None:
    command[0] = str(args.python)
    set_option(
        command,
        "--experiment_name",
        f"{args.run_tag}_waveA_{method_id}_seed1",
    )
    set_option(command, "--seed", 1)
    set_option(command, "--cuda_memory_fraction", 0.30)
    set_option(command, "--num_episodes", 2)
    set_option(command, "--gnn_freeze_epochs", 2)
    set_option(command, "--plane_freeze_epochs", 2)
    set_switch(command, "--stage2_allow_shared_unfreeze", False)
    set_option(command, "--n_rollout_threads", 30)
    set_option(command, "--n_eval_rollout_threads", 12)
    set_option(command, "--max_train_cases", 0)
    set_option(command, "--train_sampling_size", 240)
    set_option(command, "--train_sampling_pool_size", 600)
    set_option(command, "--max_eval_cases", 60)
    set_option(command, "--ppo_epoch", 1)
    # Keep each recurrent PPO forward exactly at the graph cap:
    # 20 sequences * 50 recurrent steps = 1000 graphs.  A batch of 30 would
    # request 1500 graphs and is rejected before the first update.
    set_option(command, "--mini_batch_size", 20)
    set_option(command, "--data_chunk_length", 50)
    set_option(command, "--max_graphs_per_forward", 1000)
    set_option(command, "--grad_accumulation_steps", 3)
    set_option(command, "--actor_grad_accumulation_steps", 2)
    set_option(command, "--grad_accumulation_target_graphs", 5000)
    set_option(command, "--actor_grad_accumulation_target_graphs", 2000)
    set_option(command, "--actor_warmup_shards", 0)
    set_option(command, "--adaptive_actor_lr_max_scale", 1.0)
    set_option(command, "--target_kl", 0.003)
    set_option(command, "--plane_target_kl", 0.003)
    set_option(command, "--device_target_kl", 0.003)
    set_option(command, "--transporter_target_kl", 0.003)
    set_option(command, "--plane_loss_coef", 0.0)
    set_option(command, "--device_loss_coef", 0.5)
    set_option(command, "--transporter_loss_coef", 0.5)
    set_option(command, "--device_policy_head_mode", "shared")
    set_option(command, "--device_bc_pretrain_epochs", 0)
    set_option(command, "--hindsight_cmax_coef", 0.0)
    set_option(command, "--hindsight_shaping_coef", 0.0)
    set_option(command, "--hindsight_terminal_cmax_coef", 1.0)
    set_option(command, "--resource_lateness_coef", 0.0)
    set_option(command, "--resource_critical_lateness_coef", 0.0)
    set_option(command, "--resource_earliness_coef", 0.0)
    set_option(command, "--resource_wait_constraint_target", 0.0)
    set_option(command, "--resource_wait_dual_lr", 0.0)
    set_option(command, "--tail_policy_start_fraction", 1.0)
    set_option(command, "--tail_policy_weight", 1.0)
    set_option(command, "--cvar_policy_fraction", 1.0)
    set_option(command, "--cvar_policy_weight", 1.0)
    set_option(command, "--early_stop_patience", 0)
    set_option(command, "--recovery_checkpoint_interval_shards", 1)
    set_option(command, "--bc_reference_kl_coef", 0.0)
    set_option(command, "--bc_reference_kl_coef_schedule", "0.0")
    set_option(command, "--bc_reference_target_kl", 0.0)
    set_switch(command, "--bc_reference_hard_gate", False)
    set_switch(command, "--device_bc_only", False)
    set_switch(command, "--joint_team_ppo", True)
    set_option(command, "--joint_team_ppo_scope", "all")
    set_switch(command, "--role_atomic_ppo", True)
    set_switch(command, "--role_event_returns", True)
    set_switch(command, "--role_valuenorm", True)
    set_switch(command, "--role_sequential_ppo", False)
    set_option(command, "--role_loss_weighting", "fixed")
    set_option(command, "--role_event_gae_lambda", 1.0)
    set_option(command, "--plane_role_gae_lambda", 1.0)
    set_option(command, "--device_role_gae_lambda", 1.0)
    set_option(command, "--transporter_role_gae_lambda", 1.0)
    set_option(command, "--role_event_credit_mode", "elapsed")
    set_option(command, "--role_event_credit_uniform_mix", 0.15)
    set_switch(command, "--use_eval", True)
    set_switch(command, "--rollout_until_done", True)
    set_switch(command, "--safe_graph_batch_pipeline", True)
    set_switch(command, "--safe_dagger_teacher_overlap", True)
    set_switch(command, "--clear_cuda_cache_after_update", False)


def build_command(base: list[str], method_id: str, method: dict, *, args) -> list[str]:
    command = list(base)
    apply_common(command, args=args, method_id=method_id)
    set_switch(command, "--counterfactual_q_baseline", method["counterfactual"])
    set_option(command, "--counterfactual_q_topk", 8)
    set_option(command, "--counterfactual_q_min_mass", 0.90)
    if method["potential"]:
        set_option(
            command,
            "--hindsight_reward_mode",
            "team_time_resource_fitted_potential",
        )
        set_option(command, "--iga_potential_weights_path", args.potential)
        set_option(command, "--iga_potential_beta", 0.10)
        set_option(command, "--iga_potential_beta_schedule", "0.10,0.10")
    else:
        set_option(command, "--hindsight_reward_mode", "team_time")
        set_option(command, "--iga_potential_beta", 0.0)
        set_option(command, "--iga_potential_beta_schedule", "0.0,0.0")
        remove_option(command, "--iga_potential_weights_path")
    if method["timing_anchor"]:
        set_option(command, "--bc_reference_kl_coef", 0.20)
        set_option(command, "--bc_reference_kl_coef_schedule", "0.20,0.10")
        set_option(command, "--bc_reference_target_kl", 0.01)
    if method["cvar"]:
        set_option(command, "--cvar_policy_fraction", 0.20)
        set_option(command, "--cvar_policy_weight", 1.75)
    return command


def canary_command(command: list[str]) -> list[str]:
    result = list(command)
    name_index = result.index("--experiment_name") + 1
    result[name_index] = f"{result[name_index]}_canary"
    set_option(result, "--num_episodes", 1)
    set_option(result, "--gnn_freeze_epochs", 1)
    set_option(result, "--plane_freeze_epochs", 1)
    set_option(result, "--max_train_cases", 30)
    set_option(result, "--train_sampling_size", 30)
    remove_option(result, "--train_sampling_pool_size")
    set_option(result, "--max_eval_cases", 12)
    set_switch(result, "--skip_pre_ppo_eval", True)
    set_switch(result, "--skip_epoch_eval", True)
    return result


def validate(command: list[str], *, canary: bool) -> None:
    parsed = parse_training_args(command[2:], get_config())
    if parsed.training_stage != "resource_joint":
        raise RuntimeError("Next-round command is not Stage2 resource_joint.")
    if int(parsed.max_graphs_per_forward) != 1000:
        raise RuntimeError("Next-round graph cap drifted from 1000.")
    recurrent_graphs = int(parsed.mini_batch_size) * int(parsed.data_chunk_length)
    if recurrent_graphs > int(parsed.max_graphs_per_forward):
        raise RuntimeError(
            "Next-round recurrent PPO batch exceeds the graph cap: "
            f"{parsed.mini_batch_size}*{parsed.data_chunk_length}="
            f"{recurrent_graphs} > {parsed.max_graphs_per_forward}."
        )
    if int(parsed.train_sampling_size) != (30 if canary else 240):
        raise RuntimeError("Next-round case budget drifted.")
    if not parsed.role_event_returns or not parsed.role_atomic_ppo:
        raise RuntimeError("Next round requires role-atomic event-clock PPO.")
    if any(
        abs(float(value) - 1.0) > 1e-12
        for value in (
            parsed.role_event_gae_lambda,
            parsed.plane_role_gae_lambda,
            parsed.device_role_gae_lambda,
            parsed.transporter_role_gae_lambda,
        )
    ):
        raise RuntimeError("Every next-round arm must use Monte-Carlo returns.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-tag", default=RUN_TAG)
    parser.add_argument("--suite-dir", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--source-method", default="A0_mc_control")
    parser.add_argument("--potential", type=Path, required=True)
    parser.add_argument("--dataset-dir", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--wave-output", type=Path, required=True)
    parser.add_argument("--canary-output", type=Path, required=True)
    args = parser.parse_args()
    args.python = args.python.resolve()
    args.potential = args.potential.resolve()
    for path in (
        args.source_manifest,
        args.potential,
        args.dataset_dir,
        args.python,
    ):
        if not path.resolve().exists():
            raise FileNotFoundError(path.resolve())

    potential = load_json(args.potential)
    if potential.get("status") != "calibrated":
        raise RuntimeError("Resource Potential V2 is not calibrated.")
    if (
        potential.get("potential_schema_version")
        != AircraftScheduleEnv.RESOURCE_POTENTIAL_SCHEMA_VERSION
        or potential.get("environment_semantics_version")
        != AircraftScheduleEnv.SEMANTICS_VERSION
    ):
        raise RuntimeError("Resource Potential V2 contract mismatch.")
    heldout = potential["calibration"]["heldout_metrics"]
    heldout_r2 = float(heldout["r2"])

    source = load_json(args.source_manifest.resolve())
    base = list(source["commands"][args.source_method]["argv"])
    commands = {}
    for method_id, method in METHODS.items():
        command = build_command(base, method_id, method, args=args)
        validate(command, canary=False)
        commands[method_id] = {
            **method,
            "family": "mc_cf_timing_tail_wave_a",
            "argv": command,
            "shell": shlex.join(command),
        }

    bc_path = Path(
        commands["A0_mc_control"]["argv"][
            commands["A0_mc_control"]["argv"].index(
                "--resource_bc_checkpoint"
            ) + 1
        ]
    ).resolve()
    if not bc_path.is_file():
        raise FileNotFoundError(bc_path)
    shared = {
        "schema_version": 1,
        "research_stage": "stage2_resource_joint",
        "profile": "mc_cf_timing_tail_wave_a",
        "run_tag": args.run_tag,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "code_contract": code_contract(),
        "data_contract": data_contract(args.dataset_dir.resolve()),
        "source_manifest": {
            "path": str(args.source_manifest.resolve()),
            "sha256": sha256_file(args.source_manifest.resolve()),
            "method": args.source_method,
        },
        "matched_iga_timing_dagger_boundary": {
            "path": str(bc_path),
            "sha256": sha256_file(bc_path),
            "teacher": "iga",
            "role_balanced": True,
            "timing_balanced": True,
            "dagger_schedule": [1.0, 0.7, 0.4, 0.1],
        },
        "resource_potential_v2": {
            "path": str(args.potential),
            "sha256": sha256_file(args.potential),
            "heldout_r2": heldout_r2,
            "heldout_mae": float(heldout.get("mae", 0.0)),
        },
        "screen_gate": {
            "raw_cmax_improvement_seconds": 75.0,
            "matched_iga1800_gap_seconds_max": 100.0,
            "ood_stress_regression_seconds_max": 25.0,
            "tail_regression_seconds_max": 0.0,
            "paired_ci95_upper_seconds_max": 0.0,
            "catastrophic_regression_count_500_max": 0,
            "completion_rate_min": 1.0,
            "actor_step_completion_min": 0.90,
            "cycle_count_max": 0,
        },
        "hardware_contract": {
            "gpus": [0, 1],
            "simultaneous_trainers_per_gpu": 3,
            "shared_evaluators_per_gpu": 1,
            "physical_core_isolation": True,
            "max_graphs_per_forward": 1000,
        },
        "automatic_followup_contract": {
            "wave_b": {
                "methods": "top two fully eligible Wave-A arms",
                "head_modes": ["shared", "type_adapter", "per_type"],
                "epochs": 4,
                "seeds": [1],
            },
            "formal": {
                "methods": "best eligible Wave-B arm",
                "epochs": 8,
                "seeds": [1, 2, 3],
            },
        },
    }
    wave = {
        **shared,
        "phase": "wave_a",
        "methods": METHODS,
        "evaluator_source_method": "A0_mc_control",
        "evaluator_command": commands["A0_mc_control"]["argv"],
        "commands": commands,
    }
    canary_entries = {}
    for source_key in (
        "A1_mc_cf",
        "A4_mc_cf_timing_potential",
        "A5_mc_cf_timing_potential_cvar",
    ):
        key = f"C_{source_key}"
        command = canary_command(commands[source_key]["argv"])
        validate(command, canary=True)
        canary_entries[key] = {
            "source_method": source_key,
            "argv": command,
            "shell": shlex.join(command),
        }
    canary = {
        **shared,
        "phase": "functional_memory_canary",
        "methods": canary_entries,
        "evaluator_source_method": next(iter(canary_entries)),
        "evaluator_command": next(iter(canary_entries.values()))["argv"],
        "commands": canary_entries,
    }
    atomic_json(args.wave_output.resolve(), wave)
    atomic_json(args.canary_output.resolve(), canary)
    print(json.dumps({
        "status": "prepared",
        "wave_methods": list(commands),
        "canary_methods": list(canary_entries),
        "bc_checkpoint_sha256": sha256_file(bc_path),
        "potential_heldout_r2": heldout_r2,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
