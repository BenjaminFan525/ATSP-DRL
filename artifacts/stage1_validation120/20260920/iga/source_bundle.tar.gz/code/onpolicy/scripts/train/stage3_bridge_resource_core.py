"""Execution-only 2 -> 4 rank sharding, preserving each global PPO minibatch.

Original: two logical ranks, 60 rollout / 12 backward trajectories per rank.
Expanded: four physical ranks, 30 rollout / 6 backward trajectories per rank.
Four-replica advantages are computed from metadata gathered BEFORE minibatching.
No trajectory states cross ranks; original samples, groups and update boundaries
are unchanged. Floating-point reduction/batch-shape equivalence is tolerance based.
"""
import numpy as np

from onpolicy.runner.shared.stage3_b0_engine import B0Engine
from onpolicy.runner.shared.stage3_rl_bridge_engine import GroupB0Engine
from onpolicy.utils.stage3_rl_bridge import actor_targets

VERSION = 'stage3-bridge-resource-2x12-to-4x6-v1'
PLACEMENT = {'P0_SOURCE': [0, 1, 5, 6], 'P1_GROUP': [2, 3, 4, 7]}
FIELDS = ('case_id', 'group_id', 'replica', 'seed', 'makespan', 'completed',
          'behavior_deterministic', 'forced_replay', 'policy_updates', 'population_weight')


def split_logical_shards(shards):
    if len(shards) != 2 or len(shards[0]) != len(shards[1]) or len(shards[0]) % 12:
        raise ValueError('Expected two equal logical shards with whole 12-trajectory minibatches')
    expanded = []
    for rank in range(4):
        original = shards[rank % 2]
        half = rank // 2
        expanded.append([row for first in range(0, len(original), 12)
                         for row in original[first+half*6:first+(half+1)*6]])
    return expanded


def global_targets(rows, arm, source_cost, distributed):
    if distributed is None or distributed.world_size != 4:
        raise ValueError('Resource sharding requires exactly four synchronized ranks')
    lightweight = [{k: row[k] for k in FIELDS} for row in rows]
    gathered = distributed.gather(lightweight)
    if len({len(part) for part in gathered}) != 1:
        raise ValueError('Unequal shard lengths would change collective/update boundaries')
    complete = [row for part in gathered for row in part]
    advantages, weights, audit = actor_targets(complete, arm, source_cost)
    start = sum(len(part) for part in gathered[:distributed.rank])
    return advantages[start:start+len(rows)], weights[start:start+len(rows)], audit


class ResourceGroupEngine(GroupB0Engine):
    def update(self, trajectories, mode='source', source_cost=None, *, distributed=None, **kwargs):
        if (mode != 'source' or kwargs.get('microbatch_size') != 6
                or kwargs.get('optimizer_step_per_microbatch') is not True):
            raise ValueError('Resource parallel PPO fixes physical microbatch6 and global microbatch24')
        advantages, weights, audit = global_targets(trajectories, self.bridge_arm, source_cost, distributed)
        targets = {id(row): (a, w) for row, a, w in zip(trajectories, advantages, weights)}
        def objective(rows):
            if any(id(row) not in targets for row in rows):
                raise ValueError('PPO target escaped its original global rollout batch')
            return ([targets[id(row)][0] for row in rows], [targets[id(row)][1] for row in rows])
        self.stage3_actor_objective = objective
        try:
            result = B0Engine.update(self, trajectories, mode, source_cost, distributed=distributed, **kwargs)
        finally:
            del self.stage3_actor_objective
        result.update(bridge_objective=audit, trajectory_advantages=advantages.tolist(),
            population_weights=weights.tolist(), baseline_mode=audit['advantage_mode'],
            positive_advantage_fraction=float(np.mean(advantages > 0)),
            resource_parallel={'version': VERSION, 'physical_world_size': 4,
                'logical_world_size': 2, 'physical_microbatch': 6, 'global_optimizer_trajectories': 24})
        return result
