"""Temperature schedule/queue/recovery tests, not scientific outcome evidence."""
import copy
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from onpolicy.utils.stage3_tau import (ARMS, TEMPERATURE, temperature, temperature_state,
    validate_temperature_state, training_plan, resume_cursor, TauQueue, risk_pass, select_candidate)
from onpolicy.utils.stage3_rl_bridge import actor_targets, distribution_weights
from onpolicy.utils.stage3_research import digest_json
from onpolicy.envs.HKBZ.test.test_stage3_rl_bridge import cases, group


@pytest.mark.parametrize('arm', list(ARMS))
def test_tau_schedule_boundaries_and_no_reheat(arm):
    start = ARMS[arm]['tau_start']
    assert temperature(arm, 0) == temperature(arm, 960) == start
    assert temperature(arm, 4800) == temperature(arm, 9600) == temperature(arm, 19200) == .03
    values = [temperature(arm, x) for x in range(0, 19201, 120)]
    assert all(a >= b for a, b in zip(values, values[1:]))
    assert temperature(arm, 2880) == pytest.approx((start+.03)/2)


@pytest.mark.parametrize('cursor', [-1, .0, True, 19201, None])
def test_tau_schedule_rejects_invalid_cursor(cursor):
    with pytest.raises(ValueError):
        temperature('T1_ANNEAL10', cursor)


def manifest():
    return dict(splits=dict(train_full600=cases((480, 108, 12))), training=dict(seed=2026091201),
                manifest_sha256='fixture')


def commit(m, arm='T1_ANNEAL10', world=2, episodes=9600):
    return dict(manifest_sha256='fixture', arm=arm, phase='full', world_size=world,
        schedule_sha256=digest_json(training_plan(m, world)), training_episodes=episodes,
        ranks=[dict(rank=r, state_sha256='same') for r in range(world)],
        temperature_state=temperature_state(arm, episodes))


def test_tau_resume_same_world_and_declared_transition():
    m = manifest()
    c = commit(m)
    assert resume_cursor(m, c['arm'], c, 2) == 80
    assert resume_cursor(m, c['arm'], c, 4) == 40
    c = commit(m, world=4, episodes=12000)
    assert resume_cursor(m, c['arm'], c, 4) == 50
    with pytest.raises(ValueError):
        resume_cursor(m, c['arm'], c, 2)


@pytest.mark.parametrize('bad', ['tau', 'cursor', 'sha', 'rank', 'divergence', 'early_transition'])
def test_tau_resume_rejects_uncommitted_or_changed_state(bad):
    m = manifest()
    c = commit(m)
    if bad == 'tau': c['temperature_state']['sampling_tau'] = .1
    if bad == 'cursor': c['temperature_state']['committed_episodes'] = 4800
    if bad == 'sha': c['schedule_sha256'] = 'changed'
    if bad == 'rank': c['ranks'].pop()
    if bad == 'divergence': c['ranks'][1]['state_sha256'] = 'different'
    if bad == 'early_transition': c = commit(m, episodes=4800)
    with pytest.raises(ValueError):
        resume_cursor(m, c['arm'], c, 4)


def test_tau_group_full600_k4_budget_and_pairing():
    m = manifest()
    assert distribution_weights(m['splits']['train_full600']) == dict(iid=.625, ood_stress=2.5, ood_scale=2.5)
    p2, p4 = training_plan(m, 2), training_plan(m, 4)
    assert p2[-1]['training_episodes'] == p4[-1]['training_episodes'] == 19200
    assert p2[79]['epoch'] == 4 and p2[79]['training_episodes'] == 9600
    for p in (p2, p4):
        assert all(len(shard) == 60 for b in p for shard in b['shards'])
    for epoch in (1, 4, 5, 8):
        exposure = lambda p: sorted((r['case']['path'], r['replica'], r['seed'])
            for b in p if b['epoch'] == epoch for s in b['shards'] for r in s)
        assert exposure(p2) == exposure(p4)


def test_tau_risk_cost_uses_train_B0_before_LOO_and_keeps_signs():
    rows = group((90., 100., 110., 120.))
    a, _, result = actor_targets(rows, 'T3_ANNEAL10_RISK', {'case': 100.}, arm_spec=ARMS['T3_ANNEAL10_RISK'])
    np.testing.assert_allclose(result['objective_costs'], [90., 100., 118., 138.])
    assert a[0] > 0 > a[-1] and a.sum() == pytest.approx(0.)
    for arm in ('T0_FIXED03', 'T1_ANNEAL10', 'T2_ANNEAL30'):
        _, _, result = actor_targets(rows, arm, {'case': 100.}, arm_spec=ARMS[arm])
        assert result['objective_costs'] == [90., 100., 110., 120.]


def summary(gain=.01):
    return dict(completion_rate=1., gain_fraction=gain, makespan=100*(1-gain),
        regression_over_5pct_fraction=.02, tail_makespan=100., source_tail_makespan=100.,
        profiles={p: dict(regression_fraction=0.) for p in ('resource_ood', 'resource_sparse')})


def test_tau_selection_e4_gain_and_both_resource_tail_veto():
    evaluations = {a: dict(validation=summary(.006), tune=summary(.006)) for a in ARMS}
    assert select_candidate(evaluations) is None
    evaluations['T2_ANNEAL30']['validation'] = summary(.01)
    assert select_candidate(evaluations) == 'T2_ANNEAL30'
    evaluations['T2_ANNEAL30']['tune']['profiles']['resource_sparse']['regression_fraction'] = .006
    assert select_candidate(evaluations) is None
    assert not risk_pass(evaluations['T2_ANNEAL30']['tune'])


def test_tau_queue_temperature_and_decoder_are_distinct():
    req = dict(checkpoint_sha256='c', cases_sha256='d', contract_sha256='env', code_sha256='src',
        tau=.3, seed=1, arm='T1_ANNEAL10', kind='sampling', sample_seeds=[[1]],
        manifest_sha256='m', sampling_eval_tau=.03, decoder='autoregressive_sampling')
    original = TauQueue.identity(req)
    assert original != TauQueue.identity({**req, 'sampling_eval_tau': .1})
    assert original != TauQueue.identity({**req, 'decoder': 'b0_native_hungarian'})
    assert original == TauQueue.identity(copy.deepcopy(req))


def test_tau_engine_resume_restores_temperature_optimizer_and_rng(tmp_path):
    from onpolicy.runner.shared.stage3_tau_engine import TauEngine
    from onpolicy.utils.stage3_numerics import training_state
    from onpolicy.utils.stage3_distributed import state_digest
    from onpolicy.utils.stage3_research import WORKSPACE_ROOT
    frozen = WORKSPACE_ROOT/'artifacts/stage2_frozen/20260912/manifest.json'
    runner = TauEngine(frozen, 'F_PRIVATE', arm='T1_ANNEAL10', width=1, device='cpu',
                       create_environments=False, cache_mib=0)
    try:
        runner.set_progress(2400)
        expected_tau = runner.exploration
        runner.policy_updates = 2
        cp = tmp_path/'checkpoint.pt'
        runner.save(cp, protocol_sha256='test', next_group=20, elite_buffer={}, elite_usage={}, auxiliary_steps=0)
        expected = state_digest(training_state(runner))
        expected_rng = torch.rand(4)
        runner.set_progress(9600)
        with torch.no_grad():
            next(runner.policy.ac.parameters()).add_(1.)
        payload = runner.resume(cp, protocol_sha256='test')
        assert state_digest(training_state(runner)) == expected
        assert runner.committed_episodes == 2400 and runner.exploration == expected_tau
        torch.testing.assert_close(torch.rand(4), expected_rng, rtol=0, atol=0)
        assert payload['temperature_state'] == temperature_state('T1_ANNEAL10', 2400)
        with pytest.raises(ValueError):
            runner.resume(cp, protocol_sha256='test', exploration=dict(roles=[0, 1, 2], taus=[.1]*3))
        runner._active_rollout_batch = object()
        with pytest.raises(ValueError):
            runner.set_progress(4800)
        del runner._active_rollout_batch
    finally:
        runner.close()


def test_tau_engine_group_update_preserves_behavior_and_does_not_advance():
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy
    from onpolicy.runner.shared.stage3_tau_engine import TauEngine
    from onpolicy.utils.stage3_ppo_minibatches import behavior_digest
    toy, rows, widths = minibatch_toy(24)
    runner = TauEngine.__new__(TauEngine)
    runner.__dict__.update(toy.__dict__)
    runner.bridge_arm, runner.bridge_spec = 'T0_FIXED03', ARMS['T0_FIXED03']
    runner.committed_episodes, runner.representation = 0, 'F_PRIVATE'
    runner.execution_cache, runner.zero_update_batches = None, 0
    runner.assert_optimizer_ownership = lambda: None
    for i, row in enumerate(rows):
        row.update(case_id=f'case{i//4}', group_id=f'group{i//4}', seed=i, replica=i % 4, population_weight=1.)
    before = behavior_digest(rows)
    result = runner.update(rows, source_cost={r['case_id']: 100. for r in rows},
        microbatch_size=12, optimizer_step_per_microbatch=True)
    assert result['accepted_actor_steps'] > 0 and runner.committed_episodes == 0
    assert max(widths) == 12 and behavior_digest(rows) == before


def test_tau_engine_entropy_legal_bins_are_observational_only():
    from onpolicy.runner.shared.stage3_tau_engine import TauDecisionStats
    stats = TauDecisionStats()
    logp = torch.tensor([[0., float('-inf')], [-np.log(2), -np.log(2)]])
    before = logp.clone()
    stats.add(1, logp, logp, torch.tensor([0, 1]))
    result = stats.result()['1']
    assert result['1']['decisions'] == result['2-4']['decisions'] == 1
    assert result['1']['entropy_mean'] == 0
    assert result['2-4']['entropy_mean'] == pytest.approx(np.log(2))
    assert result['2-4']['non_greedy_fraction'] == 1
    torch.testing.assert_close(logp, before, rtol=0, atol=0)


def test_tau_queue_submit_validate_both_temperatures_and_role_mix(tmp_path):
    from onpolicy.scripts.train.stage3_rl_bridge_worker import submit_evaluation, validate_request
    from onpolicy.utils.stage3_research import digest_file, read_json
    checkpoint = tmp_path/'fixture.pt'
    checkpoint.write_bytes(b'fixture-not-model')
    chosen = cases()[:2]
    m = dict(schema='stage3-tau-full600-v1', arms=ARMS, root=str(tmp_path), manifest_sha256='manifest',
        comparison_sha256='comparison', code=dict(sha256='code'), training=dict(seed=1),
        splits={s: chosen for s in ('train_full600', 'validation', 'tune')},
        diagnostic=dict(cases32=chosen), source=dict(sha256=digest_file(checkpoint)))
    ids = []
    for tau in (.03, .1):
        ids += submit_evaluation(m, checkpoint, 'T1_ANNEAL10', 9600, 'diag', split='train_full600',
                                 kind='sampling', sampling_eval_tau=tau)
    ids += submit_evaluation(m, checkpoint, 'T1_ANNEAL10', 9600, 'diag', split='train_full600',
                             kind='role_mix', role_mix=[0, 1, 0])
    ids += submit_evaluation(m, checkpoint, 'B0', 0, 'diag', split='train_full600', kind='greedy_ar')
    assert len(set(ids)) == 4
    q = TauQueue(tmp_path/'validator')
    for i in ids:
        request = read_json(q.root/'pending'/f'{i}.json')
        validate_request(m, request)
    request['decoder'] = 'wrong'
    request['cache_key'] = q.identity(request)
    with pytest.raises(ValueError):
        validate_request(m, request)


@pytest.mark.parametrize('offload', [False, True])
def test_tau_engine_real_prefix_replay_and_stale_temperature_rejection(tmp_path, offload):
    """Short diagnostic fixture only; full-trajectory GPU admission is mandatory."""
    from onpolicy.runner.shared.stage3_tau_engine import TauEngine
    from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool
    from onpolicy.utils.stage3_batched_sampling import BATCHING_VERSION
    from onpolicy.utils.stage3_research import WORKSPACE_ROOT, case_record
    runner = TauEngine(WORKSPACE_ROOT/'artifacts/stage2_frozen/20260912/manifest.json',
        'F_PRIVATE', arm='T1_ANNEAL10', device='cpu', width=4, create_environments=False, cache_mib=0,
        replay_storage=dict(directory=str(tmp_path), cache_mib=1, minimum_free_gib=0) if offload else None)
    runner.pool = EnvironmentPool(4, start_method='forkserver')
    runner.stochastic_batching = BATCHING_VERSION
    original_call = runner.pool.call
    def prefix(commands):
        results = original_call(commands)
        for i, command, _ in commands:
            if command == 'summary':
                results[i] = {**results[i], 'completed': True, 'synthetic_prefix_fixture': True}
        return results
    runner.pool.call = prefix
    try:
        case = case_record(WORKSPACE_ROOT/'onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train/case_0341')
        for cursor in (0, 2400):
            runner.set_progress(cursor)
            rows = runner.rollout([case]*4, [31, 32, 33, 34], retain=True, max_steps=2)
            assert all(row['synthetic_prefix_fixture'] for row in rows)
            assert runner.replay_metrics(rows)['max_logp_error'] <= .002
            assert runner.last_decision_stats
            for i, row in enumerate(rows):
                row.update(group_id='prefix', replica=i, population_weight=1.)
            runner.set_progress(cursor+120)
            if cursor == 2400:
                with pytest.raises(ValueError, match='on-policy|exploration'):
                    runner.update(rows, source_cost={case['path']: 8000.}, microbatch_size=4,
                                  optimizer_step_per_microbatch=True)
        assert runner.policy_updates == 0
    finally:
        runner.close()
