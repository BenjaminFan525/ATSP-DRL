"""Focused contracts for the Stage2 role-credit Wave A implementation."""

from __future__ import annotations

import numpy as np
import json

from onpolicy.config.config import get_config
from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.stage2_event_credit_autopilot import (
    analyze_phase,
    build_followup_manifest,
)


def test_event_credit_config_defaults_preserve_legacy_elapsed_returns():
    args = get_config().parse_args([])
    assert args.role_event_credit_mode == 'elapsed'
    assert np.isclose(args.role_event_credit_uniform_mix, 0.15)


def test_environment_credit_extracts_and_runner_aligns_record_identity():
    env = AircraftScheduleEnv.__new__(AircraftScheduleEnv)
    env.total_time = 100.0
    env.trajectory_log = [{
        'step_idx': 0,
        'agent_id': 0,
        'start_time': 0.0,
        'end_time': 40.0,
    }]
    env.device_trajectory_log = [
        {
            'step_idx': 1,
            'agent_id': 1,
            'start_time': 30.0,
            'end_time': 80.0,
            'duration': 50.0,
            'waiting_time_at_dispatch': 10.0,
            'predicted_lateness_at_dispatch': 5.0,
            'is_transporter': False,
        },
        {
            'step_idx': 2,
            'agent_id': 2,
            'start_time': 80.0,
            'end_time': 100.0,
            'duration': 20.0,
            'waiting_time_at_dispatch': 3.0,
            'is_transporter': True,
        },
    ]

    payload = env.get_role_event_credit_weights()
    assert payload['global_frontier_seconds'] == 100.0
    assert payload['unattributed_terminal_seconds'] == 0.0
    assert payload['role_frontier_seconds']['transporter'] == 20.0
    assert payload['weights'][(1, 1)]['request_wait_seconds'] == 10.0

    aligned = HKBZ_Runner._role_event_credit_tensor(
        [payload],
        np.asarray([100.0], dtype=np.float32),
        rollout_steps=3,
        n_envs=1,
        n_agents=3,
    )
    assert aligned.shape == (3, 1, 3)
    assert np.count_nonzero(aligned) == 3
    assert aligned[2, 0, 2] == payload['weights'][(2, 2)]['weight']


def _write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding='utf-8')


def _evaluation(raw, selection, ood_stress):
    return {
        'summary': {
            'eval_case_count': 60,
            'eval_selection_score': selection,
            'eval_raw_makespan': raw,
            'eval_iid_makespan': raw - 100.0,
            'eval_distribution_ood_stress_makespan': ood_stress,
            'eval_distribution_ood_scale_makespan': raw - 200.0,
            'eval_tail_makespan': raw + 1000.0,
            'eval_completion_rate': 1.0,
            'eval_cycle_count': 0,
            'eval_timeout_count': 0,
        },
        'cases': [
            {
                'case_key': f'tune/case_{index:04d}',
                'case_sha256': f'{index:064x}',
            }
            for index in range(60)
        ],
    }


def _screen_gate():
    return {
        'raw_cmax_improvement_seconds': 75.0,
        'matched_iga1800_gap_seconds_max': 100.0,
        'ood_stress_regression_seconds_max': 25.0,
        'completion_rate_min': 1.0,
        'actor_step_completion_min': 0.90,
        'cycle_count_max': 0,
    }


def test_autopilot_applies_scientific_and_health_gates(tmp_path):
    command = [
        'python', 'train.py', '--experiment_name', 'event_arm',
        '--num_episodes', '1',
    ]
    manifest = tmp_path / 'wave.json'
    _write_json(manifest, {
        'phase': 'wave_a',
        'screen_gate': _screen_gate(),
        'commands': {'A': {'argv': command}},
    })
    run = tmp_path / 'results/event_arm/run1'
    _write_json(run / 'run_status.json', {
        'status': 'completed',
        'training_stage': 'resource_joint',
        'phase': 'resource_joint_completed',
        'canary_rejected': False,
        'actor_update_health': {
            'step_completion_rate': 0.95,
            'zero_update_shards': 0,
        },
    })
    _write_json(
        run / 'evaluations/pre_ppo.json',
        _evaluation(8800.0, 9400.0, 9600.0),
    )
    _write_json(
        run / 'evaluations/epoch_1.json',
        _evaluation(8680.0, 9250.0, 9610.0),
    )
    checkpoint = run / 'models/checkpoint_Best.pt'
    checkpoint.parent.mkdir(parents=True)
    checkpoint.write_bytes(b'checkpoint')

    selected = analyze_phase(
        manifest, tmp_path / 'results', tmp_path / 'selection.json',
        iga1800_raw=8592.85,
    )
    assert selected['selected_method'] == 'A'
    assert selected['methods'][0]['eligible'] is True
    assert np.isclose(
        selected['methods'][0]['raw_cmax_improvement_seconds'], 120.0
    )

    _write_json(
        run / 'evaluations/epoch_1.json',
        _evaluation(8730.0, 9250.0, 9610.0),
    )
    rejected = analyze_phase(
        manifest, tmp_path / 'results', tmp_path / 'rejected.json',
        iga1800_raw=8592.85,
    )
    assert rejected['selected_method'] is None
    assert 'raw_cmax_improvement_below_gate' in (
        rejected['methods'][0]['gate_reasons']
    )
    assert 'matched_iga1800_gap_above_gate' in (
        rejected['methods'][0]['gate_reasons']
    )


def test_autopilot_builds_fresh_frozen_multiseed_formal(tmp_path):
    base = [
        'python', 'train.py', '--experiment_name', 'wave_a_A',
        '--num_episodes', '2', '--gnn_freeze_epochs', '2',
        '--plane_freeze_epochs', '2', '--seed', '1',
        '--eval_case_offset', '0', '--eval_partition_seed', '1',
        '--eval_partition_stratify_by', 'profile', '--max_eval_cases', '60',
        '--early_stop_patience', '0', '--use_eval', '--resume_stage2',
        '--skip_pre_ppo_eval', '--skip_epoch_eval',
    ]
    source = tmp_path / 'wave_a.json'
    _write_json(source, {
        'screen_gate': _screen_gate(),
        'commands': {'A': {'argv': base, 'hypothesis': 'test'}},
    })
    output = tmp_path / 'formal.json'
    manifest = build_followup_manifest(
        source, ('A',), output, phase='formal', run_tag='study',
        epochs=8, seeds=(1, 2, 3), eval_offset=60,
    )
    assert tuple(manifest['commands']) == ('A_seed1', 'A_seed2', 'A_seed3')
    for seed, entry in enumerate(manifest['commands'].values(), start=1):
        command = entry['argv']
        assert command[command.index('--num_episodes') + 1] == '8'
        assert command[command.index('--gnn_freeze_epochs') + 1] == '8'
        assert command[command.index('--plane_freeze_epochs') + 1] == '8'
        assert command[command.index('--eval_case_offset') + 1] == '60'
        assert command[command.index('--seed') + 1] == str(seed)
        assert '--resume_stage2' not in command
        assert '--skip_pre_ppo_eval' not in command
        assert '--skip_epoch_eval' not in command
        assert '--use_eval' in command
