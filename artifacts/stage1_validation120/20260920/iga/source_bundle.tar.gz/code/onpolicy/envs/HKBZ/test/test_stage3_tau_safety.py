"""Storage equivalence and deterministic safety fault injection; not reward evidence."""
import os

import numpy as np
import pytest
import torch
from torch_geometric.data import HeteroData

from onpolicy.utils.stage3_replay_store import GraphReplayStore
from onpolicy.utils.stage3_host_guard import (GIB, PressureGuard, progress_issue,
                                            stop_workload, read_json)
from onpolicy.utils.stage3_distributed import state_digest
from onpolicy.utils.stage3_ppo_minibatches import behavior_digest


def graph():
    data = HeteroData()
    data['plane'].x = torch.arange(192, dtype=torch.float32).reshape(24, 8)
    data['plane', 'next', 'plane'].edge_index = torch.tensor([[1, 2], [2, 3]])
    data['plane', 'next', 'plane'].edge_attr = torch.tensor([[float('-inf')], [3.]])
    data['description'] = 'immutable observation'
    return data


def test_replay_store_lossless_graph_dtype_shape_and_no_rng_change(tmp_path):
    store = GraphReplayStore(directory=str(tmp_path), cache_mib=1, minimum_free_gib=0)
    try:
        value = graph()
        original = state_digest(value.to_dict())
        rng = torch.get_rng_state().clone()
        field = np.ones((104, 1, 64), dtype=np.float32)
        packed = store.pack(dict(graph=value, hidden=field, old_logp=np.arange(104)))
        assert packed['hidden'] is field
        assert store.reads == 0
        assert state_digest(packed['graph'].to_dict()) == original
        assert packed['graph'] is packed['graph']
        assert store.hits == 2
        assert torch.equal(rng, torch.get_rng_state())
        assert store.report()['graph_cache_peak_bytes'] <= store.limit
        assert store.report()['compressed_bytes'] < store.report()['serialized_bytes']
    finally:
        store.close()
    with pytest.raises(RuntimeError, match='released'):
        packed['graph']


def test_replay_store_eviction_and_out_of_order_reads(tmp_path):
    store = GraphReplayStore(directory=str(tmp_path), cache_mib=.01, minimum_free_gib=0)
    try:
        values = []
        for i in range(20):
            data = graph()
            data['plane'].x += i
            values.append(store.pack(dict(graph=data, mask=np.ones(104))))
        for i in (19, 1, 10, 0, 19):
            assert values[i]['graph']['plane'].x[0, 0].item() == i
        assert store.peak_cache_bytes <= store.limit
    finally:
        descriptor = store.file.fileno()
        store.close()
    with pytest.raises(OSError):
        os.fstat(descriptor)
    assert list(tmp_path.iterdir()) == []


def test_replay_store_behavior_hash_without_graph_io(tmp_path):
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy
    _, rows, _ = minibatch_toy(12)
    expected = behavior_digest(rows)
    store = GraphReplayStore(directory=str(tmp_path), cache_mib=0, minimum_free_gib=0)
    try:
        for row in rows:
            row['states'] = [store.pack(s) for s in row['states']]
        assert behavior_digest(rows) == expected and store.reads == 0
        rows[0]['states'][0]['old_logp'][0] += .1
        assert behavior_digest(rows) != expected
    finally:
        store.close()


def test_replay_store_exact_ppo_update_optimizer_and_normalizer(tmp_path):
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy, update
    from onpolicy.utils.stage3_ppo_transaction import snapshot
    torch.manual_seed(57)
    reference, rows, _ = minibatch_toy(24)
    torch.manual_seed(57)
    packed_runner, packed_rows, _ = minibatch_toy(24)
    assert state_digest(snapshot(reference)) == state_digest(snapshot(packed_runner))
    store = GraphReplayStore(directory=str(tmp_path), cache_mib=.01, minimum_free_gib=0)
    try:
        for row in packed_rows:
            row['states'] = [store.pack(s) for s in row['states']]
        assert behavior_digest(rows) == behavior_digest(packed_rows)
        expected = update(reference, rows)
        actual = update(packed_runner, packed_rows)
        assert state_digest(snapshot(reference)) == state_digest(snapshot(packed_runner))
        assert state_digest(expected) == state_digest(actual)
    finally:
        store.close()


def test_replay_store_rejects_non_detached_and_corrupt_data(tmp_path):
    store = GraphReplayStore(directory=str(tmp_path), cache_mib=0, minimum_free_gib=0)
    try:
        with pytest.raises(ValueError, match='detached CPU'):
            store.pack(dict(graph=torch.ones(4, requires_grad=True)))
        state = store.pack(dict(graph=graph()))
        os.ftruncate(store.file.fileno(), 0)
        with pytest.raises(OSError, match='Truncated'):
            state['graph']
    finally:
        store.close()


def test_replay_store_refuses_ssd_exhaustion_before_creating_file(tmp_path, monkeypatch):
    from types import SimpleNamespace
    monkeypatch.setattr('onpolicy.utils.stage3_replay_store.shutil.disk_usage',
                        lambda _: SimpleNamespace(free=GIB))
    with pytest.raises(RuntimeError, match='SSD space'):
        GraphReplayStore(directory=str(tmp_path), minimum_free_gib=16)
    assert list(tmp_path.iterdir()) == []


def sample(available=100, psi=0):
    return dict(memory=dict(MemAvailable=available*GIB),
                pressure=dict(memory=dict(full=dict(avg10=psi))), scratch_free_bytes=100*GIB)


def test_host_guard_memory_and_pressure_hysteresis():
    guard = PressureGuard()
    assert guard.check(sample(7), 0) is None
    assert guard.check(sample(7), 19) is None
    assert 'Sustained' in guard.check(sample(7), 20)
    assert guard.check(sample(100), 21) is None
    assert guard.check(sample(100, 11), 22) is None
    assert 'Sustained' in guard.check(sample(100, 11), 42)
    assert 'emergency' in guard.check(sample(3), 43)


def test_host_guard_transient_pressure_recovers_and_disk_is_bounded():
    guard = PressureGuard()
    assert guard.check(sample(7), 0) is None
    assert guard.check(sample(), 15) is None
    assert guard.check(sample(7), 30) is None
    assert guard.check(sample(7), 40) is None
    low_disk = sample()
    low_disk['scratch_free_bytes'] = 15*GIB
    assert 'SSD' in guard.check(low_disk, 41)


def test_progress_guard_fresh_heartbeat_cannot_hide_stalled_compute():
    hb = dict(status='running', event='post_update_replay', last_progress_unix=1, heartbeat_unix=2000)
    assert 'computational progress' in progress_issue(hb, 0, 2000)
    hb['last_progress_unix'] = 1950
    assert progress_issue(hb, 0, 2000) is None
    hb['heartbeat_unix'] = 1800
    assert 'heartbeat' in progress_issue(hb, 0, 2000)


def test_progress_guard_startup_idle_and_terminal_states():
    assert progress_issue(None, 0, 100) is None
    assert 'initialize' in progress_issue(None, 0, 901)
    assert progress_issue(dict(status='completed'), 0, 9000) is None
    assert 'failed' in progress_issue(dict(status='failed', error='OOM'), 0, 1)
    assert progress_issue(dict(status='running', event='validator_idle',
        heartbeat_unix=9000, last_progress_unix=1), 0, 9000) is None


def test_host_guard_stops_only_owned_services_and_retains_files(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setattr('onpolicy.utils.stage3_host_guard.subprocess.run',
                        lambda command, **kw: calls.append((command, kw)))
    checkpoint = tmp_path/'checkpoint.pt'
    checkpoint.write_bytes(b'preserve this checkpoint')
    stop_workload(tmp_path, 'hkbz-stage3-tau-test', 'injected pressure', sample())
    assert calls[0][0] == ['systemctl', '--user', 'stop', '--no-block',
        'hkbz-stage3-tau-test-training.service', 'hkbz-stage3-tau-test-validator.service']
    assert checkpoint.read_bytes() == b'preserve this checkpoint'
    assert read_json(tmp_path/'status.json')['status'] == 'failed'
    assert read_json(tmp_path/'guard_failure.json')['automatic_retry'] is False


def test_host_guard_capacity_waves_use_unique_completion_names():
    import inspect
    from onpolicy.scripts.train.run_stage3_tau import TauSuite
    from onpolicy.scripts.train.run_stage3_rl_bridge import BridgeSuite
    source = inspect.getsource(TauSuite.admission)
    assert "execution_tag=f'capacity_wave{index}'" in source
    assert 'execution_tag' in inspect.signature(BridgeSuite.execute).parameters
