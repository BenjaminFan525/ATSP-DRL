"""Regression checks for nested search accounting and warm-start identity."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from onpolicy.envs.HKBZ.experiment import run_stage1_nested_iga as iga


class FakeEnv:
    SEMANTICS_VERSION = "test"
    n_plane_agents = 1
    job_code_list = ["job"]
    site_code_list = ["site"]

    def __init__(self, config):
        pass

    def close(self):
        pass


def fake_evaluate(config, chromosome, max_steps, deadline=None, record=False):
    return {
        "completed": True, "makespan": float(np.sum(chromosome)),
        "deadline_interrupted": False, "error": None,
        "completion": {"completed": True}, "wall_seconds": 0.0,
        "aircraft_resource_wait": {},
    }


class NestedIGATest(unittest.TestCase):
    def test_nested_incumbent_is_resolved_and_search_reaches_next_generation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            identity = {"case": "case_0001", "case_path": str(root / "case_0001")}
            task = dict(
                identity=identity, max_steps=4000, seed=20260824, population=3,
                max_generations=2, cumulative_budget=180.0, additional_budget=180.0,
                warm_budget=180.0, phase_dir=str(root / "iga180"),
                run_contract_sha256="contract",
            )
            with patch.object(iga, "AircraftScheduleEnv", FakeEnv), \
                    patch.object(iga, "case_identity", return_value=identity), \
                    patch.object(iga, "env_config", return_value={}), \
                    patch.object(iga, "evaluate", side_effect=fake_evaluate):
                first = iga.search_case(task)
                task.update(
                    cumulative_budget=1800.0, additional_budget=1620.0,
                    phase_dir=str(root / "iga1800"), warm_path=first["teacher"],
                )
                second = iga.search_case(task)
            search = second["search"]
            self.assertEqual(search["completed_generations"], 2)
            self.assertEqual(search["evaluated_candidates"], 5)
            self.assertEqual(search["inherited_verified_candidates"], 1)
            self.assertEqual(search["candidate_history"][0]["resolved"], 3)
            self.assertEqual(search["configured_additional_budget_seconds"], 1620)
            self.assertLessEqual(second["makespan"], first["makespan"])
            self.assertEqual(search["resource_n_var"], 0)
            self.assertEqual(second["resource_policy"], "heuristic")

    def test_warm_start_rejects_different_case_environment_or_budget(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "warm.json"
            teacher = {
                "case_sha256": "case_a", "resource_policy": "heuristic",
                "completed": True, "completion_verified": True, "makespan": 10,
                "search": {"nominal_cumulative_budget_seconds": 180, "chromosome": [0.5, 0.5]},
            }
            path.write_text(json.dumps(teacher))
            for expected, budget in (
                ({"case_sha256": "case_b"}, 180),
                ({"resource_policy": "drl"}, 180),
                ({"case_sha256": "case_a"}, 90),
            ):
                with self.subTest(expected=expected, budget=budget), self.assertRaises(ValueError):
                    iga.load_warm(path, expected, 2, budget)

    def test_dataset_payload_mutation_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            case = Path(directory)
            for name in iga.CASE_FILES:
                (case / name).write_text("{}")
            fingerprints = {name: iga._sha256_file(case / name) for name in iga.CASE_FILES}
            (case / "metadata.json").write_text(json.dumps({
                "fingerprints": {"case_sha256": "original", "files": fingerprints},
                "profile": "test", "distribution": "iid",
            }))
            self.assertEqual(iga.case_identity(case)["case_sha256"], "original")
            (case / "flights.json").write_text("[]")
            with self.assertRaises(ValueError):
                iga.case_identity(case)


if __name__ == "__main__":
    unittest.main()
