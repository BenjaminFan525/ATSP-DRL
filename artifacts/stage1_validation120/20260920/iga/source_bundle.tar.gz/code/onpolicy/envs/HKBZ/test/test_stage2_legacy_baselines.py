"""Contracts for the matched-budget pre-matching Stage2 baselines."""

from pathlib import Path
import unittest

from onpolicy.config.config import get_config
from onpolicy.scripts.train.prepare_stage2_legacy_baselines import (
    METHODS,
    configure,
)


ROOT = Path(__file__).resolve().parents[4]


def option(command, flag):
    index = command.index(flag)
    return command[index + 1]


class Stage2LegacyBaselineTest(unittest.TestCase):
    def test_legacy_compatibility_is_opt_in(self):
        parser = get_config()
        self.assertFalse(parser.parse_args([]).device_bc_legacy_noop_timing)
        self.assertTrue(parser.parse_args([
            '--device_bc_legacy_noop_timing'
        ]).device_bc_legacy_noop_timing)

    def test_three_arms_form_the_registered_factorial_comparison(self):
        self.assertEqual(tuple(METHODS), (
            'L0_legacy_full',
            'L1_legacy_ranking_only',
            'L2_legacy_timing_only',
        ))
        self.assertGreater(METHODS['L0_legacy_full']['ranking_coef'], 0.0)
        self.assertGreater(METHODS['L0_legacy_full']['timing_coef'], 0.0)
        self.assertGreater(
            METHODS['L1_legacy_ranking_only']['ranking_coef'], 0.0
        )
        self.assertEqual(
            METHODS['L1_legacy_ranking_only']['timing_coef'], 0.0
        )
        self.assertEqual(
            METHODS['L2_legacy_timing_only']['ranking_coef'], 0.0
        )
        self.assertGreater(
            METHODS['L2_legacy_timing_only']['timing_coef'], 0.0
        )

    def test_commands_match_current_wave_budget_and_keep_old_decoder(self):
        for method_id, method in METHODS.items():
            command = configure(
                ['python', 'train.py'], method_id, method, 'unit_test'
            )
            self.assertEqual(option(command, '--seed'), '1')
            self.assertEqual(option(command, '--max_train_cases'), '240')
            self.assertEqual(option(command, '--train_sampling_size'), '240')
            self.assertEqual(option(command, '--device_bc_pretrain_epochs'), '1')
            self.assertEqual(
                option(command, '--device_bc_max_rollouts_per_epoch'), '10'
            )
            self.assertEqual(option(command, '--max_graphs_per_forward'), '1000')
            self.assertEqual(
                option(command, '--device_bc_categorical_loss_coef'), '1.0'
            )
            self.assertEqual(
                option(command, '--device_bc_assignment_loss_coef'), '0.0'
            )
            self.assertNotIn('--device_global_matching', command)
            self.assertNotIn('--device_resource_adapter', command)

    def test_launcher_preserves_physical_core_isolation_and_shared_eval(self):
        launcher = (
            ROOT / 'onpolicy/scripts/train/'
            'launch_stage2_legacy_baselines_gpu0.sh'
        ).read_text(encoding='utf-8')
        for cpu_set in (
            '0-17,72-89',
            '18-35,90-107',
            '36-53,108-125',
            '54-69,126-141',
            '70-71,142-143',
        ):
            self.assertIn(cpu_set, launcher)
        self.assertIn('shared_hkbz_evaluator.py', launcher)
        self.assertIn('widths = [36, 36, 36, 32, 4]', launcher)


if __name__ == '__main__':
    unittest.main()
