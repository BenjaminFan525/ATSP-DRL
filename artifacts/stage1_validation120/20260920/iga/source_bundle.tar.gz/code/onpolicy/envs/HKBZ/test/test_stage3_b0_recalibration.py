"""Synthetic admission/orchestration tests, not scientific trajectory evidence."""
import copy
from pathlib import Path
from types import SimpleNamespace

import pytest

from onpolicy.envs.HKBZ.test.test_stage3_b0 import queue_fixture, MANIFEST
from onpolicy.envs.HKBZ.test.test_stage3_b0_acceleration import synthetic_evidence
from onpolicy.utils.stage3_b0_protocol import (
    B0_SHA, EVALUATION, LOCAL_BASELINE, comparison_contract, baseline_costs, submit, queue,
)
from onpolicy.utils.stage3_b0_recalibration import (
    strict_pairs, seal_pairing, historical_report, evidence_identity, audit_result,
    diagnostic_costs, fresh_initialization,
)
from onpolicy.utils.stage3_research import atomic_json, digest_json, digest_file, read_json


def local_fixture(tmp_path):
    m, case, row, result = synthetic_evidence(tmp_path)
    case.update(name="synthetic", content_sha256="fixture", case_sha256="fixture")
    row["steps"] = 5
    m.update(baseline_reference=copy.deepcopy(LOCAL_BASELINE), acceleration={"version": 2})
    m["splits"].update(validation=[], tune=[])
    checkpoint = tmp_path / "synthetic.pt"
    checkpoint.write_bytes(b"fixture-not-an-actual-checkpoint")
    init = tmp_path / "initialization/b0/rank0/initialization.json"
    atomic_json(init, {"checkpoint": str(checkpoint), "checkpoint_sha256": digest_file(checkpoint),
        "source_sha256": B0_SHA, "protocol_sha256": m["manifest_sha256"],
        "all_model_tensors_exact": True, "zero_rl_updates": True, "fresh_from_frozen_b0": True})
    evidence = tmp_path / "synthetic_result.json"
    atomic_json(evidence, result)
    return m, case, row, {str(evidence): digest_file(evidence)}


def test_local_pairing_rejects_equal_cost_different_actions(tmp_path):
    _, case, row, _ = local_fixture(tmp_path)
    assert strict_pairs([row], [dict(row)], [case])["passed"]
    report = strict_pairs([row], [{**row, "action_sha256": "b" * 64}], [case])
    assert not report["passed"] and report["differences"][case["path"]]["cost_delta"] == 0
    assert not strict_pairs([row], [{**row, "steps": 6}], [case])["passed"]
    assert strict_pairs([row], [{**row, "makespan": 100. + 1e-7}], [case])["passed"]
    assert not strict_pairs([row], [{**row, "makespan": 100. + 2e-6}], [case])["passed"]
    for native, private, cases in (([], [], []), ([row], [], [case]),
                                    ([row, row], [row, row], [case, case])):
        with pytest.raises(ValueError):
            strict_pairs(native, private, cases)
    for value in (None, True, 0, -1, 1.5):
        with pytest.raises(ValueError, match="step counts"):
            strict_pairs([row], [{**row, "steps": value}], [case])


def test_local_baseline_requires_complete_bound_pairing(tmp_path):
    m, case, row, evidence = local_fixture(tmp_path)
    costs = {case["path"]: row["makespan"]}
    record = {"costs": costs, "costs_sha256": digest_json(costs), "cases": [row],
        "source_sha256": B0_SHA, "protocol_sha256": m["manifest_sha256"],
        "evaluation": EVALUATION, "baseline_reference": LOCAL_BASELINE}
    atomic_json(tmp_path / "baselines.json", record)
    with pytest.raises(FileNotFoundError):
        baseline_costs(m)
    seal_pairing(m, [row], [dict(row)], [case], "local_diagnostic_pairing.json", evidence)
    assert diagnostic_costs(m) == costs
    with pytest.raises(FileNotFoundError):
        baseline_costs(m)  # A partial technical diagnostic never admits train().
    path = seal_pairing(m, [row], [dict(row)], [case], "local_pairing_admission.json", evidence,
        baseline_cases_sha256=digest_json([row]), baseline_costs_sha256=digest_json(costs))
    record["local_pairing_sha256"] = digest_file(path)
    atomic_json(tmp_path / "baselines.json", record)
    assert baseline_costs(m) == costs
    tampered = copy.deepcopy(record)
    tampered["cases"][0]["action_sha256"] = "b" * 64
    atomic_json(tmp_path / "baselines.json", tampered)
    with pytest.raises(ValueError, match="rows/costs"):
        baseline_costs(m)
    atomic_json(tmp_path / "baselines.json", record)
    proof = read_json(path)
    proof["private_cases"][0]["action_sha256"] = "b" * 64
    atomic_json(path, proof)
    record["local_pairing_sha256"] = digest_file(path)
    atomic_json(tmp_path / "baselines.json", record)
    with pytest.raises(ValueError, match="no longer exact"):
        baseline_costs(m)


def test_historical_difference_is_reported_not_passed_or_used_as_gate(tmp_path):
    m, case, row, _ = local_fixture(tmp_path)
    m["splits"]["tune"] = [case]
    m["diagnostic"]["initial_native_tune_costs"] = {"fixture": 101.}
    release = tmp_path / "release"
    source = release / "results/b0_source_evaluation.json"
    atomic_json(source, {"synthetic_historical_cost": 101.})
    before = digest_file(source)
    m["source"]["manifest"] = str(release / "manifest.json")
    report = historical_report(m, {case["path"]: 100.})
    assert not report["historical_costs_exact"] and report["mismatch_count"] == 1
    assert not report["required_for_training_admission"] and not report["source_results_modified"]
    assert "passed" not in report and digest_file(source) == before
    assert report["historical_mean"] == 101. and report["local_mean"] == 100.


def test_local_raw_diag_is_not_a_training_bypass(tmp_path):
    m, checkpoint, _ = queue_fixture(tmp_path)
    m.update(baseline_reference=LOCAL_BASELINE, acceleration={"version": 2})
    m["diagnostic"]["cases32"] = list(m["splits"]["train_full600"])
    request = submit(m, checkpoint, "C_PRIVATE", 0, "F_PRIVATE", split="train_full600", raw_initialization=True)
    assert read_json(queue(m).root / "pending" / (request + ".json"))["raw_initialization"]
    with pytest.raises(ValueError, match="restricted"):
        submit(m, checkpoint, "C_PRIVATE", 32, "F_PRIVATE", split="train_full600", raw_initialization=True)
    m["diagnostic"]["cases32"] = []
    with pytest.raises(ValueError, match="restricted"):
        submit(m, checkpoint, "C_PRIVATE", 0, "F_PRIVATE", split="train_full600", raw_initialization=True, tag="_bad")
    with pytest.raises(FileNotFoundError):
        baseline_costs(m)


def test_local_comparison_identity_is_explicit_and_not_legacy(tmp_path):
    m, _, _, _ = local_fixture(tmp_path)
    assert "baseline_reference" not in comparison_contract(m["splits"])
    assert digest_json(comparison_contract(m["splits"])) != digest_json(comparison_contract(m["splits"], LOCAL_BASELINE))
    with pytest.raises(ValueError, match="Unknown B0"):
        comparison_contract(m["splits"], {**LOCAL_BASELINE, "reuse_historical_trajectories": True})


def test_local_result_audit_binds_native_and_private_queue_identity(tmp_path):
    m, case, row, _ = local_fixture(tmp_path)
    for private, checkpoint in ((False, B0_SHA), (True, "synthetic-private-checkpoint")):
        expected = evidence_identity(m, [case], checkpoint, private)
        result = {**expected, "training_episodes": 0, "ok": True, "error": None,
            "evaluation": {"evaluation_protocol": EVALUATION, "source_sha256": B0_SHA, "cases": [row]}}
        assert audit_result(m, result, [case], expected) == [row]
        for key in expected:
            with pytest.raises(ValueError, match="provenance differs"):
                audit_result(m, {**result, key: "bad"}, [case], expected)


def test_local_controller_audits_pairs_instead_of_historical_costs(tmp_path):
    from onpolicy.scripts.train.stage3_b0_recalibrated import RecalibratedB0Suite
    m, case, row, _ = local_fixture(tmp_path)
    m["resources"] = {"plan": {}, "validator_queue": str(tmp_path / "validator")}
    m["diagnostic"]["initial_native_tune_costs"] = {"fixture": 999.}
    suite = RecalibratedB0Suite(m, tmp_path / "manifest.json")
    for private, request in ((False, "native"), (True, "private")):
        expected = evidence_identity(m, [case], "private-sha" if private else B0_SHA, private)
        result = {**expected, "request_id": request, "training_episodes": 0, "ok": True, "error": None,
            "evaluation": {"evaluation_protocol": EVALUATION, "source_sha256": B0_SHA, "cases": [dict(row)]}}
        suite.calibration_requests[request] = ([case], expected, private)
        atomic_json(suite.queue.root / "results" / (request + ".json"), result)
    suite.check_available_native_tune()
    assert suite.paired_audited == {case["path"]}
    assert not (tmp_path / "training_admission.json").exists()
    # Fresh controller must reject an action mismatch even when costs are equal.
    bad = read_json(suite.queue.root / "results/private.json")
    bad["evaluation"]["cases"][0]["action_sha256"] = "b" * 64
    atomic_json(suite.queue.root / "results/private.json", bad)
    again = RecalibratedB0Suite(m, tmp_path / "manifest.json")
    again.calibration_requests = suite.calibration_requests
    with pytest.raises(RuntimeError, match="no RL admitted"):
        again.check_available_native_tune()
    assert not read_json(tmp_path / "local_pairing_early_failure.json")["formal_training_admitted"]


def test_local_training_entry_rejects_unbound_pairing_before_model_allocation(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_b0_worker as worker
    m, _, _, _ = local_fixture(tmp_path)
    atomic_json(tmp_path / "baselines.json", {"synthetic": True})
    atomic_json(tmp_path / "sampling_admission.json", {"synthetic": True})
    atomic_json(tmp_path / "local_pairing_admission.json", {"synthetic": True})
    atomic_json(tmp_path / "training_admission.json", {"passed": True, "world_size": 8,
        "protocol_sha256": m["manifest_sha256"], "baseline_sha256": digest_file(tmp_path / "baselines.json"),
        "sampling_sha256": digest_file(tmp_path / "sampling_admission.json")})
    monkeypatch.setattr(worker, "engine", lambda *a, **kw: pytest.fail("Must reject before model allocation"))
    with pytest.raises(ValueError, match="Strict local pairing"):
        worker.train(SimpleNamespace(world_size=8, until=7680), m, None, None)


def test_local_fresh_initialization_copies_frozen_b0_without_reuse(tmp_path):
    import torch
    m = {"root": str(tmp_path), "source": {"manifest": str(MANIFEST)},
        "manifest_sha256": "synthetic-protocol", "comparison_sha256": "synthetic-comparison", "code": {"sha256": "code"}}
    path = fresh_initialization(m)
    payload = torch.load(path, map_location="cpu", weights_only=False)
    assert payload["initialization_only"] and not payload["diagnostic_only"]
    assert payload["policy_updates"] == payload["training_episodes"] == 0
    assert payload["source_sha256"] == B0_SHA and payload["inference_batching"] == "per_case_v1"
    proof = read_json(path.parent / "initialization.json")
    assert proof["all_model_tensors_exact"] and proof["fresh_from_frozen_b0"]
    assert proof["trajectory_admission"] == "pending"
