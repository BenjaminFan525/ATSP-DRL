"""Focused contracts for structured DeviceBC and paired Stage2 credit."""

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from onpolicy.algorithms.gnn_mappo.algorithm.gnn_actor_critic import (
    GNN_Actor_Critic,
)
from onpolicy.algorithms.gnn_mappo.gnn_mappo import MAPPO_Trainer
from onpolicy.algorithms.utils.ptr_actor import DeviceRequestPtrActor
from onpolicy.config.config import get_config
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train.prepare_stage2_structured_credit import (
    apply_common,
    validate,
)
from onpolicy.utils.shared_buffer import SharedReplayBuffer


class Stage2StructuredCreditTest(unittest.TestCase):
    def test_new_controls_are_backward_compatible_by_default(self):
        args = get_config().parse_args([])
        self.assertFalse(args.device_timing_head)
        self.assertFalse(args.device_global_matching)
        self.assertEqual(args.device_bc_ranking_loss_coef, 0.0)
        self.assertEqual(args.device_bc_timing_loss_coef, 0.0)
        self.assertEqual(args.cvar_case_metric, 'cmax')
        self.assertEqual(args.paired_case_baseline_coef, 0.0)
        self.assertEqual(args.paired_case_baseline_scope, 'returns')
        self.assertFalse(args.actor_kl_backtrack)
        self.assertFalse(args.adaptive_bc_reference_kl)
        self.assertFalse(args.reset_value_normalizer_before_ppo)

    def test_actor_only_paired_baseline_buffer_contract(self):
        buffer = SharedReplayBuffer.__new__(SharedReplayBuffer)
        buffer.n_rollout_threads = 3
        buffer.actor_case_baseline_offsets = np.zeros(3, dtype=np.float32)
        buffer.set_actor_case_baseline_offsets([4.0, 5.0, 6.0])
        np.testing.assert_allclose(
            buffer.actor_case_baseline_offsets, [4.0, 5.0, 6.0]
        )
        with self.assertRaisesRegex(ValueError, 'shape'):
            buffer.set_actor_case_baseline_offsets([1.0, 2.0])

    def test_actor_backtrack_restores_adam_and_reuses_exact_gradient(self):
        parameter = torch.nn.Parameter(torch.tensor([1.0]))
        module = torch.nn.Module()
        module.register_parameter('weight', parameter)
        optimizer = torch.optim.Adam([parameter], lr=0.1)
        trainer = MAPPO_Trainer.__new__(MAPPO_Trainer)
        trainer.policy = SimpleNamespace(
            actor_optimizer=optimizer,
            ac=SimpleNamespace(actor_param=module),
        )
        trainer.role_atomic_ppo = True
        trainer.bc_reference_hard_gate = False
        trainer.actor_kl_backtrack = True
        trainer._use_max_grad_norm = True
        trainer.max_grad_norm = 100.0

        parameter.grad = torch.tensor([2.0])
        before = parameter.detach().clone()
        trainer._perform_actor_optimizer_step()
        full_delta = parameter.detach().clone() - before
        retry = trainer.retry_last_actor_step(0.25)
        np.testing.assert_allclose(
            parameter.detach().numpy(),
            (before + 0.25 * full_delta).numpy(),
            rtol=0.0,
            atol=1e-7,
        )
        self.assertAlmostEqual(retry['actor_backtrack_step_scale'], 0.25)
        trainer.rollback_last_actor_step()
        self.assertTrue(torch.equal(parameter.detach(), before))
        self.assertEqual(len(optimizer.state), 0)

    def test_adaptive_soft_bc_controller_moves_and_clamps(self):
        trainer = MAPPO_Trainer.__new__(MAPPO_Trainer)
        trainer.adaptive_bc_reference_kl = True
        trainer.bc_reference_kl_coef = 0.1
        trainer.adaptive_bc_reference_target_kl = 0.03
        trainer.adaptive_bc_reference_coef_min = 0.05
        trainer.adaptive_bc_reference_coef_max = 0.2
        trainer.adaptive_bc_reference_coef_up = 2.0
        trainer.adaptive_bc_reference_coef_down = 0.5
        self.assertAlmostEqual(
            trainer._adapt_bc_reference_coefficient(0.04, 1), 0.2
        )
        self.assertAlmostEqual(
            trainer._adapt_bc_reference_coefficient(0.001, 1), 0.1
        )
        self.assertAlmostEqual(
            trainer._adapt_bc_reference_coefficient(0.001, 1), 0.05
        )
        self.assertAlmostEqual(
            trainer._adapt_bc_reference_coefficient(0.001, 1), 0.05
        )

    def test_zero_initialized_timing_gate_preserves_distribution(self):
        torch.manual_seed(19)
        control = DeviceRequestPtrActor(query_dim=12, embed_dim=8, nhead=2)
        torch.manual_seed(19)
        timed = DeviceRequestPtrActor(
            query_dim=12, embed_dim=8, nhead=2, timing_head=True
        )
        compatible = {
            key: value for key, value in control.state_dict().items()
            if key in timed.state_dict()
        }
        timed.load_state_dict(compatible, strict=False)
        query = torch.randn(3, 1, 12)
        requests = torch.randn(3, 5, 8)
        mask = torch.tensor([
            [True, True, True, False, False],
            [True, False, True, True, False],
            [False, True, True, True, True],
        ])
        _, _, control_logits = control(
            query, requests, mask, deterministic=True
        )
        _, _, timed_logits = timed(
            query, requests, mask, deterministic=True
        )
        self.assertTrue(torch.equal(
            timed.timing_head.weight,
            torch.zeros_like(timed.timing_head.weight),
        ))
        self.assertTrue(torch.allclose(
            control_logits, timed_logits, atol=1e-6
        ))

    def test_global_decoder_resolves_collision_optimally(self):
        actor = SimpleNamespace(max_plane_agents=1)
        logits = torch.full((1, 3, 3), float('-inf'))
        # Fixed-order argmax would give request 1 to agent 1 and leave the
        # much stronger agent-2/request-1 edge unused. Matching selects 2,1.
        logits[0, 1] = torch.log(torch.tensor([0.01, 0.55, 0.44]))
        logits[0, 2] = torch.log(torch.tensor([0.09, 0.90, 0.01]))
        active = torch.tensor([[False, True, True]])
        actions = torch.full((1, 3), -1, dtype=torch.long)
        log_prob = torch.zeros((1, 3))
        validated = torch.zeros((1, 3), dtype=torch.bool)
        request_is_lookahead = torch.ones((1, 3), dtype=torch.bool)
        GNN_Actor_Critic._apply_device_global_matching(
            actor,
            logits,
            request_is_lookahead,
            active,
            actions,
            log_prob,
            validated,
        )
        self.assertEqual(actions[0, 1:].tolist(), [2, 1])
        self.assertTrue(bool(validated[0, 1:].all()))

    def test_paired_delta_cvar_targets_regression(self):
        buffer = SharedReplayBuffer.__new__(SharedReplayBuffer)
        buffer.episode_length = 1
        buffer.filled_steps = 1
        buffer.n_rollout_threads = 4
        buffer.team_cmax_values = np.asarray(
            [1000.0, 900.0, 800.0, 700.0], dtype=np.float32
        )
        buffer.team_case_deltas = np.asarray(
            [-20.0, -10.0, 5.0, 100.0], dtype=np.float32
        )
        buffer.policy_sample_weights = np.ones(
            (1, 4, 1, 1), dtype=np.float32
        )
        buffer.value_sample_weights = buffer.policy_sample_weights.copy()
        diagnostics = buffer.apply_cvar_case_weights(
            0.25, 2.0, case_metric='paired_delta'
        )
        masses = buffer.policy_sample_weights.sum(axis=(0, 2, 3))
        self.assertEqual(diagnostics['cvar_threshold_case_metric'], 100.0)
        self.assertGreater(masses[3], masses[0])
        self.assertTrue(np.isclose(masses.sum(), 4.0))

    def test_compact_paired_baseline_loader(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'baseline.json'
            path.write_text(
                '{"cases":{"case_0001":9000,'
                '"case_0002":{"makespan":8000}}}',
                encoding='utf-8',
            )
            self.assertEqual(
                HKBZ_Runner._load_paired_case_baselines(path),
                {'case_0001': 9000.0, 'case_0002': 8000.0},
            )

    def test_round_command_exactly_respects_1000_graph_cap(self):
        command = [
            'python', 'train_hkbz.py',
            '--training_stage', 'resource_joint',
        ]
        apply_common(
            command,
            python=Path('/tmp/maia-python'),
            experiment='structured_graph_contract',
        )

        def value(flag):
            return int(command[command.index(flag) + 1])

        requested = (
            value('--mini_batch_size') * value('--data_chunk_length')
        )
        self.assertEqual(requested, 1000)
        self.assertEqual(requested, value('--max_graphs_per_forward'))
        validate(command, bc_only=False)

        command[command.index('--mini_batch_size') + 1] = '30'
        with self.assertRaisesRegex(ValueError, 'exceeds graph cap'):
            validate(command, bc_only=False)


if __name__ == '__main__':
    unittest.main()
