"""Regression-only fixtures for numerical execution, not scientific results."""
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from onpolicy.runner.shared.stage3_research_engine import ResearchEngine


def toy_runner(width):
    calls = []
    class Pool:
        def __init__(self):
            self.steps = {}
        def call(self, commands):
            result = {}
            for i, command, payload in commands:
                if command == "reset":
                    self.steps[i] = 0
                    result[i] = (i + 1, None, {})
                elif command == "step":
                    self.steps[i] += 1
                    result[i] = (i + 1, None, self.steps[i] >= i + 1, {})
                elif command == "summary":
                    result[i] = {"completed": True, "steps": self.steps[i]}
                else:
                    raise AssertionError(command)
            return result
    def actions(graph, hidden, active, op, site, **kwargs):
        calls.append(len(graph))
        # Deliberately batch-sensitive policy to exercise the real rollout loop.
        action = torch.full((len(graph), 104, 3), len(graph), dtype=torch.long)
        zeros = torch.zeros(len(graph), 104)
        return zeros, action, zeros, torch.from_numpy(hidden.copy()), zeros.bool()
    runner = SimpleNamespace(width=width, diagnostics=False, _role_exploration=None,
        environment_factory=lambda case, seed: {"seed": seed}, environment_overrides={},
        policy=SimpleNamespace(ac=SimpleNamespace(eval=lambda: None), get_actions=actions),
        pool=Pool(), exploration=None, semantic_history=False, policy_updates=0,
        device=torch.device("cpu"), norms={})
    runner._inputs = lambda graph, h, infos, previous: (
        graph, h, np.ones((len(graph), 104, 1), np.float32), previous[..., 0],
        previous[..., 1], np.zeros((len(graph), 104), np.int64))
    return runner, calls


def test_per_case_greedy_preserves_parallel_environments_and_legacy_default():
    cases = [{"path": f"/synthetic/{i}", "profile": "test", "distribution": "test"} for i in range(3)]
    stable, calls = toy_runner(3)
    rows = ResearchEngine.rollout(stable, cases, [1] * 3, deterministic=True,
                                 greedy_batching="per_case_v1")
    assert calls == [1] * 6
    assert [len(r["actions"]) for r in rows] == [1, 2, 3]
    assert all(np.asarray(r["actions"]).min() == np.asarray(r["actions"]).max() == 1 for r in rows)
    legacy, calls = toy_runner(3)
    ResearchEngine.rollout(legacy, cases, [1] * 3, deterministic=True)
    assert calls == [3, 2, 1]  # Unrelated Stage3 generations retain old behavior.


@pytest.mark.parametrize("greedy_batching", ["live_batch", "per_case_v1"])
def test_stochastic_calls_unchanged(greedy_batching):
    runner, calls = toy_runner(3)
    cases = [{"path": f"/synthetic/{i}", "profile": "test", "distribution": "test"} for i in range(3)]
    ResearchEngine.rollout(runner, cases, [1, 2, 3], greedy_batching=greedy_batching)
    assert calls == [1] * 6


def test_batching_identity_invalidates_legacy_queue_cache_and_evidence(tmp_path):
    from onpolicy.utils.stage3_b0_protocol import B0Queue, EVALUATION
    from onpolicy.utils.stage3_b0_acceleration import complete_rows
    from onpolicy.envs.HKBZ.test.test_stage3_b0_acceleration import synthetic_evidence
    m, case, row, _ = synthetic_evidence(tmp_path)
    request = {"checkpoint_sha256": "model", "cases_sha256": "cases", "contract_sha256": "env",
        "code_sha256": "code", "tau": .3, "seed": 1, "evaluation_protocol": EVALUATION,
        "representation": "NATIVE", "protocol_sha256": "protocol", "source_sha256": "b0",
        "comparison_sha256": "comparison", "kind": "native_cost", "diagnostic": None}
    request["training_exploration"] = None
    legacy = {k: v for k, v in EVALUATION.items() if k != "inference_batching"}
    assert B0Queue.identity(request) != B0Queue.identity({**request, "evaluation_protocol": legacy})
    complete_rows([row], [case])
    row.pop("inference_batching")
    with pytest.raises(ValueError, match="zero-update"):
        complete_rows([row], [case])


def test_b0_enforces_deployment_contract_and_restores_exploration(monkeypatch):
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine, GREEDY_BATCHING
    from onpolicy.envs.HKBZ.test.test_stage3_b0 import MANIFEST
    runner = B0Engine(MANIFEST, "NATIVE", device="cpu", create_environments=False)
    previous = runner.exploration.copy()
    def rollout(self, *args, **kwargs):
        assert kwargs["greedy_batching"] == GREEDY_BATCHING
        assert self.exploration is None
        return [{}]
    monkeypatch.setattr(ResearchEngine, "rollout", rollout)
    try:
        assert runner.rollout([], [], deterministic=True)[0]["inference_batching"] == GREEDY_BATCHING
        assert runner.exploration == previous
        with pytest.raises(ValueError, match="case-independent"):
            runner.rollout([], [], deterministic=True, greedy_batching="live_batch")
        def fail(*args, **kwargs):
            raise RuntimeError("synthetic failure")
        monkeypatch.setattr(ResearchEngine, "rollout", fail)
        with pytest.raises(RuntimeError, match="synthetic failure"):
            runner.rollout([], [], deterministic=True)
        assert runner.exploration == previous
        runner.assert_optimizer_ownership()
    finally:
        runner.close()


def test_early_replay_failure_keeps_strict_threshold_and_never_admits_training(tmp_path):
    from onpolicy.scripts.train.run_stage3_b0 import B0Suite
    from onpolicy.utils.stage3_b0_protocol import B0_SHA, EVALUATION
    from onpolicy.envs.HKBZ.test.test_stage3_b0_acceleration import synthetic_evidence
    from onpolicy.utils.stage3_research import atomic_json, read_json
    m, case, row, _ = synthetic_evidence(tmp_path)
    case.update(name="case_test", case_sha256="case_hash")
    m["splits"]["tune"] = [case]
    m["diagnostic"]["initial_native_tune_costs"] = {"case_hash": 100.}
    suite = B0Suite.__new__(B0Suite)
    suite.m, suite.root = m, tmp_path
    suite.queue = SimpleNamespace(root=tmp_path / "validator")
    suite._audited_native_tune_results = set()
    path = suite.queue.root / "results/B0_tune_e000000_s0000.json"
    result = {"ok": True, "checkpoint_sha256": B0_SHA, "code_sha256": m["code"]["sha256"],
        "evaluation": {"evaluation_protocol": EVALUATION, "cases": [row]}}
    row["makespan"] = 100. + 1e-7
    atomic_json(path, result)
    suite.check_available_native_tune()
    assert not (tmp_path / "training_admission.json").exists()
    assert not (tmp_path / "native_replay_early_failure.json").exists()
    row["makespan"] = 100. + 2e-6
    atomic_json(path.with_name("B0_tune_e000000_s0001.json"), result)
    with pytest.raises(RuntimeError, match="no RL admitted"):
        suite.check_available_native_tune()
    failure = read_json(tmp_path / "native_replay_early_failure.json")
    assert failure["cost_atol"] == 1e-6
    assert not failure["passed"] and not failure["formal_training_admitted"]
    assert failure["partial_audit_only"]


def test_old_b0_checkpoint_requires_explicit_migration(tmp_path):
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.envs.HKBZ.test.test_stage3_b0 import MANIFEST
    checkpoint = tmp_path / "old.pt"
    torch.save({"b0_schema": "stage3-frozen-b0-policy-v1"}, checkpoint)
    runner = B0Engine(MANIFEST, "NATIVE", device="cpu", create_environments=False)
    try:
        with pytest.raises(ValueError, match="lineage"):
            runner.load(checkpoint)
    finally:
        runner.close()
