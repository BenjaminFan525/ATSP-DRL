"""24-trajectory / 12-backward correctness, not training-benefit evidence."""
import copy
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from onpolicy.runner.shared.stage3_research_engine import ResearchEngine
from onpolicy.utils.stage3_b0_throughput import (
    MICRO_VERSION, MICRO_AUTHORIZATION, continuation_plan, parent_manifest, training_contract,
)
from onpolicy.utils.stage3_b0_protocol import identity
from onpolicy.utils.stage3_research import atomic_json, digest_file, digest_json
from onpolicy.envs.HKBZ.test.test_stage3_b0_throughput import continuation_fixture, cases, flatten


def toy(count=24):
    ac = torch.nn.Module()
    ac.theta = torch.nn.Parameter(torch.tensor(.13))
    ac.critic_param = torch.nn.Linear(1, 1, bias=False)
    with torch.no_grad():
        ac.critic_param.weight.fill_(.2)
    widths = []

    def likelihood(graph, h, active, op, site, actions, **kwargs):
        x = torch.as_tensor(np.stack(graph), dtype=ac.theta.dtype)
        if torch.is_grad_enabled():
            widths.append(len(graph))
        score = ac.theta*x + .1*h.reshape(len(graph), 3)
        lp = torch.nn.functional.logsigmoid(score)
        next_h = .6*h + (ac.theta*x)[:, :, None, None]
        return lp, torch.zeros_like(lp), torch.ones_like(lp), next_h

    def values(graph, *args, **kwargs):
        return ac.critic_param.weight.reshape(1, 1)*torch.as_tensor(np.stack(graph), dtype=torch.float32)

    runner = ResearchEngine.__new__(ResearchEngine)
    runner.device, runner.policy_updates, runner.exploration = torch.device('cpu'), 0, None
    runner.norms = {i: SimpleNamespace(normalize=lambda x: x) for i in range(3)}
    runner.policy = SimpleNamespace(ac=ac, evaluate_actions=likelihood, evaluate_values=values,
        actor_optimizer=torch.optim.Adam([{'params': [ac.theta], 'name': 'actor'}], lr=1e-5),
        critic_optimizer=torch.optim.Adam(ac.critic_param.parameters(), lr=1e-4), lr=1e-5)
    rows = []
    for i in range(count):
        h, states = np.zeros((3, 1, 1), np.float32), []
        for step in range(1+i % 5+8*(i % 3)):
            x = np.asarray([.1+.03*i, .2+.02*step, .3+.01*i], np.float32)
            with torch.no_grad():
                lp, _, _, next_h = likelihood([x], torch.tensor(h[None]), None, None, None, None)
            states.append({'graph': x, 'hidden': h.copy(), 'active': np.ones(3),
                'op': np.zeros(3), 'site': np.zeros(3), 'roles': np.arange(3),
                'action': np.zeros((3, 3)), 'old_logp': lp.numpy()[0], 'mask': np.ones(3),
                'value': np.zeros(3), 'time': float(step)})
            h = next_h.numpy()[0]
        rows.append({'case_id': f'case{i % 5}', 'makespan': 90.+i, 'completed': True,
                     'states': states, 'policy_updates': 0, 'behavior_deterministic': False,
                     'forced_replay': False})
    return runner, rows, widths


@pytest.mark.parametrize('count', [1, 8, 20, 24])
@pytest.mark.parametrize('visit_balanced', [False, True])
@pytest.mark.parametrize('deferred', [False, True])
def test_microbatch_gradients_match_full_ragged_tbptt(count, visit_balanced, deferred):
    captured = []
    class Capture(Exception):
        pass
    for micro in [count, 12]:
        runner, rows, widths = toy(count)
        runner.defer_statistics = deferred
        def capture(epoch, ac, stats):
            captured.append((ac.theta.grad.clone(), ac.critic_param.weight.grad.clone(), copy.deepcopy(stats)))
            raise Capture()
        with pytest.raises(Capture):
            runner.update(rows, 'source', {r['case_id']: 100. for r in rows}, epochs=1, chunk=8,
                allow_multi_case=True, visit_balanced=visit_balanced, microbatch_size=micro,
                gradient_callback=capture)
        assert max(widths) <= micro
        assert runner.policy_updates == 0 and not runner.policy.actor_optimizer.state
    torch.testing.assert_close(captured[0][0], captured[1][0], rtol=3e-5, atol=3e-6)
    torch.testing.assert_close(captured[0][1], captured[1][1], rtol=3e-5, atol=3e-6)
    assert captured[0][2]['decisions'] == captured[1][2]['decisions']
    assert captured[0][2]['nll'] == pytest.approx(captured[1][2]['nll'], rel=2e-6)


def test_microbatch_two_epoch_optimizer_cadence_and_full_kl():
    runner, rows, widths = toy()
    calls = []
    class Controller:
        def step(self, engine, trajectories, stats, heartbeat, distributed):
            assert len(trajectories) == 24 and engine.policy_updates == len(calls)
            engine.policy.actor_optimizer.step()
            engine.policy.critic_optimizer.step()
            engine.policy_updates += 1
            replay = engine.replay_metrics(trajectories)
            calls.append(replay)
            return {'actor_step_applied': True, 'post_update': replay}
    runner.ppo_step_controller = Controller()
    result = runner.update(rows, 'source', {r['case_id']: 100. for r in rows}, epochs=2,
        allow_multi_case=True, visit_balanced=True, microbatch_size=12)
    assert runner.policy_updates == len(calls) == len(result['epochs']) == 2
    assert max(widths) == 12 and result['backward_microbatches'] == 2
    assert result['optimizer_step_after_microbatches']
    expected = 3*sum(len(r['states']) for r in rows)
    assert all(sum(role['decisions'] for role in c['roles'].values()) == expected for c in calls)
    assert int(runner.policy.actor_optimizer.state[runner.policy.ac.theta]['step']) == 2


@pytest.mark.parametrize('value', [0, -1, 1.5, True])
def test_microbatch_rejects_invalid_size(value):
    runner, rows, _ = toy(1)
    with pytest.raises(ValueError, match='microbatch'):
        runner.update(rows, 'source', 100., microbatch_size=value)


def test_microbatch_parent96_checkpoint_lineage_and_no_stale_relabel(tmp_path):
    parent = continuation_fixture(tmp_path)
    root = tmp_path/'batch96'
    root.mkdir()
    parent['root'] = str(root)
    parent['manifest_sha256'] = identity(parent)
    atomic_json(root/'manifest.json', parent)
    atomic_json(root/'training_admission.json', {'passed': True})
    entries = []
    for rank in range(8):
        path = root/f'rank{rank}.pt'
        path.write_bytes(b'synthetic-committed-not-training-weights')
        entries.append({'rank': rank, 'checkpoint': str(path), 'sha256': digest_file(path)})
    commit = {'world_size': 8, 'ranks': entries, 'training_episodes': 608, 'actual_actor_updates': 34,
        'protocol_sha256': parent['manifest_sha256'], 'schedule_sha256': digest_json(continuation_plan(parent)),
        'recipe_sha256': digest_file(root/'training_admission.json')}
    atomic_json(root/'commit.json', commit)
    child = copy.deepcopy(parent)
    child['training'] = training_contract(192)
    child['throughput'].update(version=MICRO_VERSION, authorization=MICRO_AUTHORIZATION,
        parent_manifest=str(root/'manifest.json'), parent_manifest_sha256=digest_file(root/'manifest.json'),
        resume_commit=str(root/'commit.json'), resume_commit_sha256=digest_file(root/'commit.json'),
        start_episodes=608, start_actor_updates=34, global_batch=192, rollout_envs_per_rank=12,
        rollout_trajectories_per_rank=24, backward_trajectories_per_rank=12,
        gradient_accumulation_microbatches=2, optimizer_step_after_microbatches=True,
        parent_evidence={str(root/'training_admission.json'): digest_file(root/'training_admission.json')})
    child['throughput']['schedule_sha256'] = digest_json(continuation_plan(child))
    assert parent_manifest(child)['training']['global_batch'] == 96
    plan = continuation_plan(child)
    assert len(plan) == 37 and [b['batch_size'] for b in plan[:2]] == [192, 160]
    from onpolicy.utils.stage3_full_data import schedule
    assert flatten(plan) == flatten(schedule(cases(), child['training']['seed']))[608:]
    invalid = copy.deepcopy(child)
    invalid['throughput']['backward_trajectories_per_rank'] = 24
    with pytest.raises(ValueError, match='contract'):
        parent_manifest(invalid)
    runner, rows, _ = toy()
    from onpolicy.utils.stage3_local_exploration import MODES
    runner.exploration = MODES['J']
    for row in rows:
        row['exploration'] = copy.deepcopy(runner.exploration)
    rows[-1]['policy_updates'] = 1
    with pytest.raises(ValueError, match='Stale'):
        runner.update(rows, 'source', {r['case_id']: 100. for r in rows}, allow_multi_case=True, microbatch_size=12)
    assert runner.policy_updates == 0 and rows[-1]['policy_updates'] == 1


def _rank192(rank, init_file):
    from onpolicy.utils.stage3_distributed import TrajectoryParallel
    torch.set_num_threads(1)
    dist.init_process_group('gloo', init_method='file://'+init_file, rank=rank, world_size=8,
                            timeout=timedelta(seconds=120))
    try:
        sync = TrajectoryParallel(device_packed=True)
        weights, denom = sync.objective_weights([f'case{i}' for i in range(24)], 24, visit_balanced=True)
        actor, critic = torch.nn.Parameter(torch.tensor([.2])), torch.nn.Parameter(torch.tensor([.4]))
        x = torch.arange(rank, 192, 8, dtype=torch.float32)
        for first in (0, 12):
            (actor*x[first:first+12]*torch.tensor(weights[first:first+12])).sum().backward()
            (critic.square()*12/denom).backward()
        policy = SimpleNamespace(actor_optimizer=torch.optim.Adam([actor]), critic_optimizer=torch.optim.Adam([critic]))
        sync.synchronize_update(policy, dict(kl=0., clip=0., logp=0., decisions=24., mask_mismatch=0))
        torch.testing.assert_close(actor.grad, torch.tensor([95.5]))
        torch.testing.assert_close(critic.grad, torch.tensor([.8]))
    finally:
        dist.destroy_process_group()


def test_microbatch_eight_rank_global192_visit_mean(tmp_path):
    mp.spawn(_rank192, args=(str(tmp_path/'store'),), nprocs=8, join=True)


def test_microbatch_collects24_in_two12_environment_waves():
    from onpolicy.scripts.train.stage3_b0_worker import collect
    calls, updates = [], []
    def rollout(cases, seeds, **kwargs):
        calls.append((list(cases), list(seeds)))
        assert kwargs['retain']
        return list(zip(cases, seeds))
    runner = SimpleNamespace(width=12, rollout=rollout)
    hb = SimpleNamespace(update=lambda **row: updates.append(row))
    rows = collect(runner, {'cases': list(range(24)), 'seeds': list(range(100, 124))}, hb)
    assert rows == list(zip(range(24), range(100, 124)))
    assert [len(c) for c, _ in calls] == [12, 12]
    assert [r['rollout_wave'] for r in updates if r['event'] == 'rollout_wave_start'] == [1, 2]
    assert updates[-1]['rollout_trajectories_collected'] == 24


def test_microbatch_real_b0_cpu_graph_gradients_match_full24(record_property):
    """Actual private GNN + RNN; short synthetic fixture, never reward evidence."""
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.utils.stage3_research import WORKSPACE_ROOT, case_record
    manifest = Path(__file__).resolve().parents[4]/'artifacts/stage2_frozen/20260912/manifest.json'
    runner = B0Engine(manifest, 'F_PRIVATE', device='cpu', width=1)
    original_call = runner.pool.call
    def prefix(commands):
        result = original_call(commands)
        for i, command, _ in commands:
            if command == 'summary':
                result[i] = {**result[i], 'completed': True, 'synthetic_prefix_fixture': True}
        return result
    runner.pool.call = prefix
    class Captured(Exception):
        pass
    try:
        case = case_record(WORKSPACE_ROOT/'onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train/case_0341')
        row = runner.rollout([case], [2026091301], retain=True, max_steps=2)[0]
        assert row['synthetic_prefix_fixture']
        rows = [dict(row, case_id=f'fixture{i}', states=row['states']) for i in range(24)]
        costs = {r['case_id']: r['makespan']+30 for r in rows}
        gradients = []
        def capture(epoch, ac, stats):
            gradients.append(torch.cat([p.grad.detach().flatten().clone() if p.grad is not None
                else torch.zeros(p.numel(), dtype=p.dtype) for p in ac.parameters() if p.requires_grad]))
            raise Captured()
        for micro in (24, 12):
            with pytest.raises(Captured):
                runner.update(rows, 'source', costs, epochs=1, chunk=8, microbatch_size=micro,
                              gradient_callback=capture)
        relative = torch.linalg.vector_norm(gradients[0]-gradients[1])/torch.linalg.vector_norm(gradients[0])
        record_property('relative_gradient_l2_error', float(relative))
        record_property('trainable_gradient_elements', gradients[0].numel())
        record_property('diagnostic_synthetic_prefix_only', True)
        assert float(relative) < 3e-5
        assert runner.policy_updates == 0 and not runner.policy.actor_optimizer.state
        assert not any(p.requires_grad for p in runner.policy.ac.request_ready_head.parameters())
    finally:
        runner.close()
