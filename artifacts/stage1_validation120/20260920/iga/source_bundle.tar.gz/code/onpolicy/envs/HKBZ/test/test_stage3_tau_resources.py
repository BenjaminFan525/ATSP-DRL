"""Two-arm resource sharding contracts; not scientific outcome evidence."""
import copy
from datetime import timedelta
from types import SimpleNamespace

import numpy as np
import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from onpolicy.utils.stage3_tau_resources import (
    VERSION, RESIZE_VERSION, PLACEMENT, STOPPED, FIELDS, split_shards, global_targets,
    verify_resource_contract, validated_commit, resource_engine_class, resource_sizes,
)
from onpolicy.utils.stage3_tau import ARMS, training_plan, temperature_state
from onpolicy.utils.stage3_rl_bridge import actor_targets
from onpolicy.utils.stage3_distributed import state_digest, TrajectoryParallel
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json
from onpolicy.envs.HKBZ.test.test_stage3_rl_bridge import cases


def manifest():
    return dict(manifest_sha256='fixture', splits=dict(train_subset240=cases((192, 43, 5))),
                training=dict(seed=2026091201, training_split='train_subset240'))


def rows_fixture(count=120):
    return [dict(case_id=f'case{i//4}', group_id=f'group{i//4}', replica=i % 4, seed=1000+i,
        makespan=90.+i % 17, completed=True, behavior_deterministic=False, forced_replay=False,
        policy_updates=30, population_weight=.625 if i < 60 else 108/43, states=['never gathered'])
        for i in range(count)]


def test_tau_resource_schedule_same_cases_seeds_groups_and_every_optimizer_batch():
    plan = training_plan(manifest(), 2)
    assert len(plan) == 64 and plan[31]['training_episodes'] == 3840
    for batch in plan:
        old, new = batch['shards'], split_shards(batch['shards'])
        assert list(map(len, new)) == [30]*4
        for step in range(5):
            before = [r['seed'] for shard in old for r in shard[12*step:12*(step+1)]]
            after = [r['seed'] for shard in new for r in shard[6*step:6*(step+1)]]
            assert sorted(before) == sorted(after) and len(set(after)) == 24
    assert plan[2]['training_episodes'] == 360 and plan[3]['training_episodes'] == 480


@pytest.mark.parametrize('arm', tuple(PLACEMENT))
def test_tau_resource_targets_cross_rank_loo_and_risk_unchanged(arm):
    rows = rows_fixture()
    costs = {r['case_id']: 100. for r in rows}
    a, w, _ = actor_targets(rows, arm, costs, arm_spec=ARMS[arm])
    expected = {r['seed']: (av, wt) for r, av, wt in zip(rows, a, w)}
    shards = split_shards([rows[:60], rows[60:]])
    metadata = [[{k: r[k] for k in FIELDS} for r in shard] for shard in shards]
    for rank, local in enumerate(shards):
        def gather(value):
            assert all(set(r) == set(FIELDS) and 'states' not in r for r in value)
            return metadata
        sync = SimpleNamespace(world_size=4, rank=rank, gather=gather)
        actual, weights, audit = global_targets(local, arm, costs, sync)
        np.testing.assert_allclose(actual, [expected[r['seed']][0] for r in local], atol=1e-12)
        np.testing.assert_array_equal(weights, [expected[r['seed']][1] for r in local])
        assert len(audit['groups']) == 30 and audit['risk_lambda'] == ARMS[arm]['risk_lambda']


@pytest.mark.parametrize('bad', ['world', 'unequal', 'seed', 'version', 'partial'])
def test_tau_resource_targets_reject_invalid_groups(bad):
    rows = rows_fixture()
    shards = split_shards([rows[:60], rows[60:]])
    if bad == 'unequal': shards[-1].pop()
    if bad == 'seed': shards[0][1]['seed'] = shards[0][0]['seed']
    if bad == 'version': shards[0][1]['policy_updates'] += 1
    if bad == 'partial': shards[0][1]['completed'] = False
    sync = SimpleNamespace(world_size=2 if bad == 'world' else 4, rank=0, gather=lambda _: shards)
    with pytest.raises(ValueError):
        global_targets(shards[0], 'T1_ANNEAL10', {r['case_id']: 100. for r in rows}, sync)


def resource_contract():
    return dict(throughput=dict(rollout_envs_per_rank=30, backward_trajectories_per_rank=6),
        resource_restart=dict(version=VERSION, placement=copy.deepcopy(PLACEMENT), stopped_arms=list(STOPPED),
            until_epochs=4, logical_world_size=2, physical_world_size=4, global_rollout_trajectories=120,
            global_optimizer_trajectories=24, automatic_e8_continuation=False,
            bitwise_equivalence_claimed=False, resume_commits={a: {} for a in PLACEMENT}))


def test_tau_resource_contract_keeps_global_batch_and_does_not_auto_resume_stopped_control():
    m = resource_contract()
    verify_resource_contract(m)
    for key, value in [('until_epochs', 8), ('automatic_e8_continuation', True),
                       ('global_optimizer_trajectories', 48), ('bitwise_equivalence_claimed', True)]:
        changed = copy.deepcopy(m)
        changed['resource_restart'][key] = value
        with pytest.raises(ValueError):
            verify_resource_contract(changed)
    m['throughput']['backward_trajectories_per_rank'] = 12
    with pytest.raises(ValueError):
        verify_resource_contract(m)


def _gloo_worker(rank, world, arm, rendezvous, output, factor=1, replay_enabled=True):
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy
    from onpolicy.runner.shared.stage3_tau_engine import TauEngine
    from onpolicy.utils.stage3_numerics import training_state
    torch.set_num_threads(1)
    dist.init_process_group('gloo', init_method=f'file://{rendezvous}', world_size=world,
                            rank=rank, timeout=timedelta(seconds=120))
    try:
        toy, rows, widths = minibatch_toy(48*factor)
        kind = TauEngine if world == 2 else resource_engine_class(6*factor)
        runner = kind.__new__(kind)
        runner.__dict__.update(toy.__dict__)
        runner.ppo_step_controller.replay_enabled = replay_enabled
        if not replay_enabled:
            def forbidden_replay(*args, **kwargs):
                raise AssertionError('Distributed PPO called disabled KL replay')
            runner.replay_metrics = forbidden_replay
        runner.bridge_arm, runner.bridge_spec = arm, ARMS[arm]
        runner.representation, runner.committed_episodes = 'F_PRIVATE', 360
        runner.execution_cache, runner.zero_update_batches = None, 0
        runner.assert_optimizer_ownership = lambda: None
        runner.exploration = dict(roles=[0, 1, 2], taus=[.1]*3)
        for i, row in enumerate(rows):
            row.update(case_id=f'case{i//4}', group_id=f'group{i//4}', seed=100+i, replica=i % 4,
                population_weight=.625 if i < 24 else 2.5, exploration=copy.deepcopy(runner.exploration))
        logical = [rows[:24*factor], rows[24*factor:]]
        local = logical[rank] if world == 2 else split_shards(logical, 6*factor)[rank]
        sync = TrajectoryParallel(device_packed=True)
        result = runner.update(local, 'source', {r['case_id']: 100. for r in rows},
            epochs=2, chunk=8, distributed=sync, microbatch_size=(12 if world == 2 else 6)*factor,
            optimizer_step_per_microbatch=True)
        sync.assert_replicas(runner)
        assert runner.policy_updates == result['accepted_actor_steps'] == 4
        assert result['kl_replay_enabled'] is replay_enabled
        assert max(widths) == (12 if world == 2 else 6)*factor
        assert runner.committed_episodes == 360
        assert result['temperature_state'] == temperature_state(arm, 360)
        if rank == 0:
            torch.save(training_state(runner), output)
    finally:
        dist.destroy_process_group()


@pytest.mark.parametrize('replay_enabled', [True, False])
@pytest.mark.parametrize('arm', tuple(PLACEMENT))
@pytest.mark.parametrize('factor', [1, 2])
def test_tau_resource_gloo_two_vs_four_rank_optimizer_and_normalizers(tmp_path, arm, factor, replay_enabled):
    states = []
    for world in (2, 4):
        output = tmp_path/f'{world}.pt'
        mp.spawn(_gloo_worker, args=(world, arm, str(tmp_path/f'rdzv{world}'), str(output), factor, replay_enabled),
                 nprocs=world, join=True)
        states.append(torch.load(output, weights_only=False))
    def compare(a, b):
        assert type(a) is type(b)
        if isinstance(a, dict):
            assert a.keys() == b.keys()
            for key in a: compare(a[key], b[key])
        elif isinstance(a, (tuple, list)):
            assert len(a) == len(b)
            for x, y in zip(a, b): compare(x, y)
        elif isinstance(a, torch.Tensor):
            torch.testing.assert_close(a, b, rtol=3e-5, atol=3e-6)
        else:
            assert a == b
    compare(*states)


def fixture_commit(tmp_path, world=2):
    m, arm = manifest(), 'T1_ANNEAL10'
    if world == 4: m['resource_restart'] = resource_contract()['resource_restart']
    state = dict(model={'weight': torch.ones(2)}, actor_optim={}, critic_optim={},
                 role_value_normalizers={}, policy_updates=30)
    signature = state_digest(dict(model=state['model'], actor=state['actor_optim'],
        critic=state['critic_optim'], norms=state['role_value_normalizers'], policy_updates=state['policy_updates']))
    commit = dict(manifest_sha256='fixture', arm=arm, phase='full', world_size=world,
        training_episodes=360, policy_updates=30, schedule_sha256=digest_json(training_plan(m, 2)),
        temperature_state=temperature_state(arm, 360), ranks=[])
    for rank in range(world):
        path = tmp_path/f'rank{rank}.pt'
        torch.save({**state, 'diagnostic_only': False, 'rank': rank, 'world_size': world,
            'bridge_arm': arm, 'protocol_sha256': 'fixture', 'phase': 'full',
            'schedule_sha256': commit['schedule_sha256'], 'training_episodes': 360,
            'next_group': 3, 'temperature_state': commit['temperature_state']}, path)
        commit['ranks'].append(dict(rank=rank, checkpoint=str(path), sha256=digest_file(path), state_sha256=signature))
    path = tmp_path/'commit.json'
    atomic_json(path, commit)
    return m, arm, path


@pytest.mark.parametrize('world', [2, 4])
def test_tau_resource_resume_only_complete_hash_verified_rank_states(tmp_path, world):
    m, arm, path = fixture_commit(tmp_path, world)
    commit, cursor, state = validated_commit(m, arm, path)
    assert cursor == 3 and commit['training_episodes'] == 360
    payload = torch.load(commit['ranks'][0]['checkpoint'], weights_only=False)
    assert state == state_digest({k: payload[k] for k in
        ('model', 'actor_optim', 'critic_optim', 'role_value_normalizers', 'policy_updates')})
    commit['ranks'].pop()
    atomic_json(path, commit)
    with pytest.raises(ValueError): validated_commit(m, arm, path)


@pytest.mark.parametrize('bad', ['hash', 'tau', 'diagnostic', 'optimizer', 'cursor'])
def test_tau_resource_resume_rejects_corruption_or_partial_training(tmp_path, bad):
    m, arm, path = fixture_commit(tmp_path)
    c = read_json(path)
    entry = c['ranks'][0]
    payload = torch.load(entry['checkpoint'], weights_only=False)
    if bad == 'hash': entry['sha256'] = 'bad'
    elif bad == 'tau': c['temperature_state']['sampling_tau'] = .3
    else:
        if bad == 'diagnostic': payload['diagnostic_only'] = True
        if bad == 'optimizer': payload['actor_optim'] = {'changed': torch.ones(1)}
        if bad == 'cursor': payload['next_group'] += 1
        torch.save(payload, entry['checkpoint'])
        entry['sha256'] = digest_file(entry['checkpoint'])
    atomic_json(path, c)
    with pytest.raises(ValueError): validated_commit(m, arm, path)


def resized_manifest():
    m = {**manifest(), **resource_contract()}
    m['training'].update(first_stage_episodes=3840, episodes_per_data_epoch=960)
    m['throughput'].update(rollout_envs_per_rank=60, backward_trajectories_per_rank=12)
    m['resource_restart'].update(version=RESIZE_VERSION, global_rollout_trajectories=240,
        global_optimizer_trajectories=48, resume_commits={a: {'training_episodes': 960} for a in PLACEMENT},
        batch_resize=dict(factor=2, from_version=VERSION, switch_episodes=960,
                          optimization_equivalence_claimed=False))
    return m


def test_tau_resource_resize_schedule_preserves_prefix_cases_seeds_groups_and_budget():
    old, new = training_plan(manifest(), 2), training_plan(resized_manifest(), 2)
    assert new[:8] == old[:8]
    assert new[8]['training_episodes'] == 1200 and new[8]['index'] == 8
    assert new[19]['training_episodes'] == 3840 and new[19]['epoch_tail']
    assert len(new) == 36 and new[-1]['training_episodes'] == 7680
    for epoch in range(1, 9):
        before = [r for b in old if b['epoch'] == epoch for shard in b['shards'] for r in shard]
        after = [r for b in new if b['epoch'] == epoch for shard in b['shards'] for r in shard]
        assert sorted(before, key=lambda r: r['seed']) == sorted(after, key=lambda r: r['seed'])
        assert len(after) == len({r['seed'] for r in after}) == 960
    for batch in new[8:]:
        shards = split_shards(batch['shards'], 12)
        assert list(map(len, shards)) == [60]*4
        for step in range(5):
            rows = [r for shard in shards for r in shard[step*12:(step+1)*12]]
            assert len(rows) == len({r['seed'] for r in rows}) == 48
            assert all(sorted(r['replica'] for r in rows if r['group_id'] == g) == [0, 1, 2, 3]
                       for g in {r['group_id'] for r in rows})


def test_tau_resource_resize_contract_requires_explicit_non_equivalence_and_common_boundary():
    m = resized_manifest()
    verify_resource_contract(m)
    assert resource_sizes(m) == (60, 12)
    for field, value in [('switch_episodes', 1080), ('factor', 3), ('optimization_equivalence_claimed', True)]:
        changed = copy.deepcopy(m)
        changed['resource_restart']['batch_resize'][field] = value
        with pytest.raises(ValueError): verify_resource_contract(changed)
    changed = copy.deepcopy(m)
    changed['resource_restart']['resume_commits']['T1_ANNEAL10']['training_episodes'] = 1920
    with pytest.raises(ValueError): verify_resource_contract(changed)
    with pytest.raises(ValueError): training_plan(m, 4)


@pytest.mark.parametrize('arm', tuple(PLACEMENT))
def test_tau_resource_resize_targets_keep_complete_k4_groups(arm):
    rows = rows_fixture(240)
    costs = {r['case_id']: 100. for r in rows}
    expected_a, expected_w, _ = actor_targets(rows, arm, costs, arm_spec=ARMS[arm])
    by_seed = {r['seed']: (a, w) for r, a, w in zip(rows, expected_a, expected_w)}
    shards = split_shards([rows[:120], rows[120:]], 12)
    for rank, local in enumerate(shards):
        sync = SimpleNamespace(world_size=4, rank=rank, gather=lambda _: shards)
        actual, weights, audit = global_targets(local, arm, costs, sync)
        np.testing.assert_allclose(actual, [by_seed[r['seed']][0] for r in local], atol=1e-12)
        np.testing.assert_array_equal(weights, [by_seed[r['seed']][1] for r in local])
        assert len(audit['groups']) == 60


def test_tau_resource_resize_resume_validates_new_schedule_cursor(tmp_path):
    _, arm, path = fixture_commit(tmp_path, world=4)
    m = resized_manifest()
    c = read_json(path)
    c.update(training_episodes=1200, schedule_sha256=digest_json(training_plan(m, 2)),
             temperature_state=temperature_state(arm, 1200))
    for entry in c['ranks']:
        payload = torch.load(entry['checkpoint'], weights_only=False)
        payload.update(training_episodes=1200, next_group=9, temperature_state=c['temperature_state'],
                       schedule_sha256=c['schedule_sha256'])
        torch.save(payload, entry['checkpoint'])
        entry['sha256'] = digest_file(entry['checkpoint'])
    atomic_json(path, c)
    commit, cursor, _ = validated_commit(m, arm, path)
    assert cursor == 9 and commit['training_episodes'] == 1200
    c['schedule_sha256'] = digest_json(training_plan(manifest(), 2))
    atomic_json(path, c)
    with pytest.raises(ValueError): validated_commit(m, arm, path)
