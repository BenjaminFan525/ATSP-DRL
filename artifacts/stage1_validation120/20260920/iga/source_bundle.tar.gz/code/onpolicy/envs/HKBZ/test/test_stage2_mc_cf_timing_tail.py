"""Contracts for the Stage2 MC+CF/timing/tail research round."""

from __future__ import annotations

import json

import numpy as np

from onpolicy.config.config import get_config
from onpolicy.scripts.train.prepare_stage2_mc_cf_timing_tail import METHODS
from onpolicy.scripts.train.stage2_event_credit_autopilot import (
    analyze_phase,
    build_representation_manifest,
)
from onpolicy.utils.shared_buffer import SharedReplayBuffer


def _write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _evaluation(raw, selection, ood, tail, deltas):
    return {
        "summary": {
            "eval_case_count": 60,
            "eval_selection_score": selection,
            "eval_raw_makespan": raw,
            "eval_iid_makespan": raw - 100.0,
            "eval_distribution_ood_stress_makespan": ood,
            "eval_distribution_ood_scale_makespan": raw - 200.0,
            "eval_tail_makespan": tail,
            "eval_completion_rate": 1.0,
            "eval_cycle_count": 0,
            "eval_timeout_count": 0,
        },
        "cases": [
            {
                "case_key": f"tune/case_{index:04d}",
                "case_sha256": f"{index:064x}",
                "delta_vs_pre_ppo": float(deltas[index]),
                "resource_late_dispatch_rate": 0.1,
            }
            for index in range(60)
        ],
    }


def _strict_gate():
    return {
        "raw_cmax_improvement_seconds": 75.0,
        "matched_iga1800_gap_seconds_max": 100.0,
        "ood_stress_regression_seconds_max": 25.0,
        "tail_regression_seconds_max": 0.0,
        "paired_ci95_upper_seconds_max": 0.0,
        "catastrophic_regression_count_500_max": 0,
        "completion_rate_min": 1.0,
        "actor_step_completion_min": 0.90,
        "cycle_count_max": 0,
    }


def test_method_matrix_removes_td_and_isolates_planned_effects():
    assert tuple(METHODS) == (
        "A0_mc_control",
        "A1_mc_cf",
        "A2_mc_cf_potential",
        "A3_mc_cf_timing_anchor",
        "A4_mc_cf_timing_potential",
        "A5_mc_cf_timing_potential_cvar",
    )
    assert METHODS["A0_mc_control"]["counterfactual"] is False
    assert METHODS["A1_mc_cf"]["counterfactual"] is True
    assert METHODS["A2_mc_cf_potential"]["potential"] is True
    assert METHODS["A3_mc_cf_timing_anchor"]["timing_anchor"] is True
    assert METHODS["A5_mc_cf_timing_potential_cvar"]["cvar"] is True


def test_cvar_defaults_are_disabled_and_mass_is_conserved():
    args = get_config().parse_args([])
    assert args.cvar_policy_fraction == 1.0
    assert args.cvar_policy_weight == 1.0

    buffer = SharedReplayBuffer.__new__(SharedReplayBuffer)
    buffer.episode_length = 2
    buffer.filled_steps = 2
    buffer.n_rollout_threads = 5
    buffer.team_cmax_values = np.asarray(
        [100.0, 200.0, 300.0, 400.0, 500.0], dtype=np.float32
    )
    buffer.policy_sample_weights = np.full((2, 5, 1, 1), 0.5, dtype=np.float32)
    buffer.value_sample_weights = buffer.policy_sample_weights.copy()
    policy_before = float(buffer.policy_sample_weights.sum())
    diagnostics = buffer.apply_cvar_case_weights(0.2, 2.0)
    policy_mass = buffer.policy_sample_weights.sum(axis=(0, 2, 3))
    assert diagnostics["cvar_policy_enabled"] == 1.0
    assert diagnostics["cvar_tail_case_count"] == 1.0
    assert diagnostics["cvar_threshold_cmax"] == 500.0
    assert np.isclose(buffer.policy_sample_weights.sum(), policy_before)
    assert policy_mass[-1] > policy_mass[0]
    assert np.allclose(
        buffer.policy_sample_weights, buffer.value_sample_weights
    )


def test_strict_gate_rejects_tail_and_catastrophic_regressions(tmp_path):
    command = [
        "python", "train.py", "--experiment_name", "strict_arm",
        "--num_episodes", "1",
    ]
    manifest = tmp_path / "wave.json"
    _write_json(manifest, {
        "phase": "wave_a",
        "screen_gate": _strict_gate(),
        "commands": {"A": {"argv": command}},
    })
    run = tmp_path / "results/strict_arm/run1"
    _write_json(run / "run_status.json", {
        "status": "completed",
        "training_stage": "resource_joint",
        "phase": "resource_joint_completed",
        "canary_rejected": False,
        "actor_update_health": {
            "step_completion_rate": 0.95,
            "zero_update_shards": 0,
        },
    })
    _write_json(
        run / "evaluations/pre_ppo.json",
        _evaluation(8800.0, 9400.0, 9600.0, 10000.0, [0.0] * 60),
    )
    deltas = [-150.0] * 59 + [600.0]
    _write_json(
        run / "evaluations/epoch_1.json",
        _evaluation(8680.0, 9250.0, 9610.0, 10020.0, deltas),
    )
    checkpoint = run / "models/checkpoint_Best.pt"
    checkpoint.parent.mkdir(parents=True)
    checkpoint.write_bytes(b"checkpoint")
    selected = analyze_phase(
        manifest,
        tmp_path / "results",
        tmp_path / "selection.json",
        iga1800_raw=8592.85,
    )
    reasons = selected["methods"][0]["gate_reasons"]
    assert selected["selected_method"] is None
    assert "tail_regression_above_gate" in reasons
    assert "catastrophic_regression_count_above_gate" in reasons


def test_wave_b_crosses_two_methods_with_three_head_modes(tmp_path):
    base = [
        "python", "train.py", "--experiment_name", "base",
        "--num_episodes", "2", "--gnn_freeze_epochs", "2",
        "--plane_freeze_epochs", "2", "--seed", "1",
        "--eval_case_offset", "0", "--eval_partition_seed", "1",
        "--eval_partition_stratify_by", "distribution",
        "--max_eval_cases", "60", "--early_stop_patience", "0",
        "--device_policy_head_mode", "shared", "--use_eval",
    ]
    source = tmp_path / "wave_a.json"
    _write_json(source, {
        "screen_gate": _strict_gate(),
        "commands": {
            "A1": {"argv": base, "hypothesis": "first"},
            "A2": {"argv": base, "hypothesis": "second"},
        },
    })
    manifest = build_representation_manifest(
        source, ("A1", "A2"), tmp_path / "wave_b.json",
        run_tag="study", epochs=4,
    )
    assert len(manifest["commands"]) == 6
    assert {
        entry["device_policy_head_mode"]
        for entry in manifest["commands"].values()
    } == {"shared", "type_adapter", "per_type"}
    for entry in manifest["commands"].values():
        command = entry["argv"]
        assert command[command.index("--num_episodes") + 1] == "4"
        assert command[command.index("--gnn_freeze_epochs") + 1] == "4"
        assert command[command.index("--plane_freeze_epochs") + 1] == "4"

