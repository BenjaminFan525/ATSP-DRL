"""36/12 independent PPO steps: correctness fixtures, NOT reward evidence."""
import copy
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
import numpy as np
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from onpolicy.envs.HKBZ.test.test_stage3_b0_microbatch import toy
from onpolicy.envs.HKBZ.test.test_stage3_b0_throughput import continuation_fixture, cases, flatten
from onpolicy.utils.stage3_b0_protocol import identity
from onpolicy.utils.stage3_b0_throughput import (MINIBATCH_VERSION, MINIBATCH_AUTHORIZATION,
    training_contract, continuation_plan, parent_manifest)
from onpolicy.utils.stage3_distributed import state_digest
from onpolicy.utils.stage3_local_exploration import MODES
from onpolicy.utils.stage3_ppo_minibatches import RolloutBatchLease, behavior_digest
from onpolicy.utils.stage3_ppo_transaction import PPOStepTransaction, snapshot
from onpolicy.utils.stage3_research import atomic_json, digest_file, digest_json


class IdentityNorm(torch.nn.Module):
    def normalize(self, value):
        return value


def minibatch_toy(count=36):
    runner, rows, widths = toy(count)
    runner.exploration = copy.deepcopy(MODES['J'])
    runner.norms = {role: IdentityNorm() for role in range(3)}
    runner.ppo_step_controller = PPOStepTransaction()
    for row in rows:
        row['exploration'] = copy.deepcopy(runner.exploration)
    return runner, rows, widths


def update(runner, rows, **kwargs):
    return runner.update(rows, 'source', {r['case_id']: 100. for r in rows}, epochs=2,
        chunk=8, allow_multi_case=True, visit_balanced=True, microbatch_size=12,
        optimizer_step_per_microbatch=True, **kwargs)


def test_minibatches_six_independent_steps_keep_behavior_data():
    runner, rows, widths = minibatch_toy()
    old = behavior_digest(rows)
    result = update(runner, rows)
    assert runner.policy_updates == len(result['epochs']) == 6
    assert all(e['actor_step_applied'] for e in result['epochs'])
    assert [e['optimizer_minibatch'] for e in result['epochs']] == [1, 2, 3, 1, 2, 3]
    assert [e['ppo_epoch'] for e in result['epochs']] == [0, 0, 0, 1, 1, 1]
    assert int(runner.policy.actor_optimizer.state[runner.policy.ac.theta]['step']) == 6
    assert int(runner.policy.critic_optimizer.state[runner.policy.ac.critic_param.weight]['step']) == 6
    assert max(widths) == 12 and result['backward_microbatches'] == 3
    assert result['optimizer_step_per_microbatch'] and not result['optimizer_step_after_microbatches']
    assert behavior_digest(rows) == old and result['behavior_data_unchanged']
    assert all(r['policy_updates'] == 0 for r in rows)
    expected = 3*sum(len(r['states']) for r in rows)
    assert len(result['ppo_epoch_reports']) == 2
    assert all(sum(r['decisions'] for r in e['full_batch_post_update']['roles'].values()) == expected
               for e in result['ppo_epoch_reports'])
    assert not hasattr(runner, '_active_rollout_batch')
    with pytest.raises(ValueError, match='fresh|stale'):
        update(runner, rows)
    with pytest.raises(ValueError, match='Stale'):
        runner.update(rows[:12], 'source', 100., allow_multi_case=True)
    assert runner.policy_updates == 6


@pytest.mark.parametrize('count,steps', [(1, 2), (8, 2), (13, 4), (24, 4), (36, 6)])
def test_minibatches_epoch_tail_counts(count, steps):
    runner, rows, widths = minibatch_toy(count)
    result = update(runner, rows)
    assert runner.policy_updates == steps == len(result['epochs'])
    assert max(widths) <= 12


@pytest.mark.parametrize('corruption', ['stale', 'deterministic', 'incomplete', 'duplicate'])
def test_minibatches_reject_bad_batch_before_first_optimizer_step(corruption):
    runner, rows, _ = minibatch_toy()
    if corruption == 'stale':
        rows[-1]['policy_updates'] = 1
    elif corruption == 'deterministic':
        rows[-1]['behavior_deterministic'] = True
    elif corruption == 'incomplete':
        rows[-1]['completed'] = False
    else:
        rows[-1] = rows[0]
    with pytest.raises(ValueError, match='fresh complete'):
        update(runner, rows)
    assert runner.policy_updates == 0 and not runner.policy.actor_optimizer.state


def test_minibatches_lease_is_bounded_and_single_use():
    runner, rows, _ = minibatch_toy()
    lease = RolloutBatchLease(runner, rows, 6)
    with lease:
        assert lease.version_for(runner, rows[:12]) == 0
        with pytest.raises(ValueError, match='Nested'):
            RolloutBatchLease(runner, rows, 6)
        with pytest.raises(ValueError, match='Invalid'):
            lease.version_for(runner, [dict(rows[0])])
        runner.policy_updates = 7
        with pytest.raises(ValueError, match='Invalid'):
            lease.version_for(runner, rows)
        runner.policy_updates = 0
        rows[-1]['states'][0]['old_logp'][0] += .1
        with pytest.raises(ValueError, match='modified'):
            lease.version_for(runner, rows)
    with pytest.raises(ValueError, match='expired'):
        with lease:
            pass
    assert not hasattr(runner, '_active_rollout_batch')


def test_minibatches_full_epoch_kl_rejection_restores_every_state():
    runner, rows, _ = minibatch_toy()
    before = state_digest(snapshot(runner))
    original = runner.replay_metrics
    calls, journal = [], []
    runner.update_metrics_sink = journal.append
    def replay(group, *args, **kwargs):
        calls.append(len(group))
        result = original(group, *args, **kwargs)
        if len(group) == 36:
            result['roles']['1']['kl'] = .041
        return result
    runner.replay_metrics = replay
    result = update(runner, rows)
    assert calls == [12, 12, 12, 36]
    assert state_digest(snapshot(runner)) == before
    assert not any(e['actor_step_applied'] for e in result['epochs'])
    assert result['ppo_epoch_reports'][0]['epoch_rolled_back']
    assert result['stopped_early'] and result['behavior_data_unchanged']
    assert any(r.get('event') == 'whole_rollout_batch_kl' and r['epoch_rolled_back'] for r in journal)
    assert not hasattr(runner, '_active_rollout_batch')


def test_minibatches_technical_error_restores_epoch_without_retry():
    runner, rows, _ = minibatch_toy()
    before = state_digest(snapshot(runner))
    original, calls = runner.replay_metrics, []
    def replay(group, *args, **kwargs):
        calls.append(len(group))
        if len(calls) == 2:
            raise RuntimeError('injected technical failure')
        return original(group, *args, **kwargs)
    runner.replay_metrics = replay
    with pytest.raises(RuntimeError, match='injected technical'):
        update(runner, rows)
    assert len(calls) == 2 and state_digest(snapshot(runner)) == before
    assert not hasattr(runner, '_active_rollout_batch')


def test_minibatches_soft_kl_stops_without_rolling_back_accepted_steps():
    runner, rows, _ = minibatch_toy()
    original, calls = runner.replay_metrics, []
    def replay(group, *args, **kwargs):
        calls.append(len(group))
        result = original(group, *args, **kwargs)
        if len(calls) == 2:
            result['kl'] = .021
        return result
    runner.replay_metrics = replay
    result = update(runner, rows)
    assert calls == [12, 12, 36]
    assert runner.policy_updates == 2 and result['stopped_early']
    assert all(e['actor_step_applied'] for e in result['epochs'])


def test_minibatches_parent96_lineage_and_schedule288(tmp_path):
    parent = continuation_fixture(tmp_path)
    root = tmp_path/'batch96'
    root.mkdir()
    parent['root'] = str(root)
    parent['manifest_sha256'] = identity(parent)
    atomic_json(root/'manifest.json', parent)
    atomic_json(root/'training_admission.json', {'passed': True})
    entries = []
    for rank in range(8):
        path = root/f'rank{rank}.pt'
        path.write_bytes(b'synthetic-not-model-weights')
        entries.append({'rank': rank, 'checkpoint': str(path), 'sha256': digest_file(path)})
    atomic_json(root/'commit.json', {'world_size': 8, 'ranks': entries,
        'training_episodes': 608, 'actual_actor_updates': 34, 'protocol_sha256': parent['manifest_sha256'],
        'schedule_sha256': digest_json(continuation_plan(parent)),
        'recipe_sha256': digest_file(root/'training_admission.json')})
    child = copy.deepcopy(parent)
    child['training'] = training_contract(288)
    child['throughput'].update(version=MINIBATCH_VERSION, authorization=MINIBATCH_AUTHORIZATION,
        parent_manifest=str(root/'manifest.json'), parent_manifest_sha256=digest_file(root/'manifest.json'),
        resume_commit=str(root/'commit.json'), resume_commit_sha256=digest_file(root/'commit.json'),
        start_episodes=608, start_actor_updates=34, global_batch=288, rollout_envs_per_rank=12,
        rollout_trajectories_per_rank=36, backward_trajectories_per_rank=12,
        gradient_accumulation_microbatches=1, optimizer_step_after_microbatches=False,
        optimizer_step_per_microbatch=True, optimizer_minibatches=3, optimizer_global_batch=96,
        release_environments_after_rollout=True, fresh_rollout_cadence_changed=True,
        optimizer_update_cadence_changed=False,
        parent_evidence={str(root/'training_admission.json'): digest_file(root/'training_admission.json')})
    child['throughput']['schedule_sha256'] = digest_json(continuation_plan(child))
    assert parent_manifest(child)['training']['global_batch'] == 96
    plan = continuation_plan(child)
    assert len(plan) == 30 and [b['batch_size'] for b in plan[:2]] == [288, 64]
    assert [b['batch_size'] for b in plan[2:6]] == [288, 288, 288, 96]
    from onpolicy.utils.stage3_full_data import schedule
    assert flatten(plan) == flatten(schedule(cases(), child['training']['seed']))[608:]
    assert sum((b['batch_size']+95)//96 for b in plan)*2 == 148
    for name, value in [('backward_trajectories_per_rank', 36), ('optimizer_step_per_microbatch', False),
                        ('gradient_accumulation_microbatches', 3), ('optimizer_update_cadence_changed', True)]:
        changed = copy.deepcopy(child)
        changed['throughput'][name] = value
        with pytest.raises(ValueError, match='contract'):
            parent_manifest(changed)


def _rank_minibatches(rank, init_file):
    from onpolicy.utils.stage3_distributed import TrajectoryParallel
    torch.set_num_threads(1)
    dist.init_process_group('gloo', init_method='file://'+init_file, rank=rank, world_size=8,
                            timeout=timedelta(seconds=120))
    try:
        sync = TrajectoryParallel(device_packed=True)
        runner, rows, widths = minibatch_toy()
        result = update(runner, rows, distributed=sync)
        assert runner.policy_updates == 6 and len(result['epochs']) == 6
        assert max(widths) == 12 and result['behavior_data_unchanged']
        sync.assert_replicas(runner)
        assert all(r['weights'] == pytest.approx([1/12]*12) for r in result['minibatch_objectives'])
        assert all(e['decisions'] == 8*3*sum(len(r['states']) for r in rows[(e['optimizer_minibatch']-1)*12:e['optimizer_minibatch']*12])
                   for e in result['epochs'])
        actor = torch.nn.Parameter(torch.tensor([.2]))
        critic = torch.nn.Parameter(torch.tensor([.4]))
        expected_actor, expected_critic = torch.nn.Parameter(actor.detach().clone()), torch.nn.Parameter(critic.detach().clone())
        policy = SimpleNamespace(actor_optimizer=torch.optim.Adam([actor]), critic_optimizer=torch.optim.Adam([critic]))
        expected_opts = [torch.optim.Adam([expected_actor]), torch.optim.Adam([expected_critic])]
        for _ in range(2):
            for index in range(3):
                for opt in [policy.actor_optimizer, policy.critic_optimizer, *expected_opts]:
                    opt.zero_grad(set_to_none=True)
                weights, denom = sync.objective_weights([f'case{i}' for i in range(12)], 12, visit_balanced=True)
                x = torch.arange(index*96+rank, (index+1)*96, 8, dtype=torch.float32)
                (actor*x*torch.tensor(weights)).sum().backward()
                (critic.square()*12/denom).backward()
                sync.synchronize_update(policy, dict(kl=0., clip=0., logp=0., decisions=12., mask_mismatch=0))
                (expected_actor*torch.arange(index*96, (index+1)*96, dtype=torch.float32).mean()).backward()
                expected_critic.square().backward()
                torch.testing.assert_close(actor.grad, expected_actor.grad)
                torch.testing.assert_close(critic.grad, expected_critic.grad)
                for opt in [policy.actor_optimizer, policy.critic_optimizer, *expected_opts]:
                    opt.step()
                torch.testing.assert_close(actor, expected_actor)
                torch.testing.assert_close(critic, expected_critic)
    finally:
        dist.destroy_process_group()


def test_minibatches_eight_rank_three_optimizer_batches(tmp_path):
    mp.spawn(_rank_minibatches, args=(str(tmp_path/'store'),), nprocs=8, join=True)


def test_minibatches_collect36_releases_and_recreates_environment_pool(monkeypatch):
    from onpolicy.scripts.train.stage3_b0_worker import collect
    pools, calls = [], []
    class Pool:
        def __init__(self, width):
            self.width, self.closed = width, False
            pools.append(self)
        def close(self):
            assert not self.closed
            self.closed = True
    monkeypatch.setattr('onpolicy.runner.shared.stage3_research_engine.EnvironmentPool', Pool)
    runner = SimpleNamespace(width=12, pool=Pool(12), release_environments_after_rollout=True)
    def rollout(cases, seeds, **kwargs):
        assert not runner.pool.closed
        calls.append(len(cases))
        return list(zip(cases, seeds))
    runner.rollout = rollout
    batch = {'cases': list(range(36)), 'seeds': list(range(100, 136))}
    for _ in range(2):
        assert collect(runner, batch, None) == list(zip(batch['cases'], batch['seeds']))
        assert runner.pool is None
    assert calls == [12]*6 and len(pools) == 2 and all(p.closed for p in pools)


def test_minibatches_mechanism_reads_original_fixed_b0_archives(tmp_path, monkeypatch):
    from onpolicy.utils.stage3_b0_diagnostics import fixed_references
    from onpolicy.utils.stage3_b0_protocol import MECHANISM
    case, archives = {'path': 'synthetic-fixture'}, {}
    parent = {'root': str(tmp_path/'original'), 'diagnostic': {'cases32': [case]}}
    monkeypatch.setattr('onpolicy.utils.stage3_b0_throughput.reference_manifest', lambda m: parent)
    for replica in range(MECHANISM['fixed_b0_replicas']):
        path = Path(parent['root'])/f'sampling/temperatures/rank0/tau0.03_r{replica}.json'
        path.parent.mkdir(parents=True, exist_ok=True)
        trace = path.with_suffix('.npz')
        np.savez_compressed(trace, **{f'trajectory_0_seed_{replica}': np.zeros((2, 3, 3))})
        archives[str(trace)] = digest_file(trace)
        atomic_json(path, {'trace': {'path': str(trace), 'sha256': archives[str(trace)]},
            'trajectories': [{'case_id': case['path'], 'exploration': {'taus': [.03]*3}, 'seed': replica}]})
        archives[str(path)] = digest_file(path)
    atomic_json(Path(parent['root'])/'sampling_admission.json', {'archives': archives})
    rows = list(fixed_references({'root': str(tmp_path/'continuation'), 'throughput': {'version': MINIBATCH_VERSION}}, case, .03))
    assert len(rows) == MECHANISM['fixed_b0_replicas']
    assert all(actions.shape == (2, 3, 3) for _, actions in rows)


def test_minibatches_real_b0_cpu_private_six_steps(record_property):
    """Real private GNN + RNN with synthetic two-step episodes, not reward evidence."""
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.utils.stage3_research import WORKSPACE_ROOT, case_record
    manifest = Path(__file__).resolve().parents[4]/'artifacts/stage2_frozen/20260912/manifest.json'
    # A two-step fixture is deliberately NOT the production KL-admission test.
    # Use a small LR to isolate the six-step loop; full GPU capacity uses the
    # unmodified committed production optimizer and learning rate.
    runner = B0Engine(manifest, 'F_PRIVATE', device='cpu', width=1, actor_lr=1e-7)
    original_call = runner.pool.call
    def prefix(commands):
        result = original_call(commands)
        for i, command, _ in commands:
            if command == 'summary':
                result[i] = {**result[i], 'completed': True, 'synthetic_prefix_fixture': True}
        return result
    runner.pool.call = prefix
    try:
        case = case_record(WORKSPACE_ROOT/'onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train/case_0341')
        row = runner.rollout([case], [2026091301], retain=True, max_steps=2)[0]
        rows = [dict(row, case_id=f'fixture{i}', states=row['states']) for i in range(36)]
        old = behavior_digest(rows)
        result = runner.update(rows, 'source', {r['case_id']: r['makespan']+30 for r in rows},
            epochs=2, chunk=8, microbatch_size=12, optimizer_step_per_microbatch=True)
        assert runner.policy_updates == result['accepted_actor_steps'] == 6
        assert old == behavior_digest(rows) and result['behavior_data_unchanged']
        assert not any(e['epoch_rolled_back'] for e in result['ppo_epoch_reports'])
        assert not any(p.requires_grad for p in runner.policy.ac.request_ready_head.parameters())
        record_property('accepted_actor_steps', result['accepted_actor_steps'])
        record_property('whole_batch_post_kl', result['ppo_epoch_reports'][-1]['full_batch_post_update']['kl'])
        record_property('diagnostic_synthetic_prefix_only', True)
        record_property('diagnostic_fixture_actor_lr', 1e-7)
    finally:
        runner.close()
