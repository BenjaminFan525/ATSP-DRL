"""Synthetic data/lineage/service fixtures, never claimed as reward evidence."""
import copy
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

import pytest

from onpolicy.utils import stage3_b0_subset240 as subset
from onpolicy.utils.stage3_b0_protocol import identity
from onpolicy.utils.stage3_b0_throughput import (continuation_plan, parent_manifest,
    epoch_endpoint, completed_epoch, epoch_owner)
from onpolicy.utils.stage3_research import atomic_json, read_json, digest_file, digest_json
from onpolicy.envs.HKBZ.test.test_stage3_b0_env60 import parent36_fixture, child_recipe, committed
from onpolicy.envs.HKBZ.test.test_stage3_b0_throughput import cases, flatten


def fixture_selection(monkeypatch):
    chosen = subset.selection()
    full = cases()
    chosen['case_ids'] = [c['name'] for c in full[:192]+full[480:523]+full[588:593]]
    monkeypatch.setattr(subset, 'selection', lambda: copy.deepcopy(chosen))
    return chosen


def subset_fixture(tmp_path, monkeypatch):
    fixture_selection(monkeypatch)
    p36, c36 = parent36_fixture(tmp_path, 896)
    p60 = child_recipe(p36, c36, 60)
    p60['code'] = {'files': {'onpolicy/runner/shared/stage3_b0_engine.py': 'unchanged-numerical-file'}}
    parent, commit = committed(p60, tmp_path/'env60', 960, 42)
    child = copy.deepcopy(parent)
    child['root'] = str(tmp_path/'subset240')
    child['training'] = subset.training_contract()
    child['subset_training'] = subset.data_contract(parent['splits']['train_full600'])
    child['splits']['train_subset240'] = subset.select_cases(parent['splits']['train_full600'])
    child['resources']['validator_queue'] = str(Path(child['root'])/'validator')
    child['code']['files'].update({p: 'synthetic-overlay' for p in subset.OVERLAYS})
    child['throughput'].update(parent_manifest=str(Path(parent['root'])/'manifest.json'),
        parent_manifest_sha256=digest_file(Path(parent['root'])/'manifest.json'),
        resume_commit=str(commit), resume_commit_sha256=digest_file(commit), start_episodes=960,
        start_actor_updates=42, snapshot_overlay_files=list(subset.OVERLAYS), inherited_epoch_evidence={},
        parent_evidence={str(Path(parent['root'])/'training_admission.json'):
            digest_file(Path(parent['root'])/'training_admission.json')})
    child['throughput']['schedule_sha256'] = digest_json(continuation_plan(child))
    child['manifest_sha256'] = identity(child)
    return parent, child, commit


def test_subset240_exact_user_selection_is_immutable():
    chosen = subset.selection()
    assert len(chosen['case_ids']) == len(set(chosen['case_ids'])) == 240
    assert chosen['case_ids'][:3] == ['case_0007', 'case_0008', 'case_0009']
    assert chosen['case_ids'][-3:] == ['case_0597', 'case_0599', 'case_0600']
    assert chosen['distribution_counts'] == subset.COUNTS
    assert sum(subset.COUNTS[k]*subset.REPETITIONS[k] for k in subset.COUNTS) == 384


def test_subset240_schedule_preserves_selected_original_seeds_and_seven_epochs(tmp_path, monkeypatch):
    from onpolicy.utils.stage3_full_data import schedule
    from onpolicy.utils.stage3_full_policy import shard
    parent, child, _ = subset_fixture(tmp_path, monkeypatch)
    plan = continuation_plan(child)
    selected = {c['path'] for c in child['splits']['train_subset240']}
    expected = [r for r in flatten(schedule(parent['splits']['train_full600'], child['training']['seed']))[960:]
                if r[0] in selected]
    assert flatten(plan) == expected and len(expected) == 2688
    assert [b['data_epoch'] for b in plan] == list(range(2, 9))
    assert [b['training_episodes'] for b in plan] == subset.ENDPOINTS[1:]
    assert subset.FINAL == 3648 and all(b['batch_size'] == 384 and b['epoch_tail'] for b in plan)
    for batch in plan:
        counts = Counter(c['path'] for c in batch['cases'])
        assert set(counts) == selected and len(counts) == 240
        assert all(counts[c['path']] == subset.REPETITIONS[c['distribution']]
                   for c in child['splits']['train_subset240'])
        assert all(len(shard(batch, rank, 8)['cases']) == 48 for rank in range(8))
        assert len({v.split(':')[0] for v in batch['visit_ids']}) == 1


@pytest.mark.parametrize('change', ['duplicate', 'missing', 'counts', 'visits', 'hash_alias'])
def test_subset240_selection_rejects_missing_duplicate_or_reweighted_cases(monkeypatch, change):
    chosen = fixture_selection(monkeypatch)
    full = cases()
    if change == 'duplicate':
        chosen['case_ids'][0] = chosen['case_ids'][1]
    elif change == 'missing':
        chosen['case_ids'][0] = 'nonexistent'
    elif change == 'counts':
        full[0]['distribution'] = 'ood_stress'
    elif change == 'visits':
        chosen['visits_per_case']['ood_stress'] = 2
    else:
        full[0]['content_sha256'] = full[1]['content_sha256']
    with pytest.raises(ValueError):
        subset.select_cases(full, chosen)


def test_subset240_only_data_budget_changes_and_epoch1_keeps_its_owner(tmp_path, monkeypatch):
    parent, child, _ = subset_fixture(tmp_path, monkeypatch)
    assert parent_manifest(child)['manifest_sha256'] == parent['manifest_sha256']
    assert {k:v for k,v in child['training'].items() if k not in
        ('episodes_per_data_epoch', 'max_training_episodes', 'training_split', 'unique_training_cases')} == {
        k:v for k,v in parent['training'].items() if k not in ('episodes_per_data_epoch', 'max_training_episodes')}
    assert [epoch_endpoint(child, e) for e in range(1, 9)] == subset.ENDPOINTS
    assert [completed_epoch(child, n) for n in subset.ENDPOINTS] == list(range(1, 9))
    assert completed_epoch(child, 1920) is None and completed_epoch(child, 1344) == 2
    assert completed_epoch(parent, 1920) == 2 and completed_epoch(parent, 1344) is None
    assert epoch_owner(child, 960)[0]['manifest_sha256'] == parent['manifest_sha256']
    assert epoch_owner(child, 1344)[1] == Path(child['root'])/'epochs/e001344.json'
    assert len(child['splits']['train_full600']) == 600  # reference, NOT active training


@pytest.mark.parametrize('change', ['lr', 'backward', 'envs', 'epochs', 'memory', 'model_code',
                                  'selection', 'b0', 'diagnostic', 'checkpoint'])
def test_subset240_rejects_unapproved_setting_or_lineage_changes(tmp_path, monkeypatch, change):
    parent, child, commit = subset_fixture(tmp_path, monkeypatch)
    if change == 'lr':
        child['training']['actor_lr'] = 2e-5
    elif change == 'backward':
        child['throughput']['backward_trajectories_per_rank'] = 24
    elif change == 'envs':
        child['throughput']['rollout_envs_per_rank'] = 48
    elif change == 'epochs':
        child['training']['max_training_episodes'] = 4032
    elif change == 'memory':
        child['resources']['memory_max_gib'] = 108
    elif change == 'model_code':
        child['code']['files']['onpolicy/runner/shared/stage3_b0_engine.py'] = 'different'
    elif change == 'selection':
        child['splits']['train_subset240'][0] = child['splits']['train_full600'][193]
    elif change == 'b0':
        child['source']['sha256'] = 'changed-source'
    elif change == 'diagnostic':
        row = read_json(commit)
        row['diagnostic_only'] = True
        atomic_json(commit, row)
        child['throughput']['resume_commit_sha256'] = digest_file(commit)
    else:
        Path(read_json(commit)['ranks'][7]['checkpoint']).write_bytes(b'tampered')
    with pytest.raises(ValueError):
        parent_manifest(child)


def test_subset240_mechanism_uses_logical_epochs_not_division_by960(tmp_path):
    from onpolicy.envs.HKBZ.test.test_stage3_b0 import queue_fixture
    from onpolicy.utils.stage3_b0_protocol import submit, MECHANISM
    m, checkpoint, _ = queue_fixture(tmp_path)
    m['subset_training'] = {'version': subset.VERSION}
    atomic_json(tmp_path/'sampling_admission.json', {'selected_tau': .03})
    diagnostic = {'recipe': MECHANISM, 'sampling_sha256': digest_file(tmp_path/'sampling_admission.json'),
                  'selected_tau': .03}
    for episodes in (1344, 2112, 3648):
        submit(m, checkpoint, 'C_PRIVATE', episodes, 'F_PRIVATE', split='train_full600',
               kind='mechanism', diagnostic=diagnostic)
    for episodes in (1728, 1920, 1345):
        with pytest.raises(ValueError, match='train-only'):
            submit(m, checkpoint, 'C_PRIVATE', episodes, 'F_PRIVATE', split='train_full600',
                   kind='mechanism', diagnostic=diagnostic)


def test_subset240_four12_minibatches_eight_steps():
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy, update
    runner, rows, widths = minibatch_toy(48)
    result = update(runner, rows)
    assert runner.policy_updates == 8 and max(widths) == 12
    assert result['behavior_data_unchanged'] and result['backward_microbatches'] == 4
    assert [e['optimizer_minibatch'] for e in result['epochs']] == [1,2,3,4]*2
    assert all(not e['epoch_rolled_back'] for e in result['ppo_epoch_reports'])


def test_subset240_worker_finishes3648_and_submits_all_seven_epoch_checks(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_b0_large_batch_worker as worker
    parent, m, _ = subset_fixture(tmp_path, monkeypatch)
    root = Path(m['root'])
    atomic_json(root/'sampling_admission.json', {'selected_tau': .03})
    atomic_json(root/'training_admission.json', {'passed': True, 'protocol_sha256': m['manifest_sha256'],
        'global_batch': 480, 'parent_commit_sha256': m['throughput']['resume_commit_sha256'],
        'sampling_sha256': digest_file(root/'sampling_admission.json'), 'evidence': {}})
    output = root/'train/full/rank0'
    output.mkdir(parents=True)
    args = SimpleNamespace(world_size=8, rank=0, until=3648, resume_commit=None, output=output)
    selected = {c['path'] for c in m['splits']['train_subset240']}
    runner = SimpleNamespace(policy_updates=42, exploration={'taus': [.03]*3}, pool=SimpleNamespace(processes=[]),
        environment_start_method='forkserver', last_rollout_inference={}, zero_update_batches=0, close=lambda: None)
    def collect(r, local, hb):
        assert len(local['cases']) == 48 and all(c['path'] in selected for c in local['cases'])
        return [{'case_id': c['path'], 'seed': s} for c,s in zip(local['cases'], local['seeds'])]
    def update(rows, *unused, **kwargs):
        assert len(rows) == 48 and kwargs['microbatch_size'] == 12
        assert kwargs['epochs'] == 2 and kwargs['chunk'] == 8 and kwargs['optimizer_step_per_microbatch']
        runner.policy_updates += 8
        return {'synthetic_worker_fixture': True}
    def save(path, **metadata):
        assert metadata['diagnostic_only'] is False and metadata['rank'] == 0
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b'synthetic-worker-routing-not-model-weights')
        return digest_file(path)
    runner.update, runner.save = update, save
    monkeypatch.setattr(worker, 'engine', lambda manifest, kind, width: runner if kind == 'F_PRIVATE' and width == 60 else None)
    monkeypatch.setattr(worker, 'restore_parent', lambda r, manifest, rank: {
        'protocol_sha256': parent['manifest_sha256'], 'training_episodes': 960, 'policy_updates': 42})
    monkeypatch.setattr(worker, 'baseline_costs', lambda manifest: {p: 1. for p in selected})
    monkeypatch.setattr(worker, 'collect', collect)
    monkeypatch.setattr(worker, 'attach_journal', lambda *a: None)
    monkeypatch.setattr(worker, 'save_group', lambda *a: None)
    monkeypatch.setattr(worker, 'metadata', lambda manifest, **kw: kw)
    monkeypatch.setattr(worker, 'training_state', lambda r: {'synthetic': True})
    monkeypatch.setattr(worker, 'frozen_state', lambda r: {})
    monkeypatch.setattr(worker, 'assert_frozen', lambda *a: None)
    monkeypatch.setattr(worker, 'queue', lambda manifest: SimpleNamespace(pending_count=lambda *a: 0))
    submitted, diagnostics = [], []
    def submit_split(manifest, checkpoint, arm, episodes, representation, **kwargs):
        submitted.append((episodes, kwargs['split']))
        return [f'{episodes}_{kwargs["split"]}']
    def mechanism(manifest, checkpoint, episodes):
        diagnostics.append(episodes)
        return [f'mechanism_{episodes}']
    monkeypatch.setattr(worker, 'submit_split', submit_split)
    monkeypatch.setattr(worker, 'submit_mechanism', mechanism)
    for name in ('reset_peak_memory_stats', 'synchronize'):
        monkeypatch.setattr(worker.torch.cuda, name, lambda: None)
    for name in ('max_memory_allocated', 'max_memory_reserved'):
        monkeypatch.setattr(worker.torch.cuda, name, lambda: 0)
    sync = SimpleNamespace(barrier=lambda: None, assert_replicas=lambda r: None,
        gather=lambda value: [{**value, 'rank': i} for i in range(8)] if isinstance(value, dict) else [value]*8)
    events = []
    worker.train(args, m, sync, SimpleNamespace(update=lambda **kw: events.append(kw)))
    assert read_json(output/'result.json')['training_episodes'] == 3648
    assert runner.policy_updates == 42+7*8
    assert submitted == [(e,s) for e in subset.ENDPOINTS[1:] for s in ('validation', 'tune')]
    assert diagnostics == [1344, 2112, 3648]
    commits = sorted((root/'train/commits').glob('*.json'))
    assert len(commits) == 7 and read_json(commits[-1])['training_episodes'] == 3648
    assert [e['data_epoch'] for e in events if e['event'] == 'batch_start'] == list(range(2,9))


def test_subset240_real_eight_rank_eight_steps(tmp_path):
    import torch.multiprocessing as mp
    from onpolicy.envs.HKBZ.test.test_stage3_b0_env48 import _env48rank
    mp.spawn(_env48rank, args=(str(tmp_path/'store'),), nprocs=8, join=True)


def test_subset240_capacity_reuse_requires_passed_full_parent_not_diagnostic_weights(tmp_path, monkeypatch):
    parent, child, commit = subset_fixture(tmp_path, monkeypatch)
    root = Path(parent['root'])
    evidence = {}
    for rank in range(8):
        path = root/f'capacity/large_batch_dense/rank{rank}/result.json'
        atomic_json(path, {'passed': True, 'update': {'accepted_actor_steps': 10,
            'backward_microbatch_size': 12, 'rollout_trajectories': 60,
            'ppo_epoch_reports': [{'epoch_rolled_back': False}]*2}})
        evidence[str(path)] = digest_file(path)
    report = {'passed': True, 'protocol_sha256': parent['manifest_sha256'], 'world_size': 8,
        'global_batch': 480, 'rollout_envs_per_rank': 60, 'backward_microbatch': 12,
        'optimizer_minibatches': 5, 'optimizer_step_per_microbatch': True,
        'full_trajectories_and_two_epoch_ppo': True, 'diagnostic_weights_discarded': True,
        'batched_sampling_verified': True, 'evidence': evidence}
    atomic_json(root/'training_admission.json', report)
    row = read_json(commit)
    row['recipe_sha256'] = digest_file(root/'training_admission.json')
    atomic_json(commit, row)
    child['throughput']['resume_commit_sha256'] = digest_file(commit)
    child['throughput']['parent_evidence'][str(root/'training_admission.json')] = row['recipe_sha256']
    atomic_json(Path(child['root'])/'sampling_admission.json', {'selected_tau': .03})
    admitted = subset.capacity_reuse(child)
    assert admitted['passed'] and not admitted['new_gpu_capacity_test_performed']
    assert admitted['formal_subset_trajectories_per_rank'] == 48
    assert admitted['model_optimizer_normalizer_rng_resume_source'] == str(commit)
    path = Path(next(iter(evidence)))
    bad = read_json(path)
    bad['passed'] = False
    atomic_json(path, bad)
    with pytest.raises(ValueError):
        subset.capacity_reuse(child)


def test_subset240_handoff_health_is_bound_and_time_limited():
    from onpolicy.scripts.train.stage3_b0_subset240 import handoff_location
    m = {'root': '/new', 'manifest_sha256': 'new', 'validator_handoff': {
        'parent_root': '/old', 'parent_protocol_sha256': 'old', 'transition_sha256': 'plan'}}
    state = {'protocol_sha256': 'new', 'parent_protocol_sha256': 'old', 'transition_sha256': 'plan',
             'phase': 'draining_parent_pool', 'heartbeat_unix': 100}
    assert handoff_location(m, state, now=101) == Path('/old')
    assert handoff_location(m, {**state, 'phase': 'switching_pool', 'switch_started_unix': 100}, now=101) is None
    assert handoff_location(m, {**state, 'phase': 'new_pool_active'}, now=999) == Path('/new')
    for bad in ({**state, 'phase': 'failed'}, {**state, 'heartbeat_unix': 0},
                {**state, 'phase': 'switching_pool', 'switch_started_unix': 0}):
        with pytest.raises(RuntimeError):
            handoff_location(m, bad, now=200)
    with pytest.raises(ValueError):
        handoff_location(m, {**state, 'transition_sha256': 'wrong'}, now=101)


def test_subset240_launcher_rejects_overlapping_validator_pools(tmp_path, monkeypatch):
    from onpolicy.scripts.train import queue_stage3_b0_subset240 as transition
    plan = {'current_root': str(tmp_path/'old'), 'output_root': str(tmp_path/'new')}
    monkeypatch.setattr(transition, 'run_unit', lambda p: Path(p).name)
    monkeypatch.setattr(transition, 'service', lambda unit: {'MainPID': '123' if 'validator' in unit else '0',
                                                          'ExecMainStatus': '0'})
    with pytest.raises(RuntimeError, match='Never overlap'):
        transition.launch(plan, 'validator')


def test_subset240_transition_starts_training_before_serial_pool_handoff(tmp_path, monkeypatch):
    from onpolicy.scripts.train import queue_stage3_b0_subset240 as transition
    parent, child, commit = subset_fixture(tmp_path, monkeypatch)
    current, output, staging = Path(parent['root']), Path(child['root']), tmp_path/'staging'
    staging.mkdir()
    (staging/'source').mkdir()
    child['validator_handoff'] = {'parent_root': str(current),
        'parent_protocol_sha256': parent['manifest_sha256'], 'transition_sha256': 'fixture'}
    plan = {'schema': transition.SCHEMA, 'authorization': subset.AUTHORIZATION,
        'current_root': str(current), 'output_root': str(output), 'staging_root': str(staging),
        'target_episodes': 960, 'parent_manifest_sha256': digest_file(current/'manifest.json'),
        'python': 'synthetic-no-execution', 'timeout_seconds': 60, 'poll_seconds': 0,
        'plan_sha256': 'fixture', 'files': child['code']['files']}
    atomic_json(staging/'transition.json', plan)
    for rank in range(8):
        atomic_json(current/f'train/full/rank{rank}/result.json', {'paused': True, 'training_episodes': 960})
    atomic_json(current/'train/full/rank0/status.json', {'phase': 'train', 'global_batch': 1,
        'training_episodes': 896, 'event': 'update'})
    for kind in ('epochs', 'mechanism'):
        atomic_json(current/kind/'e000960.json', {'requests': [kind+'_request']})
        atomic_json(current/'validator/results'/f'{kind}_request.json', {'fixture_result': True})
    states = iter([{'phase': 'full_data_training'}, {'phase': 'paused_at_commit'}])
    actual_read = transition.read_json
    monkeypatch.setattr(transition, 'read_json', lambda p: next(states) if Path(p) == current/'status.json' else actual_read(p))
    monkeypatch.setattr(transition, 'ROOT', staging/'source')
    monkeypatch.setattr(transition, 'verify_staged', lambda p: None)
    monkeypatch.setattr(transition, 'run_unit', lambda p: Path(p).name)
    monkeypatch.setattr(transition.time, 'sleep', lambda seconds: None)
    calls, pending = [], [2, 1, 0]
    def services(unit):
        if unit == current.name+'-training.service':
            return {'MainPID': '0', 'ExecMainStatus': '0', 'ActiveState': 'active'}
        return {'MainPID': '0' if (current/'validator/STOP').exists() else '1',
                'ExecMainStatus': '0', 'ActiveState': 'active'}
    monkeypatch.setattr(transition, 'service', services)
    monkeypatch.setattr(transition, 'queue', lambda m: SimpleNamespace(
        pending_count=lambda: pending.pop(0) if pending else 0, poll=lambda r: {'fixture': True}))
    def prepare_command(argv, **kwargs):
        assert '--prepare-plan' in argv
        atomic_json(output/'manifest.json', child)
    monkeypatch.setattr(transition.subprocess, 'run', prepare_command)
    def fake_launch(p, role):
        if role == 'training':
            assert not (current/'validator/STOP').exists()
            assert read_json(output/'validator_handoff.json')['phase'] == 'draining_parent_pool'
        else:
            assert calls == ['training'] and (current/'validator/STOP').exists()
            atomic_json(output/'validator/pool_status.json', {'status': 'running'})
        calls.append(role)
    monkeypatch.setattr(transition, 'launch', fake_launch)
    transition.run(staging/'transition.json')
    assert calls == ['training', 'validator']
    assert read_json(staging/'completed.json')['single_pool_handoff_complete']
    assert read_json(output/'validator_handoff.json')['phase'] == 'new_pool_active'
    assert commit.exists() and len(list(current.glob('train/full/rank*/models/*.pt'))) == 8
