"""Regression tests for the matched-IGA DeviceBC/PPO causal pipeline."""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

import numpy as np

from onpolicy.config.config import get_config
from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
from onpolicy.scripts.train import prepare_stage2_iga_distill_ppo as research
from onpolicy.scripts.train.train_hkbz import parse_args as parse_training_args


class Stage2IgaDistillPpoTest(unittest.TestCase):
    def test_device_bc_merge_exports_auditable_score_margins(self):
        runner = HKBZ_Runner.__new__(HKBZ_Runner)
        runner.policy = SimpleNamespace(
            ac=SimpleNamespace(max_plane_agents=2)
        )
        runner.num_agents = 4
        policy = np.zeros((1, 4, 2), dtype=np.int64)
        teacher = np.zeros((4, 2), dtype=np.int64)
        teacher[2, 0] = 3
        result = {
            "actions": teacher,
            "info": {
                "real_dispatches": 1,
                "decisions": [
                    {
                        "agent_id": 2,
                        "selected_request_id": 3,
                        "selected_score_margin": 0.125,
                    },
                    {
                        "agent_id": 3,
                        "selected_request_id": 0,
                        "selected_score_margin": None,
                    },
                ],
            },
        }
        actions, labels, stats, metadata = runner._merge_device_bc_actions(
            policy, [result], np.asarray([True]), return_metadata=True
        )
        self.assertEqual(actions[0, 2, 0], 3)
        self.assertEqual(labels[0, 2, 0], 3)
        self.assertEqual(stats["real_dispatches"], 1)
        self.assertAlmostEqual(
            float(metadata["teacher_score_margins"][0, 2]), 0.125
        )
        self.assertTrue(
            np.isnan(metadata["teacher_score_margins"][0, 3])
        )

    def test_common_command_is_small_batch_hard_matched_and_parseable(self):
        source = {"path": "/tmp/source.pt"}
        with mock.patch.object(
            research, "build_stage2_command",
            return_value=["python", "train_hkbz.py"],
        ), mock.patch.object(
            research, "configure_command",
            side_effect=lambda base, *args, **kwargs: list(base),
        ):
            command = research.common_command(
                source,
                [],
                run_tag="test",
                method_id="T1_iga_plain",
                python=Path("/tmp/python"),
                teacher_dir=Path("/tmp/teachers"),
                teacher_index=Path("/tmp/index.json"),
            )
        parsed = parse_training_args(command[2:], get_config())
        self.assertEqual(parsed.max_train_cases, 0)
        self.assertEqual(
            parsed.train_sampling_size, research.TRAIN_CASE_SLOTS
        )
        self.assertEqual(parsed.n_rollout_threads, 30)
        self.assertEqual(parsed.max_graphs_per_forward, 1500)
        self.assertTrue(parsed.device_deadline_aware_dispatch)
        self.assertTrue(parsed.resource_release_aware_eta)
        self.assertTrue(parsed.device_departure_lookahead)
        self.assertEqual(parsed.device_future_intent_mode, "bounded_frontier")
        self.assertEqual(parsed.device_lookahead_reservation_mode, "hard")

    def test_small_batch_keeps_every_ood_case_without_duplicates(self):
        coverage = research.small_batch_coverage_audit(
            research.DEFAULT_DATASET,
            seed=1,
            n_rollout_threads=research.ROLLOUT_THREADS,
        )
        self.assertEqual(coverage["selected_cases"], 240)
        self.assertEqual(coverage["unique_cases"], 240)
        self.assertEqual(coverage["shards_per_epoch"], 8)
        self.assertEqual(
            coverage["selected_distribution_counts"],
            research.TRAIN_DISTRIBUTION_COUNTS,
        )
        self.assertEqual(
            coverage["unique_distribution_counts"],
            research.TRAIN_DISTRIBUTION_COUNTS,
        )
        self.assertTrue(coverage["all_ood_unique_cases_retained"])

    def test_bc_and_ppo_matrices_have_one_clean_causal_boundary(self):
        self.assertEqual(len(research.BC_METHODS), 6)
        self.assertEqual(len(research.PPO_METHODS), 6)
        self.assertEqual(research.BC_ROLLOUTS, 8)
        self.assertEqual(
            research.PPO_EPOCHS
            * (research.TRAIN_CASE_SLOTS // research.ROLLOUT_THREADS),
            64,
        )
        self.assertEqual(
            sum(method["teacher"] == "heuristic"
                for method in research.BC_METHODS.values()),
            1,
        )
        self.assertEqual(
            sum(method.get("counterfactual_q", False)
                for method in research.PPO_METHODS.values()),
            2,
        )
        self.assertFalse(research.PPO_METHODS["P0_legacy"].get(
            "role_atomic", False
        ))
        self.assertTrue(research.PPO_METHODS["P5_sequential_roles"][
            "role_sequential"
        ])

    def test_selection_rejects_bad_runs_and_chooses_lowest_valid_score(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            commands = {}
            for method, score, completion in (
                ("T0", 9000.0, 1.0),
                ("T1", 8800.0, 1.0),
                ("T2", 8700.0, 0.9),
            ):
                experiment = f"experiment_{method}"
                run_dir = (
                    root / "onpolicy/scripts/results/HKBZ/simple/gnn_mappo"
                    / experiment / "run1"
                )
                (run_dir / "evaluations").mkdir(parents=True)
                (run_dir / "models").mkdir()
                (run_dir / "evaluations/pre_ppo.json").write_text(
                    json.dumps({"summary": {
                        "eval_selection_score": score,
                        "eval_raw_makespan": score - 100.0,
                        "eval_completion_rate": completion,
                        "eval_timeout_count": 0,
                        "eval_cycle_count": 0,
                    }}),
                    encoding="utf-8",
                )
                (run_dir / "models/checkpoint_DeviceBC.pt").write_bytes(
                    method.encode("ascii")
                )
                commands[method] = {
                    "argv": [
                        "python", "train.py", "--experiment_name", experiment
                    ]
                }
            manifest = root / "bc.json"
            manifest.write_text(json.dumps({"commands": commands}))
            output = root / "selection.json"
            args = SimpleNamespace(bc_manifest=manifest, output=output)
            with mock.patch.object(research, "ROOT", root):
                payload = research.select_bc(args)
            self.assertEqual(payload["selected_method"], "T1")
            self.assertFalse(next(
                row for row in payload["rows"] if row["method"] == "T2"
            )["valid"])
            self.assertTrue(output.is_file())


if __name__ == "__main__":
    unittest.main()
