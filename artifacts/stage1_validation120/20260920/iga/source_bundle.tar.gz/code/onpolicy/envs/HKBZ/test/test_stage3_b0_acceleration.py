"""Synthetic orchestration tests; never promoted to scientific trajectory evidence."""
import copy
from pathlib import Path
from types import SimpleNamespace

import pytest

from onpolicy.utils.stage3_b0_acceleration import (
    pool_placements, assert_pool_request, complete_rows, baseline_evidence, canary_costs, source_equivalence,
)
from onpolicy.utils.stage3_b0_protocol import B0_SHA, EVALUATION, PLANNING, B0Queue, identity
from onpolicy.utils.stage3_full_policy import resource_plan
from onpolicy.utils.stage3_research import atomic_json, digest_json, digest_file, read_json
from onpolicy.envs.HKBZ.test.test_stage3_b0 import queue_fixture


def test_elastic_pool_cpu_gpu_leases():
    plan = resource_plan([[i, i + 64] for i in range(64)])
    boosted = pool_placements(plan, "boost", [0, 3, 4, 7])
    running = [plan["trainers"][str(g)] for g in [1, 2, 5, 6]]
    assert len(boosted) == 4
    for b in boosted.values():
        assert all(b["gpu"] != t["gpu"] and not set(b["cpus"]) & set(t["cpus"]) for t in running)
    steady = pool_placements(plan, "steady")
    assert {p["gpu"] for p in steady.values()} == {0, 4}
    assert all(not set(p["cpus"]) & set(t["cpus"]) for p in steady.values() for t in plan["trainers"].values())
    for mode, gpus in (("boost", []), ("boost", [0, 0]), ("boost", [8]), ("steady", [0]), ("invalid", [1])):
        with pytest.raises(ValueError):
            pool_placements(plan, mode, gpus)


def test_raw_initialization_is_not_a_formal_validation_bypass(tmp_path):
    from onpolicy.utils.stage3_b0_protocol import submit, queue, validate_request
    m, checkpoint, _ = queue_fixture(tmp_path)
    m["acceleration"] = {"version": 1}
    request_id = submit(m, checkpoint, "C_PRIVATE", 0, "F_PRIVATE", split="validation", raw_initialization=True)
    request = read_json(queue(m).root / "pending" / (request_id + ".json"))
    validate_request(m, request)
    assert B0Queue.identity(request) != B0Queue.identity({**request, "raw_initialization": False})
    with pytest.raises(ValueError, match="identity corrupted"):
        validate_request(m, {**request, "raw_initialization": False})
    for split, episodes in (("validation", 960), ("train_full600", 0), ("confirmation", 0)):
        with pytest.raises(ValueError, match="restricted"):
            submit(m, checkpoint, "C_PRIVATE", episodes, "F_PRIVATE", split=split, raw_initialization=True, tag="_bad")
    m.pop("acceleration")
    with pytest.raises(ValueError, match="restricted"):
        submit(m, checkpoint, "C_PRIVATE", 0, "F_PRIVATE", split="tune", raw_initialization=True)


def synthetic_evidence(tmp_path):
    case = {"path": "/synthetic/case", "profile": "balanced", "distribution": "iid"}
    row = {"case_id": case["path"], "profile": "balanced", "distribution": "iid", "makespan": 100.,
        "completed": True, "cycle_terminated": False, "source_sha256": B0_SHA, "history": EVALUATION["history"],
        "inference_batching": EVALUATION["inference_batching"],
        "decoder": EVALUATION["decoder"], "seed": 1, "policy_updates": 0, "behavior_deterministic": True,
        "action_sha256": "a" * 64}
    m = {"root": str(tmp_path), "diagnostic": {"cases32": [case]}, "source": {"sha256": B0_SHA},
        "code": {"sha256": "code"}, "manifest_sha256": "protocol", "comparison_sha256": "comparison",
        "splits": {"train_full600": [case]}}
    request = {"checkpoint_sha256": B0_SHA, "cases_sha256": digest_json([case]), "contract_sha256": digest_json(PLANNING),
        "code_sha256": "code", "tau": .3, "seed": 1, "evaluation_protocol": EVALUATION, "training_exploration": None,
        "representation": "NATIVE", "protocol_sha256": "protocol", "source_sha256": B0_SHA,
        "comparison_sha256": "comparison", "kind": "native_cost", "diagnostic": None}
    result = {"request_id": "B0_train_full600_e000000_s0000", "training_episodes": 0, "ok": True, "error": None,
        **{k: request[k] for k in ("checkpoint_sha256", "cases_sha256", "contract_sha256", "code_sha256")},
        "cache_key": B0Queue.identity(request),
        "evaluation": {"cases": [row], "source_sha256": B0_SHA, "evaluation_protocol": EVALUATION}}
    return m, case, row, result


@pytest.mark.parametrize("change", ["checkpoint_sha256", "code_sha256", "cases_sha256", "cache_key", "contract_sha256", "ok"])
def test_reused_baseline_rejects_corrupt_provenance(tmp_path, change):
    m, _, row, result = synthetic_evidence(tmp_path)
    path = tmp_path / "result.json"
    atomic_json(path, result)
    assert baseline_evidence(m, path) == [row]
    result[change] = False if change == "ok" else "wrong"
    atomic_json(path, result)
    with pytest.raises(ValueError):
        baseline_evidence(m, path)


@pytest.mark.parametrize("field,value", [("completed", False), ("cycle_terminated", True), ("seed", 2),
    ("policy_updates", 1), ("makespan", float("nan")), ("decoder", "greedy"), ("source_sha256", "old-c0")])
def test_reuse_requires_complete_native_trajectories(tmp_path, field, value):
    _, case, row, _ = synthetic_evidence(tmp_path)
    row[field] = value
    with pytest.raises(ValueError):
        complete_rows([row], [case])
    with pytest.raises(ValueError):
        complete_rows([], [case])


def test_only_diagnostic_canary_can_use_partial_costs(tmp_path):
    from onpolicy.utils.stage3_b0_protocol import baseline_costs
    m, case, row, _ = synthetic_evidence(tmp_path)
    path = tmp_path / "reuse.json"
    atomic_json(path, {"source_sha256": B0_SHA, "comparison_sha256": m["comparison_sha256"],
        "evaluation": EVALUATION, "native_initialization_cases": [row]})
    m["acceleration"] = {"reuse_receipt": {"path": str(path), "sha256": digest_file(path)}}
    assert canary_costs(m, [case, case]) == {case["path"]: 100.}
    with pytest.raises(FileNotFoundError):
        baseline_costs(m)  # Formal admission still rejects incomplete baselines.
    with pytest.raises(ValueError, match="not ready"):
        canary_costs(m, [{"path": "/unseen"}])
    atomic_json(path, {"changed": True})
    with pytest.raises(ValueError, match="receipt changed"):
        canary_costs(m, [case])


def test_validator_drain_happens_before_claim(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_b0_worker as worker
    args = SimpleNamespace(output=tmp_path)
    atomic_json(tmp_path / "DRAIN", {"generation": 1})
    monkeypatch.setattr(worker, "queue", lambda m: SimpleNamespace(claim=lambda: pytest.fail("Must not claim after drain")))
    events = []
    worker.validator(args, {}, SimpleNamespace(update=lambda **kw: events.append(kw)))
    assert events[-1]["event"] == "validator_drained"


def test_pool_drain_ack_precedes_replacement_leases(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_b0_accelerated as module
    from onpolicy.utils.stage3_b0_protocol import queue
    plan = resource_plan([[i, i + 64] for i in range(64)])
    m = {"root": str(tmp_path), "resources": {"plan": plan, "validator_queue": str(tmp_path / "validator")},
         "manifest_sha256": "test"}
    suite = module.AcceleratedB0Suite(m, tmp_path / "manifest.json")
    observations, starts, ticks = [], [], [0]
    class Heartbeat:
        def __init__(self, *a, **k): pass
        def __enter__(self): return self
        def __exit__(self, *a): pass
        def update(self, **kw): observations.append(kw)
    class Process:
        rc = None
        def poll(self): return self.rc
    def start(name, phase, placement):
        output = tmp_path / name
        output.mkdir()
        suite.jobs[name] = {"process": Process(), "output": output, "placement": placement}
        starts.append(name)
        return name
    def request(mode, gpus, generation):
        row = {"protocol_sha256": "test", "generation": generation, "mode": mode, "gpus": gpus,
               "placements": pool_placements(plan, mode, gpus)}
        assert_pool_request(m, row)
        atomic_json(suite.queue.root / "desired_pool.json", row)
    request("boost", [0, 4], 0)
    def tick(seconds):
        ticks[0] += 1
        if ticks[0] == 1:
            request("steady", [], 1)
        elif ticks[0] == 2:
            assert len(starts) == 2 and observations[-1]["acknowledged_generation"] is None
            assert all((suite.jobs[n]["output"] / "DRAIN").exists() for n in starts)
        elif ticks[0] == 3:
            assert len(starts) == 2  # In-flight jobs must not be overlapped by replacement workers.
            for n in starts:
                suite.jobs[n]["process"].rc = 0
        elif ticks[0] == 4:
            assert len(starts) == 4 and observations[-1]["acknowledged_generation"] == 1
            atomic_json(suite.queue.root / "STOP", {})
        elif ticks[0] > 4:
            pytest.fail("Pool failed to stop")
    monkeypatch.setattr(module, "ProgressHeartbeat", Heartbeat)
    monkeypatch.setattr(module.os, "sched_setaffinity", lambda *a: None)
    monkeypatch.setattr(module.time, "sleep", tick)
    monkeypatch.setattr(suite, "start", start)
    monkeypatch.setattr(suite, "check", lambda hb: None)
    monkeypatch.setattr(suite, "stop_owned", lambda: None)
    suite.run_pool()


def test_temperature_shards_keep_logical_eight_world_and_archive_layout(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_b0_accelerated as module
    m = {"root": str(tmp_path), "resources": {"plan": resource_plan([[i, i + 64] for i in range(64)]),
         "validator_queue": str(tmp_path / "validator")}, "acceleration": {"temperature_gpus": [1, 2, 5, 6]}}
    suite = module.AcceleratedB0Suite(m, tmp_path / "manifest.json")
    starts = []
    def start(name, phase, placement, **options):
        output = tmp_path / "sampling" / name
        atomic_json(output / "result.json", {"passed": True, "actor_updates": 0, "rank": options["rank"]})
        suite.jobs[name] = {"output": output, "process": SimpleNamespace(poll=lambda: 0)}
        starts.append((name, placement["gpu"], options))
        return name
    monkeypatch.setattr(suite, "start", start)
    monkeypatch.setattr(suite, "check", lambda hb: None)
    monkeypatch.setattr(module.time, "sleep", lambda *a: None)
    results = suite.temperature_tasks(SimpleNamespace(update=lambda **kw: None))
    assert [r["rank"] for r in results] == list(range(8))
    assert [r[0] for r in starts] == [f"temperatures/rank{i}" for i in range(8)]
    assert all(options["world_size"] == 8 for _, _, options in starts)
    assert {g for _, g, _ in starts} == {1, 2, 5, 6}


def test_preflight_submits_only_missing_native_cases_to_one_queue(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_b0_accelerated as module
    cases = [{"path": f"case{i}"} for i in range(9)]
    m = {"root": str(tmp_path), "resources": {"plan": {}, "validator_queue": str(tmp_path / "validator")},
        "source": {"path": "B0"}, "splits": {"tune": cases[:3], "validation": cases[3:6], "train_full600": cases[6:]},
        "acceleration": {"preflight_chunk_size": 3}}
    suite = module.AcceleratedB0Suite(m, tmp_path / "manifest.json")
    sent = []
    def submit(*args, **kwargs):
        sent.append((args, kwargs))
        return str(len(sent))
    monkeypatch.setattr(module, "submit", submit)
    native, private = suite.preflight_requests("private-init", [{"case_id": "case0"}, {"case_id": "case7"}])
    native_cases = [c["path"] for args, kw in sent if kw.get("native") for c in kw["cases_override"]]
    assert set(native_cases) == {f"case{i}" for i in [1, 2, 3, 4, 5, 6, 8]}
    assert len(native) == 3 and len(private) == 2
    assert all(args[0] is m for args, kw in sent)
    assert [kw["split"] for args, kw in sent] == ["tune", "tune", "validation", "validation", "train_full600"]


def test_source_reuse_rejects_algorithm_and_protected_function_changes(tmp_path, monkeypatch):
    from onpolicy.utils import stage3_b0_acceleration as module
    protected = {
        "onpolicy/scripts/train/stage3_b0_worker.py":
            ("metadata", "engine", "evaluate", "collect", "initialization", "sampling", "diagnostic_batch", "train"),
        "onpolicy/utils/stage3_b0_protocol.py": ("identity", "comparison_contract", "verify", "baseline_costs"),
        "onpolicy/runner/shared/stage3_b0_engine.py": ("algorithm",),
    }
    old, new = tmp_path / "old", tmp_path / "new"
    files = {}
    for file, names in protected.items():
        for root in (old, new):
            path = root / file
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("\n".join(f"def {name}():\n    return 1\n" for name in names))
        files[file] = digest_file(old / file)
    parent = {k: {} for k in ("contract", "history", "evaluation", "training", "numerics", "splits", "diagnostic")}
    parent.update(comparison_sha256="same", code={"files": files, "sha256": digest_json(files)},
        execution={"code_root": str(old), "packages": {}}, source={"sha256": B0_SHA, "path": "synthetic-b0",
        "manifest_file_sha256": "same-release"}, resources={"validator_width": 3})
    parent["manifest_sha256"] = identity(parent)
    child = copy.deepcopy(parent)
    child["execution"]["code_root"] = str(new)
    original_digest = module.digest_file
    monkeypatch.setattr(module, "digest_file", lambda p: B0_SHA if p == "synthetic-b0" else original_digest(p))
    assert source_equivalence(parent, child)["all_other_parent_source_files_identical"]
    worker = "onpolicy/scripts/train/stage3_b0_worker.py"
    (new / worker).write_text((new / worker).read_text().replace("def evaluate():\n    return 1", "def evaluate():\n    return 2"))
    child["code"]["files"][worker] = digest_file(new / worker)
    with pytest.raises(ValueError, match="Protected computation changed"):
        source_equivalence(parent, child)
    engine = "onpolicy/runner/shared/stage3_b0_engine.py"
    child["code"]["files"][engine] = "changed-runtime"
    with pytest.raises(ValueError, match="Non-scheduling runtime changed"):
        source_equivalence(parent, child)
