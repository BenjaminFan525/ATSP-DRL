"""Execution-only CPU handoff fixtures; no GPU or experimental scores needed."""
import copy
from types import SimpleNamespace

import pytest

from onpolicy.scripts.train import boost_stage3_b0_validator as boost


def fixture(tmp_path):
    m = {"root": str(tmp_path), "manifest_sha256": "frozen-protocol",
         "training": {"max_training_episodes": 3648},
         "resources": {"core_groups": [[i, i+64] for i in range(64)],
                       "gpus": [{"index": i, "uuid": f"GPU-{i}"} for i in range(8)]},
         "execution": {"code_root": str(tmp_path/"source"), "workspace_root": "/workspace",
                       "worker": "onpolicy/scripts/train/stage3_b0_worker.py", "python": "/python"},
         "numerics": {"cublas_workspace_config": ":4096:8"}}
    boost.write(tmp_path/"status.json", {"status": "running", "phase": "checkpoint_selection",
                 "worker_exit_codes": {f"train/full/rank{r}": 0 for r in range(8)}})
    entries = []
    for rank in range(8):
        output = tmp_path/f"train/full/rank{rank}"
        boost.write(output/"status.json", {"pid": 1000+rank})
        boost.write(output/"result.json", {"completed": True, "training_episodes": 3648,
                                           "actual_actor_updates": 98})
        model = output/"models/episodes_003648.pt"
        model.parent.mkdir(parents=True)
        model.write_bytes(f"synthetic-checkpoint-{rank}".encode())
        entries.append({"rank": rank, "checkpoint": str(model), "sha256": boost.sha(model)})
    boost.write(tmp_path/"train/commits/episodes_003648.json", {"training_episodes": 3648,
                 "world_size": 8, "protocol_sha256": "frozen-protocol", "actual_actor_updates": 98,
                 "ranks": entries})
    for kind in ("epochs", "mechanism"):
        boost.write(tmp_path/kind/"e003648.json", {"training_episodes": 3648,
                    "checkpoint_sha256": entries[0]["sha256"], "requests": [kind]})
    return m


def test_full_cpu_plan_preserves_complete_smt_cores_and_numa(tmp_path):
    m = fixture(tmp_path)
    plan = boost.placements(m)
    assert list(plan) == list(map(str, range(8)))
    all_cpus = [cpu for p in plan.values() for cpu in p["cpus"]]
    assert sorted(all_cpus) == list(range(128))
    for gpu, placement in plan.items():
        assert len(placement["cpus"]) == 16
        assert {cpu % 64 for cpu in placement["cpus"]} == set(range(int(gpu)*8, int(gpu)*8+8))
    assert all(cpu % 64 < 32 for g in range(4) for cpu in plan[str(g)]["cpus"])
    assert all(cpu % 64 >= 32 for g in range(4, 8) for cpu in plan[str(g)]["cpus"])


@pytest.mark.parametrize("change", ["missing_core", "duplicate_cpu", "missing_gpu"])
def test_reject_incompatible_topology(tmp_path, change):
    m = fixture(tmp_path)
    if change == "missing_core":
        m["resources"]["core_groups"].pop()
    elif change == "duplicate_cpu":
        m["resources"]["core_groups"][0] = [0, 0]
    else:
        m["resources"]["gpus"].pop()
    with pytest.raises(ValueError):
        boost.placements(m)


def test_final_commit_and_all_exits_allow_boost_while_controller_stays_running(tmp_path):
    m = fixture(tmp_path)
    assert boost.training_ready(m, alive=lambda pid: None)[0]
    boost.verify_checkpoints(m)


@pytest.mark.parametrize("missing", ["train/commits/episodes_003648.json", "train/full/rank7/result.json",
                                     "epochs/e003648.json", "mechanism/e003648.json"])
def test_checkpoint_alone_or_incomplete_publication_never_releases_resources(tmp_path, missing):
    m = fixture(tmp_path)
    (tmp_path/missing).unlink()
    assert not boost.training_ready(m, alive=lambda pid: None)[0]


def test_live_training_worker_or_unacknowledged_exit_blocks_boost(tmp_path):
    m = fixture(tmp_path)
    assert boost.training_ready(m, alive=lambda pid: {"pid": pid} if pid == 1007 else None)[1] == "waiting_training_worker_exit"
    state = boost.read(tmp_path/"status.json")
    state["worker_exit_codes"]["train/full/rank7"] = None
    boost.write(tmp_path/"status.json", state)
    assert boost.training_ready(m, alive=lambda pid: None)[1] == "waiting_controller_exit_acknowledgement"


@pytest.mark.parametrize("change", ["wrong_commit", "wrong_receipt", "failed_exit", "paused", "wrong_publication"])
def test_invalid_training_evidence_fails_closed(tmp_path, change):
    m = fixture(tmp_path)
    path = tmp_path/"status.json"
    if change == "wrong_commit":
        path = tmp_path/"train/commits/episodes_003648.json"
        value = boost.read(path)
        value["protocol_sha256"] = "different-run"
    elif change == "wrong_receipt":
        path = tmp_path/"train/full/rank7/result.json"
        value = boost.read(path)
        value["training_episodes"] = 3264
    elif change == "wrong_publication":
        path = tmp_path/"epochs/e003648.json"
        value = boost.read(path)
        value["checkpoint_sha256"] = "wrong-model"
    else:
        value = boost.read(path)
        if change == "paused":
            value["phase"] = "paused_at_commit"
        else:
            value["worker_exit_codes"]["train/full/rank7"] = 1
    boost.write(path, value)
    with pytest.raises((ValueError, RuntimeError)):
        boost.training_ready(m, alive=lambda pid: None)


def test_final_checkpoint_hash_checked_without_loading_or_rewriting_model(tmp_path):
    m = fixture(tmp_path)
    (tmp_path/"train/full/rank7/models/episodes_003648.pt").write_bytes(b"changed")
    with pytest.raises(ValueError, match="checkpoint"):
        boost.verify_checkpoints(m)


def test_added_worker_uses_exact_frozen_entrypoint_and_numerical_environment(tmp_path):
    m = fixture(tmp_path)
    original = copy.deepcopy(m)
    output = tmp_path/"validator/workers/fullcpu_g1"
    command, env = boost.worker_launch(m, boost.placements(m)["1"], output)
    assert m == original
    assert command[:2] == ["/usr/bin/taskset", "--cpu-list"]
    assert str(tmp_path/"source/onpolicy/scripts/train/stage3_b0_worker.py") in command
    assert str(tmp_path/"manifest.json") in command
    assert command[-4:] == ["--phase", "validator", "--output", str(output)]
    assert "--batch-size" not in command and "--tau" not in command
    assert env["PYTHONPATH"] == str(tmp_path/"source") and env["CUDA_VISIBLE_DEVICES"] == "GPU-1"
    for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        assert env[key] == "1"
    assert env["CUBLAS_WORKSPACE_CONFIG"] == ":4096:8"


def test_activation_cannot_run_early(tmp_path, monkeypatch):
    instance = object.__new__(boost.Boost)
    instance.m = fixture(tmp_path)
    monkeypatch.setattr(boost, "training_ready", lambda m: (False, "still_training"))
    monkeypatch.setattr(boost, "guard_gpu_owners", lambda *a: pytest.fail("must not touch resources"))
    with pytest.raises(RuntimeError, match="still_training"):
        instance.activate()


def test_gpu_guard_leaves_unrelated_process_untouched(tmp_path, monkeypatch):
    m = fixture(tmp_path)
    monkeypatch.setattr(boost.subprocess, "check_output", lambda *a, **k: "GPU-1, 1234\n")
    monkeypatch.setattr(boost, "process_identity", lambda pid: {"cgroup": "0::/other-experiment.service"})
    with pytest.raises(RuntimeError, match="left untouched"):
        boost.guard_gpu_owners(m, "our-validator.service")


def test_receipts_never_overwrite_previous_attempt(tmp_path):
    path = tmp_path/"plan.json"
    boost.write(path, {"first": True}, exclusive=True)
    with pytest.raises(FileExistsError):
        boost.write(path, {"first": False}, exclusive=True)
    assert boost.read(path) == {"first": True}
    assert list(tmp_path.iterdir()) == [path]


def test_drain_only_signals_owned_request_boundaries(tmp_path):
    instance = object.__new__(boost.Boost)
    output = tmp_path/"validator/workers/fullcpu_g1"
    polls = iter([None, 0])
    instance.children = [{"process": SimpleNamespace(poll=lambda: next(polls)), "output": output}]
    instance.drain()
    marker = boost.read(output/"DRAIN")
    assert marker["preserve_inflight_request"]
    assert not (tmp_path/"validator/STOP").exists()


def test_snapshot_and_manifest_are_read_only_and_hash_bound(tmp_path):
    m = fixture(tmp_path)
    source = tmp_path/"source"
    source.mkdir()
    code = source/"worker.py"
    code.write_text("unchanged frozen code\n")
    m["code"] = {"files": {"worker.py": boost.sha(code)}}
    boost.write(tmp_path/"manifest.json", m)
    digest = boost.sha(tmp_path/"manifest.json")
    boost.verify_files(m, digest)
    code.write_text("modified code\n")
    with pytest.raises(ValueError, match="Frozen source changed"):
        boost.verify_files(m, digest)
    assert boost.sha(tmp_path/"manifest.json") == digest


def test_affinity_pid_reuse_is_rejected_before_any_change(tmp_path, monkeypatch):
    monkeypatch.setattr(boost, "process_identity", lambda *a: {"pid": 123, "start_ticks": 11})
    monkeypatch.setattr(boost.os, "sched_setaffinity", lambda *a: pytest.fail("must not change reused PID"))
    with pytest.raises(RuntimeError, match="PID changed"):
        boost.affinity_tree({"pid": 123, "start_ticks": 10}, [0, 64], proc=tmp_path)


def test_affinity_covers_parent_threads_and_environment_children(tmp_path, monkeypatch):
    for pid, tid, children in ((100, 100, "200"), (100, 101, ""), (200, 200, "")):
        directory = tmp_path/str(pid)/"task"/str(tid)
        directory.mkdir(parents=True)
        (directory/"children").write_text(children)
    identity = {"pid": 100, "start_ticks": 10, "cgroup": "0::/our-validator.service"}
    monkeypatch.setattr(boost, "process_identity", lambda pid, proc: {**identity, "pid": pid})
    changed = {}
    monkeypatch.setattr(boost.os, "sched_setaffinity", lambda tid, mask: changed.update({tid: set(mask)}))
    monkeypatch.setattr(boost.os, "sched_getaffinity", lambda pid: changed[pid])
    receipt = boost.affinity_tree(identity, [0, 1, 64, 65], proc=tmp_path)
    assert set(changed) == {100, 101, 200}
    assert all(mask == {0, 1, 64, 65} for mask in changed.values())
    assert receipt["updated_tasks"] == 3


def test_activation_adds_six_workers_to_same_queue_without_changing_manifest(tmp_path, monkeypatch):
    instance = object.__new__(boost.Boost)
    instance.m = fixture(tmp_path)
    frozen = copy.deepcopy(instance.m)
    instance.manifest_hash, instance.root = "unchanged", tmp_path
    instance.directory = tmp_path/"validator/cpu_boost_20260914"
    instance.unit = "our-validator.service"
    instance.allocations = boost.placements(instance.m)
    instance.originals = [{"identity": {"pid": 400+g}, "gpu": g} for g in (0, 4)]
    instance.children = []
    monkeypatch.setattr(boost, "training_ready", lambda m: (True, "ready"))
    for name in ("verify_files", "verify_checkpoints", "guard_gpu_owners", "assert_worker"):
        monkeypatch.setattr(boost, name, lambda *args: None)
    monkeypatch.setattr(boost.os, "sched_getaffinity", lambda pid: set(range(128)))
    monkeypatch.setattr(boost, "affinity_tree", lambda identity, cpus: {"pid": identity["pid"], "cpus": cpus})
    commands = []
    def launch(command, **kwargs):
        commands.append(command)
        return SimpleNamespace(pid=500+len(commands))
    monkeypatch.setattr(boost.subprocess, "Popen", launch)
    instance.activate()
    assert len(commands) == len(instance.children) == 6
    assert {c["placement"]["gpu"] for c in instance.children} == {1, 2, 3, 5, 6, 7}
    assert all(str(tmp_path/"manifest.json") in command for command in commands)
    assert instance.m == frozen
    assert boost.read(instance.directory/"activated.json")["shared_queue"] == str(tmp_path/"validator")
    assert not (tmp_path/"validator/STOP").exists()
