"""True 24-environment collection / 12-trajectory independent PPO minibatches."""
import copy
from datetime import timedelta
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy, update
from onpolicy.envs.HKBZ.test.test_stage3_b0_throughput import continuation_fixture, cases, flatten
from onpolicy.utils.stage3_b0_protocol import identity
from onpolicy.utils.stage3_b0_throughput import (ENV24_VERSION, ENV24_AUTHORIZATION,
    training_contract, continuation_plan, parent_manifest)
from onpolicy.utils.stage3_ppo_minibatches import behavior_digest
from onpolicy.utils.stage3_research import atomic_json, digest_file, digest_json


def test_env24_collects_in_one_call_and_recreates24(monkeypatch):
    from onpolicy.scripts.train.stage3_b0_worker import collect
    pools, calls, events = [], [], []
    class Pool:
        def __init__(self, width, *, start_method):
            assert width == 24 and start_method == 'forkserver'
            self.closed = False
            pools.append(self)
        def close(self):
            self.closed = True
    monkeypatch.setattr('onpolicy.runner.shared.stage3_research_engine.EnvironmentPool', Pool)
    runner = SimpleNamespace(width=24, pool=None, release_environments_after_rollout=True,
                             environment_start_method='forkserver')
    def rollout(cases, seeds, **kwargs):
        assert len(cases) == len(seeds) == 24 and not runner.pool.closed
        calls.append(list(cases))
        return list(zip(cases, seeds))
    runner.rollout = rollout
    hb = SimpleNamespace(update=lambda **row: events.append(row))
    batch = {'cases': list(range(24)), 'seeds': list(range(100, 124))}
    for _ in range(2):
        assert collect(runner, batch, hb) == list(zip(batch['cases'], batch['seeds']))
        assert runner.pool is None
    assert len(calls) == len(pools) == 2 and all(p.closed for p in pools)
    starts = [e for e in events if e['event'] == 'rollout_wave_start']
    assert len(starts) == 2 and all(e['rollout_wave'] == e['rollout_waves'] == 1 for e in starts)


def test_env24_two_independent_optimizer_minibatches():
    runner, rows, widths = minibatch_toy(24)
    before = behavior_digest(rows)
    result = update(runner, rows)
    assert runner.policy_updates == 4
    assert [e['optimizer_minibatch'] for e in result['epochs']] == [1, 2, 1, 2]
    assert all(e['actor_step_applied'] for e in result['epochs'])
    assert int(runner.policy.actor_optimizer.state[runner.policy.ac.theta]['step']) == 4
    assert max(widths) == 12 and result['rollout_trajectories'] == 24
    assert result['backward_microbatches'] == 2 and result['optimizer_step_per_microbatch']
    assert before == behavior_digest(rows) and not result['optimizer_step_after_microbatches']


def test_env24_parent96_lineage_and_schedule192(tmp_path):
    parent = continuation_fixture(tmp_path)
    root = tmp_path/'batch96'
    root.mkdir()
    parent['root'] = str(root)
    parent['manifest_sha256'] = identity(parent)
    atomic_json(root/'manifest.json', parent)
    atomic_json(root/'training_admission.json', {'passed': True})
    entries = []
    for rank in range(8):
        path = root/f'rank{rank}.pt'
        path.write_bytes(b'synthetic-not-model-weights')
        entries.append({'rank': rank, 'checkpoint': str(path), 'sha256': digest_file(path)})
    atomic_json(root/'commit.json', {'world_size': 8, 'ranks': entries,
        'training_episodes': 608, 'actual_actor_updates': 34, 'protocol_sha256': parent['manifest_sha256'],
        'schedule_sha256': digest_json(continuation_plan(parent)),
        'recipe_sha256': digest_file(root/'training_admission.json')})
    child = copy.deepcopy(parent)
    child['training'] = training_contract(192)
    child['throughput'].update(version=ENV24_VERSION, authorization=ENV24_AUTHORIZATION,
        parent_manifest=str(root/'manifest.json'), parent_manifest_sha256=digest_file(root/'manifest.json'),
        resume_commit=str(root/'commit.json'), resume_commit_sha256=digest_file(root/'commit.json'),
        start_episodes=608, start_actor_updates=34, global_batch=192, rollout_envs_per_rank=24,
        rollout_trajectories_per_rank=24, rollout_waves_per_rank=1, backward_trajectories_per_rank=12,
        gradient_accumulation_microbatches=1, optimizer_step_after_microbatches=False,
        optimizer_step_per_microbatch=True, optimizer_minibatches=2, optimizer_global_batch=96,
        release_environments_after_rollout=True, fresh_rollout_cadence_changed=True,
        environment_start_method='forkserver', optimizer_update_cadence_changed=False,
        parent_evidence={str(root/'training_admission.json'): digest_file(root/'training_admission.json')})
    child['throughput']['schedule_sha256'] = digest_json(continuation_plan(child))
    assert parent_manifest(child)['training']['global_batch'] == 96
    plan = continuation_plan(child)
    assert len(plan) == 37 and [b['batch_size'] for b in plan[:2]] == [192, 160]
    from onpolicy.utils.stage3_full_data import schedule
    assert flatten(plan) == flatten(schedule(cases(), child['training']['seed']))[608:]
    assert sum((b['batch_size']+95)//96 for b in plan)*2 == 148
    for name, value in [('rollout_envs_per_rank', 12), ('rollout_waves_per_rank', 2),
                        ('optimizer_step_per_microbatch', False), ('environment_start_method', 'fork'),
                        ('gradient_accumulation_microbatches', 2)]:
        changed = copy.deepcopy(child)
        changed['throughput'][name] = value
        with pytest.raises(ValueError, match='contract'):
            parent_manifest(changed)


def _env24rank(rank, init_file):
    from onpolicy.utils.stage3_distributed import TrajectoryParallel
    torch.set_num_threads(1)
    dist.init_process_group('gloo', init_method='file://'+init_file, rank=rank, world_size=8,
                            timeout=timedelta(seconds=120))
    try:
        sync = TrajectoryParallel(device_packed=True)
        runner, rows, widths = minibatch_toy(24)
        for row in rows:
            row['makespan'] += rank
        result = update(runner, rows, distributed=sync)
        assert runner.policy_updates == len(result['epochs']) == 4
        assert max(widths) == 12 and result['behavior_data_unchanged']
        sync.assert_replicas(runner)
        assert all(r['weights'] == pytest.approx([1/12]*12) for r in result['minibatch_objectives'])
        assert all(sum(r['decisions'] for r in e['full_batch_post_update']['roles'].values()) == 8*3*sum(len(r['states']) for r in rows)
                   for e in result['ppo_epoch_reports'])
    finally:
        dist.destroy_process_group()


def test_env24_real_eight_rank_four_steps(tmp_path):
    mp.spawn(_env24rank, args=(str(tmp_path/'store'),), nprocs=8, join=True)


def test_env24_real_workers_spawn_forkserver_prefix_parity(tmp_path, record_property):
    root = Path(__file__).resolve().parents[4]
    results = {}
    for method in ('spawn', 'forkserver'):
        target = tmp_path/f'{method}.json'
        completed = subprocess.run([sys.executable, '-B', str(root/'onpolicy/scripts/train/probe_stage3_b0_env_pool.py'),
            '--start-method', method, '--output', str(target)], env={**os.environ, 'CUDA_VISIBLE_DEVICES': ''},
            cwd=root, capture_output=True, text=True, timeout=180)
        assert completed.returncode == 0, completed.stdout+'\n'+completed.stderr
        results[method] = json.loads(target.read_text())
        assert results[method]['passed'] and results[method]['live_environments'] == 24
        assert results[method]['actor_updates'] == 0 and not results[method]['full_capacity_admission']
    assert results['spawn']['records'] == results['forkserver']['records']
    spawn_pss = max(m['total_pss_gib'] for m in results['spawn']['memory'])
    fork_pss = max(m['total_pss_gib'] for m in results['forkserver']['memory'])
    assert fork_pss < spawn_pss
    record_property('spawn24_process_tree_pss_gib', spawn_pss)
    record_property('forkserver24_process_tree_pss_gib', fork_pss)
    record_property('prefix_only_not_full_admission', True)


def test_env24_rejects_unsafe_fork_without_starting_workers():
    from onpolicy.runner.shared.stage3_research_engine import EnvironmentPool
    with pytest.raises(ValueError, match='CPU-only forkserver'):
        EnvironmentPool(24, start_method='fork')
