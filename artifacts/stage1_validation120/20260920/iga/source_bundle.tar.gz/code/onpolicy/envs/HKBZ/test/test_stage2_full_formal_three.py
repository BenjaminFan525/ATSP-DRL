from pathlib import Path
import tempfile
import unittest

import torch

from onpolicy.scripts.train.prepare_stage2_full_formal import (
    EXPECTED_CASE_SLOTS,
    EXPECTED_UNIQUE_CASES,
    FORMAL_BC_EPOCHS,
    FORMAL_PPO_EPOCHS,
)
from onpolicy.scripts.train.prepare_stage2_full_formal_three import (
    FORMAL_ACTOR_ACCUMULATION_STEPS,
    FORMAL_BC_ROLLOUTS,
    FORMAL_CRITIC_ACCUMULATION_STEPS,
    FORMAL_DATA_CHUNK_LENGTH,
    FORMAL_GRAPHS_PER_FORWARD,
    FORMAL_MINI_BATCH_SIZE,
    FORMAL_ROLLOUT_THREADS,
    SELECTED_FORMAL_METHODS,
    configure_selected_command,
)
from onpolicy.scripts.train.handoff_stage2_full_formal_three_ppo30 import (
    lookahead_contract_from_command,
    validate_checkpoint,
)
from onpolicy.scripts.train.shared_hkbz_evaluator import accept_connection


class Stage2FullFormalThreeTest(unittest.TestCase):
    def test_shared_evaluator_survives_abandoned_auth_handshake(self):
        accepted = object()

        class FlakyListener:
            def __init__(self):
                self.calls = 0

            def accept(self):
                self.calls += 1
                if self.calls == 1:
                    raise BrokenPipeError(32, 'client exited during auth')
                return accepted

        listener = FlakyListener()
        self.assertIs(accept_connection(listener), accepted)
        self.assertEqual(listener.calls, 2)

    @staticmethod
    def _value(command, flag):
        return command[command.index(flag) + 1]

    def test_selected_methods_are_complementary_wave4_top_three(self):
        self.assertEqual(
            list(SELECTED_FORMAL_METHODS),
            [
                "F1_hard_reservation",
                "F2_iga_flow_bc",
                "F3_wait_constraint",
            ],
        )
        self.assertTrue(
            all(method["bc_leader"] for method in SELECTED_FORMAL_METHODS.values())
        )
        self.assertTrue(
            all(
                method["reuse_bc_from"] is None
                for method in SELECTED_FORMAL_METHODS.values()
            )
        )

    def test_selected_commands_use_full_data_and_graph1500(self):
        base = ["python", "train_hkbz.py", "--rollout_until_done"]
        for method_id, method in SELECTED_FORMAL_METHODS.items():
            command = configure_selected_command(
                base,
                method_id,
                method,
                run_tag="formal-three-test",
                teacher_dir=Path("/tmp/teacher"),
                teacher_index=Path("/tmp/index.json"),
            )
            value = lambda flag: self._value(command, flag)
            self.assertEqual(int(value("--max_train_cases")), 0)
            self.assertEqual(int(value("--train_sampling_size")), 0)
            self.assertEqual(int(value("--num_episodes")), FORMAL_PPO_EPOCHS)
            self.assertEqual(
                int(value("--device_bc_pretrain_epochs")), FORMAL_BC_EPOCHS
            )
            self.assertEqual(
                int(value("--n_rollout_threads")), FORMAL_ROLLOUT_THREADS
            )
            self.assertEqual(
                int(value("--device_bc_min_rollouts_per_epoch")),
                FORMAL_BC_ROLLOUTS,
            )
            self.assertEqual(
                int(value("--device_bc_max_rollouts_per_epoch")),
                FORMAL_BC_ROLLOUTS,
            )
            self.assertEqual(
                int(value("--mini_batch_size")), FORMAL_MINI_BATCH_SIZE
            )
            self.assertEqual(
                int(value("--data_chunk_length")), FORMAL_DATA_CHUNK_LENGTH
            )
            self.assertEqual(
                int(value("--max_graphs_per_forward")),
                FORMAL_GRAPHS_PER_FORWARD,
            )
            self.assertEqual(
                int(value("--grad_accumulation_steps")),
                FORMAL_CRITIC_ACCUMULATION_STEPS,
            )
            self.assertEqual(
                int(value("--actor_grad_accumulation_steps")),
                FORMAL_ACTOR_ACCUMULATION_STEPS,
            )
            self.assertEqual(
                int(value("--mini_batch_size"))
                * int(value("--data_chunk_length")),
                int(value("--max_graphs_per_forward")),
            )
            self.assertLessEqual(
                int(value("--mini_batch_size")),
                int(value("--n_rollout_threads")),
            )
            self.assertEqual(
                int(value("--n_rollout_threads"))
                * int(value("--device_bc_min_rollouts_per_epoch")),
                EXPECTED_CASE_SLOTS,
            )

    def test_inherited_full_data_contract_is_unchanged(self):
        self.assertEqual(EXPECTED_UNIQUE_CASES, 600)
        self.assertEqual(EXPECTED_CASE_SLOTS, 960)

    def test_handoff_preflights_the_complete_lookahead_contract(self):
        method = SELECTED_FORMAL_METHODS["F1_hard_reservation"]
        command = configure_selected_command(
            ["python", "train_hkbz.py", "--rollout_until_done"],
            "F1_hard_reservation",
            method,
            run_tag="formal-three-test",
            teacher_dir=Path("/tmp/teacher"),
            teacher_index=Path("/tmp/index.json"),
        )
        contract = lookahead_contract_from_command(command)
        self.assertEqual(
            set(contract),
            {
                "device_lookahead_dispatch",
                "device_lookahead_safety_margin",
                "device_deadline_aware_dispatch",
                "device_future_intent_horizon",
                "device_future_intent_mode",
                "device_frontier_max_requests",
                "resource_release_aware_eta",
                "device_lookahead_reservation_mode",
                "device_reservation_grace_seconds",
                "device_departure_lookahead",
            },
        )
        self.assertEqual(
            contract["device_lookahead_reservation_mode"], "hard"
        )

        checkpoint = {
            "training_stage": "resource_joint",
            "stage": "resource_bc_warmup",
            "phase": "resource_bc_warmup_completed",
            "resource_bc_optimizer_reset": True,
            "resource_bc_total_labels": 123,
            "resource_actor_summary_after_bc": {"sha256": "actor"},
            "protected_parameter_summary_after_bc": {"sha256": "plane"},
            "device_bc_teacher": "heuristic",
            "source_m2_sha256": "a" * 64,
            "resource_lookahead_contract": contract,
        }
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "checkpoint.pt"
            torch.save(checkpoint, path)
            evidence = validate_checkpoint(
                path,
                expected_teacher="heuristic",
                expected_source_sha256="a" * 64,
                expected_lookahead_contract=contract,
            )
            self.assertEqual(evidence["resource_lookahead_contract"], contract)
            with self.assertRaisesRegex(
                RuntimeError, "resource lookahead contract mismatch"
            ):
                validate_checkpoint(
                    path,
                    expected_teacher="heuristic",
                    expected_source_sha256="a" * 64,
                    expected_lookahead_contract={
                        **contract,
                        "device_lookahead_reservation_mode": "soft",
                    },
                )


if __name__ == "__main__":
    unittest.main()
