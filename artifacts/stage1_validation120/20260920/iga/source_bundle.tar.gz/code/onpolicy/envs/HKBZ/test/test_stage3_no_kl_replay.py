"""Explicit no-replay continuation: technical correctness, not reward evidence."""
import copy

import pytest
import torch

from onpolicy.envs.HKBZ.test.test_stage3_b0 import fake_runner, stats
from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy, update
from onpolicy.envs.HKBZ.test.test_stage3_tau_resources import resized_manifest
from onpolicy.utils.stage3_distributed import state_digest
from onpolicy.utils.stage3_numerics import training_state
from onpolicy.utils.stage3_ppo_minibatches import behavior_digest
from onpolicy.utils.stage3_ppo_transaction import PPOStepTransaction, snapshot
from onpolicy.utils.stage3_research import digest_json
from onpolicy.utils.stage3_tau import training_plan
from onpolicy.utils.stage3_tau_resources import (
    NO_KL_REPLAY_VERSION, PLACEMENT, configure_kl_replay, verify_resource_contract,
)


def forbidden_replay(*args, **kwargs):
    raise AssertionError('Disabled KL replay was called')


def test_no_kl_replay_default_remains_enabled_and_requires_boolean():
    assert PPOStepTransaction().replay_enabled is True
    for value in (0, 1, None, 'false'):
        with pytest.raises(ValueError):
            PPOStepTransaction(replay_enabled=value)


def test_no_kl_replay_ten_steps_match_guarded_updates_without_replay():
    states = []
    for enabled in (True, False):
        runner, rows, widths = minibatch_toy(60)
        runner.ppo_step_controller = PPOStepTransaction(replay_enabled=enabled)
        events = []
        runner.update_metrics_sink = events.append
        if not enabled:
            runner.replay_metrics = forbidden_replay
        digest = behavior_digest(rows)
        result = update(runner, rows)
        assert runner.policy_updates == 10 and len(result['epochs']) == 10
        assert max(widths) == 12 and not result['stopped_early']
        assert behavior_digest(rows) == digest and result['behavior_data_unchanged']
        assert result['kl_replay_enabled'] is enabled
        if not enabled:
            assert all(r['post_update'] == {} for r in result['epochs'])
            assert all(r['max_role_mean_kl'] is None and not r['epoch_rolled_back']
                       for r in result['ppo_epoch_reports'])
            assert sum(e.get('event') == 'whole_rollout_batch_kl_skipped' for e in events) == 2
            assert not any(e.get('event') == 'whole_rollout_batch_kl' for e in events)
        states.append(state_digest(training_state(runner)))
        with pytest.raises(ValueError, match='fresh|stale'):
            update(runner, rows)
    assert states[0] == states[1]


def test_no_kl_replay_keeps_training_forward_soft_stop():
    runner = fake_runner([])
    runner.replay_metrics = forbidden_replay
    before = state_digest(snapshot(runner))
    result = PPOStepTransaction(replay_enabled=False).step(runner, [], {**stats(), 'kl': .021})
    assert not result['actor_step_applied'] and result['stop_reason'] == 'soft_kl_before_step'
    assert result['post_update'] == {} and state_digest(snapshot(runner)) == before


@pytest.mark.parametrize('bad', [float('nan'), float('inf')])
def test_no_kl_replay_rejects_nonfinite_training_kl(bad):
    runner = fake_runner([])
    runner.replay_metrics = forbidden_replay
    before = state_digest(snapshot(runner))
    with pytest.raises(FloatingPointError):
        PPOStepTransaction(replay_enabled=False).step(runner, [], {**stats(), 'kl': bad})
    assert state_digest(snapshot(runner)) == before


@pytest.mark.parametrize('failure', ['exception', 'nonfinite'])
def test_no_kl_replay_technical_failure_restores_without_retry(failure):
    runner = fake_runner([])
    runner.replay_metrics = forbidden_replay
    before = state_digest(snapshot(runner))
    calls = []
    def fail():
        calls.append(True)
        if failure == 'exception':
            raise RuntimeError('injected optimizer failure')
        with torch.no_grad():
            next(runner.policy.ac.critic_param.parameters()).fill_(float('nan'))
    runner.policy.critic_optimizer.step = fail
    with pytest.raises((RuntimeError, FloatingPointError)):
        PPOStepTransaction(replay_enabled=False).step(runner, [], stats())
    assert calls == [True] and state_digest(snapshot(runner)) == before


def test_no_kl_replay_epoch_exception_restores_preceding_minibatches():
    runner, rows, _ = minibatch_toy(60)
    runner.ppo_step_controller = PPOStepTransaction(replay_enabled=False)
    runner.replay_metrics = forbidden_replay
    before = state_digest(snapshot(runner))
    original, calls = runner.policy.critic_optimizer.step, []
    def fail_second():
        calls.append(True)
        if len(calls) == 2:
            raise RuntimeError('injected second minibatch failure')
        return original()
    runner.policy.critic_optimizer.step = fail_second
    with pytest.raises(RuntimeError, match='injected second'):
        update(runner, rows)
    assert len(calls) == 2 and state_digest(snapshot(runner)) == before
    assert not hasattr(runner, '_active_rollout_batch')


def no_replay_manifest():
    m = resized_manifest()
    m['resource_restart']['resume_commits'] = {a: {'training_episodes': 1200} for a in PLACEMENT}
    m['kl_replay_restart'] = dict(version=NO_KL_REPLAY_VERSION,
        minibatch_replay=False, whole_batch_replay=False, pre_step_soft_kl=True,
        technical_rollback=True, optimization_equivalence_claimed=False,
        switch_episodes={a: 1200 for a in PLACEMENT},
        parent_schedule_sha256=digest_json(training_plan(m, 2)))
    return m


def test_no_kl_replay_contract_preserves_exact_schedule_and_batch_boundary():
    m = no_replay_manifest()
    verify_resource_contract(m)
    assert training_plan(m, 2) == training_plan(resized_manifest(), 2)
    runner, _, _ = minibatch_toy(1)
    configure_kl_replay(runner, m)
    assert runner.ppo_step_controller.replay_enabled is False
    assert runner.ppo_step_controller.soft_kl == .02
    for key, value in [('minibatch_replay', True), ('whole_batch_replay', True),
                       ('pre_step_soft_kl', False), ('technical_rollback', False),
                       ('optimization_equivalence_claimed', True), ('parent_schedule_sha256', 'bad')]:
        changed = copy.deepcopy(m)
        changed['kl_replay_restart'][key] = value
        with pytest.raises(ValueError):
            verify_resource_contract(changed)
    for episodes in (1201, 3840, 480):
        changed = copy.deepcopy(m)
        for arm in PLACEMENT:
            changed['resource_restart']['resume_commits'][arm]['training_episodes'] = episodes
            changed['kl_replay_restart']['switch_episodes'][arm] = episodes
        with pytest.raises(ValueError):
            verify_resource_contract(changed)


def test_no_kl_replay_probe_scope_matches_actual_change():
    from onpolicy.scripts.train.stage3_tau_resource_control import probe_comparisons
    assert probe_comparisons(resized_manifest()) == ('ppo12_vs_accumulated6', ((12, True), (6, True)))
    assert probe_comparisons(no_replay_manifest()) == ('same_ppo12_replay_on_vs_off', ((12, True), (12, False)))
