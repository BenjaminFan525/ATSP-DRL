#!/usr/bin/env python3
"""Stage1 plane-only IGA with the frozen Stage3 anytime search protocol.

Run two case-parallel phases: 180 seconds, then 1620 additional seconds from
each replay-verified incumbent. Resource dispatch remains Stage1 heuristic.
Never overwrite a previous run. All results and progress are written atomically.
"""
from __future__ import annotations

import argparse
import concurrent.futures as futures
import hashlib
import json
import math
import multiprocessing
import os
from pathlib import Path
import platform
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[4]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv
from onpolicy.envs.HKBZ.experiment.eval_common import (
    build_case_env_config, completion_details, write_json,
)
from onpolicy.envs.HKBZ.experiment.generate_stage3_joint_iga_labels import (
    CASE_FILES, _derived_seed, _next_population, _sha256_file, _valid_vector,
)
from onpolicy.envs.HKBZ.experiment.resource_wait_metrics import (
    summarize_aircraft_resource_wait,
)
from onpolicy.envs.HKBZ.experiment.valid_iga import GA_Policy

ALGORITHM = "real_coded_ga_sbx15_pm20_elitist_tournament2_anytime"
PLANNING = {
    "device_lookahead_dispatch": False,
    "device_lookahead_safety_margin": 60.0,
    "device_deadline_aware_dispatch": False,
    "device_future_intent_horizon": 0,
    "device_future_intent_mode": "legacy_one",
    "device_frontier_max_requests": 2,
    "device_request_capacity_per_plane": 0,
    "resource_release_aware_eta": False,
    "device_lookahead_reservation_mode": "none",
    "device_reservation_grace_seconds": 300.0,
    "device_departure_lookahead": False,
    "resource_slack_forecast_seconds": 0.0,
}
WEIGHTS = {"iid": 0.50, "ood_stress": 0.45, "ood_scale": 0.05}


def atomic(path, value):
    write_json(str(path), value)


def case_identity(case):
    metadata = json.loads((case / "metadata.json").read_text())
    # Dataset fingerprints hash canonical JSON; retain raw-byte hashes too.
    files = {
        name: hashlib.sha256(json.dumps(
            json.loads((case / name).read_text()), sort_keys=True,
            ensure_ascii=False, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        for name in CASE_FILES
    }
    if files != metadata["fingerprints"]["files"]:
        raise ValueError(f"Dataset payload/fingerprint mismatch: {case}")
    return {
        "case": case.name,
        "case_path": str(case.resolve()),
        "case_sha256": metadata["fingerprints"]["case_sha256"],
        "files_sha256": files,
        "raw_files_sha256": {name: _sha256_file(case / name) for name in CASE_FILES},
        "profile": metadata["profile"],
        "distribution": metadata["distribution"],
    }


def env_config(case, max_steps):
    config = build_case_env_config(
        str(case), max_plane_agents=24, max_device_num=80,
        resource_policy="heuristic", seed=42, global_feature_mode="f1f2",
    )
    config.update(
        use_domain_rand=False, plane_cycle_repeat_limit=8,
        plane_no_progress_limit=120, plane_relocation_limit=40,
        max_episode_steps=max_steps, **PLANNING,
    )
    return config


def evaluate(config, chromosome, max_steps, deadline=None, record=False):
    started = time.monotonic()
    env = AircraftScheduleEnv(dict(config))
    steps, error, interrupted = 0, None, False
    try:
        count = env.n_plane_agents
        job_end = count * len(env.job_code_list)
        genes = _valid_vector(
            chromosome, count * (len(env.job_code_list) + len(env.site_code_list))
        )
        jobs = genes[:job_end].reshape(count, len(env.job_code_list))
        sites = genes[job_end:].reshape(count, len(env.site_code_list))
        _, dones, info = env.reset()
        while not np.all(dones) and steps < max_steps:
            if deadline is not None and time.monotonic() >= deadline:
                interrupted = True
                break
            actions = GA_Policy(env, info, jobs, sites)
            _, _, dones, info = env.step(actions)
            steps += 1
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    try:
        completion = completion_details(env, steps, max_steps)
        result = {
            "completed": bool(completion["completed"] and error is None and not interrupted),
            "makespan": float(env.total_time), "completion": completion,
            "error": error, "deadline_interrupted": interrupted,
            "wall_seconds": time.monotonic() - started,
        }
        if record:
            result.update(
                plane_trajectory=env.trajectory_log,
                resource_trajectory=env.device_trajectory_log,
                resource_decision_log=env.device_decision_log,
                aircraft_resource_wait=summarize_aircraft_resource_wait(
                    env.trajectory_log, env.device_trajectory_log,
                    {code: env._needed_mobile_types(code) for code in env.job_code_list},
                    transporter_type=env.TRANSPORTER_RESOURCE_TYPE,
                    aircraft_count=len(env.flights_data), include_events=True,
                ),
            )
        return result
    finally:
        env.close()


def load_warm(path, expected, n_var, budget):
    teacher = json.loads(Path(path).read_text())
    for key, value in expected.items():
        if teacher.get(key) != value:
            raise ValueError(f"Warm-start mismatch for {key}: {path}")
    if not teacher.get("completed") or not teacher.get("completion_verified"):
        raise ValueError(f"Warm-start has no verified completion: {path}")
    if teacher["search"]["nominal_cumulative_budget_seconds"] != budget:
        raise ValueError(f"Warm-start budget mismatch: {path}")
    vector = _valid_vector(teacher["search"]["chromosome"], n_var)
    objective = float(teacher["makespan"])
    if not math.isfinite(objective):
        raise ValueError(f"Non-finite warm-start objective: {path}")
    return vector, objective, {
        "kind": "verified_stage1_nested_incumbent", "path": str(path),
        "sha256": _sha256_file(Path(path)), "source_budget_seconds": budget,
        "source_makespan": objective,
    }


def search_case(task):
    identity = task["identity"]
    case = Path(identity["case_path"])
    if case_identity(case) != identity:
        raise ValueError(f"Case changed since manifest creation: {case}")
    config = env_config(case, task["max_steps"])
    env = AircraftScheduleEnv(config)
    try:
        shape = {
            "n_plane_agents": int(env.n_plane_agents),
            "n_jobs": len(env.job_code_list), "n_sites": len(env.site_code_list),
        }
    finally:
        env.close()
    n_var = shape["n_plane_agents"] * (shape["n_jobs"] + shape["n_sites"])
    expected = {
        **identity, "teacher_scope": "stage1_plane_policy", "teacher_method": "iga",
        "resource_policy": "heuristic", "planning_contract": PLANNING,
        "environment_semantics_version": AircraftScheduleEnv.SEMANTICS_VERSION,
        "search_contract": "stage1_nested_stage3_operators_v1",
        "env_config": config, "run_contract_sha256": task["run_contract_sha256"],
    }
    best, objective, warm = None, math.inf, None
    if task.get("warm_path"):
        best, objective, warm = load_warm(
            task["warm_path"], expected, n_var, task["warm_budget"]
        )
    seed = _derived_seed(task["seed"], case.name, str(float(task["cumulative_budget"])))
    rng = np.random.default_rng(seed)
    size = task["population"]
    population = rng.random((size, n_var))
    heuristic = np.full(n_var, 0.5, dtype=np.float64)
    population[0] = best if best is not None else heuristic
    if best is not None and size > 1:
        population[1] = heuristic
    inherited = int(best is not None)
    evaluated, feasible, generation = 0, 0, 0
    history = []
    errors = {}
    started = time.monotonic()
    deadline = started + task["additional_budget"]
    while generation < task["max_generations"]:
        fitness = np.full(size, math.inf)
        resolved, new = 0, 0
        for index, chromosome in enumerate(population):
            if generation == 0 and index == 0 and inherited:
                fitness[index] = objective
                resolved += 1
                continue
            if best is not None and time.monotonic() >= deadline:
                break
            episode = evaluate(
                config, chromosome, task["max_steps"],
                deadline=deadline if best is not None else None,
            )
            if episode["deadline_interrupted"]:
                break
            evaluated += 1
            new += 1
            resolved += 1
            if episode["completed"]:
                feasible += 1
                fitness[index] = float(episode["makespan"])
                if fitness[index] < objective:
                    objective, best = fitness[index], chromosome.copy()
            else:
                reason = episode["error"] or "incomplete_episode"
                errors[reason] = errors.get(reason, 0) + 1
        history.append({
            "generation": generation, "evaluated": new, "resolved": resolved,
            "inherited": int(generation == 0 and inherited),
            "best_makespan": float(objective) if best is not None else None,
            "wall_seconds": time.monotonic() - started,
        })
        if best is None:
            raise RuntimeError(f"No feasible candidate: {case.name}; {errors}")
        if resolved < size or time.monotonic() >= deadline:
            break
        generation += 1
        population = _next_population(rng, population, fitness)
    wall = time.monotonic() - started
    replay = evaluate(config, best, task["max_steps"], record=True)
    if not replay["completed"] or not math.isclose(replay["makespan"], objective, abs_tol=1e-9, rel_tol=0):
        raise RuntimeError(f"Incumbent replay failed: {case.name}; {replay['error']}")
    if warm and replay["makespan"] > warm["source_makespan"] + 1e-9:
        raise RuntimeError(f"Nested incumbent regression: {case.name}")
    if case_identity(case) != identity:
        raise ValueError(f"Dataset changed during search: {case}")
    search = {
        "algorithm": ALGORITHM, "parallel_axis": "independent_cases",
        "population": size, "max_generations": task["max_generations"],
        "completed_generations": generation, "evaluated_candidates": evaluated,
        "completed_candidates": feasible, "inherited_verified_candidates": inherited,
        "seed": seed, **shape, "plane_n_var": n_var, "resource_n_var": 0,
        "n_var": n_var, "configured_additional_budget_seconds": task["additional_budget"],
        "nominal_cumulative_budget_seconds": task["cumulative_budget"],
        "optimization_wall_seconds": wall,
        "budget_overshoot_seconds": max(0.0, wall - task["additional_budget"]),
        "incumbent_preserved": True, "warm_start": warm, "candidate_history": history,
        "failed_candidate_reasons": errors, "chromosome": best.tolist(),
    }
    teacher = {
        **expected, **replay, "completion_verified": True, "search": search,
        "generated_unix_time": time.time(),
    }
    out = Path(task["phase_dir"])
    teacher_path = out / "teachers" / f"{case.name}.json"
    atomic(teacher_path, teacher)
    row = {
        **expected, "completed": True, "completion_verified": True,
        "makespan": replay["makespan"], "completion": replay["completion"],
        "aircraft_resource_wait": replay["aircraft_resource_wait"],
        "replay_wall_seconds": replay["wall_seconds"],
        "search": {key: value for key, value in search.items() if key != "chromosome"},
        "teacher": str(teacher_path), "teacher_sha256": _sha256_file(teacher_path),
    }
    atomic(out / "cases" / f"{case.name}.json", row)
    return row


def metrics(rows):
    if not rows:
        return {"case_count": 0}
    values = np.array([row["makespan"] for row in rows], dtype=float)
    groups = {}
    for label in WEIGHTS:
        subset = [row["makespan"] for row in rows if row["distribution"] == label]
        if subset:
            groups[label] = {"count": len(subset), "mean": float(np.mean(subset))}
    composite = (sum(WEIGHTS[key] * groups[key]["mean"] for key in WEIGHTS)
                 if all(key in groups for key in WEIGHTS) else None)
    return {
        "case_count": len(rows), "mean_makespan": float(values.mean()),
        "median_makespan": float(np.median(values)), "p95_makespan": float(np.percentile(values, 95)),
        "worst_makespan": float(values.max()), "composite_makespan": composite,
        "composite_weights": WEIGHTS, "distributions": groups,
        "mean_evaluated_candidates": float(np.mean([r["search"]["evaluated_candidates"] for r in rows])),
        "mean_optimization_wall_seconds": float(np.mean([r["search"]["optimization_wall_seconds"] for r in rows])),
    }


def run(args):
    out = Path(args.output_dir).resolve()
    if out.exists() and any(out.iterdir()):
        raise ValueError(f"Refusing to overwrite a nonempty run directory: {out}")
    out.mkdir(parents=True, exist_ok=True)
    dataset = Path(args.dataset_dir).resolve()
    cases = sorted(p for p in dataset.glob("case_*") if p.is_dir())
    if args.max_cases:
        cases = cases[:args.max_cases]
    if not cases:
        raise ValueError("Dataset contains no cases")
    identities = [case_identity(case) for case in cases]
    panel_path = Path(args.aligned_evaluation).resolve()
    panel_records = json.loads(panel_path.read_text())["cases"]
    if len(panel_records) != 60 or len({r["case_dir"] for r in panel_records}) != 60:
        raise ValueError("Aligned evaluation must contain 60 unique cases")
    identity_by_name = {r["case"]: r for r in identities}
    selected = []
    for record in panel_records:
        identity = identity_by_name.get(record["case_dir"])
        if identity is None:
            if args.max_cases:
                continue
            raise ValueError(f"Aligned case missing: {record['case_dir']}")
        if (record["fingerprints"]["case_sha256"] != identity["case_sha256"]
                or record["fingerprints"]["files"] != identity["files_sha256"]):
            raise ValueError(f"Aligned evaluation case mismatch: {record['case_dir']}")
        selected.append(identity["case"])
    manifest = {
        "schema_version": 1, "dataset_dir": str(dataset), "case_count": len(cases),
        "cases": identities, "aligned60_cases": selected,
        "aligned_evaluation": str(panel_path), "aligned_evaluation_sha256": _sha256_file(panel_path),
        "search_seed": args.seed, "population": args.population,
        "max_generations": args.max_generations, "max_steps": args.max_steps,
        "budget180": args.budget180, "budget1800": args.budget1800,
        "additional_second_phase_budget": args.budget1800 - args.budget180,
        "algorithm": ALGORITHM, "resource_policy": "heuristic", "planning_contract": PLANNING,
        "environment_semantics_version": AircraftScheduleEnv.SEMANTICS_VERSION,
        "workers": args.workers, "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "thread_environment": {k: os.environ.get(k) for k in (
            "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")},
        "python": sys.executable, "python_version": platform.python_version(),
        "numpy_version": np.__version__, "command": [sys.executable, *sys.argv],
        "source_root": str(ROOT), "entrypoint_sha256": _sha256_file(Path(__file__)),
        "created_unix_time": time.time(),
        "budget_note": "Wall-clock search excludes setup and final replay; first feasible candidate may overshoot, as in Stage3.",
        "stage3_reference": args.stage3_reference,
    }
    contract_hash = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    manifest["run_contract_sha256"] = contract_hash
    atomic(out / "manifest.json", manifest)
    state = {"status": "running", "started_unix_time": time.time(), "phases": {}}
    atomic(out / "pipeline_state.json", state)
    all_results = {}
    try:
        for label, budget, additional, warm_label in (
            ("iga180", args.budget180, args.budget180, None),
            ("iga1800", args.budget1800, args.budget1800 - args.budget180, "iga180"),
        ):
            phase_dir = out / label
            phase = {"status": "running", "started_unix_time": time.time(), "completed": 0, "failed": 0, "total": len(cases)}
            state["phases"][label] = phase
            state["current_phase"] = label
            rows, failures = [], []
            print(f"[Stage1IGA] {label} started: cases={len(cases)} workers={args.workers} additional={additional}s", flush=True)
            with futures.ProcessPoolExecutor(max_workers=args.workers, mp_context=multiprocessing.get_context("fork")) as pool:
                pending = {}
                for identity in identities:
                    task = {
                        "identity": identity, "max_steps": args.max_steps, "population": args.population,
                        "seed": args.seed, "max_generations": args.max_generations,
                        "cumulative_budget": budget, "additional_budget": additional,
                        "warm_budget": args.budget180, "phase_dir": str(phase_dir),
                        "warm_path": str(out / warm_label / "teachers" / f"{identity['case']}.json") if warm_label else None,
                        "run_contract_sha256": contract_hash,
                    }
                    pending[pool.submit(search_case, task)] = identity["case"]
                while pending:
                    done, _ = futures.wait(pending, timeout=15, return_when=futures.FIRST_COMPLETED)
                    for future in done:
                        case_name = pending.pop(future)
                        try:
                            row = future.result()
                            rows.append(row)
                            print(f"[Stage1IGA] {label} {case_name}: makespan={row['makespan']:.3f} candidates={row['search']['evaluated_candidates']} ({len(rows)}/{len(cases)})", flush=True)
                        except Exception:
                            failure = {"case": case_name, "traceback": traceback.format_exc()}
                            failures.append(failure)
                            atomic(phase_dir / "errors" / f"{case_name}.json", failure)
                            print(f"[Stage1IGA] FAILED {label} {case_name}: {failure['traceback']}", flush=True)
                    phase.update(completed=len(rows), failed=len(failures), updated_unix_time=time.time())
                    atomic(out / "pipeline_state.json", state)
                    atomic(phase_dir / "progress.json", {**phase, "metrics_so_far": metrics(rows)})
            rows.sort(key=lambda row: row["case"])
            phase.update(status="failed" if failures else "completed", ended_unix_time=time.time())
            selected_set = set(selected)
            summary = {
                "status": phase["status"], "budget_seconds": budget,
                "workers": args.workers, "run_contract_sha256": contract_hash,
                "validation120": metrics(rows),
                "aligned_validation60": metrics([row for row in rows if row["case"] in selected_set]),
                "cases": [{key: row[key] for key in ("case", "case_sha256", "profile", "distribution", "makespan", "teacher", "teacher_sha256")} for row in rows],
                "failures": failures,
            }
            atomic(phase_dir / "summary.json", summary)
            atomic(out / "pipeline_state.json", state)
            if failures:
                raise RuntimeError(f"{label}: {len(failures)} case failures; stopping before next phase")
            all_results[label] = {r["case"]: r for r in rows}
        differences = [all_results["iga1800"][name]["makespan"] - row["makespan"] for name, row in all_results["iga180"].items()]
        nested = {
            "case_count": len(differences), "nested_regression_count": sum(d > 1e-9 for d in differences),
            "improved_count": sum(d < -1e-9 for d in differences), "tied_count": sum(abs(d) <= 1e-9 for d in differences),
            "mean_improvement": -float(np.mean(differences)),
        }
        atomic(out / "nested_verification.json", nested)
        if nested["nested_regression_count"]:
            raise RuntimeError("Nested continuation regression")
        state.update(status="completed", ended_unix_time=time.time(), nested_verification=nested)
        print(f"[Stage1IGA] COMPLETED {json.dumps(nested)}", flush=True)
    except BaseException:
        state.update(status="failed", ended_unix_time=time.time(), error=traceback.format_exc())
        raise
    finally:
        atomic(out / "pipeline_state.json", state)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--aligned-evaluation", required=True)
    parser.add_argument("--stage3-reference", default="result/hkbz_train_logs/stage3_matched_iga_h3f4_validation120_20260918_r1/full")
    parser.add_argument("--workers", type=int, default=120)
    parser.add_argument("--seed", type=int, default=20260824)
    parser.add_argument("--population", type=int, default=20)
    parser.add_argument("--max-generations", type=int, default=100000)
    parser.add_argument("--max-steps", type=int, default=4000)
    parser.add_argument("--budget180", type=float, default=180.0)
    parser.add_argument("--budget1800", type=float, default=1800.0)
    parser.add_argument("--max-cases", type=int, default=0)
    args = parser.parse_args()
    if not (0 < args.budget180 < args.budget1800):
        parser.error("Budgets must satisfy 0 < first < cumulative second")
    if min(args.workers, args.max_generations, args.max_steps) < 1 or args.population < 2 or args.max_cases < 0:
        parser.error("Invalid search dimensions")
    return args


if __name__ == "__main__":
    run(parse_args())
