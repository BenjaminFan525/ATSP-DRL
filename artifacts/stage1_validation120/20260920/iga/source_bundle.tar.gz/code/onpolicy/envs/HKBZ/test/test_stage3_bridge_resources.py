"""Execution-only expansion fixtures; not reward or scientific admission evidence."""
from datetime import timedelta
import os
import subprocess
import sys
from types import SimpleNamespace

import numpy as np
import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from onpolicy.scripts.train.stage3_bridge_resource_core import (
    FIELDS, PLACEMENT, ResourceGroupEngine, global_targets, split_logical_shards,
)
from onpolicy.utils.stage3_rl_bridge import actor_targets, schedule, ARMS
from onpolicy.utils.stage3_research import atomic_json, digest_file, read_json
from onpolicy.utils.stage3_distributed import TrajectoryParallel


def rows_fixture():
    rows = []
    for i in range(120):
        rows.append(dict(case_id=f'case{i//4}', group_id=f'group{i//4}', replica=i % 4,
            seed=1000+i, makespan=90.+i % 17, completed=True, behavior_deterministic=False,
            forced_replay=False, policy_updates=7, population_weight=.625 if i < 60 else 2.5,
            states=['must never cross ranks']))
    return rows


def test_resource_schedule_exact_samples_groups_optimizer_membership_and_tail():
    from onpolicy.envs.HKBZ.test.test_stage3_rl_bridge import cases
    plan = schedule(cases(), seed=2026091201, epochs=4, world_size=2, width=60)
    for batch in plan:
        logical = batch['shards']
        physical = split_logical_shards(logical)
        assert [len(x) for x in physical] == [len(logical[0])//2]*4
        assert len(physical[0]) in (6, 30)
        for step in range(len(logical[0])//12):
            before = [r['seed'] for shard in logical for r in shard[12*step:12*(step+1)]]
            after = [r['seed'] for shard in physical for r in shard[6*step:6*(step+1)]]
            assert len(before) == len(after) == 24
            assert sorted(before) == sorted(after) and len(set(after)) == 24
    assert plan[-1]['training_episodes'] == 1536


@pytest.mark.parametrize('arm', tuple(PLACEMENT))
def test_resource_targets_cross_rank_groups_keep_original_advantages(arm):
    rows = rows_fixture()
    costs = {r['case_id']: 100. for r in rows}
    a, w, _ = actor_targets(rows, arm, costs)
    expected = {r['seed']: (av, wt) for r, av, wt in zip(rows, a, w)}
    shards = split_logical_shards([rows[:60], rows[60:]])
    metadata = [[{k: r[k] for k in FIELDS} for r in shard] for shard in shards]
    for rank, local in enumerate(shards):
        def gather(value):
            assert all(set(r) == set(FIELDS) and 'states' not in r for r in value)
            return metadata
        sync = SimpleNamespace(world_size=4, rank=rank, gather=gather)
        actual_a, actual_w, audit = global_targets(local, arm, costs, sync)
        np.testing.assert_allclose(actual_a, [expected[r['seed']][0] for r in local], atol=1e-12)
        np.testing.assert_array_equal(actual_w, [expected[r['seed']][1] for r in local])
        assert len(audit['groups']) == 30


@pytest.mark.parametrize('corruption', ('world', 'unequal', 'seed', 'version', 'partial'))
def test_resource_rejects_malformed_global_groups(corruption):
    rows = rows_fixture()
    shards = split_logical_shards([rows[:60], rows[60:]])
    if corruption == 'unequal':
        shards[-1].pop()
    if corruption == 'seed':
        shards[0][1]['seed'] = shards[0][0]['seed']
    if corruption == 'version':
        shards[0][1]['policy_updates'] += 1
    if corruption == 'partial':
        shards[0][1]['completed'] = False
    sync = SimpleNamespace(world_size=2 if corruption == 'world' else 4, rank=0, gather=lambda _: shards)
    with pytest.raises(ValueError):
        global_targets(shards[0], 'P1_GROUP', {r['case_id']: 100. for r in rows}, sync)


def _gloo_worker(rank, world, arm, rendezvous, output):
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy
    from onpolicy.runner.shared.stage3_rl_bridge_engine import GroupB0Engine
    from onpolicy.utils.stage3_numerics import training_state
    torch.set_num_threads(1)
    dist.init_process_group('gloo', init_method=f'file://{rendezvous}', world_size=world,
                            rank=rank, timeout=timedelta(seconds=120))
    try:
        toy, rows, widths = minibatch_toy(48)
        kind = GroupB0Engine if world == 2 else ResourceGroupEngine
        runner = kind.__new__(kind)
        runner.__dict__.update(toy.__dict__)
        runner.bridge_arm, runner.representation, runner.execution_cache = arm, 'F_PRIVATE', None
        runner.zero_update_batches = 0
        runner.assert_optimizer_ownership = lambda: None
        for i, row in enumerate(rows):
            row.update(case_id=f'case{i//4}', group_id=f'group{i//4}', seed=100+i,
                replica=i % 4, population_weight=.625 if i < 24 else 2.5)
        logical = [rows[:24], rows[24:]]
        local = logical[rank] if world == 2 else split_logical_shards(logical)[rank]
        sync = TrajectoryParallel(device_packed=True)
        result = runner.update(local, 'source', {r['case_id']: 100. for r in rows},
            epochs=2, chunk=8, distributed=sync, microbatch_size=12 if world == 2 else 6,
            optimizer_step_per_microbatch=True)
        sync.assert_replicas(runner)
        assert runner.policy_updates == result['accepted_actor_steps'] == 4
        assert max(widths) == (12 if world == 2 else 6)
        if rank == 0:
            torch.save(training_state(runner), output)
    finally:
        dist.destroy_process_group()


@pytest.mark.parametrize('arm', tuple(PLACEMENT))
def test_resource_gloo_two_vs_four_rank_optimizer_and_normalizers(tmp_path, arm):
    states = []
    for world in (2, 4):
        output = tmp_path/f'{world}.pt'
        mp.spawn(_gloo_worker, args=(world, arm, str(tmp_path/f'rdzv{world}'), str(output)),
                 nprocs=world, join=True)
        states.append(torch.load(output, weights_only=False))
    def compare(a, b):
        assert type(a) is type(b)
        if isinstance(a, dict):
            assert a.keys() == b.keys()
            for key in a:
                compare(a[key], b[key])
        elif isinstance(a, (tuple, list)):
            assert len(a) == len(b)
            for left, right in zip(a, b):
                compare(left, right)
        elif isinstance(a, torch.Tensor):
            torch.testing.assert_close(a, b, rtol=3e-5, atol=3e-6)
        else:
            assert a == b
    compare(states[0], states[1])


def test_resource_controller_reuses_only_completed_phases_and_keeps_gates(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    root = tmp_path/'experiment'
    m = {'root': str(root), 'manifest_sha256': 'science'}
    atomic_json(root/'training_admission.json', {'passed': True, 'manifest_sha256': 'science'})
    for arm in ARMS:
        for rank in range(2):
            atomic_json(root/'screen'/arm/f'rank{rank}/result_epoch2.json',
                        {'completed': True, 'training_episodes': 768})
        for epoch in (1, 2):
            checkpoint = root/'screen'/arm/f'fixture{epoch}.json'
            atomic_json(checkpoint, {'not_real_weights': True})
            atomic_json(root/'screen'/arm/f'epochs/e{epoch:02d}.json',
                        {'checkpoint': str(checkpoint), 'checkpoint_sha256': digest_file(checkpoint)})
    calls = []
    class Suite:
        def __init__(self, *args):
            self.lock = SimpleNamespace(close=lambda: calls.append('closed'))
        def admission(self, hb):
            raise AssertionError('Do not rerun existing admission')
        def execute(self, *args, **kwargs):
            calls.append(('future_original_execute', args, kwargs))
        def pool_mode(self, mode, hb):
            calls.append(('pool', mode))
        def run(self):
            self.admission(None)
            self.execute('train', 'screen', ARMS, 2, None)
            calls.append('unchanged_selection_gate')
            self.execute('train', 'screen', ARMS, 4, None, resume=True)
    monkeypatch.setattr(control, 'original_controller', lambda _: SimpleNamespace(BridgeSuite=Suite))
    control.resume_original_controller(m, root/'manifest.json')
    assert calls[0] == ('pool', 'evaluation_only')
    assert calls[1] == 'unchanged_selection_gate'
    assert calls[2][0] == 'future_original_execute' and calls[2][2] == {'resume': True}
    assert calls[-1] == 'closed'


def test_resource_controller_refuses_incomplete_screening(tmp_path, monkeypatch):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    atomic_json(tmp_path/'training_admission.json', {'passed': True, 'manifest_sha256': 'science'})
    class Suite:
        def __init__(self, *args):
            self.lock = SimpleNamespace(close=lambda: None)
        def execute(self, *args, **kwargs):
            raise AssertionError('Cannot restart silently')
        def run(self):
            self.admission(None)
            self.execute('train', 'screen', ARMS, 2, None)
    monkeypatch.setattr(control, 'original_controller', lambda _: SimpleNamespace(BridgeSuite=Suite))
    with pytest.raises(FileNotFoundError):
        control.resume_original_controller({'root': str(tmp_path), 'manifest_sha256': 'science'}, tmp_path/'manifest.json')


def test_resource_controller_pid_reuse_is_rejected(monkeypatch):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    record = {'pid': 10, 'start_ticks': 100, 'command': 'owned'}
    monkeypatch.setattr(control, 'process_record', lambda _: {**record, 'start_ticks': 101})
    with pytest.raises(RuntimeError, match='identity'):
        control.assert_process(record)


@pytest.mark.parametrize('corruption', ('none', 'rank', 'optimizer', 'checksum'))
def test_resource_controller_checks_full_commit_before_handoff(tmp_path, monkeypatch, corruption):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    from onpolicy.utils.stage3_research import digest_json
    plan = [{'training_episodes': 240}]
    monkeypatch.setattr(control, 'logical_plan', lambda _: plan)
    m = {'root': str(tmp_path), 'manifest_sha256': 'science'}
    entries = []
    for rank in range(2):
        payload = dict(diagnostic_only=False, rank=rank, next_group=2 if corruption == 'rank' and rank else 1,
            world_size=2, bridge_arm='P0_SOURCE', protocol_sha256='science',
            schedule_sha256=digest_json(plan), training_episodes=240, policy_updates=20,
            model={'weight': torch.ones(3)}, actor_optim={'state': torch.ones(3)},
            critic_optim={}, role_value_normalizers={})
        if corruption == 'optimizer' and rank == 1:
            payload['actor_optim']['state'][0] += .001
        target = tmp_path/f'rank{rank}.pt'
        torch.save(payload, target)
        entries.append({'rank': rank, 'checkpoint': str(target),
                        'sha256': 'wrong' if corruption == 'checksum' else digest_file(target)})
    atomic_json(tmp_path/'screen/P0_SOURCE/commits/e000240.json', {
        'manifest_sha256': 'science', 'arm': 'P0_SOURCE', 'world_size': 2, 'phase': 'screen',
        'schedule_sha256': digest_json(plan), 'ranks': entries, 'policy_updates': 20})
    p = {'pause_next_group': {'P0_SOURCE': 1}}
    if corruption == 'none':
        _, result, state = control.boundary_commit(p, m, 'P0_SOURCE')
        assert result['policy_updates'] == 20 and len(state) == 64
    else:
        with pytest.raises(ValueError):
            control.boundary_commit(p, m, 'P0_SOURCE')


def test_resource_gradient_proposals_do_not_mutate_live_state():
    from onpolicy.scripts.train.stage3_bridge_resource_control import compare_gradient_proposals
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy
    from onpolicy.utils.stage3_numerics import training_state
    from onpolicy.utils.stage3_distributed import state_digest
    runner, _, _ = minibatch_toy(4)
    gradients = {name: torch.full_like(parameter, .5) for name, parameter in runner.policy.ac.named_parameters()}
    unchanged = state_digest(training_state(runner))
    passed, report = compare_gradient_proposals(runner, gradients, gradients)
    assert passed and all(row['proposed_parameter_max_absolute_error'] == 0 for row in report.values())
    assert state_digest(training_state(runner)) == unchanged
    corrupt = {name: -value for name, value in gradients.items()}
    passed, _ = compare_gradient_proposals(runner, gradients, corrupt)
    assert not passed and state_digest(training_state(runner)) == unchanged


@pytest.mark.parametrize('state,command,expected', [
    ('R', 'owned', True), ('S', 'owned', True), ('T', 'owned', True),
    ('Z', '', False), ('X', '', False)])
def test_resource_controller_process_exit_state_precedes_cmdline(monkeypatch, state, command, expected):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    owned = {'pid': 10, 'start_ticks': 100, 'command': 'owned'}
    monkeypatch.setattr(control, 'process_record', lambda _: {**owned, 'state': state, 'command': command})
    assert control.process_active(owned) is expected


def test_resource_controller_handles_stat_cmdline_exit_race(monkeypatch):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    owned = {'pid': 10, 'start_ticks': 100, 'command': 'owned'}
    snapshots = iter([{**owned, 'state': 'R', 'command': ''}, {**owned, 'state': 'Z', 'command': ''}])
    monkeypatch.setattr(control, 'process_record', lambda _: next(snapshots))
    assert not control.process_active(owned)


@pytest.mark.parametrize('state', ('R', 'Z'))
def test_resource_controller_reused_pid_is_rejected_even_if_dead(monkeypatch, state):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    owned = {'pid': 10, 'start_ticks': 100, 'command': 'owned'}
    monkeypatch.setattr(control, 'process_record', lambda _: {**owned, 'state': state, 'start_ticks': 101})
    with pytest.raises(RuntimeError, match='identity'):
        control.process_active(owned)


def test_resource_controller_live_exec_change_is_rejected(monkeypatch):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    owned = {'pid': 10, 'start_ticks': 100, 'command': 'owned'}
    monkeypatch.setattr(control, 'process_record', lambda _: {**owned, 'state': 'R', 'command': 'foreign'})
    with pytest.raises(RuntimeError, match='command changed'):
        control.process_active(owned)


def test_resource_controller_missing_pid_is_inactive(monkeypatch):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    def gone(_):
        raise FileNotFoundError()
    monkeypatch.setattr(control, 'process_record', gone)
    assert not control.process_active({'pid': 10, 'start_ticks': 100, 'command': 'owned'})


def test_resource_controller_real_zombie_is_inactive_before_reaping():
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    child = subprocess.Popen([sys.executable, '-B', '-c', 'import time; time.sleep(.2)'])
    try:
        record = control.process_record(child.pid)
        os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOWAIT)
        zombie = control.process_record(child.pid)
        assert zombie['state'] == 'Z' and zombie['command'] == ''
        assert zombie['start_ticks'] == record['start_ticks']
        assert not control.process_active(record)
    finally:
        child.wait(timeout=5)


@pytest.mark.parametrize('corruption', ('none', 'cursor', 'owner', 'active', 'controller', 'updates', 'launched'))
def test_resource_controller_recovery_requires_owned_full_commit(tmp_path, monkeypatch, corruption):
    from onpolicy.scripts.train import stage3_bridge_resource_control as control
    root, prior = tmp_path/'run', tmp_path/'previous'
    previous = {'root': str(prior), 'pause_next_group': {a: 2 for a in PLACEMENT},
        'controller': {'pid': 1}, 'controller_unit': 'owned.service',
        'workers': {f'{a}:{r}': {'pid': 100+r} for a in PLACEMENT for r in range(2)}}
    atomic_json(prior/'error.json', {'controller_paused': True})
    atomic_json(root/'PAUSE_AFTER_COMMIT', {'owner': control.VERSION,
        'resource_manifest': str(prior/'manifest.json') if corruption != 'owner' else 'someone_else',
        'next_groups': previous['pause_next_group']})
    for arm in PLACEMENT:
        for rank in range(2):
            atomic_json(root/'screen'/arm/f'rank{rank}/paused_2.json', {
                'paused': True, 'next_group': 3 if corruption == 'cursor' else 2,
                'policy_updates': 19 if corruption == 'updates' else 20})
    if corruption == 'launched':
        atomic_json(prior/'activated.json', {'already_started': True})
    monkeypatch.setattr(control, 'assert_process', lambda _: None)
    monkeypatch.setattr(control, 'process_record', lambda _: {'pid': 1, 'state': 'R' if corruption == 'controller' else 'T'})
    monkeypatch.setattr(control, 'unit_property', lambda *args: '1')
    monkeypatch.setattr(control, 'process_active', lambda _: corruption == 'active')
    monkeypatch.setattr(control, 'boundary_commit', lambda *args: (
        None, {'policy_updates': 20, 'training_episodes': 240}, 'unchanged_state'))
    if corruption == 'none':
        result = control.validate_paused_recovery(previous, {'root': str(root)}, prior/'manifest.json')
        assert all(row['training_episodes'] == 240 and row['policy_updates'] == 20 for row in result.values())
    else:
        with pytest.raises(ValueError):
            control.validate_paused_recovery(previous, {'root': str(root)}, prior/'manifest.json')
