from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest

import numpy as np
import torch

from onpolicy.algorithms.utils.stage1_baselines import L2DActor
from onpolicy.utils.stage1_async_eval import Stage1AsyncEvalMixin
from onpolicy.utils.training_stage import protected_parameter_summary
from onpolicy.scripts.train.prepare_stage1_p5_aligned_baselines import (
    check_cpu_isolation, runtime_command, source_commands, option,
)
from onpolicy.scripts.train.run_stage1_p5_aligned_suite import load_manifest


class L2DTeacherReplayTest(unittest.TestCase):
    def test_teacher_supervises_operation_without_changing_ppo_site_rule(self):
        torch.manual_seed(17)
        actor = L2DActor(query_dim=24, embed_dim=8, nhead=2, pair_feature_dim=10)
        features = torch.zeros(1, 2, 3, 10)
        features[..., 2] = torch.tensor([0.1, 0.2, 0.3])
        args = (
            torch.randn(1, 1, 24), torch.randn(1, 2, 8),
            torch.randn(1, 3, 8), torch.ones(1, 2, dtype=torch.bool),
            torch.ones(1, 2, 3, dtype=torch.bool),
        )
        chosen_op, teacher_site = torch.tensor([0]), torch.tensor([2])
        with self.assertRaisesRegex(RuntimeError, "earliest-finish"):
            actor(*args, chosen_op=chosen_op, chosen_site=teacher_site, pair_features=features)
        standard = actor(*args, chosen_op=chosen_op, chosen_site=torch.tensor([0]), pair_features=features)
        actor.operation_teacher_replay = True
        supervised = actor(*args, chosen_op=chosen_op, chosen_site=teacher_site, pair_features=features)
        self.assertEqual(supervised[1].item(), 2)
        torch.testing.assert_close(supervised[2], standard[2])
        torch.testing.assert_close(supervised[3].exp().sum(-1), torch.ones(1))
        (-supervised[2].mean()).backward()
        self.assertGreater(sum(float(p.grad.abs().sum()) for p in actor.parameters() if p.grad is not None), 0)
        actor.operation_teacher_replay = False
        predicted = actor(*args, deterministic=True, pair_features=features)
        self.assertEqual(predicted[1].item(), 0)
        with self.assertRaisesRegex(RuntimeError, "earliest-finish"):
            actor(*args, chosen_op=chosen_op, chosen_site=teacher_site, pair_features=features)

    def test_teacher_cannot_bypass_environment_mask(self):
        actor = L2DActor(query_dim=24, embed_dim=8, nhead=2, pair_feature_dim=10)
        actor.operation_teacher_replay = True
        mask = torch.ones(1, 2, 3, dtype=torch.bool)
        mask[0, 0, 2] = False
        with self.assertRaisesRegex(ValueError, "environment mask"):
            actor(
                torch.zeros(1, 1, 24), torch.zeros(1, 2, 8), torch.zeros(1, 3, 8),
                torch.ones(1, 2, dtype=torch.bool), mask,
                chosen_op=torch.tensor([0]), chosen_site=torch.tensor([2]),
                pair_features=torch.zeros(1, 2, 3, 10),
            )


class _FakeClient:
    def __init__(self, released):
        self.released = released

    def request(self, request):
        if not self.released.wait(5):
            raise TimeoutError("test did not release evaluation")
        packet = torch.load(request["checkpoint_path"], weights_only=False)
        value = int(packet["model"]["weight"].item())
        return {"request_id": request["request_id"], "evaluation": {"score": {0: 30, 1: 10, 2: 20}[value]}}


class _FakeRunner:
    def __init__(self, config):
        self.run_dir = Path(config["directory"])
        self.save_dir = self.run_dir / "models"
        self.save_dir.mkdir()
        self.training_stage = "plane_pretrain"
        self.policy = SimpleNamespace(ac=SimpleNamespace(stage1_baseline="l2d"))
        self.shared_eval_client = _FakeClient(config["released"])
        self.early_stop_patience = self.canary_eval_interval_shards = 0
        self.evaluation_tau = 0.3
        self.total_num_steps = 0
        self.weight = 0
        self.best_eval_makespan = self.best_eval_iid_makespan = self.best_eval_composite_makespan = float("inf")
        self.logs = []

    def save(self, episode=0, filename=None, extra=None):
        packet = {
            "model": {"weight": torch.tensor([float(self.weight)])},
            "optimizer_step": self.total_num_steps, "episodes": episode + 1,
            **(extra or {}),
        }
        self._atomic_torch_save(packet, str(self.save_dir / (filename or f"checkpoint_Epoch{episode + 1}.pt")))

    @staticmethod
    def _atomic_torch_save(packet, path):
        torch.save(packet, path)

    def eval(self, render=False, evaluation_label=None):
        model = {"weight": torch.tensor([float(self.weight)])}
        digest = protected_parameter_summary(model, prefixes=("",))["sha256"]
        packet = self.run_dir / (evaluation_label + ".pt")
        torch.save({"model": model}, packet)
        try:
            response = self.shared_eval_client.request({
                "checkpoint_path": str(packet), "request_id": evaluation_label,
                "model_sha256": digest,
            })
            return self._consume_raw_evaluation(response["evaluation"], evaluation_label)
        finally:
            packet.unlink()

    def _consume_raw_evaluation(self, payload, evaluation_label=None):
        score = payload["score"]
        self.last_eval_raw_makespan = self.last_eval_iid_makespan = score
        self.last_eval_composite_makespan = self.last_eval_tail_makespan = score
        self.last_eval_selection_score = score
        return score

    def _update_best_checkpoints(self, episode, stage):
        if self.last_eval_selection_score >= self.best_eval_makespan:
            return False
        self.best_eval_makespan = self.last_eval_selection_score
        self.save(episode, filename="checkpoint_Best.pt", extra={"selection_score": self.best_eval_makespan})
        return True

    def _evaluation_log_info(self, score):
        return {"eval_makespan": score}

    def log_train(self, info, steps):
        self.logs.append((info, steps))

    def _report_progress(self, event, **extra):
        pass


class _FakeAsyncRunner(Stage1AsyncEvalMixin, _FakeRunner):
    pass


class AsyncSnapshotTest(unittest.TestCase):
    def test_submission_is_nonblocking_and_best_uses_evaluated_full_snapshot(self):
        with tempfile.TemporaryDirectory() as directory:
            released = threading.Event()
            runner = _FakeAsyncRunner({"directory": directory, "released": released})
            try:
                runner.eval(evaluation_label="pre_ppo")
                self.assertEqual(len(runner._async_jobs), 1)
                self.assertFalse(runner._async_jobs[0]["future"].done())
                runner.weight, runner.total_num_steps = 1, 100
                runner.eval(evaluation_label="epoch_1")
                runner.weight, runner.total_num_steps = 2, 200
                runner.eval(evaluation_label="epoch_2")
                # Live parameters can advance while all three evaluations wait.
                runner.weight, runner.total_num_steps = 99, 999
                released.set()
                runner._drain_async(wait=True)
                best = torch.load(runner.save_dir / "checkpoint_Best.pt", weights_only=False)
                self.assertEqual(best["model"]["weight"].item(), 1)
                self.assertEqual(best["optimizer_step"], 100)
                self.assertEqual(best["episodes"], 1)
                self.assertEqual(runner.weight, 99)
                self.assertEqual(runner.total_num_steps, 999)
                self.assertEqual([job["label"] for job in runner._async_completed], ["pre_ppo", "epoch_1", "epoch_2"])
                self.assertEqual([step for _, step in runner.logs], [0, 100, 200])
                self.assertTrue(best["evaluation_snapshot_verified"])
            finally:
                released.set()
                runner._async_executor.shutdown(wait=True)

    def test_modified_snapshot_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            released = threading.Event()
            runner = _FakeAsyncRunner({"directory": directory, "released": released})
            try:
                runner.eval(evaluation_label="pre_ppo")
                path = runner._async_jobs[0]["snapshot_path"]
                torch.save({"model": {"weight": torch.tensor([999.0])}}, path)
                released.set()
                with self.assertRaisesRegex(RuntimeError, "checkpoint changed"):
                    runner._drain_async(wait=True)
            finally:
                released.set()
                runner._async_executor.shutdown(wait=True)


class AlignmentContractTest(unittest.TestCase):
    def test_aligned_runner_initializes_bc_but_standard_runner_keeps_guard(self):
        from onpolicy.config.config import get_config
        from onpolicy.envs.HKBZ.test.test_stage1_learning_baselines import ROOT, _ac_config
        from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
        from onpolicy.scripts.train.train_hkbz import parse_args

        class Runner(Stage1AsyncEvalMixin, HKBZ_Runner):
            pass

        for method in ("l2d", "multi_ppo", "fjsp_drl", "daniel"):
            with self.subTest(method=method), tempfile.TemporaryDirectory() as directory:
                command = runtime_command(source_commands()["p5"], method=method,
                    experiment="test_aligned_initialization", seed=1, code_root=ROOT,
                    suite=Path(directory), socket_path="/tmp/test-aligned-init.sock")
                args = parse_args(command[2:], get_config())
                args.use_wandb = False  # train_hkbz.main applies this locally too.
                args.use_recurrent_policy = True
                args.use_naive_recurrent_policy = False
                args.plane_bc_pretrain_epochs = 1
                args.n_rollout_threads = args.n_eval_rollout_threads = 1
                args.episode_length = args.rollout_max_steps = 2
                args.mini_batch_size = args.data_chunk_length = 1
                config = {"all_args": args, "envs": None, "eval_envs": None,
                    "device": torch.device("cpu"), "num_agents": 24,
                    "ac_config": _ac_config(), "num_envs": 1,
                    "run_dir": Path(directory),
                    "shared_eval_socket": "/tmp/test-aligned-init.sock",
                    "shared_eval_cpu_set": "56-63,120-127"}
                with self.assertRaisesRegex(ValueError, "Published learning-baseline"):
                    HKBZ_Runner(config)
                runner = Runner(config)
                released = threading.Event()

                class BlockingClient:
                    def request(self, payload):
                        if not released.wait(5):
                            raise TimeoutError("test did not release real-runner submission")
                        return {"request_id": payload["request_id"], "evaluation": {}}

                try:
                    self.assertEqual(runner.plane_bc_pretrain_epochs, 1)
                    self.assertEqual(runner.policy.ac.stage1_baseline, method)
                    # Exercise the real runner save/serialization/RPC adapter,
                    # without starting an environment rollout or an evaluator.
                    runner.shared_eval_client = BlockingClient()
                    runner.total_num_steps = 0
                    self.assertTrue(np.isnan(runner.eval(evaluation_label="pre_ppo")))
                    self.assertEqual(len(runner._async_jobs), 1)
                    job = runner._async_jobs[0]
                    self.assertFalse(job["future"].done())
                    snapshot = torch.load(job["snapshot_path"], map_location="cpu", weights_only=False)
                    self.assertEqual(protected_parameter_summary(
                        snapshot["model"], prefixes=("",))["sha256"], job["model_sha256"])
                    released.set()
                    job["future"].result(timeout=5)
                    args.resource_policy = "drl"
                    with self.assertRaisesRegex(ValueError, "Hungarian"):
                        runner._validate_training_stage_config()
                    args.resource_policy = "heuristic"
                    runner.plane_bc_teacher_dir = str(Path(directory) / "missing_teachers")
                    with self.assertRaisesRegex(ValueError, "teacher directory does not exist"):
                        runner._validate_training_stage_config()
                finally:
                    released.set()
                    runner._async_executor.shutdown(wait=True)
                    runner.writter.close()

    def test_cpu_isolation_keeps_smt_siblings_and_avoids_other_experiments(self):
        self.assertTrue(check_cpu_isolation())
        with self.assertRaisesRegex(ValueError, "overlap"):
            check_cpu_isolation(("32-37,96-101", "32-37,96-101"))
        with self.assertRaisesRegex(ValueError, "SMT"):
            check_cpu_isolation(("32-37",))
        with self.assertRaisesRegex(ValueError, "NUMA"):
            check_cpu_isolation(("0-5,64-69",))

    def test_pending_initialization_choice_cannot_launch(self):
        import json
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "manifest.json"
            path.write_text(json.dumps({"scope": "stage1_p5_aligned_baselines", "launch_authorized": False}))
            with self.assertRaisesRegex(RuntimeError, "explicit user approval"):
                load_manifest(path)

    def test_formal_recipe_preserves_p5_training_controls(self):
        with tempfile.TemporaryDirectory() as directory:
            source = source_commands()["p5"]
            command = runtime_command(source, method="daniel", experiment="test_formal_daniel_seed1",
                seed=1, code_root=Path(directory), suite=Path(directory), socket_path="/tmp/test-p5.sock")
            for flag in ("--num_episodes", "--hindsight_reward_mode", "--iga_potential_beta",
                "--iga_potential_gamma", "--gamma", "--hindsight_terminal_cmax_coef",
                "--bc_reference_kl_coef_schedule", "--lr", "--critic_lr", "--ppo_epoch",
                "--actor_grad_accumulation_steps", "--grad_accumulation_steps"):
                self.assertEqual(option(command, flag), option(source, flag), flag)
            self.assertIn("--adaptive_actor_kl", command)
            self.assertNotIn("--checkpoint_dir", command)
            self.assertEqual(option(command, "--stage1_baseline"), "daniel")

    def test_real_teacher_bc_updates_all_four_baselines(self):
        from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
        from onpolicy.config.config import get_config
        from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv
        from onpolicy.envs.HKBZ.test.test_stage1_learning_baselines import CASE_DIR, _ac_config
        from onpolicy.runner.shared.hkbz_runner import HKBZ_Runner
        from onpolicy.scripts.train.prepare_stage1_p5_aligned_baselines import TEACHER

        class Runner(Stage1AsyncEvalMixin, HKBZ_Runner):
            pass

        environment = AircraftScheduleEnv({
            "jobs_path": str(CASE_DIR / "job.json"),
            "fixed_res_path": str(CASE_DIR / "fixed_resources.json"),
            "mobile_res_path": str(CASE_DIR / "mobile_resources.json"),
            "sites_path": str(CASE_DIR / "sites.json"),
            "flights_path": str(CASE_DIR / "flights.json"),
            "seed": 42, "resource_policy": "heuristic", "n_agents": 24,
            "max_device_num": 80, "pair_feature_storage": "sparse_legal",
            "global_feature_mode": "f1f2", "iga_teacher_dir": str(TEACHER),
        })
        policies = {}
        updates = {method: 0 for method in ("l2d", "multi_ppo", "fjsp_drl", "daniel")}
        try:
            obs, _, info = environment.reset()
            for method in updates:
                args = get_config().parse_args(["--stage1_baseline", method, "--resource_policy", "heuristic",
                    "--plane_order_mode", "fixed", "--plane_pair_decoder", "joint_pair", "--global_feature_mode", "f1f2"])
                runner = Runner.__new__(Runner)
                runner.__dict__.update(vars(args))
                runner.all_args = args
                runner.device = torch.device("cpu")
                runner.policy = GNN_MAPPOPolicy(args, _ac_config(), device=runner.device)
                runner.policy.ac.eval()
                policies[method] = runner
            last = np.full((1, 24, 2), -1, dtype=np.int64)
            recurrent = np.zeros((1, 24, 1, 64), dtype=np.float32)
            for _ in range(12):
                teacher = environment.iga_teacher_actions(return_info=True)
                self.assertTrue(teacher["info"]["available"])
                labels = np.asarray(teacher["actions"], dtype=np.int64)[None, ...]
                active = np.asarray(info["active_agents"], dtype=np.float32)[None, :, None]
                for method, runner in policies.items():
                    result = runner._plane_bc_update([obs.clone()], recurrent, active, last, labels,
                        runner.policy.actor_optimizer)
                    if result is not None:
                        updates[method] += 1
                        self.assertTrue(np.isfinite(result["plane_bc_loss"]))
                    self.assertFalse(getattr(runner.policy.ac.actor, "operation_teacher_replay", False))
                obs, _, done, info = environment.step(labels[0])
                last = labels.copy()
                if np.all(done):
                    break
            self.assertTrue(all(count > 0 for count in updates.values()), updates)
        finally:
            environment.close()


if __name__ == "__main__":
    unittest.main()
