"""Batched B0 sampling contracts; all short fixtures are diagnostic only."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest
import torch

from onpolicy.utils.stage3_batched_sampling import (BATCHING_VERSION, SAMPLING_VERSION,
    TrajectorySamplingStreams, categorical_from_uniform, sampling_uniforms)


def test_batch36_rng_independent_of_membership_and_completion():
    seeds = [101, 202, 303]
    together = TrajectorySamplingStreams(seeds, 104)
    separate = [TrajectorySamplingStreams([s], 104) for s in seeds]
    torch_before = torch.get_rng_state().clone()
    for indices in ([0, 1, 2], [2, 0], [0], [0, 2]):
        actual = together.draw(indices)
        expected = np.stack([separate[i].draw([0])[0] for i in indices])
        assert np.array_equal(actual, expected)
    assert torch.equal(torch_before, torch.get_rng_state())
    draws = TrajectorySamplingStreams(list(range(36)), 104).draw(list(range(36)))
    assert len({r.tobytes() for r in draws}) == 36


def test_batch36_categorical_distribution_and_legal_padding():
    # Fixed stratified uniforms give a deterministic probability-mass check.
    logits = torch.tensor([[-float('inf'), np.log(.1), np.log(.3), -float('inf'), np.log(.6)]], dtype=torch.float32)
    n = 10000
    u = (torch.arange(n, dtype=torch.float64)+.5)/n
    selected = categorical_from_uniform(logits.expand(n, -1), u)
    counts = torch.bincount(selected, minlength=5).double()/n
    torch.testing.assert_close(counts, torch.tensor([0., .1, .3, 0., .6], dtype=torch.float64), atol=.0001, rtol=0)
    edge = torch.tensor([0., np.nextafter(1., 0.)], dtype=torch.float64)
    assert categorical_from_uniform(logits.expand(2, -1), edge).tolist() == [1, 4]
    from onpolicy.algorithms.utils.ptr_actor import _select_masked_index
    assert _select_masked_index(logits, torch.isfinite(logits), True,
                                sampling_uniform=torch.tensor([0.])).item() == 4
    with pytest.raises(ValueError, match=r'\[0,1\)'):
        categorical_from_uniform(logits, torch.tensor([1.]))


def test_batch36_context_is_scoped_and_failure_safe():
    from types import SimpleNamespace
    ac = SimpleNamespace()
    with pytest.raises(ValueError, match='without autograd'):
        with sampling_uniforms(ac, np.zeros((3, 104)), 'cpu'):
            pass
    with torch.no_grad():
        with pytest.raises(RuntimeError, match='fixture'):
            with sampling_uniforms(ac, np.zeros((3, 104)), 'cpu'):
                with pytest.raises(ValueError, match='Nested'):
                    with sampling_uniforms(ac, np.zeros((3, 104)), 'cpu'):
                        pass
                raise RuntimeError('fixture')
    assert not hasattr(ac, 'stage3_sampling_uniforms')


def test_batch36_real_rollout_loop_batches_live_rows_and_preserves_greedy():
    from onpolicy.envs.HKBZ.test.test_stage3_b0_reproduction import toy_runner
    from onpolicy.runner.shared.stage3_research_engine import ResearchEngine
    cases = [{'path':f'/synthetic/{i}', 'profile':'test', 'distribution':'test'} for i in range(36)]
    runner, widths = toy_runner(36)
    rows = ResearchEngine.rollout(runner, cases, list(range(36)), stochastic_batching=BATCHING_VERSION)
    assert widths == list(range(36, 0, -1))
    assert all(r['sampling_rng'] == SAMPLING_VERSION for r in rows)
    assert runner.last_rollout_inference['max_forward_batch'] == 36
    assert not hasattr(runner.policy.ac, 'stage3_sampling_uniforms')
    runner, widths = toy_runner(3)
    ResearchEngine.rollout(runner, cases[:3], [1,2,3], deterministic=True,
        stochastic_batching=BATCHING_VERSION, greedy_batching='per_case_v1')
    assert widths == [1]*6


def test_batch36_parent_lineage_schedule_and_contract(tmp_path):
    from onpolicy.envs.HKBZ.test.test_stage3_b0_throughput import continuation_fixture, cases, flatten
    from onpolicy.utils.stage3_b0_protocol import identity
    from onpolicy.utils.stage3_b0_throughput import (ENV36_BATCH_VERSION, ENV36_BATCH_AUTHORIZATION,
        training_contract, parent_manifest, continuation_plan)
    from onpolicy.utils.stage3_research import atomic_json, digest_file, digest_json
    from onpolicy.utils.stage3_full_data import schedule
    parent = continuation_fixture(tmp_path)
    root = tmp_path/'batch96'
    root.mkdir()
    parent['root'] = str(root)
    parent['manifest_sha256'] = identity(parent)
    atomic_json(root/'manifest.json', parent)
    atomic_json(root/'training_admission.json', {'passed':True})
    ranks = []
    for rank in range(8):
        path = root/f'rank{rank}.pt'
        path.write_bytes(b'synthetic-not-weights')
        ranks.append({'rank':rank, 'checkpoint':str(path), 'sha256':digest_file(path)})
    atomic_json(root/'commit.json', {'world_size':8, 'ranks':ranks, 'training_episodes':608,
        'actual_actor_updates':34, 'protocol_sha256':parent['manifest_sha256'],
        'schedule_sha256':digest_json(continuation_plan(parent)),
        'recipe_sha256':digest_file(root/'training_admission.json')})
    child = copy.deepcopy(parent)
    child['training'] = training_contract(288)
    child['throughput'].update(version=ENV36_BATCH_VERSION, authorization=ENV36_BATCH_AUTHORIZATION,
        parent_manifest=str(root/'manifest.json'), parent_manifest_sha256=digest_file(root/'manifest.json'),
        resume_commit=str(root/'commit.json'), resume_commit_sha256=digest_file(root/'commit.json'),
        start_episodes=608, start_actor_updates=34, global_batch=288, rollout_envs_per_rank=36,
        rollout_trajectories_per_rank=36, rollout_waves_per_rank=1, backward_trajectories_per_rank=12,
        gradient_accumulation_microbatches=1, optimizer_step_after_microbatches=False,
        optimizer_step_per_microbatch=True, optimizer_minibatches=3, optimizer_global_batch=96,
        release_environments_after_rollout=True, fresh_rollout_cadence_changed=True,
        environment_start_method='forkserver', optimizer_update_cadence_changed=False,
        stochastic_batching=BATCHING_VERSION, sampling_rng=SAMPLING_VERSION, sampling_forward_batch=36,
        greedy_inference_unchanged=True,
        parent_evidence={str(root/'training_admission.json'):digest_file(root/'training_admission.json')})
    child['throughput']['schedule_sha256'] = digest_json(continuation_plan(child))
    assert parent_manifest(child)['training']['global_batch'] == 96
    plan = continuation_plan(child)
    assert len(plan) == 30 and [b['batch_size'] for b in plan[:2]] == [288, 64]
    assert flatten(plan) == flatten(schedule(cases(), child['training']['seed']))[608:]
    assert sum((b['batch_size']+95)//96 for b in plan)*2 == 148
    for key,value in [('stochastic_batching','per_case_v1'), ('sampling_forward_batch',1),
                      ('sampling_rng','global_torch_rng'), ('rollout_envs_per_rank',48),
                      ('backward_trajectories_per_rank',36), ('greedy_inference_unchanged',False)]:
        bad = copy.deepcopy(child)
        bad['throughput'][key] = value
        with pytest.raises(ValueError, match='contract'):
            parent_manifest(bad)


def test_batch36_real_workers_and_batched_replay(tmp_path, record_property):
    root = Path(__file__).resolve().parents[4]
    reports = {}
    for method in ('spawn','forkserver'):
        output = tmp_path/f'{method}.json'
        completed = subprocess.run([sys.executable,'-B',str(root/'onpolicy/scripts/train/probe_stage3_b0_env_pool.py'),
            '--width','36','--batched-inference','--start-method',method,'--output',str(output)],
            cwd=root, env={**os.environ,'CUDA_VISIBLE_DEVICES':''}, capture_output=True,text=True,timeout=180)
        assert completed.returncode == 0, completed.stdout+'\n'+completed.stderr
        reports[method] = json.loads(output.read_text())
        assert reports[method]['live_environments'] == 36 and reports[method]['actor_updates'] == 0
        assert reports[method]['inference']['max_forward_batch'] == 36
        assert reports[method]['inference']['forward_calls'] == 2
        assert reports[method]['replay']['max_logp_error'] <= .002
        assert not reports[method]['full_capacity_admission']
    assert reports['spawn']['records'] == reports['forkserver']['records']
    record_property('forkserver36_pss_gib', max(m['total_pss_gib'] for m in reports['forkserver']['memory']))
    record_property('diagnostic_prefix_only', True)


def test_batch36_real_policy_heads_and_greedy_unchanged():
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.envs.HKBZ.test.test_stage3_b0 import MANIFEST
    from onpolicy.utils.stage3_research import WORKSPACE_ROOT, case_record
    from onpolicy.scripts.train.run_stage3_sampling_audit import trajectory_record
    runner = B0Engine(MANIFEST, width=1, device='cpu')
    original = runner.pool.call
    def prefix(commands):
        result = original(commands)
        for i, command, _ in commands:
            if command == 'summary':
                result[i] = {**result[i], 'completed':True, 'synthetic_prefix_fixture':True}
        return result
    runner.pool.call = prefix
    case = case_record(WORKSPACE_ROOT/'onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train/case_0341')
    try:
        before = runner.rollout([case], [1], deterministic=True, max_steps=2)
        runner.stochastic_batching = BATCHING_VERSION
        after = runner.rollout([case], [1], deterministic=True, max_steps=2)
        assert trajectory_record(before[0]) == trajectory_record(after[0])
        row = runner.rollout([case], [7], retain=True, max_steps=2)[0]
        assert row['sampling_rng'] == SAMPLING_VERSION
        assert runner.replay_metrics([row])['max_logp_error'] <= .002
        # Sample/replay each native head with the new explicit draws; logp
        # and masks must remain the original head's differentiable output.
        torch.manual_seed(123)
        for actor in (runner.policy.ac.device_actor, runner.policy.ac.transporter_actor):
            kwargs = {'query':torch.randn(3,1,actor.req_query_ff.embedding[0].in_features),
                'request_nodes':torch.randn(3,5,64), 'request_valid_mask':torch.ones(3,5,dtype=torch.bool),
                'sampling_uniform':torch.tensor([0., .4, .999],dtype=torch.float64)}
            with torch.no_grad():
                selected, lp, logits = actor(**kwargs)
                replay = actor(**{k:v for k,v in kwargs.items() if k!='sampling_uniform'},chosen_request=selected)
            torch.testing.assert_close(lp, replay[1], atol=0, rtol=0)
            assert torch.isfinite(logits.gather(1, selected[:,None])).all()
    finally:
        runner.close()
