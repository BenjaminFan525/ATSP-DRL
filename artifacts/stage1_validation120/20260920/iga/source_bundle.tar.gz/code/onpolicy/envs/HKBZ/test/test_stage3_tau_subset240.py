"""Data-only K4 subset regression; no scientific performance claims."""
import copy
from collections import Counter

import pytest

from onpolicy.utils.stage3_b0_subset240 import selection, select_cases
from onpolicy.utils.stage3_research import digest_json
from onpolicy.utils.stage3_rl_bridge import distribution_weights, TARGET_WEIGHTS
from onpolicy.utils.stage3_tau import (ARMS, TEMPERATURE, data_budget, subset_contract,
    training_cases, training_plan, resume_cursor, temperature, temperature_state, verify_data)


def full_cases():
    chosen = selection()['case_ids']
    remaining = sorted({f'case_{i:04d}' for i in range(1, 601)} - set(chosen))
    rows = []
    for names, counts in ((chosen, (192, 43, 5)), (remaining, (288, 65, 7))):
        kinds = [kind for kind, count in zip(('iid', 'ood_stress', 'ood_scale'), counts)
                 for _ in range(count)]
        rows += [dict(name=name, path=f'/fixture/train/{name}', distribution=kind,
                      content_sha256=digest_json(name), profile='fixture')
                 for name, kind in zip(names, kinds)]
    return rows


def manifest(subset=True):
    full = full_cases()
    m = dict(manifest_sha256='fixture', splits=dict(train_full600=full),
             training=dict(seed=2026091201, **data_budget(240 if subset else 600)))
    if subset:
        m['splits']['train_subset240'] = select_cases(full)
        m['subset_training'] = subset_contract(full)
    return m


def commit(m, episodes, world=2, arm='T1_ANNEAL10'):
    return dict(manifest_sha256=m['manifest_sha256'], arm=arm, phase='full',
        world_size=world, schedule_sha256=digest_json(training_plan(m, world)),
        training_episodes=episodes, temperature_state=temperature_state(arm, episodes),
        ranks=[dict(rank=r, state_sha256='same') for r in range(world)])


def test_tau_subset_selection_exact_list_and_population_objective():
    m = manifest()
    verify_data(m)
    chosen = training_cases(m)
    assert [c['name'] for c in chosen] == selection()['case_ids']
    counts = Counter(c['distribution'] for c in chosen)
    assert counts == dict(iid=192, ood_stress=43, ood_scale=5)
    weights = distribution_weights(chosen)
    assert weights == dict(iid=.625, ood_stress=108/43, ood_scale=2.4)
    for kind, target in TARGET_WEIGHTS.items():
        assert counts[kind]*weights[kind]/240 == pytest.approx(target)
    assert m['subset_training']['episodes_per_data_epoch'] == 960
    assert m['subset_training']['replicas_per_case'] == 4


@pytest.mark.parametrize('world', [2, 4])
def test_tau_subset_budget_whole_groups_and_no_extra_visits(world):
    m = manifest()
    original = copy.deepcopy(m)
    plan = training_plan(m, world)
    assert m == original
    assert plan[-1]['training_episodes'] == 7680
    assert [b['training_episodes'] for b in plan if b['epoch_tail']] == list(range(960, 7681, 960))
    assert m['training']['first_stage_total_budget'] == 15360
    assert m['training']['maximum_total_budget'] == 23040
    for epoch in range(1, 9):
        batches = [b for b in plan if b['epoch'] == epoch]
        assert len(batches) == 16 // world
        rows = [r for b in batches for shard in b['shards'] for r in shard]
        assert Counter(r['case']['name'] for r in rows) == Counter(dict.fromkeys(selection()['case_ids'], 4))
        for batch in batches:
            assert batch['batch_size'] == 60*world
            for shard in batch['shards']:
                assert len(shard) == 60
                for start in range(0, 60, 12):
                    group_counts = Counter(r['group_id'] for r in shard[start:start+12])
                    assert sorted(group_counts.values()) == [4, 4, 4]


def test_tau_subset_selection_keeps_original_group_ids_and_replica_seeds():
    full, subset = manifest(False), manifest()
    selected_paths = {c['path'] for c in training_cases(subset)}
    def exposure(m, world):
        return sorted((b['epoch'], r['case']['path'], r['replica'], r['seed'], r['group_id'])
            for b in training_plan(m, world) for shard in b['shards'] for r in shard
            if r['case']['path'] in selected_paths)
    assert exposure(full, 2) == exposure(subset, 2) == exposure(subset, 4)
    verify_data(full)
    assert data_budget(600)['maximum_total_budget'] == 57600


def test_tau_subset_resume_transition_is_at_new_E4_not_old_absolute_budget():
    m = manifest()
    c = commit(m, 3840)
    assert resume_cursor(m, c['arm'], c, 2) == 32
    assert resume_cursor(m, c['arm'], c, 4) == 16
    later = commit(m, 4800, world=4)
    assert resume_cursor(m, later['arm'], later, 4) == 20
    for episodes in (1920, 4800, 9600):
        c = commit(m, episodes)
        with pytest.raises(ValueError):
            resume_cursor(m, c['arm'], c, 4)
    with pytest.raises(ValueError):
        resume_cursor(m, later['arm'], later, 2)


def test_tau_subset_temperature_uses_unchanged_absolute_trajectory_thresholds():
    assert TEMPERATURE['hold_episodes'] == 960
    assert TEMPERATURE['anneal_end_episodes'] == 4800
    for arm in ARMS:
        assert temperature(arm, 960) == ARMS[arm]['tau_start']
        assert temperature(arm, 4800) == temperature(arm, 7680) == .03
        if arm != 'T0_FIXED03':
            assert temperature(arm, 3840) > .03
        c = commit(manifest(), 3840, arm=arm)
        assert c['temperature_state'] == temperature_state(arm, 3840)


@pytest.mark.parametrize('bad', ['drop', 'substitute', 'reorder', 'old_repetitions',
    'old_budget', 'old_split', 'population', 'sha', 'unselected_full', 'ambiguous_full'])
def test_tau_subset_reject_changed_selection_or_budget(bad):
    m = manifest()
    if bad == 'drop':
        m['splits']['train_subset240'].pop()
    elif bad == 'substitute':
        m['splits']['train_subset240'][0] = m['splits']['train_full600'][-1]
    elif bad == 'reorder':
        m['splits']['train_subset240'].reverse()
    elif bad == 'old_repetitions':
        m['subset_training']['replicas_per_case'] = 1
    elif bad == 'old_budget':
        m['training']['episodes_per_data_epoch'] = 384
    elif bad == 'old_split':
        m['training']['training_split'] = 'train_full600'
    elif bad == 'population':
        m['subset_training']['population_weights']['ood_scale'] = 2.5
    elif bad == 'sha':
        m['subset_training']['cases_sha256'] = 'changed'
    elif bad == 'unselected_full':
        m['splits']['train_full600'].pop()
    elif bad == 'ambiguous_full':
        m = manifest(False)
        m['splits']['train_subset240'] = select_cases(m['splits']['train_full600'])
    with pytest.raises(ValueError):
        verify_data(m)
