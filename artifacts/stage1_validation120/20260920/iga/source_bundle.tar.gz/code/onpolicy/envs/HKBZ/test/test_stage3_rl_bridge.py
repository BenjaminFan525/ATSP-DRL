"""Bridge contracts and diagnostic fixtures. None are scientific performance evidence."""
import copy
import os
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from onpolicy.utils.stage3_rl_bridge import (
    ARMS, LATENT, BridgeQueue, actor_targets, distribution_weights, schedule, select_candidate,
)
from onpolicy.utils.stage3_research import WORKSPACE_ROOT, digest_json, read_json

ROOT = Path(__file__).resolve().parents[4]
FROZEN = ROOT/'artifacts/stage2_frozen/20260912/manifest.json'


def cases(counts=(48, 43, 5)):
    return [{'path': f'/fixture/{kind}/{i}', 'content_sha256': digest_json([kind, i]),
             'distribution': kind, 'profile': 'fixture'}
            for kind, count in zip(('iid', 'ood_stress', 'ood_scale'), counts) for i in range(count)]


def group(costs=(90., 100., 110., 120.)):
    return [dict(case_id='case', group_id='group', replica=i, seed=31+i, makespan=c,
        completed=True, behavior_deterministic=False, forced_replay=False,
        policy_updates=0, population_weight=1.) for i, c in enumerate(costs)]


def test_group_leave_one_out_and_risk_keeps_both_signs():
    rows = group()
    a, w, report = actor_targets(rows, 'P1_GROUP', {'case': 100.})
    np.testing.assert_allclose(a, [.2, 1/15, -1/15, -.2])
    assert abs(sum(a)) < 1e-12 and report['both_advantage_signs_retained']
    np.testing.assert_array_equal(w, np.ones(4))
    source, _, _ = actor_targets(rows, 'P0_SOURCE', {'case': 100.})
    np.testing.assert_allclose(source, [.1, 0, -.1, -.2])
    a, _, report = actor_targets(rows, 'P3_NATIVE_RISK', {'case': 100.})
    np.testing.assert_allclose(report['objective_costs'], [90., 100., 115., 135.])
    assert a[0] > 0 > a[-1] and abs(sum(a)) < 1e-12


@pytest.mark.parametrize('corruption', ['partial', 'replica', 'seed', 'case', 'version', 'greedy', 'forced', 'nan', 'weight'])
def test_group_rejects_invalid_behavior(corruption):
    rows = group()
    field, value = {'partial': ('completed', False), 'replica': ('replica', 0), 'seed': ('seed', 31),
        'case': ('case_id', 'other'), 'version': ('policy_updates', 1), 'greedy': ('behavior_deterministic', True),
        'forced': ('forced_replay', True), 'nan': ('makespan', float('nan')), 'weight': ('population_weight', 0)}[corruption]
    rows[-1][field] = value
    with pytest.raises(ValueError):
        actor_targets(rows, 'P2_NATIVE', {'case': 100.})


@pytest.mark.parametrize('world,counts,total', [(2, (48, 43, 5), 1536), (4, (480, 108, 12), 9600)])
def test_group_schedule_whole_groups_finite_budget_and_pairing(world, counts, total):
    selected = cases(counts)
    plan = schedule(selected, seed=13, epochs=4, world_size=world)
    assert plan == schedule(selected, seed=13, epochs=4, world_size=world)
    assert plan[-1]['training_episodes'] == total
    for batch in plan:
        assert len({len(s) for s in batch['shards']}) == 1
        for shard in batch['shards']:
            assert len(shard) <= 60 and len(shard) % 4 == 0
            for first in range(0, len(shard), 12):
                sub = shard[first:first+12]
                assert set(Counter(r['group_id'] for r in sub).values()) == {4}
            assert len({r['seed'] for r in shard}) == len(shard)
    assert len([b for b in plan if b['epoch_tail']]) == 4
    for epoch in range(1, 5):
        used = [r['case']['path'] for b in plan if b['epoch'] == epoch for shard in b['shards'] for r in shard]
        assert Counter(used) == Counter({r['path']: 4 for r in selected})


def test_group_fixed_population_weights():
    selected = cases((480, 108, 12))
    weights = distribution_weights(selected)
    assert weights == {'iid': .625, 'ood_stress': 2.5, 'ood_scale': 2.5}
    assert sum(weights[c['distribution']] for c in selected) == 600


def test_objective_hook_changes_actor_not_critic_and_preserves_legacy():
    from onpolicy.envs.HKBZ.test.test_stage3_b0_microbatch import toy
    class Captured(Exception):
        pass
    gradients = []
    for multiplier in (None, 1., 2.):
        runner, rows, _ = toy(4)
        if multiplier is not None:
            runner.stage3_actor_objective = lambda rs: ([.01*(100-r['makespan']) for r in rs], [multiplier]*len(rs))
        def capture(*args):
            gradients.append((runner.policy.ac.theta.grad.clone(), runner.policy.ac.critic_param.weight.grad.clone()))
            raise Captured()
        with pytest.raises(Captured):
            runner.update(rows, 'source', {r['case_id']: 100. for r in rows}, epochs=1,
                allow_multi_case=True, visit_balanced=True, gradient_callback=capture)
    torch.testing.assert_close(gradients[0][0], gradients[1][0], rtol=0, atol=0)
    torch.testing.assert_close(2*gradients[0][0], gradients[2][0])
    torch.testing.assert_close(gradients[0][1], gradients[2][1], rtol=0, atol=0)


def test_native_gaussian_density_and_exact_kl():
    from onpolicy.algorithms.utils.stage3_native_latent import gaussian_log_prob, gaussian_kl
    mean = torch.zeros(4, 3, 8, requires_grad=True)
    action = torch.ones_like(mean)*.1
    lp = gaussian_log_prob(action, mean, .1)
    assert lp.shape == (4, 3)
    torch.testing.assert_close(gaussian_kl(mean.detach(), mean+.01, .1), torch.full((4, 3), .04))
    (-lp.sum()).backward()
    assert mean.grad.abs().sum() > 0


def test_objective_group_wrapper_minibatches_keep_original_targets():
    from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy
    from onpolicy.runner.shared.stage3_rl_bridge_engine import GroupB0Engine
    from onpolicy.utils.stage3_ppo_minibatches import behavior_digest
    toy, rows, widths = minibatch_toy(24)
    runner = GroupB0Engine.__new__(GroupB0Engine)
    runner.__dict__.update(toy.__dict__)
    runner.bridge_arm, runner.representation, runner.execution_cache = 'P1_GROUP', 'F_PRIVATE', None
    runner.zero_update_batches = 0
    runner.assert_optimizer_ownership = lambda: None
    for i, row in enumerate(rows):
        row.update(case_id=f'case{i//4}', group_id=f'group{i//4}', seed=i,
                   replica=i % 4, population_weight=1.)
    costs = {r['case_id']: 100. for r in rows}
    expected, _, _ = actor_targets(rows, runner.bridge_arm, costs)
    digest = behavior_digest(rows)
    result = runner.update(rows, source_cost=costs, microbatch_size=12, optimizer_step_per_microbatch=True)
    np.testing.assert_array_equal(result['trajectory_advantages'], expected)
    assert len(result['bridge_objective']['groups']) == 6 and result['accepted_actor_steps'] > 0
    assert max(widths) == 12 and behavior_digest(rows) == digest
    assert not hasattr(runner, 'stage3_actor_objective')


def test_native_real_encoder_zero_mean_frozen_executor_and_exact_prefix(tmp_path):
    from onpolicy.runner.shared.stage3_rl_bridge_engine import NativeBridgeEngine
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.envs.HKBZ.environment import AircraftScheduleEnv
    device = os.environ.get('HKBZ_STAGE3_BRIDGE_DEVICE', 'cpu')
    native = NativeBridgeEngine(FROZEN, device=device, width=1, create_environments=False)
    baseline = B0Engine(FROZEN, 'F_PRIVATE', device=device, width=1, create_environments=False)
    baseline.configure_exploration(None)
    config = baseline.make_environment(WORKSPACE_ROOT/'onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train/case_0341', 1)
    env = AircraftScheduleEnv(config)
    try:
        graph, _, info = env.reset(seed=1)
        native.assert_optimizer_ownership()
        means, values, _ = native.policy.ac([graph], torch.zeros(1, 3, 64, device=device))
        assert torch.count_nonzero(means) == 0
        values.sum().backward()
        assert all(p.grad is None for p in native.policy.ac.encoder.parameters())
        native.policy.critic_optimizer.zero_grad(set_to_none=True)
        means.sum().backward()
        assert all(head.weight.grad.abs().sum() > 0 for head in native.policy.ac.mean_heads)
        assert not any(p.requires_grad for p in native.policy.ac.executor.parameters())
        native.policy.actor_optimizer.zero_grad(set_to_none=True)
        hidden = np.zeros((1, 104, 1, 64), np.float32)
        previous = np.full((1, 104, 3), -1, np.int64)
        steps = 32 if device.startswith('cuda') else 8
        with torch.no_grad():
            for _ in range(steps):
                inputs = baseline._inputs([graph], hidden, [info], previous)
                g, h, active, op, site, roles = inputs
                native.intervention.set_context(torch.zeros(1, 3, 8, device=device), g)
                before = baseline.policy.get_actions(g, h, active, op, site, agent_types=roles,
                    deterministic=True, return_decision_mask=True)
                after = native.executor_policy.get_actions(g, h, active, op, site, agent_types=roles,
                    deterministic=True, return_decision_mask=True)
                assert torch.equal(before[1], after[1])
                assert torch.equal(before[3], after[3])
                native.intervention.set_context(torch.full((1, 3, 8), .15, device=device), g)
                perturbed = native.executor_policy.get_actions(g, h, active, op, site, agent_types=roles,
                    deterministic=True, return_decision_mask=True)
                assert torch.isfinite(perturbed[1]).all()
                hidden, previous = before[3].cpu().numpy(), before[1].cpu().numpy()
                graph, _, _, info = env.step(previous[0])
        assert native.intervention.report == {'plane': 2, 'resource': 2}
    finally:
        env.close()
        baseline.close()
        native.close()


def native_toy():
    from onpolicy.runner.shared.stage3_rl_bridge_engine import NativeBridgeEngine
    from onpolicy.algorithms.utils.stage3_native_latent import gaussian_log_prob
    from onpolicy.utils.stage3_ppo_transaction import PPOStepTransaction
    from onpolicy.utils.stage3_local_exploration import exploration_config
    from onpolicy.utils.valuenorm import ValueNorm
    class Model(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.theta = torch.nn.Parameter(torch.zeros(3, 8))
            self.critics = torch.nn.Linear(1, 3)
            self.critic_param = self.critics
            self.executor = torch.nn.Linear(1, 1).requires_grad_(False)
            self.tau = .3
        def forward(self, graphs, hidden):
            x = torch.tensor(np.asarray(graphs), dtype=torch.float32)[:, None]
            mean = self.theta[None]*x[:, :, None]
            return mean, self.critics(x), hidden
    runner = NativeBridgeEngine.__new__(NativeBridgeEngine)
    model = Model()
    runner.policy = SimpleNamespace(ac=model, lr=1e-5,
        actor_optimizer=torch.optim.Adam([{'name': 'latent', 'params': [model.theta]}], lr=1e-5),
        critic_optimizer=torch.optim.Adam(model.critics.parameters(), lr=1e-4))
    runner.device, runner.bridge_arm = torch.device('cpu'), 'P2_NATIVE'
    runner.exploration = exploration_config({'roles': [0, 1, 2], 'taus': [.03]*3})
    runner.norms = {r: ValueNorm(1) for r in range(3)}
    runner.ppo_step_controller = PPOStepTransaction()
    runner.policy_updates, runner.zero_update_batches = 0, 0
    runner.source_metadata, runner.freeze_shared = {}, False
    runner.b0_sha256, runner.b0_manifest_sha256 = 'fixture-source', 'fixture-manifest'
    runner.update_metrics_sink = None
    rows = group()
    rng = np.random.default_rng(2)
    for i, row in enumerate(rows):
        row['exploration'] = copy.deepcopy(runner.exploration)
        row['states'] = []
        for step in range(10+i):
            action = rng.normal(size=(3, 8)).astype(np.float32)*.1
            row['states'].append({'graph': 1+i*.1, 'hidden': np.zeros((3, 64), np.float32),
                'action': action, 'old_mean': np.zeros((3, 8), np.float32),
                'old_logp': gaussian_log_prob(torch.tensor(action), torch.zeros(3, 8), .1).numpy(),
                'mask': np.ones(3), 'roles': np.arange(3), 'time': float(step)})
    return runner, rows


def test_native_update_resume_exact_and_rejects_stale(tmp_path):
    from onpolicy.utils.stage3_numerics import training_state
    from onpolicy.utils.stage3_distributed import state_digest
    runner, rows = native_toy()
    checkpoint = tmp_path/'before.pt'
    runner.save(checkpoint, protocol_sha256='fixture', next_group=0, elite_buffer={}, elite_usage={}, auxiliary_steps=0)
    assert runner.replay_metrics(rows)['max_logp_error'] < 1e-6
    result = runner.update(rows, source_cost={'case': 100.})
    assert result['accepted_actor_steps'] >= 1
    digest = state_digest(training_state(runner))
    with pytest.raises(ValueError, match='fresh complete'):
        runner.update(rows, source_cost={'case': 100.})
    runner.resume(checkpoint, protocol_sha256='fixture', exploration=runner.exploration)
    runner.update(rows, source_cost={'case': 100.})
    assert digest == state_digest(training_state(runner))


def test_queue_isolated_request_identity_and_forbidden_solver(tmp_path):
    from onpolicy.scripts.train.stage3_rl_bridge_worker import submit_evaluation, validate_request
    from onpolicy.utils.stage3_research import digest_file
    checkpoint = tmp_path/'synthetic.pt'
    checkpoint.write_bytes(b'diagnostic-fixture-not-a-checkpoint')
    m = {'root': str(tmp_path), 'manifest_sha256': 'manifest', 'comparison_sha256': 'comparison',
         'code': {'sha256': 'code'}, 'training': {'seed': 1}, 'splits': {s: cases()[:2] for s in
         ('train_full600', 'validation', 'tune')}, 'diagnostic': {'cases32': cases()[:2]},
         'source': {'sha256': digest_file(checkpoint)}}
    ids = submit_evaluation(m, checkpoint, 'P2_NATIVE', 768, 'screen', split='validation')
    q = BridgeQueue(tmp_path/'validator')
    request = read_json(q.root/'pending'/f'{ids[0]}.json')
    validate_request(m, request)
    assert q.identity(request) != q.identity({**request, 'arm': 'P3_NATIVE_RISK'})
    for kind in ('iga', 'solve', 'confirmation'):
        with pytest.raises(ValueError, match='forbidden'):
            validate_request(m, {**request, 'kind': kind})
    bad = {**request, 'cases': [{**request['cases'][0], 'path': '/sealed-confirmation'}]}
    bad['cases_sha256'] = digest_json(bad['cases'])
    bad['cache_key'] = q.identity(bad)
    with pytest.raises(ValueError, match='sealed'):
        validate_request(m, bad)
    # Independent consumers serialize only the claim scan, not evaluation.
    for index in range(20):
        q.submit({**request, 'request_id': f'concurrent_{index}'})
    with ThreadPoolExecutor(max_workers=8) as executor:
        claimed = list(executor.map(lambda _: BridgeQueue(q.root).claim(), range(30)))
    paths = [str(item[0]) for item in claimed if item is not None]
    assert len(paths) == len(set(paths)) == 21


def test_selection_greedy_risk_and_control_veto():
    safe = {'makespan': 100., 'gain_fraction': 0., 'completion_rate': 1.,
        'tail_makespan': 100., 'source_tail_makespan': 100., 'regression_over_5pct_fraction': 0.,
        'distributions': {'ood_stress': {'regression_fraction': 0.}},
        'profiles': {'stress_joint': {'regression_fraction': 0.}, 'resource_ood': {'regression_fraction': 0.}}}
    evaluations = {a: {s: copy.deepcopy(safe) for s in ('validation', 'tune')} for a in ARMS}
    assert select_candidate(evaluations) is None
    for s in ('validation', 'tune'):
        evaluations['P2_NATIVE'][s].update(makespan=99., gain_fraction=.01)
    assert select_candidate(evaluations) == 'P2_NATIVE'
    evaluations['P2_NATIVE']['tune']['profiles']['resource_ood']['regression_fraction'] = .006
    assert select_candidate(evaluations) is None


def test_group_diagnostic_separates_sampling_gains_from_rl():
    from onpolicy.utils.stage3_rl_bridge import diagnostic_summary
    rows = [{**r, 'profile': 'fixture', 'distribution': 'iid'} for r in group((90., 100., 110., 120.))]
    report = diagnostic_summary([{'arm': a, 'kind': 'sampling', 'cases': rows} for a in ('B0', 'P2_NATIVE')], {'case': 100.})
    assert report['arms']['P2_NATIVE']['best_of4']['gain_fraction'] == pytest.approx(.1)
    assert report['arms']['P2_NATIVE']['best_of4_vs_B0_best_of4']['gain_fraction'] == 0
    assert report['arms']['P2_NATIVE']['sampling_mean']['gain_fraction'] < 0
