import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from onpolicy.scripts.train import stop_stage1_p5_aligned_after_seed1 as guard


class Seed1StopTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.suite = Path(self.temporary.name)
        self.run_dir = self.suite / "formal_seed1/run1"
        self.spec = {"experiment": "test_formal_l2d_seed1", "run_dir": str(self.run_dir),
                     "required_evaluations": 9, "status_path": str(self.suite / "l2d.json")}
        self.state = {"phase": "formal_seed1", "pid": 100, "training_pid": 101,
                      "completed_phases": [], "phase_started_unix_time": 10}
        guard.atomic_json(Path(self.spec["status_path"]), self.state)
        self.child = {"pid": 101, "ppid": 100, "state": "R", "start_ticks": 42,
                      "cmdline": self.spec["experiment"]}
        self.controller = {"pid": 100, "state": "R", "start_ticks": 40}

    def final_files(self, pending=None, count=9, status="completed", checkpoint=True):
        guard.atomic_json(self.run_dir / "run_status.json", {"status": status})
        guard.atomic_json(self.run_dir / "async_evaluation/status.json", {
            "pending": [] if pending is None else pending, "completed": [{}] * count})
        if checkpoint:
            (self.run_dir / "models").mkdir(exist_ok=True)
            (self.run_dir / "models/checkpoint_Best.pt").write_bytes(b"test checkpoint")

    def outcome(self):
        with patch.object(guard, "trainer_wait_status", return_value=0):
            return guard.formal_outcome(self.spec, {**self.child, "state": "Z"})

    def test_freezes_only_scheduling_parent(self):
        with patch.object(guard, "controller_snapshot", side_effect=[
                self.controller, {**self.controller, "state": "T"}]), \
                patch.object(guard, "process_snapshot", return_value=self.child), \
                patch.object(guard.os, "kill") as kill:
            adopted = guard.freeze_formal(self.suite, "l2d", self.spec, self.state)
        kill.assert_called_once_with(100, signal.SIGSTOP)
        self.assertEqual(adopted["training_pid"], 101)

    def test_never_freezes_preparation(self):
        with patch.object(guard.os, "kill") as kill:
            with self.assertRaises(ValueError):
                guard.freeze_formal(self.suite, "l2d", self.spec,
                                    {**self.state, "phase": "initial_bc_seed1"})
        kill.assert_not_called()

    def test_rejects_wrong_parentage(self):
        with patch.object(guard, "controller_snapshot", return_value=self.controller), \
                patch.object(guard, "process_snapshot", return_value={**self.child, "ppid": 999}), \
                patch.object(guard.os, "kill") as kill:
            with self.assertRaisesRegex(RuntimeError, "not a child"):
                guard.freeze_formal(self.suite, "l2d", self.spec, self.state)
        kill.assert_not_called()

    def test_rejects_recycled_trainer(self):
        with patch.object(guard, "controller_snapshot", return_value=self.controller), \
                patch.object(guard, "process_snapshot", return_value=self.child), \
                patch.object(guard.os, "kill") as kill:
            with self.assertRaisesRegex(RuntimeError, "recycled"):
                guard.freeze_formal(self.suite, "l2d", self.spec, self.state,
                                    {"training_start_ticks": 41})
        kill.assert_not_called()

    def test_does_not_stop_trainer_still_draining_or_closing(self):
        self.final_files()
        self.assertIsNone(guard.formal_outcome(self.spec, self.child))

    def test_requires_all_evaluations(self):
        self.final_files(pending=[{"label": "epoch_8"}], count=8)
        self.assertFalse(self.outcome()[0])
        self.final_files(count=8)
        self.assertFalse(self.outcome()[0])

    def test_requires_best_checkpoint(self):
        self.final_files(checkpoint=False)
        self.assertFalse(self.outcome()[0])

    def test_requires_completed_status_and_zero_exit(self):
        self.final_files(status="failed")
        self.assertFalse(self.outcome()[0])
        self.final_files()
        with patch.object(guard, "trainer_wait_status", return_value=256):
            self.assertFalse(guard.formal_outcome(self.spec, {**self.child, "state": "Z"})[0])
        self.assertTrue(self.outcome()[0])

    def test_kernel_wait_status_is_read_without_reaping(self):
        child = subprocess.Popen([sys.executable, "-c", "raise SystemExit(7)"])
        try:
            os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOWAIT)
            self.assertEqual(guard.trainer_wait_status(child.pid), 7 << 8)
        finally:
            child.wait(timeout=5)

    def test_real_parent_freeze_keeps_child_running_and_prevents_next_seed(self):
        # Tiny CPU-only fixture, never a real experiment or systemd service.
        trainer_code = (
            "import pathlib,sys,time; p=pathlib.Path(sys.argv[2]); "
            "[(p.joinpath('ticks').write_text(str(i)),time.sleep(.05)) for i in range(30)]"
        )
        controller_code = (
            "import pathlib,subprocess,sys; p=pathlib.Path(sys.argv[2]); "
            "c=subprocess.Popen([sys.executable,'-c',sys.argv[3],sys.argv[1],str(p)]); "
            "p.joinpath('child_pid').write_text(str(c.pid)); c.wait(); "
            "p.joinpath('later_seed_started').write_text('unexpected')"
        )
        controller = subprocess.Popen([
            sys.executable, "-c", controller_code, self.spec["experiment"],
            str(self.suite), trainer_code,
        ])
        try:
            deadline = time.monotonic() + 5
            while not (self.suite / "ticks").exists():
                self.assertLess(time.monotonic(), deadline)
                time.sleep(.01)
            child_pid = int((self.suite / "child_pid").read_text())
            self.state.update(pid=controller.pid, training_pid=child_pid)
            guard.atomic_json(Path(self.spec["status_path"]), self.state)
            self.final_files()
            with patch.object(guard, "controller_snapshot",
                              side_effect=lambda *args: guard.process_snapshot(controller.pid)):
                adopted = guard.freeze_formal(self.suite, "l2d", self.spec, self.state)
            tick = int((self.suite / "ticks").read_text())
            time.sleep(.15)
            self.assertGreater(int((self.suite / "ticks").read_text()), tick)
            self.assertIn(guard.process_snapshot(controller.pid)["state"], {"T", "t"})
            self.assertIsNone(guard.formal_outcome(self.spec, guard.process_snapshot(child_pid)))
            while guard.process_snapshot(child_pid)["state"] != "Z":
                self.assertLess(time.monotonic(), deadline)
                time.sleep(.02)
            self.assertTrue(guard.formal_outcome(self.spec, guard.process_snapshot(child_pid))[0])
            self.assertFalse((self.suite / "later_seed_started").exists())

            def stop_fixture(_unit, pid):
                self.assertEqual(pid, controller.pid)
                os.kill(pid, signal.SIGTERM)
                os.kill(pid, signal.SIGCONT)
                controller.wait(timeout=5)

            with patch.object(guard, "stop_owned_service", side_effect=stop_fixture):
                guard.retire_lane(self.spec, "fixture.service", self.state, adopted,
                                  True, "seed1-only fixture", time.time())
            self.assertFalse((self.suite / "later_seed_started").exists())
        finally:
            if controller.poll() is None:
                os.kill(controller.pid, signal.SIGKILL)
                controller.wait(timeout=5)

    def test_service_ownership_is_checked_before_stop(self):
        with patch.object(guard.subprocess, "check_output", return_value="999\n"), \
                patch.object(guard.subprocess, "run") as stop:
            with self.assertRaisesRegex(RuntimeError, "ownership changed"):
                guard.stop_owned_service("test-l2d.service", 100)
        stop.assert_not_called()

    def test_success_records_only_seed1_and_preserves_validation_files(self):
        self.final_files()
        validation = (self.run_dir / "async_evaluation/status.json").read_bytes()
        with patch.object(guard, "stop_owned_service") as stop:
            result = guard.retire_lane(self.spec, "test-l2d.service", self.state,
                                       {"controller_pid": 100}, True, "user_scope", 1000)
        stop.assert_called_once_with("test-l2d.service", 100)
        lane = guard.read_json(Path(self.spec["status_path"]))
        self.assertEqual(result["state"], "completed")
        self.assertEqual(lane["completed_formal_seeds"], [1])
        self.assertEqual(lane["deferred_formal_seeds"], [2, 3])
        self.assertEqual(lane["completed_phases"][0]["phase"], "formal_seed1")
        self.assertEqual((self.run_dir / "async_evaluation/status.json").read_bytes(), validation)

    def test_fail_closed_backstop_and_policy_validation(self):
        tag = "test_suite"
        phases = [("canary", 1), ("initial_bc", 1), ("warm_ppo", 1),
                  ("departure_bc", 1), ("formal", 1), ("formal", 2), ("formal", 3)]
        lanes = []
        for method in guard.METHODS:
            records = []
            for phase, seed in phases:
                run_dir = self.suite / f"{phase}_{method}_{seed}/run1"
                records.append({"phase": phase, "seed": seed, "run_dir": str(run_dir)})
                if seed > 1:
                    guard.atomic_json(run_dir.parent / "DEFERRED_BY_USER.json", {
                        "policy": guard.POLICY_NAME, "method": method, "seed": seed, "run_tag": tag})
            lanes.append({"method": method, "phases": records})
        guard.atomic_json(self.suite / "manifest.json", {
            "scope": "stage1_p5_aligned_baselines", "run_tag": tag, "lanes": lanes})
        guard.atomic_json(self.suite / "execution_policy.json", {
            "policy": guard.POLICY_NAME, "allowed_formal_seeds": [1],
            "deferred_formal_seeds": [2, 3], "manifest_sha256": guard.digest(self.suite / "manifest.json")})
        prefix = "hkbz-p5b-" + hashlib.sha256(tag.encode()).hexdigest()[:10]
        guard.atomic_json(self.suite / "launch_record.json", {"units": [
            {"role": "lane", "method": method, "unit": f"{prefix}-{method}.service"}
            for method in guard.METHODS]})
        guard.load_policy(self.suite)
        later_run = Path(lanes[0]["phases"][-1]["run_dir"])
        self.assertTrue(later_run.parent.exists())  # frozen launcher's rejection condition
        self.assertFalse(later_run.exists())  # no training results were created
        later_run.mkdir()
        with self.assertRaisesRegex(ValueError, "reserved/unstarted"):
            guard.load_policy(self.suite)


if __name__ == "__main__":
    unittest.main()
