"""ENV60 is a new, checkpoint-bound execution recipe, not diagnostic training."""
import copy
from datetime import timedelta
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from onpolicy.envs.HKBZ.test.test_stage3_b0_minibatches import minibatch_toy, update
from onpolicy.envs.HKBZ.test.test_stage3_b0_throughput import continuation_fixture, cases, flatten
from onpolicy.utils.stage3_b0_protocol import identity
from onpolicy.utils.stage3_b0_throughput import (ENV36_BATCH_VERSION, ENV36_BATCH_AUTHORIZATION,
    ENV60_BATCH_VERSION, ENV60_BATCH_AUTHORIZATION, training_contract, continuation_plan,
    parent_manifest, epoch_owner, capacity_memory_pass)
from onpolicy.utils.stage3_batched_sampling import BATCHING_VERSION, SAMPLING_VERSION
from onpolicy.utils.stage3_research import atomic_json, digest_file, digest_json


def committed(parent, root, episodes, updates):
    root.mkdir()
    parent = copy.deepcopy(parent)
    parent['root'] = str(root)
    parent['manifest_sha256'] = identity(parent)
    atomic_json(root/'manifest.json', parent)
    atomic_json(root/'training_admission.json', {'passed':True})
    entries = []
    for rank in range(8):
        checkpoint = root/f'train/full/rank{rank}/models/episodes_{episodes:06d}.pt'
        checkpoint.parent.mkdir(parents=True)
        checkpoint.write_bytes(b'synthetic-not-model-weights')
        entries.append({'rank':rank, 'checkpoint':str(checkpoint), 'sha256':digest_file(checkpoint)})
    commit = root/f'train/commits/episodes_{episodes:06d}.json'
    atomic_json(commit, {'world_size':8, 'ranks':entries, 'training_episodes':episodes,
        'actual_actor_updates':updates, 'protocol_sha256':parent['manifest_sha256'],
        'schedule_sha256':digest_json(continuation_plan(parent)),
        'recipe_sha256':digest_file(root/'training_admission.json')})
    return parent, commit


def child_recipe(parent, commit, width):
    child = copy.deepcopy(parent)
    record = json.loads(commit.read_text())
    child['training'] = training_contract(width*8)
    child['throughput'].update(
        version=ENV60_BATCH_VERSION if width == 60 else ENV36_BATCH_VERSION,
        authorization=ENV60_BATCH_AUTHORIZATION if width == 60 else ENV36_BATCH_AUTHORIZATION,
        parent_manifest=str(Path(parent['root'])/'manifest.json'),
        parent_manifest_sha256=digest_file(Path(parent['root'])/'manifest.json'),
        resume_commit=str(commit), resume_commit_sha256=digest_file(commit),
        start_episodes=record['training_episodes'], start_actor_updates=record['actual_actor_updates'],
        global_batch=width*8, rollout_envs_per_rank=width, rollout_trajectories_per_rank=width,
        rollout_waves_per_rank=1, backward_trajectories_per_rank=12,
        gradient_accumulation_microbatches=1, optimizer_step_after_microbatches=False,
        optimizer_step_per_microbatch=True, optimizer_minibatches=width//12, optimizer_global_batch=96,
        release_environments_after_rollout=True, fresh_rollout_cadence_changed=True,
        environment_start_method='forkserver', optimizer_update_cadence_changed=False,
        stochastic_batching=BATCHING_VERSION, sampling_rng=SAMPLING_VERSION,
        sampling_forward_batch=width, greedy_inference_unchanged=True,
        parent_evidence={str(Path(parent['root'])/'training_admission.json'):
            digest_file(Path(parent['root'])/'training_admission.json')})
    if width == 60:
        child['resources'] = {'memory_high_gib':None, 'memory_max_gib':None, 'memory_swap_max_gib':0,
            'tasks_max':1024, 'memory_limit_authorization':ENV60_BATCH_AUTHORIZATION}
        child['throughput'].update(host_memory_limit_removed=True, capacity_memory_limit_gib=None)
    child['throughput']['schedule_sha256'] = digest_json(continuation_plan(child))
    return child


def parent36_fixture(tmp_path, episodes=960):
    original = continuation_fixture(tmp_path)
    first, commit = committed(original, tmp_path/'batch96', 608, 34)
    second = child_recipe(first, commit, 36)
    return committed(second, tmp_path/'env36', episodes, 42)


@pytest.mark.parametrize('start', [896, 960, 1920, 6720])
def test_env60_parent36_lineage_epoch_schedule_and_memory_contract(tmp_path, start):
    from onpolicy.utils.stage3_full_data import schedule
    parent, commit = parent36_fixture(tmp_path, start)
    child = child_recipe(parent, commit, 60)
    assert parent_manifest(child)['throughput']['version'] == ENV36_BATCH_VERSION
    plan = continuation_plan(child)
    assert flatten(plan) == flatten(schedule(cases(), child['training']['seed']))[start:]
    assert [b['training_episodes'] for b in plan if b['training_episodes'] % 960 == 0] == list(range((start//960+1)*960,7681,960))
    if start == 960:
        assert len(plan) == 14 and all(b['batch_size'] == 480 for b in plan)
        assert sum((b['batch_size']+95)//96 for b in plan)*2 == 140
    if start == 896:
        assert len(plan) == 15 and plan[0]['batch_size'] == 64
        assert sum((b['batch_size']+95)//96 for b in plan)*2 == 142
    for key,value in [('rollout_envs_per_rank',36), ('sampling_forward_batch',36),
                      ('optimizer_minibatches',3), ('backward_trajectories_per_rank',60),
                      ('capacity_memory_limit_gib',96), ('host_memory_limit_removed',False)]:
        bad = copy.deepcopy(child)
        bad['throughput'][key] = value
        with pytest.raises(ValueError, match='contract'):
            parent_manifest(bad)
    for key,value in [('memory_max_gib',108), ('memory_high_gib',96),
                      ('tasks_max',512), ('memory_swap_max_gib',135)]:
        bad = copy.deepcopy(child)
        bad['resources'][key] = value
        with pytest.raises(ValueError, match='contract'):
            parent_manifest(bad)


def test_env60_old_epoch_owner_and_unlimited_ram_are_explicit(tmp_path):
    parent, commit = parent36_fixture(tmp_path)
    child = child_recipe(parent, commit, 60)
    child['root'] = str(tmp_path/'env60')
    owner, record = epoch_owner(child,960)
    assert owner['manifest_sha256'] == parent['manifest_sha256']
    assert record == Path(parent['root'])/'epochs/e000960.json'
    assert epoch_owner(child,1920)[1] == Path(child['root'])/'epochs/e001920.json'
    assert capacity_memory_pass(child,122.)
    assert not capacity_memory_pass(child,float('nan'))
    assert not capacity_memory_pass(child,0.)
    assert capacity_memory_pass(parent,73.) and not capacity_memory_pass(parent,97.)


def test_env60_ten_independent_optimizer_steps():
    from onpolicy.utils.stage3_ppo_minibatches import behavior_digest
    runner, rows, widths = minibatch_toy(60)
    before = behavior_digest(rows)
    result = update(runner,rows)
    assert runner.policy_updates == 10
    assert [e['optimizer_minibatch'] for e in result['epochs']] == [1,2,3,4,5]*2
    assert len(result['ppo_epoch_reports']) == 2
    assert max(widths) == 12 and result['backward_microbatches'] == 5
    assert int(runner.policy.actor_optimizer.state[runner.policy.ac.theta]['step']) == 10
    assert all(e['actor_step_applied'] for e in result['epochs'])
    assert behavior_digest(rows) == before


def _env60_rank(rank, init_file):
    from onpolicy.utils.stage3_distributed import TrajectoryParallel
    torch.set_num_threads(1)
    dist.init_process_group('gloo',init_method='file://'+init_file,rank=rank,world_size=8,
                            timeout=timedelta(seconds=180))
    try:
        sync = TrajectoryParallel(device_packed=True)
        for count, steps in ((60,10),(8,2)):
            runner, rows, widths = minibatch_toy(count)
            for row in rows:
                row['makespan'] += rank
            result = update(runner,rows,distributed=sync)
            assert runner.policy_updates == len(result['epochs']) == steps
            assert max(widths) <= 12 and result['behavior_data_unchanged']
            sync.assert_replicas(runner)
            assert all(r['weights'] == pytest.approx([1/len(r['weights'])]*len(r['weights']))
                       for r in result['minibatch_objectives'])
    finally:
        dist.destroy_process_group()


def test_env60_real_eight_rank_ten_steps(tmp_path):
    mp.spawn(_env60_rank,args=(str(tmp_path/'store'),),nprocs=8,join=True)


def test_env60_batched_ragged_rollout():
    from onpolicy.envs.HKBZ.test.test_stage3_b0_reproduction import toy_runner
    from onpolicy.runner.shared.stage3_research_engine import ResearchEngine
    runner, widths = toy_runner(60)
    rows = ResearchEngine.rollout(runner,[{'path':f'/synthetic/{i}', 'profile':'test','distribution':'test'}
        for i in range(60)],list(range(60)),stochastic_batching=BATCHING_VERSION)
    assert widths == list(range(60,0,-1))
    assert runner.last_rollout_inference['max_forward_batch'] == 60
    assert all(r['sampling_rng'] == SAMPLING_VERSION for r in rows)


def test_env60_boundary_arming_never_uses_diagnostic_or_previous_group(tmp_path):
    from onpolicy.scripts.train.queue_stage3_b0_env60 import boundary_action, verify_commit
    parent, commit = parent36_fixture(tmp_path)
    assert boundary_action(parent,960,{'phase':'capacity','global_batch':2,'training_episodes':896}) == 'wait'
    assert boundary_action(parent,960,{'phase':'train','global_batch':1,'training_episodes':896,
                                     'event':'batch_committed'}) == 'wait'
    state = {'phase':'train','global_batch':2,'training_episodes':896,'event':'rollout'}
    assert boundary_action(parent,960,state) == 'arm'
    with pytest.raises(RuntimeError, match='passed'):
        boundary_action(parent,960,{**state,'global_batch':3})
    assert verify_commit(parent,commit,960)['training_episodes'] == 960
    row = json.loads(commit.read_text())['ranks'][7]
    Path(row['checkpoint']).write_bytes(b'tampered')
    with pytest.raises(ValueError, match='checkpoint'):
        verify_commit(parent,commit,960)


def test_env60_real_workers_and_batched_replay(tmp_path, record_property):
    root = Path(__file__).resolve().parents[4]
    records = {}
    for method in ('spawn','forkserver'):
        output = tmp_path/f'{method}.json'
        completed = subprocess.run([sys.executable,'-B',str(root/'onpolicy/scripts/train/probe_stage3_b0_env_pool.py'),
            '--width','60','--batched-inference','--start-method',method,'--output',str(output)],
            env={**os.environ,'CUDA_VISIBLE_DEVICES':''},cwd=root,capture_output=True,text=True,timeout=240)
        assert completed.returncode == 0, completed.stdout+'\n'+completed.stderr
        records[method] = json.loads(output.read_text())
        assert records[method]['live_environments'] == 60 and records[method]['actor_updates'] == 0
        assert records[method]['inference']['max_forward_batch'] == 60
        assert records[method]['inference']['forward_calls'] == 2
        assert records[method]['replay']['max_logp_error'] <= .002
        assert not records[method]['full_capacity_admission']
    assert records['spawn']['records'] == records['forkserver']['records']
    record_property('diagnostic_prefix_only',True)


def test_env60_transition_drains_then_launches_without_discarding_checkpoint(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from onpolicy.scripts.train import queue_stage3_b0_env60 as transition
    parent, commit = parent36_fixture(tmp_path,896)
    current, output, staging = Path(parent['root']), tmp_path/'candidate', tmp_path/'staging'
    staging.mkdir()
    staged = {'schema':transition.SCHEMA, 'authorization':ENV60_BATCH_AUTHORIZATION,
        'current_root':str(current),'output_root':str(output),'staging_root':str(staging),
        'target_episodes':896,'parent_manifest_sha256':digest_file(current/'manifest.json'),
        'python':sys.executable,'timeout_seconds':60,'poll_seconds':10,'plan_sha256':'fixture','files':{}}
    atomic_json(staging/'transition.json',staged)
    for rank in range(8):
        atomic_json(current/f'train/full/rank{rank}/result.json',{'paused':True,'training_episodes':896})
    states = iter([{'phase':'full_data_training','formal_training_started':True},
                   {'phase':'paused_at_commit','formal_training_started':True}])
    rank_path = current/'train/full/rank0/status.json'
    atomic_json(rank_path,{'phase':'train','global_batch':1,'training_episodes':608,'event':'update'})
    actual_read = transition.read_json
    monkeypatch.setattr(transition,'read_json',lambda p: next(states) if Path(p) == current/'status.json' else actual_read(p))
    monkeypatch.setattr(transition,'verify_staged',lambda p:None)
    monkeypatch.setattr(transition,'run_unit',lambda p:'fixture-'+Path(p).name)
    responses = iter([{'ActiveState':'active','MainPID':'1','ExecMainStatus':'0'}])
    def fake_service(unit):
        return next(responses, {'ActiveState':'inactive','MainPID':'0','ExecMainStatus':'0'})
    monkeypatch.setattr(transition,'service',fake_service)
    monkeypatch.setattr(transition,'queue',lambda m:SimpleNamespace(pending_count=lambda:0))
    monkeypatch.setattr(transition.time,'sleep',lambda seconds:None)
    calls = []
    def command(argv,**kwargs):
        calls.append(argv)
        if '--output' in argv:
            atomic_json(output/'manifest.json',{'code':{'files':{},'sha256':digest_json({})}})
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(transition.subprocess,'run',command)
    atomic_json(staging/'verification/receipt.json',{'passed':True})
    before = digest_file(commit)
    transition.run(staging/'transition.json')
    assert digest_file(commit) == before
    assert read_json_for_test(current/'PAUSE_AFTER_COMMIT')['target_episodes'] == 896
    assert (current/'validator/STOP').exists()
    assert len(calls) == 3 and calls[-1][0] == 'bash'
    assert '--env60-batched-minibatch12-uncapped' in calls[0]
    assert read_json_for_test(staging/'completed.json')['capacity_admission_still_required']


def read_json_for_test(path):
    return json.loads(path.read_text())


def test_env60_sealer_accepts_parameterized_passing_test_names():
    from onpolicy.scripts.train.stage3_b0_large_batch import required_tests_present
    assert required_tests_present({'test_lineage','test_sync'}, {'test_lineage[896]','test_lineage[960]','test_sync'})
    assert not required_tests_present({'test_lineage','test_sync'}, {'test_lineage[896]'})


def test_env60_rejects_a_different_parent_batch(tmp_path):
    original = continuation_fixture(tmp_path)
    original['training'] = training_contract(64)
    original['throughput'].update(global_batch=64, rollout_envs_per_rank=8, backward_trajectories_per_rank=8)
    original['throughput']['schedule_sha256'] = digest_json(continuation_plan(original))
    parent, commit = committed(original,tmp_path/'batch64',608,34)
    child = child_recipe(parent,commit,60)
    with pytest.raises(ValueError,match='admitted batch96'):
        parent_manifest(child)
