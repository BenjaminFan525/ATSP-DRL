"""B0-specific tests. Prefix fixtures are NEVER scientific trajectory evidence."""
import copy
import os
from pathlib import Path
from types import SimpleNamespace
from datetime import timedelta

import numpy as np
import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from onpolicy.utils.stage3_ppo_transaction import PPOStepTransaction, snapshot, cpu_copy
from onpolicy.utils.stage3_distributed import state_digest, TrajectoryParallel
from onpolicy.utils.stage3_research import WORKSPACE_ROOT, case_record

ROOT = Path(__file__).resolve().parents[4]
MANIFEST = ROOT / "artifacts/stage2_frozen/20260912/manifest.json"


def test_b0_private_exact_initialization_and_ready_frozen():
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    native = B0Engine(MANIFEST, "NATIVE", device="cpu", create_environments=False)
    private = B0Engine(MANIFEST, "F_PRIVATE", device="cpu", create_environments=False)
    try:
        expected = native.policy.ac.state_dict()
        actual = private.policy.ac.state_dict()
        for key, value in expected.items():
            if key.startswith("encoder."):
                for role in range(3):
                    assert torch.equal(value, actual[f"encoder.encoders.{role}." + key[len("encoder."):]])
            else:
                assert torch.equal(value, actual[key])
        for config in (None, {"roles": [0, 1, 2], "taus": [.1] * 3}):
            private.configure_exploration(config)
            assert not any(p.requires_grad for p in private.policy.ac.request_ready_head.parameters())
            private.assert_optimizer_ownership()
        assert [g["name"] for g in private.policy.actor_optimizer.param_groups][:3] == [
            "encoder_role0", "encoder_role1", "encoder_role2"]
        assert not private.policy.actor_optimizer.state
        assert not private.policy.critic_optimizer.state
        assert private.policy_updates == 0
        assert private.policy.ac.device_global_matching
        assert private.policy.ac.request_ready_policy_injection == "none"
    finally:
        native.close()
        private.close()


def fake_runner(kls):
    class Model(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.actor = torch.nn.Linear(1, 1)
            self.critic_param = torch.nn.Linear(1, 1)
    ac = Model()
    runner = SimpleNamespace(policy=SimpleNamespace(ac=ac, lr=.01,
        actor_optimizer=torch.optim.Adam(ac.actor.parameters(), lr=.01),
        critic_optimizer=torch.optim.Adam(ac.critic_param.parameters(), lr=.01)),
        norms={0: torch.nn.Linear(1, 1)}, policy_updates=0, device=torch.device("cpu"))
    def lr(value):
        runner.policy.lr = value
        for group in runner.policy.actor_optimizer.param_groups:
            group["lr"] = value
    runner.set_actor_lr = lr
    values = iter(kls)
    def replay(*args, **kwargs):
        kl = next(values)
        return {"kl": kl / 2, "roles": {"0": {"kl": kl, "decisions": 1}}}
    runner.replay_metrics = replay
    ac.actor(torch.ones(1, 1)).sum().backward()
    ac.critic_param(torch.ones(1, 1)).sum().backward()
    return runner


def stats():
    return {"kl": 0., "gradient_norm_by_group": {"actor": 1.}, "actor_gradient_norm": 1.}


def test_transaction_rejection_restores_every_state():
    runner = fake_runner([.09, .08, .07, 0.])
    before = snapshot(runner)
    events = []
    runner.update_metrics_sink = events.append
    result = PPOStepTransaction().step(runner, [], stats())
    after = snapshot(runner)
    for key in ("model", "critic", "norms", "updates", "torch", "numpy", "python"):
        assert state_digest(before[key]) == state_digest(after[key])
    assert not runner.policy.actor_optimizer.state
    assert runner.policy_updates == 0 and runner.policy.lr == .01 / 8
    assert len(events) == 3 and not result["actor_step_applied"]
    assert result["rolled_back_attempts"] == 3


def test_transaction_retry_keeps_exactly_one_adam_step_and_persists_failure():
    runner = fake_runner([.06, .01])
    events = []
    runner.update_metrics_sink = events.append
    result = PPOStepTransaction().step(runner, [], stats())
    assert result["actor_step_applied"] and runner.policy_updates == 1
    assert result["accepted_actor_lr"] == .005
    assert [r["accepted"] for r in events] == [False, True]
    for optimizer in (runner.policy.actor_optimizer, runner.policy.critic_optimizer):
        assert all(int(s["step"]) == 1 for s in optimizer.state.values())


def test_transaction_soft_stop_is_not_experiment_failure():
    runner = fake_runner([.03])
    result = PPOStepTransaction().step(runner, [], {**stats(), "kl": .021})
    assert result["stop_reason"] == "soft_kl_before_step" and runner.policy_updates == 0


def test_transaction_technical_failure_restores_without_retry():
    runner = fake_runner([float("nan")])
    before = snapshot(runner)
    with pytest.raises(FloatingPointError):
        PPOStepTransaction().step(runner, [], stats())
    assert state_digest(before) == state_digest(snapshot(runner))


def queue_fixture(tmp_path):
    from onpolicy.utils.stage3_b0_protocol import EVALUATION, B0_SHA
    from onpolicy.utils.stage3_research import digest_file, digest_json
    checkpoint = tmp_path / "fixture.pt"
    checkpoint.write_bytes(b"synthetic-queue-only-not-a-model")
    case = {"path": str(tmp_path / "case"), "content_sha256": "casefixture", "name": "case"}
    m = {"root": str(tmp_path), "resources": {"validator_queue": str(tmp_path / "validator")},
         "manifest_sha256": "private-protocol", "comparison_sha256": "comparison",
         "code": {"sha256": "source-code"}, "splits": {s: [case] for s in ("train_full600", "validation", "tune", "confirmation")},
         "source": {"sha256": B0_SHA}, "evaluation": EVALUATION,
         "diagnostic": {"mechanism_cases": [case]}}
    lock = {"arm": "C_PRIVATE", "protocol_sha256": m["manifest_sha256"], "comparison_sha256": m["comparison_sha256"],
            "checkpoint": str(checkpoint), "checkpoint_sha256": digest_file(checkpoint), "training_episodes": 960,
            "locked_before_confirmation": True}
    return m, checkpoint, lock


def test_b0_queue_binds_request_kind_and_rejects_tampering(tmp_path):
    from onpolicy.utils.stage3_b0_protocol import submit, queue, validate_request, B0Queue
    from onpolicy.utils.stage3_research import read_json
    m, checkpoint, _ = queue_fixture(tmp_path)
    request_id = submit(m, checkpoint, "C_PRIVATE", 960, "F_PRIVATE", split="validation")
    request = read_json(queue(m).root / "pending" / (request_id + ".json"))
    validate_request(m, request)
    assert B0Queue.identity(request) != B0Queue.identity({**request, "kind": "mechanism"})
    with pytest.raises(ValueError, match="identity corrupted"):
        validate_request(m, {**request, "training_exploration": {"taus": [.9] * 3}})
    with pytest.raises(ValueError, match="impersonate"):
        submit(m, checkpoint, "B_SHARED", 960, "F_SHARED", split="validation")


def test_confirmation_requires_two_immutable_locks(tmp_path):
    from onpolicy.utils.stage3_b0_protocol import submit, queue, validate_request
    from onpolicy.utils.stage3_research import atomic_json, digest_file, read_json
    m, checkpoint, lock = queue_fixture(tmp_path)
    local = tmp_path / "selection_locked.json"
    atomic_json(local, lock)
    with pytest.raises(FileNotFoundError):
        submit(m, checkpoint, "C_PRIVATE", 960, "F_PRIVATE", split="confirmation")
    peer = tmp_path / "peer_selection.json"
    atomic_json(peer, {**lock, "arm": "B_SHARED"})
    atomic_json(tmp_path / "confirmation_open.json", {"comparison_sha256": m["comparison_sha256"], "locks": {
        arm: {"path": str(path), "sha256": digest_file(path)} for arm, path in (("C_PRIVATE", local), ("B_SHARED", peer))}})
    request_id = submit(m, checkpoint, "C_PRIVATE", 960, "F_PRIVATE", split="confirmation")
    request = read_json(queue(m).root / "pending" / (request_id + ".json"))
    validate_request(m, request)
    atomic_json(peer, {**lock, "arm": "B_SHARED", "training_episodes": 1920})
    with pytest.raises(ValueError, match="selection changed"):
        validate_request(m, request)


def test_mechanism_diagnostic_remains_training_only(tmp_path):
    from onpolicy.utils.stage3_b0_protocol import submit, validate_request, MECHANISM
    from onpolicy.utils.stage3_research import atomic_json, digest_file
    m, checkpoint, _ = queue_fixture(tmp_path)
    path = tmp_path / "sampling_admission.json"
    atomic_json(path, {"selected_tau": .03})
    diagnostic = {"recipe": MECHANISM, "sampling_sha256": digest_file(path), "selected_tau": .03}
    with pytest.raises(ValueError, match="train-only"):
        submit(m, checkpoint, "C_PRIVATE", 960, "F_PRIVATE", split="validation", kind="mechanism", diagnostic=diagnostic)
    submit(m, checkpoint, "C_PRIVATE", 960, "F_PRIVATE", split="train_full600", kind="mechanism", diagnostic=diagnostic)


def test_historical_ready_and_matching_guards_remain_opt_in():
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.algorithms.utils.stage3_encoder import install_encoder
    from onpolicy.utils.stage3_local_exploration import RoleExploration
    runner = B0Engine(MANIFEST, "NATIVE", device="cpu", create_environments=False)
    try:
        with pytest.raises(ValueError):
            install_encoder(runner.policy, "F_PRIVATE")
        with pytest.raises(ValueError):
            RoleExploration(runner.policy.ac, "J")
    finally:
        runner.close()


def _eight_rank(rank, init_file):
    dist.init_process_group("gloo", init_method="file://" + init_file, rank=rank, world_size=8,
                            timeout=timedelta(seconds=120))
    try:
        sync = TrajectoryParallel(device_packed=True)
        weights, denominator = sync.objective_weights([f"case{i}" for i in range(4)], 4, visit_balanced=True)
        actor = torch.nn.Parameter(torch.tensor([.2]))
        critic = torch.nn.Parameter(torch.tensor([.4]))
        x = torch.arange(rank, 32, 8, dtype=torch.float32)
        (actor * x * torch.tensor(weights)).sum().backward()
        (critic.square() * 4 / denominator).backward()
        policy = SimpleNamespace(actor_optimizer=torch.optim.Adam([actor]), critic_optimizer=torch.optim.Adam([critic]))
        info = dict(kl=0., clip=0., logp=0., decisions=4., mask_mismatch=0)
        sync.synchronize_update(policy, info)
        assert torch.allclose(actor.grad, torch.tensor([15.5]))
        assert torch.allclose(critic.grad, torch.tensor([.8]))
    finally:
        dist.destroy_process_group()


def test_real_eight_rank_b0_visit_mean(tmp_path):
    mp.spawn(_eight_rank, args=(str(tmp_path / "store"),), nprocs=8, join=True)


def test_b0_gpu_prefix_cache_resume_and_gradient_isolation(tmp_path):
    if os.environ.get("HKBZ_STAGE3_GPU_TEST") != "1":
        pytest.skip("requires explicitly coordinated GPU")
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.utils.stage3_numerics import training_state
    from onpolicy.scripts.train.stage3_local_worker import nested_close
    runner = B0Engine(MANIFEST, "F_PRIVATE", width=1)
    original_call = runner.pool.call
    def prefix_fixture(commands):
        result = original_call(commands)
        for i, command, _ in commands:
            if command == "summary":
                result[i] = {**result[i], "completed": True, "synthetic_prefix_fixture": True}
        return result
    runner.pool.call = prefix_fixture
    try:
        case = case_record(WORKSPACE_ROOT / "onpolicy/envs/HKBZ/dataset/fjsp_v3_t600_v120_test60/train/case_0341")
        # The first16 steps of this real case contain no trainable transporter
        # choice. A bounded longer prefix exercises all three role pathways.
        trajectory = runner.rollout([case], [2026091201], retain=True, max_steps=128, likelihood_audit=True)[0]
        assert trajectory["synthetic_prefix_fixture"]
        from onpolicy.utils.stage3_b0_diagnostics import likelihood_record
        assert likelihood_record(trajectory) == trajectory["likelihood"]
        assert runner.replay_metrics([trajectory])["max_logp_error"] < .002
        observed_roles = set()
        for state in trajectory["states"]:
            roles = state["roles"]
            for role in range(3):
                selected = (roles == role) & state["mask"].astype(bool)
                if role in observed_roles or not selected.any():
                    continue
                from onpolicy.runner.shared.stage3_research_engine import gradient_mode
                gradient_mode(runner.policy.ac)
                runner.policy.actor_optimizer.zero_grad(set_to_none=True)
                lp, _, _ = runner.policy.evaluate_actions([state["graph"]], state["hidden"][None],
                    state["active"][None], state["op"][None], state["site"][None], state["action"][None],
                    agent_types=roles[None], return_decision_mask=True)
                lp.reshape(-1)[torch.as_tensor(selected, device=runner.device)].sum().backward()
                for other, encoder in enumerate(runner.policy.ac.encoder.encoders):
                    active = any(p.grad is not None and bool(p.grad.abs().sum()) for p in encoder.parameters())
                    assert active == (role == other)
                observed_roles.add(role)
        assert observed_roles == {0, 1, 2}
        group = [dict(trajectory, case_id=f"fixture{i}", states=trajectory["states"][:16-i%3]) for i in range(4)]
        costs = {t["case_id"]: t["makespan"] + 30 for t in group}
        path = tmp_path / "start.pt"
        runner.save(path, protocol_sha256="fixture", next_group=0, elite_buffer={}, elite_usage={}, auxiliary_steps=0)
        cache, exploration = runner.execution_cache, copy.deepcopy(runner.exploration)
        states = []
        for optimized in (False, True):
            runner.resume(path, protocol_sha256="fixture", exploration=exploration)
            runner.execution_cache = cache if optimized else None
            result = runner.update(group, "source", costs)
            assert result["accepted_actor_steps"] >= 1
            states.append(cpu_copy(training_state(runner)))
        assert nested_close(states[0], states[1])
        assert result["execution_cache"]["critic_reuses"] > 0
        assert result["execution_cache"]["frozen_hits"] == 0
    finally:
        runner.close()


def test_b0_gpu_native_complete_release_replay():
    if os.environ.get("HKBZ_STAGE3_GPU_TEST") != "1":
        pytest.skip("requires explicitly coordinated GPU")
    from onpolicy.runner.shared.stage3_b0_engine import B0Engine
    from onpolicy.utils.stage3_research import read_json
    case = case_record(WORKSPACE_ROOT / "onpolicy/envs/HKBZ/dataset/fjsp_v3_resource_joint_eval_s20260811/joint/tune/case_0044")
    released = read_json(MANIFEST.parent / "results/b0_source_evaluation.json")["cases"]
    expected = next(r for r in released if r["case_sha256"] == case["case_sha256"])
    runner = B0Engine(MANIFEST, "NATIVE", width=1)
    try:
        row = runner.rollout([case], [1], deterministic=True)[0]
        assert row["completed"] and not row.get("cycle_terminated")
        assert row["makespan"] == pytest.approx(expected["makespan"], abs=1e-6)
    finally:
        runner.close()
