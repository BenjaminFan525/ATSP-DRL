"""Opt-in grouped AR PPO and native latent PPO. Historical runners are unchanged."""
import copy
import math
from pathlib import Path
import time
from types import SimpleNamespace

import numpy as np
import torch

from onpolicy.runner.shared.stage3_b0_engine import B0Engine, HISTORY, GREEDY_BATCHING
from onpolicy.runner.shared.stage3_research_engine import ResearchEngine, EnvironmentPool
from onpolicy.utils.stage3_rl_bridge import ARMS, LATENT, actor_targets
from onpolicy.utils.stage3_ppo_transaction import PPOStepTransaction, snapshot, restore, max_role_kl
from onpolicy.utils.stage3_ppo_minibatches import RolloutBatchLease
from onpolicy.utils.stage3_research import digest_file
from onpolicy.utils.stage3_local_exploration import exploration_config
from onpolicy.utils.valuenorm import ValueNorm


class GroupB0Engine(B0Engine):
    def __init__(self, *args, arm='P0_SOURCE', arm_spec=None, **kwargs):
        spec = ARMS.get(arm) if arm_spec is None else arm_spec
        if spec is None or spec['native']:
            raise ValueError('AR engine requires a source/group arm')
        self.bridge_arm, self.bridge_spec = arm, copy.deepcopy(spec)
        super().__init__(*args, **kwargs)

    def update(self, trajectories, mode='source', source_cost=None, **kwargs):
        if mode != 'source' or kwargs.get('microbatch_size', 12) % 4:
            raise ValueError('Grouped PPO requires source mode and whole-group optimizer minibatches')
        advantages, weights, audit = actor_targets(trajectories, self.bridge_arm, source_cost,
            arm_spec=getattr(self, 'bridge_spec', None))
        targets = {id(t): (a, w) for t, a, w in zip(trajectories, advantages, weights)}
        def objective(rows):
            if any(id(t) not in targets for t in rows):
                raise ValueError('Objective target escaped the original on-policy group')
            return ([targets[id(t)][0] for t in rows], [targets[id(t)][1] for t in rows])
        self.stage3_actor_objective = objective
        try:
            result = super().update(trajectories, mode, source_cost, **kwargs)
        finally:
            del self.stage3_actor_objective
        result.update(bridge_objective=audit, trajectory_advantages=advantages.tolist(),
                      population_weights=weights.tolist(), baseline_mode=audit['advantage_mode'],
                      positive_advantage_fraction=float(np.mean(advantages > 0)))
        return result

    def save(self, path, **metadata):
        return super().save(path, bridge_arm=self.bridge_arm, **metadata)

    def load(self, checkpoint):
        payload = torch.load(checkpoint, map_location='cpu', weights_only=False)
        if payload.get('bridge_arm') != self.bridge_arm:
            raise ValueError('AR checkpoint belongs to a different bridge arm')
        return super().load(checkpoint)


class NativeBridgeEngine(ResearchEngine):
    def __init__(self, frozen_manifest, *, arm='P2_NATIVE', width=60, device='cuda:0',
                 actor_lr=1e-5, create_environments=True, start_method='forkserver'):
        from onpolicy.algorithms.utils.stage3_native_latent import NativeLatentActor, NativeScoreIntervention
        if arm not in ARMS or not ARMS[arm]['native']:
            raise ValueError('Native engine requires the native/risk arm')
        self.bridge_arm, self.latent_config = arm, dict(LATENT)
        base = B0Engine(frozen_manifest, 'F_PRIVATE', width=width, device=device,
                        cache_mib=0, actor_lr=actor_lr, create_environments=False)
        base.configure_exploration(None)
        self.executor_policy = base.policy
        self.device, self.source_metadata = base.device, base.source_metadata
        self.b0_sha256, self.b0_manifest_sha256 = base.b0_sha256, base.b0_manifest_sha256
        self.environment_factory, self.environment_overrides = base.make_environment, base.environment_overrides
        self.frozen_manifest = base.frozen_manifest
        self.width, self.environment_start_method = width, start_method
        self.pool = EnvironmentPool(width, start_method=start_method) if create_environments else None
        actor = NativeLatentActor(base.policy.ac, self.latent_config)
        groups = []
        for role in range(3):
            groups.append({'name': f'encoder_role{role}', 'params': list(actor.encoder.encoders[role].parameters()),
                           'lr': actor_lr, 'lr_scale': 1.})
            groups.append({'name': f'latent_role{role}', 'params': list(actor.recurrent[role].parameters()) +
                list(actor.mean_heads[role].parameters()), 'lr': actor_lr*[.25, 1., .5][role],
                'lr_scale': [.25, 1., .5][role]})
        self.policy = SimpleNamespace(ac=actor, lr=actor_lr,
            actor_optimizer=torch.optim.Adam(groups, eps=base.policy.opti_eps),
            critic_optimizer=torch.optim.Adam(actor.critics.parameters(), lr=1e-4, eps=base.policy.opti_eps))
        self.intervention = NativeScoreIntervention(actor.executor)
        self.policy_updates, self.zero_update_batches = 0, 0
        self.freeze_shared, self.semantic_history = False, False
        self.exploration = exploration_config({'roles': [0, 1, 2], 'taus': [.03]*3})
        self.norms = {r: ValueNorm(1, device=self.device) for r in range(3)}
        self.ppo_step_controller = PPOStepTransaction()
        self.update_metrics_sink = None
        self.release_environments_after_rollout = False
        self.last_decision_stats, self.last_rollout_inference = {}, {}
        self.checkpoint = base.checkpoint
        self.assert_optimizer_ownership()

    def configure_exploration(self, config):
        self.exploration = exploration_config(config)
        if self.exploration is None:
            raise ValueError('Native latent policy requires its explicit stochastic contract')

    def assert_optimizer_ownership(self):
        parameters = [p for opt in (self.policy.actor_optimizer, self.policy.critic_optimizer)
                      for g in opt.param_groups for p in g['params']]
        if len(parameters) != len({id(p) for p in parameters}):
            raise ValueError('Native optimizer parameter alias')
        if {id(p) for p in self.policy.ac.parameters() if p.requires_grad} != {id(p) for p in parameters}:
            raise ValueError('Native trainable parameter ownership mismatch')
        if any(p.requires_grad for p in self.policy.ac.executor.parameters()):
            raise ValueError('Native B0 executor must remain frozen')

    @torch.no_grad()
    def rollout(self, cases, seeds, *, deterministic=False, retain=False, heartbeat=None,
                max_steps=4000, **kwargs):
        from onpolicy.algorithms.utils.stage3_native_latent import gaussian_log_prob
        if kwargs or not 0 < len(cases) <= self.width or len(cases) != len(seeds):
            raise ValueError('Unsupported native rollout arguments or batch')
        self.policy.ac.eval()
        count, agents = len(cases), 104
        initial = self.pool.call([(i, 'reset', {**self.environment_factory(c['path'], seed),
            '_stage3_diagnostics': True}) for i, (c, seed) in enumerate(zip(cases, seeds))])
        obs, infos = [initial[i][0] for i in range(count)], [initial[i][2] for i in range(count)]
        hidden = np.zeros((count, agents, 1, 64), np.float32)
        previous = np.full((count, agents, 3), -1, np.int64)
        latent_hidden = torch.zeros(count, 3, 64, device=self.device)
        coefficients = torch.zeros(count, 3, LATENT['dimension_per_role'], device=self.device)
        randoms = [np.random.default_rng(int(s)) for s in seeds]
        live = np.ones(count, dtype=bool)
        rows = [{'case_id': c['path'], 'profile': c['profile'], 'distribution': c['distribution'],
            'seed': int(seed), 'states': [], 'actions': [], 'latent_samples': [],
            'exploration': copy.deepcopy(self.exploration), 'policy_updates': self.policy_updates,
            'behavior_deterministic': deterministic, 'forced_replay': False, 'history': HISTORY,
            'source_sha256': self.b0_sha256, 'decoder': 'native_latent_mean' if deterministic else 'native_latent_sample',
            'inference_batching': GREEDY_BATCHING if deterministic else 'live_batch_native_latent_v1'}
            for c, seed in zip(cases, seeds)]
        timing = {'forward_calls': 0, 'graph_forwards': 0, 'max_forward_batch': 0,
                  'inference_and_transfer_seconds': 0., 'environment_step_seconds': 0.}
        for step in range(max_steps):
            indices = np.flatnonzero(live).tolist()
            if not indices:
                break
            groups = [[i] for i in indices] if deterministic else [indices]
            actions_to_step = {}
            begin = time.perf_counter()
            for group in groups:
                if step % LATENT['window_events'] == 0:
                    before_h = latent_hidden[group].clone()
                    means, values, new_h = self.policy.ac([obs[i] for i in group], before_h)
                    noise = torch.as_tensor(np.stack([randoms[i].normal(size=(3, LATENT['dimension_per_role']))
                        for i in group]), device=self.device, dtype=means.dtype) if not deterministic else torch.zeros_like(means)
                    z = means + LATENT['sigma']*noise
                    lp = gaussian_log_prob(z, means, LATENT['sigma'])
                    coefficients[group] = z
                    latent_hidden[group] = new_h
                    for j, i in enumerate(group):
                        sample = {'event': step, 'time': float(infos[i]['env_total_time']),
                                  'z': z[j].cpu().numpy(), 'mean': means[j].cpu().numpy(),
                                  'old_logp': lp[j].cpu().numpy()}
                        rows[i]['latent_samples'].append(sample)
                        if retain:
                            rows[i]['states'].append({'graph': obs[i], 'hidden': before_h[j].cpu().numpy(),
                                'action': sample['z'], 'old_mean': sample['mean'], 'old_logp': sample['old_logp'],
                                'mask': np.ones(3, np.float32), 'roles': np.arange(3),
                                'value': values[j].cpu().numpy(), 'time': sample['time']})
                graph, h, active, op, site, roles = self._inputs(
                    [obs[i] for i in group], hidden[group], [infos[i] for i in group], previous[group])
                self.intervention.set_context(coefficients[group], graph)
                _, actions, _, new_h, _ = self.executor_policy.get_actions(graph, h, active, op, site,
                    agent_types=roles, deterministic=True, return_decision_mask=True)
                actions = actions.cpu().numpy().astype(np.int64)
                if actions.shape[-1] == 2:
                    actions = np.concatenate((actions, np.full((*actions.shape[:-1], 1), -1, np.int64)), -1)
                for j, i in enumerate(group):
                    rows[i]['actions'].append(actions[j].tolist())
                    hidden[i], previous[i] = new_h[j].cpu().numpy(), actions[j]
                    actions_to_step[i] = actions[j]
                timing['forward_calls'] += 1
                timing['graph_forwards'] += len(group)
                timing['max_forward_batch'] = max(timing['max_forward_batch'], len(group))
            timing['inference_and_transfer_seconds'] += time.perf_counter()-begin
            begin = time.perf_counter()
            results = self.pool.call([(i, 'step', actions_to_step[i]) for i in indices])
            timing['environment_step_seconds'] += time.perf_counter()-begin
            for i in indices:
                obs[i], _, done, infos[i] = results[i]
                live[i] = not np.all(done)
            if heartbeat and step % 50 == 0:
                heartbeat.update(event='native_rollout', rollout_step=step,
                    live_trajectories=int(live.sum()), inference=timing)
        summaries = self.pool.call([(i, 'summary', None) for i in range(count)])
        for i, row in enumerate(rows):
            row.update(summaries[i])
            row['latent_decisions'] = len(row['latent_samples'])*3
            if not row['completed'] or row.get('cycle_terminated'):
                raise RuntimeError(f'Incomplete native trajectory: {row["case_id"]}')
        self.last_rollout_inference = timing
        return rows

    @torch.no_grad()
    def replay_metrics(self, trajectories, heartbeat=None, *, distributed=None):
        from onpolicy.algorithms.utils.stage3_native_latent import gaussian_log_prob, gaussian_kl
        self.policy.ac.eval()
        tensor = lambda x: torch.as_tensor(np.asarray(x), device=self.device, dtype=torch.float32)
        hidden = tensor([t['states'][0]['hidden'] for t in trajectories])
        sums = {r: {'decisions': 0, 'kl_sum': 0., 'nll_sum': 0., 'max_logp_error': 0.} for r in range(3)}
        for step in range(max(len(t['states']) for t in trajectories)):
            ids = [i for i, t in enumerate(trajectories) if step < len(t['states'])]
            states = [trajectories[i]['states'][step] for i in ids]
            mean, _, next_h = self.policy.ac([s['graph'] for s in states], hidden[ids])
            hidden[ids] = next_h
            lp = gaussian_log_prob(tensor([s['action'] for s in states]), mean, LATENT['sigma'])
            kl = gaussian_kl(tensor([s['old_mean'] for s in states]), mean, LATENT['sigma'])
            diff = (lp-tensor([s['old_logp'] for s in states])).abs()
            if not torch.isfinite(lp).all() or not torch.isfinite(kl).all():
                raise FloatingPointError('Nonfinite Gaussian likelihood')
            for r in range(3):
                sums[r]['decisions'] += len(ids)
                sums[r]['kl_sum'] += float(kl[:, r].sum())
                sums[r]['nll_sum'] -= float(lp[:, r].sum())
                sums[r]['max_logp_error'] = max(sums[r]['max_logp_error'], float(diff[:, r].max()))
            if heartbeat and step % 25 == 0:
                heartbeat.update(event='native_likelihood_replay', replay_window=step)
        if distributed is not None:
            sums = distributed.replay_sums(sums)
        n = sum(r['decisions'] for r in sums.values())
        return {'kl': sum(r['kl_sum'] for r in sums.values())/n,
            'nll': sum(r['nll_sum'] for r in sums.values())/n,
            'max_logp_error': max(r['max_logp_error'] for r in sums.values()),
            'kl_measure': 'exact_gaussian_per_role_window',
            'roles': {str(k): {**r, 'kl': r['kl_sum']/r['decisions']} for k, r in sums.items()}}

    def _update_group(self, rows, targets, heartbeat, sync, chunk):
        from onpolicy.algorithms.utils.stage3_native_latent import gaussian_log_prob, gaussian_kl
        tensor = lambda x: torch.as_tensor(np.asarray(x), device=self.device, dtype=torch.float32)
        self.policy.ac.eval()
        self.policy.actor_optimizer.zero_grad(set_to_none=True)
        self.policy.critic_optimizer.zero_grad(set_to_none=True)
        hidden = tensor([t['states'][0]['hidden'] for t in rows])
        decisions = sum(3*len(t['states']) for t in rows)
        weights, denom = (np.full(len(rows), 1/len(rows)), float(decisions)) if sync is None else sync.objective_weights(
            [t['case_id'] for t in rows], decisions, visit_balanced=True)
        advantage = tensor([targets[id(t)][0] for t in rows])
        weights = tensor(weights * np.asarray([targets[id(t)][1] for t in rows]))
        actor_loss = critic_loss = None
        stats = dict(kl=0., clip=0., logp=0., decisions=0., mask_mismatch=0)
        steps = max(len(t['states']) for t in rows)
        for step in range(steps):
            ids = [i for i, t in enumerate(rows) if step < len(t['states'])]
            states = [rows[i]['states'][step] for i in ids]
            mean, values, next_h = self.policy.ac([s['graph'] for s in states], hidden[ids])
            hidden = hidden.index_copy(0, torch.tensor(ids, device=self.device), next_h)
            lp = gaussian_log_prob(tensor([s['action'] for s in states]), mean, LATENT['sigma'])
            diff = lp-tensor([s['old_logp'] for s in states])
            ratio = diff.clamp(-40, 40).exp()
            surrogate = torch.minimum(ratio*advantage[ids, None], ratio.clamp(.8, 1.2)*advantage[ids, None])
            loss = -(surrogate*weights[ids, None]).sum()
            actor_loss = loss if actor_loss is None else actor_loss+loss
            remaining = tensor([-.01*(rows[i]['makespan']-s['time']) for i, s in zip(ids, states)])
            target = torch.stack([self.norms[r].normalize(remaining[:, None]).squeeze(-1) for r in range(3)], 1)
            c_loss = (values-target.detach()).square().sum()/denom
            critic_loss = c_loss if critic_loss is None else critic_loss+c_loss
            with torch.no_grad():
                kl = gaussian_kl(tensor([s['old_mean'] for s in states]), mean, LATENT['sigma'])
                stats['kl'] += float(kl.sum())
                stats['clip'] += float(((ratio-1).abs()>.2).sum())
                stats['logp'] += float(lp.sum())
                stats['decisions'] += lp.numel()
            if (step+1) % chunk == 0 or step+1 == steps:
                actor_loss.backward()
                critic_loss.backward()
                hidden = hidden.detach()
                actor_loss = critic_loss = None
            if heartbeat and step % 25 == 0:
                heartbeat.update(event='native_update', update_window=step, backward_trajectories=len(rows))
        if sync is not None:
            sync.synchronize_update(self.policy, stats)
        stats['kl'] /= stats['decisions']
        stats['clip'] /= stats['decisions']
        stats['nll'] = -stats.pop('logp')/stats['decisions']
        stats['gradient_norm_by_group'] = {}
        parameters = []
        for group in self.policy.actor_optimizer.param_groups:
            ps = [p for p in group['params'] if p.grad is not None]
            parameters.extend(ps)
            stats['gradient_norm_by_group'][group['name']] = float(torch.stack(
                [p.grad.square().sum() for p in ps]).sum().sqrt()) if ps else 0.
        stats['actor_gradient_norm'] = float(torch.nn.utils.clip_grad_norm_(parameters, 1., error_if_nonfinite=True))
        stats.update(self.ppo_step_controller.step(self, rows, stats, heartbeat, sync))
        return stats

    def update(self, rows, mode='source', source_cost=None, *, epochs=2, chunk=8,
               heartbeat=None, distributed=None, microbatch_size=12, optimizer_step_per_microbatch=True):
        if mode != 'source' or not optimizer_step_per_microbatch or microbatch_size % 4:
            raise ValueError('Native PPO requires complete replica groups and explicit optimizer minibatches')
        advantages, weights, audit = actor_targets(rows, self.bridge_arm, source_cost)
        targets = {id(t): (a, w) for t, a, w in zip(rows, advantages, weights)}
        groups = [rows[i:i+microbatch_size] for i in range(0, len(rows), microbatch_size)]
        metrics, reports, stop = [], [], False
        with RolloutBatchLease(self, rows, epochs*len(groups)) as lease:
            for epoch in range(epochs):
                before, offset = snapshot(self), len(metrics)
                try:
                    for index, group in enumerate(groups):
                        lease.version_for(self, group)
                        row = self._update_group(group, targets, heartbeat, distributed, chunk)
                        row.update(ppo_epoch=epoch, optimizer_minibatch=index+1)
                        metrics.append(row)
                        if not row['actor_step_applied'] or row['post_update']['kl'] > self.ppo_step_controller.soft_kl:
                            stop = True
                            break
                    post = self.replay_metrics(rows, heartbeat, distributed=distributed)
                    rejected = max_role_kl(post) > self.ppo_step_controller.hard_role_kl
                    if rejected:
                        restore(self, before)
                        for row in metrics[offset:]:
                            row.update(actor_step_applied=False, epoch_rolled_back=True)
                        stop = True
                    reports.append({'ppo_epoch': epoch, 'full_batch_post_update': post, 'epoch_rolled_back': rejected})
                    lease.version_for(self, rows)
                    if post['kl'] > self.ppo_step_controller.soft_kl:
                        stop = True
                except BaseException:
                    restore(self, before)
                    raise
                if stop:
                    break
        accepted = sum(bool(r['actor_step_applied']) for r in metrics)
        self.zero_update_batches = 0 if accepted else self.zero_update_batches+1
        self.assert_optimizer_ownership()
        return {'epochs': metrics, 'ppo_epoch_reports': reports, 'bridge_objective': audit,
            'trajectory_advantages': advantages.tolist(), 'population_weights': weights.tolist(),
            'accepted_actor_steps': accepted, 'zero_update_batches': self.zero_update_batches,
            'rollout_trajectories': len(rows), 'backward_microbatch_size': microbatch_size,
            'optimizer_step_per_microbatch': True, 'stopped_early': stop}

    def save(self, path, **metadata):
        return super().save(path, bridge_arm=self.bridge_arm, native_latent=LATENT,
            source_sha256=self.b0_sha256, b0_manifest_sha256=self.b0_manifest_sha256,
            history=HISTORY, inference_batching=GREEDY_BATCHING,
            zero_update_batches=self.zero_update_batches, **metadata)

    def load(self, checkpoint):
        payload = torch.load(checkpoint, map_location='cpu', weights_only=False)
        if (payload.get('bridge_arm') != self.bridge_arm or payload.get('native_latent') != LATENT
                or payload.get('source_sha256') != self.b0_sha256
                or payload.get('b0_manifest_sha256') != self.b0_manifest_sha256
                or payload.get('history') != HISTORY or payload.get('inference_batching') != GREEDY_BATCHING):
            raise ValueError('Native checkpoint source/policy family mismatch')
        super().load(checkpoint)
        self.zero_update_batches = payload['zero_update_batches']
        self.assert_optimizer_ownership()

    def close(self):
        self.intervention.close()
        if self.pool is not None:
            self.pool.close()
