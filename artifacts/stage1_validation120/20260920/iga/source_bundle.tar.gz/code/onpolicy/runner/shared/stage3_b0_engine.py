"""Opt-in frozen Stage2 B0 -> full-depth Stage3 engine, with native deployment.

No historical command or old C0 checkpoint is used to construct this model.
Stage2's original files remain immutable; only an in-memory copy is expanded.
"""
import copy
from pathlib import Path

import numpy as np
import torch
import yaml

from onpolicy.algorithms.gnn_mappo.algorithm.MAPPOPolicy import GNN_MAPPOPolicy
from onpolicy.algorithms.utils.stage3_encoder import install_encoder
from onpolicy.runner.shared.stage3_research_engine import ResearchEngine, EnvironmentPool
from onpolicy.utils.stage2_frozen import load_frozen_stage2, PLANNING
from onpolicy.utils.stage3_local_exploration import RoleExploration, exploration_config
from onpolicy.utils.stage3_numerics import configure_runtime, install_stable_pool
from onpolicy.utils.stage3_performance import GroupExecutionCache
from onpolicy.utils.stage3_ppo_transaction import PPOStepTransaction
from onpolicy.utils.stage3_research import digest_file
from onpolicy.utils.valuenorm import ValueNorm

HISTORY = "b0_native_environment_authoritative_v1"
SCHEMA = "stage3-frozen-b0-policy-v2"
GREEDY_BATCHING = "per_case_v1"


class B0Engine(ResearchEngine):
    def __init__(self, frozen_manifest, variant="F_PRIVATE", *, width=4,
                 device="cuda:0", tau=.03, actor_lr=1e-5, cache_mib=1024,
                 create_environments=True, stable_pool=True):
        if variant not in ("NATIVE", "F_SHARED", "F_PRIVATE"):
            raise ValueError("Unsupported B0 representation")
        configure_runtime()
        self.device = torch.device(device)
        torch.set_num_threads(1)
        if self.device.type == "cuda":
            torch.cuda.set_device(self.device)
            torch.cuda.set_per_process_memory_fraction(1., self.device)
        checkpoint, self.args, bundle = load_frozen_stage2(frozen_manifest)
        self.frozen_manifest = str(Path(frozen_manifest).resolve())
        self.b0_sha256 = bundle.files["b0"]["sha256"]
        self.b0_manifest_sha256 = digest_file(frozen_manifest)
        self.args.lr, self.args.critic_lr = actor_lr, 1e-4
        self.args.shared_actor_lr_scale = 1.
        self.args.plane_actor_lr_scale = .25
        self.args.device_actor_lr_scale = 1.
        self.args.transporter_actor_lr_scale = .5
        self.args.shared_encoder_activation_checkpoint = False
        self.policy = GNN_MAPPOPolicy(self.args,
            yaml.safe_load(Path(self.args.ac_config).read_text()), device=self.device)
        self.policy.ac.load_state_dict(checkpoint["model"], strict=True)
        self.handoff_report = bundle.validate(self.policy.ac.state_dict())
        self.source_metadata = {k: copy.deepcopy(checkpoint[k]) for k in (
            "global_feature_mode", "observation_schema_id", "observation_schema",
            "environment_semantics_version", "plane_order_mode", "plane_pair_decoder") if k in checkpoint}
        self.base_env_config = yaml.safe_load(bundle.path("env_config").read_text())
        self.environment_overrides = dict(PLANNING)
        self.environment_factory = self.make_environment
        self.freeze_shared, self.semantic_history = False, False
        self.measure_graph_bytes, self.diagnostics = True, True
        self.representation = variant
        self.policy_updates = 0
        self.zero_update_batches = 0
        self.norms = {role: ValueNorm(1, device=self.device) for role in range(3)}
        self.representation_report = {"variant": "NATIVE", "full_encoder_copies": 1}
        if variant != "NATIVE":
            self.representation_report = install_encoder(self.policy, variant, frozen_ready_handoff=True)
        self.exploration = None
        self._role_exploration = None
        self.last_decision_stats = {}
        self.configure_exploration({"roles": [0, 1, 2], "taus": [float(tau)] * 3})
        self._separate_optimizer_groups()
        self.set_actor_lr(actor_lr)
        self.assert_optimizer_ownership()
        self.policy.ac.eval()
        if stable_pool:
            install_stable_pool(self.policy)
        self.defer_statistics = True
        self.execution_cache = (GroupExecutionCache(self.policy, cache_mib, frozen_features=False)
                                if cache_mib else None)
        self.policy.stage3_execution_cache = self.execution_cache
        self.policy.ac.stage3_execution_cache = self.execution_cache
        self.ppo_step_controller = PPOStepTransaction()
        self.update_metrics_sink = None
        self.width = int(width)
        self.stochastic_batching = 'per_case_v1'
        self.pool = EnvironmentPool(width) if create_environments else None
        self.checkpoint = str(bundle.path("b0"))

    def make_environment(self, case, seed):
        from onpolicy.envs.HKBZ.experiment.eval_common import build_case_env_config
        config = dict(self.base_env_config)
        config.update(build_case_env_config(str(case), max_plane_agents=24, max_device_num=80,
            resource_policy="drl", seed=int(seed), global_feature_mode="f1f2"))
        config.update(PLANNING, device_request_capacity_per_plane=5,
            use_domain_rand=False, resource_slack_forecast_seconds=0.,
            iga_teacher_dir="", resource_iga_teacher_dir="", resource_iga_teacher_index="",
            joint_iga_teacher_dir="", joint_iga_teacher_index="", pair_feature_storage="sparse_legal")
        return config

    def freeze_auxiliary(self):
        self.policy.ac.request_ready_head.requires_grad_(False)
        self.policy.ac.request_ready_feature.requires_grad_(False)

    def configure_exploration(self, config):
        if self._role_exploration is not None:
            self._role_exploration.close()
        self._role_exploration = None
        self.exploration = exploration_config(config)
        self.policy.set_resource_joint_training_stage(freeze_plane=False, freeze_shared=False)
        self.freeze_auxiliary()
        self.policy.ac.tau = .3
        if self.exploration is not None:
            self._role_exploration = RoleExploration(self.policy.ac, self.exploration,
                                                    allow_hungarian_evaluation=True)
            self.policy.ac.tau = self.exploration["taus"][0]

    def _separate_optimizer_groups(self):
        groups = []
        for group in self.policy.actor_optimizer.param_groups:
            if group["name"] == "shared_encoder" and self.representation == "F_PRIVATE":
                for role, encoder in enumerate(self.policy.ac.encoder.encoders):
                    groups.append({**{k: v for k, v in group.items() if k != "params"},
                                   "name": f"encoder_role{role}", "params": list(encoder.parameters())})
            else:
                groups.append({**group, "params": [p for p in group["params"] if p.requires_grad]})
        self.policy.actor_optimizer = torch.optim.Adam(groups, **self.policy.actor_optimizer.defaults)

    def assert_optimizer_ownership(self):
        actor = [p for g in self.policy.actor_optimizer.param_groups for p in g["params"]]
        critic = [p for g in self.policy.critic_optimizer.param_groups for p in g["params"]]
        ids = [id(p) for p in actor + critic]
        if len(ids) != len(set(ids)):
            raise RuntimeError("Duplicate/overlapping optimizer ownership")
        if {id(p) for p in self.policy.ac.parameters() if p.requires_grad} != set(ids):
            raise RuntimeError("Orphan or frozen trainable-parameter ownership")
        pointers = [p.data_ptr() for p in self.policy.ac.encoder.parameters()]
        if len(pointers) != len(set(pointers)):
            raise RuntimeError("Role encoders alias parameter storage")
        self.freeze_auxiliary()

    def rollout(self, *args, deterministic=False, **kwargs):
        if kwargs.get("greedy_batching", GREEDY_BATCHING) != GREEDY_BATCHING:
            raise ValueError("B0 deployment requires case-independent inference")
        kwargs["greedy_batching"] = GREEDY_BATCHING
        kwargs.setdefault('stochastic_batching', self.stochastic_batching if not deterministic else 'per_case_v1')
        previous = copy.deepcopy(self.exploration)
        if deterministic:
            # Role sampling hooks must not change B0's deployment temperature.
            self.configure_exploration(None)
        try:
            rows = super().rollout(*args, deterministic=deterministic, **kwargs)
            for row in rows:
                row.update(history=HISTORY, source_sha256=self.b0_sha256,
                    decoder="b0_native_hungarian" if deterministic else "autoregressive_sampling")
                if deterministic:
                    row["inference_batching"] = GREEDY_BATCHING
            return rows
        finally:
            if deterministic:
                self.configure_exploration(previous)

    def update(self, *args, **kwargs):
        if self.representation == "NATIVE":
            raise ValueError("The native B0 reference must never train")
        kwargs.setdefault("visit_balanced", True)
        kwargs.setdefault("allow_multi_case", True)
        if self.execution_cache is None:
            result = super().update(*args, **kwargs)
        else:
            with self.execution_cache.group():
                result = super().update(*args, **kwargs)
            result["execution_cache"] = self.execution_cache.last_report
        accepted = sum(bool(e["actor_step_applied"]) for e in result["epochs"])
        self.zero_update_batches = 0 if accepted else self.zero_update_batches + 1
        result.update(accepted_actor_steps=accepted, zero_update_batches=self.zero_update_batches,
                      actor_base_lr=self.policy.lr)
        self.assert_optimizer_ownership()
        return result

    def save(self, path, **metadata):
        metadata.update(b0_schema=SCHEMA, b0_manifest_sha256=self.b0_manifest_sha256,
            source_sha256=self.b0_sha256, representation=self.representation,
            representation_report=self.representation_report, history=HISTORY,
            environment_overrides=dict(PLANNING), zero_update_batches=self.zero_update_batches)
        metadata["inference_batching"] = GREEDY_BATCHING
        return super().save(path, **metadata)

    def load(self, checkpoint):
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if (payload.get("b0_schema") != SCHEMA or payload.get("source_sha256") != self.b0_sha256
                or payload.get("b0_manifest_sha256") != self.b0_manifest_sha256
                or payload.get("representation") != self.representation
                or payload.get("inference_batching") != GREEDY_BATCHING
                or payload.get("history") != HISTORY
                or payload.get("environment_overrides") != PLANNING):
            raise ValueError("Checkpoint is not this B0/architecture/environment lineage")
        super().load(checkpoint)
        self.zero_update_batches = int(payload["zero_update_batches"])
        self.assert_optimizer_ownership()

    def close(self):
        if self._role_exploration is not None:
            self._role_exploration.close()
        if self.pool is not None:
            self.pool.close()
