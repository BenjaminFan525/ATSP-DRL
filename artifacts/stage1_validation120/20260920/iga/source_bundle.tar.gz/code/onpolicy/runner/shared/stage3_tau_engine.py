"""Private grouped PPO with resume-safe, batch-constant temperature."""
import copy
import torch

from onpolicy.runner.shared.stage3_rl_bridge_engine import GroupB0Engine
from onpolicy.utils.stage3_tau import ARMS, temperature_state, validate_temperature_state


class TauDecisionStats:
    """On-device role/legality-bin counters; one host transfer per rollout."""
    def __init__(self):
        self.rows = {}

    def add(self, role, base, effective, selected):
        scores = effective.detach()
        legal = torch.isfinite(scores).sum(-1)
        probabilities = scores.softmax(-1)
        entropy = -(probabilities*scores.nan_to_num(neginf=0.)).sum(-1)
        top = scores.topk(min(2, scores.shape[-1]), dim=-1).values
        gap = top[:, 0]-top[:, -1]
        gap = torch.where(legal > 1, gap, torch.zeros_like(gap))
        values = torch.stack((torch.ones_like(entropy), legal, entropy, probabilities.max(-1).values,
            gap, (selected != scores.argmax(-1)).to(scores.dtype)), -1)
        masks = torch.stack((legal == 1, (legal > 1) & (legal <= 4),
                             (legal > 4) & (legal <= 16), legal > 16), 0)
        sums = masks.to(scores.dtype) @ values
        if role not in self.rows:
            self.rows[role] = sums
        else:
            self.rows[role].add_(sums)

    def result(self):
        result = {}
        for role, tensor in self.rows.items():
            bins = {}
            for label, row in zip(('1', '2-4', '5-16', '17+'), tensor.cpu().double().tolist()):
                n = max(row[0], 1.)
                bins[label] = dict(decisions=int(row[0]), legal_candidates_mean=row[1]/n,
                    entropy_mean=row[2]/n, pmax_mean=row[3]/n, scaled_logit_gap_mean=row[4]/n,
                    non_greedy_fraction=row[5]/n)
            result[str(role)] = bins
        return result


class TauEngine(GroupB0Engine):
    def __init__(self, *args, arm, replay_storage=None, **kwargs):
        self.committed_episodes = 0
        self.replay_storage = copy.deepcopy(replay_storage)
        self.replay_stores = []
        super().__init__(*args, arm=arm, arm_spec=ARMS[arm], tau=ARMS[arm]['tau_start'], **kwargs)
        self.decision_stats_factory = TauDecisionStats

    def rollout(self, *args, **kwargs):
        if kwargs.get('retain') and self.replay_storage:
            from onpolicy.utils.stage3_replay_store import GraphReplayStore
            store = GraphReplayStore(**self.replay_storage)
            self.replay_stores.append(store)
            self.retained_state_factory = store.pack
        try:
            return super().rollout(*args, **kwargs)
        finally:
            self.retained_state_factory = None

    def replay_storage_report(self):
        return [store.report() for store in self.replay_stores]

    def release_replay(self):
        for store in getattr(self, 'replay_stores', []):
            store.close()
        self.replay_stores = []

    def close(self):
        self.release_replay()
        super().close()

    def set_progress(self, committed):
        if getattr(self, '_active_rollout_batch', None) is not None:
            raise ValueError('Cannot anneal inside an active PPO batch')
        if committed < self.committed_episodes:
            raise ValueError('Cannot rewind temperature without an explicit checkpoint resume')
        state = temperature_state(self.bridge_arm, committed)
        self.configure_exploration(dict(roles=[0, 1, 2], taus=[state['sampling_tau']]*3))
        self.committed_episodes = committed
        return state

    def update(self, trajectories, *args, **kwargs):
        state = temperature_state(self.bridge_arm, self.committed_episodes)
        if self.exploration['taus'] != [state['sampling_tau']]*3:
            raise ValueError('Training must use the temperature at its committed cursor')
        result = super().update(trajectories, *args, **kwargs)
        result['temperature_state'] = state
        return result

    def save(self, path, **metadata):
        state = temperature_state(self.bridge_arm, self.committed_episodes)
        if self.exploration['taus'] != [state['sampling_tau']]*3:
            raise ValueError('Cannot save a diagnostic temperature as training state')
        return super().save(path, temperature_state=state, **metadata)

    def load(self, checkpoint):
        payload = torch.load(checkpoint, map_location='cpu', weights_only=False)
        committed = validate_temperature_state(payload['temperature_state'], self.bridge_arm)
        if payload['exploration']['taus'] != [payload['temperature_state']['sampling_tau']]*3:
            raise ValueError('Saved behavior temperature differs from schedule cursor')
        super().load(checkpoint)
        self.committed_episodes = committed

    def resume(self, checkpoint, *, protocol_sha256, exploration=None):
        # The saved schedule, not the constructor's initial temperature, controls resume.
        payload = torch.load(checkpoint, map_location='cpu', weights_only=False)
        validate_temperature_state(payload['temperature_state'], self.bridge_arm)
        if exploration is not None and exploration != payload['exploration']:
            raise ValueError('Explicit resume exploration disagrees with saved schedule')
        return super().resume(checkpoint, protocol_sha256=protocol_sha256,
                              exploration=copy.deepcopy(payload['exploration']))
