#!/usr/bin/env bash
set -euo pipefail
cd /data/fanyx/HKBZ-environment
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
export CUDA_VISIBLE_DEVICES=''
export MPLCONFIGDIR=/data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_matched_iga_validation120_20260920_r1/mplconfig
export PYTHONUNBUFFERED=1
export PYTHONPATH=/data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_matched_iga_validation120_20260920_r1/code
exec taskset -c 0-127 /data/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python -u /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_matched_iga_validation120_20260920_r1/code/onpolicy/envs/HKBZ/experiment/run_stage1_nested_iga.py --dataset-dir /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_matched_iga_validation120_20260920_r1/inputs/validation --output-dir /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_matched_iga_validation120_20260920_r1/full --aligned-evaluation /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_matched_iga_validation120_20260920_r1/inputs/aligned_validation60.json --workers 120 --population 20 --max-generations 100000 --max-steps 4000 --seed 20260824 --budget180 180 --budget1800 1800 --stage3-reference /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage3_matched_iga_h3f4_validation120_20260918_r1/full >> /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_matched_iga_validation120_20260920_r1/logs/pipeline.log 2>&1
