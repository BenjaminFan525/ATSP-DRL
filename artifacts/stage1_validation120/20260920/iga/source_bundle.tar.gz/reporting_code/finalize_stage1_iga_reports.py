#!/usr/bin/env python3
"""Publish both actual dataset groups and legacy baseline-compatible groups.

This postprocessor leaves case results/teachers and the active search untouched.
It supports the first frozen Stage1 runner, which reported only dataset labels.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import statistics
import time


WEIGHTS = {"iid": 0.5, "ood_stress": 0.45, "ood_scale": 0.05}


def read(path):
    return json.loads(path.read_text())


def atomic(path, payload):
    temporary = path.with_suffix(path.suffix + ".report.tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def finalize_phase(root, phase, manifest, panel):
    summary_path = root / phase / "summary.json"
    if not summary_path.exists():
        return None
    summary = read(summary_path)
    if summary["status"] != "completed":
        return None
    if summary["run_contract_sha256"] != manifest["run_contract_sha256"]:
        raise ValueError("Summary/manifest contract mismatch")
    rows = {row["case"]: row for row in summary["cases"]}
    baseline_labels = {row["case_dir"]: row["distribution"] for row in panel["cases"]}
    selected = manifest["aligned60_cases"]
    if len(selected) != 60 or set(selected) != set(baseline_labels) or len(rows) != manifest["case_count"]:
        raise ValueError("Reporting requires a complete validation120/aligned60 run")
    mismatches = []
    values = {key: [] for key in WEIGHTS}
    for record in panel["cases"]:
        name = record["case_dir"]
        row = rows[name]
        if row["case_sha256"] != record["fingerprints"]["case_sha256"]:
            raise ValueError(f"Case fingerprint mismatch: {name}")
        values[record["distribution"]].append(row["makespan"])
        if record["distribution"] != row["distribution"]:
            mismatches.append({"case": name, "historical_baseline_distribution": record["distribution"],
                               "dataset_distribution": row["distribution"]})
    groups = {key: {"count": len(value), "mean": statistics.mean(value)} for key, value in values.items()}
    raw = summary.get("aligned_validation60_case_metadata", summary["aligned_validation60"])
    aligned = {
        **raw, "distributions": groups,
        "composite_makespan": sum(WEIGHTS[key] * groups[key]["mean"] for key in WEIGHTS),
        "distribution_label_source": "historical_learning_baseline_evaluation",
    }
    report_note = (
        "The historical learning evaluation used manifest distribution overrides. "
        "aligned_validation60 preserves those groups solely for score compatibility; "
        "aligned_validation60_case_metadata reports actual dataset groups. "
        "Both use exactly the same 60 case payloads and makespans."
    )
    summary.update(
        aligned_validation60=aligned, aligned_validation60_case_metadata=raw,
        aligned_label_note=report_note,
        aligned_label_audit={"mismatch_count": len(mismatches), "mismatches": mismatches},
        reporting_finalized=True, reporting_finalized_at=datetime.now().astimezone().isoformat(),
    )
    backup = summary_path.with_name("summary_before_label_alignment.json")
    if not backup.exists():
        backup.write_bytes(summary_path.read_bytes())
    atomic(summary_path, summary)
    atomic(root / "aligned_reporting_contract.json", {
        "note": report_note, "historical_distribution_by_case": baseline_labels,
        "mismatch_count": len(mismatches), "mismatches": mismatches,
        "source_evaluation": manifest["aligned_evaluation"],
        "source_evaluation_sha256": manifest["aligned_evaluation_sha256"],
        "postprocessor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    })
    print(f"[Stage1IGAReport] {phase}: aligned60 composite={aligned['composite_makespan']:.6f}; label mismatches={len(mismatches)}", flush=True)
    return {"phase": phase, "summary": str(summary_path), "aligned_validation60": aligned}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", required=True, type=Path)
    parser.add_argument("--wait", action="store_true")
    args = parser.parse_args()
    root = args.run_root.resolve()
    manifest = read(root / "manifest.json")
    panel_path = Path(manifest["aligned_evaluation"])
    if hashlib.sha256(panel_path.read_bytes()).hexdigest() != manifest["aligned_evaluation_sha256"]:
        raise ValueError("Aligned evaluation changed")
    panel = read(panel_path)
    done = {}
    while True:
        for phase in ("iga180", "iga1800"):
            if phase not in done:
                result = finalize_phase(root, phase, manifest, panel)
                if result:
                    done[phase] = result
        state = read(root / "pipeline_state.json")
        status = ("failed" if state["status"] == "failed" else
                  "completed" if len(done) == 2 and state["status"] == "completed" else "waiting")
        atomic(root / "report_status.json", {
            "status": status, "phases": done,
            "updated_at": datetime.now().astimezone().isoformat(),
        })
        if status == "failed":
            raise RuntimeError("Search failed before reports were complete")
        if status == "completed" or not args.wait:
            return
        if state["status"] == "completed":
            raise RuntimeError("Completed search has missing or invalid summary")
        time.sleep(15)


if __name__ == "__main__":
    main()
