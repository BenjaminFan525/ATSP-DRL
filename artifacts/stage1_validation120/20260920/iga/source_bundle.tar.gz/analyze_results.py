"""Read-only audit and paired analysis; writes only the analysis/ directory."""
from pathlib import Path
import collections
import csv
from datetime import datetime
import hashlib
import json
import math
import statistics

import numpy as np

ROOT = Path(__file__).resolve().parent
FULL = ROOT / "full"
OUT = ROOT / "analysis"
OUT.mkdir(exist_ok=True)
WEIGHTS = {"iid": .50, "ood_stress": .45, "ood_scale": .05}
SOURCES = {}


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    SOURCES[str(path)] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


def metrics(values, labels):
    values = np.asarray(values, dtype=float)
    groups = {d: float(np.mean(values[np.asarray(labels) == d])) for d in WEIGHTS}
    return dict(mean=float(values.mean()), median=float(np.median(values)),
                p95=float(np.percentile(values, 95)), worst=float(values.max()),
                worst10_mean=float(np.mean(np.sort(values)[-math.ceil(len(values) / 10):])),
                composite=sum(WEIGHTS[d] * groups[d] for d in WEIGHTS), groups=groups)


def paired(a, b, labels):
    """Difference a-b; bootstrap cases within fixed reporting strata."""
    delta = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    rng = np.random.default_rng(20260920)
    boot = np.zeros(20000)
    labels = np.asarray(labels)
    for label, weight in WEIGHTS.items():
        subset = delta[labels == label]
        boot += weight * subset[rng.integers(0, len(subset), (len(boot), len(subset)))].mean(axis=1)
    return dict(a_wins=int(sum(delta < -1e-9)), a_losses=int(sum(delta > 1e-9)),
                ties=int(sum(abs(delta) <= 1e-9)), mean_delta=float(delta.mean()),
                composite_delta=metrics(a, labels)["composite"] - metrics(b, labels)["composite"],
                paired_case_bootstrap95=list(map(float, np.percentile(boot, [2.5, 97.5]))),
                median_delta=float(np.median(delta)))


manifest = read(FULL / "manifest.json")
state = read(FULL / "pipeline_state.json")
report_state = read(FULL / "report_status.json")
assert state["status"] == report_state["status"] == "completed"
identities = {r["case"]: r for r in manifest["cases"]}
names = sorted(identities)
panel = read(manifest["aligned_evaluation"])
historical = {r["case_dir"]: r for r in panel["cases"]}
aligned = sorted(historical)
assert len(names) == 120 and len(aligned) == 60
assert set(aligned) == set(manifest["aligned60_cases"])
labels120 = [identities[n]["distribution"] for n in names]
labels60 = [historical[n]["distribution"] for n in aligned]
actual60 = [identities[n]["distribution"] for n in aligned]
rows, summaries, values120, values60 = {}, {}, {}, {}
teacher_checks = []
for phase in ("iga180", "iga1800"):
    summaries[phase] = read(FULL / phase / "summary.json")
    rows[phase] = {n: read(FULL / phase / "cases" / (n + ".json")) for n in names}
    for name, row in rows[phase].items():
        teacher_path = Path(row["teacher"])
        teacher = read(teacher_path)
        assert SOURCES[str(teacher_path)] == row["teacher_sha256"]
        assert teacher["makespan"] == row["makespan"]
        assert teacher["completed"] and teacher["completion_verified"] and teacher["completion"]["completed"]
        assert not teacher["completion"]["cycle_terminated"]
        assert row["case_sha256"] == identities[name]["case_sha256"]
        assert row["run_contract_sha256"] == manifest["run_contract_sha256"]
        assert row["resource_policy"] == "heuristic" and row["search"]["resource_n_var"] == 0
        assert row["planning_contract"] == manifest["planning_contract"]
        search = row["search"]
        assert search["configured_additional_budget_seconds"] == (180 if phase == "iga180" else 1620)
        assert search["optimization_wall_seconds"] >= search["configured_additional_budget_seconds"]
        if phase == "iga1800":
            old = rows["iga180"][name]
            warm = search["warm_start"]
            assert warm["sha256"] == old["teacher_sha256"]
            assert warm["source_makespan"] == old["makespan"] and warm["source_budget_seconds"] == 180
            assert search["inherited_verified_candidates"] == 1
            assert row["makespan"] <= old["makespan"]
        teacher_checks.append({"phase": phase, "case": name, "verified_artifact": True})
    values120[phase] = np.array([rows[phase][n]["makespan"] for n in names])
    values60[phase] = np.array([rows[phase][n]["makespan"] for n in aligned])
    assert abs(metrics(values120[phase], labels120)["mean"] - summaries[phase]["validation120"]["mean_makespan"]) < 1e-8
    assert abs(metrics(values60[phase], labels60)["composite"] - summaries[phase]["aligned_validation60"]["composite_makespan"]) < 1e-8

# The previous index provides file locations only. Reload all evaluations and
# select validation-Best again from the original evaluation/response artifacts.
index = read("/tmp/hkbz_baseline_analysis_20260920.json")
learning = {}
for key, run in index["runs"].items():
    fresh = []
    for ev in run["evals"]:
        data = read(ev["source"])
        cases = data["evaluation"]["records"] if "evaluation" in data else data["cases"]
        by_name = {c["case_dir"]: c for c in cases}
        assert set(by_name) == set(aligned)
        for name, case in by_name.items():
            assert case["fingerprints"]["case_sha256"] == identities[name]["case_sha256"]
            assert case["fingerprints"]["files"] == identities[name]["files_sha256"]
            assert case["distribution"] == historical[name]["distribution"]
            assert case["completed"] and not case["timeout"] and not case["cycle_terminated"]
        costs = np.array([by_name[n]["makespan"] for n in aligned])
        fresh.append(dict(epoch=ev["epoch"], source=ev["source"], costs=costs,
                          historical=metrics(costs, labels60), actual=metrics(costs, actual60)))
    best = min(fresh, key=lambda ev: (ev["historical"]["composite"], ev["epoch"]))
    assert best["epoch"] == run["best"]["epoch"]
    learning[key] = dict(method=run["method"], seed=run["seed"], **best)

models = {}
for method in ("P5", "multi_ppo", "fjsp_drl", "daniel", "l2d"):
    seeds = [learning[f"{method}_s{s}"] for s in (1, 2, 3)]
    matrix = np.array([s["costs"] for s in seeds])
    avg = matrix.mean(axis=0)
    models[method] = {
        "seeds": [dict(seed=s["seed"], epoch=s["epoch"], source=s["source"],
                       historical=s["historical"], actual=s["actual"]) for s in seeds],
        "historical_composite_mean": float(np.mean([s["historical"]["composite"] for s in seeds])),
        "historical_composite_sd": float(np.std([s["historical"]["composite"] for s in seeds], ddof=1)),
        "actual_composite_mean": float(np.mean([s["actual"]["composite"] for s in seeds])),
        "raw_mean": float(matrix.mean()),
        "p95_mean_across_seeds": float(np.mean([s["historical"]["p95"] for s in seeds])),
        "worst10_mean_across_seeds": float(np.mean([s["historical"]["worst10_mean"] for s in seeds])),
        "actual_group_means": {d: float(np.mean([s["actual"]["groups"][d] for s in seeds])) for d in WEIGHTS},
        "iga180_vs_seed_mean": paired(values60["iga180"], avg, labels60),
        "iga1800_vs_seed_mean": paired(values60["iga1800"], avg, labels60),
        "iga1800_vs_seed_mean_actual_labels": paired(values60["iga1800"], avg, actual60),
        "iga1800_vs_each_seed": [paired(values60["iga1800"], s["costs"], labels60) for s in seeds],
    }

gain = values120["iga180"] - values120["iga1800"]
search_stats = {}
for phase in rows:
    searches = [r["search"] for r in rows[phase].values()]
    search_stats[phase] = {
        "generation_counts": dict(collections.Counter(s["completed_generations"] for s in searches)),
        "new_candidate_total": sum(s["evaluated_candidates"] for s in searches),
        "new_candidate_mean": statistics.mean(s["evaluated_candidates"] for s in searches),
        "new_candidate_min": min(s["evaluated_candidates"] for s in searches),
        "new_candidate_max": max(s["evaluated_candidates"] for s in searches),
        "all_evaluated_candidates_completed": all(s["evaluated_candidates"] == s["completed_candidates"] for s in searches),
        "search_wall_min": min(s["optimization_wall_seconds"] for s in searches),
        "search_wall_max": max(s["optimization_wall_seconds"] for s in searches),
        "search_wall_mean": statistics.mean(s["optimization_wall_seconds"] for s in searches),
    }
improved_at_last_record = sum(s["search"]["candidate_history"][-1]["best_makespan"] < s["search"]["candidate_history"][-2]["best_makespan"] for s in rows["iga1800"].values() if len(s["search"]["candidate_history"]) > 1)
result = {
    "created_at": datetime.now().astimezone().isoformat(),
    "verification_status": "ANALYZED", "artifact_verified_count": len(teacher_checks),
    "search_rerun_for_analysis": False,
    "completed_at": datetime.fromtimestamp(state["ended_unix_time"]).astimezone().isoformat(),
    "elapsed_seconds": state["ended_unix_time"] - state["started_unix_time"],
    "validation120": {p: metrics(values120[p], labels120) for p in rows},
    "aligned60_historical": {p: metrics(values60[p], labels60) for p in rows},
    "aligned60_actual": {p: metrics(values60[p], actual60) for p in rows},
    "nested120": paired(values120["iga1800"], values120["iga180"], labels120),
    "nested60": paired(values60["iga1800"], values60["iga180"], labels60),
    "case_relative_reduction_mean_pct": float(np.mean(gain / values120["iga180"]) * 100),
    "search": search_stats,
    "cumulative_candidate_mean": sum(s["new_candidate_mean"] for s in search_stats.values()),
    "last_generation_record_still_improved_cases": improved_at_last_record,
    "learning": models,
    "label_mismatch_count": sum(a != b for a, b in zip(labels60, actual60)),
    "label_counts_historical": dict(collections.Counter(labels60)),
    "label_counts_actual": dict(collections.Counter(actual60)),
    "bootstrap_note": "20000 paired case bootstrap samples, stratified by stated labels; learning seed means are fixed, not an ensemble. Conditional on selected validation-Best checkpoints and one IGA search seed; not seed-robust or independent-test inference. Pointwise intervals, exploratory, no p-values or multiple-comparison claims.",
    "source_sha256": SOURCES,
}
(OUT / "analysis.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
with (OUT / "per_case.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["case", "actual_distribution", "profile", "aligned60", "historical_distribution", "iga180", "iga1800", "improvement_seconds", "improvement_pct"] + [f"P5_seed{s}" for s in (1, 2, 3)])
    for i, name in enumerate(names):
        costs = [learning[f"P5_s{s}"]["costs"][aligned.index(name)] for s in (1, 2, 3)] if name in historical else [""] * 3
        writer.writerow([name, identities[name]["distribution"], identities[name]["profile"], name in historical,
                         historical[name]["distribution"] if name in historical else "", values120["iga180"][i], values120["iga1800"][i], gain[i], gain[i] / values120["iga180"][i] * 100, *costs])

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), constrained_layout=True)
colors = {"iid": "#3288bd", "ood_stress": "#d95f02", "ood_scale": "#2ca25f"}
for label, color in colors.items():
    selected = np.array(labels120) == label
    axes[0].scatter(values120["iga180"][selected], values120["iga1800"][selected], s=26, c=color, alpha=.8, label=label)
limits = [min(values120["iga1800"]) - 200, max(values120["iga180"]) + 200]
axes[0].plot(limits, limits, "--", color="0.5", linewidth=1)
axes[0].set(xlabel="IGA-180 makespan (s)", ylabel="IGA-1800 makespan (s)", title="Validation120: 111 improved / 9 tied / 0 worse")
axes[0].legend(frameon=False, fontsize=9)
entries = [("IGA-1800", metrics(values60["iga1800"], labels60)["composite"], 0), ("IGA-180", metrics(values60["iga180"], labels60)["composite"], 0)]
display = {"P5": "P5", "multi_ppo": "Multi-PPO-AT", "fjsp_drl": "FJSP-DRL-AT", "daniel": "DANIEL-AT", "l2d": "L2D-AT"}
entries += [(display[m], v["historical_composite_mean"], v["historical_composite_sd"]) for m, v in models.items()]
entries.sort(key=lambda row: row[1])
axes[1].barh([e[0] for e in entries], [e[1] for e in entries], color=["#1b9e77" if e[0].startswith("IGA") else "#7570b3" for e in entries])
for i, (_, value, sd) in enumerate(entries):
    if sd > 0:
        axes[1].errorbar(value, i, xerr=sd, color="black", fmt="none", capsize=3)
axes[1].invert_yaxis()
axes[1].set(xlabel="Historical-group composite (s), lower is better", title="Aligned validation60: fixed Best checkpoints")
axes[1].set_xlim(0, 11900)
for i, (_, value, sd) in enumerate(entries): axes[1].text(value + sd + 130, i, f"{value:.0f}", va="center", fontsize=9)
fig.suptitle("Stage1 IGA rerun | learning: 3 seeds (mean +/- sample SD); IGA: 1 search seed", fontsize=12)
fig.savefig(OUT / "comparison.png", dpi=170)
fig.savefig(OUT / "comparison.pdf")
plt.close(fig)
print(json.dumps({k: v for k, v in result.items() if k not in {"source_sha256", "learning"}}, ensure_ascii=False))
print("LEARNING", json.dumps(models, ensure_ascii=False))
