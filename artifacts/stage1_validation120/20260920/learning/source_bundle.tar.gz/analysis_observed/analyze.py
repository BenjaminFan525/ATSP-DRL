from pathlib import Path
import csv,hashlib,json,statistics,datetime
r=Path('/data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_validation120_best_20260920_r3')
m=json.loads((r/'manifest.json').read_text());s=json.loads((r/'state.json').read_text());cases={x['case']:x for x in m['cases']}
model_rows={};group={};changes=[]
for j in m['jobs']:
 p=Path(j['output']);o=json.loads(p.read_text());a=json.loads((r/'audits'/f"{j['id']}.json").read_text())
 assert hashlib.sha256(p.read_bytes()).hexdigest()==a['result_sha256']
 assert hashlib.sha256(Path(j['checkpoint']).read_bytes()).hexdigest()==j['checkpoint_sha256']
 assert o['model_sha256']==j['model_sha256'] and o['status']=='completed' and o['seed']==j['seed']
 rows=o['evaluation']['records'];assert len(rows)==120 and {x['case_dir'] for x in rows}==set(cases)
 assert all(x['completed'] and not x['timeout'] and not x['cycle_terminated'] and x['fingerprints']['case_sha256']==cases[x['case_dir']]['case_sha256'] and x['distribution']==cases[x['case_dir']]['distribution'] for x in rows)
 model_rows[j['id']]={x['case_dir']:x['makespan'] for x in rows}
 group.setdefault(j['method'],[]).append((j,a))
 changes += [{'job':j['id'],**d,'delta':d['new']-d['old']} for d in a['overlap60_differences']]
snapshot=json.loads((r/'snapshot_manifest.json').read_text())
for rel,h in snapshot['files'].items():assert hashlib.sha256((r/rel).read_bytes()).hexdigest()==h,rel
p5={n:statistics.mean(model_rows[f'P5_s{k}'][n] for k in [1,2,3]) for n in cases}
methods={}
for name,pairs in group.items():
 pairs.sort(key=lambda pair:pair[0]['seed']);ms=[a['metrics'] for j,a in pairs]
 vals={n:statistics.mean(model_rows[j['id']][n] for j,a in pairs) for n in cases}
 d=[p5[n]-vals[n] for n in cases]
 ds=[x for x in changes if x['job'] in {j['id'] for j,a in pairs}]
 original60_means=[];new60_means=[]
 for j,a in pairs:
  old={x['case_dir'] for x in json.loads(Path(j['reference']).read_text())['cases']}
  original60_means.append(statistics.mean(model_rows[j['id']][n] for n in old));new60_means.append(statistics.mean(model_rows[j['id']][n] for n in set(cases)-old))
 methods[name]={'mean':statistics.mean(v['mean'] for v in ms),'seed_sd':statistics.stdev(v['mean'] for v in ms),'per_seed':[{'seed':j['seed'],'best_epoch':j['best_epoch'],'mean':a['metrics']['mean'],'overlap_match':a['overlap60_exact_match_count']} for j,a in pairs], 'groups':{dist:statistics.mean(v['groups'][dist] for v in ms) for dist in ['iid','ood_stress','ood_scale']},'p95_seed_average':statistics.mean(v['p95'] for v in ms),'worst10_seed_average':statistics.mean(v['worst10_mean'] for v in ms),'worst_seed_average':statistics.mean(v['worst'] for v in ms),'original60_mean':statistics.mean(original60_means),'additional60_mean':statistics.mean(new60_means),'p5_lower_percent':(statistics.mean(v['mean'] for v in ms)-statistics.mean(p5.values()))/statistics.mean(v['mean'] for v in ms)*100,'p5_wins':sum(x<0 for x in d),'p5_ties':sum(x==0 for x in d),'p5_losses':sum(x>0 for x in d),'old60_exact_match':sum(a['overlap60_exact_match_count'] for j,a in pairs),'old60_total':180,'status':'verified' if all(a['overlap60_exact_match_count']==60 for j,a in pairs) else 'provisional_needs_review','drift_absolute_mean_on_changed_cases':statistics.mean(abs(x['delta']) for x in ds) if ds else 0,'drift_max_abs':max((abs(x['delta']) for x in ds),default=0),'old_overlap_drift_contribution_to_full120_mean':sum(x['delta'] for x in ds)/360}
out={'status':'all_evaluations_complete_reproducibility_review_pending','suite_state':s['status'],'ended_at':datetime.datetime.fromtimestamp(s['ended_unix_time'],datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'total_evaluations':1800,'baseline_evaluations':1440,'baseline_checkpoints':12,'baseline_accepted_checkpoints':sum(st['status']=='completed' for key,st in s['jobs'].items() if not key.startswith('P5')),'baseline_changed_overlap_cases':len(changes),'methods':methods,'overlap_differences':changes,'snapshot_file_count_verified':len(snapshot['files']),'note':'Observed r3 results only; no historical makespans substituted, no selecting favorable runs across r2/r3. Three baseline methods remain provisional. SD is sample SD over 3 seed-level means.'}
target=r/'analysis_observed';target.mkdir(exist_ok=True)
(target/'summary.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
with (target/'overlap_differences.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['job','case','old','new','delta']);w.writeheader();w.writerows(changes)
with (target/'per_case.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['method','seed','best_epoch','case','distribution','case_sha256','makespan','checkpoint_status'])
 for j in m['jobs']:
  for n,x in model_rows[j['id']].items():w.writerow([j['method'],j['seed'],j['best_epoch'],n,cases[n]['distribution'],cases[n]['case_sha256'],x,s['jobs'][j['id']]['status']])
print(json.dumps({k:v for k,v in out.items() if k!='overlap_differences'},indent=2,ensure_ascii=False))
