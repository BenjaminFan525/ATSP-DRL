#!/usr/bin/env python3
"""Report fixed-Best validation120 results after all overlap audits pass."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import statistics
import time


def read(path):
    return json.loads(Path(path).read_text())


def quantile(values, p):
    ordered = sorted(values)
    position = (len(ordered) - 1) * p
    lower = int(position)
    return ordered[lower] + (position - lower) * (ordered[min(lower + 1, len(ordered) - 1)] - ordered[lower])


def describe(records):
    values = list(records.values())
    return {"mean": statistics.mean(values), "median": statistics.median(values),
            "p95": quantile(values, .95), "worst10_mean": statistics.mean(sorted(values)[-((len(values) + 9) // 10):]),
            "worst": max(values)}


def analyze(root):
    manifest, state = read(root / "manifest.json"), read(root / "state.json")
    if state["status"] != "completed" or state["completed_jobs"] != 15:
        raise ValueError("All 15 evaluation jobs must finish before a final comparison")
    cases = {case["case"]: case for case in manifest["cases"]}
    models = {}
    old60 = None
    for job in manifest["jobs"]:
        audit, result = read(root / "audits" / (job["id"] + ".json")), read(job["output"])
        if audit["overlap60_exact_match_count"] != 60:
            raise ValueError("Historical overlap was not reproduced")
        reference = {case["case_dir"] for case in read(job["reference"])["cases"]}
        if old60 is None:
            old60 = reference
        if reference != old60:
            raise ValueError("Learning models use different historical validation panels")
        values = {row["case_dir"]: row["makespan"] for row in result["evaluation"]["records"]}
        if set(values) != set(cases):
            raise ValueError("Learning case identity mismatch")
        models.setdefault(job["method"], []).append(values)
    for phase in ("iga180", "iga1800"):
        result = read(Path(manifest["iga_run_root"]) / phase / "summary.json")
        if any(row["case_sha256"] != cases[row["case"]]["case_sha256"] for row in result["cases"]):
            raise ValueError("IGA and learning methods used different case content")
        values = {row["case"]: row["makespan"] for row in result["cases"]}
        if set(values) != set(cases):
            raise ValueError("IGA case identity mismatch")
        models[phase] = [values]
    panels = {"validation120": set(cases), "original60": old60, "additional60": set(cases) - old60}
    output = {"status": "completed", "checkpoint_selection": manifest["checkpoint_selection"],
              "case_count": 120, "learning_seed_count": 3, "iga_search_seed_count": 1,
              "overlap_exact_reproductions": 900, "panels": {}}
    for panel, names in panels.items():
        methods = {}
        for method, seeds in models.items():
            stats = [describe({name: seed[name] for name in names}) for seed in seeds]
            methods[method] = {
                "mean": statistics.mean(row["mean"] for row in stats),
                "seed_sd": statistics.stdev(row["mean"] for row in stats) if len(stats) > 1 else None,
                "seed_count": len(seeds), "per_seed": stats,
                "p95_mean_across_seeds": statistics.mean(row["p95"] for row in stats),
                "worst10_mean_across_seeds": statistics.mean(row["worst10_mean"] for row in stats),
                "distributions": {d: statistics.mean(seed[name] for seed in seeds for name in names if cases[name]["distribution"] == d)
                                  for d in ("iid", "ood_stress", "ood_scale")},
            }
        p5 = {name: statistics.mean(seed[name] for seed in models["P5"]) for name in names}
        paired = {}
        for method, seeds in models.items():
            if method == "P5":
                continue
            differences = [p5[name] - statistics.mean(seed[name] for seed in seeds) for name in sorted(names)]
            paired[method] = {"p5_wins": sum(d < -1e-6 for d in differences),
                              "ties": sum(abs(d) <= 1e-6 for d in differences),
                              "p5_losses": sum(d > 1e-6 for d in differences),
                              "p5_minus_comparator_mean": statistics.mean(differences),
                              "p5_reduction_percent": (methods[method]["mean"] - methods["P5"]["mean"]) / methods[method]["mean"] * 100}
        output["panels"][panel] = {"case_count": len(names),
            "distribution_counts": {d: sum(cases[name]["distribution"] == d for name in names) for d in ("iid", "ood_stress", "ood_scale")},
            "methods": methods, "p5_pairwise": paired}
    target = root / "analysis"
    target.mkdir(exist_ok=True)
    (target / "summary.json").write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n")
    full = output["panels"]["validation120"]
    lines = ["# Stage1 validation120 补评结果", "",
             "P5 和四个学习基线各3个训练种子，固定原 validation60 Best；IGA使用本轮既有单搜索种子结果。", "",
             "120例真实构成为60 IID、54 OOD-stress、6 OOD-scale；平均makespan等于0.50/0.45/0.05加权综合分，越低越好。±为三个种子的样本标准差。", "",
             "| 方法 | 平均makespan / 综合分 | IID | OOD-stress | OOD-scale | P95 | 最差10%均值 |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    labels = {"multi_ppo": "Multi-PPO-AT", "fjsp_drl": "FJSP-DRL-AT", "daniel": "DANIEL-AT", "l2d": "L2D-AT", "iga180": "IGA-180", "iga1800": "IGA-1800", "P5": "P5"}
    for method, row in sorted(full["methods"].items(), key=lambda item: item[1]["mean"]):
        value = f"{row['mean']:.2f}" + (f" ± {row['seed_sd']:.2f}" if row['seed_sd'] is not None else "")
        ds = row["distributions"]
        lines.append(f"| {labels[method]} | {value} | {ds['iid']:.2f} | {ds['ood_stress']:.2f} | {ds['ood_scale']:.2f} | {row['p95_mean_across_seeds']:.2f} | {row['worst10_mean_across_seeds']:.2f} |")
    lines += ["", "P95和最差10%均值先逐种子计算再平均。", "", "## P5逐例对比", "",
              "学习方法按每例的三种子均值比较；IGA为该例单次搜索结果。这是描述性胜负统计。", "",
              "| 对照方法 | P5胜 / 平 / 负 | P5平均降低比例 |", "|---|---:|---:|"]
    for method, row in full["p5_pairwise"].items():
        lines.append(f"| {labels[method]} | {row['p5_wins']} / {row['ties']} / {row['p5_losses']} | {row['p5_reduction_percent']:.2f}% |")
    lines += ["", "## 原有60例和新增60例", "", "两个60例面板均按案例metadata的真实分组统计。", "",
              "| 方法 | 原有60例均值 | 新增60例均值 |", "|---|---:|---:|"]
    for method in models:
        values = [output["panels"][panel]["methods"][method]["mean"] for panel in ("original60", "additional60")]
        lines.append(f"| {labels[method]} | {values[0]:.2f} | {values[1]:.2f} |")
    lines += ["", "15个checkpoint在旧60例上的900个makespan全部逐例复现，1800个案例评测均完成且无超时/循环终止。", "",
              "每个模型保留其原评测的历史动作接口；P5兼容性证据见 ../inference_compatibility.md。", "",
              "完整validation120包含原选模用60例，不能视为独立测试集；新增60例只用于扩展覆盖，不重新选模。IGA只有一个搜索种子，未估计其跨搜索种子方差。"]
    (target / "report.md").write_text("\n".join(lines) + "\n")
    print(f"Completed validation120 report: {target / 'report.md'}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--wait", action="store_true")
    args = parser.parse_args()
    if args.wait:
        while read(args.root / "state.json")["status"] in {"starting", "running"}:
            time.sleep(15)
    analyze(args.root)
