#!/usr/bin/env python3
"""Evaluate frozen Stage1 Best checkpoints through one shared validator."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import shutil
import statistics
import subprocess
import time
import traceback

WEIGHTS = {"iid": .5, "ood_stress": .45, "ood_scale": .05}


class OverlapDrift(ValueError):
    """A model-local reproducibility difference, without invalid case content."""


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
    temp.replace(path)


def quantile(values, p):
    x = sorted(values)
    index = (len(x) - 1) * p
    lower, upper = math.floor(index), math.ceil(index)
    return x[lower] * (upper - index) + x[upper] * (index - lower) if upper != lower else x[lower]


def metrics(records):
    costs = [r["makespan"] for r in records]
    groups = {d: statistics.mean(r["makespan"] for r in records if r["distribution"] == d) for d in WEIGHTS}
    return {"case_count": len(records), "mean": statistics.mean(costs),
            "composite": sum(WEIGHTS[d] * groups[d] for d in WEIGHTS),
            "median": statistics.median(costs), "p95": quantile(costs, .95),
            "worst10_mean": statistics.mean(sorted(costs)[-math.ceil(len(costs) / 10):]),
            "worst": max(costs), "groups": groups}


def audit_result(job, manifest):
    output = read(job["output"])
    if output["status"] != "completed" or output["seed"] != job["seed"]:
        raise ValueError(f"Invalid evaluation status: {job['id']}")
    if digest(job["checkpoint"]) != job["checkpoint_sha256"]:
        raise ValueError(f"Frozen checkpoint changed: {job['id']}")
    if output["model_sha256"] != job["model_sha256"]:
        raise ValueError(f"Model digest mismatch: {job['id']}")
    if output["evaluation"].get("policy_history_mode") != job["policy_history_mode"]:
        raise ValueError(f"Inference history contract mismatch: {job['id']}")
    records = output["evaluation"]["records"]
    by_name = {r["case_dir"]: r for r in records}
    expected = {c["case"]: c for c in manifest["cases"]}
    if len(records) != 120 or set(by_name) != set(expected):
        raise ValueError(f"Evaluation case mismatch: {job['id']}")
    layout = None
    if manifest.get("case_order") and not job.get("reuse_result"):
        order = manifest["case_order"]
        expected_order_sha = hashlib.sha256(json.dumps(order).encode()).hexdigest()
        if output["evaluation"].get("case_order_sha256") != expected_order_sha or output["evaluation"].get("worker_count") != manifest["workers"]:
            raise ValueError(f"Evaluation batch contract mismatch: {job['id']}")
        per_worker = len(order) // manifest["workers"]
        layout = {name: (i // per_worker, i % per_worker) for i, name in enumerate(order)}
    for name, row in by_name.items():
        case = expected[name]
        if row["fingerprints"]["case_sha256"] != case["case_sha256"] or row["fingerprints"]["files"] != case["files"]:
            raise ValueError(f"Case content mismatch: {job['id']} {name}")
        if row["distribution"] != case["distribution"] or row["profile"] != case["profile"]:
            raise ValueError(f"Incorrect reporting label: {job['id']} {name}")
        if not row["completed"] or row["timeout"] or row["cycle_terminated"]:
            raise ValueError(f"Incomplete case: {job['id']} {name}")
        if layout and (row["rank_index"], row["round_index"]) != layout[name]:
            raise ValueError(f"Case-worker-round mismatch: {job['id']} {name}")
    reference = read(job["reference"])
    differences = [{"case": old["case_dir"], "old": old["makespan"],
                    "new": by_name[old["case_dir"]]["makespan"]}
                   for old in reference["cases"]
                   if abs(by_name[old["case_dir"]]["makespan"] - old["makespan"]) > 1e-6]
    audit = {"case_count": len(records), "completion_count": len(records),
             "overlap60_exact_match_count": 60 - len(differences),
             "overlap60_differences": differences, "metrics": metrics(records),
             "evaluation_seconds": output["evaluation_seconds"],
             "policy_history_mode": job["policy_history_mode"],
             "result_sha256": digest(job["output"]), "checked_unix_time": time.time()}
    atomic(Path(manifest["root"]) / "audits" / f"{job['id']}.json", audit)
    if differences:
        raise OverlapDrift(f"Overlap validation drift: {job['id']} has {len(differences)}/60 changed makespans; result requires review")
    return audit


def summarize(manifest, audits):
    root = Path(manifest["root"])
    groups = {}
    for method in ("P5", "multi_ppo", "fjsp_drl", "daniel", "l2d"):
        jobs = [j for j in manifest["jobs"] if j["method"] == method]
        if not all(j["id"] in audits for j in jobs):
            continue
        ms = [audits[j["id"]]["metrics"] for j in jobs]
        groups[method] = {
            "seed_count": 3, "seeds": [j["seed"] for j in jobs],
            "best_epochs": [j["best_epoch"] for j in jobs],
            "mean": statistics.mean(m["mean"] for m in ms),
            "seed_sd": statistics.stdev(m["mean"] for m in ms),
            "composite": statistics.mean(m["composite"] for m in ms),
            "p95_mean_across_seeds": statistics.mean(m["p95"] for m in ms),
            "worst10_mean_across_seeds": statistics.mean(m["worst10_mean"] for m in ms),
            "groups": {d: statistics.mean(m["groups"][d] for m in ms) for d in WEIGHTS},
            "per_seed": [{"seed": j["seed"], **audits[j["id"]]["metrics"]} for j in jobs],
        }
    iga = {phase: read(Path(manifest["iga_run_root"]) / phase / "summary.json")["validation120"]
           for phase in ("iga180", "iga1800")}
    summary = {"status": "completed" if len(audits) == len(manifest["jobs"]) else "running",
               "checkpoint_selection": manifest["checkpoint_selection"],
               "case_count": 120, "actual_distribution_counts": {d: sum(c["distribution"] == d for c in manifest["cases"]) for d in WEIGHTS},
               "completed_jobs": len(audits), "total_jobs": len(manifest["jobs"]),
               "learning": groups, "iga": iga, "updated_unix_time": time.time()}
    atomic(root / "summary.json", summary)
    if summary["status"] != "completed":
        return
    with (root / "per_case.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["method", "seed", "best_epoch", "case", "case_sha256", "distribution", "profile", "makespan"])
        for job in manifest["jobs"]:
            for row in read(job["output"])["evaluation"]["records"]:
                writer.writerow([job["method"], job["seed"], job["best_epoch"], row["case_dir"], row["fingerprints"]["case_sha256"], row["distribution"], row["profile"], row["makespan"]])
    text = ["# Stage1 validation120：固定原 validation60 Best 的补评", "",
            "5 个学习方法 × 3 seed × 120 案例；一个共享 validator。没有重新训练或重新选择 checkpoint。", "",
            "使用真实数据分组：60 IID / 54 OOD-stress / 6 OOD-scale。均值等于 0.50/0.45/0.05 加权综合分。", "",
            "学习方法为三个 seed 的均值 ± 样本标准差；IGA 为本轮已有的单搜索种子结果。", "",
            "每个模型沿用原评测的历史动作输入：P5 使用前一步动作且非活动行置 -1，四个基线使用环境历史；原60例逐例复现作为验收条件。", "",
            "| 方法 | 平均 makespan / 综合分 | IID | OOD-stress | OOD-scale |", "|---|---:|---:|---:|---:|"]
    table = [(name, v["mean"], v["seed_sd"], v["groups"]) for name, v in groups.items()]
    table += [(phase.upper(), v["mean_makespan"], None, {d: v["distributions"][d]["mean"] for d in WEIGHTS}) for phase, v in iga.items()]
    for name, value, sd, ds in sorted(table, key=lambda row: row[1]):
        cell = f"{value:.2f}" + (f" ± {sd:.2f}" if sd is not None else "")
        text.append(f"| {name} | {cell} | {ds['iid']:.2f} | {ds['ood_stress']:.2f} | {ds['ood_scale']:.2f} |")
    text += ["", "15 个 checkpoint 在原有 60 例上的 makespan 均逐例复现；所有 1800 个案例完成，无超时或循环终止。", "",
             "这是扩大评测覆盖范围后的验证结果，仍包含原选模用的60例，不是独立测试集结论。详细逐例结果见 per_case.csv，checkpoint/数据/代码指纹见 manifest.json 与 snapshot_manifest.json。"]
    (root / "report.md").write_text("\n".join(text) + "\n")


def run(manifest_path):
    manifest = read(manifest_path)
    root, code = Path(manifest["root"]), Path(manifest["code_root"])
    python = manifest["python"]
    state = {"status": "starting", "started_unix_time": time.time(), "completed_jobs": 0, "total_jobs": len(manifest["jobs"]), "jobs": {}, "review_required_jobs": []}
    state_path = root / "state.json"
    atomic(state_path, state)
    if Path(manifest["socket_path"]).exists():
        raise FileExistsError("Refusing to replace an existing evaluator socket")
    server = client = None
    audits = {}
    try:
        for job in manifest["jobs"]:
            if not job.get("reuse_result"):
                continue
            if digest(job["reuse_result"]) != job["reuse_result_sha256"]:
                raise ValueError(f"Reused result changed: {job['id']}")
            if Path(job["output"]).exists():
                raise FileExistsError(f"Refusing to replace result: {job['output']}")
            shutil.copy2(job["reuse_result"], job["output"])
            audits[job["id"]] = audit_result(job, manifest)
            state["jobs"][job["id"]] = {"status": "completed", "reused": True, "audit": audits[job["id"]]}
        state["completed_jobs"] = len(audits)
        atomic(state_path, state)
        summarize(manifest, audits)
        server_command = [python, "-u", str(code / "onpolicy/scripts/train/stage1_validation120_evaluator.py"),
                          "--history-contract", str(Path(manifest_path).resolve()),
                          "--source-command-json", manifest["source_command"], "--socket-path", manifest["socket_path"],
                          "--cpu-pool", manifest["cpu_set"], "--run-dir", str(root / "validator"),
                          "--eval-dataset-dir", manifest["dataset"], "--max-eval-cases", "120",
                          "--eval-case-offset", "0", "--cuda-memory-fraction", "0.9"]
        with (root / "logs/validator.log").open("a") as log:
            server = subprocess.Popen(server_command, stdout=log, stderr=subprocess.STDOUT)
        state["validator_pid"] = server.pid
        ready_path = root / "validator/service_status.json"
        startup_deadline = time.monotonic() + 900
        while not ready_path.exists() or read(ready_path).get("status") != "ready":
            if server.poll() is not None:
                raise RuntimeError(f"Validator exited during startup: {server.returncode}")
            if time.monotonic() > startup_deadline:
                raise TimeoutError("Validator did not become ready within 900 seconds")
            state["updated_unix_time"] = time.time()
            atomic(state_path, state)
            time.sleep(5)
        for job in manifest["jobs"]:
            if job["id"] in audits:
                continue
            state.update(status="running", current_job=job["id"], updated_unix_time=time.time())
            if Path(job["output"]).exists():
                raise FileExistsError(f"Refusing to replace result: {job['output']}")
            started = time.time()
            state["jobs"][job["id"]] = {"status": "running", "started_unix_time": started}
            atomic(state_path, state)
            command = [python, "-u", str(code / "onpolicy/scripts/train/evaluate_stage1_shared_checkpoint.py"),
                       "--socket-path", manifest["socket_path"], "--checkpoint", job["checkpoint"],
                       "--cpu-set", manifest["cpu_set"], "--seed", str(job["seed"]),
                       "--output", job["output"], "--label", f"validation120_{job['id']}_BestE{job['best_epoch']}",
                       "--evaluation-tau", str(manifest["evaluation_tau"]),
                       "--n-eval-rollout-threads", str(manifest["workers"])]
            print(f"[Validation120] start {job['id']} BestE{job['best_epoch']}", flush=True)
            with (root / "logs" / f"{job['id']}.log").open("a") as log:
                client = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
            while client.poll() is None:
                if server.poll() is not None:
                    raise RuntimeError("Validator exited during evaluation")
                state.update(updated_unix_time=time.time(), current_job_elapsed_seconds=time.time() - started)
                atomic(state_path, state)
                time.sleep(10)
            if client.returncode != 0:
                raise RuntimeError(f"Evaluation failed for {job['id']}: exit {client.returncode}")
            try:
                audits[job["id"]] = audit_result(job, manifest)
            except OverlapDrift as error:
                state["jobs"][job["id"]].update(status="needs_review", ended_unix_time=time.time(), error=str(error))
                state["review_required_jobs"].append(job["id"])
                atomic(state_path, state)
                print(f"[Validation120] quarantined {job['id']}: {error}; continuing independent models", flush=True)
                continue
            state["jobs"][job["id"]].update(status="completed", ended_unix_time=time.time(), audit=audits[job["id"]])
            state["completed_jobs"] = len(audits)
            atomic(state_path, state)
            summarize(manifest, audits)
            print(f"[Validation120] completed {job['id']} mean={audits[job['id']]['metrics']['mean']:.4f} overlap60=60/60 ({len(audits)}/{len(manifest['jobs'])})", flush=True)
        state.update(status="needs_review" if state["review_required_jobs"] else "completed", ended_unix_time=time.time())
        print(f"[Validation120] finished: accepted={len(audits)}/{len(manifest['jobs'])} review={state['review_required_jobs']}", flush=True)
    except BaseException:
        state.update(status="failed", ended_unix_time=time.time(), error=traceback.format_exc())
        if state.get("current_job") in state["jobs"]:
            state["jobs"][state["current_job"]]["status"] = "failed"
        raise
    finally:
        atomic(state_path, state)
        summary_path = root / "summary.json"
        if summary_path.exists():
            summary = read(summary_path)
            summary.update(status=state["status"], completed_jobs=state["completed_jobs"],
                           review_required_jobs=state["review_required_jobs"], error=state.get("error"))
            atomic(summary_path, summary)
        for process in (client, server):
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=90)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=30)
    if state["status"] == "completed":
        subprocess.run([python, "-u", str(code / "onpolicy/scripts/train/analyze_stage1_validation120.py"),
                        "--root", str(root)], check=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args()
    run(args.manifest)
