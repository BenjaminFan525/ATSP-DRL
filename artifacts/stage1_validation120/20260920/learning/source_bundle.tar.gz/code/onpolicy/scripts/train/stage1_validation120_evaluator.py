#!/usr/bin/env python3
"""Preserve the recorded inference history contract of frozen Stage1 models.

The August P5 evaluator passed the preceding policy action to its recurrent
selection encoder. The September baseline evaluator uses environment-owned
plane history and preserves inactive actions. This adapter also restores the
August evaluator's -1 action output for inactive aircraft. It pins the choice
by model digest; it
does not alter the environment, parameters, or the general shared evaluator.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from onpolicy.scripts.train import shared_hkbz_evaluator as shared


def contract_for_request(contracts, request):
    contract = contracts[request["model_sha256"]]
    if request["stage1_baseline"] != contract["stage1_baseline"]:
        raise ValueError("History contract belongs to a different model architecture")
    if contract["policy_history_mode"] not in {"legacy_previous_action_reset_inactive", "authoritative"}:
        raise ValueError("Unsupported Stage1 policy history mode")
    return contract["policy_history_mode"]


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--history-contract", type=Path, required=True)
    args, remaining = parser.parse_known_args()
    manifest = json.loads(args.history_contract.read_text())
    case_order = manifest.get("case_order")
    if case_order is not None:
        expected = {case["case"] for case in manifest["cases"]}
        if len(case_order) != len(expected) or set(case_order) != expected:
            raise ValueError("Pinned evaluation order must cover every case exactly once")
        if len(case_order) % manifest["workers"]:
            raise ValueError("Pinned evaluation order must split evenly across workers")
        from onpolicy.scripts.train import train_hkbz

        def pinned_cases(dataset, count, **kwargs):
            if Path(dataset).resolve() != Path(manifest["dataset"]).resolve():
                raise ValueError("Pinned evaluation order belongs to a different dataset")
            if int(count) != len(case_order) or int(kwargs.get("case_offset", 0)) != 0:
                raise ValueError("Pinned evaluation order requires the complete panel")
            return list(case_order)

        train_hkbz.list_case_folders = pinned_cases
    contracts = {
        job["model_sha256"]: {
            "stage1_baseline": "proposed" if job["method"] == "P5" else job["method"],
            "policy_history_mode": job["policy_history_mode"],
        }
        for job in manifest["jobs"]
    }
    if len(contracts) != len(manifest["jobs"]):
        raise ValueError("Every evaluation job must identify a unique model")
    evaluate = shared.evaluate_request

    def evaluate_with_history(runner, envs, pool, request):
        mode = contract_for_request(contracts, request)
        if runner.all_args.training_stage != "plane_pretrain" or runner.all_args.resource_policy != "heuristic":
            raise ValueError("Historical Stage1 inference adapter requires plane_pretrain + heuristic")
        original = runner._authoritative_policy_history
        original_act = runner.policy.act
        if mode == "legacy_previous_action_reset_inactive":
            runner._authoritative_policy_history = lambda infos, actions, count: np.asarray(actions).copy()

            def legacy_act(graph, states, active, last_op, last_site, **kwargs):
                actions, next_states = original_act(graph, states, active, last_op, last_site, **kwargs)
                inactive = torch.as_tensor(active, device=actions.device).squeeze(-1) == 0
                actions = actions.clone()
                actions[inactive] = -1
                return actions, next_states

            runner.policy.act = legacy_act
        try:
            result = evaluate(runner, envs, pool, request)
            result["policy_history_mode"] = mode
            if case_order is not None:
                result["case_order_sha256"] = hashlib.sha256(json.dumps(case_order).encode()).hexdigest()
                result["worker_count"] = len(envs.ps)
            return result
        finally:
            runner._authoritative_policy_history = original
            runner.policy.act = original_act

    shared.evaluate_request = evaluate_with_history
    sys.argv = [sys.argv[0], *remaining]
    return shared.serve(shared.parse_cli())


if __name__ == "__main__":
    raise SystemExit(main())
