#!/usr/bin/env bash
set -euo pipefail
cd /data/fanyx/HKBZ-environment
export PYTHONPATH=/data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_validation120_best_20260920_r3/code
export PYTHONUNBUFFERED=1
export PYTHONHASHSEED=0
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
export CUDA_VISIBLE_DEVICES=0
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export MPLCONFIGDIR=/data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_validation120_best_20260920_r3/mplconfig
exec taskset -c 0-127 /data/fanyx/conda/envs/maia-hkbz-cu124-20260903/bin/python -u /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_validation120_best_20260920_r3/code/onpolicy/scripts/train/run_stage1_validation120.py --manifest /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_validation120_best_20260920_r3/manifest.json >> /data/fanyx/HKBZ-environment/result/hkbz_train_logs/stage1_validation120_best_20260920_r3/logs/controller.log 2>&1
